<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-12 18:09:03 --> Config Class Initialized
INFO - 2022-05-12 18:09:03 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:09:03 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:09:03 --> Utf8 Class Initialized
INFO - 2022-05-12 18:09:03 --> URI Class Initialized
DEBUG - 2022-05-12 18:09:03 --> No URI present. Default controller set.
INFO - 2022-05-12 18:09:03 --> Router Class Initialized
INFO - 2022-05-12 18:09:03 --> Output Class Initialized
INFO - 2022-05-12 18:09:03 --> Security Class Initialized
DEBUG - 2022-05-12 18:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:09:03 --> Input Class Initialized
INFO - 2022-05-12 18:09:04 --> Language Class Initialized
INFO - 2022-05-12 18:09:04 --> Language Class Initialized
INFO - 2022-05-12 18:09:04 --> Config Class Initialized
INFO - 2022-05-12 18:09:04 --> Loader Class Initialized
INFO - 2022-05-12 18:09:04 --> Helper loaded: url_helper
INFO - 2022-05-12 18:09:04 --> Database Driver Class Initialized
INFO - 2022-05-12 18:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:09:04 --> Controller Class Initialized
DEBUG - 2022-05-12 18:09:04 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:09:04 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:09:04 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-12 18:09:05 --> Final output sent to browser
DEBUG - 2022-05-12 18:09:05 --> Total execution time: 1.6866
INFO - 2022-05-12 18:09:24 --> Config Class Initialized
INFO - 2022-05-12 18:09:24 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:09:24 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:09:24 --> Utf8 Class Initialized
INFO - 2022-05-12 18:09:24 --> URI Class Initialized
INFO - 2022-05-12 18:09:24 --> Router Class Initialized
INFO - 2022-05-12 18:09:24 --> Output Class Initialized
INFO - 2022-05-12 18:09:24 --> Security Class Initialized
DEBUG - 2022-05-12 18:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:09:24 --> Input Class Initialized
INFO - 2022-05-12 18:09:24 --> Language Class Initialized
INFO - 2022-05-12 18:09:24 --> Language Class Initialized
INFO - 2022-05-12 18:09:24 --> Config Class Initialized
INFO - 2022-05-12 18:09:24 --> Loader Class Initialized
INFO - 2022-05-12 18:09:24 --> Helper loaded: url_helper
INFO - 2022-05-12 18:09:24 --> Database Driver Class Initialized
INFO - 2022-05-12 18:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:09:24 --> Controller Class Initialized
DEBUG - 2022-05-12 18:09:24 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:09:24 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:09:24 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:09:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:09:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-12 18:09:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:09:24 --> Final output sent to browser
DEBUG - 2022-05-12 18:09:24 --> Total execution time: 0.0399
INFO - 2022-05-12 18:09:28 --> Config Class Initialized
INFO - 2022-05-12 18:09:28 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:09:28 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:09:28 --> Utf8 Class Initialized
INFO - 2022-05-12 18:09:28 --> URI Class Initialized
INFO - 2022-05-12 18:09:28 --> Router Class Initialized
INFO - 2022-05-12 18:09:28 --> Output Class Initialized
INFO - 2022-05-12 18:09:28 --> Security Class Initialized
DEBUG - 2022-05-12 18:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:09:28 --> Input Class Initialized
INFO - 2022-05-12 18:09:28 --> Language Class Initialized
INFO - 2022-05-12 18:09:28 --> Language Class Initialized
INFO - 2022-05-12 18:09:28 --> Config Class Initialized
INFO - 2022-05-12 18:09:28 --> Loader Class Initialized
INFO - 2022-05-12 18:09:28 --> Helper loaded: url_helper
INFO - 2022-05-12 18:09:28 --> Database Driver Class Initialized
INFO - 2022-05-12 18:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:09:29 --> Controller Class Initialized
DEBUG - 2022-05-12 18:09:29 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:09:29 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:09:29 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:09:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:09:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-12 18:09:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:09:29 --> Final output sent to browser
DEBUG - 2022-05-12 18:09:29 --> Total execution time: 0.8909
INFO - 2022-05-12 18:09:56 --> Config Class Initialized
INFO - 2022-05-12 18:09:56 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:09:56 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:09:56 --> Utf8 Class Initialized
INFO - 2022-05-12 18:09:56 --> URI Class Initialized
INFO - 2022-05-12 18:09:56 --> Router Class Initialized
INFO - 2022-05-12 18:09:56 --> Output Class Initialized
INFO - 2022-05-12 18:09:56 --> Security Class Initialized
DEBUG - 2022-05-12 18:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:09:56 --> Input Class Initialized
INFO - 2022-05-12 18:09:56 --> Language Class Initialized
INFO - 2022-05-12 18:09:56 --> Language Class Initialized
INFO - 2022-05-12 18:09:56 --> Config Class Initialized
INFO - 2022-05-12 18:09:56 --> Loader Class Initialized
INFO - 2022-05-12 18:09:56 --> Helper loaded: url_helper
INFO - 2022-05-12 18:09:56 --> Database Driver Class Initialized
INFO - 2022-05-12 18:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:09:56 --> Controller Class Initialized
DEBUG - 2022-05-12 18:09:56 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:09:56 --> Model Class Initialized
DEBUG - 2022-05-12 18:09:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:09:56 --> Model Class Initialized
DEBUG - 2022-05-12 18:10:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:10:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:10:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:10:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:10:00 --> Final output sent to browser
DEBUG - 2022-05-12 18:10:00 --> Total execution time: 3.7845
INFO - 2022-05-12 18:12:26 --> Config Class Initialized
INFO - 2022-05-12 18:12:26 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:12:26 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:12:26 --> Utf8 Class Initialized
INFO - 2022-05-12 18:12:26 --> URI Class Initialized
INFO - 2022-05-12 18:12:26 --> Router Class Initialized
INFO - 2022-05-12 18:12:26 --> Output Class Initialized
INFO - 2022-05-12 18:12:26 --> Security Class Initialized
DEBUG - 2022-05-12 18:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:12:26 --> Input Class Initialized
INFO - 2022-05-12 18:12:26 --> Language Class Initialized
INFO - 2022-05-12 18:12:26 --> Language Class Initialized
INFO - 2022-05-12 18:12:26 --> Config Class Initialized
INFO - 2022-05-12 18:12:26 --> Loader Class Initialized
INFO - 2022-05-12 18:12:26 --> Helper loaded: url_helper
INFO - 2022-05-12 18:12:26 --> Database Driver Class Initialized
INFO - 2022-05-12 18:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:12:26 --> Controller Class Initialized
DEBUG - 2022-05-12 18:12:26 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:12:26 --> Model Class Initialized
DEBUG - 2022-05-12 18:12:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:12:26 --> Model Class Initialized
DEBUG - 2022-05-12 18:12:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:12:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:12:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:12:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:12:26 --> Final output sent to browser
DEBUG - 2022-05-12 18:12:26 --> Total execution time: 0.0390
INFO - 2022-05-12 18:19:01 --> Config Class Initialized
INFO - 2022-05-12 18:19:01 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:19:01 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:19:01 --> Utf8 Class Initialized
INFO - 2022-05-12 18:19:01 --> URI Class Initialized
INFO - 2022-05-12 18:19:01 --> Router Class Initialized
INFO - 2022-05-12 18:19:01 --> Output Class Initialized
INFO - 2022-05-12 18:19:01 --> Security Class Initialized
DEBUG - 2022-05-12 18:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:19:01 --> Input Class Initialized
INFO - 2022-05-12 18:19:01 --> Language Class Initialized
INFO - 2022-05-12 18:19:01 --> Language Class Initialized
INFO - 2022-05-12 18:19:01 --> Config Class Initialized
INFO - 2022-05-12 18:19:01 --> Loader Class Initialized
INFO - 2022-05-12 18:19:01 --> Helper loaded: url_helper
INFO - 2022-05-12 18:19:01 --> Database Driver Class Initialized
INFO - 2022-05-12 18:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:19:01 --> Controller Class Initialized
DEBUG - 2022-05-12 18:19:01 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:19:01 --> Model Class Initialized
DEBUG - 2022-05-12 18:19:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:19:01 --> Model Class Initialized
DEBUG - 2022-05-12 18:19:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:19:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:19:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-12 18:19:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:19:01 --> Final output sent to browser
DEBUG - 2022-05-12 18:19:01 --> Total execution time: 0.0385
INFO - 2022-05-12 18:19:25 --> Config Class Initialized
INFO - 2022-05-12 18:19:25 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:19:25 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:19:25 --> Utf8 Class Initialized
INFO - 2022-05-12 18:19:25 --> URI Class Initialized
INFO - 2022-05-12 18:19:25 --> Router Class Initialized
INFO - 2022-05-12 18:19:25 --> Output Class Initialized
INFO - 2022-05-12 18:19:25 --> Security Class Initialized
DEBUG - 2022-05-12 18:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:19:25 --> Input Class Initialized
INFO - 2022-05-12 18:19:25 --> Language Class Initialized
INFO - 2022-05-12 18:19:25 --> Language Class Initialized
INFO - 2022-05-12 18:19:25 --> Config Class Initialized
INFO - 2022-05-12 18:19:25 --> Loader Class Initialized
INFO - 2022-05-12 18:19:25 --> Helper loaded: url_helper
INFO - 2022-05-12 18:19:25 --> Database Driver Class Initialized
INFO - 2022-05-12 18:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:19:25 --> Controller Class Initialized
DEBUG - 2022-05-12 18:19:25 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:19:25 --> Model Class Initialized
DEBUG - 2022-05-12 18:19:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:19:25 --> Model Class Initialized
DEBUG - 2022-05-12 18:19:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:19:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:19:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-12 18:19:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:19:25 --> Final output sent to browser
DEBUG - 2022-05-12 18:19:25 --> Total execution time: 0.0435
INFO - 2022-05-12 18:19:46 --> Config Class Initialized
INFO - 2022-05-12 18:19:46 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:19:46 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:19:46 --> Utf8 Class Initialized
INFO - 2022-05-12 18:19:46 --> URI Class Initialized
INFO - 2022-05-12 18:19:46 --> Router Class Initialized
INFO - 2022-05-12 18:19:46 --> Output Class Initialized
INFO - 2022-05-12 18:19:46 --> Security Class Initialized
DEBUG - 2022-05-12 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:19:46 --> Input Class Initialized
INFO - 2022-05-12 18:19:46 --> Language Class Initialized
INFO - 2022-05-12 18:19:46 --> Language Class Initialized
INFO - 2022-05-12 18:19:46 --> Config Class Initialized
INFO - 2022-05-12 18:19:46 --> Loader Class Initialized
INFO - 2022-05-12 18:19:46 --> Helper loaded: url_helper
INFO - 2022-05-12 18:19:46 --> Database Driver Class Initialized
INFO - 2022-05-12 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:19:46 --> Controller Class Initialized
DEBUG - 2022-05-12 18:19:46 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:19:46 --> Model Class Initialized
DEBUG - 2022-05-12 18:19:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:19:46 --> Model Class Initialized
INFO - 2022-05-12 18:19:46 --> Final output sent to browser
DEBUG - 2022-05-12 18:19:46 --> Total execution time: 0.0379
INFO - 2022-05-12 18:21:07 --> Config Class Initialized
INFO - 2022-05-12 18:21:07 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:21:07 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:21:07 --> Utf8 Class Initialized
INFO - 2022-05-12 18:21:07 --> URI Class Initialized
INFO - 2022-05-12 18:21:07 --> Router Class Initialized
INFO - 2022-05-12 18:21:07 --> Output Class Initialized
INFO - 2022-05-12 18:21:07 --> Security Class Initialized
DEBUG - 2022-05-12 18:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:21:07 --> Input Class Initialized
INFO - 2022-05-12 18:21:07 --> Language Class Initialized
INFO - 2022-05-12 18:21:07 --> Language Class Initialized
INFO - 2022-05-12 18:21:07 --> Config Class Initialized
INFO - 2022-05-12 18:21:07 --> Loader Class Initialized
INFO - 2022-05-12 18:21:07 --> Helper loaded: url_helper
INFO - 2022-05-12 18:21:07 --> Database Driver Class Initialized
INFO - 2022-05-12 18:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:21:07 --> Controller Class Initialized
DEBUG - 2022-05-12 18:21:07 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:21:07 --> Model Class Initialized
DEBUG - 2022-05-12 18:21:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:21:07 --> Model Class Initialized
INFO - 2022-05-12 18:21:12 --> Upload Class Initialized
INFO - 2022-05-12 18:21:15 --> Config Class Initialized
INFO - 2022-05-12 18:21:15 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:21:15 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:21:15 --> Utf8 Class Initialized
INFO - 2022-05-12 18:21:15 --> URI Class Initialized
INFO - 2022-05-12 18:21:15 --> Router Class Initialized
INFO - 2022-05-12 18:21:15 --> Output Class Initialized
INFO - 2022-05-12 18:21:15 --> Security Class Initialized
DEBUG - 2022-05-12 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:21:15 --> Input Class Initialized
INFO - 2022-05-12 18:21:15 --> Language Class Initialized
INFO - 2022-05-12 18:21:15 --> Language Class Initialized
INFO - 2022-05-12 18:21:15 --> Config Class Initialized
INFO - 2022-05-12 18:21:15 --> Loader Class Initialized
INFO - 2022-05-12 18:21:15 --> Helper loaded: url_helper
INFO - 2022-05-12 18:21:15 --> Database Driver Class Initialized
INFO - 2022-05-12 18:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:21:15 --> Controller Class Initialized
DEBUG - 2022-05-12 18:21:15 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:21:15 --> Model Class Initialized
DEBUG - 2022-05-12 18:21:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:21:15 --> Model Class Initialized
DEBUG - 2022-05-12 18:21:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:21:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:21:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:21:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:21:15 --> Final output sent to browser
DEBUG - 2022-05-12 18:21:15 --> Total execution time: 0.0399
INFO - 2022-05-12 18:21:20 --> Config Class Initialized
INFO - 2022-05-12 18:21:20 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:21:20 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:21:20 --> Utf8 Class Initialized
INFO - 2022-05-12 18:21:20 --> URI Class Initialized
INFO - 2022-05-12 18:21:20 --> Router Class Initialized
INFO - 2022-05-12 18:21:20 --> Output Class Initialized
INFO - 2022-05-12 18:21:20 --> Security Class Initialized
DEBUG - 2022-05-12 18:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:21:20 --> Input Class Initialized
INFO - 2022-05-12 18:21:20 --> Language Class Initialized
INFO - 2022-05-12 18:21:20 --> Language Class Initialized
INFO - 2022-05-12 18:21:20 --> Config Class Initialized
INFO - 2022-05-12 18:21:20 --> Loader Class Initialized
INFO - 2022-05-12 18:21:20 --> Helper loaded: url_helper
INFO - 2022-05-12 18:21:20 --> Database Driver Class Initialized
INFO - 2022-05-12 18:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:21:20 --> Controller Class Initialized
DEBUG - 2022-05-12 18:21:20 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:21:20 --> Model Class Initialized
DEBUG - 2022-05-12 18:21:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:21:20 --> Model Class Initialized
ERROR - 2022-05-12 18:21:20 --> Query error: Unknown column 'vd.id' in 'where clause' - Invalid query: SELECT `vd`.`v_id`, `vd`.`varient`, `vd`.`price`, `vd`.`current_on_road`, `cat`.`c_name`, `b`.`b_name`, `m`.`m_name`
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `b`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
WHERE `vd`.`id` = '2'
GROUP BY `vd`.`v_id`
INFO - 2022-05-12 18:21:20 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-12 18:21:45 --> Config Class Initialized
INFO - 2022-05-12 18:21:45 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:21:45 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:21:45 --> Utf8 Class Initialized
INFO - 2022-05-12 18:21:45 --> URI Class Initialized
INFO - 2022-05-12 18:21:45 --> Router Class Initialized
INFO - 2022-05-12 18:21:45 --> Output Class Initialized
INFO - 2022-05-12 18:21:45 --> Security Class Initialized
DEBUG - 2022-05-12 18:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:21:45 --> Input Class Initialized
INFO - 2022-05-12 18:21:45 --> Language Class Initialized
INFO - 2022-05-12 18:21:45 --> Language Class Initialized
INFO - 2022-05-12 18:21:45 --> Config Class Initialized
INFO - 2022-05-12 18:21:45 --> Loader Class Initialized
INFO - 2022-05-12 18:21:45 --> Helper loaded: url_helper
INFO - 2022-05-12 18:21:45 --> Database Driver Class Initialized
INFO - 2022-05-12 18:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:21:45 --> Controller Class Initialized
DEBUG - 2022-05-12 18:21:45 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:21:45 --> Model Class Initialized
DEBUG - 2022-05-12 18:21:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:21:45 --> Model Class Initialized
INFO - 2022-05-12 18:23:18 --> Config Class Initialized
INFO - 2022-05-12 18:23:18 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:23:18 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:23:18 --> Utf8 Class Initialized
INFO - 2022-05-12 18:23:18 --> URI Class Initialized
INFO - 2022-05-12 18:23:18 --> Router Class Initialized
INFO - 2022-05-12 18:23:18 --> Output Class Initialized
INFO - 2022-05-12 18:23:18 --> Security Class Initialized
DEBUG - 2022-05-12 18:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:23:18 --> Input Class Initialized
INFO - 2022-05-12 18:23:18 --> Language Class Initialized
INFO - 2022-05-12 18:23:18 --> Language Class Initialized
INFO - 2022-05-12 18:23:18 --> Config Class Initialized
INFO - 2022-05-12 18:23:18 --> Loader Class Initialized
INFO - 2022-05-12 18:23:18 --> Helper loaded: url_helper
INFO - 2022-05-12 18:23:18 --> Database Driver Class Initialized
INFO - 2022-05-12 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:23:18 --> Controller Class Initialized
DEBUG - 2022-05-12 18:23:18 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:23:18 --> Model Class Initialized
DEBUG - 2022-05-12 18:23:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:23:18 --> Model Class Initialized
INFO - 2022-05-12 18:24:48 --> Config Class Initialized
INFO - 2022-05-12 18:24:48 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:24:48 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:24:48 --> Utf8 Class Initialized
INFO - 2022-05-12 18:24:48 --> URI Class Initialized
INFO - 2022-05-12 18:24:48 --> Router Class Initialized
INFO - 2022-05-12 18:24:48 --> Output Class Initialized
INFO - 2022-05-12 18:24:48 --> Security Class Initialized
DEBUG - 2022-05-12 18:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:24:48 --> Input Class Initialized
INFO - 2022-05-12 18:24:48 --> Language Class Initialized
INFO - 2022-05-12 18:24:48 --> Language Class Initialized
INFO - 2022-05-12 18:24:48 --> Config Class Initialized
INFO - 2022-05-12 18:24:48 --> Loader Class Initialized
INFO - 2022-05-12 18:24:48 --> Helper loaded: url_helper
INFO - 2022-05-12 18:24:48 --> Database Driver Class Initialized
INFO - 2022-05-12 18:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:24:48 --> Controller Class Initialized
DEBUG - 2022-05-12 18:24:48 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:24:48 --> Model Class Initialized
DEBUG - 2022-05-12 18:24:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:24:48 --> Model Class Initialized
INFO - 2022-05-12 18:25:00 --> Config Class Initialized
INFO - 2022-05-12 18:25:00 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:25:00 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:25:00 --> Utf8 Class Initialized
INFO - 2022-05-12 18:25:00 --> URI Class Initialized
INFO - 2022-05-12 18:25:00 --> Router Class Initialized
INFO - 2022-05-12 18:25:00 --> Output Class Initialized
INFO - 2022-05-12 18:25:00 --> Security Class Initialized
DEBUG - 2022-05-12 18:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:25:00 --> Input Class Initialized
INFO - 2022-05-12 18:25:00 --> Language Class Initialized
INFO - 2022-05-12 18:25:00 --> Language Class Initialized
INFO - 2022-05-12 18:25:00 --> Config Class Initialized
INFO - 2022-05-12 18:25:00 --> Loader Class Initialized
INFO - 2022-05-12 18:25:00 --> Helper loaded: url_helper
INFO - 2022-05-12 18:25:00 --> Database Driver Class Initialized
INFO - 2022-05-12 18:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:25:00 --> Controller Class Initialized
DEBUG - 2022-05-12 18:25:00 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:25:00 --> Model Class Initialized
DEBUG - 2022-05-12 18:25:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:25:00 --> Model Class Initialized
INFO - 2022-05-12 18:32:24 --> Config Class Initialized
INFO - 2022-05-12 18:32:24 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:32:24 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:32:24 --> Utf8 Class Initialized
INFO - 2022-05-12 18:32:24 --> URI Class Initialized
INFO - 2022-05-12 18:32:25 --> Router Class Initialized
INFO - 2022-05-12 18:32:25 --> Output Class Initialized
INFO - 2022-05-12 18:32:25 --> Security Class Initialized
DEBUG - 2022-05-12 18:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:32:25 --> Input Class Initialized
INFO - 2022-05-12 18:32:25 --> Language Class Initialized
INFO - 2022-05-12 18:32:25 --> Language Class Initialized
INFO - 2022-05-12 18:32:25 --> Config Class Initialized
INFO - 2022-05-12 18:32:25 --> Loader Class Initialized
INFO - 2022-05-12 18:32:25 --> Helper loaded: url_helper
INFO - 2022-05-12 18:32:25 --> Database Driver Class Initialized
INFO - 2022-05-12 18:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:32:25 --> Controller Class Initialized
DEBUG - 2022-05-12 18:32:25 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:32:25 --> Model Class Initialized
DEBUG - 2022-05-12 18:32:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:32:25 --> Model Class Initialized
INFO - 2022-05-12 18:32:32 --> Config Class Initialized
INFO - 2022-05-12 18:32:32 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:32:32 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:32:32 --> Utf8 Class Initialized
INFO - 2022-05-12 18:32:32 --> URI Class Initialized
INFO - 2022-05-12 18:32:32 --> Router Class Initialized
INFO - 2022-05-12 18:32:32 --> Output Class Initialized
INFO - 2022-05-12 18:32:32 --> Security Class Initialized
DEBUG - 2022-05-12 18:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:32:32 --> Input Class Initialized
INFO - 2022-05-12 18:32:32 --> Language Class Initialized
INFO - 2022-05-12 18:32:32 --> Language Class Initialized
INFO - 2022-05-12 18:32:32 --> Config Class Initialized
INFO - 2022-05-12 18:32:32 --> Loader Class Initialized
INFO - 2022-05-12 18:32:32 --> Helper loaded: url_helper
INFO - 2022-05-12 18:32:32 --> Database Driver Class Initialized
INFO - 2022-05-12 18:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:32:33 --> Controller Class Initialized
DEBUG - 2022-05-12 18:32:33 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:32:33 --> Model Class Initialized
DEBUG - 2022-05-12 18:32:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:32:33 --> Model Class Initialized
DEBUG - 2022-05-12 18:32:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:32:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:32:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:32:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:32:33 --> Final output sent to browser
DEBUG - 2022-05-12 18:32:33 --> Total execution time: 0.0336
INFO - 2022-05-12 18:32:34 --> Config Class Initialized
INFO - 2022-05-12 18:32:34 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:32:34 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:32:34 --> Utf8 Class Initialized
INFO - 2022-05-12 18:32:34 --> URI Class Initialized
INFO - 2022-05-12 18:32:34 --> Router Class Initialized
INFO - 2022-05-12 18:32:34 --> Output Class Initialized
INFO - 2022-05-12 18:32:34 --> Security Class Initialized
DEBUG - 2022-05-12 18:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:32:34 --> Input Class Initialized
INFO - 2022-05-12 18:32:34 --> Language Class Initialized
INFO - 2022-05-12 18:32:34 --> Language Class Initialized
INFO - 2022-05-12 18:32:34 --> Config Class Initialized
INFO - 2022-05-12 18:32:34 --> Loader Class Initialized
INFO - 2022-05-12 18:32:34 --> Helper loaded: url_helper
INFO - 2022-05-12 18:32:34 --> Database Driver Class Initialized
INFO - 2022-05-12 18:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:32:34 --> Controller Class Initialized
DEBUG - 2022-05-12 18:32:34 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:32:34 --> Model Class Initialized
DEBUG - 2022-05-12 18:32:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:32:34 --> Model Class Initialized
DEBUG - 2022-05-12 18:32:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:32:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:32:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:32:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:32:34 --> Final output sent to browser
DEBUG - 2022-05-12 18:32:34 --> Total execution time: 0.0486
INFO - 2022-05-12 18:32:37 --> Config Class Initialized
INFO - 2022-05-12 18:32:37 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:32:37 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:32:37 --> Utf8 Class Initialized
INFO - 2022-05-12 18:32:37 --> URI Class Initialized
INFO - 2022-05-12 18:32:37 --> Router Class Initialized
INFO - 2022-05-12 18:32:37 --> Output Class Initialized
INFO - 2022-05-12 18:32:37 --> Security Class Initialized
DEBUG - 2022-05-12 18:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:32:37 --> Input Class Initialized
INFO - 2022-05-12 18:32:37 --> Language Class Initialized
INFO - 2022-05-12 18:32:37 --> Language Class Initialized
INFO - 2022-05-12 18:32:37 --> Config Class Initialized
INFO - 2022-05-12 18:32:37 --> Loader Class Initialized
INFO - 2022-05-12 18:32:37 --> Helper loaded: url_helper
INFO - 2022-05-12 18:32:37 --> Database Driver Class Initialized
INFO - 2022-05-12 18:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:32:37 --> Controller Class Initialized
DEBUG - 2022-05-12 18:32:37 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:32:37 --> Model Class Initialized
DEBUG - 2022-05-12 18:32:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:32:37 --> Model Class Initialized
INFO - 2022-05-12 18:33:37 --> Config Class Initialized
INFO - 2022-05-12 18:33:37 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:33:37 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:33:37 --> Utf8 Class Initialized
INFO - 2022-05-12 18:33:37 --> URI Class Initialized
INFO - 2022-05-12 18:33:37 --> Router Class Initialized
INFO - 2022-05-12 18:33:37 --> Output Class Initialized
INFO - 2022-05-12 18:33:37 --> Security Class Initialized
DEBUG - 2022-05-12 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:33:37 --> Input Class Initialized
INFO - 2022-05-12 18:33:37 --> Language Class Initialized
INFO - 2022-05-12 18:33:37 --> Language Class Initialized
INFO - 2022-05-12 18:33:37 --> Config Class Initialized
INFO - 2022-05-12 18:33:37 --> Loader Class Initialized
INFO - 2022-05-12 18:33:37 --> Helper loaded: url_helper
INFO - 2022-05-12 18:33:37 --> Database Driver Class Initialized
INFO - 2022-05-12 18:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:33:37 --> Controller Class Initialized
DEBUG - 2022-05-12 18:33:37 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:33:37 --> Model Class Initialized
DEBUG - 2022-05-12 18:33:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:33:37 --> Model Class Initialized
INFO - 2022-05-12 18:33:39 --> Config Class Initialized
INFO - 2022-05-12 18:33:39 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:33:39 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:33:39 --> Utf8 Class Initialized
INFO - 2022-05-12 18:33:39 --> URI Class Initialized
INFO - 2022-05-12 18:33:39 --> Router Class Initialized
INFO - 2022-05-12 18:33:39 --> Output Class Initialized
INFO - 2022-05-12 18:33:39 --> Security Class Initialized
DEBUG - 2022-05-12 18:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:33:39 --> Input Class Initialized
INFO - 2022-05-12 18:33:39 --> Language Class Initialized
INFO - 2022-05-12 18:33:39 --> Language Class Initialized
INFO - 2022-05-12 18:33:39 --> Config Class Initialized
INFO - 2022-05-12 18:33:39 --> Loader Class Initialized
INFO - 2022-05-12 18:33:39 --> Helper loaded: url_helper
INFO - 2022-05-12 18:33:39 --> Database Driver Class Initialized
INFO - 2022-05-12 18:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:33:39 --> Controller Class Initialized
DEBUG - 2022-05-12 18:33:39 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:33:39 --> Model Class Initialized
DEBUG - 2022-05-12 18:33:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:33:39 --> Model Class Initialized
DEBUG - 2022-05-12 18:33:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:33:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:33:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:33:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:33:39 --> Final output sent to browser
DEBUG - 2022-05-12 18:33:39 --> Total execution time: 0.0425
INFO - 2022-05-12 18:33:41 --> Config Class Initialized
INFO - 2022-05-12 18:33:41 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:33:41 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:33:41 --> Utf8 Class Initialized
INFO - 2022-05-12 18:33:41 --> URI Class Initialized
INFO - 2022-05-12 18:33:41 --> Router Class Initialized
INFO - 2022-05-12 18:33:41 --> Output Class Initialized
INFO - 2022-05-12 18:33:41 --> Security Class Initialized
DEBUG - 2022-05-12 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:33:41 --> Input Class Initialized
INFO - 2022-05-12 18:33:41 --> Language Class Initialized
INFO - 2022-05-12 18:33:41 --> Language Class Initialized
INFO - 2022-05-12 18:33:41 --> Config Class Initialized
INFO - 2022-05-12 18:33:41 --> Loader Class Initialized
INFO - 2022-05-12 18:33:41 --> Helper loaded: url_helper
INFO - 2022-05-12 18:33:41 --> Database Driver Class Initialized
INFO - 2022-05-12 18:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:33:41 --> Controller Class Initialized
DEBUG - 2022-05-12 18:33:41 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:33:41 --> Model Class Initialized
DEBUG - 2022-05-12 18:33:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:33:41 --> Model Class Initialized
INFO - 2022-05-12 18:34:42 --> Config Class Initialized
INFO - 2022-05-12 18:34:42 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:34:42 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:34:42 --> Utf8 Class Initialized
INFO - 2022-05-12 18:34:42 --> URI Class Initialized
INFO - 2022-05-12 18:34:42 --> Router Class Initialized
INFO - 2022-05-12 18:34:42 --> Output Class Initialized
INFO - 2022-05-12 18:34:42 --> Security Class Initialized
DEBUG - 2022-05-12 18:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:34:42 --> Input Class Initialized
INFO - 2022-05-12 18:34:42 --> Language Class Initialized
INFO - 2022-05-12 18:34:42 --> Language Class Initialized
INFO - 2022-05-12 18:34:42 --> Config Class Initialized
INFO - 2022-05-12 18:34:42 --> Loader Class Initialized
INFO - 2022-05-12 18:34:42 --> Helper loaded: url_helper
INFO - 2022-05-12 18:34:42 --> Database Driver Class Initialized
INFO - 2022-05-12 18:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:34:42 --> Controller Class Initialized
DEBUG - 2022-05-12 18:34:42 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:34:42 --> Model Class Initialized
DEBUG - 2022-05-12 18:34:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:34:42 --> Model Class Initialized
INFO - 2022-05-12 18:34:43 --> Config Class Initialized
INFO - 2022-05-12 18:34:43 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:34:43 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:34:43 --> Utf8 Class Initialized
INFO - 2022-05-12 18:34:43 --> URI Class Initialized
INFO - 2022-05-12 18:34:43 --> Router Class Initialized
INFO - 2022-05-12 18:34:43 --> Output Class Initialized
INFO - 2022-05-12 18:34:43 --> Security Class Initialized
DEBUG - 2022-05-12 18:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:34:43 --> Input Class Initialized
INFO - 2022-05-12 18:34:43 --> Language Class Initialized
INFO - 2022-05-12 18:34:43 --> Language Class Initialized
INFO - 2022-05-12 18:34:43 --> Config Class Initialized
INFO - 2022-05-12 18:34:43 --> Loader Class Initialized
INFO - 2022-05-12 18:34:43 --> Helper loaded: url_helper
INFO - 2022-05-12 18:34:43 --> Database Driver Class Initialized
INFO - 2022-05-12 18:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:34:43 --> Controller Class Initialized
DEBUG - 2022-05-12 18:34:43 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:34:43 --> Model Class Initialized
DEBUG - 2022-05-12 18:34:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:34:43 --> Model Class Initialized
INFO - 2022-05-12 18:36:08 --> Config Class Initialized
INFO - 2022-05-12 18:36:08 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:36:08 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:36:08 --> Utf8 Class Initialized
INFO - 2022-05-12 18:36:08 --> URI Class Initialized
INFO - 2022-05-12 18:36:08 --> Router Class Initialized
INFO - 2022-05-12 18:36:08 --> Output Class Initialized
INFO - 2022-05-12 18:36:08 --> Security Class Initialized
DEBUG - 2022-05-12 18:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:36:08 --> Input Class Initialized
INFO - 2022-05-12 18:36:08 --> Language Class Initialized
INFO - 2022-05-12 18:36:08 --> Language Class Initialized
INFO - 2022-05-12 18:36:08 --> Config Class Initialized
INFO - 2022-05-12 18:36:08 --> Loader Class Initialized
INFO - 2022-05-12 18:36:08 --> Helper loaded: url_helper
INFO - 2022-05-12 18:36:08 --> Database Driver Class Initialized
INFO - 2022-05-12 18:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:36:09 --> Controller Class Initialized
DEBUG - 2022-05-12 18:36:09 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:36:09 --> Model Class Initialized
DEBUG - 2022-05-12 18:36:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:36:09 --> Model Class Initialized
INFO - 2022-05-12 18:36:32 --> Config Class Initialized
INFO - 2022-05-12 18:36:32 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:36:32 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:36:32 --> Utf8 Class Initialized
INFO - 2022-05-12 18:36:32 --> URI Class Initialized
INFO - 2022-05-12 18:36:32 --> Router Class Initialized
INFO - 2022-05-12 18:36:32 --> Output Class Initialized
INFO - 2022-05-12 18:36:32 --> Security Class Initialized
DEBUG - 2022-05-12 18:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:36:32 --> Input Class Initialized
INFO - 2022-05-12 18:36:32 --> Language Class Initialized
INFO - 2022-05-12 18:36:32 --> Language Class Initialized
INFO - 2022-05-12 18:36:32 --> Config Class Initialized
INFO - 2022-05-12 18:36:32 --> Loader Class Initialized
INFO - 2022-05-12 18:36:32 --> Helper loaded: url_helper
INFO - 2022-05-12 18:36:32 --> Database Driver Class Initialized
INFO - 2022-05-12 18:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:36:32 --> Controller Class Initialized
DEBUG - 2022-05-12 18:36:32 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:36:32 --> Model Class Initialized
DEBUG - 2022-05-12 18:36:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:36:32 --> Model Class Initialized
DEBUG - 2022-05-12 18:36:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:36:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:36:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:36:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:36:32 --> Final output sent to browser
DEBUG - 2022-05-12 18:36:32 --> Total execution time: 0.0738
INFO - 2022-05-12 18:36:35 --> Config Class Initialized
INFO - 2022-05-12 18:36:35 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:36:35 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:36:35 --> Utf8 Class Initialized
INFO - 2022-05-12 18:36:35 --> URI Class Initialized
INFO - 2022-05-12 18:36:35 --> Router Class Initialized
INFO - 2022-05-12 18:36:35 --> Output Class Initialized
INFO - 2022-05-12 18:36:35 --> Security Class Initialized
DEBUG - 2022-05-12 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:36:35 --> Input Class Initialized
INFO - 2022-05-12 18:36:35 --> Language Class Initialized
INFO - 2022-05-12 18:36:35 --> Language Class Initialized
INFO - 2022-05-12 18:36:35 --> Config Class Initialized
INFO - 2022-05-12 18:36:35 --> Loader Class Initialized
INFO - 2022-05-12 18:36:35 --> Helper loaded: url_helper
INFO - 2022-05-12 18:36:35 --> Database Driver Class Initialized
INFO - 2022-05-12 18:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:36:35 --> Controller Class Initialized
DEBUG - 2022-05-12 18:36:35 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:36:35 --> Model Class Initialized
DEBUG - 2022-05-12 18:36:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:36:35 --> Model Class Initialized
INFO - 2022-05-12 18:37:56 --> Config Class Initialized
INFO - 2022-05-12 18:37:56 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:37:56 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:37:56 --> Utf8 Class Initialized
INFO - 2022-05-12 18:37:56 --> URI Class Initialized
INFO - 2022-05-12 18:37:56 --> Router Class Initialized
INFO - 2022-05-12 18:37:56 --> Output Class Initialized
INFO - 2022-05-12 18:37:56 --> Security Class Initialized
DEBUG - 2022-05-12 18:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:37:56 --> Input Class Initialized
INFO - 2022-05-12 18:37:56 --> Language Class Initialized
INFO - 2022-05-12 18:37:56 --> Language Class Initialized
INFO - 2022-05-12 18:37:56 --> Config Class Initialized
INFO - 2022-05-12 18:37:56 --> Loader Class Initialized
INFO - 2022-05-12 18:37:56 --> Helper loaded: url_helper
INFO - 2022-05-12 18:37:56 --> Database Driver Class Initialized
INFO - 2022-05-12 18:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:37:56 --> Controller Class Initialized
DEBUG - 2022-05-12 18:37:56 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:37:56 --> Model Class Initialized
DEBUG - 2022-05-12 18:37:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:37:56 --> Model Class Initialized
INFO - 2022-05-12 18:39:11 --> Config Class Initialized
INFO - 2022-05-12 18:39:11 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:39:11 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:39:11 --> Utf8 Class Initialized
INFO - 2022-05-12 18:39:11 --> URI Class Initialized
INFO - 2022-05-12 18:39:11 --> Router Class Initialized
INFO - 2022-05-12 18:39:11 --> Output Class Initialized
INFO - 2022-05-12 18:39:11 --> Security Class Initialized
DEBUG - 2022-05-12 18:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:39:11 --> Input Class Initialized
INFO - 2022-05-12 18:39:11 --> Language Class Initialized
INFO - 2022-05-12 18:39:11 --> Language Class Initialized
INFO - 2022-05-12 18:39:11 --> Config Class Initialized
INFO - 2022-05-12 18:39:11 --> Loader Class Initialized
INFO - 2022-05-12 18:39:11 --> Helper loaded: url_helper
INFO - 2022-05-12 18:39:11 --> Database Driver Class Initialized
INFO - 2022-05-12 18:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:39:11 --> Controller Class Initialized
DEBUG - 2022-05-12 18:39:11 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:39:11 --> Model Class Initialized
DEBUG - 2022-05-12 18:39:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:39:11 --> Model Class Initialized
INFO - 2022-05-12 18:39:21 --> Config Class Initialized
INFO - 2022-05-12 18:39:21 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:39:21 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:39:21 --> Utf8 Class Initialized
INFO - 2022-05-12 18:39:21 --> URI Class Initialized
INFO - 2022-05-12 18:39:21 --> Router Class Initialized
INFO - 2022-05-12 18:39:21 --> Output Class Initialized
INFO - 2022-05-12 18:39:21 --> Security Class Initialized
DEBUG - 2022-05-12 18:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:39:21 --> Input Class Initialized
INFO - 2022-05-12 18:39:21 --> Language Class Initialized
INFO - 2022-05-12 18:39:21 --> Language Class Initialized
INFO - 2022-05-12 18:39:21 --> Config Class Initialized
INFO - 2022-05-12 18:39:21 --> Loader Class Initialized
INFO - 2022-05-12 18:39:21 --> Helper loaded: url_helper
INFO - 2022-05-12 18:39:21 --> Database Driver Class Initialized
INFO - 2022-05-12 18:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:39:21 --> Controller Class Initialized
DEBUG - 2022-05-12 18:39:21 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:39:22 --> Model Class Initialized
DEBUG - 2022-05-12 18:39:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:39:22 --> Model Class Initialized
INFO - 2022-05-12 18:40:26 --> Config Class Initialized
INFO - 2022-05-12 18:40:26 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:40:26 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:40:26 --> Utf8 Class Initialized
INFO - 2022-05-12 18:40:26 --> URI Class Initialized
INFO - 2022-05-12 18:40:26 --> Router Class Initialized
INFO - 2022-05-12 18:40:26 --> Output Class Initialized
INFO - 2022-05-12 18:40:26 --> Security Class Initialized
DEBUG - 2022-05-12 18:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:40:26 --> Input Class Initialized
INFO - 2022-05-12 18:40:26 --> Language Class Initialized
INFO - 2022-05-12 18:40:26 --> Language Class Initialized
INFO - 2022-05-12 18:40:26 --> Config Class Initialized
INFO - 2022-05-12 18:40:26 --> Loader Class Initialized
INFO - 2022-05-12 18:40:26 --> Helper loaded: url_helper
INFO - 2022-05-12 18:40:26 --> Database Driver Class Initialized
INFO - 2022-05-12 18:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:40:26 --> Controller Class Initialized
DEBUG - 2022-05-12 18:40:26 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:40:26 --> Model Class Initialized
DEBUG - 2022-05-12 18:40:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:40:26 --> Model Class Initialized
DEBUG - 2022-05-12 18:40:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:40:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:40:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:40:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:40:26 --> Final output sent to browser
DEBUG - 2022-05-12 18:40:26 --> Total execution time: 0.0768
INFO - 2022-05-12 18:40:31 --> Config Class Initialized
INFO - 2022-05-12 18:40:31 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:40:31 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:40:31 --> Utf8 Class Initialized
INFO - 2022-05-12 18:40:31 --> URI Class Initialized
INFO - 2022-05-12 18:40:31 --> Router Class Initialized
INFO - 2022-05-12 18:40:31 --> Output Class Initialized
INFO - 2022-05-12 18:40:31 --> Security Class Initialized
DEBUG - 2022-05-12 18:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:40:31 --> Input Class Initialized
INFO - 2022-05-12 18:40:31 --> Language Class Initialized
INFO - 2022-05-12 18:40:31 --> Language Class Initialized
INFO - 2022-05-12 18:40:31 --> Config Class Initialized
INFO - 2022-05-12 18:40:31 --> Loader Class Initialized
INFO - 2022-05-12 18:40:31 --> Helper loaded: url_helper
INFO - 2022-05-12 18:40:31 --> Database Driver Class Initialized
INFO - 2022-05-12 18:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:40:32 --> Controller Class Initialized
DEBUG - 2022-05-12 18:40:32 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:40:32 --> Model Class Initialized
DEBUG - 2022-05-12 18:40:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:40:32 --> Model Class Initialized
DEBUG - 2022-05-12 18:40:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:40:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:40:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:40:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:40:32 --> Final output sent to browser
DEBUG - 2022-05-12 18:40:32 --> Total execution time: 0.5833
INFO - 2022-05-12 18:40:55 --> Config Class Initialized
INFO - 2022-05-12 18:40:55 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:40:55 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:40:55 --> Utf8 Class Initialized
INFO - 2022-05-12 18:40:55 --> URI Class Initialized
INFO - 2022-05-12 18:40:55 --> Router Class Initialized
INFO - 2022-05-12 18:40:55 --> Output Class Initialized
INFO - 2022-05-12 18:40:55 --> Security Class Initialized
DEBUG - 2022-05-12 18:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:40:55 --> Input Class Initialized
INFO - 2022-05-12 18:40:55 --> Language Class Initialized
INFO - 2022-05-12 18:40:55 --> Language Class Initialized
INFO - 2022-05-12 18:40:55 --> Config Class Initialized
INFO - 2022-05-12 18:40:55 --> Loader Class Initialized
INFO - 2022-05-12 18:40:55 --> Helper loaded: url_helper
INFO - 2022-05-12 18:40:55 --> Database Driver Class Initialized
INFO - 2022-05-12 18:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:40:55 --> Controller Class Initialized
DEBUG - 2022-05-12 18:40:55 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:40:55 --> Model Class Initialized
DEBUG - 2022-05-12 18:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:40:55 --> Model Class Initialized
DEBUG - 2022-05-12 18:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:40:55 --> Final output sent to browser
DEBUG - 2022-05-12 18:40:55 --> Total execution time: 0.0588
INFO - 2022-05-12 18:41:35 --> Config Class Initialized
INFO - 2022-05-12 18:41:35 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:41:35 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:41:35 --> Utf8 Class Initialized
INFO - 2022-05-12 18:41:35 --> URI Class Initialized
INFO - 2022-05-12 18:41:35 --> Router Class Initialized
INFO - 2022-05-12 18:41:35 --> Output Class Initialized
INFO - 2022-05-12 18:41:35 --> Security Class Initialized
DEBUG - 2022-05-12 18:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:41:35 --> Input Class Initialized
INFO - 2022-05-12 18:41:35 --> Language Class Initialized
INFO - 2022-05-12 18:41:35 --> Language Class Initialized
INFO - 2022-05-12 18:41:35 --> Config Class Initialized
INFO - 2022-05-12 18:41:35 --> Loader Class Initialized
INFO - 2022-05-12 18:41:35 --> Helper loaded: url_helper
INFO - 2022-05-12 18:41:35 --> Database Driver Class Initialized
INFO - 2022-05-12 18:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:41:35 --> Controller Class Initialized
DEBUG - 2022-05-12 18:41:35 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:41:35 --> Model Class Initialized
DEBUG - 2022-05-12 18:41:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:41:35 --> Model Class Initialized
INFO - 2022-05-12 18:42:44 --> Config Class Initialized
INFO - 2022-05-12 18:42:44 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:42:44 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:42:44 --> Utf8 Class Initialized
INFO - 2022-05-12 18:42:44 --> URI Class Initialized
INFO - 2022-05-12 18:42:44 --> Router Class Initialized
INFO - 2022-05-12 18:42:44 --> Output Class Initialized
INFO - 2022-05-12 18:42:44 --> Security Class Initialized
DEBUG - 2022-05-12 18:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:42:44 --> Input Class Initialized
INFO - 2022-05-12 18:42:44 --> Language Class Initialized
INFO - 2022-05-12 18:42:44 --> Language Class Initialized
INFO - 2022-05-12 18:42:44 --> Config Class Initialized
INFO - 2022-05-12 18:42:44 --> Loader Class Initialized
INFO - 2022-05-12 18:42:44 --> Helper loaded: url_helper
INFO - 2022-05-12 18:42:44 --> Database Driver Class Initialized
INFO - 2022-05-12 18:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:42:44 --> Controller Class Initialized
DEBUG - 2022-05-12 18:42:44 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:42:44 --> Model Class Initialized
DEBUG - 2022-05-12 18:42:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:42:44 --> Model Class Initialized
INFO - 2022-05-12 18:42:45 --> Config Class Initialized
INFO - 2022-05-12 18:42:45 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:42:45 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:42:45 --> Utf8 Class Initialized
INFO - 2022-05-12 18:42:45 --> URI Class Initialized
INFO - 2022-05-12 18:42:45 --> Router Class Initialized
INFO - 2022-05-12 18:42:45 --> Output Class Initialized
INFO - 2022-05-12 18:42:45 --> Security Class Initialized
DEBUG - 2022-05-12 18:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:42:45 --> Input Class Initialized
INFO - 2022-05-12 18:42:45 --> Language Class Initialized
INFO - 2022-05-12 18:42:45 --> Language Class Initialized
INFO - 2022-05-12 18:42:45 --> Config Class Initialized
INFO - 2022-05-12 18:42:45 --> Loader Class Initialized
INFO - 2022-05-12 18:42:45 --> Helper loaded: url_helper
INFO - 2022-05-12 18:42:45 --> Database Driver Class Initialized
INFO - 2022-05-12 18:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:42:45 --> Controller Class Initialized
DEBUG - 2022-05-12 18:42:45 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:42:45 --> Model Class Initialized
DEBUG - 2022-05-12 18:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:42:45 --> Model Class Initialized
INFO - 2022-05-12 18:42:46 --> Config Class Initialized
INFO - 2022-05-12 18:42:46 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:42:46 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:42:46 --> Utf8 Class Initialized
INFO - 2022-05-12 18:42:46 --> URI Class Initialized
INFO - 2022-05-12 18:42:46 --> Router Class Initialized
INFO - 2022-05-12 18:42:46 --> Output Class Initialized
INFO - 2022-05-12 18:42:46 --> Security Class Initialized
DEBUG - 2022-05-12 18:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:42:46 --> Input Class Initialized
INFO - 2022-05-12 18:42:46 --> Language Class Initialized
INFO - 2022-05-12 18:42:46 --> Language Class Initialized
INFO - 2022-05-12 18:42:46 --> Config Class Initialized
INFO - 2022-05-12 18:42:46 --> Loader Class Initialized
INFO - 2022-05-12 18:42:46 --> Helper loaded: url_helper
INFO - 2022-05-12 18:42:46 --> Database Driver Class Initialized
INFO - 2022-05-12 18:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:42:46 --> Controller Class Initialized
DEBUG - 2022-05-12 18:42:46 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:42:46 --> Model Class Initialized
DEBUG - 2022-05-12 18:42:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:42:46 --> Model Class Initialized
DEBUG - 2022-05-12 18:42:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:42:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 18:42:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-12 18:42:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:42:46 --> Final output sent to browser
DEBUG - 2022-05-12 18:42:46 --> Total execution time: 0.0694
INFO - 2022-05-12 18:42:49 --> Config Class Initialized
INFO - 2022-05-12 18:42:49 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:42:49 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:42:49 --> Utf8 Class Initialized
INFO - 2022-05-12 18:42:49 --> URI Class Initialized
INFO - 2022-05-12 18:42:49 --> Router Class Initialized
INFO - 2022-05-12 18:42:49 --> Output Class Initialized
INFO - 2022-05-12 18:42:49 --> Security Class Initialized
DEBUG - 2022-05-12 18:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:42:49 --> Input Class Initialized
INFO - 2022-05-12 18:42:49 --> Language Class Initialized
INFO - 2022-05-12 18:42:49 --> Language Class Initialized
INFO - 2022-05-12 18:42:49 --> Config Class Initialized
INFO - 2022-05-12 18:42:49 --> Loader Class Initialized
INFO - 2022-05-12 18:42:49 --> Helper loaded: url_helper
INFO - 2022-05-12 18:42:49 --> Database Driver Class Initialized
INFO - 2022-05-12 18:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:42:49 --> Controller Class Initialized
DEBUG - 2022-05-12 18:42:49 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:42:49 --> Model Class Initialized
DEBUG - 2022-05-12 18:42:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:42:49 --> Model Class Initialized
INFO - 2022-05-12 18:45:15 --> Config Class Initialized
INFO - 2022-05-12 18:45:15 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:45:15 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:45:15 --> Utf8 Class Initialized
INFO - 2022-05-12 18:45:15 --> URI Class Initialized
INFO - 2022-05-12 18:45:16 --> Router Class Initialized
INFO - 2022-05-12 18:45:16 --> Output Class Initialized
INFO - 2022-05-12 18:45:16 --> Security Class Initialized
DEBUG - 2022-05-12 18:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:45:16 --> Input Class Initialized
INFO - 2022-05-12 18:45:16 --> Language Class Initialized
INFO - 2022-05-12 18:45:16 --> Language Class Initialized
INFO - 2022-05-12 18:45:16 --> Config Class Initialized
INFO - 2022-05-12 18:45:16 --> Loader Class Initialized
INFO - 2022-05-12 18:45:16 --> Helper loaded: url_helper
INFO - 2022-05-12 18:45:16 --> Database Driver Class Initialized
INFO - 2022-05-12 18:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:45:16 --> Controller Class Initialized
DEBUG - 2022-05-12 18:45:16 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:45:16 --> Model Class Initialized
DEBUG - 2022-05-12 18:45:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:45:16 --> Model Class Initialized
INFO - 2022-05-12 18:46:28 --> Config Class Initialized
INFO - 2022-05-12 18:46:28 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:46:29 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:46:29 --> Utf8 Class Initialized
INFO - 2022-05-12 18:46:29 --> URI Class Initialized
INFO - 2022-05-12 18:46:29 --> Router Class Initialized
INFO - 2022-05-12 18:46:29 --> Output Class Initialized
INFO - 2022-05-12 18:46:29 --> Security Class Initialized
DEBUG - 2022-05-12 18:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:46:29 --> Input Class Initialized
INFO - 2022-05-12 18:46:29 --> Language Class Initialized
INFO - 2022-05-12 18:46:29 --> Language Class Initialized
INFO - 2022-05-12 18:46:29 --> Config Class Initialized
INFO - 2022-05-12 18:46:29 --> Loader Class Initialized
INFO - 2022-05-12 18:46:29 --> Helper loaded: url_helper
INFO - 2022-05-12 18:46:29 --> Database Driver Class Initialized
INFO - 2022-05-12 18:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:46:29 --> Controller Class Initialized
DEBUG - 2022-05-12 18:46:29 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:46:29 --> Model Class Initialized
DEBUG - 2022-05-12 18:46:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:46:29 --> Model Class Initialized
INFO - 2022-05-12 18:53:52 --> Config Class Initialized
INFO - 2022-05-12 18:53:52 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:53:52 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:53:52 --> Utf8 Class Initialized
INFO - 2022-05-12 18:53:52 --> URI Class Initialized
INFO - 2022-05-12 18:53:52 --> Router Class Initialized
INFO - 2022-05-12 18:53:52 --> Output Class Initialized
INFO - 2022-05-12 18:53:52 --> Security Class Initialized
DEBUG - 2022-05-12 18:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:53:52 --> Input Class Initialized
INFO - 2022-05-12 18:53:52 --> Language Class Initialized
INFO - 2022-05-12 18:53:52 --> Language Class Initialized
INFO - 2022-05-12 18:53:52 --> Config Class Initialized
INFO - 2022-05-12 18:53:52 --> Loader Class Initialized
INFO - 2022-05-12 18:53:52 --> Helper loaded: url_helper
INFO - 2022-05-12 18:53:52 --> Database Driver Class Initialized
INFO - 2022-05-12 18:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:53:52 --> Controller Class Initialized
DEBUG - 2022-05-12 18:53:52 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:53:52 --> Model Class Initialized
DEBUG - 2022-05-12 18:53:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:53:52 --> Model Class Initialized
ERROR - 2022-05-12 18:53:52 --> Query error: FUNCTION group.concat does not exist - Invalid query: SELECT `vd`.*, `cat`.*, `b`.*, `m`.*, `s`.*, `vs`.*, `vo`.*, group.concat(viv.doc_name) as vivn
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category`
JOIN `brand` as `b` ON `b`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
JOIN `vehicle_specification` as `vs` ON `vs`.`v_id` = `vd`.`v_id`
JOIN `vehicle_overview` as `vo` ON `vo`.`v_id` = `vd`.`v_id`
JOIN `vehicle_image_video` as `viv` ON `viv`.`v_id` = `vd`.`v_id`
JOIN `seo` as `s` ON `s`.`v_id` = `vd`.`v_id`
WHERE `vd`.`v_id` = '2'
GROUP BY `vd`.`v_id`
INFO - 2022-05-12 18:53:52 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-12 18:54:02 --> Config Class Initialized
INFO - 2022-05-12 18:54:02 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:54:02 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:54:02 --> Utf8 Class Initialized
INFO - 2022-05-12 18:54:02 --> URI Class Initialized
INFO - 2022-05-12 18:54:02 --> Router Class Initialized
INFO - 2022-05-12 18:54:02 --> Output Class Initialized
INFO - 2022-05-12 18:54:02 --> Security Class Initialized
DEBUG - 2022-05-12 18:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:54:02 --> Input Class Initialized
INFO - 2022-05-12 18:54:02 --> Language Class Initialized
INFO - 2022-05-12 18:54:02 --> Language Class Initialized
INFO - 2022-05-12 18:54:02 --> Config Class Initialized
INFO - 2022-05-12 18:54:02 --> Loader Class Initialized
INFO - 2022-05-12 18:54:02 --> Helper loaded: url_helper
INFO - 2022-05-12 18:54:02 --> Database Driver Class Initialized
INFO - 2022-05-12 18:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:54:02 --> Controller Class Initialized
DEBUG - 2022-05-12 18:54:02 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:54:02 --> Model Class Initialized
DEBUG - 2022-05-12 18:54:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:54:02 --> Model Class Initialized
INFO - 2022-05-12 18:57:33 --> Config Class Initialized
INFO - 2022-05-12 18:57:33 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:57:33 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:57:33 --> Utf8 Class Initialized
INFO - 2022-05-12 18:57:33 --> URI Class Initialized
INFO - 2022-05-12 18:57:33 --> Router Class Initialized
INFO - 2022-05-12 18:57:33 --> Output Class Initialized
INFO - 2022-05-12 18:57:33 --> Security Class Initialized
DEBUG - 2022-05-12 18:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:57:33 --> Input Class Initialized
INFO - 2022-05-12 18:57:33 --> Language Class Initialized
INFO - 2022-05-12 18:57:33 --> Language Class Initialized
INFO - 2022-05-12 18:57:33 --> Config Class Initialized
INFO - 2022-05-12 18:57:33 --> Loader Class Initialized
INFO - 2022-05-12 18:57:33 --> Helper loaded: url_helper
INFO - 2022-05-12 18:57:33 --> Database Driver Class Initialized
INFO - 2022-05-12 18:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:57:33 --> Controller Class Initialized
DEBUG - 2022-05-12 18:57:33 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:57:33 --> Model Class Initialized
DEBUG - 2022-05-12 18:57:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:57:33 --> Model Class Initialized
DEBUG - 2022-05-12 18:57:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:57:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-12 18:57:33 --> Severity: Notice --> Undefined index: doc_name N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 397
ERROR - 2022-05-12 18:57:33 --> Severity: Notice --> Undefined variable: vi N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 403
ERROR - 2022-05-12 18:57:33 --> Severity: Notice --> Undefined variable: vi N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 415
DEBUG - 2022-05-12 18:57:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 18:57:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:57:33 --> Final output sent to browser
DEBUG - 2022-05-12 18:57:33 --> Total execution time: 0.1135
INFO - 2022-05-12 18:59:15 --> Config Class Initialized
INFO - 2022-05-12 18:59:15 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:59:15 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:59:15 --> Utf8 Class Initialized
INFO - 2022-05-12 18:59:15 --> URI Class Initialized
INFO - 2022-05-12 18:59:15 --> Router Class Initialized
INFO - 2022-05-12 18:59:15 --> Output Class Initialized
INFO - 2022-05-12 18:59:15 --> Security Class Initialized
DEBUG - 2022-05-12 18:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:59:15 --> Input Class Initialized
INFO - 2022-05-12 18:59:15 --> Language Class Initialized
INFO - 2022-05-12 18:59:15 --> Language Class Initialized
INFO - 2022-05-12 18:59:15 --> Config Class Initialized
INFO - 2022-05-12 18:59:15 --> Loader Class Initialized
INFO - 2022-05-12 18:59:15 --> Helper loaded: url_helper
INFO - 2022-05-12 18:59:15 --> Database Driver Class Initialized
INFO - 2022-05-12 18:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:59:15 --> Controller Class Initialized
DEBUG - 2022-05-12 18:59:15 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:59:15 --> Model Class Initialized
DEBUG - 2022-05-12 18:59:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:59:15 --> Model Class Initialized
INFO - 2022-05-12 18:59:40 --> Config Class Initialized
INFO - 2022-05-12 18:59:40 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:59:40 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:59:40 --> Utf8 Class Initialized
INFO - 2022-05-12 18:59:40 --> URI Class Initialized
INFO - 2022-05-12 18:59:40 --> Router Class Initialized
INFO - 2022-05-12 18:59:40 --> Output Class Initialized
INFO - 2022-05-12 18:59:40 --> Security Class Initialized
DEBUG - 2022-05-12 18:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:59:40 --> Input Class Initialized
INFO - 2022-05-12 18:59:40 --> Language Class Initialized
INFO - 2022-05-12 18:59:40 --> Language Class Initialized
INFO - 2022-05-12 18:59:40 --> Config Class Initialized
INFO - 2022-05-12 18:59:40 --> Loader Class Initialized
INFO - 2022-05-12 18:59:40 --> Helper loaded: url_helper
INFO - 2022-05-12 18:59:40 --> Database Driver Class Initialized
INFO - 2022-05-12 18:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:59:40 --> Controller Class Initialized
DEBUG - 2022-05-12 18:59:40 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:59:40 --> Model Class Initialized
DEBUG - 2022-05-12 18:59:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:59:40 --> Model Class Initialized
DEBUG - 2022-05-12 18:59:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 18:59:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-12 18:59:40 --> Severity: Notice --> Undefined variable: vivn N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 397
ERROR - 2022-05-12 18:59:40 --> Severity: Notice --> Undefined variable: vi N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 403
ERROR - 2022-05-12 18:59:40 --> Severity: Notice --> Undefined variable: vi N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 415
DEBUG - 2022-05-12 18:59:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 18:59:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 18:59:40 --> Final output sent to browser
DEBUG - 2022-05-12 18:59:40 --> Total execution time: 0.1032
INFO - 2022-05-12 18:59:53 --> Config Class Initialized
INFO - 2022-05-12 18:59:53 --> Hooks Class Initialized
DEBUG - 2022-05-12 18:59:53 --> UTF-8 Support Enabled
INFO - 2022-05-12 18:59:53 --> Utf8 Class Initialized
INFO - 2022-05-12 18:59:53 --> URI Class Initialized
INFO - 2022-05-12 18:59:53 --> Router Class Initialized
INFO - 2022-05-12 18:59:53 --> Output Class Initialized
INFO - 2022-05-12 18:59:53 --> Security Class Initialized
DEBUG - 2022-05-12 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 18:59:54 --> Input Class Initialized
INFO - 2022-05-12 18:59:54 --> Language Class Initialized
INFO - 2022-05-12 18:59:54 --> Language Class Initialized
INFO - 2022-05-12 18:59:54 --> Config Class Initialized
INFO - 2022-05-12 18:59:54 --> Loader Class Initialized
INFO - 2022-05-12 18:59:54 --> Helper loaded: url_helper
INFO - 2022-05-12 18:59:54 --> Database Driver Class Initialized
INFO - 2022-05-12 18:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 18:59:54 --> Controller Class Initialized
DEBUG - 2022-05-12 18:59:54 --> Admin MX_Controller Initialized
INFO - 2022-05-12 18:59:54 --> Model Class Initialized
DEBUG - 2022-05-12 18:59:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 18:59:54 --> Model Class Initialized
INFO - 2022-05-12 19:00:43 --> Config Class Initialized
INFO - 2022-05-12 19:00:43 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:00:43 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:00:43 --> Utf8 Class Initialized
INFO - 2022-05-12 19:00:43 --> URI Class Initialized
INFO - 2022-05-12 19:00:43 --> Router Class Initialized
INFO - 2022-05-12 19:00:43 --> Output Class Initialized
INFO - 2022-05-12 19:00:43 --> Security Class Initialized
DEBUG - 2022-05-12 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:00:43 --> Input Class Initialized
INFO - 2022-05-12 19:00:43 --> Language Class Initialized
INFO - 2022-05-12 19:00:43 --> Language Class Initialized
INFO - 2022-05-12 19:00:43 --> Config Class Initialized
INFO - 2022-05-12 19:00:43 --> Loader Class Initialized
INFO - 2022-05-12 19:00:43 --> Helper loaded: url_helper
INFO - 2022-05-12 19:00:43 --> Database Driver Class Initialized
INFO - 2022-05-12 19:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:00:43 --> Controller Class Initialized
DEBUG - 2022-05-12 19:00:43 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:00:43 --> Model Class Initialized
DEBUG - 2022-05-12 19:00:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:00:43 --> Model Class Initialized
DEBUG - 2022-05-12 19:00:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:00:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-12 19:00:43 --> Severity: Notice --> Undefined variable: vi N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 403
ERROR - 2022-05-12 19:00:43 --> Severity: Notice --> Undefined variable: vi N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 415
DEBUG - 2022-05-12 19:00:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:00:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:00:43 --> Final output sent to browser
DEBUG - 2022-05-12 19:00:43 --> Total execution time: 0.0900
INFO - 2022-05-12 19:01:35 --> Config Class Initialized
INFO - 2022-05-12 19:01:35 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:01:35 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:01:35 --> Utf8 Class Initialized
INFO - 2022-05-12 19:01:35 --> URI Class Initialized
INFO - 2022-05-12 19:01:35 --> Router Class Initialized
INFO - 2022-05-12 19:01:35 --> Output Class Initialized
INFO - 2022-05-12 19:01:35 --> Security Class Initialized
DEBUG - 2022-05-12 19:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:01:35 --> Input Class Initialized
INFO - 2022-05-12 19:01:35 --> Language Class Initialized
INFO - 2022-05-12 19:01:35 --> Language Class Initialized
INFO - 2022-05-12 19:01:35 --> Config Class Initialized
INFO - 2022-05-12 19:01:35 --> Loader Class Initialized
INFO - 2022-05-12 19:01:35 --> Helper loaded: url_helper
INFO - 2022-05-12 19:01:35 --> Database Driver Class Initialized
INFO - 2022-05-12 19:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:01:35 --> Controller Class Initialized
DEBUG - 2022-05-12 19:01:35 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:01:35 --> Model Class Initialized
DEBUG - 2022-05-12 19:01:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:01:35 --> Model Class Initialized
DEBUG - 2022-05-12 19:01:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:01:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:01:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:01:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:01:35 --> Final output sent to browser
DEBUG - 2022-05-12 19:01:35 --> Total execution time: 0.0881
INFO - 2022-05-12 19:03:07 --> Config Class Initialized
INFO - 2022-05-12 19:03:07 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:03:07 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:03:07 --> Utf8 Class Initialized
INFO - 2022-05-12 19:03:07 --> URI Class Initialized
INFO - 2022-05-12 19:03:07 --> Router Class Initialized
INFO - 2022-05-12 19:03:07 --> Output Class Initialized
INFO - 2022-05-12 19:03:07 --> Security Class Initialized
DEBUG - 2022-05-12 19:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:03:07 --> Input Class Initialized
INFO - 2022-05-12 19:03:07 --> Language Class Initialized
INFO - 2022-05-12 19:03:07 --> Language Class Initialized
INFO - 2022-05-12 19:03:07 --> Config Class Initialized
INFO - 2022-05-12 19:03:07 --> Loader Class Initialized
INFO - 2022-05-12 19:03:07 --> Helper loaded: url_helper
INFO - 2022-05-12 19:03:07 --> Database Driver Class Initialized
INFO - 2022-05-12 19:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:03:07 --> Controller Class Initialized
DEBUG - 2022-05-12 19:03:07 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:03:07 --> Model Class Initialized
DEBUG - 2022-05-12 19:03:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:03:07 --> Model Class Initialized
DEBUG - 2022-05-12 19:03:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:03:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:03:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:03:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:03:07 --> Final output sent to browser
DEBUG - 2022-05-12 19:03:07 --> Total execution time: 0.0914
INFO - 2022-05-12 19:04:57 --> Config Class Initialized
INFO - 2022-05-12 19:04:57 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:04:57 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:04:57 --> Utf8 Class Initialized
INFO - 2022-05-12 19:04:57 --> URI Class Initialized
INFO - 2022-05-12 19:04:57 --> Router Class Initialized
INFO - 2022-05-12 19:04:57 --> Output Class Initialized
INFO - 2022-05-12 19:04:57 --> Security Class Initialized
DEBUG - 2022-05-12 19:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:04:57 --> Input Class Initialized
INFO - 2022-05-12 19:04:57 --> Language Class Initialized
INFO - 2022-05-12 19:04:57 --> Language Class Initialized
INFO - 2022-05-12 19:04:57 --> Config Class Initialized
INFO - 2022-05-12 19:04:57 --> Loader Class Initialized
INFO - 2022-05-12 19:04:57 --> Helper loaded: url_helper
INFO - 2022-05-12 19:04:57 --> Database Driver Class Initialized
INFO - 2022-05-12 19:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:04:57 --> Controller Class Initialized
DEBUG - 2022-05-12 19:04:57 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:04:57 --> Model Class Initialized
DEBUG - 2022-05-12 19:04:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:04:57 --> Model Class Initialized
DEBUG - 2022-05-12 19:04:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:04:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:04:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:04:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:04:57 --> Final output sent to browser
DEBUG - 2022-05-12 19:04:57 --> Total execution time: 0.1298
INFO - 2022-05-12 19:07:09 --> Config Class Initialized
INFO - 2022-05-12 19:07:09 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:07:09 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:07:09 --> Utf8 Class Initialized
INFO - 2022-05-12 19:07:09 --> URI Class Initialized
INFO - 2022-05-12 19:07:09 --> Router Class Initialized
INFO - 2022-05-12 19:07:09 --> Output Class Initialized
INFO - 2022-05-12 19:07:09 --> Security Class Initialized
DEBUG - 2022-05-12 19:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:07:09 --> Input Class Initialized
INFO - 2022-05-12 19:07:09 --> Language Class Initialized
INFO - 2022-05-12 19:07:09 --> Language Class Initialized
INFO - 2022-05-12 19:07:09 --> Config Class Initialized
INFO - 2022-05-12 19:07:09 --> Loader Class Initialized
INFO - 2022-05-12 19:07:09 --> Helper loaded: url_helper
INFO - 2022-05-12 19:07:09 --> Database Driver Class Initialized
INFO - 2022-05-12 19:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:07:09 --> Controller Class Initialized
DEBUG - 2022-05-12 19:07:09 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:07:09 --> Model Class Initialized
DEBUG - 2022-05-12 19:07:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:07:09 --> Model Class Initialized
DEBUG - 2022-05-12 19:07:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:07:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-12 19:07:09 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 103
ERROR - 2022-05-12 19:07:09 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\edit_vehicle.php 103
DEBUG - 2022-05-12 19:07:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:07:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:07:09 --> Final output sent to browser
DEBUG - 2022-05-12 19:07:09 --> Total execution time: 0.3522
INFO - 2022-05-12 19:07:33 --> Config Class Initialized
INFO - 2022-05-12 19:07:33 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:07:33 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:07:33 --> Utf8 Class Initialized
INFO - 2022-05-12 19:07:33 --> URI Class Initialized
INFO - 2022-05-12 19:07:33 --> Router Class Initialized
INFO - 2022-05-12 19:07:33 --> Output Class Initialized
INFO - 2022-05-12 19:07:33 --> Security Class Initialized
DEBUG - 2022-05-12 19:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:07:33 --> Input Class Initialized
INFO - 2022-05-12 19:07:33 --> Language Class Initialized
INFO - 2022-05-12 19:07:33 --> Language Class Initialized
INFO - 2022-05-12 19:07:33 --> Config Class Initialized
INFO - 2022-05-12 19:07:33 --> Loader Class Initialized
INFO - 2022-05-12 19:07:33 --> Helper loaded: url_helper
INFO - 2022-05-12 19:07:33 --> Database Driver Class Initialized
INFO - 2022-05-12 19:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:07:33 --> Controller Class Initialized
DEBUG - 2022-05-12 19:07:33 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:07:33 --> Model Class Initialized
DEBUG - 2022-05-12 19:07:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:07:33 --> Model Class Initialized
DEBUG - 2022-05-12 19:07:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:07:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:07:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:07:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:07:33 --> Final output sent to browser
DEBUG - 2022-05-12 19:07:33 --> Total execution time: 0.0954
INFO - 2022-05-12 19:08:45 --> Config Class Initialized
INFO - 2022-05-12 19:08:45 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:08:45 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:08:45 --> Utf8 Class Initialized
INFO - 2022-05-12 19:08:45 --> URI Class Initialized
INFO - 2022-05-12 19:08:45 --> Router Class Initialized
INFO - 2022-05-12 19:08:45 --> Output Class Initialized
INFO - 2022-05-12 19:08:45 --> Security Class Initialized
DEBUG - 2022-05-12 19:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:08:45 --> Input Class Initialized
INFO - 2022-05-12 19:08:45 --> Language Class Initialized
INFO - 2022-05-12 19:08:45 --> Language Class Initialized
INFO - 2022-05-12 19:08:45 --> Config Class Initialized
INFO - 2022-05-12 19:08:45 --> Loader Class Initialized
INFO - 2022-05-12 19:08:45 --> Helper loaded: url_helper
INFO - 2022-05-12 19:08:45 --> Database Driver Class Initialized
INFO - 2022-05-12 19:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:08:45 --> Controller Class Initialized
DEBUG - 2022-05-12 19:08:45 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:08:45 --> Model Class Initialized
DEBUG - 2022-05-12 19:08:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:08:45 --> Model Class Initialized
DEBUG - 2022-05-12 19:08:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:08:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:08:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:08:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:08:45 --> Final output sent to browser
DEBUG - 2022-05-12 19:08:45 --> Total execution time: 0.0927
INFO - 2022-05-12 19:09:20 --> Config Class Initialized
INFO - 2022-05-12 19:09:20 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:09:20 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:09:20 --> Utf8 Class Initialized
INFO - 2022-05-12 19:09:20 --> URI Class Initialized
INFO - 2022-05-12 19:09:20 --> Router Class Initialized
INFO - 2022-05-12 19:09:20 --> Output Class Initialized
INFO - 2022-05-12 19:09:20 --> Security Class Initialized
DEBUG - 2022-05-12 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:09:20 --> Input Class Initialized
INFO - 2022-05-12 19:09:20 --> Language Class Initialized
INFO - 2022-05-12 19:09:20 --> Language Class Initialized
INFO - 2022-05-12 19:09:20 --> Config Class Initialized
INFO - 2022-05-12 19:09:20 --> Loader Class Initialized
INFO - 2022-05-12 19:09:20 --> Helper loaded: url_helper
INFO - 2022-05-12 19:09:20 --> Database Driver Class Initialized
INFO - 2022-05-12 19:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:09:20 --> Controller Class Initialized
DEBUG - 2022-05-12 19:09:20 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:09:21 --> Model Class Initialized
DEBUG - 2022-05-12 19:09:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:09:21 --> Model Class Initialized
DEBUG - 2022-05-12 19:09:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:09:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:09:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:09:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:09:21 --> Final output sent to browser
DEBUG - 2022-05-12 19:09:21 --> Total execution time: 0.0778
INFO - 2022-05-12 19:10:34 --> Config Class Initialized
INFO - 2022-05-12 19:10:34 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:10:34 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:10:34 --> Utf8 Class Initialized
INFO - 2022-05-12 19:10:34 --> URI Class Initialized
INFO - 2022-05-12 19:10:34 --> Router Class Initialized
INFO - 2022-05-12 19:10:34 --> Output Class Initialized
INFO - 2022-05-12 19:10:34 --> Security Class Initialized
DEBUG - 2022-05-12 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:10:34 --> Input Class Initialized
INFO - 2022-05-12 19:10:34 --> Language Class Initialized
INFO - 2022-05-12 19:10:34 --> Language Class Initialized
INFO - 2022-05-12 19:10:34 --> Config Class Initialized
INFO - 2022-05-12 19:10:34 --> Loader Class Initialized
INFO - 2022-05-12 19:10:34 --> Helper loaded: url_helper
INFO - 2022-05-12 19:10:34 --> Database Driver Class Initialized
INFO - 2022-05-12 19:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:10:34 --> Controller Class Initialized
DEBUG - 2022-05-12 19:10:34 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:10:34 --> Model Class Initialized
DEBUG - 2022-05-12 19:10:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:10:34 --> Model Class Initialized
DEBUG - 2022-05-12 19:10:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:10:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:10:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:10:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:10:34 --> Final output sent to browser
DEBUG - 2022-05-12 19:10:34 --> Total execution time: 0.0722
INFO - 2022-05-12 19:10:37 --> Config Class Initialized
INFO - 2022-05-12 19:10:37 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:10:37 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:10:37 --> Utf8 Class Initialized
INFO - 2022-05-12 19:10:37 --> URI Class Initialized
INFO - 2022-05-12 19:10:37 --> Router Class Initialized
INFO - 2022-05-12 19:10:37 --> Output Class Initialized
INFO - 2022-05-12 19:10:37 --> Security Class Initialized
DEBUG - 2022-05-12 19:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:10:37 --> Input Class Initialized
INFO - 2022-05-12 19:10:37 --> Language Class Initialized
INFO - 2022-05-12 19:10:37 --> Language Class Initialized
INFO - 2022-05-12 19:10:37 --> Config Class Initialized
INFO - 2022-05-12 19:10:37 --> Loader Class Initialized
INFO - 2022-05-12 19:10:37 --> Helper loaded: url_helper
INFO - 2022-05-12 19:10:37 --> Database Driver Class Initialized
INFO - 2022-05-12 19:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:10:37 --> Controller Class Initialized
DEBUG - 2022-05-12 19:10:37 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:10:37 --> Model Class Initialized
DEBUG - 2022-05-12 19:10:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:10:37 --> Model Class Initialized
INFO - 2022-05-12 19:10:37 --> Final output sent to browser
DEBUG - 2022-05-12 19:10:37 --> Total execution time: 0.0735
INFO - 2022-05-12 19:10:41 --> Config Class Initialized
INFO - 2022-05-12 19:10:41 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:10:41 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:10:41 --> Utf8 Class Initialized
INFO - 2022-05-12 19:10:41 --> URI Class Initialized
INFO - 2022-05-12 19:10:41 --> Router Class Initialized
INFO - 2022-05-12 19:10:41 --> Output Class Initialized
INFO - 2022-05-12 19:10:41 --> Security Class Initialized
DEBUG - 2022-05-12 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:10:41 --> Input Class Initialized
INFO - 2022-05-12 19:10:41 --> Language Class Initialized
INFO - 2022-05-12 19:10:41 --> Language Class Initialized
INFO - 2022-05-12 19:10:41 --> Config Class Initialized
INFO - 2022-05-12 19:10:41 --> Loader Class Initialized
INFO - 2022-05-12 19:10:41 --> Helper loaded: url_helper
INFO - 2022-05-12 19:10:41 --> Database Driver Class Initialized
INFO - 2022-05-12 19:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:10:41 --> Controller Class Initialized
DEBUG - 2022-05-12 19:10:41 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:10:41 --> Model Class Initialized
DEBUG - 2022-05-12 19:10:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:10:41 --> Model Class Initialized
INFO - 2022-05-12 19:10:41 --> Final output sent to browser
DEBUG - 2022-05-12 19:10:41 --> Total execution time: 0.0766
INFO - 2022-05-12 19:11:08 --> Config Class Initialized
INFO - 2022-05-12 19:11:08 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:11:08 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:11:08 --> Utf8 Class Initialized
INFO - 2022-05-12 19:11:08 --> URI Class Initialized
INFO - 2022-05-12 19:11:08 --> Router Class Initialized
INFO - 2022-05-12 19:11:08 --> Output Class Initialized
INFO - 2022-05-12 19:11:08 --> Security Class Initialized
DEBUG - 2022-05-12 19:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:11:08 --> Input Class Initialized
INFO - 2022-05-12 19:11:08 --> Language Class Initialized
INFO - 2022-05-12 19:11:08 --> Language Class Initialized
INFO - 2022-05-12 19:11:08 --> Config Class Initialized
INFO - 2022-05-12 19:11:08 --> Loader Class Initialized
INFO - 2022-05-12 19:11:08 --> Helper loaded: url_helper
INFO - 2022-05-12 19:11:08 --> Database Driver Class Initialized
INFO - 2022-05-12 19:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:11:08 --> Controller Class Initialized
DEBUG - 2022-05-12 19:11:08 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:11:08 --> Model Class Initialized
DEBUG - 2022-05-12 19:11:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:11:08 --> Model Class Initialized
DEBUG - 2022-05-12 19:11:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:11:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:11:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:11:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:11:08 --> Final output sent to browser
DEBUG - 2022-05-12 19:11:08 --> Total execution time: 0.0953
INFO - 2022-05-12 19:11:11 --> Config Class Initialized
INFO - 2022-05-12 19:11:11 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:11:11 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:11:11 --> Utf8 Class Initialized
INFO - 2022-05-12 19:11:11 --> URI Class Initialized
INFO - 2022-05-12 19:11:11 --> Router Class Initialized
INFO - 2022-05-12 19:11:11 --> Output Class Initialized
INFO - 2022-05-12 19:11:11 --> Security Class Initialized
DEBUG - 2022-05-12 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:11:11 --> Input Class Initialized
INFO - 2022-05-12 19:11:11 --> Language Class Initialized
INFO - 2022-05-12 19:11:11 --> Language Class Initialized
INFO - 2022-05-12 19:11:11 --> Config Class Initialized
INFO - 2022-05-12 19:11:11 --> Loader Class Initialized
INFO - 2022-05-12 19:11:11 --> Helper loaded: url_helper
INFO - 2022-05-12 19:11:11 --> Database Driver Class Initialized
INFO - 2022-05-12 19:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:11:11 --> Controller Class Initialized
DEBUG - 2022-05-12 19:11:11 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:11:11 --> Model Class Initialized
DEBUG - 2022-05-12 19:11:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:11:11 --> Model Class Initialized
INFO - 2022-05-12 19:11:11 --> Final output sent to browser
DEBUG - 2022-05-12 19:11:11 --> Total execution time: 0.0756
INFO - 2022-05-12 19:11:17 --> Config Class Initialized
INFO - 2022-05-12 19:11:17 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:11:17 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:11:17 --> Utf8 Class Initialized
INFO - 2022-05-12 19:11:17 --> URI Class Initialized
INFO - 2022-05-12 19:11:17 --> Router Class Initialized
INFO - 2022-05-12 19:11:17 --> Output Class Initialized
INFO - 2022-05-12 19:11:17 --> Security Class Initialized
DEBUG - 2022-05-12 19:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:11:17 --> Input Class Initialized
INFO - 2022-05-12 19:11:17 --> Language Class Initialized
INFO - 2022-05-12 19:11:17 --> Language Class Initialized
INFO - 2022-05-12 19:11:17 --> Config Class Initialized
INFO - 2022-05-12 19:11:17 --> Loader Class Initialized
INFO - 2022-05-12 19:11:17 --> Helper loaded: url_helper
INFO - 2022-05-12 19:11:17 --> Database Driver Class Initialized
INFO - 2022-05-12 19:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:11:17 --> Controller Class Initialized
DEBUG - 2022-05-12 19:11:17 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:11:17 --> Model Class Initialized
DEBUG - 2022-05-12 19:11:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:11:17 --> Model Class Initialized
DEBUG - 2022-05-12 19:11:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:11:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:11:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:11:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:11:17 --> Final output sent to browser
DEBUG - 2022-05-12 19:11:17 --> Total execution time: 0.0797
INFO - 2022-05-12 19:25:57 --> Config Class Initialized
INFO - 2022-05-12 19:25:57 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:25:57 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:25:57 --> Utf8 Class Initialized
INFO - 2022-05-12 19:25:57 --> URI Class Initialized
INFO - 2022-05-12 19:25:57 --> Router Class Initialized
INFO - 2022-05-12 19:25:57 --> Output Class Initialized
INFO - 2022-05-12 19:25:57 --> Security Class Initialized
DEBUG - 2022-05-12 19:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:25:57 --> Input Class Initialized
INFO - 2022-05-12 19:25:57 --> Language Class Initialized
INFO - 2022-05-12 19:25:57 --> Language Class Initialized
INFO - 2022-05-12 19:25:57 --> Config Class Initialized
INFO - 2022-05-12 19:25:57 --> Loader Class Initialized
INFO - 2022-05-12 19:25:57 --> Helper loaded: url_helper
INFO - 2022-05-12 19:25:57 --> Database Driver Class Initialized
INFO - 2022-05-12 19:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:25:57 --> Controller Class Initialized
DEBUG - 2022-05-12 19:25:57 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:25:57 --> Model Class Initialized
DEBUG - 2022-05-12 19:25:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:25:57 --> Model Class Initialized
DEBUG - 2022-05-12 19:25:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:25:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:25:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:25:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:25:57 --> Final output sent to browser
DEBUG - 2022-05-12 19:25:57 --> Total execution time: 0.0332
INFO - 2022-05-12 19:26:02 --> Config Class Initialized
INFO - 2022-05-12 19:26:02 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:26:02 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:26:02 --> Utf8 Class Initialized
INFO - 2022-05-12 19:26:02 --> URI Class Initialized
INFO - 2022-05-12 19:26:02 --> Router Class Initialized
INFO - 2022-05-12 19:26:02 --> Output Class Initialized
INFO - 2022-05-12 19:26:02 --> Security Class Initialized
DEBUG - 2022-05-12 19:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:26:02 --> Input Class Initialized
INFO - 2022-05-12 19:26:02 --> Language Class Initialized
INFO - 2022-05-12 19:26:02 --> Language Class Initialized
INFO - 2022-05-12 19:26:02 --> Config Class Initialized
INFO - 2022-05-12 19:26:02 --> Loader Class Initialized
INFO - 2022-05-12 19:26:02 --> Helper loaded: url_helper
INFO - 2022-05-12 19:26:02 --> Database Driver Class Initialized
INFO - 2022-05-12 19:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:26:02 --> Controller Class Initialized
DEBUG - 2022-05-12 19:26:02 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:26:02 --> Model Class Initialized
DEBUG - 2022-05-12 19:26:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:26:02 --> Model Class Initialized
INFO - 2022-05-12 19:26:02 --> Final output sent to browser
DEBUG - 2022-05-12 19:26:02 --> Total execution time: 0.0356
INFO - 2022-05-12 19:26:08 --> Config Class Initialized
INFO - 2022-05-12 19:26:08 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:26:08 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:26:08 --> Utf8 Class Initialized
INFO - 2022-05-12 19:26:08 --> URI Class Initialized
INFO - 2022-05-12 19:26:08 --> Router Class Initialized
INFO - 2022-05-12 19:26:08 --> Output Class Initialized
INFO - 2022-05-12 19:26:08 --> Security Class Initialized
DEBUG - 2022-05-12 19:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:26:08 --> Input Class Initialized
INFO - 2022-05-12 19:26:08 --> Language Class Initialized
INFO - 2022-05-12 19:26:08 --> Language Class Initialized
INFO - 2022-05-12 19:26:08 --> Config Class Initialized
INFO - 2022-05-12 19:26:08 --> Loader Class Initialized
INFO - 2022-05-12 19:26:08 --> Helper loaded: url_helper
INFO - 2022-05-12 19:26:08 --> Database Driver Class Initialized
INFO - 2022-05-12 19:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:26:08 --> Controller Class Initialized
DEBUG - 2022-05-12 19:26:08 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:26:08 --> Model Class Initialized
DEBUG - 2022-05-12 19:26:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:26:08 --> Model Class Initialized
INFO - 2022-05-12 19:26:08 --> Final output sent to browser
DEBUG - 2022-05-12 19:26:08 --> Total execution time: 0.0348
INFO - 2022-05-12 19:26:10 --> Config Class Initialized
INFO - 2022-05-12 19:26:10 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:26:10 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:26:10 --> Utf8 Class Initialized
INFO - 2022-05-12 19:26:10 --> URI Class Initialized
INFO - 2022-05-12 19:26:10 --> Router Class Initialized
INFO - 2022-05-12 19:26:10 --> Output Class Initialized
INFO - 2022-05-12 19:26:10 --> Security Class Initialized
DEBUG - 2022-05-12 19:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:26:10 --> Input Class Initialized
INFO - 2022-05-12 19:26:10 --> Language Class Initialized
INFO - 2022-05-12 19:26:10 --> Language Class Initialized
INFO - 2022-05-12 19:26:10 --> Config Class Initialized
INFO - 2022-05-12 19:26:10 --> Loader Class Initialized
INFO - 2022-05-12 19:26:10 --> Helper loaded: url_helper
INFO - 2022-05-12 19:26:10 --> Database Driver Class Initialized
INFO - 2022-05-12 19:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:26:10 --> Controller Class Initialized
DEBUG - 2022-05-12 19:26:10 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:26:10 --> Model Class Initialized
DEBUG - 2022-05-12 19:26:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:26:10 --> Model Class Initialized
INFO - 2022-05-12 19:26:10 --> Final output sent to browser
DEBUG - 2022-05-12 19:26:10 --> Total execution time: 0.0372
INFO - 2022-05-12 19:31:13 --> Config Class Initialized
INFO - 2022-05-12 19:31:13 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:31:13 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:31:13 --> Utf8 Class Initialized
INFO - 2022-05-12 19:31:13 --> URI Class Initialized
INFO - 2022-05-12 19:31:13 --> Router Class Initialized
INFO - 2022-05-12 19:31:13 --> Output Class Initialized
INFO - 2022-05-12 19:31:13 --> Security Class Initialized
DEBUG - 2022-05-12 19:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:31:13 --> Input Class Initialized
INFO - 2022-05-12 19:31:13 --> Language Class Initialized
INFO - 2022-05-12 19:31:13 --> Language Class Initialized
INFO - 2022-05-12 19:31:13 --> Config Class Initialized
INFO - 2022-05-12 19:31:13 --> Loader Class Initialized
INFO - 2022-05-12 19:31:13 --> Helper loaded: url_helper
INFO - 2022-05-12 19:31:13 --> Database Driver Class Initialized
INFO - 2022-05-12 19:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:31:13 --> Controller Class Initialized
DEBUG - 2022-05-12 19:31:13 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:31:13 --> Model Class Initialized
DEBUG - 2022-05-12 19:31:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:31:13 --> Model Class Initialized
DEBUG - 2022-05-12 19:31:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:31:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:31:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:31:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:31:13 --> Final output sent to browser
DEBUG - 2022-05-12 19:31:13 --> Total execution time: 0.0335
INFO - 2022-05-12 19:31:44 --> Config Class Initialized
INFO - 2022-05-12 19:31:44 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:31:44 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:31:44 --> Utf8 Class Initialized
INFO - 2022-05-12 19:31:44 --> URI Class Initialized
INFO - 2022-05-12 19:31:44 --> Router Class Initialized
INFO - 2022-05-12 19:31:44 --> Output Class Initialized
INFO - 2022-05-12 19:31:44 --> Security Class Initialized
DEBUG - 2022-05-12 19:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:31:44 --> Input Class Initialized
INFO - 2022-05-12 19:31:44 --> Language Class Initialized
INFO - 2022-05-12 19:31:44 --> Language Class Initialized
INFO - 2022-05-12 19:31:44 --> Config Class Initialized
INFO - 2022-05-12 19:31:44 --> Loader Class Initialized
INFO - 2022-05-12 19:31:44 --> Helper loaded: url_helper
INFO - 2022-05-12 19:31:44 --> Database Driver Class Initialized
INFO - 2022-05-12 19:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:31:44 --> Controller Class Initialized
DEBUG - 2022-05-12 19:31:44 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:31:44 --> Model Class Initialized
DEBUG - 2022-05-12 19:31:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:31:44 --> Model Class Initialized
DEBUG - 2022-05-12 19:31:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:31:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:31:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:31:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:31:44 --> Final output sent to browser
DEBUG - 2022-05-12 19:31:44 --> Total execution time: 0.0501
INFO - 2022-05-12 19:32:21 --> Config Class Initialized
INFO - 2022-05-12 19:32:21 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:32:21 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:32:21 --> Utf8 Class Initialized
INFO - 2022-05-12 19:32:21 --> URI Class Initialized
INFO - 2022-05-12 19:32:21 --> Router Class Initialized
INFO - 2022-05-12 19:32:21 --> Output Class Initialized
INFO - 2022-05-12 19:32:21 --> Security Class Initialized
DEBUG - 2022-05-12 19:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:32:21 --> Input Class Initialized
INFO - 2022-05-12 19:32:21 --> Language Class Initialized
INFO - 2022-05-12 19:32:21 --> Language Class Initialized
INFO - 2022-05-12 19:32:21 --> Config Class Initialized
INFO - 2022-05-12 19:32:21 --> Loader Class Initialized
INFO - 2022-05-12 19:32:21 --> Helper loaded: url_helper
INFO - 2022-05-12 19:32:21 --> Database Driver Class Initialized
INFO - 2022-05-12 19:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:32:21 --> Controller Class Initialized
DEBUG - 2022-05-12 19:32:21 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:32:21 --> Model Class Initialized
DEBUG - 2022-05-12 19:32:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:32:21 --> Model Class Initialized
DEBUG - 2022-05-12 19:32:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:32:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:32:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:32:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:32:21 --> Final output sent to browser
DEBUG - 2022-05-12 19:32:21 --> Total execution time: 0.0422
INFO - 2022-05-12 19:34:32 --> Config Class Initialized
INFO - 2022-05-12 19:34:32 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:34:32 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:34:32 --> Utf8 Class Initialized
INFO - 2022-05-12 19:34:32 --> URI Class Initialized
INFO - 2022-05-12 19:34:32 --> Router Class Initialized
INFO - 2022-05-12 19:34:32 --> Output Class Initialized
INFO - 2022-05-12 19:34:32 --> Security Class Initialized
DEBUG - 2022-05-12 19:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:34:32 --> Input Class Initialized
INFO - 2022-05-12 19:34:32 --> Language Class Initialized
INFO - 2022-05-12 19:34:32 --> Language Class Initialized
INFO - 2022-05-12 19:34:32 --> Config Class Initialized
INFO - 2022-05-12 19:34:32 --> Loader Class Initialized
INFO - 2022-05-12 19:34:32 --> Helper loaded: url_helper
INFO - 2022-05-12 19:34:32 --> Database Driver Class Initialized
INFO - 2022-05-12 19:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:34:32 --> Controller Class Initialized
DEBUG - 2022-05-12 19:34:32 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:34:32 --> Model Class Initialized
DEBUG - 2022-05-12 19:34:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:34:32 --> Model Class Initialized
DEBUG - 2022-05-12 19:34:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:34:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:34:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:34:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:34:32 --> Final output sent to browser
DEBUG - 2022-05-12 19:34:32 --> Total execution time: 0.0454
INFO - 2022-05-12 19:34:41 --> Config Class Initialized
INFO - 2022-05-12 19:34:41 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:34:41 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:34:41 --> Utf8 Class Initialized
INFO - 2022-05-12 19:34:41 --> URI Class Initialized
INFO - 2022-05-12 19:34:41 --> Router Class Initialized
INFO - 2022-05-12 19:34:41 --> Output Class Initialized
INFO - 2022-05-12 19:34:41 --> Security Class Initialized
DEBUG - 2022-05-12 19:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:34:41 --> Input Class Initialized
INFO - 2022-05-12 19:34:41 --> Language Class Initialized
INFO - 2022-05-12 19:34:41 --> Language Class Initialized
INFO - 2022-05-12 19:34:41 --> Config Class Initialized
INFO - 2022-05-12 19:34:41 --> Loader Class Initialized
INFO - 2022-05-12 19:34:41 --> Helper loaded: url_helper
INFO - 2022-05-12 19:34:41 --> Database Driver Class Initialized
INFO - 2022-05-12 19:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:34:41 --> Controller Class Initialized
DEBUG - 2022-05-12 19:34:41 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:34:41 --> Model Class Initialized
DEBUG - 2022-05-12 19:34:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:34:41 --> Model Class Initialized
INFO - 2022-05-12 19:34:41 --> Final output sent to browser
DEBUG - 2022-05-12 19:34:41 --> Total execution time: 0.0355
INFO - 2022-05-12 19:35:13 --> Config Class Initialized
INFO - 2022-05-12 19:35:13 --> Hooks Class Initialized
DEBUG - 2022-05-12 19:35:13 --> UTF-8 Support Enabled
INFO - 2022-05-12 19:35:13 --> Utf8 Class Initialized
INFO - 2022-05-12 19:35:13 --> URI Class Initialized
INFO - 2022-05-12 19:35:13 --> Router Class Initialized
INFO - 2022-05-12 19:35:13 --> Output Class Initialized
INFO - 2022-05-12 19:35:13 --> Security Class Initialized
DEBUG - 2022-05-12 19:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-12 19:35:13 --> Input Class Initialized
INFO - 2022-05-12 19:35:13 --> Language Class Initialized
INFO - 2022-05-12 19:35:13 --> Language Class Initialized
INFO - 2022-05-12 19:35:13 --> Config Class Initialized
INFO - 2022-05-12 19:35:13 --> Loader Class Initialized
INFO - 2022-05-12 19:35:13 --> Helper loaded: url_helper
INFO - 2022-05-12 19:35:13 --> Database Driver Class Initialized
INFO - 2022-05-12 19:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-12 19:35:13 --> Controller Class Initialized
DEBUG - 2022-05-12 19:35:13 --> Admin MX_Controller Initialized
INFO - 2022-05-12 19:35:13 --> Model Class Initialized
DEBUG - 2022-05-12 19:35:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-12 19:35:13 --> Model Class Initialized
DEBUG - 2022-05-12 19:35:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-12 19:35:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-12 19:35:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/edit_vehicle.php
DEBUG - 2022-05-12 19:35:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-12 19:35:13 --> Final output sent to browser
DEBUG - 2022-05-12 19:35:13 --> Total execution time: 0.0450
