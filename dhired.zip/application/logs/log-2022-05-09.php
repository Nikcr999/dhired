<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-09 04:15:04 --> Config Class Initialized
INFO - 2022-05-09 04:15:04 --> Hooks Class Initialized
DEBUG - 2022-05-09 04:15:04 --> UTF-8 Support Enabled
INFO - 2022-05-09 04:15:04 --> Utf8 Class Initialized
INFO - 2022-05-09 04:15:04 --> URI Class Initialized
DEBUG - 2022-05-09 04:15:04 --> No URI present. Default controller set.
INFO - 2022-05-09 04:15:04 --> Router Class Initialized
INFO - 2022-05-09 04:15:04 --> Output Class Initialized
INFO - 2022-05-09 04:15:04 --> Security Class Initialized
DEBUG - 2022-05-09 04:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 04:15:04 --> Input Class Initialized
INFO - 2022-05-09 04:15:04 --> Language Class Initialized
INFO - 2022-05-09 04:15:04 --> Language Class Initialized
INFO - 2022-05-09 04:15:04 --> Config Class Initialized
INFO - 2022-05-09 04:15:04 --> Loader Class Initialized
INFO - 2022-05-09 04:15:04 --> Helper loaded: url_helper
INFO - 2022-05-09 04:15:04 --> Database Driver Class Initialized
INFO - 2022-05-09 04:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 04:15:04 --> Controller Class Initialized
DEBUG - 2022-05-09 04:15:04 --> Admin MX_Controller Initialized
INFO - 2022-05-09 04:15:04 --> Model Class Initialized
DEBUG - 2022-05-09 04:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 04:15:04 --> Model Class Initialized
DEBUG - 2022-05-09 04:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-09 04:15:04 --> Final output sent to browser
DEBUG - 2022-05-09 04:15:04 --> Total execution time: 0.2728
INFO - 2022-05-09 04:16:28 --> Config Class Initialized
INFO - 2022-05-09 04:16:28 --> Hooks Class Initialized
DEBUG - 2022-05-09 04:16:28 --> UTF-8 Support Enabled
INFO - 2022-05-09 04:16:28 --> Utf8 Class Initialized
INFO - 2022-05-09 04:16:28 --> URI Class Initialized
INFO - 2022-05-09 04:16:28 --> Router Class Initialized
INFO - 2022-05-09 04:16:28 --> Output Class Initialized
INFO - 2022-05-09 04:16:28 --> Security Class Initialized
DEBUG - 2022-05-09 04:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 04:16:28 --> Input Class Initialized
INFO - 2022-05-09 04:16:28 --> Language Class Initialized
INFO - 2022-05-09 04:16:28 --> Language Class Initialized
INFO - 2022-05-09 04:16:28 --> Config Class Initialized
INFO - 2022-05-09 04:16:28 --> Loader Class Initialized
INFO - 2022-05-09 04:16:28 --> Helper loaded: url_helper
INFO - 2022-05-09 04:16:28 --> Database Driver Class Initialized
INFO - 2022-05-09 04:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 04:16:28 --> Controller Class Initialized
DEBUG - 2022-05-09 04:16:28 --> Admin MX_Controller Initialized
INFO - 2022-05-09 04:16:28 --> Model Class Initialized
DEBUG - 2022-05-09 04:16:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 04:16:28 --> Model Class Initialized
DEBUG - 2022-05-09 04:16:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 04:16:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 04:16:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-09 04:16:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 04:16:29 --> Final output sent to browser
DEBUG - 2022-05-09 04:16:29 --> Total execution time: 0.5388
INFO - 2022-05-09 20:23:05 --> Config Class Initialized
INFO - 2022-05-09 20:23:05 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:23:05 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:23:05 --> Utf8 Class Initialized
INFO - 2022-05-09 20:23:05 --> URI Class Initialized
DEBUG - 2022-05-09 20:23:05 --> No URI present. Default controller set.
INFO - 2022-05-09 20:23:05 --> Router Class Initialized
INFO - 2022-05-09 20:23:05 --> Output Class Initialized
INFO - 2022-05-09 20:23:05 --> Security Class Initialized
DEBUG - 2022-05-09 20:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:23:05 --> Input Class Initialized
INFO - 2022-05-09 20:23:05 --> Language Class Initialized
INFO - 2022-05-09 20:23:05 --> Language Class Initialized
INFO - 2022-05-09 20:23:05 --> Config Class Initialized
INFO - 2022-05-09 20:23:05 --> Loader Class Initialized
INFO - 2022-05-09 20:23:05 --> Helper loaded: url_helper
INFO - 2022-05-09 20:23:05 --> Database Driver Class Initialized
INFO - 2022-05-09 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:23:08 --> Controller Class Initialized
DEBUG - 2022-05-09 20:23:08 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:23:08 --> Model Class Initialized
DEBUG - 2022-05-09 20:23:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:23:08 --> Model Class Initialized
DEBUG - 2022-05-09 20:23:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-09 20:23:08 --> Final output sent to browser
DEBUG - 2022-05-09 20:23:08 --> Total execution time: 2.7177
INFO - 2022-05-09 20:24:38 --> Config Class Initialized
INFO - 2022-05-09 20:24:38 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:24:38 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:24:38 --> Utf8 Class Initialized
INFO - 2022-05-09 20:24:38 --> URI Class Initialized
INFO - 2022-05-09 20:24:38 --> Router Class Initialized
INFO - 2022-05-09 20:24:38 --> Output Class Initialized
INFO - 2022-05-09 20:24:38 --> Security Class Initialized
DEBUG - 2022-05-09 20:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:24:38 --> Input Class Initialized
INFO - 2022-05-09 20:24:38 --> Language Class Initialized
INFO - 2022-05-09 20:24:38 --> Language Class Initialized
INFO - 2022-05-09 20:24:38 --> Config Class Initialized
INFO - 2022-05-09 20:24:38 --> Loader Class Initialized
INFO - 2022-05-09 20:24:38 --> Helper loaded: url_helper
INFO - 2022-05-09 20:24:38 --> Database Driver Class Initialized
INFO - 2022-05-09 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:24:38 --> Controller Class Initialized
DEBUG - 2022-05-09 20:24:38 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:24:38 --> Model Class Initialized
DEBUG - 2022-05-09 20:24:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:24:38 --> Model Class Initialized
DEBUG - 2022-05-09 20:24:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:24:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:24:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-09 20:24:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:24:38 --> Final output sent to browser
DEBUG - 2022-05-09 20:24:38 --> Total execution time: 0.1312
INFO - 2022-05-09 20:24:41 --> Config Class Initialized
INFO - 2022-05-09 20:24:41 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:24:41 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:24:41 --> Utf8 Class Initialized
INFO - 2022-05-09 20:24:41 --> URI Class Initialized
INFO - 2022-05-09 20:24:41 --> Router Class Initialized
INFO - 2022-05-09 20:24:41 --> Output Class Initialized
INFO - 2022-05-09 20:24:41 --> Security Class Initialized
DEBUG - 2022-05-09 20:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:24:41 --> Input Class Initialized
INFO - 2022-05-09 20:24:41 --> Language Class Initialized
INFO - 2022-05-09 20:24:41 --> Language Class Initialized
INFO - 2022-05-09 20:24:41 --> Config Class Initialized
INFO - 2022-05-09 20:24:41 --> Loader Class Initialized
INFO - 2022-05-09 20:24:41 --> Helper loaded: url_helper
INFO - 2022-05-09 20:24:41 --> Database Driver Class Initialized
INFO - 2022-05-09 20:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:24:41 --> Controller Class Initialized
DEBUG - 2022-05-09 20:24:41 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:24:41 --> Model Class Initialized
DEBUG - 2022-05-09 20:24:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:24:41 --> Model Class Initialized
DEBUG - 2022-05-09 20:24:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:24:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:24:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-09 20:24:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:24:41 --> Final output sent to browser
DEBUG - 2022-05-09 20:24:41 --> Total execution time: 0.1606
INFO - 2022-05-09 20:25:55 --> Config Class Initialized
INFO - 2022-05-09 20:25:55 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:25:55 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:25:55 --> Utf8 Class Initialized
INFO - 2022-05-09 20:25:55 --> URI Class Initialized
INFO - 2022-05-09 20:25:55 --> Router Class Initialized
INFO - 2022-05-09 20:25:55 --> Output Class Initialized
INFO - 2022-05-09 20:25:55 --> Security Class Initialized
DEBUG - 2022-05-09 20:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:25:55 --> Input Class Initialized
INFO - 2022-05-09 20:25:55 --> Language Class Initialized
INFO - 2022-05-09 20:25:55 --> Language Class Initialized
INFO - 2022-05-09 20:25:55 --> Config Class Initialized
INFO - 2022-05-09 20:25:55 --> Loader Class Initialized
INFO - 2022-05-09 20:25:55 --> Helper loaded: url_helper
INFO - 2022-05-09 20:25:55 --> Database Driver Class Initialized
INFO - 2022-05-09 20:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:25:55 --> Controller Class Initialized
DEBUG - 2022-05-09 20:25:55 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:25:55 --> Model Class Initialized
DEBUG - 2022-05-09 20:25:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:25:55 --> Model Class Initialized
DEBUG - 2022-05-09 20:25:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:25:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:25:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-09 20:25:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:25:55 --> Final output sent to browser
DEBUG - 2022-05-09 20:25:55 --> Total execution time: 0.0485
INFO - 2022-05-09 20:26:43 --> Config Class Initialized
INFO - 2022-05-09 20:26:43 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:26:43 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:26:43 --> Utf8 Class Initialized
INFO - 2022-05-09 20:26:43 --> URI Class Initialized
INFO - 2022-05-09 20:26:43 --> Router Class Initialized
INFO - 2022-05-09 20:26:43 --> Output Class Initialized
INFO - 2022-05-09 20:26:43 --> Security Class Initialized
DEBUG - 2022-05-09 20:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:26:43 --> Input Class Initialized
INFO - 2022-05-09 20:26:43 --> Language Class Initialized
INFO - 2022-05-09 20:26:43 --> Language Class Initialized
INFO - 2022-05-09 20:26:43 --> Config Class Initialized
INFO - 2022-05-09 20:26:43 --> Loader Class Initialized
INFO - 2022-05-09 20:26:43 --> Helper loaded: url_helper
INFO - 2022-05-09 20:26:43 --> Database Driver Class Initialized
INFO - 2022-05-09 20:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:26:43 --> Controller Class Initialized
DEBUG - 2022-05-09 20:26:43 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:26:43 --> Model Class Initialized
DEBUG - 2022-05-09 20:26:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:26:43 --> Model Class Initialized
DEBUG - 2022-05-09 20:26:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:26:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:26:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-09 20:26:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:26:43 --> Final output sent to browser
DEBUG - 2022-05-09 20:26:43 --> Total execution time: 0.0578
INFO - 2022-05-09 20:27:49 --> Config Class Initialized
INFO - 2022-05-09 20:27:49 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:27:49 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:27:49 --> Utf8 Class Initialized
INFO - 2022-05-09 20:27:49 --> URI Class Initialized
INFO - 2022-05-09 20:27:49 --> Router Class Initialized
INFO - 2022-05-09 20:27:49 --> Output Class Initialized
INFO - 2022-05-09 20:27:49 --> Security Class Initialized
DEBUG - 2022-05-09 20:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:27:49 --> Input Class Initialized
INFO - 2022-05-09 20:27:49 --> Language Class Initialized
INFO - 2022-05-09 20:27:49 --> Language Class Initialized
INFO - 2022-05-09 20:27:49 --> Config Class Initialized
INFO - 2022-05-09 20:27:49 --> Loader Class Initialized
INFO - 2022-05-09 20:27:49 --> Helper loaded: url_helper
INFO - 2022-05-09 20:27:49 --> Database Driver Class Initialized
INFO - 2022-05-09 20:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:27:49 --> Controller Class Initialized
DEBUG - 2022-05-09 20:27:49 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:27:49 --> Model Class Initialized
DEBUG - 2022-05-09 20:27:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:27:49 --> Model Class Initialized
DEBUG - 2022-05-09 20:27:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:27:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:27:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-09 20:27:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:27:49 --> Final output sent to browser
DEBUG - 2022-05-09 20:27:49 --> Total execution time: 0.0627
INFO - 2022-05-09 20:28:39 --> Config Class Initialized
INFO - 2022-05-09 20:28:39 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:28:39 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:28:39 --> Utf8 Class Initialized
INFO - 2022-05-09 20:28:39 --> URI Class Initialized
INFO - 2022-05-09 20:28:39 --> Router Class Initialized
INFO - 2022-05-09 20:28:39 --> Output Class Initialized
INFO - 2022-05-09 20:28:39 --> Security Class Initialized
DEBUG - 2022-05-09 20:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:28:39 --> Input Class Initialized
INFO - 2022-05-09 20:28:39 --> Language Class Initialized
INFO - 2022-05-09 20:28:39 --> Language Class Initialized
INFO - 2022-05-09 20:28:39 --> Config Class Initialized
INFO - 2022-05-09 20:28:39 --> Loader Class Initialized
INFO - 2022-05-09 20:28:39 --> Helper loaded: url_helper
INFO - 2022-05-09 20:28:39 --> Database Driver Class Initialized
INFO - 2022-05-09 20:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:28:39 --> Controller Class Initialized
DEBUG - 2022-05-09 20:28:39 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:28:39 --> Model Class Initialized
DEBUG - 2022-05-09 20:28:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:28:39 --> Model Class Initialized
DEBUG - 2022-05-09 20:28:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:28:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:28:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-09 20:28:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:28:39 --> Final output sent to browser
DEBUG - 2022-05-09 20:28:39 --> Total execution time: 0.0521
INFO - 2022-05-09 20:28:54 --> Config Class Initialized
INFO - 2022-05-09 20:28:54 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:28:54 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:28:54 --> Utf8 Class Initialized
INFO - 2022-05-09 20:28:54 --> URI Class Initialized
INFO - 2022-05-09 20:28:54 --> Router Class Initialized
INFO - 2022-05-09 20:28:54 --> Output Class Initialized
INFO - 2022-05-09 20:28:54 --> Security Class Initialized
DEBUG - 2022-05-09 20:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:28:54 --> Input Class Initialized
INFO - 2022-05-09 20:28:54 --> Language Class Initialized
INFO - 2022-05-09 20:28:54 --> Language Class Initialized
INFO - 2022-05-09 20:28:54 --> Config Class Initialized
INFO - 2022-05-09 20:28:54 --> Loader Class Initialized
INFO - 2022-05-09 20:28:54 --> Helper loaded: url_helper
INFO - 2022-05-09 20:28:54 --> Database Driver Class Initialized
INFO - 2022-05-09 20:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:28:54 --> Controller Class Initialized
ERROR - 2022-05-09 20:28:54 --> 404 Page Not Found: ../modules/admin/controllers/Admin/add_car
INFO - 2022-05-09 20:29:32 --> Config Class Initialized
INFO - 2022-05-09 20:29:32 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:29:32 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:29:32 --> Utf8 Class Initialized
INFO - 2022-05-09 20:29:32 --> URI Class Initialized
INFO - 2022-05-09 20:29:32 --> Router Class Initialized
INFO - 2022-05-09 20:29:32 --> Output Class Initialized
INFO - 2022-05-09 20:29:32 --> Security Class Initialized
DEBUG - 2022-05-09 20:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:29:32 --> Input Class Initialized
INFO - 2022-05-09 20:29:32 --> Language Class Initialized
INFO - 2022-05-09 20:29:32 --> Language Class Initialized
INFO - 2022-05-09 20:29:32 --> Config Class Initialized
INFO - 2022-05-09 20:29:32 --> Loader Class Initialized
INFO - 2022-05-09 20:29:32 --> Helper loaded: url_helper
INFO - 2022-05-09 20:29:32 --> Database Driver Class Initialized
INFO - 2022-05-09 20:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:29:32 --> Controller Class Initialized
DEBUG - 2022-05-09 20:29:32 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:29:32 --> Model Class Initialized
DEBUG - 2022-05-09 20:29:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:29:32 --> Model Class Initialized
DEBUG - 2022-05-09 20:29:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:29:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:29:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:29:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:29:32 --> Final output sent to browser
DEBUG - 2022-05-09 20:29:32 --> Total execution time: 0.0322
INFO - 2022-05-09 20:29:40 --> Config Class Initialized
INFO - 2022-05-09 20:29:40 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:29:40 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:29:40 --> Utf8 Class Initialized
INFO - 2022-05-09 20:29:40 --> URI Class Initialized
INFO - 2022-05-09 20:29:40 --> Router Class Initialized
INFO - 2022-05-09 20:29:40 --> Output Class Initialized
INFO - 2022-05-09 20:29:40 --> Security Class Initialized
DEBUG - 2022-05-09 20:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:29:40 --> Input Class Initialized
INFO - 2022-05-09 20:29:40 --> Language Class Initialized
INFO - 2022-05-09 20:29:40 --> Language Class Initialized
INFO - 2022-05-09 20:29:40 --> Config Class Initialized
INFO - 2022-05-09 20:29:40 --> Loader Class Initialized
INFO - 2022-05-09 20:29:40 --> Helper loaded: url_helper
INFO - 2022-05-09 20:29:40 --> Database Driver Class Initialized
INFO - 2022-05-09 20:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:29:40 --> Controller Class Initialized
DEBUG - 2022-05-09 20:29:40 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:29:40 --> Model Class Initialized
DEBUG - 2022-05-09 20:29:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:29:40 --> Model Class Initialized
DEBUG - 2022-05-09 20:29:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:29:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:29:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:29:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:29:40 --> Final output sent to browser
DEBUG - 2022-05-09 20:29:40 --> Total execution time: 0.0521
INFO - 2022-05-09 20:30:31 --> Config Class Initialized
INFO - 2022-05-09 20:30:31 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:30:31 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:30:31 --> Utf8 Class Initialized
INFO - 2022-05-09 20:30:31 --> URI Class Initialized
INFO - 2022-05-09 20:30:31 --> Router Class Initialized
INFO - 2022-05-09 20:30:31 --> Output Class Initialized
INFO - 2022-05-09 20:30:31 --> Security Class Initialized
DEBUG - 2022-05-09 20:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:30:31 --> Input Class Initialized
INFO - 2022-05-09 20:30:31 --> Language Class Initialized
INFO - 2022-05-09 20:30:31 --> Language Class Initialized
INFO - 2022-05-09 20:30:31 --> Config Class Initialized
INFO - 2022-05-09 20:30:31 --> Loader Class Initialized
INFO - 2022-05-09 20:30:31 --> Helper loaded: url_helper
INFO - 2022-05-09 20:30:31 --> Database Driver Class Initialized
INFO - 2022-05-09 20:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:30:31 --> Controller Class Initialized
DEBUG - 2022-05-09 20:30:31 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:30:31 --> Model Class Initialized
DEBUG - 2022-05-09 20:30:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:30:31 --> Model Class Initialized
DEBUG - 2022-05-09 20:30:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:30:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:30:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:30:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:30:31 --> Final output sent to browser
DEBUG - 2022-05-09 20:30:31 --> Total execution time: 0.0460
INFO - 2022-05-09 20:31:11 --> Config Class Initialized
INFO - 2022-05-09 20:31:11 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:31:11 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:31:11 --> Utf8 Class Initialized
INFO - 2022-05-09 20:31:11 --> URI Class Initialized
INFO - 2022-05-09 20:31:11 --> Router Class Initialized
INFO - 2022-05-09 20:31:11 --> Output Class Initialized
INFO - 2022-05-09 20:31:11 --> Security Class Initialized
DEBUG - 2022-05-09 20:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:31:11 --> Input Class Initialized
INFO - 2022-05-09 20:31:11 --> Language Class Initialized
INFO - 2022-05-09 20:31:11 --> Language Class Initialized
INFO - 2022-05-09 20:31:11 --> Config Class Initialized
INFO - 2022-05-09 20:31:11 --> Loader Class Initialized
INFO - 2022-05-09 20:31:11 --> Helper loaded: url_helper
INFO - 2022-05-09 20:31:11 --> Database Driver Class Initialized
INFO - 2022-05-09 20:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:31:11 --> Controller Class Initialized
DEBUG - 2022-05-09 20:31:11 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:31:11 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:31:11 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:31:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:31:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:31:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:31:11 --> Final output sent to browser
DEBUG - 2022-05-09 20:31:11 --> Total execution time: 0.0598
INFO - 2022-05-09 20:31:29 --> Config Class Initialized
INFO - 2022-05-09 20:31:29 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:31:29 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:31:29 --> Utf8 Class Initialized
INFO - 2022-05-09 20:31:29 --> URI Class Initialized
INFO - 2022-05-09 20:31:29 --> Router Class Initialized
INFO - 2022-05-09 20:31:29 --> Output Class Initialized
INFO - 2022-05-09 20:31:29 --> Security Class Initialized
DEBUG - 2022-05-09 20:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:31:29 --> Input Class Initialized
INFO - 2022-05-09 20:31:29 --> Language Class Initialized
INFO - 2022-05-09 20:31:29 --> Language Class Initialized
INFO - 2022-05-09 20:31:29 --> Config Class Initialized
INFO - 2022-05-09 20:31:29 --> Loader Class Initialized
INFO - 2022-05-09 20:31:29 --> Helper loaded: url_helper
INFO - 2022-05-09 20:31:29 --> Database Driver Class Initialized
INFO - 2022-05-09 20:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:31:29 --> Controller Class Initialized
DEBUG - 2022-05-09 20:31:29 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:31:29 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:31:29 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:31:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:31:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:31:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:31:29 --> Final output sent to browser
DEBUG - 2022-05-09 20:31:29 --> Total execution time: 0.0497
INFO - 2022-05-09 20:31:32 --> Config Class Initialized
INFO - 2022-05-09 20:31:32 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:31:32 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:31:32 --> Utf8 Class Initialized
INFO - 2022-05-09 20:31:32 --> URI Class Initialized
INFO - 2022-05-09 20:31:32 --> Router Class Initialized
INFO - 2022-05-09 20:31:32 --> Output Class Initialized
INFO - 2022-05-09 20:31:32 --> Security Class Initialized
DEBUG - 2022-05-09 20:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:31:32 --> Input Class Initialized
INFO - 2022-05-09 20:31:32 --> Language Class Initialized
INFO - 2022-05-09 20:31:32 --> Language Class Initialized
INFO - 2022-05-09 20:31:32 --> Config Class Initialized
INFO - 2022-05-09 20:31:32 --> Loader Class Initialized
INFO - 2022-05-09 20:31:32 --> Helper loaded: url_helper
INFO - 2022-05-09 20:31:32 --> Database Driver Class Initialized
INFO - 2022-05-09 20:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:31:32 --> Controller Class Initialized
DEBUG - 2022-05-09 20:31:32 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:31:32 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:31:32 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:31:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:31:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-09 20:31:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:31:32 --> Final output sent to browser
DEBUG - 2022-05-09 20:31:32 --> Total execution time: 0.1168
INFO - 2022-05-09 20:31:58 --> Config Class Initialized
INFO - 2022-05-09 20:31:58 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:31:58 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:31:58 --> Utf8 Class Initialized
INFO - 2022-05-09 20:31:58 --> URI Class Initialized
INFO - 2022-05-09 20:31:58 --> Router Class Initialized
INFO - 2022-05-09 20:31:58 --> Output Class Initialized
INFO - 2022-05-09 20:31:58 --> Security Class Initialized
DEBUG - 2022-05-09 20:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:31:59 --> Input Class Initialized
INFO - 2022-05-09 20:31:59 --> Language Class Initialized
INFO - 2022-05-09 20:31:59 --> Language Class Initialized
INFO - 2022-05-09 20:31:59 --> Config Class Initialized
INFO - 2022-05-09 20:31:59 --> Loader Class Initialized
INFO - 2022-05-09 20:31:59 --> Helper loaded: url_helper
INFO - 2022-05-09 20:31:59 --> Database Driver Class Initialized
INFO - 2022-05-09 20:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:31:59 --> Controller Class Initialized
DEBUG - 2022-05-09 20:31:59 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:31:59 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:31:59 --> Model Class Initialized
DEBUG - 2022-05-09 20:31:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:31:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:31:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-09 20:31:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:31:59 --> Final output sent to browser
DEBUG - 2022-05-09 20:31:59 --> Total execution time: 0.0540
INFO - 2022-05-09 20:32:03 --> Config Class Initialized
INFO - 2022-05-09 20:32:03 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:32:03 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:32:03 --> Utf8 Class Initialized
INFO - 2022-05-09 20:32:03 --> URI Class Initialized
INFO - 2022-05-09 20:32:03 --> Router Class Initialized
INFO - 2022-05-09 20:32:03 --> Output Class Initialized
INFO - 2022-05-09 20:32:03 --> Security Class Initialized
DEBUG - 2022-05-09 20:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:32:03 --> Input Class Initialized
INFO - 2022-05-09 20:32:03 --> Language Class Initialized
INFO - 2022-05-09 20:32:03 --> Language Class Initialized
INFO - 2022-05-09 20:32:03 --> Config Class Initialized
INFO - 2022-05-09 20:32:03 --> Loader Class Initialized
INFO - 2022-05-09 20:32:03 --> Helper loaded: url_helper
INFO - 2022-05-09 20:32:03 --> Database Driver Class Initialized
INFO - 2022-05-09 20:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:32:03 --> Controller Class Initialized
DEBUG - 2022-05-09 20:32:03 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:32:03 --> Model Class Initialized
DEBUG - 2022-05-09 20:32:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:32:03 --> Model Class Initialized
DEBUG - 2022-05-09 20:32:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:32:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:32:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:32:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:32:03 --> Final output sent to browser
DEBUG - 2022-05-09 20:32:03 --> Total execution time: 0.0671
INFO - 2022-05-09 20:32:25 --> Config Class Initialized
INFO - 2022-05-09 20:32:25 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:32:25 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:32:25 --> Utf8 Class Initialized
INFO - 2022-05-09 20:32:25 --> URI Class Initialized
INFO - 2022-05-09 20:32:25 --> Router Class Initialized
INFO - 2022-05-09 20:32:25 --> Output Class Initialized
INFO - 2022-05-09 20:32:25 --> Security Class Initialized
DEBUG - 2022-05-09 20:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:32:25 --> Input Class Initialized
INFO - 2022-05-09 20:32:25 --> Language Class Initialized
INFO - 2022-05-09 20:32:25 --> Language Class Initialized
INFO - 2022-05-09 20:32:25 --> Config Class Initialized
INFO - 2022-05-09 20:32:25 --> Loader Class Initialized
INFO - 2022-05-09 20:32:25 --> Helper loaded: url_helper
INFO - 2022-05-09 20:32:25 --> Database Driver Class Initialized
INFO - 2022-05-09 20:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:32:25 --> Controller Class Initialized
DEBUG - 2022-05-09 20:32:25 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:32:25 --> Model Class Initialized
DEBUG - 2022-05-09 20:32:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:32:25 --> Model Class Initialized
DEBUG - 2022-05-09 20:32:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:32:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:32:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:32:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:32:25 --> Final output sent to browser
DEBUG - 2022-05-09 20:32:25 --> Total execution time: 0.0439
INFO - 2022-05-09 20:32:36 --> Config Class Initialized
INFO - 2022-05-09 20:32:36 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:32:36 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:32:36 --> Utf8 Class Initialized
INFO - 2022-05-09 20:32:36 --> URI Class Initialized
INFO - 2022-05-09 20:32:36 --> Router Class Initialized
INFO - 2022-05-09 20:32:36 --> Output Class Initialized
INFO - 2022-05-09 20:32:36 --> Security Class Initialized
DEBUG - 2022-05-09 20:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:32:36 --> Input Class Initialized
INFO - 2022-05-09 20:32:36 --> Language Class Initialized
INFO - 2022-05-09 20:32:36 --> Language Class Initialized
INFO - 2022-05-09 20:32:36 --> Config Class Initialized
INFO - 2022-05-09 20:32:36 --> Loader Class Initialized
INFO - 2022-05-09 20:32:36 --> Helper loaded: url_helper
INFO - 2022-05-09 20:32:36 --> Database Driver Class Initialized
INFO - 2022-05-09 20:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:32:36 --> Controller Class Initialized
DEBUG - 2022-05-09 20:32:36 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:32:36 --> Model Class Initialized
DEBUG - 2022-05-09 20:32:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:32:36 --> Model Class Initialized
DEBUG - 2022-05-09 20:32:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:32:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:32:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:32:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:32:36 --> Final output sent to browser
DEBUG - 2022-05-09 20:32:36 --> Total execution time: 0.0455
INFO - 2022-05-09 20:33:03 --> Config Class Initialized
INFO - 2022-05-09 20:33:03 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:33:03 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:33:03 --> Utf8 Class Initialized
INFO - 2022-05-09 20:33:03 --> URI Class Initialized
INFO - 2022-05-09 20:33:03 --> Router Class Initialized
INFO - 2022-05-09 20:33:03 --> Output Class Initialized
INFO - 2022-05-09 20:33:03 --> Security Class Initialized
DEBUG - 2022-05-09 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:33:03 --> Input Class Initialized
INFO - 2022-05-09 20:33:03 --> Language Class Initialized
INFO - 2022-05-09 20:33:03 --> Language Class Initialized
INFO - 2022-05-09 20:33:03 --> Config Class Initialized
INFO - 2022-05-09 20:33:03 --> Loader Class Initialized
INFO - 2022-05-09 20:33:03 --> Helper loaded: url_helper
INFO - 2022-05-09 20:33:03 --> Database Driver Class Initialized
INFO - 2022-05-09 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:33:03 --> Controller Class Initialized
DEBUG - 2022-05-09 20:33:03 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:33:03 --> Model Class Initialized
DEBUG - 2022-05-09 20:33:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:33:03 --> Model Class Initialized
DEBUG - 2022-05-09 20:33:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:33:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:33:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:33:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:33:03 --> Final output sent to browser
DEBUG - 2022-05-09 20:33:03 --> Total execution time: 0.0508
INFO - 2022-05-09 20:33:32 --> Config Class Initialized
INFO - 2022-05-09 20:33:32 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:33:32 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:33:32 --> Utf8 Class Initialized
INFO - 2022-05-09 20:33:32 --> URI Class Initialized
INFO - 2022-05-09 20:33:32 --> Router Class Initialized
INFO - 2022-05-09 20:33:32 --> Output Class Initialized
INFO - 2022-05-09 20:33:32 --> Security Class Initialized
DEBUG - 2022-05-09 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:33:32 --> Input Class Initialized
INFO - 2022-05-09 20:33:32 --> Language Class Initialized
INFO - 2022-05-09 20:33:32 --> Language Class Initialized
INFO - 2022-05-09 20:33:32 --> Config Class Initialized
INFO - 2022-05-09 20:33:32 --> Loader Class Initialized
INFO - 2022-05-09 20:33:32 --> Helper loaded: url_helper
INFO - 2022-05-09 20:33:32 --> Database Driver Class Initialized
INFO - 2022-05-09 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:33:32 --> Controller Class Initialized
DEBUG - 2022-05-09 20:33:32 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:33:32 --> Model Class Initialized
DEBUG - 2022-05-09 20:33:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:33:32 --> Model Class Initialized
DEBUG - 2022-05-09 20:33:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:33:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:33:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:33:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:33:32 --> Final output sent to browser
DEBUG - 2022-05-09 20:33:32 --> Total execution time: 0.0509
INFO - 2022-05-09 20:35:36 --> Config Class Initialized
INFO - 2022-05-09 20:35:36 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:35:36 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:35:36 --> Utf8 Class Initialized
INFO - 2022-05-09 20:35:36 --> URI Class Initialized
INFO - 2022-05-09 20:35:36 --> Router Class Initialized
INFO - 2022-05-09 20:35:36 --> Output Class Initialized
INFO - 2022-05-09 20:35:36 --> Security Class Initialized
DEBUG - 2022-05-09 20:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:35:36 --> Input Class Initialized
INFO - 2022-05-09 20:35:36 --> Language Class Initialized
INFO - 2022-05-09 20:35:36 --> Language Class Initialized
INFO - 2022-05-09 20:35:36 --> Config Class Initialized
INFO - 2022-05-09 20:35:36 --> Loader Class Initialized
INFO - 2022-05-09 20:35:36 --> Helper loaded: url_helper
INFO - 2022-05-09 20:35:36 --> Database Driver Class Initialized
INFO - 2022-05-09 20:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:35:36 --> Controller Class Initialized
DEBUG - 2022-05-09 20:35:36 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:35:36 --> Model Class Initialized
DEBUG - 2022-05-09 20:35:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:35:36 --> Model Class Initialized
DEBUG - 2022-05-09 20:35:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:35:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:35:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:35:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:35:36 --> Final output sent to browser
DEBUG - 2022-05-09 20:35:36 --> Total execution time: 0.0465
INFO - 2022-05-09 20:36:45 --> Config Class Initialized
INFO - 2022-05-09 20:36:45 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:36:45 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:36:45 --> Utf8 Class Initialized
INFO - 2022-05-09 20:36:45 --> URI Class Initialized
INFO - 2022-05-09 20:36:45 --> Router Class Initialized
INFO - 2022-05-09 20:36:45 --> Output Class Initialized
INFO - 2022-05-09 20:36:45 --> Security Class Initialized
DEBUG - 2022-05-09 20:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:36:45 --> Input Class Initialized
INFO - 2022-05-09 20:36:45 --> Language Class Initialized
INFO - 2022-05-09 20:36:45 --> Language Class Initialized
INFO - 2022-05-09 20:36:45 --> Config Class Initialized
INFO - 2022-05-09 20:36:45 --> Loader Class Initialized
INFO - 2022-05-09 20:36:45 --> Helper loaded: url_helper
INFO - 2022-05-09 20:36:45 --> Database Driver Class Initialized
INFO - 2022-05-09 20:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:36:45 --> Controller Class Initialized
DEBUG - 2022-05-09 20:36:45 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:36:45 --> Model Class Initialized
DEBUG - 2022-05-09 20:36:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:36:45 --> Model Class Initialized
DEBUG - 2022-05-09 20:36:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:36:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:36:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:36:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:36:45 --> Final output sent to browser
DEBUG - 2022-05-09 20:36:45 --> Total execution time: 0.0397
INFO - 2022-05-09 20:37:14 --> Config Class Initialized
INFO - 2022-05-09 20:37:14 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:37:14 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:37:14 --> Utf8 Class Initialized
INFO - 2022-05-09 20:37:14 --> URI Class Initialized
INFO - 2022-05-09 20:37:14 --> Router Class Initialized
INFO - 2022-05-09 20:37:14 --> Output Class Initialized
INFO - 2022-05-09 20:37:14 --> Security Class Initialized
DEBUG - 2022-05-09 20:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:37:14 --> Input Class Initialized
INFO - 2022-05-09 20:37:14 --> Language Class Initialized
INFO - 2022-05-09 20:37:14 --> Language Class Initialized
INFO - 2022-05-09 20:37:14 --> Config Class Initialized
INFO - 2022-05-09 20:37:14 --> Loader Class Initialized
INFO - 2022-05-09 20:37:14 --> Helper loaded: url_helper
INFO - 2022-05-09 20:37:14 --> Database Driver Class Initialized
INFO - 2022-05-09 20:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:37:14 --> Controller Class Initialized
DEBUG - 2022-05-09 20:37:14 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:37:14 --> Model Class Initialized
DEBUG - 2022-05-09 20:37:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:37:14 --> Model Class Initialized
DEBUG - 2022-05-09 20:37:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:37:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:37:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:37:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:37:14 --> Final output sent to browser
DEBUG - 2022-05-09 20:37:14 --> Total execution time: 0.0554
INFO - 2022-05-09 20:37:46 --> Config Class Initialized
INFO - 2022-05-09 20:37:46 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:37:46 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:37:46 --> Utf8 Class Initialized
INFO - 2022-05-09 20:37:46 --> URI Class Initialized
INFO - 2022-05-09 20:37:46 --> Router Class Initialized
INFO - 2022-05-09 20:37:46 --> Output Class Initialized
INFO - 2022-05-09 20:37:46 --> Security Class Initialized
DEBUG - 2022-05-09 20:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:37:46 --> Input Class Initialized
INFO - 2022-05-09 20:37:46 --> Language Class Initialized
INFO - 2022-05-09 20:37:46 --> Language Class Initialized
INFO - 2022-05-09 20:37:46 --> Config Class Initialized
INFO - 2022-05-09 20:37:46 --> Loader Class Initialized
INFO - 2022-05-09 20:37:46 --> Helper loaded: url_helper
INFO - 2022-05-09 20:37:46 --> Database Driver Class Initialized
INFO - 2022-05-09 20:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:37:46 --> Controller Class Initialized
DEBUG - 2022-05-09 20:37:46 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:37:46 --> Model Class Initialized
DEBUG - 2022-05-09 20:37:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:37:46 --> Model Class Initialized
DEBUG - 2022-05-09 20:37:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:37:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:37:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:37:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:37:46 --> Final output sent to browser
DEBUG - 2022-05-09 20:37:46 --> Total execution time: 0.0556
INFO - 2022-05-09 20:39:20 --> Config Class Initialized
INFO - 2022-05-09 20:39:20 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:39:20 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:39:20 --> Utf8 Class Initialized
INFO - 2022-05-09 20:39:20 --> URI Class Initialized
INFO - 2022-05-09 20:39:20 --> Router Class Initialized
INFO - 2022-05-09 20:39:20 --> Output Class Initialized
INFO - 2022-05-09 20:39:20 --> Security Class Initialized
DEBUG - 2022-05-09 20:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:39:20 --> Input Class Initialized
INFO - 2022-05-09 20:39:20 --> Language Class Initialized
INFO - 2022-05-09 20:39:20 --> Language Class Initialized
INFO - 2022-05-09 20:39:20 --> Config Class Initialized
INFO - 2022-05-09 20:39:20 --> Loader Class Initialized
INFO - 2022-05-09 20:39:20 --> Helper loaded: url_helper
INFO - 2022-05-09 20:39:20 --> Database Driver Class Initialized
INFO - 2022-05-09 20:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:39:20 --> Controller Class Initialized
DEBUG - 2022-05-09 20:39:20 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:39:20 --> Model Class Initialized
DEBUG - 2022-05-09 20:39:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:39:20 --> Model Class Initialized
DEBUG - 2022-05-09 20:39:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:39:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:39:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:39:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:39:20 --> Final output sent to browser
DEBUG - 2022-05-09 20:39:20 --> Total execution time: 0.0566
INFO - 2022-05-09 20:39:37 --> Config Class Initialized
INFO - 2022-05-09 20:39:37 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:39:37 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:39:37 --> Utf8 Class Initialized
INFO - 2022-05-09 20:39:37 --> URI Class Initialized
INFO - 2022-05-09 20:39:37 --> Router Class Initialized
INFO - 2022-05-09 20:39:37 --> Output Class Initialized
INFO - 2022-05-09 20:39:37 --> Security Class Initialized
DEBUG - 2022-05-09 20:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:39:37 --> Input Class Initialized
INFO - 2022-05-09 20:39:37 --> Language Class Initialized
INFO - 2022-05-09 20:39:37 --> Language Class Initialized
INFO - 2022-05-09 20:39:37 --> Config Class Initialized
INFO - 2022-05-09 20:39:37 --> Loader Class Initialized
INFO - 2022-05-09 20:39:37 --> Helper loaded: url_helper
INFO - 2022-05-09 20:39:37 --> Database Driver Class Initialized
INFO - 2022-05-09 20:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:39:37 --> Controller Class Initialized
DEBUG - 2022-05-09 20:39:37 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:39:38 --> Model Class Initialized
DEBUG - 2022-05-09 20:39:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:39:38 --> Model Class Initialized
DEBUG - 2022-05-09 20:39:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:39:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:39:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:39:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:39:38 --> Final output sent to browser
DEBUG - 2022-05-09 20:39:38 --> Total execution time: 0.0527
INFO - 2022-05-09 20:45:35 --> Config Class Initialized
INFO - 2022-05-09 20:45:35 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:45:35 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:45:35 --> Utf8 Class Initialized
INFO - 2022-05-09 20:45:35 --> URI Class Initialized
INFO - 2022-05-09 20:45:35 --> Router Class Initialized
INFO - 2022-05-09 20:45:35 --> Output Class Initialized
INFO - 2022-05-09 20:45:35 --> Security Class Initialized
DEBUG - 2022-05-09 20:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:45:35 --> Input Class Initialized
INFO - 2022-05-09 20:45:35 --> Language Class Initialized
INFO - 2022-05-09 20:45:35 --> Language Class Initialized
INFO - 2022-05-09 20:45:35 --> Config Class Initialized
INFO - 2022-05-09 20:45:35 --> Loader Class Initialized
INFO - 2022-05-09 20:45:35 --> Helper loaded: url_helper
INFO - 2022-05-09 20:45:35 --> Database Driver Class Initialized
INFO - 2022-05-09 20:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:45:35 --> Controller Class Initialized
DEBUG - 2022-05-09 20:45:35 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:45:35 --> Model Class Initialized
DEBUG - 2022-05-09 20:45:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:45:35 --> Model Class Initialized
DEBUG - 2022-05-09 20:45:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:45:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:45:35 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:45:35 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:45:35 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
DEBUG - 2022-05-09 20:45:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:45:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:45:35 --> Final output sent to browser
DEBUG - 2022-05-09 20:45:35 --> Total execution time: 0.1085
INFO - 2022-05-09 20:45:50 --> Config Class Initialized
INFO - 2022-05-09 20:45:50 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:45:50 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:45:50 --> Utf8 Class Initialized
INFO - 2022-05-09 20:45:50 --> URI Class Initialized
INFO - 2022-05-09 20:45:50 --> Router Class Initialized
INFO - 2022-05-09 20:45:50 --> Output Class Initialized
INFO - 2022-05-09 20:45:50 --> Security Class Initialized
DEBUG - 2022-05-09 20:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:45:50 --> Input Class Initialized
INFO - 2022-05-09 20:45:50 --> Language Class Initialized
INFO - 2022-05-09 20:45:50 --> Language Class Initialized
INFO - 2022-05-09 20:45:50 --> Config Class Initialized
INFO - 2022-05-09 20:45:50 --> Loader Class Initialized
INFO - 2022-05-09 20:45:50 --> Helper loaded: url_helper
INFO - 2022-05-09 20:45:50 --> Database Driver Class Initialized
INFO - 2022-05-09 20:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:45:50 --> Controller Class Initialized
DEBUG - 2022-05-09 20:45:50 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:45:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:45:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:45:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:45:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:45:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-09 20:46:46 --> Config Class Initialized
INFO - 2022-05-09 20:46:46 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:46:46 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:46:46 --> Utf8 Class Initialized
INFO - 2022-05-09 20:46:46 --> URI Class Initialized
INFO - 2022-05-09 20:46:46 --> Router Class Initialized
INFO - 2022-05-09 20:46:46 --> Output Class Initialized
INFO - 2022-05-09 20:46:46 --> Security Class Initialized
DEBUG - 2022-05-09 20:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:46:46 --> Input Class Initialized
INFO - 2022-05-09 20:46:46 --> Language Class Initialized
INFO - 2022-05-09 20:46:46 --> Language Class Initialized
INFO - 2022-05-09 20:46:46 --> Config Class Initialized
INFO - 2022-05-09 20:46:46 --> Loader Class Initialized
INFO - 2022-05-09 20:46:46 --> Helper loaded: url_helper
INFO - 2022-05-09 20:46:46 --> Database Driver Class Initialized
INFO - 2022-05-09 20:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:46:47 --> Controller Class Initialized
DEBUG - 2022-05-09 20:46:47 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:46:47 --> Model Class Initialized
DEBUG - 2022-05-09 20:46:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:46:47 --> Model Class Initialized
DEBUG - 2022-05-09 20:46:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:46:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:46:47 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:46:47 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:46:47 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:46:47 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:46:47 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:46:47 --> Severity: Notice --> Undefined index: $i N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
DEBUG - 2022-05-09 20:46:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:46:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:46:47 --> Final output sent to browser
DEBUG - 2022-05-09 20:46:47 --> Total execution time: 0.0507
INFO - 2022-05-09 20:47:16 --> Config Class Initialized
INFO - 2022-05-09 20:47:16 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:47:16 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:47:16 --> Utf8 Class Initialized
INFO - 2022-05-09 20:47:16 --> URI Class Initialized
INFO - 2022-05-09 20:47:16 --> Router Class Initialized
INFO - 2022-05-09 20:47:16 --> Output Class Initialized
INFO - 2022-05-09 20:47:16 --> Security Class Initialized
DEBUG - 2022-05-09 20:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:47:16 --> Input Class Initialized
INFO - 2022-05-09 20:47:16 --> Language Class Initialized
INFO - 2022-05-09 20:47:16 --> Language Class Initialized
INFO - 2022-05-09 20:47:16 --> Config Class Initialized
INFO - 2022-05-09 20:47:16 --> Loader Class Initialized
INFO - 2022-05-09 20:47:16 --> Helper loaded: url_helper
INFO - 2022-05-09 20:47:16 --> Database Driver Class Initialized
INFO - 2022-05-09 20:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:47:16 --> Controller Class Initialized
DEBUG - 2022-05-09 20:47:16 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:47:16 --> Model Class Initialized
DEBUG - 2022-05-09 20:47:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:47:16 --> Model Class Initialized
DEBUG - 2022-05-09 20:47:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:47:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:47:16 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:16 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:16 --> Severity: Notice --> Undefined offset: 1 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:16 --> Severity: Notice --> Undefined offset: 1 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:16 --> Severity: Notice --> Undefined offset: 2 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:16 --> Severity: Notice --> Undefined offset: 2 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
DEBUG - 2022-05-09 20:47:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:47:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:47:16 --> Final output sent to browser
DEBUG - 2022-05-09 20:47:16 --> Total execution time: 0.0573
INFO - 2022-05-09 20:47:22 --> Config Class Initialized
INFO - 2022-05-09 20:47:22 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:47:22 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:47:22 --> Utf8 Class Initialized
INFO - 2022-05-09 20:47:22 --> URI Class Initialized
INFO - 2022-05-09 20:47:22 --> Router Class Initialized
INFO - 2022-05-09 20:47:22 --> Output Class Initialized
INFO - 2022-05-09 20:47:22 --> Security Class Initialized
DEBUG - 2022-05-09 20:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:47:22 --> Input Class Initialized
INFO - 2022-05-09 20:47:22 --> Language Class Initialized
INFO - 2022-05-09 20:47:22 --> Language Class Initialized
INFO - 2022-05-09 20:47:22 --> Config Class Initialized
INFO - 2022-05-09 20:47:22 --> Loader Class Initialized
INFO - 2022-05-09 20:47:22 --> Helper loaded: url_helper
INFO - 2022-05-09 20:47:22 --> Database Driver Class Initialized
INFO - 2022-05-09 20:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:47:22 --> Controller Class Initialized
DEBUG - 2022-05-09 20:47:22 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:47:22 --> Model Class Initialized
DEBUG - 2022-05-09 20:47:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:47:22 --> Model Class Initialized
DEBUG - 2022-05-09 20:47:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:47:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:47:22 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:22 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:22 --> Severity: Notice --> Undefined offset: 1 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:22 --> Severity: Notice --> Undefined offset: 1 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:22 --> Severity: Notice --> Undefined offset: 2 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:47:22 --> Severity: Notice --> Undefined offset: 2 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
DEBUG - 2022-05-09 20:47:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:47:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:47:22 --> Final output sent to browser
DEBUG - 2022-05-09 20:47:22 --> Total execution time: 0.0544
INFO - 2022-05-09 20:48:31 --> Config Class Initialized
INFO - 2022-05-09 20:48:31 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:48:31 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:48:31 --> Utf8 Class Initialized
INFO - 2022-05-09 20:48:31 --> URI Class Initialized
INFO - 2022-05-09 20:48:31 --> Router Class Initialized
INFO - 2022-05-09 20:48:31 --> Output Class Initialized
INFO - 2022-05-09 20:48:31 --> Security Class Initialized
DEBUG - 2022-05-09 20:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:48:31 --> Input Class Initialized
INFO - 2022-05-09 20:48:31 --> Language Class Initialized
INFO - 2022-05-09 20:48:31 --> Language Class Initialized
INFO - 2022-05-09 20:48:31 --> Config Class Initialized
INFO - 2022-05-09 20:48:31 --> Loader Class Initialized
INFO - 2022-05-09 20:48:31 --> Helper loaded: url_helper
INFO - 2022-05-09 20:48:31 --> Database Driver Class Initialized
INFO - 2022-05-09 20:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:48:31 --> Controller Class Initialized
DEBUG - 2022-05-09 20:48:31 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:48:31 --> Model Class Initialized
DEBUG - 2022-05-09 20:48:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:48:31 --> Model Class Initialized
DEBUG - 2022-05-09 20:48:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:48:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:48:31 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:48:31 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:48:31 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:48:31 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:48:31 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:48:31 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
DEBUG - 2022-05-09 20:48:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:48:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:48:31 --> Final output sent to browser
DEBUG - 2022-05-09 20:48:31 --> Total execution time: 0.0665
INFO - 2022-05-09 20:48:50 --> Config Class Initialized
INFO - 2022-05-09 20:48:50 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:48:50 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:48:50 --> Utf8 Class Initialized
INFO - 2022-05-09 20:48:50 --> URI Class Initialized
INFO - 2022-05-09 20:48:50 --> Router Class Initialized
INFO - 2022-05-09 20:48:50 --> Output Class Initialized
INFO - 2022-05-09 20:48:50 --> Security Class Initialized
DEBUG - 2022-05-09 20:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:48:50 --> Input Class Initialized
INFO - 2022-05-09 20:48:50 --> Language Class Initialized
INFO - 2022-05-09 20:48:50 --> Language Class Initialized
INFO - 2022-05-09 20:48:50 --> Config Class Initialized
INFO - 2022-05-09 20:48:50 --> Loader Class Initialized
INFO - 2022-05-09 20:48:50 --> Helper loaded: url_helper
INFO - 2022-05-09 20:48:50 --> Database Driver Class Initialized
INFO - 2022-05-09 20:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:48:50 --> Controller Class Initialized
DEBUG - 2022-05-09 20:48:50 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:48:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:48:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:48:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:48:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:48:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-09 20:49:33 --> Config Class Initialized
INFO - 2022-05-09 20:49:33 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:49:33 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:49:33 --> Utf8 Class Initialized
INFO - 2022-05-09 20:49:33 --> URI Class Initialized
INFO - 2022-05-09 20:49:33 --> Router Class Initialized
INFO - 2022-05-09 20:49:33 --> Output Class Initialized
INFO - 2022-05-09 20:49:33 --> Security Class Initialized
DEBUG - 2022-05-09 20:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:49:33 --> Input Class Initialized
INFO - 2022-05-09 20:49:33 --> Language Class Initialized
INFO - 2022-05-09 20:49:33 --> Language Class Initialized
INFO - 2022-05-09 20:49:33 --> Config Class Initialized
INFO - 2022-05-09 20:49:33 --> Loader Class Initialized
INFO - 2022-05-09 20:49:33 --> Helper loaded: url_helper
INFO - 2022-05-09 20:49:33 --> Database Driver Class Initialized
INFO - 2022-05-09 20:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:49:33 --> Controller Class Initialized
DEBUG - 2022-05-09 20:49:33 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:49:33 --> Model Class Initialized
DEBUG - 2022-05-09 20:49:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:49:33 --> Model Class Initialized
DEBUG - 2022-05-09 20:49:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:49:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:49:33 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:49:33 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:49:33 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:49:33 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:49:33 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
ERROR - 2022-05-09 20:49:33 --> Severity: Notice --> Undefined offset: 0 N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 39
DEBUG - 2022-05-09 20:49:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:49:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:49:33 --> Final output sent to browser
DEBUG - 2022-05-09 20:49:33 --> Total execution time: 0.0531
INFO - 2022-05-09 20:49:59 --> Config Class Initialized
INFO - 2022-05-09 20:49:59 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:49:59 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:49:59 --> Utf8 Class Initialized
INFO - 2022-05-09 20:49:59 --> URI Class Initialized
INFO - 2022-05-09 20:49:59 --> Router Class Initialized
INFO - 2022-05-09 20:49:59 --> Output Class Initialized
INFO - 2022-05-09 20:49:59 --> Security Class Initialized
DEBUG - 2022-05-09 20:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:49:59 --> Input Class Initialized
INFO - 2022-05-09 20:49:59 --> Language Class Initialized
INFO - 2022-05-09 20:49:59 --> Language Class Initialized
INFO - 2022-05-09 20:49:59 --> Config Class Initialized
INFO - 2022-05-09 20:49:59 --> Loader Class Initialized
INFO - 2022-05-09 20:49:59 --> Helper loaded: url_helper
INFO - 2022-05-09 20:49:59 --> Database Driver Class Initialized
INFO - 2022-05-09 20:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:49:59 --> Controller Class Initialized
DEBUG - 2022-05-09 20:49:59 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:49:59 --> Model Class Initialized
DEBUG - 2022-05-09 20:49:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:49:59 --> Model Class Initialized
DEBUG - 2022-05-09 20:49:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:49:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:49:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:49:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:49:59 --> Final output sent to browser
DEBUG - 2022-05-09 20:49:59 --> Total execution time: 0.0557
INFO - 2022-05-09 20:51:50 --> Config Class Initialized
INFO - 2022-05-09 20:51:50 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:51:50 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:51:50 --> Utf8 Class Initialized
INFO - 2022-05-09 20:51:50 --> URI Class Initialized
INFO - 2022-05-09 20:51:50 --> Router Class Initialized
INFO - 2022-05-09 20:51:50 --> Output Class Initialized
INFO - 2022-05-09 20:51:50 --> Security Class Initialized
DEBUG - 2022-05-09 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:51:50 --> Input Class Initialized
INFO - 2022-05-09 20:51:50 --> Language Class Initialized
INFO - 2022-05-09 20:51:50 --> Language Class Initialized
INFO - 2022-05-09 20:51:50 --> Config Class Initialized
INFO - 2022-05-09 20:51:50 --> Loader Class Initialized
INFO - 2022-05-09 20:51:50 --> Helper loaded: url_helper
INFO - 2022-05-09 20:51:50 --> Database Driver Class Initialized
INFO - 2022-05-09 20:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:51:50 --> Controller Class Initialized
DEBUG - 2022-05-09 20:51:50 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:51:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:51:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:51:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:51:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:51:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:51:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:51:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:51:50 --> Final output sent to browser
DEBUG - 2022-05-09 20:51:50 --> Total execution time: 0.0580
INFO - 2022-05-09 20:52:10 --> Config Class Initialized
INFO - 2022-05-09 20:52:10 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:52:10 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:52:10 --> Utf8 Class Initialized
INFO - 2022-05-09 20:52:10 --> URI Class Initialized
INFO - 2022-05-09 20:52:10 --> Router Class Initialized
INFO - 2022-05-09 20:52:10 --> Output Class Initialized
INFO - 2022-05-09 20:52:10 --> Security Class Initialized
DEBUG - 2022-05-09 20:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:52:10 --> Input Class Initialized
INFO - 2022-05-09 20:52:10 --> Language Class Initialized
INFO - 2022-05-09 20:52:10 --> Language Class Initialized
INFO - 2022-05-09 20:52:10 --> Config Class Initialized
INFO - 2022-05-09 20:52:10 --> Loader Class Initialized
INFO - 2022-05-09 20:52:10 --> Helper loaded: url_helper
INFO - 2022-05-09 20:52:10 --> Database Driver Class Initialized
INFO - 2022-05-09 20:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:52:10 --> Controller Class Initialized
DEBUG - 2022-05-09 20:52:10 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:52:10 --> Model Class Initialized
DEBUG - 2022-05-09 20:52:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:52:10 --> Model Class Initialized
DEBUG - 2022-05-09 20:52:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:52:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:52:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:52:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:52:10 --> Final output sent to browser
DEBUG - 2022-05-09 20:52:10 --> Total execution time: 0.0593
INFO - 2022-05-09 20:53:54 --> Config Class Initialized
INFO - 2022-05-09 20:53:54 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:53:54 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:53:54 --> Utf8 Class Initialized
INFO - 2022-05-09 20:53:54 --> URI Class Initialized
INFO - 2022-05-09 20:53:54 --> Router Class Initialized
INFO - 2022-05-09 20:53:54 --> Output Class Initialized
INFO - 2022-05-09 20:53:54 --> Security Class Initialized
DEBUG - 2022-05-09 20:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:53:54 --> Input Class Initialized
INFO - 2022-05-09 20:53:54 --> Language Class Initialized
INFO - 2022-05-09 20:53:54 --> Language Class Initialized
INFO - 2022-05-09 20:53:54 --> Config Class Initialized
INFO - 2022-05-09 20:53:54 --> Loader Class Initialized
INFO - 2022-05-09 20:53:54 --> Helper loaded: url_helper
INFO - 2022-05-09 20:53:54 --> Database Driver Class Initialized
INFO - 2022-05-09 20:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:53:54 --> Controller Class Initialized
DEBUG - 2022-05-09 20:53:54 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:53:54 --> Model Class Initialized
DEBUG - 2022-05-09 20:53:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:53:54 --> Model Class Initialized
DEBUG - 2022-05-09 20:53:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:53:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:53:54 --> Severity: Notice --> Undefined variable: brand N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 46
DEBUG - 2022-05-09 20:53:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:53:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:53:54 --> Final output sent to browser
DEBUG - 2022-05-09 20:53:54 --> Total execution time: 0.0617
INFO - 2022-05-09 20:54:10 --> Config Class Initialized
INFO - 2022-05-09 20:54:10 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:54:10 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:54:10 --> Utf8 Class Initialized
INFO - 2022-05-09 20:54:10 --> URI Class Initialized
INFO - 2022-05-09 20:54:10 --> Router Class Initialized
INFO - 2022-05-09 20:54:10 --> Output Class Initialized
INFO - 2022-05-09 20:54:10 --> Security Class Initialized
DEBUG - 2022-05-09 20:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:54:10 --> Input Class Initialized
INFO - 2022-05-09 20:54:10 --> Language Class Initialized
INFO - 2022-05-09 20:54:10 --> Language Class Initialized
INFO - 2022-05-09 20:54:10 --> Config Class Initialized
INFO - 2022-05-09 20:54:10 --> Loader Class Initialized
INFO - 2022-05-09 20:54:10 --> Helper loaded: url_helper
INFO - 2022-05-09 20:54:10 --> Database Driver Class Initialized
INFO - 2022-05-09 20:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:54:10 --> Controller Class Initialized
DEBUG - 2022-05-09 20:54:10 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:54:10 --> Model Class Initialized
DEBUG - 2022-05-09 20:54:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:54:10 --> Model Class Initialized
DEBUG - 2022-05-09 20:54:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:54:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:54:10 --> Severity: Notice --> Undefined variable: brand N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 46
DEBUG - 2022-05-09 20:54:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:54:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:54:10 --> Final output sent to browser
DEBUG - 2022-05-09 20:54:10 --> Total execution time: 0.0424
INFO - 2022-05-09 20:55:19 --> Config Class Initialized
INFO - 2022-05-09 20:55:19 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:55:19 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:55:19 --> Utf8 Class Initialized
INFO - 2022-05-09 20:55:19 --> URI Class Initialized
INFO - 2022-05-09 20:55:19 --> Router Class Initialized
INFO - 2022-05-09 20:55:19 --> Output Class Initialized
INFO - 2022-05-09 20:55:19 --> Security Class Initialized
DEBUG - 2022-05-09 20:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:55:19 --> Input Class Initialized
INFO - 2022-05-09 20:55:19 --> Language Class Initialized
INFO - 2022-05-09 20:55:19 --> Language Class Initialized
INFO - 2022-05-09 20:55:19 --> Config Class Initialized
INFO - 2022-05-09 20:55:19 --> Loader Class Initialized
INFO - 2022-05-09 20:55:19 --> Helper loaded: url_helper
INFO - 2022-05-09 20:55:19 --> Database Driver Class Initialized
INFO - 2022-05-09 20:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:55:19 --> Controller Class Initialized
DEBUG - 2022-05-09 20:55:19 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:55:19 --> Model Class Initialized
DEBUG - 2022-05-09 20:55:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:55:19 --> Model Class Initialized
DEBUG - 2022-05-09 20:55:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:55:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:55:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:55:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:55:19 --> Final output sent to browser
DEBUG - 2022-05-09 20:55:19 --> Total execution time: 0.0469
INFO - 2022-05-09 20:55:50 --> Config Class Initialized
INFO - 2022-05-09 20:55:50 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:55:50 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:55:50 --> Utf8 Class Initialized
INFO - 2022-05-09 20:55:50 --> URI Class Initialized
INFO - 2022-05-09 20:55:50 --> Router Class Initialized
INFO - 2022-05-09 20:55:50 --> Output Class Initialized
INFO - 2022-05-09 20:55:50 --> Security Class Initialized
DEBUG - 2022-05-09 20:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:55:50 --> Input Class Initialized
INFO - 2022-05-09 20:55:50 --> Language Class Initialized
INFO - 2022-05-09 20:55:50 --> Language Class Initialized
INFO - 2022-05-09 20:55:50 --> Config Class Initialized
INFO - 2022-05-09 20:55:50 --> Loader Class Initialized
INFO - 2022-05-09 20:55:50 --> Helper loaded: url_helper
INFO - 2022-05-09 20:55:50 --> Database Driver Class Initialized
INFO - 2022-05-09 20:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:55:50 --> Controller Class Initialized
DEBUG - 2022-05-09 20:55:50 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:55:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:55:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:55:50 --> Model Class Initialized
DEBUG - 2022-05-09 20:55:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:55:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-09 20:55:50 --> Severity: Notice --> Undefined variable: brand N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_car.php 46
DEBUG - 2022-05-09 20:55:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:55:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:55:50 --> Final output sent to browser
DEBUG - 2022-05-09 20:55:50 --> Total execution time: 0.0702
INFO - 2022-05-09 20:58:10 --> Config Class Initialized
INFO - 2022-05-09 20:58:10 --> Hooks Class Initialized
DEBUG - 2022-05-09 20:58:10 --> UTF-8 Support Enabled
INFO - 2022-05-09 20:58:10 --> Utf8 Class Initialized
INFO - 2022-05-09 20:58:10 --> URI Class Initialized
INFO - 2022-05-09 20:58:10 --> Router Class Initialized
INFO - 2022-05-09 20:58:10 --> Output Class Initialized
INFO - 2022-05-09 20:58:10 --> Security Class Initialized
DEBUG - 2022-05-09 20:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 20:58:10 --> Input Class Initialized
INFO - 2022-05-09 20:58:10 --> Language Class Initialized
INFO - 2022-05-09 20:58:10 --> Language Class Initialized
INFO - 2022-05-09 20:58:10 --> Config Class Initialized
INFO - 2022-05-09 20:58:10 --> Loader Class Initialized
INFO - 2022-05-09 20:58:10 --> Helper loaded: url_helper
INFO - 2022-05-09 20:58:10 --> Database Driver Class Initialized
INFO - 2022-05-09 20:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 20:58:10 --> Controller Class Initialized
DEBUG - 2022-05-09 20:58:10 --> Admin MX_Controller Initialized
INFO - 2022-05-09 20:58:10 --> Model Class Initialized
DEBUG - 2022-05-09 20:58:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 20:58:10 --> Model Class Initialized
DEBUG - 2022-05-09 20:58:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 20:58:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 20:58:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 20:58:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 20:58:10 --> Final output sent to browser
DEBUG - 2022-05-09 20:58:10 --> Total execution time: 0.0444
INFO - 2022-05-09 21:01:33 --> Config Class Initialized
INFO - 2022-05-09 21:01:33 --> Hooks Class Initialized
DEBUG - 2022-05-09 21:01:33 --> UTF-8 Support Enabled
INFO - 2022-05-09 21:01:33 --> Utf8 Class Initialized
INFO - 2022-05-09 21:01:33 --> URI Class Initialized
INFO - 2022-05-09 21:01:33 --> Router Class Initialized
INFO - 2022-05-09 21:01:33 --> Output Class Initialized
INFO - 2022-05-09 21:01:33 --> Security Class Initialized
DEBUG - 2022-05-09 21:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-09 21:01:33 --> Input Class Initialized
INFO - 2022-05-09 21:01:33 --> Language Class Initialized
INFO - 2022-05-09 21:01:33 --> Language Class Initialized
INFO - 2022-05-09 21:01:33 --> Config Class Initialized
INFO - 2022-05-09 21:01:33 --> Loader Class Initialized
INFO - 2022-05-09 21:01:33 --> Helper loaded: url_helper
INFO - 2022-05-09 21:01:33 --> Database Driver Class Initialized
INFO - 2022-05-09 21:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-09 21:01:33 --> Controller Class Initialized
DEBUG - 2022-05-09 21:01:33 --> Admin MX_Controller Initialized
INFO - 2022-05-09 21:01:33 --> Model Class Initialized
DEBUG - 2022-05-09 21:01:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-09 21:01:33 --> Model Class Initialized
DEBUG - 2022-05-09 21:01:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-09 21:01:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-09 21:01:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-09 21:01:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-09 21:01:33 --> Final output sent to browser
DEBUG - 2022-05-09 21:01:33 --> Total execution time: 0.0664
