<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-11 03:59:47 --> Config Class Initialized
INFO - 2022-05-11 03:59:47 --> Hooks Class Initialized
DEBUG - 2022-05-11 03:59:47 --> UTF-8 Support Enabled
INFO - 2022-05-11 03:59:47 --> Utf8 Class Initialized
INFO - 2022-05-11 03:59:47 --> URI Class Initialized
INFO - 2022-05-11 03:59:47 --> Router Class Initialized
INFO - 2022-05-11 03:59:47 --> Output Class Initialized
INFO - 2022-05-11 03:59:47 --> Security Class Initialized
DEBUG - 2022-05-11 03:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 03:59:47 --> Input Class Initialized
INFO - 2022-05-11 03:59:47 --> Language Class Initialized
INFO - 2022-05-11 03:59:47 --> Language Class Initialized
INFO - 2022-05-11 03:59:47 --> Config Class Initialized
INFO - 2022-05-11 03:59:47 --> Loader Class Initialized
INFO - 2022-05-11 03:59:47 --> Helper loaded: url_helper
INFO - 2022-05-11 03:59:47 --> Database Driver Class Initialized
INFO - 2022-05-11 03:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 03:59:47 --> Controller Class Initialized
DEBUG - 2022-05-11 03:59:47 --> Admin MX_Controller Initialized
INFO - 2022-05-11 03:59:47 --> Model Class Initialized
DEBUG - 2022-05-11 03:59:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 03:59:47 --> Model Class Initialized
INFO - 2022-05-11 03:59:47 --> Config Class Initialized
INFO - 2022-05-11 03:59:47 --> Hooks Class Initialized
DEBUG - 2022-05-11 03:59:47 --> UTF-8 Support Enabled
INFO - 2022-05-11 03:59:47 --> Utf8 Class Initialized
INFO - 2022-05-11 03:59:47 --> URI Class Initialized
INFO - 2022-05-11 03:59:47 --> Router Class Initialized
INFO - 2022-05-11 03:59:47 --> Output Class Initialized
INFO - 2022-05-11 03:59:47 --> Security Class Initialized
DEBUG - 2022-05-11 03:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 03:59:47 --> Input Class Initialized
INFO - 2022-05-11 03:59:47 --> Language Class Initialized
INFO - 2022-05-11 03:59:47 --> Language Class Initialized
INFO - 2022-05-11 03:59:47 --> Config Class Initialized
INFO - 2022-05-11 03:59:47 --> Loader Class Initialized
INFO - 2022-05-11 03:59:47 --> Helper loaded: url_helper
INFO - 2022-05-11 03:59:47 --> Database Driver Class Initialized
INFO - 2022-05-11 03:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 03:59:47 --> Controller Class Initialized
DEBUG - 2022-05-11 03:59:47 --> Admin MX_Controller Initialized
INFO - 2022-05-11 03:59:47 --> Model Class Initialized
DEBUG - 2022-05-11 03:59:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 03:59:47 --> Model Class Initialized
DEBUG - 2022-05-11 03:59:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-11 03:59:47 --> Final output sent to browser
DEBUG - 2022-05-11 03:59:47 --> Total execution time: 0.0523
INFO - 2022-05-11 03:59:55 --> Config Class Initialized
INFO - 2022-05-11 03:59:55 --> Hooks Class Initialized
DEBUG - 2022-05-11 03:59:55 --> UTF-8 Support Enabled
INFO - 2022-05-11 03:59:55 --> Utf8 Class Initialized
INFO - 2022-05-11 03:59:55 --> URI Class Initialized
INFO - 2022-05-11 03:59:55 --> Router Class Initialized
INFO - 2022-05-11 03:59:55 --> Output Class Initialized
INFO - 2022-05-11 03:59:55 --> Security Class Initialized
DEBUG - 2022-05-11 03:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 03:59:55 --> Input Class Initialized
INFO - 2022-05-11 03:59:55 --> Language Class Initialized
INFO - 2022-05-11 03:59:55 --> Language Class Initialized
INFO - 2022-05-11 03:59:55 --> Config Class Initialized
INFO - 2022-05-11 03:59:55 --> Loader Class Initialized
INFO - 2022-05-11 03:59:55 --> Helper loaded: url_helper
INFO - 2022-05-11 03:59:56 --> Database Driver Class Initialized
INFO - 2022-05-11 03:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 03:59:56 --> Controller Class Initialized
DEBUG - 2022-05-11 03:59:56 --> Admin MX_Controller Initialized
INFO - 2022-05-11 03:59:56 --> Model Class Initialized
DEBUG - 2022-05-11 03:59:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 03:59:56 --> Model Class Initialized
INFO - 2022-05-11 03:59:56 --> Config Class Initialized
INFO - 2022-05-11 03:59:56 --> Hooks Class Initialized
DEBUG - 2022-05-11 03:59:56 --> UTF-8 Support Enabled
INFO - 2022-05-11 03:59:56 --> Utf8 Class Initialized
INFO - 2022-05-11 03:59:56 --> URI Class Initialized
INFO - 2022-05-11 03:59:56 --> Router Class Initialized
INFO - 2022-05-11 03:59:56 --> Output Class Initialized
INFO - 2022-05-11 03:59:56 --> Security Class Initialized
DEBUG - 2022-05-11 03:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 03:59:56 --> Input Class Initialized
INFO - 2022-05-11 03:59:56 --> Language Class Initialized
INFO - 2022-05-11 03:59:56 --> Language Class Initialized
INFO - 2022-05-11 03:59:56 --> Config Class Initialized
INFO - 2022-05-11 03:59:56 --> Loader Class Initialized
INFO - 2022-05-11 03:59:56 --> Helper loaded: url_helper
INFO - 2022-05-11 03:59:56 --> Database Driver Class Initialized
INFO - 2022-05-11 03:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 03:59:56 --> Controller Class Initialized
DEBUG - 2022-05-11 03:59:56 --> Admin MX_Controller Initialized
INFO - 2022-05-11 03:59:56 --> Model Class Initialized
DEBUG - 2022-05-11 03:59:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 03:59:56 --> Model Class Initialized
DEBUG - 2022-05-11 03:59:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 03:59:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 03:59:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 03:59:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 03:59:56 --> Final output sent to browser
DEBUG - 2022-05-11 03:59:56 --> Total execution time: 0.0541
INFO - 2022-05-11 04:00:00 --> Config Class Initialized
INFO - 2022-05-11 04:00:00 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:00:00 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:00:00 --> Utf8 Class Initialized
INFO - 2022-05-11 04:00:00 --> URI Class Initialized
INFO - 2022-05-11 04:00:00 --> Router Class Initialized
INFO - 2022-05-11 04:00:00 --> Output Class Initialized
INFO - 2022-05-11 04:00:00 --> Security Class Initialized
DEBUG - 2022-05-11 04:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:00:00 --> Input Class Initialized
INFO - 2022-05-11 04:00:00 --> Language Class Initialized
INFO - 2022-05-11 04:00:00 --> Language Class Initialized
INFO - 2022-05-11 04:00:00 --> Config Class Initialized
INFO - 2022-05-11 04:00:00 --> Loader Class Initialized
INFO - 2022-05-11 04:00:00 --> Helper loaded: url_helper
INFO - 2022-05-11 04:00:00 --> Database Driver Class Initialized
INFO - 2022-05-11 04:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:00:00 --> Controller Class Initialized
DEBUG - 2022-05-11 04:00:00 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:00:00 --> Model Class Initialized
DEBUG - 2022-05-11 04:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:00:00 --> Model Class Initialized
DEBUG - 2022-05-11 04:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:00:00 --> Final output sent to browser
DEBUG - 2022-05-11 04:00:00 --> Total execution time: 0.0843
INFO - 2022-05-11 04:01:49 --> Config Class Initialized
INFO - 2022-05-11 04:01:49 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:01:49 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:01:49 --> Utf8 Class Initialized
INFO - 2022-05-11 04:01:49 --> URI Class Initialized
INFO - 2022-05-11 04:01:49 --> Router Class Initialized
INFO - 2022-05-11 04:01:49 --> Output Class Initialized
INFO - 2022-05-11 04:01:49 --> Security Class Initialized
DEBUG - 2022-05-11 04:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:01:49 --> Input Class Initialized
INFO - 2022-05-11 04:01:49 --> Language Class Initialized
INFO - 2022-05-11 04:01:49 --> Language Class Initialized
INFO - 2022-05-11 04:01:49 --> Config Class Initialized
INFO - 2022-05-11 04:01:49 --> Loader Class Initialized
INFO - 2022-05-11 04:01:49 --> Helper loaded: url_helper
INFO - 2022-05-11 04:01:49 --> Database Driver Class Initialized
INFO - 2022-05-11 04:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:01:49 --> Controller Class Initialized
DEBUG - 2022-05-11 04:01:49 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:01:49 --> Model Class Initialized
DEBUG - 2022-05-11 04:01:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:01:49 --> Model Class Initialized
DEBUG - 2022-05-11 04:01:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:01:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:01:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:01:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:01:49 --> Final output sent to browser
DEBUG - 2022-05-11 04:01:49 --> Total execution time: 0.1137
INFO - 2022-05-11 04:02:26 --> Config Class Initialized
INFO - 2022-05-11 04:02:26 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:02:26 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:02:26 --> Utf8 Class Initialized
INFO - 2022-05-11 04:02:26 --> URI Class Initialized
INFO - 2022-05-11 04:02:26 --> Router Class Initialized
INFO - 2022-05-11 04:02:26 --> Output Class Initialized
INFO - 2022-05-11 04:02:26 --> Security Class Initialized
DEBUG - 2022-05-11 04:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:02:26 --> Input Class Initialized
INFO - 2022-05-11 04:02:26 --> Language Class Initialized
INFO - 2022-05-11 04:02:26 --> Language Class Initialized
INFO - 2022-05-11 04:02:26 --> Config Class Initialized
INFO - 2022-05-11 04:02:26 --> Loader Class Initialized
INFO - 2022-05-11 04:02:26 --> Helper loaded: url_helper
INFO - 2022-05-11 04:02:26 --> Database Driver Class Initialized
INFO - 2022-05-11 04:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:02:26 --> Controller Class Initialized
DEBUG - 2022-05-11 04:02:26 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:02:26 --> Model Class Initialized
DEBUG - 2022-05-11 04:02:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:02:26 --> Model Class Initialized
INFO - 2022-05-11 04:02:26 --> Final output sent to browser
DEBUG - 2022-05-11 04:02:26 --> Total execution time: 0.0783
INFO - 2022-05-11 04:04:54 --> Config Class Initialized
INFO - 2022-05-11 04:04:54 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:04:54 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:04:54 --> Utf8 Class Initialized
INFO - 2022-05-11 04:04:54 --> URI Class Initialized
INFO - 2022-05-11 04:04:54 --> Router Class Initialized
INFO - 2022-05-11 04:04:54 --> Output Class Initialized
INFO - 2022-05-11 04:04:54 --> Security Class Initialized
DEBUG - 2022-05-11 04:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:04:54 --> Input Class Initialized
INFO - 2022-05-11 04:04:54 --> Language Class Initialized
INFO - 2022-05-11 04:04:54 --> Language Class Initialized
INFO - 2022-05-11 04:04:54 --> Config Class Initialized
INFO - 2022-05-11 04:04:54 --> Loader Class Initialized
INFO - 2022-05-11 04:04:54 --> Helper loaded: url_helper
INFO - 2022-05-11 04:04:54 --> Database Driver Class Initialized
INFO - 2022-05-11 04:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:04:54 --> Controller Class Initialized
DEBUG - 2022-05-11 04:04:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:04:54 --> Model Class Initialized
DEBUG - 2022-05-11 04:04:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:04:54 --> Model Class Initialized
INFO - 2022-05-11 04:04:54 --> Upload Class Initialized
INFO - 2022-05-11 04:04:54 --> Config Class Initialized
INFO - 2022-05-11 04:04:54 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:04:54 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:04:54 --> Utf8 Class Initialized
INFO - 2022-05-11 04:04:54 --> URI Class Initialized
INFO - 2022-05-11 04:04:54 --> Router Class Initialized
INFO - 2022-05-11 04:04:54 --> Output Class Initialized
INFO - 2022-05-11 04:04:54 --> Security Class Initialized
DEBUG - 2022-05-11 04:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:04:54 --> Input Class Initialized
INFO - 2022-05-11 04:04:54 --> Language Class Initialized
INFO - 2022-05-11 04:04:54 --> Language Class Initialized
INFO - 2022-05-11 04:04:54 --> Config Class Initialized
INFO - 2022-05-11 04:04:54 --> Loader Class Initialized
INFO - 2022-05-11 04:04:54 --> Helper loaded: url_helper
INFO - 2022-05-11 04:04:54 --> Database Driver Class Initialized
INFO - 2022-05-11 04:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:04:54 --> Controller Class Initialized
DEBUG - 2022-05-11 04:04:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:04:54 --> Model Class Initialized
DEBUG - 2022-05-11 04:04:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:04:54 --> Model Class Initialized
DEBUG - 2022-05-11 04:04:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:04:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:04:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:04:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:04:54 --> Final output sent to browser
DEBUG - 2022-05-11 04:04:54 --> Total execution time: 0.1022
INFO - 2022-05-11 04:06:35 --> Config Class Initialized
INFO - 2022-05-11 04:06:35 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:06:35 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:06:35 --> Utf8 Class Initialized
INFO - 2022-05-11 04:06:35 --> URI Class Initialized
INFO - 2022-05-11 04:06:35 --> Router Class Initialized
INFO - 2022-05-11 04:06:35 --> Output Class Initialized
INFO - 2022-05-11 04:06:35 --> Security Class Initialized
DEBUG - 2022-05-11 04:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:06:35 --> Input Class Initialized
INFO - 2022-05-11 04:06:35 --> Language Class Initialized
INFO - 2022-05-11 04:06:35 --> Language Class Initialized
INFO - 2022-05-11 04:06:35 --> Config Class Initialized
INFO - 2022-05-11 04:06:35 --> Loader Class Initialized
INFO - 2022-05-11 04:06:35 --> Helper loaded: url_helper
INFO - 2022-05-11 04:06:35 --> Database Driver Class Initialized
INFO - 2022-05-11 04:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:06:35 --> Controller Class Initialized
DEBUG - 2022-05-11 04:06:35 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:06:35 --> Model Class Initialized
DEBUG - 2022-05-11 04:06:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:06:35 --> Model Class Initialized
INFO - 2022-05-11 04:06:35 --> Final output sent to browser
DEBUG - 2022-05-11 04:06:35 --> Total execution time: 0.0524
INFO - 2022-05-11 04:07:37 --> Config Class Initialized
INFO - 2022-05-11 04:07:37 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:07:37 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:07:37 --> Utf8 Class Initialized
INFO - 2022-05-11 04:07:37 --> URI Class Initialized
INFO - 2022-05-11 04:07:37 --> Router Class Initialized
INFO - 2022-05-11 04:07:37 --> Output Class Initialized
INFO - 2022-05-11 04:07:37 --> Security Class Initialized
DEBUG - 2022-05-11 04:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:07:37 --> Input Class Initialized
INFO - 2022-05-11 04:07:37 --> Language Class Initialized
INFO - 2022-05-11 04:07:37 --> Language Class Initialized
INFO - 2022-05-11 04:07:37 --> Config Class Initialized
INFO - 2022-05-11 04:07:37 --> Loader Class Initialized
INFO - 2022-05-11 04:07:37 --> Helper loaded: url_helper
INFO - 2022-05-11 04:07:37 --> Database Driver Class Initialized
INFO - 2022-05-11 04:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:07:37 --> Controller Class Initialized
DEBUG - 2022-05-11 04:07:37 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:07:37 --> Model Class Initialized
DEBUG - 2022-05-11 04:07:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:07:37 --> Model Class Initialized
INFO - 2022-05-11 04:07:37 --> Upload Class Initialized
INFO - 2022-05-11 04:07:37 --> Config Class Initialized
INFO - 2022-05-11 04:07:37 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:07:37 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:07:37 --> Utf8 Class Initialized
INFO - 2022-05-11 04:07:37 --> URI Class Initialized
INFO - 2022-05-11 04:07:37 --> Router Class Initialized
INFO - 2022-05-11 04:07:37 --> Output Class Initialized
INFO - 2022-05-11 04:07:37 --> Security Class Initialized
DEBUG - 2022-05-11 04:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:07:37 --> Input Class Initialized
INFO - 2022-05-11 04:07:37 --> Language Class Initialized
INFO - 2022-05-11 04:07:37 --> Language Class Initialized
INFO - 2022-05-11 04:07:37 --> Config Class Initialized
INFO - 2022-05-11 04:07:37 --> Loader Class Initialized
INFO - 2022-05-11 04:07:37 --> Helper loaded: url_helper
INFO - 2022-05-11 04:07:37 --> Database Driver Class Initialized
INFO - 2022-05-11 04:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:07:37 --> Controller Class Initialized
DEBUG - 2022-05-11 04:07:37 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:07:37 --> Model Class Initialized
DEBUG - 2022-05-11 04:07:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:07:37 --> Model Class Initialized
DEBUG - 2022-05-11 04:07:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:07:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:07:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:07:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:07:37 --> Final output sent to browser
DEBUG - 2022-05-11 04:07:37 --> Total execution time: 0.0728
INFO - 2022-05-11 04:13:50 --> Config Class Initialized
INFO - 2022-05-11 04:13:50 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:13:50 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:13:50 --> Utf8 Class Initialized
INFO - 2022-05-11 04:13:50 --> URI Class Initialized
INFO - 2022-05-11 04:13:50 --> Router Class Initialized
INFO - 2022-05-11 04:13:50 --> Output Class Initialized
INFO - 2022-05-11 04:13:50 --> Security Class Initialized
DEBUG - 2022-05-11 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:13:50 --> Input Class Initialized
INFO - 2022-05-11 04:13:50 --> Language Class Initialized
INFO - 2022-05-11 04:13:50 --> Language Class Initialized
INFO - 2022-05-11 04:13:50 --> Config Class Initialized
INFO - 2022-05-11 04:13:50 --> Loader Class Initialized
INFO - 2022-05-11 04:13:50 --> Helper loaded: url_helper
INFO - 2022-05-11 04:13:50 --> Database Driver Class Initialized
INFO - 2022-05-11 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:13:50 --> Controller Class Initialized
DEBUG - 2022-05-11 04:13:50 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:13:50 --> Model Class Initialized
DEBUG - 2022-05-11 04:13:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:13:50 --> Model Class Initialized
DEBUG - 2022-05-11 04:13:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:13:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:13:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:13:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:13:50 --> Final output sent to browser
DEBUG - 2022-05-11 04:13:50 --> Total execution time: 0.0430
INFO - 2022-05-11 04:13:58 --> Config Class Initialized
INFO - 2022-05-11 04:13:58 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:13:58 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:13:58 --> Utf8 Class Initialized
INFO - 2022-05-11 04:13:58 --> URI Class Initialized
INFO - 2022-05-11 04:13:58 --> Router Class Initialized
INFO - 2022-05-11 04:13:58 --> Output Class Initialized
INFO - 2022-05-11 04:13:58 --> Security Class Initialized
DEBUG - 2022-05-11 04:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:13:58 --> Input Class Initialized
INFO - 2022-05-11 04:13:58 --> Language Class Initialized
INFO - 2022-05-11 04:13:58 --> Language Class Initialized
INFO - 2022-05-11 04:13:58 --> Config Class Initialized
INFO - 2022-05-11 04:13:58 --> Loader Class Initialized
INFO - 2022-05-11 04:13:58 --> Helper loaded: url_helper
INFO - 2022-05-11 04:13:58 --> Database Driver Class Initialized
INFO - 2022-05-11 04:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:13:58 --> Controller Class Initialized
DEBUG - 2022-05-11 04:13:58 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:13:58 --> Model Class Initialized
DEBUG - 2022-05-11 04:13:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:13:58 --> Model Class Initialized
INFO - 2022-05-11 04:13:58 --> Final output sent to browser
DEBUG - 2022-05-11 04:13:58 --> Total execution time: 0.0452
INFO - 2022-05-11 04:14:27 --> Config Class Initialized
INFO - 2022-05-11 04:14:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:14:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:14:27 --> Utf8 Class Initialized
INFO - 2022-05-11 04:14:27 --> URI Class Initialized
INFO - 2022-05-11 04:14:27 --> Router Class Initialized
INFO - 2022-05-11 04:14:27 --> Output Class Initialized
INFO - 2022-05-11 04:14:27 --> Security Class Initialized
DEBUG - 2022-05-11 04:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:14:27 --> Input Class Initialized
INFO - 2022-05-11 04:14:27 --> Language Class Initialized
INFO - 2022-05-11 04:14:27 --> Language Class Initialized
INFO - 2022-05-11 04:14:27 --> Config Class Initialized
INFO - 2022-05-11 04:14:27 --> Loader Class Initialized
INFO - 2022-05-11 04:14:27 --> Helper loaded: url_helper
INFO - 2022-05-11 04:14:28 --> Database Driver Class Initialized
INFO - 2022-05-11 04:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:14:28 --> Controller Class Initialized
DEBUG - 2022-05-11 04:14:28 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:14:28 --> Model Class Initialized
DEBUG - 2022-05-11 04:14:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:14:28 --> Model Class Initialized
INFO - 2022-05-11 04:14:28 --> Upload Class Initialized
DEBUG - 2022-05-11 04:14:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:14:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:14:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:14:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:14:28 --> Final output sent to browser
DEBUG - 2022-05-11 04:14:28 --> Total execution time: 0.1687
INFO - 2022-05-11 04:36:13 --> Config Class Initialized
INFO - 2022-05-11 04:36:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:36:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:36:13 --> Utf8 Class Initialized
INFO - 2022-05-11 04:36:13 --> URI Class Initialized
INFO - 2022-05-11 04:36:13 --> Router Class Initialized
INFO - 2022-05-11 04:36:13 --> Output Class Initialized
INFO - 2022-05-11 04:36:13 --> Security Class Initialized
DEBUG - 2022-05-11 04:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:36:13 --> Input Class Initialized
INFO - 2022-05-11 04:36:13 --> Language Class Initialized
INFO - 2022-05-11 04:36:13 --> Language Class Initialized
INFO - 2022-05-11 04:36:13 --> Config Class Initialized
INFO - 2022-05-11 04:36:13 --> Loader Class Initialized
INFO - 2022-05-11 04:36:13 --> Helper loaded: url_helper
INFO - 2022-05-11 04:36:13 --> Database Driver Class Initialized
INFO - 2022-05-11 04:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:36:13 --> Controller Class Initialized
DEBUG - 2022-05-11 04:36:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:36:13 --> Model Class Initialized
DEBUG - 2022-05-11 04:36:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:36:13 --> Model Class Initialized
INFO - 2022-05-11 04:36:13 --> Final output sent to browser
DEBUG - 2022-05-11 04:36:13 --> Total execution time: 0.0463
INFO - 2022-05-11 04:37:20 --> Config Class Initialized
INFO - 2022-05-11 04:37:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:37:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:37:20 --> Utf8 Class Initialized
INFO - 2022-05-11 04:37:20 --> URI Class Initialized
INFO - 2022-05-11 04:37:20 --> Router Class Initialized
INFO - 2022-05-11 04:37:20 --> Output Class Initialized
INFO - 2022-05-11 04:37:20 --> Security Class Initialized
DEBUG - 2022-05-11 04:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:37:20 --> Input Class Initialized
INFO - 2022-05-11 04:37:20 --> Language Class Initialized
INFO - 2022-05-11 04:37:20 --> Language Class Initialized
INFO - 2022-05-11 04:37:20 --> Config Class Initialized
INFO - 2022-05-11 04:37:20 --> Loader Class Initialized
INFO - 2022-05-11 04:37:20 --> Helper loaded: url_helper
INFO - 2022-05-11 04:37:20 --> Database Driver Class Initialized
INFO - 2022-05-11 04:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:37:20 --> Controller Class Initialized
DEBUG - 2022-05-11 04:37:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:37:20 --> Model Class Initialized
DEBUG - 2022-05-11 04:37:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:37:20 --> Model Class Initialized
INFO - 2022-05-11 04:37:20 --> Upload Class Initialized
INFO - 2022-05-11 04:37:20 --> Config Class Initialized
INFO - 2022-05-11 04:37:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:37:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:37:20 --> Utf8 Class Initialized
INFO - 2022-05-11 04:37:20 --> URI Class Initialized
INFO - 2022-05-11 04:37:20 --> Router Class Initialized
INFO - 2022-05-11 04:37:20 --> Output Class Initialized
INFO - 2022-05-11 04:37:21 --> Security Class Initialized
DEBUG - 2022-05-11 04:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:37:21 --> Input Class Initialized
INFO - 2022-05-11 04:37:21 --> Language Class Initialized
INFO - 2022-05-11 04:37:21 --> Language Class Initialized
INFO - 2022-05-11 04:37:21 --> Config Class Initialized
INFO - 2022-05-11 04:37:21 --> Loader Class Initialized
INFO - 2022-05-11 04:37:21 --> Helper loaded: url_helper
INFO - 2022-05-11 04:37:21 --> Database Driver Class Initialized
INFO - 2022-05-11 04:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:37:21 --> Controller Class Initialized
DEBUG - 2022-05-11 04:37:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:37:21 --> Model Class Initialized
DEBUG - 2022-05-11 04:37:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:37:21 --> Model Class Initialized
DEBUG - 2022-05-11 04:37:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:37:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:37:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:37:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:37:21 --> Final output sent to browser
DEBUG - 2022-05-11 04:37:21 --> Total execution time: 0.0825
INFO - 2022-05-11 04:43:02 --> Config Class Initialized
INFO - 2022-05-11 04:43:02 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:43:02 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:43:02 --> Utf8 Class Initialized
INFO - 2022-05-11 04:43:02 --> URI Class Initialized
INFO - 2022-05-11 04:43:02 --> Router Class Initialized
INFO - 2022-05-11 04:43:02 --> Output Class Initialized
INFO - 2022-05-11 04:43:02 --> Security Class Initialized
DEBUG - 2022-05-11 04:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:43:02 --> Input Class Initialized
INFO - 2022-05-11 04:43:02 --> Language Class Initialized
INFO - 2022-05-11 04:43:02 --> Language Class Initialized
INFO - 2022-05-11 04:43:02 --> Config Class Initialized
INFO - 2022-05-11 04:43:02 --> Loader Class Initialized
INFO - 2022-05-11 04:43:02 --> Helper loaded: url_helper
INFO - 2022-05-11 04:43:02 --> Database Driver Class Initialized
INFO - 2022-05-11 04:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:43:02 --> Controller Class Initialized
DEBUG - 2022-05-11 04:43:02 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:43:02 --> Model Class Initialized
DEBUG - 2022-05-11 04:43:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:43:02 --> Model Class Initialized
DEBUG - 2022-05-11 04:43:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:43:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:43:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:43:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:43:02 --> Final output sent to browser
DEBUG - 2022-05-11 04:43:02 --> Total execution time: 0.0608
INFO - 2022-05-11 04:43:28 --> Config Class Initialized
INFO - 2022-05-11 04:43:28 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:43:28 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:43:28 --> Utf8 Class Initialized
INFO - 2022-05-11 04:43:28 --> URI Class Initialized
INFO - 2022-05-11 04:43:28 --> Router Class Initialized
INFO - 2022-05-11 04:43:28 --> Output Class Initialized
INFO - 2022-05-11 04:43:28 --> Security Class Initialized
DEBUG - 2022-05-11 04:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:43:28 --> Input Class Initialized
INFO - 2022-05-11 04:43:28 --> Language Class Initialized
INFO - 2022-05-11 04:43:28 --> Language Class Initialized
INFO - 2022-05-11 04:43:28 --> Config Class Initialized
INFO - 2022-05-11 04:43:28 --> Loader Class Initialized
INFO - 2022-05-11 04:43:28 --> Helper loaded: url_helper
INFO - 2022-05-11 04:43:28 --> Database Driver Class Initialized
INFO - 2022-05-11 04:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:43:28 --> Controller Class Initialized
DEBUG - 2022-05-11 04:43:28 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:43:28 --> Model Class Initialized
DEBUG - 2022-05-11 04:43:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:43:28 --> Model Class Initialized
INFO - 2022-05-11 04:43:28 --> Final output sent to browser
DEBUG - 2022-05-11 04:43:28 --> Total execution time: 0.0690
INFO - 2022-05-11 04:45:11 --> Config Class Initialized
INFO - 2022-05-11 04:45:11 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:45:11 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:45:11 --> Utf8 Class Initialized
INFO - 2022-05-11 04:45:11 --> URI Class Initialized
INFO - 2022-05-11 04:45:11 --> Router Class Initialized
INFO - 2022-05-11 04:45:11 --> Output Class Initialized
INFO - 2022-05-11 04:45:11 --> Security Class Initialized
DEBUG - 2022-05-11 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:45:11 --> Input Class Initialized
INFO - 2022-05-11 04:45:11 --> Language Class Initialized
INFO - 2022-05-11 04:45:11 --> Language Class Initialized
INFO - 2022-05-11 04:45:11 --> Config Class Initialized
INFO - 2022-05-11 04:45:11 --> Loader Class Initialized
INFO - 2022-05-11 04:45:11 --> Helper loaded: url_helper
INFO - 2022-05-11 04:45:11 --> Database Driver Class Initialized
INFO - 2022-05-11 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:45:11 --> Controller Class Initialized
DEBUG - 2022-05-11 04:45:11 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:45:11 --> Model Class Initialized
DEBUG - 2022-05-11 04:45:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:45:11 --> Model Class Initialized
INFO - 2022-05-11 04:45:11 --> Upload Class Initialized
INFO - 2022-05-11 04:45:11 --> Config Class Initialized
INFO - 2022-05-11 04:45:11 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:45:11 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:45:11 --> Utf8 Class Initialized
INFO - 2022-05-11 04:45:11 --> URI Class Initialized
INFO - 2022-05-11 04:45:11 --> Router Class Initialized
INFO - 2022-05-11 04:45:11 --> Output Class Initialized
INFO - 2022-05-11 04:45:11 --> Security Class Initialized
DEBUG - 2022-05-11 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:45:11 --> Input Class Initialized
INFO - 2022-05-11 04:45:11 --> Language Class Initialized
INFO - 2022-05-11 04:45:11 --> Language Class Initialized
INFO - 2022-05-11 04:45:11 --> Config Class Initialized
INFO - 2022-05-11 04:45:11 --> Loader Class Initialized
INFO - 2022-05-11 04:45:11 --> Helper loaded: url_helper
INFO - 2022-05-11 04:45:11 --> Database Driver Class Initialized
INFO - 2022-05-11 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:45:11 --> Controller Class Initialized
DEBUG - 2022-05-11 04:45:11 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:45:11 --> Model Class Initialized
DEBUG - 2022-05-11 04:45:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:45:11 --> Model Class Initialized
DEBUG - 2022-05-11 04:45:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:45:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:45:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:45:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:45:11 --> Final output sent to browser
DEBUG - 2022-05-11 04:45:11 --> Total execution time: 0.0801
INFO - 2022-05-11 04:46:26 --> Config Class Initialized
INFO - 2022-05-11 04:46:26 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:46:26 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:46:26 --> Utf8 Class Initialized
INFO - 2022-05-11 04:46:26 --> URI Class Initialized
INFO - 2022-05-11 04:46:26 --> Router Class Initialized
INFO - 2022-05-11 04:46:26 --> Output Class Initialized
INFO - 2022-05-11 04:46:26 --> Security Class Initialized
DEBUG - 2022-05-11 04:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:46:26 --> Input Class Initialized
INFO - 2022-05-11 04:46:26 --> Language Class Initialized
INFO - 2022-05-11 04:46:26 --> Language Class Initialized
INFO - 2022-05-11 04:46:26 --> Config Class Initialized
INFO - 2022-05-11 04:46:26 --> Loader Class Initialized
INFO - 2022-05-11 04:46:26 --> Helper loaded: url_helper
INFO - 2022-05-11 04:46:26 --> Database Driver Class Initialized
INFO - 2022-05-11 04:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:46:26 --> Controller Class Initialized
DEBUG - 2022-05-11 04:46:26 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:46:26 --> Model Class Initialized
DEBUG - 2022-05-11 04:46:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:46:26 --> Model Class Initialized
INFO - 2022-05-11 04:46:26 --> Final output sent to browser
DEBUG - 2022-05-11 04:46:26 --> Total execution time: 0.0448
INFO - 2022-05-11 04:47:02 --> Config Class Initialized
INFO - 2022-05-11 04:47:02 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:47:02 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:47:02 --> Utf8 Class Initialized
INFO - 2022-05-11 04:47:02 --> URI Class Initialized
INFO - 2022-05-11 04:47:02 --> Router Class Initialized
INFO - 2022-05-11 04:47:02 --> Output Class Initialized
INFO - 2022-05-11 04:47:02 --> Security Class Initialized
DEBUG - 2022-05-11 04:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:47:02 --> Input Class Initialized
INFO - 2022-05-11 04:47:02 --> Language Class Initialized
INFO - 2022-05-11 04:47:02 --> Language Class Initialized
INFO - 2022-05-11 04:47:02 --> Config Class Initialized
INFO - 2022-05-11 04:47:02 --> Loader Class Initialized
INFO - 2022-05-11 04:47:02 --> Helper loaded: url_helper
INFO - 2022-05-11 04:47:02 --> Database Driver Class Initialized
INFO - 2022-05-11 04:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:47:02 --> Controller Class Initialized
DEBUG - 2022-05-11 04:47:02 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:47:02 --> Model Class Initialized
DEBUG - 2022-05-11 04:47:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:47:02 --> Model Class Initialized
INFO - 2022-05-11 04:47:02 --> Upload Class Initialized
INFO - 2022-05-11 04:47:03 --> Config Class Initialized
INFO - 2022-05-11 04:47:03 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:47:03 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:47:03 --> Utf8 Class Initialized
INFO - 2022-05-11 04:47:03 --> URI Class Initialized
INFO - 2022-05-11 04:47:03 --> Router Class Initialized
INFO - 2022-05-11 04:47:03 --> Output Class Initialized
INFO - 2022-05-11 04:47:03 --> Security Class Initialized
DEBUG - 2022-05-11 04:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:47:03 --> Input Class Initialized
INFO - 2022-05-11 04:47:03 --> Language Class Initialized
INFO - 2022-05-11 04:47:03 --> Language Class Initialized
INFO - 2022-05-11 04:47:03 --> Config Class Initialized
INFO - 2022-05-11 04:47:03 --> Loader Class Initialized
INFO - 2022-05-11 04:47:03 --> Helper loaded: url_helper
INFO - 2022-05-11 04:47:03 --> Database Driver Class Initialized
INFO - 2022-05-11 04:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:47:03 --> Controller Class Initialized
DEBUG - 2022-05-11 04:47:03 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:47:03 --> Model Class Initialized
DEBUG - 2022-05-11 04:47:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:47:03 --> Model Class Initialized
DEBUG - 2022-05-11 04:47:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:47:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:47:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:47:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:47:03 --> Final output sent to browser
DEBUG - 2022-05-11 04:47:03 --> Total execution time: 0.0626
INFO - 2022-05-11 04:51:10 --> Config Class Initialized
INFO - 2022-05-11 04:51:10 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:10 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:10 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:10 --> URI Class Initialized
INFO - 2022-05-11 04:51:10 --> Router Class Initialized
INFO - 2022-05-11 04:51:10 --> Output Class Initialized
INFO - 2022-05-11 04:51:10 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:10 --> Input Class Initialized
INFO - 2022-05-11 04:51:10 --> Language Class Initialized
INFO - 2022-05-11 04:51:10 --> Language Class Initialized
INFO - 2022-05-11 04:51:10 --> Config Class Initialized
INFO - 2022-05-11 04:51:10 --> Loader Class Initialized
INFO - 2022-05-11 04:51:10 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:10 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:10 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:10 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:10 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:10 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:51:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:51:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 04:51:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:51:10 --> Final output sent to browser
DEBUG - 2022-05-11 04:51:10 --> Total execution time: 0.0906
INFO - 2022-05-11 04:51:16 --> Config Class Initialized
INFO - 2022-05-11 04:51:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:16 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:16 --> URI Class Initialized
INFO - 2022-05-11 04:51:16 --> Router Class Initialized
INFO - 2022-05-11 04:51:16 --> Output Class Initialized
INFO - 2022-05-11 04:51:16 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:16 --> Input Class Initialized
INFO - 2022-05-11 04:51:16 --> Language Class Initialized
INFO - 2022-05-11 04:51:16 --> Language Class Initialized
INFO - 2022-05-11 04:51:16 --> Config Class Initialized
INFO - 2022-05-11 04:51:16 --> Loader Class Initialized
INFO - 2022-05-11 04:51:16 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:16 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:16 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:16 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:16 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:16 --> Model Class Initialized
INFO - 2022-05-11 04:51:16 --> Config Class Initialized
INFO - 2022-05-11 04:51:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:16 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:16 --> URI Class Initialized
INFO - 2022-05-11 04:51:16 --> Router Class Initialized
INFO - 2022-05-11 04:51:16 --> Output Class Initialized
INFO - 2022-05-11 04:51:16 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:16 --> Input Class Initialized
INFO - 2022-05-11 04:51:16 --> Language Class Initialized
INFO - 2022-05-11 04:51:16 --> Language Class Initialized
INFO - 2022-05-11 04:51:16 --> Config Class Initialized
INFO - 2022-05-11 04:51:16 --> Loader Class Initialized
INFO - 2022-05-11 04:51:16 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:16 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:16 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:16 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:16 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:16 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:51:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:51:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 04:51:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:51:16 --> Final output sent to browser
DEBUG - 2022-05-11 04:51:16 --> Total execution time: 0.0878
INFO - 2022-05-11 04:51:19 --> Config Class Initialized
INFO - 2022-05-11 04:51:19 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:19 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:19 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:19 --> URI Class Initialized
INFO - 2022-05-11 04:51:19 --> Router Class Initialized
INFO - 2022-05-11 04:51:19 --> Output Class Initialized
INFO - 2022-05-11 04:51:19 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:19 --> Input Class Initialized
INFO - 2022-05-11 04:51:19 --> Language Class Initialized
INFO - 2022-05-11 04:51:19 --> Language Class Initialized
INFO - 2022-05-11 04:51:19 --> Config Class Initialized
INFO - 2022-05-11 04:51:19 --> Loader Class Initialized
INFO - 2022-05-11 04:51:19 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:19 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:19 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:19 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:19 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:19 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:51:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:51:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 04:51:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:51:19 --> Final output sent to browser
DEBUG - 2022-05-11 04:51:19 --> Total execution time: 0.1022
INFO - 2022-05-11 04:51:43 --> Config Class Initialized
INFO - 2022-05-11 04:51:43 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:43 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:43 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:43 --> URI Class Initialized
INFO - 2022-05-11 04:51:43 --> Router Class Initialized
INFO - 2022-05-11 04:51:43 --> Output Class Initialized
INFO - 2022-05-11 04:51:43 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:43 --> Input Class Initialized
INFO - 2022-05-11 04:51:43 --> Language Class Initialized
INFO - 2022-05-11 04:51:43 --> Language Class Initialized
INFO - 2022-05-11 04:51:43 --> Config Class Initialized
INFO - 2022-05-11 04:51:43 --> Loader Class Initialized
INFO - 2022-05-11 04:51:43 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:43 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:43 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:43 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:43 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:43 --> Model Class Initialized
INFO - 2022-05-11 04:51:43 --> Upload Class Initialized
INFO - 2022-05-11 04:51:43 --> Config Class Initialized
INFO - 2022-05-11 04:51:43 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:43 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:43 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:43 --> URI Class Initialized
INFO - 2022-05-11 04:51:43 --> Router Class Initialized
INFO - 2022-05-11 04:51:43 --> Output Class Initialized
INFO - 2022-05-11 04:51:43 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:43 --> Input Class Initialized
INFO - 2022-05-11 04:51:43 --> Language Class Initialized
INFO - 2022-05-11 04:51:43 --> Language Class Initialized
INFO - 2022-05-11 04:51:43 --> Config Class Initialized
INFO - 2022-05-11 04:51:43 --> Loader Class Initialized
INFO - 2022-05-11 04:51:43 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:43 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:43 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:43 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:43 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:43 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:51:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:51:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 04:51:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:51:43 --> Final output sent to browser
DEBUG - 2022-05-11 04:51:43 --> Total execution time: 0.0816
INFO - 2022-05-11 04:51:46 --> Config Class Initialized
INFO - 2022-05-11 04:51:46 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:51:46 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:51:46 --> Utf8 Class Initialized
INFO - 2022-05-11 04:51:46 --> URI Class Initialized
INFO - 2022-05-11 04:51:46 --> Router Class Initialized
INFO - 2022-05-11 04:51:46 --> Output Class Initialized
INFO - 2022-05-11 04:51:46 --> Security Class Initialized
DEBUG - 2022-05-11 04:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:51:46 --> Input Class Initialized
INFO - 2022-05-11 04:51:46 --> Language Class Initialized
INFO - 2022-05-11 04:51:46 --> Language Class Initialized
INFO - 2022-05-11 04:51:46 --> Config Class Initialized
INFO - 2022-05-11 04:51:46 --> Loader Class Initialized
INFO - 2022-05-11 04:51:46 --> Helper loaded: url_helper
INFO - 2022-05-11 04:51:46 --> Database Driver Class Initialized
INFO - 2022-05-11 04:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:51:46 --> Controller Class Initialized
DEBUG - 2022-05-11 04:51:46 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:51:46 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:51:46 --> Model Class Initialized
DEBUG - 2022-05-11 04:51:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:51:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:51:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 04:51:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:51:46 --> Final output sent to browser
DEBUG - 2022-05-11 04:51:46 --> Total execution time: 0.0741
INFO - 2022-05-11 04:52:03 --> Config Class Initialized
INFO - 2022-05-11 04:52:03 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:03 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:03 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:03 --> URI Class Initialized
INFO - 2022-05-11 04:52:03 --> Router Class Initialized
INFO - 2022-05-11 04:52:03 --> Output Class Initialized
INFO - 2022-05-11 04:52:03 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:03 --> Input Class Initialized
INFO - 2022-05-11 04:52:03 --> Language Class Initialized
INFO - 2022-05-11 04:52:04 --> Language Class Initialized
INFO - 2022-05-11 04:52:04 --> Config Class Initialized
INFO - 2022-05-11 04:52:04 --> Loader Class Initialized
INFO - 2022-05-11 04:52:04 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:04 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:04 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:04 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:04 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:04 --> Model Class Initialized
INFO - 2022-05-11 04:52:04 --> Config Class Initialized
INFO - 2022-05-11 04:52:04 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:04 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:04 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:04 --> URI Class Initialized
INFO - 2022-05-11 04:52:04 --> Router Class Initialized
INFO - 2022-05-11 04:52:04 --> Output Class Initialized
INFO - 2022-05-11 04:52:04 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:04 --> Input Class Initialized
INFO - 2022-05-11 04:52:04 --> Language Class Initialized
INFO - 2022-05-11 04:52:04 --> Language Class Initialized
INFO - 2022-05-11 04:52:04 --> Config Class Initialized
INFO - 2022-05-11 04:52:04 --> Loader Class Initialized
INFO - 2022-05-11 04:52:04 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:04 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:04 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:04 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:04 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:04 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:52:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:52:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 04:52:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:52:04 --> Final output sent to browser
DEBUG - 2022-05-11 04:52:04 --> Total execution time: 0.0841
INFO - 2022-05-11 04:52:11 --> Config Class Initialized
INFO - 2022-05-11 04:52:11 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:11 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:11 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:11 --> URI Class Initialized
INFO - 2022-05-11 04:52:11 --> Router Class Initialized
INFO - 2022-05-11 04:52:11 --> Output Class Initialized
INFO - 2022-05-11 04:52:11 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:11 --> Input Class Initialized
INFO - 2022-05-11 04:52:11 --> Language Class Initialized
INFO - 2022-05-11 04:52:11 --> Language Class Initialized
INFO - 2022-05-11 04:52:11 --> Config Class Initialized
INFO - 2022-05-11 04:52:11 --> Loader Class Initialized
INFO - 2022-05-11 04:52:11 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:11 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:11 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:11 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:11 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:11 --> Model Class Initialized
INFO - 2022-05-11 04:52:11 --> Config Class Initialized
INFO - 2022-05-11 04:52:11 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:11 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:11 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:11 --> URI Class Initialized
INFO - 2022-05-11 04:52:11 --> Router Class Initialized
INFO - 2022-05-11 04:52:11 --> Output Class Initialized
INFO - 2022-05-11 04:52:11 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:11 --> Input Class Initialized
INFO - 2022-05-11 04:52:11 --> Language Class Initialized
INFO - 2022-05-11 04:52:11 --> Language Class Initialized
INFO - 2022-05-11 04:52:11 --> Config Class Initialized
INFO - 2022-05-11 04:52:11 --> Loader Class Initialized
INFO - 2022-05-11 04:52:11 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:11 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:11 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:11 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:11 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:11 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 04:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:52:11 --> Final output sent to browser
DEBUG - 2022-05-11 04:52:11 --> Total execution time: 0.0871
INFO - 2022-05-11 04:52:20 --> Config Class Initialized
INFO - 2022-05-11 04:52:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:20 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:20 --> URI Class Initialized
INFO - 2022-05-11 04:52:20 --> Router Class Initialized
INFO - 2022-05-11 04:52:20 --> Output Class Initialized
INFO - 2022-05-11 04:52:20 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:20 --> Input Class Initialized
INFO - 2022-05-11 04:52:20 --> Language Class Initialized
INFO - 2022-05-11 04:52:20 --> Language Class Initialized
INFO - 2022-05-11 04:52:20 --> Config Class Initialized
INFO - 2022-05-11 04:52:20 --> Loader Class Initialized
INFO - 2022-05-11 04:52:20 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:20 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:20 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:20 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:20 --> Model Class Initialized
INFO - 2022-05-11 04:52:21 --> Config Class Initialized
INFO - 2022-05-11 04:52:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:21 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:21 --> URI Class Initialized
INFO - 2022-05-11 04:52:21 --> Router Class Initialized
INFO - 2022-05-11 04:52:21 --> Output Class Initialized
INFO - 2022-05-11 04:52:21 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:21 --> Input Class Initialized
INFO - 2022-05-11 04:52:21 --> Language Class Initialized
INFO - 2022-05-11 04:52:21 --> Language Class Initialized
INFO - 2022-05-11 04:52:21 --> Config Class Initialized
INFO - 2022-05-11 04:52:21 --> Loader Class Initialized
INFO - 2022-05-11 04:52:21 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:21 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:21 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:21 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:21 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:52:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:52:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 04:52:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:52:21 --> Final output sent to browser
DEBUG - 2022-05-11 04:52:21 --> Total execution time: 0.1123
INFO - 2022-05-11 04:52:23 --> Config Class Initialized
INFO - 2022-05-11 04:52:23 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:23 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:23 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:23 --> URI Class Initialized
INFO - 2022-05-11 04:52:23 --> Router Class Initialized
INFO - 2022-05-11 04:52:23 --> Output Class Initialized
INFO - 2022-05-11 04:52:23 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:23 --> Input Class Initialized
INFO - 2022-05-11 04:52:23 --> Language Class Initialized
INFO - 2022-05-11 04:52:23 --> Language Class Initialized
INFO - 2022-05-11 04:52:23 --> Config Class Initialized
INFO - 2022-05-11 04:52:23 --> Loader Class Initialized
INFO - 2022-05-11 04:52:23 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:23 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:23 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:23 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:23 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:23 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:52:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:52:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 04:52:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:52:23 --> Final output sent to browser
DEBUG - 2022-05-11 04:52:23 --> Total execution time: 0.0790
INFO - 2022-05-11 04:52:30 --> Config Class Initialized
INFO - 2022-05-11 04:52:30 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:30 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:30 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:30 --> URI Class Initialized
INFO - 2022-05-11 04:52:30 --> Router Class Initialized
INFO - 2022-05-11 04:52:30 --> Output Class Initialized
INFO - 2022-05-11 04:52:30 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:30 --> Input Class Initialized
INFO - 2022-05-11 04:52:30 --> Language Class Initialized
INFO - 2022-05-11 04:52:30 --> Language Class Initialized
INFO - 2022-05-11 04:52:30 --> Config Class Initialized
INFO - 2022-05-11 04:52:30 --> Loader Class Initialized
INFO - 2022-05-11 04:52:30 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:30 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:30 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:30 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:30 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:30 --> Model Class Initialized
INFO - 2022-05-11 04:52:30 --> Config Class Initialized
INFO - 2022-05-11 04:52:30 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:52:30 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:52:30 --> Utf8 Class Initialized
INFO - 2022-05-11 04:52:30 --> URI Class Initialized
INFO - 2022-05-11 04:52:30 --> Router Class Initialized
INFO - 2022-05-11 04:52:30 --> Output Class Initialized
INFO - 2022-05-11 04:52:30 --> Security Class Initialized
DEBUG - 2022-05-11 04:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:52:30 --> Input Class Initialized
INFO - 2022-05-11 04:52:30 --> Language Class Initialized
INFO - 2022-05-11 04:52:30 --> Language Class Initialized
INFO - 2022-05-11 04:52:30 --> Config Class Initialized
INFO - 2022-05-11 04:52:30 --> Loader Class Initialized
INFO - 2022-05-11 04:52:30 --> Helper loaded: url_helper
INFO - 2022-05-11 04:52:30 --> Database Driver Class Initialized
INFO - 2022-05-11 04:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:52:30 --> Controller Class Initialized
DEBUG - 2022-05-11 04:52:30 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:52:30 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:52:30 --> Model Class Initialized
DEBUG - 2022-05-11 04:52:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:52:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:52:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 04:52:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:52:30 --> Final output sent to browser
DEBUG - 2022-05-11 04:52:30 --> Total execution time: 0.0796
INFO - 2022-05-11 04:53:01 --> Config Class Initialized
INFO - 2022-05-11 04:53:01 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:01 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:01 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:01 --> URI Class Initialized
INFO - 2022-05-11 04:53:01 --> Router Class Initialized
INFO - 2022-05-11 04:53:01 --> Output Class Initialized
INFO - 2022-05-11 04:53:01 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:01 --> Input Class Initialized
INFO - 2022-05-11 04:53:01 --> Language Class Initialized
INFO - 2022-05-11 04:53:01 --> Language Class Initialized
INFO - 2022-05-11 04:53:01 --> Config Class Initialized
INFO - 2022-05-11 04:53:01 --> Loader Class Initialized
INFO - 2022-05-11 04:53:01 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:01 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:01 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:01 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:01 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:01 --> Model Class Initialized
INFO - 2022-05-11 04:53:01 --> Config Class Initialized
INFO - 2022-05-11 04:53:01 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:01 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:01 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:01 --> URI Class Initialized
INFO - 2022-05-11 04:53:01 --> Router Class Initialized
INFO - 2022-05-11 04:53:01 --> Output Class Initialized
INFO - 2022-05-11 04:53:01 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:01 --> Input Class Initialized
INFO - 2022-05-11 04:53:01 --> Language Class Initialized
INFO - 2022-05-11 04:53:01 --> Language Class Initialized
INFO - 2022-05-11 04:53:01 --> Config Class Initialized
INFO - 2022-05-11 04:53:01 --> Loader Class Initialized
INFO - 2022-05-11 04:53:01 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:01 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:01 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:01 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:01 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:01 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:53:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:53:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 04:53:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:53:01 --> Final output sent to browser
DEBUG - 2022-05-11 04:53:01 --> Total execution time: 0.0944
INFO - 2022-05-11 04:53:03 --> Config Class Initialized
INFO - 2022-05-11 04:53:03 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:03 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:03 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:03 --> URI Class Initialized
INFO - 2022-05-11 04:53:03 --> Router Class Initialized
INFO - 2022-05-11 04:53:03 --> Output Class Initialized
INFO - 2022-05-11 04:53:03 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:03 --> Input Class Initialized
INFO - 2022-05-11 04:53:03 --> Language Class Initialized
INFO - 2022-05-11 04:53:03 --> Language Class Initialized
INFO - 2022-05-11 04:53:03 --> Config Class Initialized
INFO - 2022-05-11 04:53:03 --> Loader Class Initialized
INFO - 2022-05-11 04:53:03 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:03 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:03 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:03 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:03 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:03 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:53:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:53:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 04:53:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:53:03 --> Final output sent to browser
DEBUG - 2022-05-11 04:53:03 --> Total execution time: 0.0807
INFO - 2022-05-11 04:53:13 --> Config Class Initialized
INFO - 2022-05-11 04:53:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:13 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:13 --> URI Class Initialized
INFO - 2022-05-11 04:53:13 --> Router Class Initialized
INFO - 2022-05-11 04:53:13 --> Output Class Initialized
INFO - 2022-05-11 04:53:13 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:13 --> Input Class Initialized
INFO - 2022-05-11 04:53:13 --> Language Class Initialized
INFO - 2022-05-11 04:53:13 --> Language Class Initialized
INFO - 2022-05-11 04:53:13 --> Config Class Initialized
INFO - 2022-05-11 04:53:13 --> Loader Class Initialized
INFO - 2022-05-11 04:53:13 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:13 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:13 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:13 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:13 --> Model Class Initialized
INFO - 2022-05-11 04:53:13 --> Config Class Initialized
INFO - 2022-05-11 04:53:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:13 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:13 --> URI Class Initialized
INFO - 2022-05-11 04:53:13 --> Router Class Initialized
INFO - 2022-05-11 04:53:13 --> Output Class Initialized
INFO - 2022-05-11 04:53:13 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:13 --> Input Class Initialized
INFO - 2022-05-11 04:53:13 --> Language Class Initialized
INFO - 2022-05-11 04:53:13 --> Language Class Initialized
INFO - 2022-05-11 04:53:13 --> Config Class Initialized
INFO - 2022-05-11 04:53:13 --> Loader Class Initialized
INFO - 2022-05-11 04:53:13 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:13 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:13 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:13 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:13 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:53:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:53:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 04:53:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:53:13 --> Final output sent to browser
DEBUG - 2022-05-11 04:53:13 --> Total execution time: 0.0733
INFO - 2022-05-11 04:53:15 --> Config Class Initialized
INFO - 2022-05-11 04:53:15 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:15 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:15 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:15 --> URI Class Initialized
INFO - 2022-05-11 04:53:15 --> Router Class Initialized
INFO - 2022-05-11 04:53:15 --> Output Class Initialized
INFO - 2022-05-11 04:53:15 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:15 --> Input Class Initialized
INFO - 2022-05-11 04:53:15 --> Language Class Initialized
INFO - 2022-05-11 04:53:15 --> Language Class Initialized
INFO - 2022-05-11 04:53:15 --> Config Class Initialized
INFO - 2022-05-11 04:53:15 --> Loader Class Initialized
INFO - 2022-05-11 04:53:15 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:15 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:15 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:15 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:15 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:15 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:53:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:53:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 04:53:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:53:15 --> Final output sent to browser
DEBUG - 2022-05-11 04:53:15 --> Total execution time: 0.0643
INFO - 2022-05-11 04:53:16 --> Config Class Initialized
INFO - 2022-05-11 04:53:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:16 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:16 --> URI Class Initialized
INFO - 2022-05-11 04:53:16 --> Router Class Initialized
INFO - 2022-05-11 04:53:16 --> Output Class Initialized
INFO - 2022-05-11 04:53:16 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:16 --> Input Class Initialized
INFO - 2022-05-11 04:53:16 --> Language Class Initialized
INFO - 2022-05-11 04:53:16 --> Language Class Initialized
INFO - 2022-05-11 04:53:16 --> Config Class Initialized
INFO - 2022-05-11 04:53:16 --> Loader Class Initialized
INFO - 2022-05-11 04:53:16 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:16 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:16 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:16 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:16 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:16 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:53:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:53:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:53:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:53:16 --> Final output sent to browser
DEBUG - 2022-05-11 04:53:16 --> Total execution time: 0.0837
INFO - 2022-05-11 04:53:41 --> Config Class Initialized
INFO - 2022-05-11 04:53:41 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:53:41 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:53:41 --> Utf8 Class Initialized
INFO - 2022-05-11 04:53:41 --> URI Class Initialized
INFO - 2022-05-11 04:53:41 --> Router Class Initialized
INFO - 2022-05-11 04:53:41 --> Output Class Initialized
INFO - 2022-05-11 04:53:41 --> Security Class Initialized
DEBUG - 2022-05-11 04:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:53:41 --> Input Class Initialized
INFO - 2022-05-11 04:53:41 --> Language Class Initialized
INFO - 2022-05-11 04:53:41 --> Language Class Initialized
INFO - 2022-05-11 04:53:41 --> Config Class Initialized
INFO - 2022-05-11 04:53:41 --> Loader Class Initialized
INFO - 2022-05-11 04:53:41 --> Helper loaded: url_helper
INFO - 2022-05-11 04:53:41 --> Database Driver Class Initialized
INFO - 2022-05-11 04:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:53:41 --> Controller Class Initialized
DEBUG - 2022-05-11 04:53:41 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:53:41 --> Model Class Initialized
DEBUG - 2022-05-11 04:53:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:53:41 --> Model Class Initialized
INFO - 2022-05-11 04:53:41 --> Final output sent to browser
DEBUG - 2022-05-11 04:53:41 --> Total execution time: 0.0705
INFO - 2022-05-11 04:55:42 --> Config Class Initialized
INFO - 2022-05-11 04:55:42 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:55:42 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:55:42 --> Utf8 Class Initialized
INFO - 2022-05-11 04:55:42 --> URI Class Initialized
INFO - 2022-05-11 04:55:42 --> Router Class Initialized
INFO - 2022-05-11 04:55:42 --> Output Class Initialized
INFO - 2022-05-11 04:55:42 --> Security Class Initialized
DEBUG - 2022-05-11 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:55:42 --> Input Class Initialized
INFO - 2022-05-11 04:55:42 --> Language Class Initialized
INFO - 2022-05-11 04:55:42 --> Language Class Initialized
INFO - 2022-05-11 04:55:42 --> Config Class Initialized
INFO - 2022-05-11 04:55:42 --> Loader Class Initialized
INFO - 2022-05-11 04:55:42 --> Helper loaded: url_helper
INFO - 2022-05-11 04:55:42 --> Database Driver Class Initialized
INFO - 2022-05-11 04:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:55:42 --> Controller Class Initialized
DEBUG - 2022-05-11 04:55:42 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:55:42 --> Model Class Initialized
DEBUG - 2022-05-11 04:55:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:55:42 --> Model Class Initialized
INFO - 2022-05-11 04:55:42 --> Upload Class Initialized
INFO - 2022-05-11 04:55:42 --> Config Class Initialized
INFO - 2022-05-11 04:55:42 --> Hooks Class Initialized
DEBUG - 2022-05-11 04:55:42 --> UTF-8 Support Enabled
INFO - 2022-05-11 04:55:42 --> Utf8 Class Initialized
INFO - 2022-05-11 04:55:42 --> URI Class Initialized
INFO - 2022-05-11 04:55:42 --> Router Class Initialized
INFO - 2022-05-11 04:55:42 --> Output Class Initialized
INFO - 2022-05-11 04:55:42 --> Security Class Initialized
DEBUG - 2022-05-11 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 04:55:42 --> Input Class Initialized
INFO - 2022-05-11 04:55:42 --> Language Class Initialized
INFO - 2022-05-11 04:55:42 --> Language Class Initialized
INFO - 2022-05-11 04:55:42 --> Config Class Initialized
INFO - 2022-05-11 04:55:42 --> Loader Class Initialized
INFO - 2022-05-11 04:55:42 --> Helper loaded: url_helper
INFO - 2022-05-11 04:55:42 --> Database Driver Class Initialized
INFO - 2022-05-11 04:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 04:55:42 --> Controller Class Initialized
DEBUG - 2022-05-11 04:55:42 --> Admin MX_Controller Initialized
INFO - 2022-05-11 04:55:42 --> Model Class Initialized
DEBUG - 2022-05-11 04:55:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 04:55:42 --> Model Class Initialized
DEBUG - 2022-05-11 04:55:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 04:55:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 04:55:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 04:55:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 04:55:42 --> Final output sent to browser
DEBUG - 2022-05-11 04:55:42 --> Total execution time: 0.1021
INFO - 2022-05-11 05:00:14 --> Config Class Initialized
INFO - 2022-05-11 05:00:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 05:00:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 05:00:14 --> Utf8 Class Initialized
INFO - 2022-05-11 05:00:14 --> URI Class Initialized
INFO - 2022-05-11 05:00:14 --> Router Class Initialized
INFO - 2022-05-11 05:00:14 --> Output Class Initialized
INFO - 2022-05-11 05:00:14 --> Security Class Initialized
DEBUG - 2022-05-11 05:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 05:00:14 --> Input Class Initialized
INFO - 2022-05-11 05:00:14 --> Language Class Initialized
INFO - 2022-05-11 05:00:14 --> Language Class Initialized
INFO - 2022-05-11 05:00:14 --> Config Class Initialized
INFO - 2022-05-11 05:00:14 --> Loader Class Initialized
INFO - 2022-05-11 05:00:14 --> Helper loaded: url_helper
INFO - 2022-05-11 05:00:14 --> Database Driver Class Initialized
INFO - 2022-05-11 05:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 05:00:14 --> Controller Class Initialized
DEBUG - 2022-05-11 05:00:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 05:00:14 --> Model Class Initialized
DEBUG - 2022-05-11 05:00:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 05:00:14 --> Model Class Initialized
DEBUG - 2022-05-11 05:00:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 05:00:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 05:00:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 05:00:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 05:00:14 --> Final output sent to browser
DEBUG - 2022-05-11 05:00:14 --> Total execution time: 0.0694
INFO - 2022-05-11 05:00:41 --> Config Class Initialized
INFO - 2022-05-11 05:00:41 --> Hooks Class Initialized
DEBUG - 2022-05-11 05:00:41 --> UTF-8 Support Enabled
INFO - 2022-05-11 05:00:41 --> Utf8 Class Initialized
INFO - 2022-05-11 05:00:41 --> URI Class Initialized
INFO - 2022-05-11 05:00:41 --> Router Class Initialized
INFO - 2022-05-11 05:00:41 --> Output Class Initialized
INFO - 2022-05-11 05:00:41 --> Security Class Initialized
DEBUG - 2022-05-11 05:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 05:00:41 --> Input Class Initialized
INFO - 2022-05-11 05:00:41 --> Language Class Initialized
INFO - 2022-05-11 05:00:41 --> Language Class Initialized
INFO - 2022-05-11 05:00:41 --> Config Class Initialized
INFO - 2022-05-11 05:00:41 --> Loader Class Initialized
INFO - 2022-05-11 05:00:41 --> Helper loaded: url_helper
INFO - 2022-05-11 05:00:41 --> Database Driver Class Initialized
INFO - 2022-05-11 05:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 05:00:41 --> Controller Class Initialized
DEBUG - 2022-05-11 05:00:41 --> Admin MX_Controller Initialized
INFO - 2022-05-11 05:00:41 --> Model Class Initialized
DEBUG - 2022-05-11 05:00:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 05:00:41 --> Model Class Initialized
INFO - 2022-05-11 05:00:41 --> Final output sent to browser
DEBUG - 2022-05-11 05:00:41 --> Total execution time: 0.0882
INFO - 2022-05-11 05:02:27 --> Config Class Initialized
INFO - 2022-05-11 05:02:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 05:02:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 05:02:27 --> Utf8 Class Initialized
INFO - 2022-05-11 05:02:27 --> URI Class Initialized
INFO - 2022-05-11 05:02:27 --> Router Class Initialized
INFO - 2022-05-11 05:02:27 --> Output Class Initialized
INFO - 2022-05-11 05:02:27 --> Security Class Initialized
DEBUG - 2022-05-11 05:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 05:02:27 --> Input Class Initialized
INFO - 2022-05-11 05:02:27 --> Language Class Initialized
INFO - 2022-05-11 05:02:27 --> Language Class Initialized
INFO - 2022-05-11 05:02:27 --> Config Class Initialized
INFO - 2022-05-11 05:02:27 --> Loader Class Initialized
INFO - 2022-05-11 05:02:27 --> Helper loaded: url_helper
INFO - 2022-05-11 05:02:27 --> Database Driver Class Initialized
INFO - 2022-05-11 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 05:02:27 --> Controller Class Initialized
DEBUG - 2022-05-11 05:02:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 05:02:27 --> Model Class Initialized
DEBUG - 2022-05-11 05:02:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 05:02:27 --> Model Class Initialized
INFO - 2022-05-11 05:02:27 --> Upload Class Initialized
INFO - 2022-05-11 05:02:27 --> Config Class Initialized
INFO - 2022-05-11 05:02:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 05:02:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 05:02:27 --> Utf8 Class Initialized
INFO - 2022-05-11 05:02:27 --> URI Class Initialized
INFO - 2022-05-11 05:02:27 --> Router Class Initialized
INFO - 2022-05-11 05:02:27 --> Output Class Initialized
INFO - 2022-05-11 05:02:27 --> Security Class Initialized
DEBUG - 2022-05-11 05:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 05:02:27 --> Input Class Initialized
INFO - 2022-05-11 05:02:27 --> Language Class Initialized
INFO - 2022-05-11 05:02:27 --> Language Class Initialized
INFO - 2022-05-11 05:02:27 --> Config Class Initialized
INFO - 2022-05-11 05:02:27 --> Loader Class Initialized
INFO - 2022-05-11 05:02:27 --> Helper loaded: url_helper
INFO - 2022-05-11 05:02:27 --> Database Driver Class Initialized
INFO - 2022-05-11 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 05:02:27 --> Controller Class Initialized
DEBUG - 2022-05-11 05:02:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 05:02:27 --> Model Class Initialized
DEBUG - 2022-05-11 05:02:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 05:02:27 --> Model Class Initialized
DEBUG - 2022-05-11 05:02:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 05:02:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 05:02:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 05:02:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 05:02:27 --> Final output sent to browser
DEBUG - 2022-05-11 05:02:27 --> Total execution time: 0.0746
INFO - 2022-05-11 09:36:12 --> Config Class Initialized
INFO - 2022-05-11 09:36:12 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:36:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:36:13 --> Utf8 Class Initialized
INFO - 2022-05-11 09:36:13 --> URI Class Initialized
DEBUG - 2022-05-11 09:36:13 --> No URI present. Default controller set.
INFO - 2022-05-11 09:36:13 --> Router Class Initialized
INFO - 2022-05-11 09:36:13 --> Output Class Initialized
INFO - 2022-05-11 09:36:13 --> Security Class Initialized
DEBUG - 2022-05-11 09:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:36:13 --> Input Class Initialized
INFO - 2022-05-11 09:36:13 --> Language Class Initialized
INFO - 2022-05-11 09:36:13 --> Language Class Initialized
INFO - 2022-05-11 09:36:13 --> Config Class Initialized
INFO - 2022-05-11 09:36:13 --> Loader Class Initialized
INFO - 2022-05-11 09:36:13 --> Helper loaded: url_helper
INFO - 2022-05-11 09:36:13 --> Database Driver Class Initialized
ERROR - 2022-05-11 09:36:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'motodeal' C:\xampp\htdocs\motodeal\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2022-05-11 09:36:13 --> Unable to connect to the database
INFO - 2022-05-11 09:36:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:39:33 --> Config Class Initialized
INFO - 2022-05-11 09:39:33 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:39:33 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:39:33 --> Utf8 Class Initialized
INFO - 2022-05-11 09:39:33 --> URI Class Initialized
DEBUG - 2022-05-11 09:39:33 --> No URI present. Default controller set.
INFO - 2022-05-11 09:39:33 --> Router Class Initialized
INFO - 2022-05-11 09:39:33 --> Output Class Initialized
INFO - 2022-05-11 09:39:33 --> Security Class Initialized
DEBUG - 2022-05-11 09:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:39:33 --> Input Class Initialized
INFO - 2022-05-11 09:39:33 --> Language Class Initialized
INFO - 2022-05-11 09:39:33 --> Language Class Initialized
INFO - 2022-05-11 09:39:33 --> Config Class Initialized
INFO - 2022-05-11 09:39:33 --> Loader Class Initialized
INFO - 2022-05-11 09:39:33 --> Helper loaded: url_helper
INFO - 2022-05-11 09:39:33 --> Database Driver Class Initialized
INFO - 2022-05-11 09:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:39:33 --> Controller Class Initialized
DEBUG - 2022-05-11 09:39:33 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:39:33 --> Model Class Initialized
DEBUG - 2022-05-11 09:39:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:39:33 --> Model Class Initialized
DEBUG - 2022-05-11 09:39:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:39:33 --> Final output sent to browser
DEBUG - 2022-05-11 09:39:33 --> Total execution time: 0.0457
INFO - 2022-05-11 09:39:45 --> Config Class Initialized
INFO - 2022-05-11 09:39:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:39:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:39:45 --> Utf8 Class Initialized
INFO - 2022-05-11 09:39:45 --> URI Class Initialized
INFO - 2022-05-11 09:39:45 --> Router Class Initialized
INFO - 2022-05-11 09:39:45 --> Output Class Initialized
INFO - 2022-05-11 09:39:45 --> Security Class Initialized
DEBUG - 2022-05-11 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:39:45 --> Input Class Initialized
INFO - 2022-05-11 09:39:45 --> Language Class Initialized
INFO - 2022-05-11 09:39:45 --> Language Class Initialized
INFO - 2022-05-11 09:39:45 --> Config Class Initialized
INFO - 2022-05-11 09:39:45 --> Loader Class Initialized
INFO - 2022-05-11 09:39:45 --> Helper loaded: url_helper
INFO - 2022-05-11 09:39:45 --> Database Driver Class Initialized
INFO - 2022-05-11 09:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:39:45 --> Controller Class Initialized
ERROR - 2022-05-11 09:39:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/add_car
INFO - 2022-05-11 09:39:49 --> Config Class Initialized
INFO - 2022-05-11 09:39:49 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:39:49 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:39:49 --> Utf8 Class Initialized
INFO - 2022-05-11 09:39:49 --> URI Class Initialized
DEBUG - 2022-05-11 09:39:49 --> No URI present. Default controller set.
INFO - 2022-05-11 09:39:49 --> Router Class Initialized
INFO - 2022-05-11 09:39:49 --> Output Class Initialized
INFO - 2022-05-11 09:39:49 --> Security Class Initialized
DEBUG - 2022-05-11 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:39:49 --> Input Class Initialized
INFO - 2022-05-11 09:39:49 --> Language Class Initialized
INFO - 2022-05-11 09:39:49 --> Language Class Initialized
INFO - 2022-05-11 09:39:49 --> Config Class Initialized
INFO - 2022-05-11 09:39:49 --> Loader Class Initialized
INFO - 2022-05-11 09:39:49 --> Helper loaded: url_helper
INFO - 2022-05-11 09:39:49 --> Database Driver Class Initialized
INFO - 2022-05-11 09:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:39:49 --> Controller Class Initialized
DEBUG - 2022-05-11 09:39:49 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:39:49 --> Model Class Initialized
DEBUG - 2022-05-11 09:39:49 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:39:49 --> Model Class Initialized
DEBUG - 2022-05-11 09:39:49 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:39:49 --> Final output sent to browser
DEBUG - 2022-05-11 09:39:49 --> Total execution time: 0.0386
INFO - 2022-05-11 09:40:27 --> Config Class Initialized
INFO - 2022-05-11 09:40:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:40:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:40:27 --> Utf8 Class Initialized
INFO - 2022-05-11 09:40:27 --> URI Class Initialized
INFO - 2022-05-11 09:40:27 --> Router Class Initialized
INFO - 2022-05-11 09:40:27 --> Output Class Initialized
INFO - 2022-05-11 09:40:27 --> Security Class Initialized
DEBUG - 2022-05-11 09:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:40:27 --> Input Class Initialized
INFO - 2022-05-11 09:40:27 --> Language Class Initialized
INFO - 2022-05-11 09:40:27 --> Language Class Initialized
INFO - 2022-05-11 09:40:27 --> Config Class Initialized
INFO - 2022-05-11 09:40:27 --> Loader Class Initialized
INFO - 2022-05-11 09:40:27 --> Helper loaded: url_helper
INFO - 2022-05-11 09:40:27 --> Database Driver Class Initialized
INFO - 2022-05-11 09:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:40:27 --> Controller Class Initialized
DEBUG - 2022-05-11 09:40:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:40:27 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:40:27 --> Model Class Initialized
INFO - 2022-05-11 09:40:27 --> Config Class Initialized
INFO - 2022-05-11 09:40:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:40:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:40:27 --> Utf8 Class Initialized
INFO - 2022-05-11 09:40:27 --> URI Class Initialized
INFO - 2022-05-11 09:40:27 --> Router Class Initialized
INFO - 2022-05-11 09:40:27 --> Output Class Initialized
INFO - 2022-05-11 09:40:27 --> Security Class Initialized
DEBUG - 2022-05-11 09:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:40:27 --> Input Class Initialized
INFO - 2022-05-11 09:40:27 --> Language Class Initialized
INFO - 2022-05-11 09:40:27 --> Language Class Initialized
INFO - 2022-05-11 09:40:27 --> Config Class Initialized
INFO - 2022-05-11 09:40:27 --> Loader Class Initialized
INFO - 2022-05-11 09:40:27 --> Helper loaded: url_helper
INFO - 2022-05-11 09:40:27 --> Database Driver Class Initialized
INFO - 2022-05-11 09:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:40:27 --> Controller Class Initialized
DEBUG - 2022-05-11 09:40:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:40:27 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:40:27 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:40:27 --> Final output sent to browser
DEBUG - 2022-05-11 09:40:27 --> Total execution time: 0.0433
INFO - 2022-05-11 09:40:36 --> Config Class Initialized
INFO - 2022-05-11 09:40:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:40:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:40:36 --> Utf8 Class Initialized
INFO - 2022-05-11 09:40:36 --> URI Class Initialized
INFO - 2022-05-11 09:40:36 --> Router Class Initialized
INFO - 2022-05-11 09:40:36 --> Output Class Initialized
INFO - 2022-05-11 09:40:36 --> Security Class Initialized
DEBUG - 2022-05-11 09:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:40:36 --> Input Class Initialized
INFO - 2022-05-11 09:40:36 --> Language Class Initialized
INFO - 2022-05-11 09:40:36 --> Language Class Initialized
INFO - 2022-05-11 09:40:36 --> Config Class Initialized
INFO - 2022-05-11 09:40:36 --> Loader Class Initialized
INFO - 2022-05-11 09:40:36 --> Helper loaded: url_helper
INFO - 2022-05-11 09:40:36 --> Database Driver Class Initialized
INFO - 2022-05-11 09:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:40:36 --> Controller Class Initialized
DEBUG - 2022-05-11 09:40:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:40:36 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:40:36 --> Model Class Initialized
INFO - 2022-05-11 09:40:36 --> Config Class Initialized
INFO - 2022-05-11 09:40:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:40:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:40:36 --> Utf8 Class Initialized
INFO - 2022-05-11 09:40:36 --> URI Class Initialized
INFO - 2022-05-11 09:40:36 --> Router Class Initialized
INFO - 2022-05-11 09:40:36 --> Output Class Initialized
INFO - 2022-05-11 09:40:36 --> Security Class Initialized
DEBUG - 2022-05-11 09:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:40:36 --> Input Class Initialized
INFO - 2022-05-11 09:40:36 --> Language Class Initialized
INFO - 2022-05-11 09:40:36 --> Language Class Initialized
INFO - 2022-05-11 09:40:36 --> Config Class Initialized
INFO - 2022-05-11 09:40:36 --> Loader Class Initialized
INFO - 2022-05-11 09:40:36 --> Helper loaded: url_helper
INFO - 2022-05-11 09:40:36 --> Database Driver Class Initialized
INFO - 2022-05-11 09:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:40:36 --> Controller Class Initialized
DEBUG - 2022-05-11 09:40:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:40:36 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:40:36 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:40:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:40:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 09:40:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:40:36 --> Final output sent to browser
DEBUG - 2022-05-11 09:40:36 --> Total execution time: 0.0406
INFO - 2022-05-11 09:40:37 --> Config Class Initialized
INFO - 2022-05-11 09:40:37 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:40:37 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:40:37 --> Utf8 Class Initialized
INFO - 2022-05-11 09:40:37 --> URI Class Initialized
INFO - 2022-05-11 09:40:37 --> Router Class Initialized
INFO - 2022-05-11 09:40:37 --> Output Class Initialized
INFO - 2022-05-11 09:40:37 --> Security Class Initialized
DEBUG - 2022-05-11 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:40:37 --> Input Class Initialized
INFO - 2022-05-11 09:40:37 --> Language Class Initialized
INFO - 2022-05-11 09:40:37 --> Language Class Initialized
INFO - 2022-05-11 09:40:37 --> Config Class Initialized
INFO - 2022-05-11 09:40:37 --> Loader Class Initialized
INFO - 2022-05-11 09:40:37 --> Helper loaded: url_helper
INFO - 2022-05-11 09:40:37 --> Database Driver Class Initialized
INFO - 2022-05-11 09:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:40:37 --> Controller Class Initialized
DEBUG - 2022-05-11 09:40:37 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:40:37 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:40:37 --> Model Class Initialized
DEBUG - 2022-05-11 09:40:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:40:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:40:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 09:40:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:40:37 --> Final output sent to browser
DEBUG - 2022-05-11 09:40:37 --> Total execution time: 0.0485
INFO - 2022-05-11 09:44:20 --> Config Class Initialized
INFO - 2022-05-11 09:44:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:20 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:20 --> URI Class Initialized
INFO - 2022-05-11 09:44:20 --> Router Class Initialized
INFO - 2022-05-11 09:44:20 --> Output Class Initialized
INFO - 2022-05-11 09:44:20 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:20 --> Input Class Initialized
INFO - 2022-05-11 09:44:20 --> Language Class Initialized
INFO - 2022-05-11 09:44:20 --> Language Class Initialized
INFO - 2022-05-11 09:44:20 --> Config Class Initialized
INFO - 2022-05-11 09:44:20 --> Loader Class Initialized
INFO - 2022-05-11 09:44:20 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:20 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:20 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:20 --> Model Class Initialized
INFO - 2022-05-11 09:44:20 --> Config Class Initialized
INFO - 2022-05-11 09:44:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:20 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:20 --> URI Class Initialized
INFO - 2022-05-11 09:44:20 --> Router Class Initialized
INFO - 2022-05-11 09:44:20 --> Output Class Initialized
INFO - 2022-05-11 09:44:20 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:20 --> Input Class Initialized
INFO - 2022-05-11 09:44:20 --> Language Class Initialized
INFO - 2022-05-11 09:44:20 --> Language Class Initialized
INFO - 2022-05-11 09:44:20 --> Config Class Initialized
INFO - 2022-05-11 09:44:20 --> Loader Class Initialized
INFO - 2022-05-11 09:44:20 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:20 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:20 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:20 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:20 --> Total execution time: 0.0294
INFO - 2022-05-11 09:44:29 --> Config Class Initialized
INFO - 2022-05-11 09:44:29 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:29 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:29 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:29 --> URI Class Initialized
INFO - 2022-05-11 09:44:29 --> Router Class Initialized
INFO - 2022-05-11 09:44:29 --> Output Class Initialized
INFO - 2022-05-11 09:44:29 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:29 --> Input Class Initialized
INFO - 2022-05-11 09:44:29 --> Language Class Initialized
INFO - 2022-05-11 09:44:29 --> Language Class Initialized
INFO - 2022-05-11 09:44:29 --> Config Class Initialized
INFO - 2022-05-11 09:44:29 --> Loader Class Initialized
INFO - 2022-05-11 09:44:29 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:29 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:29 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:29 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:29 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:29 --> Model Class Initialized
INFO - 2022-05-11 09:44:29 --> Config Class Initialized
INFO - 2022-05-11 09:44:29 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:29 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:29 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:29 --> URI Class Initialized
INFO - 2022-05-11 09:44:29 --> Router Class Initialized
INFO - 2022-05-11 09:44:29 --> Output Class Initialized
INFO - 2022-05-11 09:44:29 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:29 --> Input Class Initialized
INFO - 2022-05-11 09:44:29 --> Language Class Initialized
INFO - 2022-05-11 09:44:29 --> Language Class Initialized
INFO - 2022-05-11 09:44:29 --> Config Class Initialized
INFO - 2022-05-11 09:44:29 --> Loader Class Initialized
INFO - 2022-05-11 09:44:29 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:29 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:29 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:29 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:29 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:29 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:29 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:29 --> Total execution time: 0.0417
INFO - 2022-05-11 09:44:44 --> Config Class Initialized
INFO - 2022-05-11 09:44:44 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:44 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:44 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:44 --> URI Class Initialized
INFO - 2022-05-11 09:44:44 --> Router Class Initialized
INFO - 2022-05-11 09:44:44 --> Output Class Initialized
INFO - 2022-05-11 09:44:44 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:44 --> Input Class Initialized
INFO - 2022-05-11 09:44:44 --> Language Class Initialized
INFO - 2022-05-11 09:44:44 --> Language Class Initialized
INFO - 2022-05-11 09:44:44 --> Config Class Initialized
INFO - 2022-05-11 09:44:44 --> Loader Class Initialized
INFO - 2022-05-11 09:44:44 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:44 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:44 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:44 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:44 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:44 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:44 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:44 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:44 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:44 --> Total execution time: 0.0385
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:45 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:45 --> URI Class Initialized
INFO - 2022-05-11 09:44:45 --> Router Class Initialized
INFO - 2022-05-11 09:44:45 --> Output Class Initialized
INFO - 2022-05-11 09:44:45 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:45 --> Input Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Loader Class Initialized
INFO - 2022-05-11 09:44:45 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:45 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:45 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:45 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:45 --> Total execution time: 0.0396
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:45 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:45 --> URI Class Initialized
INFO - 2022-05-11 09:44:45 --> Router Class Initialized
INFO - 2022-05-11 09:44:45 --> Output Class Initialized
INFO - 2022-05-11 09:44:45 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:45 --> Input Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Loader Class Initialized
INFO - 2022-05-11 09:44:45 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:45 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:45 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:45 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:45 --> Total execution time: 0.0469
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:45 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:45 --> URI Class Initialized
INFO - 2022-05-11 09:44:45 --> Router Class Initialized
INFO - 2022-05-11 09:44:45 --> Output Class Initialized
INFO - 2022-05-11 09:44:45 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:45 --> Input Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Loader Class Initialized
INFO - 2022-05-11 09:44:45 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:45 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:45 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:45 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:45 --> Total execution time: 0.0420
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:45 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:45 --> URI Class Initialized
INFO - 2022-05-11 09:44:45 --> Router Class Initialized
INFO - 2022-05-11 09:44:45 --> Output Class Initialized
INFO - 2022-05-11 09:44:45 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:45 --> Input Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Language Class Initialized
INFO - 2022-05-11 09:44:45 --> Config Class Initialized
INFO - 2022-05-11 09:44:45 --> Loader Class Initialized
INFO - 2022-05-11 09:44:45 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:45 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:45 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:45 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 09:44:45 --> Final output sent to browser
DEBUG - 2022-05-11 09:44:45 --> Total execution time: 0.0382
INFO - 2022-05-11 09:44:52 --> Config Class Initialized
INFO - 2022-05-11 09:44:52 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:44:52 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:44:52 --> Utf8 Class Initialized
INFO - 2022-05-11 09:44:52 --> URI Class Initialized
INFO - 2022-05-11 09:44:52 --> Router Class Initialized
INFO - 2022-05-11 09:44:52 --> Output Class Initialized
INFO - 2022-05-11 09:44:52 --> Security Class Initialized
DEBUG - 2022-05-11 09:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:44:52 --> Input Class Initialized
INFO - 2022-05-11 09:44:52 --> Language Class Initialized
INFO - 2022-05-11 09:44:52 --> Language Class Initialized
INFO - 2022-05-11 09:44:52 --> Config Class Initialized
INFO - 2022-05-11 09:44:52 --> Loader Class Initialized
INFO - 2022-05-11 09:44:52 --> Helper loaded: url_helper
INFO - 2022-05-11 09:44:52 --> Database Driver Class Initialized
INFO - 2022-05-11 09:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:44:52 --> Controller Class Initialized
DEBUG - 2022-05-11 09:44:52 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:44:52 --> Model Class Initialized
DEBUG - 2022-05-11 09:44:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:44:52 --> Model Class Initialized
ERROR - 2022-05-11 09:44:52 --> Severity: Error --> Call to undefined method Admin::session_no() C:\xampp\htdocs\vm\application\modules\admin\controllers\Admin.php 50
INFO - 2022-05-11 09:45:02 --> Config Class Initialized
INFO - 2022-05-11 09:45:02 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:02 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:02 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:02 --> URI Class Initialized
INFO - 2022-05-11 09:45:02 --> Router Class Initialized
INFO - 2022-05-11 09:45:02 --> Output Class Initialized
INFO - 2022-05-11 09:45:02 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:02 --> Input Class Initialized
INFO - 2022-05-11 09:45:02 --> Language Class Initialized
INFO - 2022-05-11 09:45:02 --> Language Class Initialized
INFO - 2022-05-11 09:45:02 --> Config Class Initialized
INFO - 2022-05-11 09:45:02 --> Loader Class Initialized
INFO - 2022-05-11 09:45:02 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:02 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:02 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:02 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:02 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:02 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:02 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:02 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:02 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:02 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 09:45:02 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:02 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:02 --> Total execution time: 0.0469
INFO - 2022-05-11 09:45:03 --> Config Class Initialized
INFO - 2022-05-11 09:45:03 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:03 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:03 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:03 --> URI Class Initialized
INFO - 2022-05-11 09:45:03 --> Router Class Initialized
INFO - 2022-05-11 09:45:03 --> Output Class Initialized
INFO - 2022-05-11 09:45:03 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:03 --> Input Class Initialized
INFO - 2022-05-11 09:45:03 --> Language Class Initialized
INFO - 2022-05-11 09:45:03 --> Language Class Initialized
INFO - 2022-05-11 09:45:03 --> Config Class Initialized
INFO - 2022-05-11 09:45:03 --> Loader Class Initialized
INFO - 2022-05-11 09:45:03 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:03 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:03 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:03 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:03 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:03 --> Model Class Initialized
ERROR - 2022-05-11 09:45:03 --> Severity: Error --> Call to undefined method Admin::session_no() C:\xampp\htdocs\vm\application\modules\admin\controllers\Admin.php 143
INFO - 2022-05-11 09:45:15 --> Config Class Initialized
INFO - 2022-05-11 09:45:15 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:15 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:15 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:15 --> URI Class Initialized
INFO - 2022-05-11 09:45:15 --> Router Class Initialized
INFO - 2022-05-11 09:45:15 --> Output Class Initialized
INFO - 2022-05-11 09:45:15 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:15 --> Input Class Initialized
INFO - 2022-05-11 09:45:15 --> Language Class Initialized
INFO - 2022-05-11 09:45:15 --> Language Class Initialized
INFO - 2022-05-11 09:45:15 --> Config Class Initialized
INFO - 2022-05-11 09:45:15 --> Loader Class Initialized
INFO - 2022-05-11 09:45:15 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:15 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:15 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:15 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:15 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:15 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:15 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:15 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:15 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:15 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 09:45:15 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:15 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:15 --> Total execution time: 0.0325
INFO - 2022-05-11 09:45:18 --> Config Class Initialized
INFO - 2022-05-11 09:45:18 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:18 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:18 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:18 --> URI Class Initialized
INFO - 2022-05-11 09:45:18 --> Router Class Initialized
INFO - 2022-05-11 09:45:18 --> Output Class Initialized
INFO - 2022-05-11 09:45:18 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:18 --> Input Class Initialized
INFO - 2022-05-11 09:45:18 --> Language Class Initialized
INFO - 2022-05-11 09:45:18 --> Language Class Initialized
INFO - 2022-05-11 09:45:18 --> Config Class Initialized
INFO - 2022-05-11 09:45:18 --> Loader Class Initialized
INFO - 2022-05-11 09:45:18 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:18 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:18 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:18 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:18 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:18 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:18 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:18 --> Total execution time: 0.0534
INFO - 2022-05-11 09:45:18 --> Config Class Initialized
INFO - 2022-05-11 09:45:18 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:18 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:18 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:18 --> URI Class Initialized
INFO - 2022-05-11 09:45:18 --> Router Class Initialized
INFO - 2022-05-11 09:45:18 --> Output Class Initialized
INFO - 2022-05-11 09:45:18 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:18 --> Input Class Initialized
INFO - 2022-05-11 09:45:18 --> Language Class Initialized
INFO - 2022-05-11 09:45:18 --> Language Class Initialized
INFO - 2022-05-11 09:45:18 --> Config Class Initialized
INFO - 2022-05-11 09:45:18 --> Loader Class Initialized
INFO - 2022-05-11 09:45:18 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:18 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:18 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:18 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:18 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:18 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 09:45:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:18 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:18 --> Total execution time: 0.0459
INFO - 2022-05-11 09:45:19 --> Config Class Initialized
INFO - 2022-05-11 09:45:19 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:19 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:19 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:19 --> URI Class Initialized
INFO - 2022-05-11 09:45:19 --> Router Class Initialized
INFO - 2022-05-11 09:45:19 --> Output Class Initialized
INFO - 2022-05-11 09:45:19 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:19 --> Input Class Initialized
INFO - 2022-05-11 09:45:19 --> Language Class Initialized
INFO - 2022-05-11 09:45:19 --> Language Class Initialized
INFO - 2022-05-11 09:45:19 --> Config Class Initialized
INFO - 2022-05-11 09:45:19 --> Loader Class Initialized
INFO - 2022-05-11 09:45:19 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:19 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:19 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:19 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:19 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:19 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 09:45:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:19 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:19 --> Total execution time: 0.0459
INFO - 2022-05-11 09:45:20 --> Config Class Initialized
INFO - 2022-05-11 09:45:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:20 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:20 --> URI Class Initialized
INFO - 2022-05-11 09:45:20 --> Router Class Initialized
INFO - 2022-05-11 09:45:20 --> Output Class Initialized
INFO - 2022-05-11 09:45:20 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:20 --> Input Class Initialized
INFO - 2022-05-11 09:45:20 --> Language Class Initialized
INFO - 2022-05-11 09:45:20 --> Language Class Initialized
INFO - 2022-05-11 09:45:20 --> Config Class Initialized
INFO - 2022-05-11 09:45:20 --> Loader Class Initialized
INFO - 2022-05-11 09:45:20 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:20 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:20 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:20 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:20 --> Total execution time: 0.0525
INFO - 2022-05-11 09:45:20 --> Config Class Initialized
INFO - 2022-05-11 09:45:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:20 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:20 --> URI Class Initialized
INFO - 2022-05-11 09:45:20 --> Router Class Initialized
INFO - 2022-05-11 09:45:20 --> Output Class Initialized
INFO - 2022-05-11 09:45:20 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:20 --> Input Class Initialized
INFO - 2022-05-11 09:45:20 --> Language Class Initialized
INFO - 2022-05-11 09:45:20 --> Language Class Initialized
INFO - 2022-05-11 09:45:20 --> Config Class Initialized
INFO - 2022-05-11 09:45:20 --> Loader Class Initialized
INFO - 2022-05-11 09:45:20 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:20 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:20 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:20 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 09:45:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:20 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:20 --> Total execution time: 0.0494
INFO - 2022-05-11 09:45:21 --> Config Class Initialized
INFO - 2022-05-11 09:45:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:21 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:21 --> URI Class Initialized
INFO - 2022-05-11 09:45:21 --> Router Class Initialized
INFO - 2022-05-11 09:45:21 --> Output Class Initialized
INFO - 2022-05-11 09:45:21 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:21 --> Input Class Initialized
INFO - 2022-05-11 09:45:21 --> Language Class Initialized
INFO - 2022-05-11 09:45:21 --> Language Class Initialized
INFO - 2022-05-11 09:45:21 --> Config Class Initialized
INFO - 2022-05-11 09:45:21 --> Loader Class Initialized
INFO - 2022-05-11 09:45:21 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:21 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:21 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:21 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:21 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:45:21 --> Final output sent to browser
DEBUG - 2022-05-11 09:45:21 --> Total execution time: 0.0379
INFO - 2022-05-11 09:45:21 --> Config Class Initialized
INFO - 2022-05-11 09:45:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:45:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:45:21 --> Utf8 Class Initialized
INFO - 2022-05-11 09:45:21 --> URI Class Initialized
INFO - 2022-05-11 09:45:21 --> Router Class Initialized
INFO - 2022-05-11 09:45:21 --> Output Class Initialized
INFO - 2022-05-11 09:45:21 --> Security Class Initialized
DEBUG - 2022-05-11 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:45:21 --> Input Class Initialized
INFO - 2022-05-11 09:45:21 --> Language Class Initialized
INFO - 2022-05-11 09:45:21 --> Language Class Initialized
INFO - 2022-05-11 09:45:21 --> Config Class Initialized
INFO - 2022-05-11 09:45:21 --> Loader Class Initialized
INFO - 2022-05-11 09:45:21 --> Helper loaded: url_helper
INFO - 2022-05-11 09:45:21 --> Database Driver Class Initialized
INFO - 2022-05-11 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:45:21 --> Controller Class Initialized
DEBUG - 2022-05-11 09:45:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:45:21 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:45:21 --> Model Class Initialized
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:45:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
INFO - 2022-05-11 09:48:47 --> Config Class Initialized
INFO - 2022-05-11 09:48:47 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:48:47 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:48:47 --> Utf8 Class Initialized
INFO - 2022-05-11 09:48:47 --> URI Class Initialized
INFO - 2022-05-11 09:48:47 --> Router Class Initialized
INFO - 2022-05-11 09:48:47 --> Output Class Initialized
INFO - 2022-05-11 09:48:47 --> Security Class Initialized
DEBUG - 2022-05-11 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:48:47 --> Input Class Initialized
INFO - 2022-05-11 09:48:47 --> Language Class Initialized
INFO - 2022-05-11 09:48:47 --> Language Class Initialized
INFO - 2022-05-11 09:48:47 --> Config Class Initialized
INFO - 2022-05-11 09:48:47 --> Loader Class Initialized
INFO - 2022-05-11 09:48:47 --> Helper loaded: url_helper
INFO - 2022-05-11 09:48:47 --> Database Driver Class Initialized
INFO - 2022-05-11 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:48:47 --> Controller Class Initialized
DEBUG - 2022-05-11 09:48:47 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:48:47 --> Model Class Initialized
DEBUG - 2022-05-11 09:48:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:48:47 --> Model Class Initialized
DEBUG - 2022-05-11 09:48:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:48:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:48:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 09:48:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:48:47 --> Final output sent to browser
DEBUG - 2022-05-11 09:48:47 --> Total execution time: 0.0425
INFO - 2022-05-11 09:55:37 --> Config Class Initialized
INFO - 2022-05-11 09:55:37 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:55:37 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:55:37 --> Utf8 Class Initialized
INFO - 2022-05-11 09:55:37 --> URI Class Initialized
INFO - 2022-05-11 09:55:37 --> Router Class Initialized
INFO - 2022-05-11 09:55:37 --> Output Class Initialized
INFO - 2022-05-11 09:55:37 --> Security Class Initialized
DEBUG - 2022-05-11 09:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:55:37 --> Input Class Initialized
INFO - 2022-05-11 09:55:37 --> Language Class Initialized
INFO - 2022-05-11 09:55:37 --> Language Class Initialized
INFO - 2022-05-11 09:55:37 --> Config Class Initialized
INFO - 2022-05-11 09:55:37 --> Loader Class Initialized
INFO - 2022-05-11 09:55:37 --> Helper loaded: url_helper
INFO - 2022-05-11 09:55:37 --> Database Driver Class Initialized
INFO - 2022-05-11 09:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:55:37 --> Controller Class Initialized
DEBUG - 2022-05-11 09:55:37 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:55:37 --> Model Class Initialized
DEBUG - 2022-05-11 09:55:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:55:37 --> Model Class Initialized
ERROR - 2022-05-11 09:55:37 --> Query error: Unknown column 'brand.b_id' in 'on clause' - Invalid query: SELECT *
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `brand`.`b_id` = `vd`.`brand`
JOIN `model` as `pm` ON `m`.`m_id` = `vd`.`model`
GROUP BY `vd`.`vd_id`
INFO - 2022-05-11 09:55:37 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:58:06 --> Config Class Initialized
INFO - 2022-05-11 09:58:06 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:58:06 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:58:06 --> Utf8 Class Initialized
INFO - 2022-05-11 09:58:06 --> URI Class Initialized
INFO - 2022-05-11 09:58:06 --> Router Class Initialized
INFO - 2022-05-11 09:58:06 --> Output Class Initialized
INFO - 2022-05-11 09:58:06 --> Security Class Initialized
DEBUG - 2022-05-11 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:58:06 --> Input Class Initialized
INFO - 2022-05-11 09:58:06 --> Language Class Initialized
INFO - 2022-05-11 09:58:06 --> Language Class Initialized
INFO - 2022-05-11 09:58:06 --> Config Class Initialized
INFO - 2022-05-11 09:58:06 --> Loader Class Initialized
INFO - 2022-05-11 09:58:06 --> Helper loaded: url_helper
INFO - 2022-05-11 09:58:06 --> Database Driver Class Initialized
INFO - 2022-05-11 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:58:06 --> Controller Class Initialized
DEBUG - 2022-05-11 09:58:06 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:58:06 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:58:06 --> Model Class Initialized
ERROR - 2022-05-11 09:58:06 --> Query error: Unknown column 'brand.b_id' in 'on clause' - Invalid query: SELECT *
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `brand`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
GROUP BY `vd`.`vd_id`
INFO - 2022-05-11 09:58:06 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:58:08 --> Config Class Initialized
INFO - 2022-05-11 09:58:08 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:58:08 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:58:08 --> Utf8 Class Initialized
INFO - 2022-05-11 09:58:08 --> URI Class Initialized
INFO - 2022-05-11 09:58:08 --> Router Class Initialized
INFO - 2022-05-11 09:58:08 --> Output Class Initialized
INFO - 2022-05-11 09:58:08 --> Security Class Initialized
DEBUG - 2022-05-11 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:58:08 --> Input Class Initialized
INFO - 2022-05-11 09:58:08 --> Language Class Initialized
INFO - 2022-05-11 09:58:08 --> Language Class Initialized
INFO - 2022-05-11 09:58:08 --> Config Class Initialized
INFO - 2022-05-11 09:58:08 --> Loader Class Initialized
INFO - 2022-05-11 09:58:08 --> Helper loaded: url_helper
INFO - 2022-05-11 09:58:08 --> Database Driver Class Initialized
INFO - 2022-05-11 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:58:08 --> Controller Class Initialized
DEBUG - 2022-05-11 09:58:08 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:58:08 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:58:08 --> Model Class Initialized
ERROR - 2022-05-11 09:58:08 --> Query error: Unknown column 'brand.b_id' in 'on clause' - Invalid query: SELECT *
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `brand`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
GROUP BY `vd`.`vd_id`
INFO - 2022-05-11 09:58:08 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:58:21 --> Config Class Initialized
INFO - 2022-05-11 09:58:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:58:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:58:21 --> Utf8 Class Initialized
INFO - 2022-05-11 09:58:21 --> URI Class Initialized
INFO - 2022-05-11 09:58:21 --> Router Class Initialized
INFO - 2022-05-11 09:58:21 --> Output Class Initialized
INFO - 2022-05-11 09:58:21 --> Security Class Initialized
DEBUG - 2022-05-11 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:58:21 --> Input Class Initialized
INFO - 2022-05-11 09:58:21 --> Language Class Initialized
INFO - 2022-05-11 09:58:22 --> Language Class Initialized
INFO - 2022-05-11 09:58:22 --> Config Class Initialized
INFO - 2022-05-11 09:58:22 --> Loader Class Initialized
INFO - 2022-05-11 09:58:22 --> Helper loaded: url_helper
INFO - 2022-05-11 09:58:22 --> Database Driver Class Initialized
INFO - 2022-05-11 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:58:22 --> Controller Class Initialized
DEBUG - 2022-05-11 09:58:22 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:58:22 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:58:22 --> Model Class Initialized
ERROR - 2022-05-11 09:58:22 --> Query error: Unknown column 'brand.b_id' in 'on clause' - Invalid query: SELECT *
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `brand`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
GROUP BY `vd`.`vd_id`
INFO - 2022-05-11 09:58:22 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:58:24 --> Config Class Initialized
INFO - 2022-05-11 09:58:24 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:58:24 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:58:24 --> Utf8 Class Initialized
INFO - 2022-05-11 09:58:24 --> URI Class Initialized
INFO - 2022-05-11 09:58:24 --> Router Class Initialized
INFO - 2022-05-11 09:58:24 --> Output Class Initialized
INFO - 2022-05-11 09:58:24 --> Security Class Initialized
DEBUG - 2022-05-11 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:58:24 --> Input Class Initialized
INFO - 2022-05-11 09:58:24 --> Language Class Initialized
INFO - 2022-05-11 09:58:24 --> Language Class Initialized
INFO - 2022-05-11 09:58:24 --> Config Class Initialized
INFO - 2022-05-11 09:58:24 --> Loader Class Initialized
INFO - 2022-05-11 09:58:24 --> Helper loaded: url_helper
INFO - 2022-05-11 09:58:24 --> Database Driver Class Initialized
INFO - 2022-05-11 09:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:58:24 --> Controller Class Initialized
DEBUG - 2022-05-11 09:58:24 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:58:24 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:24 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:58:24 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:24 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:58:24 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:58:24 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 09:58:24 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:58:24 --> Final output sent to browser
DEBUG - 2022-05-11 09:58:24 --> Total execution time: 0.0440
INFO - 2022-05-11 09:58:25 --> Config Class Initialized
INFO - 2022-05-11 09:58:25 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:58:25 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:58:25 --> Utf8 Class Initialized
INFO - 2022-05-11 09:58:25 --> URI Class Initialized
INFO - 2022-05-11 09:58:25 --> Router Class Initialized
INFO - 2022-05-11 09:58:25 --> Output Class Initialized
INFO - 2022-05-11 09:58:25 --> Security Class Initialized
DEBUG - 2022-05-11 09:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:58:25 --> Input Class Initialized
INFO - 2022-05-11 09:58:25 --> Language Class Initialized
INFO - 2022-05-11 09:58:25 --> Language Class Initialized
INFO - 2022-05-11 09:58:25 --> Config Class Initialized
INFO - 2022-05-11 09:58:25 --> Loader Class Initialized
INFO - 2022-05-11 09:58:25 --> Helper loaded: url_helper
INFO - 2022-05-11 09:58:25 --> Database Driver Class Initialized
INFO - 2022-05-11 09:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:58:25 --> Controller Class Initialized
DEBUG - 2022-05-11 09:58:25 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:58:25 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:58:25 --> Model Class Initialized
ERROR - 2022-05-11 09:58:25 --> Query error: Unknown column 'brand.b_id' in 'on clause' - Invalid query: SELECT *
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `brand`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
GROUP BY `vd`.`vd_id`
INFO - 2022-05-11 09:58:25 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:58:51 --> Config Class Initialized
INFO - 2022-05-11 09:58:51 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:58:51 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:58:51 --> Utf8 Class Initialized
INFO - 2022-05-11 09:58:51 --> URI Class Initialized
INFO - 2022-05-11 09:58:51 --> Router Class Initialized
INFO - 2022-05-11 09:58:51 --> Output Class Initialized
INFO - 2022-05-11 09:58:51 --> Security Class Initialized
DEBUG - 2022-05-11 09:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:58:51 --> Input Class Initialized
INFO - 2022-05-11 09:58:51 --> Language Class Initialized
INFO - 2022-05-11 09:58:51 --> Language Class Initialized
INFO - 2022-05-11 09:58:51 --> Config Class Initialized
INFO - 2022-05-11 09:58:51 --> Loader Class Initialized
INFO - 2022-05-11 09:58:51 --> Helper loaded: url_helper
INFO - 2022-05-11 09:58:51 --> Database Driver Class Initialized
INFO - 2022-05-11 09:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:58:51 --> Controller Class Initialized
DEBUG - 2022-05-11 09:58:51 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:58:51 --> Model Class Initialized
DEBUG - 2022-05-11 09:58:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:58:51 --> Model Class Initialized
ERROR - 2022-05-11 09:58:51 --> Query error: Unknown column 'vd.vd_id' in 'group statement' - Invalid query: SELECT *
FROM `vehicle_details` as `vd`
JOIN `category` as `cat` ON `cat`.`c_id` =  `vd`.`category` 
JOIN `brand` as `b` ON `b`.`b_id` = `vd`.`brand`
JOIN `model` as `m` ON `m`.`m_id` = `vd`.`model`
GROUP BY `vd`.`vd_id`
INFO - 2022-05-11 09:58:51 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 09:59:08 --> Config Class Initialized
INFO - 2022-05-11 09:59:08 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:59:08 --> Utf8 Class Initialized
INFO - 2022-05-11 09:59:08 --> URI Class Initialized
INFO - 2022-05-11 09:59:08 --> Router Class Initialized
INFO - 2022-05-11 09:59:08 --> Output Class Initialized
INFO - 2022-05-11 09:59:08 --> Security Class Initialized
DEBUG - 2022-05-11 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:59:08 --> Input Class Initialized
INFO - 2022-05-11 09:59:08 --> Language Class Initialized
INFO - 2022-05-11 09:59:08 --> Language Class Initialized
INFO - 2022-05-11 09:59:08 --> Config Class Initialized
INFO - 2022-05-11 09:59:08 --> Loader Class Initialized
INFO - 2022-05-11 09:59:08 --> Helper loaded: url_helper
INFO - 2022-05-11 09:59:08 --> Database Driver Class Initialized
INFO - 2022-05-11 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:59:08 --> Controller Class Initialized
DEBUG - 2022-05-11 09:59:08 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:59:08 --> Model Class Initialized
DEBUG - 2022-05-11 09:59:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:59:08 --> Model Class Initialized
DEBUG - 2022-05-11 09:59:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 09:59:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 09:59:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 09:59:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 09:59:08 --> Final output sent to browser
DEBUG - 2022-05-11 09:59:08 --> Total execution time: 0.0435
INFO - 2022-05-11 09:59:22 --> Config Class Initialized
INFO - 2022-05-11 09:59:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 09:59:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 09:59:22 --> Utf8 Class Initialized
INFO - 2022-05-11 09:59:22 --> URI Class Initialized
INFO - 2022-05-11 09:59:22 --> Router Class Initialized
INFO - 2022-05-11 09:59:22 --> Output Class Initialized
INFO - 2022-05-11 09:59:22 --> Security Class Initialized
DEBUG - 2022-05-11 09:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 09:59:22 --> Input Class Initialized
INFO - 2022-05-11 09:59:22 --> Language Class Initialized
INFO - 2022-05-11 09:59:22 --> Language Class Initialized
INFO - 2022-05-11 09:59:22 --> Config Class Initialized
INFO - 2022-05-11 09:59:22 --> Loader Class Initialized
INFO - 2022-05-11 09:59:22 --> Helper loaded: url_helper
INFO - 2022-05-11 09:59:22 --> Database Driver Class Initialized
INFO - 2022-05-11 09:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 09:59:22 --> Controller Class Initialized
DEBUG - 2022-05-11 09:59:22 --> Admin MX_Controller Initialized
INFO - 2022-05-11 09:59:22 --> Model Class Initialized
DEBUG - 2022-05-11 09:59:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 09:59:22 --> Model Class Initialized
INFO - 2022-05-11 10:01:14 --> Config Class Initialized
INFO - 2022-05-11 10:01:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:01:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:01:14 --> Utf8 Class Initialized
INFO - 2022-05-11 10:01:14 --> URI Class Initialized
INFO - 2022-05-11 10:01:14 --> Router Class Initialized
INFO - 2022-05-11 10:01:14 --> Output Class Initialized
INFO - 2022-05-11 10:01:14 --> Security Class Initialized
DEBUG - 2022-05-11 10:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:01:14 --> Input Class Initialized
INFO - 2022-05-11 10:01:14 --> Language Class Initialized
INFO - 2022-05-11 10:01:14 --> Language Class Initialized
INFO - 2022-05-11 10:01:14 --> Config Class Initialized
INFO - 2022-05-11 10:01:14 --> Loader Class Initialized
INFO - 2022-05-11 10:01:14 --> Helper loaded: url_helper
INFO - 2022-05-11 10:01:14 --> Database Driver Class Initialized
INFO - 2022-05-11 10:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:01:14 --> Controller Class Initialized
DEBUG - 2022-05-11 10:01:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:01:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:01:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:01:14 --> Model Class Initialized
INFO - 2022-05-11 10:04:39 --> Config Class Initialized
INFO - 2022-05-11 10:04:39 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:04:39 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:04:39 --> Utf8 Class Initialized
INFO - 2022-05-11 10:04:39 --> URI Class Initialized
INFO - 2022-05-11 10:04:39 --> Router Class Initialized
INFO - 2022-05-11 10:04:39 --> Output Class Initialized
INFO - 2022-05-11 10:04:39 --> Security Class Initialized
DEBUG - 2022-05-11 10:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:04:39 --> Input Class Initialized
INFO - 2022-05-11 10:04:39 --> Language Class Initialized
INFO - 2022-05-11 10:04:39 --> Language Class Initialized
INFO - 2022-05-11 10:04:39 --> Config Class Initialized
INFO - 2022-05-11 10:04:39 --> Loader Class Initialized
INFO - 2022-05-11 10:04:39 --> Helper loaded: url_helper
INFO - 2022-05-11 10:04:39 --> Database Driver Class Initialized
INFO - 2022-05-11 10:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:04:39 --> Controller Class Initialized
DEBUG - 2022-05-11 10:04:39 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:04:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:04:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:04:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:04:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:04:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:04:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:04:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:04:39 --> Final output sent to browser
DEBUG - 2022-05-11 10:04:39 --> Total execution time: 0.0289
INFO - 2022-05-11 10:09:39 --> Config Class Initialized
INFO - 2022-05-11 10:09:39 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:09:39 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:09:39 --> Utf8 Class Initialized
INFO - 2022-05-11 10:09:39 --> URI Class Initialized
INFO - 2022-05-11 10:09:39 --> Router Class Initialized
INFO - 2022-05-11 10:09:39 --> Output Class Initialized
INFO - 2022-05-11 10:09:39 --> Security Class Initialized
DEBUG - 2022-05-11 10:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:09:39 --> Input Class Initialized
INFO - 2022-05-11 10:09:39 --> Language Class Initialized
INFO - 2022-05-11 10:09:39 --> Language Class Initialized
INFO - 2022-05-11 10:09:39 --> Config Class Initialized
INFO - 2022-05-11 10:09:39 --> Loader Class Initialized
INFO - 2022-05-11 10:09:39 --> Helper loaded: url_helper
INFO - 2022-05-11 10:09:39 --> Database Driver Class Initialized
INFO - 2022-05-11 10:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:09:39 --> Controller Class Initialized
DEBUG - 2022-05-11 10:09:39 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:09:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:09:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:09:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:09:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:09:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:09:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:09:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:09:39 --> Final output sent to browser
DEBUG - 2022-05-11 10:09:39 --> Total execution time: 0.0507
INFO - 2022-05-11 10:09:52 --> Config Class Initialized
INFO - 2022-05-11 10:09:52 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:09:52 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:09:52 --> Utf8 Class Initialized
INFO - 2022-05-11 10:09:52 --> URI Class Initialized
INFO - 2022-05-11 10:09:52 --> Router Class Initialized
INFO - 2022-05-11 10:09:52 --> Output Class Initialized
INFO - 2022-05-11 10:09:52 --> Security Class Initialized
DEBUG - 2022-05-11 10:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:09:52 --> Input Class Initialized
INFO - 2022-05-11 10:09:52 --> Language Class Initialized
INFO - 2022-05-11 10:09:52 --> Language Class Initialized
INFO - 2022-05-11 10:09:52 --> Config Class Initialized
INFO - 2022-05-11 10:09:52 --> Loader Class Initialized
INFO - 2022-05-11 10:09:52 --> Helper loaded: url_helper
INFO - 2022-05-11 10:09:52 --> Database Driver Class Initialized
INFO - 2022-05-11 10:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:09:52 --> Controller Class Initialized
DEBUG - 2022-05-11 10:09:52 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:09:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:09:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:09:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:09:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:09:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:09:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:09:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:09:52 --> Final output sent to browser
DEBUG - 2022-05-11 10:09:52 --> Total execution time: 0.0489
INFO - 2022-05-11 10:10:14 --> Config Class Initialized
INFO - 2022-05-11 10:10:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:10:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:10:14 --> Utf8 Class Initialized
INFO - 2022-05-11 10:10:14 --> URI Class Initialized
INFO - 2022-05-11 10:10:14 --> Router Class Initialized
INFO - 2022-05-11 10:10:14 --> Output Class Initialized
INFO - 2022-05-11 10:10:14 --> Security Class Initialized
DEBUG - 2022-05-11 10:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:10:14 --> Input Class Initialized
INFO - 2022-05-11 10:10:14 --> Language Class Initialized
INFO - 2022-05-11 10:10:14 --> Language Class Initialized
INFO - 2022-05-11 10:10:14 --> Config Class Initialized
INFO - 2022-05-11 10:10:14 --> Loader Class Initialized
INFO - 2022-05-11 10:10:14 --> Helper loaded: url_helper
INFO - 2022-05-11 10:10:14 --> Database Driver Class Initialized
INFO - 2022-05-11 10:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:10:14 --> Controller Class Initialized
DEBUG - 2022-05-11 10:10:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:10:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:10:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:10:14 --> Model Class Initialized
INFO - 2022-05-11 10:10:14 --> Final output sent to browser
DEBUG - 2022-05-11 10:10:14 --> Total execution time: 0.0284
INFO - 2022-05-11 10:11:52 --> Config Class Initialized
INFO - 2022-05-11 10:11:52 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:11:52 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:11:52 --> Utf8 Class Initialized
INFO - 2022-05-11 10:11:52 --> URI Class Initialized
INFO - 2022-05-11 10:11:52 --> Router Class Initialized
INFO - 2022-05-11 10:11:52 --> Output Class Initialized
INFO - 2022-05-11 10:11:52 --> Security Class Initialized
DEBUG - 2022-05-11 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:11:52 --> Input Class Initialized
INFO - 2022-05-11 10:11:52 --> Language Class Initialized
INFO - 2022-05-11 10:11:52 --> Language Class Initialized
INFO - 2022-05-11 10:11:52 --> Config Class Initialized
INFO - 2022-05-11 10:11:52 --> Loader Class Initialized
INFO - 2022-05-11 10:11:52 --> Helper loaded: url_helper
INFO - 2022-05-11 10:11:52 --> Database Driver Class Initialized
INFO - 2022-05-11 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:11:52 --> Controller Class Initialized
DEBUG - 2022-05-11 10:11:52 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:11:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:11:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:11:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:11:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:11:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:11:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:11:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:11:52 --> Final output sent to browser
DEBUG - 2022-05-11 10:11:52 --> Total execution time: 0.0311
INFO - 2022-05-11 10:12:21 --> Config Class Initialized
INFO - 2022-05-11 10:12:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:12:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:12:21 --> Utf8 Class Initialized
INFO - 2022-05-11 10:12:21 --> URI Class Initialized
INFO - 2022-05-11 10:12:21 --> Router Class Initialized
INFO - 2022-05-11 10:12:21 --> Output Class Initialized
INFO - 2022-05-11 10:12:21 --> Security Class Initialized
DEBUG - 2022-05-11 10:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:12:21 --> Input Class Initialized
INFO - 2022-05-11 10:12:21 --> Language Class Initialized
INFO - 2022-05-11 10:12:21 --> Language Class Initialized
INFO - 2022-05-11 10:12:21 --> Config Class Initialized
INFO - 2022-05-11 10:12:21 --> Loader Class Initialized
INFO - 2022-05-11 10:12:21 --> Helper loaded: url_helper
INFO - 2022-05-11 10:12:21 --> Database Driver Class Initialized
INFO - 2022-05-11 10:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:12:21 --> Controller Class Initialized
DEBUG - 2022-05-11 10:12:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:12:21 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:12:21 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:12:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:12:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:12:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:12:21 --> Final output sent to browser
DEBUG - 2022-05-11 10:12:21 --> Total execution time: 0.0477
INFO - 2022-05-11 10:12:22 --> Config Class Initialized
INFO - 2022-05-11 10:12:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:12:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:12:22 --> Utf8 Class Initialized
INFO - 2022-05-11 10:12:22 --> URI Class Initialized
INFO - 2022-05-11 10:12:22 --> Router Class Initialized
INFO - 2022-05-11 10:12:22 --> Output Class Initialized
INFO - 2022-05-11 10:12:22 --> Security Class Initialized
DEBUG - 2022-05-11 10:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:12:22 --> Input Class Initialized
INFO - 2022-05-11 10:12:22 --> Language Class Initialized
INFO - 2022-05-11 10:12:22 --> Language Class Initialized
INFO - 2022-05-11 10:12:22 --> Config Class Initialized
INFO - 2022-05-11 10:12:22 --> Loader Class Initialized
INFO - 2022-05-11 10:12:22 --> Helper loaded: url_helper
INFO - 2022-05-11 10:12:22 --> Database Driver Class Initialized
INFO - 2022-05-11 10:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:12:22 --> Controller Class Initialized
DEBUG - 2022-05-11 10:12:22 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:12:22 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:12:22 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:12:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:12:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:12:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:12:22 --> Final output sent to browser
DEBUG - 2022-05-11 10:12:22 --> Total execution time: 0.0471
INFO - 2022-05-11 10:12:27 --> Config Class Initialized
INFO - 2022-05-11 10:12:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:12:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:12:27 --> Utf8 Class Initialized
INFO - 2022-05-11 10:12:27 --> URI Class Initialized
INFO - 2022-05-11 10:12:27 --> Router Class Initialized
INFO - 2022-05-11 10:12:27 --> Output Class Initialized
INFO - 2022-05-11 10:12:27 --> Security Class Initialized
DEBUG - 2022-05-11 10:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:12:27 --> Input Class Initialized
INFO - 2022-05-11 10:12:27 --> Language Class Initialized
INFO - 2022-05-11 10:12:27 --> Language Class Initialized
INFO - 2022-05-11 10:12:27 --> Config Class Initialized
INFO - 2022-05-11 10:12:27 --> Loader Class Initialized
INFO - 2022-05-11 10:12:27 --> Helper loaded: url_helper
INFO - 2022-05-11 10:12:27 --> Database Driver Class Initialized
INFO - 2022-05-11 10:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:12:27 --> Controller Class Initialized
DEBUG - 2022-05-11 10:12:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:12:27 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:12:27 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:12:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:12:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:12:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:12:27 --> Final output sent to browser
DEBUG - 2022-05-11 10:12:27 --> Total execution time: 0.0532
INFO - 2022-05-11 10:12:34 --> Config Class Initialized
INFO - 2022-05-11 10:12:34 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:12:34 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:12:34 --> Utf8 Class Initialized
INFO - 2022-05-11 10:12:34 --> URI Class Initialized
INFO - 2022-05-11 10:12:34 --> Router Class Initialized
INFO - 2022-05-11 10:12:34 --> Output Class Initialized
INFO - 2022-05-11 10:12:34 --> Security Class Initialized
DEBUG - 2022-05-11 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:12:34 --> Input Class Initialized
INFO - 2022-05-11 10:12:34 --> Language Class Initialized
INFO - 2022-05-11 10:12:34 --> Language Class Initialized
INFO - 2022-05-11 10:12:34 --> Config Class Initialized
INFO - 2022-05-11 10:12:34 --> Loader Class Initialized
INFO - 2022-05-11 10:12:34 --> Helper loaded: url_helper
INFO - 2022-05-11 10:12:34 --> Database Driver Class Initialized
INFO - 2022-05-11 10:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:12:34 --> Controller Class Initialized
DEBUG - 2022-05-11 10:12:34 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:12:34 --> Model Class Initialized
DEBUG - 2022-05-11 10:12:34 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:12:34 --> Model Class Initialized
INFO - 2022-05-11 10:12:34 --> Final output sent to browser
DEBUG - 2022-05-11 10:12:34 --> Total execution time: 0.0423
INFO - 2022-05-11 10:13:08 --> Config Class Initialized
INFO - 2022-05-11 10:13:08 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:13:08 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:13:08 --> Utf8 Class Initialized
INFO - 2022-05-11 10:13:08 --> URI Class Initialized
INFO - 2022-05-11 10:13:08 --> Router Class Initialized
INFO - 2022-05-11 10:13:08 --> Output Class Initialized
INFO - 2022-05-11 10:13:08 --> Security Class Initialized
DEBUG - 2022-05-11 10:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:13:08 --> Input Class Initialized
INFO - 2022-05-11 10:13:08 --> Language Class Initialized
INFO - 2022-05-11 10:13:08 --> Language Class Initialized
INFO - 2022-05-11 10:13:08 --> Config Class Initialized
INFO - 2022-05-11 10:13:08 --> Loader Class Initialized
INFO - 2022-05-11 10:13:08 --> Helper loaded: url_helper
INFO - 2022-05-11 10:13:08 --> Database Driver Class Initialized
INFO - 2022-05-11 10:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:13:08 --> Controller Class Initialized
DEBUG - 2022-05-11 10:13:08 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:13:08 --> Model Class Initialized
DEBUG - 2022-05-11 10:13:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:13:08 --> Model Class Initialized
DEBUG - 2022-05-11 10:13:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:13:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:13:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:13:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:13:08 --> Final output sent to browser
DEBUG - 2022-05-11 10:13:08 --> Total execution time: 0.0292
INFO - 2022-05-11 10:17:52 --> Config Class Initialized
INFO - 2022-05-11 10:17:52 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:17:52 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:17:52 --> Utf8 Class Initialized
INFO - 2022-05-11 10:17:52 --> URI Class Initialized
DEBUG - 2022-05-11 10:17:52 --> No URI present. Default controller set.
INFO - 2022-05-11 10:17:52 --> Router Class Initialized
INFO - 2022-05-11 10:17:52 --> Output Class Initialized
INFO - 2022-05-11 10:17:52 --> Security Class Initialized
DEBUG - 2022-05-11 10:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:17:52 --> Input Class Initialized
INFO - 2022-05-11 10:17:52 --> Language Class Initialized
INFO - 2022-05-11 10:17:52 --> Language Class Initialized
INFO - 2022-05-11 10:17:52 --> Config Class Initialized
INFO - 2022-05-11 10:17:52 --> Loader Class Initialized
INFO - 2022-05-11 10:17:52 --> Helper loaded: url_helper
INFO - 2022-05-11 10:17:52 --> Database Driver Class Initialized
INFO - 2022-05-11 10:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:17:52 --> Controller Class Initialized
DEBUG - 2022-05-11 10:17:52 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:17:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:17:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:17:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:17:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 10:17:52 --> Final output sent to browser
DEBUG - 2022-05-11 10:17:52 --> Total execution time: 0.0480
INFO - 2022-05-11 10:18:03 --> Config Class Initialized
INFO - 2022-05-11 10:18:03 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:03 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:03 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:03 --> URI Class Initialized
INFO - 2022-05-11 10:18:03 --> Router Class Initialized
INFO - 2022-05-11 10:18:03 --> Output Class Initialized
INFO - 2022-05-11 10:18:03 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:03 --> Input Class Initialized
INFO - 2022-05-11 10:18:03 --> Language Class Initialized
INFO - 2022-05-11 10:18:03 --> Language Class Initialized
INFO - 2022-05-11 10:18:03 --> Config Class Initialized
INFO - 2022-05-11 10:18:03 --> Loader Class Initialized
INFO - 2022-05-11 10:18:03 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:03 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:03 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:03 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:03 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:03 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 10:18:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:03 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:03 --> Total execution time: 0.0400
INFO - 2022-05-11 10:18:04 --> Config Class Initialized
INFO - 2022-05-11 10:18:04 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:04 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:04 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:04 --> URI Class Initialized
INFO - 2022-05-11 10:18:04 --> Router Class Initialized
INFO - 2022-05-11 10:18:04 --> Output Class Initialized
INFO - 2022-05-11 10:18:04 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:04 --> Input Class Initialized
INFO - 2022-05-11 10:18:04 --> Language Class Initialized
INFO - 2022-05-11 10:18:04 --> Language Class Initialized
INFO - 2022-05-11 10:18:04 --> Config Class Initialized
INFO - 2022-05-11 10:18:04 --> Loader Class Initialized
INFO - 2022-05-11 10:18:04 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:04 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:04 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:04 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:04 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:04 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:18:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:04 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:04 --> Total execution time: 0.0405
INFO - 2022-05-11 10:18:06 --> Config Class Initialized
INFO - 2022-05-11 10:18:06 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:06 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:06 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:06 --> URI Class Initialized
INFO - 2022-05-11 10:18:06 --> Router Class Initialized
INFO - 2022-05-11 10:18:06 --> Output Class Initialized
INFO - 2022-05-11 10:18:06 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:06 --> Input Class Initialized
INFO - 2022-05-11 10:18:06 --> Language Class Initialized
INFO - 2022-05-11 10:18:06 --> Language Class Initialized
INFO - 2022-05-11 10:18:06 --> Config Class Initialized
INFO - 2022-05-11 10:18:06 --> Loader Class Initialized
INFO - 2022-05-11 10:18:06 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:06 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:06 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:06 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:06 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:06 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:18:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:06 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:06 --> Total execution time: 0.0434
INFO - 2022-05-11 10:18:10 --> Config Class Initialized
INFO - 2022-05-11 10:18:10 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:10 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:10 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:10 --> URI Class Initialized
INFO - 2022-05-11 10:18:10 --> Router Class Initialized
INFO - 2022-05-11 10:18:10 --> Output Class Initialized
INFO - 2022-05-11 10:18:10 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:10 --> Input Class Initialized
INFO - 2022-05-11 10:18:10 --> Language Class Initialized
INFO - 2022-05-11 10:18:10 --> Language Class Initialized
INFO - 2022-05-11 10:18:10 --> Config Class Initialized
INFO - 2022-05-11 10:18:10 --> Loader Class Initialized
INFO - 2022-05-11 10:18:10 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:10 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:10 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:10 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:10 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:10 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:10 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:10 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:10 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:10 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:18:10 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:10 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:10 --> Total execution time: 0.0385
INFO - 2022-05-11 10:18:12 --> Config Class Initialized
INFO - 2022-05-11 10:18:12 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:12 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:12 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:12 --> URI Class Initialized
INFO - 2022-05-11 10:18:12 --> Router Class Initialized
INFO - 2022-05-11 10:18:12 --> Output Class Initialized
INFO - 2022-05-11 10:18:12 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:12 --> Input Class Initialized
INFO - 2022-05-11 10:18:12 --> Language Class Initialized
INFO - 2022-05-11 10:18:12 --> Language Class Initialized
INFO - 2022-05-11 10:18:12 --> Config Class Initialized
INFO - 2022-05-11 10:18:12 --> Loader Class Initialized
INFO - 2022-05-11 10:18:12 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:12 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:12 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:12 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:12 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:12 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 10:18:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:12 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:12 --> Total execution time: 0.0454
INFO - 2022-05-11 10:18:16 --> Config Class Initialized
INFO - 2022-05-11 10:18:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:16 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:16 --> URI Class Initialized
INFO - 2022-05-11 10:18:16 --> Router Class Initialized
INFO - 2022-05-11 10:18:16 --> Output Class Initialized
INFO - 2022-05-11 10:18:16 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:17 --> Input Class Initialized
INFO - 2022-05-11 10:18:17 --> Language Class Initialized
INFO - 2022-05-11 10:18:17 --> Language Class Initialized
INFO - 2022-05-11 10:18:17 --> Config Class Initialized
INFO - 2022-05-11 10:18:17 --> Loader Class Initialized
INFO - 2022-05-11 10:18:17 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:17 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:17 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:17 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:17 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:17 --> Model Class Initialized
INFO - 2022-05-11 10:18:17 --> Config Class Initialized
INFO - 2022-05-11 10:18:17 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:17 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:17 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:17 --> URI Class Initialized
INFO - 2022-05-11 10:18:17 --> Router Class Initialized
INFO - 2022-05-11 10:18:17 --> Output Class Initialized
INFO - 2022-05-11 10:18:17 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:17 --> Input Class Initialized
INFO - 2022-05-11 10:18:17 --> Language Class Initialized
INFO - 2022-05-11 10:18:17 --> Language Class Initialized
INFO - 2022-05-11 10:18:17 --> Config Class Initialized
INFO - 2022-05-11 10:18:17 --> Loader Class Initialized
INFO - 2022-05-11 10:18:17 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:17 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:17 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:17 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:17 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:17 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 10:18:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:17 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:17 --> Total execution time: 0.0295
INFO - 2022-05-11 10:18:18 --> Config Class Initialized
INFO - 2022-05-11 10:18:18 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:18 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:18 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:18 --> URI Class Initialized
INFO - 2022-05-11 10:18:18 --> Router Class Initialized
INFO - 2022-05-11 10:18:18 --> Output Class Initialized
INFO - 2022-05-11 10:18:18 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:18 --> Input Class Initialized
INFO - 2022-05-11 10:18:18 --> Language Class Initialized
INFO - 2022-05-11 10:18:18 --> Language Class Initialized
INFO - 2022-05-11 10:18:18 --> Config Class Initialized
INFO - 2022-05-11 10:18:18 --> Loader Class Initialized
INFO - 2022-05-11 10:18:18 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:18 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:18 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:18 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:18 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:18 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:18:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:18 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:18 --> Total execution time: 0.0401
INFO - 2022-05-11 10:18:38 --> Config Class Initialized
INFO - 2022-05-11 10:18:38 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:38 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:38 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:38 --> URI Class Initialized
INFO - 2022-05-11 10:18:38 --> Router Class Initialized
INFO - 2022-05-11 10:18:38 --> Output Class Initialized
INFO - 2022-05-11 10:18:38 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:38 --> Input Class Initialized
INFO - 2022-05-11 10:18:38 --> Language Class Initialized
INFO - 2022-05-11 10:18:38 --> Language Class Initialized
INFO - 2022-05-11 10:18:38 --> Config Class Initialized
INFO - 2022-05-11 10:18:38 --> Loader Class Initialized
INFO - 2022-05-11 10:18:38 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:38 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:38 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:38 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:38 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:38 --> Model Class Initialized
INFO - 2022-05-11 10:18:38 --> Upload Class Initialized
INFO - 2022-05-11 10:18:38 --> Config Class Initialized
INFO - 2022-05-11 10:18:38 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:18:38 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:18:38 --> Utf8 Class Initialized
INFO - 2022-05-11 10:18:38 --> URI Class Initialized
INFO - 2022-05-11 10:18:38 --> Router Class Initialized
INFO - 2022-05-11 10:18:38 --> Output Class Initialized
INFO - 2022-05-11 10:18:38 --> Security Class Initialized
DEBUG - 2022-05-11 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:18:38 --> Input Class Initialized
INFO - 2022-05-11 10:18:38 --> Language Class Initialized
INFO - 2022-05-11 10:18:38 --> Language Class Initialized
INFO - 2022-05-11 10:18:38 --> Config Class Initialized
INFO - 2022-05-11 10:18:38 --> Loader Class Initialized
INFO - 2022-05-11 10:18:38 --> Helper loaded: url_helper
INFO - 2022-05-11 10:18:38 --> Database Driver Class Initialized
INFO - 2022-05-11 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:18:38 --> Controller Class Initialized
DEBUG - 2022-05-11 10:18:38 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:18:38 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:18:38 --> Model Class Initialized
DEBUG - 2022-05-11 10:18:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:18:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:18:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:18:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:18:38 --> Final output sent to browser
DEBUG - 2022-05-11 10:18:38 --> Total execution time: 0.0469
INFO - 2022-05-11 10:20:18 --> Config Class Initialized
INFO - 2022-05-11 10:20:18 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:20:18 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:20:18 --> Utf8 Class Initialized
INFO - 2022-05-11 10:20:18 --> URI Class Initialized
INFO - 2022-05-11 10:20:18 --> Router Class Initialized
INFO - 2022-05-11 10:20:18 --> Output Class Initialized
INFO - 2022-05-11 10:20:18 --> Security Class Initialized
DEBUG - 2022-05-11 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:20:18 --> Input Class Initialized
INFO - 2022-05-11 10:20:18 --> Language Class Initialized
INFO - 2022-05-11 10:20:18 --> Language Class Initialized
INFO - 2022-05-11 10:20:18 --> Config Class Initialized
INFO - 2022-05-11 10:20:18 --> Loader Class Initialized
INFO - 2022-05-11 10:20:18 --> Helper loaded: url_helper
INFO - 2022-05-11 10:20:18 --> Database Driver Class Initialized
INFO - 2022-05-11 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:20:18 --> Controller Class Initialized
DEBUG - 2022-05-11 10:20:18 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:20:18 --> Model Class Initialized
DEBUG - 2022-05-11 10:20:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:20:18 --> Model Class Initialized
DEBUG - 2022-05-11 10:20:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:20:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:20:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:20:18 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:20:18 --> Final output sent to browser
DEBUG - 2022-05-11 10:20:18 --> Total execution time: 0.0485
INFO - 2022-05-11 10:20:28 --> Config Class Initialized
INFO - 2022-05-11 10:20:28 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:20:28 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:20:28 --> Utf8 Class Initialized
INFO - 2022-05-11 10:20:28 --> URI Class Initialized
INFO - 2022-05-11 10:20:28 --> Router Class Initialized
INFO - 2022-05-11 10:20:28 --> Output Class Initialized
INFO - 2022-05-11 10:20:28 --> Security Class Initialized
DEBUG - 2022-05-11 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:20:28 --> Input Class Initialized
INFO - 2022-05-11 10:20:28 --> Language Class Initialized
INFO - 2022-05-11 10:20:28 --> Language Class Initialized
INFO - 2022-05-11 10:20:28 --> Config Class Initialized
INFO - 2022-05-11 10:20:28 --> Loader Class Initialized
INFO - 2022-05-11 10:20:28 --> Helper loaded: url_helper
INFO - 2022-05-11 10:20:28 --> Database Driver Class Initialized
INFO - 2022-05-11 10:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:20:28 --> Controller Class Initialized
DEBUG - 2022-05-11 10:20:28 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:20:28 --> Model Class Initialized
DEBUG - 2022-05-11 10:20:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:20:28 --> Model Class Initialized
INFO - 2022-05-11 10:20:28 --> Upload Class Initialized
INFO - 2022-05-11 10:20:28 --> Config Class Initialized
INFO - 2022-05-11 10:20:28 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:20:28 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:20:28 --> Utf8 Class Initialized
INFO - 2022-05-11 10:20:28 --> URI Class Initialized
INFO - 2022-05-11 10:20:28 --> Router Class Initialized
INFO - 2022-05-11 10:20:28 --> Output Class Initialized
INFO - 2022-05-11 10:20:28 --> Security Class Initialized
DEBUG - 2022-05-11 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:20:28 --> Input Class Initialized
INFO - 2022-05-11 10:20:28 --> Language Class Initialized
INFO - 2022-05-11 10:20:28 --> Language Class Initialized
INFO - 2022-05-11 10:20:28 --> Config Class Initialized
INFO - 2022-05-11 10:20:28 --> Loader Class Initialized
INFO - 2022-05-11 10:20:28 --> Helper loaded: url_helper
INFO - 2022-05-11 10:20:28 --> Database Driver Class Initialized
INFO - 2022-05-11 10:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:20:28 --> Controller Class Initialized
DEBUG - 2022-05-11 10:20:28 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:20:28 --> Model Class Initialized
DEBUG - 2022-05-11 10:20:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:20:28 --> Model Class Initialized
DEBUG - 2022-05-11 10:20:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:20:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:20:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:20:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:20:28 --> Final output sent to browser
DEBUG - 2022-05-11 10:20:28 --> Total execution time: 0.0486
INFO - 2022-05-11 10:21:14 --> Config Class Initialized
INFO - 2022-05-11 10:21:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:14 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:14 --> URI Class Initialized
INFO - 2022-05-11 10:21:14 --> Router Class Initialized
INFO - 2022-05-11 10:21:14 --> Output Class Initialized
INFO - 2022-05-11 10:21:14 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:14 --> Input Class Initialized
INFO - 2022-05-11 10:21:14 --> Language Class Initialized
INFO - 2022-05-11 10:21:14 --> Language Class Initialized
INFO - 2022-05-11 10:21:14 --> Config Class Initialized
INFO - 2022-05-11 10:21:14 --> Loader Class Initialized
INFO - 2022-05-11 10:21:14 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:14 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:14 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:21:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:21:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:21:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:21:14 --> Final output sent to browser
DEBUG - 2022-05-11 10:21:14 --> Total execution time: 0.0296
INFO - 2022-05-11 10:21:26 --> Config Class Initialized
INFO - 2022-05-11 10:21:26 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:26 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:26 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:26 --> URI Class Initialized
INFO - 2022-05-11 10:21:26 --> Router Class Initialized
INFO - 2022-05-11 10:21:26 --> Output Class Initialized
INFO - 2022-05-11 10:21:26 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:26 --> Input Class Initialized
INFO - 2022-05-11 10:21:26 --> Language Class Initialized
INFO - 2022-05-11 10:21:26 --> Language Class Initialized
INFO - 2022-05-11 10:21:26 --> Config Class Initialized
INFO - 2022-05-11 10:21:26 --> Loader Class Initialized
INFO - 2022-05-11 10:21:26 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:26 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:26 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:26 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:26 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:26 --> Model Class Initialized
INFO - 2022-05-11 10:21:26 --> Config Class Initialized
INFO - 2022-05-11 10:21:26 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:26 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:26 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:26 --> URI Class Initialized
INFO - 2022-05-11 10:21:26 --> Router Class Initialized
INFO - 2022-05-11 10:21:26 --> Output Class Initialized
INFO - 2022-05-11 10:21:26 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:26 --> Input Class Initialized
INFO - 2022-05-11 10:21:26 --> Language Class Initialized
INFO - 2022-05-11 10:21:26 --> Language Class Initialized
INFO - 2022-05-11 10:21:26 --> Config Class Initialized
INFO - 2022-05-11 10:21:26 --> Loader Class Initialized
INFO - 2022-05-11 10:21:26 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:26 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:26 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:26 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:26 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:26 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:21:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:21:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:21:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:21:26 --> Final output sent to browser
DEBUG - 2022-05-11 10:21:26 --> Total execution time: 0.0403
INFO - 2022-05-11 10:21:32 --> Config Class Initialized
INFO - 2022-05-11 10:21:32 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:32 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:32 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:32 --> URI Class Initialized
INFO - 2022-05-11 10:21:32 --> Router Class Initialized
INFO - 2022-05-11 10:21:32 --> Output Class Initialized
INFO - 2022-05-11 10:21:32 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:32 --> Input Class Initialized
INFO - 2022-05-11 10:21:32 --> Language Class Initialized
INFO - 2022-05-11 10:21:32 --> Language Class Initialized
INFO - 2022-05-11 10:21:32 --> Config Class Initialized
INFO - 2022-05-11 10:21:32 --> Loader Class Initialized
INFO - 2022-05-11 10:21:32 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:32 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:32 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:32 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:32 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:32 --> Model Class Initialized
INFO - 2022-05-11 10:21:32 --> Config Class Initialized
INFO - 2022-05-11 10:21:32 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:32 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:32 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:32 --> URI Class Initialized
INFO - 2022-05-11 10:21:32 --> Router Class Initialized
INFO - 2022-05-11 10:21:32 --> Output Class Initialized
INFO - 2022-05-11 10:21:32 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:32 --> Input Class Initialized
INFO - 2022-05-11 10:21:32 --> Language Class Initialized
INFO - 2022-05-11 10:21:32 --> Language Class Initialized
INFO - 2022-05-11 10:21:32 --> Config Class Initialized
INFO - 2022-05-11 10:21:32 --> Loader Class Initialized
INFO - 2022-05-11 10:21:32 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:32 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:33 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:33 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:33 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:33 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:21:33 --> Final output sent to browser
DEBUG - 2022-05-11 10:21:33 --> Total execution time: 0.0518
INFO - 2022-05-11 10:21:33 --> Config Class Initialized
INFO - 2022-05-11 10:21:33 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:33 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:33 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:33 --> URI Class Initialized
INFO - 2022-05-11 10:21:33 --> Router Class Initialized
INFO - 2022-05-11 10:21:33 --> Output Class Initialized
INFO - 2022-05-11 10:21:33 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:33 --> Input Class Initialized
INFO - 2022-05-11 10:21:33 --> Language Class Initialized
INFO - 2022-05-11 10:21:33 --> Language Class Initialized
INFO - 2022-05-11 10:21:33 --> Config Class Initialized
INFO - 2022-05-11 10:21:33 --> Loader Class Initialized
INFO - 2022-05-11 10:21:33 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:33 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:33 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:33 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:33 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:33 --> Model Class Initialized
INFO - 2022-05-11 10:21:33 --> Config Class Initialized
INFO - 2022-05-11 10:21:33 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:33 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:33 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:33 --> URI Class Initialized
INFO - 2022-05-11 10:21:33 --> Router Class Initialized
INFO - 2022-05-11 10:21:33 --> Output Class Initialized
INFO - 2022-05-11 10:21:33 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:33 --> Input Class Initialized
INFO - 2022-05-11 10:21:33 --> Language Class Initialized
INFO - 2022-05-11 10:21:33 --> Language Class Initialized
INFO - 2022-05-11 10:21:33 --> Config Class Initialized
INFO - 2022-05-11 10:21:33 --> Loader Class Initialized
INFO - 2022-05-11 10:21:33 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:33 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:33 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:33 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:33 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:33 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:21:33 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:21:33 --> Final output sent to browser
DEBUG - 2022-05-11 10:21:33 --> Total execution time: 0.0588
INFO - 2022-05-11 10:21:43 --> Config Class Initialized
INFO - 2022-05-11 10:21:43 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:43 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:43 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:43 --> URI Class Initialized
INFO - 2022-05-11 10:21:43 --> Router Class Initialized
INFO - 2022-05-11 10:21:43 --> Output Class Initialized
INFO - 2022-05-11 10:21:43 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:43 --> Input Class Initialized
INFO - 2022-05-11 10:21:43 --> Language Class Initialized
INFO - 2022-05-11 10:21:43 --> Language Class Initialized
INFO - 2022-05-11 10:21:43 --> Config Class Initialized
INFO - 2022-05-11 10:21:43 --> Loader Class Initialized
INFO - 2022-05-11 10:21:43 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:43 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:43 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:43 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:43 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:43 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:43 --> Model Class Initialized
INFO - 2022-05-11 10:21:43 --> Config Class Initialized
INFO - 2022-05-11 10:21:43 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:43 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:43 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:43 --> URI Class Initialized
INFO - 2022-05-11 10:21:43 --> Router Class Initialized
INFO - 2022-05-11 10:21:43 --> Output Class Initialized
INFO - 2022-05-11 10:21:43 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:43 --> Input Class Initialized
INFO - 2022-05-11 10:21:43 --> Language Class Initialized
INFO - 2022-05-11 10:21:43 --> Language Class Initialized
INFO - 2022-05-11 10:21:43 --> Config Class Initialized
INFO - 2022-05-11 10:21:43 --> Loader Class Initialized
INFO - 2022-05-11 10:21:43 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:43 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:43 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:43 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:43 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:43 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:43 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:43 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:21:43 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:21:43 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:21:43 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:21:43 --> Final output sent to browser
DEBUG - 2022-05-11 10:21:43 --> Total execution time: 0.0408
INFO - 2022-05-11 10:21:45 --> Config Class Initialized
INFO - 2022-05-11 10:21:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:45 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:45 --> URI Class Initialized
INFO - 2022-05-11 10:21:45 --> Router Class Initialized
INFO - 2022-05-11 10:21:45 --> Output Class Initialized
INFO - 2022-05-11 10:21:45 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:45 --> Input Class Initialized
INFO - 2022-05-11 10:21:45 --> Language Class Initialized
INFO - 2022-05-11 10:21:45 --> Language Class Initialized
INFO - 2022-05-11 10:21:45 --> Config Class Initialized
INFO - 2022-05-11 10:21:45 --> Loader Class Initialized
INFO - 2022-05-11 10:21:45 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:45 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:45 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:45 --> Model Class Initialized
INFO - 2022-05-11 10:21:45 --> Config Class Initialized
INFO - 2022-05-11 10:21:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:21:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:21:45 --> Utf8 Class Initialized
INFO - 2022-05-11 10:21:45 --> URI Class Initialized
INFO - 2022-05-11 10:21:45 --> Router Class Initialized
INFO - 2022-05-11 10:21:45 --> Output Class Initialized
INFO - 2022-05-11 10:21:45 --> Security Class Initialized
DEBUG - 2022-05-11 10:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:21:45 --> Input Class Initialized
INFO - 2022-05-11 10:21:45 --> Language Class Initialized
INFO - 2022-05-11 10:21:45 --> Language Class Initialized
INFO - 2022-05-11 10:21:45 --> Config Class Initialized
INFO - 2022-05-11 10:21:45 --> Loader Class Initialized
INFO - 2022-05-11 10:21:45 --> Helper loaded: url_helper
INFO - 2022-05-11 10:21:45 --> Database Driver Class Initialized
INFO - 2022-05-11 10:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:21:45 --> Controller Class Initialized
DEBUG - 2022-05-11 10:21:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:21:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:21:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:21:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:21:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:21:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:21:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:21:45 --> Final output sent to browser
DEBUG - 2022-05-11 10:21:45 --> Total execution time: 0.0327
INFO - 2022-05-11 10:23:08 --> Config Class Initialized
INFO - 2022-05-11 10:23:08 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:08 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:08 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:08 --> URI Class Initialized
INFO - 2022-05-11 10:23:08 --> Router Class Initialized
INFO - 2022-05-11 10:23:08 --> Output Class Initialized
INFO - 2022-05-11 10:23:08 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:08 --> Input Class Initialized
INFO - 2022-05-11 10:23:08 --> Language Class Initialized
INFO - 2022-05-11 10:23:08 --> Language Class Initialized
INFO - 2022-05-11 10:23:08 --> Config Class Initialized
INFO - 2022-05-11 10:23:08 --> Loader Class Initialized
INFO - 2022-05-11 10:23:08 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:08 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:08 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:08 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:08 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:08 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:23:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:23:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:23:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:23:08 --> Final output sent to browser
DEBUG - 2022-05-11 10:23:08 --> Total execution time: 0.0398
INFO - 2022-05-11 10:23:09 --> Config Class Initialized
INFO - 2022-05-11 10:23:09 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:09 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:09 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:09 --> URI Class Initialized
INFO - 2022-05-11 10:23:09 --> Router Class Initialized
INFO - 2022-05-11 10:23:09 --> Output Class Initialized
INFO - 2022-05-11 10:23:09 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:09 --> Input Class Initialized
INFO - 2022-05-11 10:23:09 --> Language Class Initialized
INFO - 2022-05-11 10:23:09 --> Language Class Initialized
INFO - 2022-05-11 10:23:09 --> Config Class Initialized
INFO - 2022-05-11 10:23:09 --> Loader Class Initialized
INFO - 2022-05-11 10:23:09 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:09 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:09 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:09 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:09 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:09 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:09 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:09 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:23:09 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:23:09 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 10:23:09 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:23:09 --> Final output sent to browser
DEBUG - 2022-05-11 10:23:09 --> Total execution time: 0.0542
INFO - 2022-05-11 10:23:13 --> Config Class Initialized
INFO - 2022-05-11 10:23:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:13 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:13 --> URI Class Initialized
INFO - 2022-05-11 10:23:13 --> Router Class Initialized
INFO - 2022-05-11 10:23:13 --> Output Class Initialized
INFO - 2022-05-11 10:23:13 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:13 --> Input Class Initialized
INFO - 2022-05-11 10:23:13 --> Language Class Initialized
INFO - 2022-05-11 10:23:13 --> Language Class Initialized
INFO - 2022-05-11 10:23:13 --> Config Class Initialized
INFO - 2022-05-11 10:23:13 --> Loader Class Initialized
INFO - 2022-05-11 10:23:13 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:13 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:13 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:13 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:13 --> Model Class Initialized
INFO - 2022-05-11 10:23:13 --> Config Class Initialized
INFO - 2022-05-11 10:23:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:13 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:13 --> URI Class Initialized
INFO - 2022-05-11 10:23:13 --> Router Class Initialized
INFO - 2022-05-11 10:23:13 --> Output Class Initialized
INFO - 2022-05-11 10:23:13 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:13 --> Input Class Initialized
INFO - 2022-05-11 10:23:13 --> Language Class Initialized
INFO - 2022-05-11 10:23:13 --> Language Class Initialized
INFO - 2022-05-11 10:23:13 --> Config Class Initialized
INFO - 2022-05-11 10:23:13 --> Loader Class Initialized
INFO - 2022-05-11 10:23:13 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:13 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:13 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:13 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:13 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:23:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:23:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_category.php
DEBUG - 2022-05-11 10:23:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:23:13 --> Final output sent to browser
DEBUG - 2022-05-11 10:23:13 --> Total execution time: 0.0556
INFO - 2022-05-11 10:23:16 --> Config Class Initialized
INFO - 2022-05-11 10:23:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:16 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:16 --> URI Class Initialized
INFO - 2022-05-11 10:23:16 --> Router Class Initialized
INFO - 2022-05-11 10:23:16 --> Output Class Initialized
INFO - 2022-05-11 10:23:16 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:16 --> Input Class Initialized
INFO - 2022-05-11 10:23:16 --> Language Class Initialized
INFO - 2022-05-11 10:23:16 --> Language Class Initialized
INFO - 2022-05-11 10:23:16 --> Config Class Initialized
INFO - 2022-05-11 10:23:16 --> Loader Class Initialized
INFO - 2022-05-11 10:23:16 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:16 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:16 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:16 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:16 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:16 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:23:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:23:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:23:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:23:16 --> Final output sent to browser
DEBUG - 2022-05-11 10:23:16 --> Total execution time: 0.0654
INFO - 2022-05-11 10:23:28 --> Config Class Initialized
INFO - 2022-05-11 10:23:28 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:28 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:28 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:28 --> URI Class Initialized
INFO - 2022-05-11 10:23:28 --> Router Class Initialized
INFO - 2022-05-11 10:23:28 --> Output Class Initialized
INFO - 2022-05-11 10:23:28 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:28 --> Input Class Initialized
INFO - 2022-05-11 10:23:28 --> Language Class Initialized
INFO - 2022-05-11 10:23:28 --> Language Class Initialized
INFO - 2022-05-11 10:23:28 --> Config Class Initialized
INFO - 2022-05-11 10:23:28 --> Loader Class Initialized
INFO - 2022-05-11 10:23:28 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:28 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:28 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:28 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:28 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:28 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:28 --> Model Class Initialized
INFO - 2022-05-11 10:23:28 --> Upload Class Initialized
INFO - 2022-05-11 10:23:28 --> Config Class Initialized
INFO - 2022-05-11 10:23:28 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:28 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:28 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:28 --> URI Class Initialized
INFO - 2022-05-11 10:23:28 --> Router Class Initialized
INFO - 2022-05-11 10:23:28 --> Output Class Initialized
INFO - 2022-05-11 10:23:28 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:28 --> Input Class Initialized
INFO - 2022-05-11 10:23:28 --> Language Class Initialized
INFO - 2022-05-11 10:23:28 --> Language Class Initialized
INFO - 2022-05-11 10:23:28 --> Config Class Initialized
INFO - 2022-05-11 10:23:28 --> Loader Class Initialized
INFO - 2022-05-11 10:23:28 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:28 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:29 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:29 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:29 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:29 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:23:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:23:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:23:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:23:29 --> Final output sent to browser
DEBUG - 2022-05-11 10:23:29 --> Total execution time: 0.0276
INFO - 2022-05-11 10:23:54 --> Config Class Initialized
INFO - 2022-05-11 10:23:54 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:54 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:54 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:54 --> URI Class Initialized
INFO - 2022-05-11 10:23:54 --> Router Class Initialized
INFO - 2022-05-11 10:23:54 --> Output Class Initialized
INFO - 2022-05-11 10:23:54 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:54 --> Input Class Initialized
INFO - 2022-05-11 10:23:54 --> Language Class Initialized
INFO - 2022-05-11 10:23:54 --> Language Class Initialized
INFO - 2022-05-11 10:23:54 --> Config Class Initialized
INFO - 2022-05-11 10:23:54 --> Loader Class Initialized
INFO - 2022-05-11 10:23:54 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:54 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:54 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:54 --> Model Class Initialized
INFO - 2022-05-11 10:23:54 --> Upload Class Initialized
INFO - 2022-05-11 10:23:54 --> Config Class Initialized
INFO - 2022-05-11 10:23:54 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:23:54 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:23:54 --> Utf8 Class Initialized
INFO - 2022-05-11 10:23:54 --> URI Class Initialized
INFO - 2022-05-11 10:23:54 --> Router Class Initialized
INFO - 2022-05-11 10:23:54 --> Output Class Initialized
INFO - 2022-05-11 10:23:54 --> Security Class Initialized
DEBUG - 2022-05-11 10:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:23:54 --> Input Class Initialized
INFO - 2022-05-11 10:23:54 --> Language Class Initialized
INFO - 2022-05-11 10:23:54 --> Language Class Initialized
INFO - 2022-05-11 10:23:54 --> Config Class Initialized
INFO - 2022-05-11 10:23:54 --> Loader Class Initialized
INFO - 2022-05-11 10:23:54 --> Helper loaded: url_helper
INFO - 2022-05-11 10:23:54 --> Database Driver Class Initialized
INFO - 2022-05-11 10:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:23:54 --> Controller Class Initialized
DEBUG - 2022-05-11 10:23:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:23:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:23:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:23:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:23:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:23:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:23:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:23:54 --> Final output sent to browser
DEBUG - 2022-05-11 10:23:54 --> Total execution time: 0.0520
INFO - 2022-05-11 10:24:11 --> Config Class Initialized
INFO - 2022-05-11 10:24:11 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:11 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:11 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:11 --> URI Class Initialized
INFO - 2022-05-11 10:24:11 --> Router Class Initialized
INFO - 2022-05-11 10:24:11 --> Output Class Initialized
INFO - 2022-05-11 10:24:11 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:11 --> Input Class Initialized
INFO - 2022-05-11 10:24:11 --> Language Class Initialized
INFO - 2022-05-11 10:24:11 --> Language Class Initialized
INFO - 2022-05-11 10:24:11 --> Config Class Initialized
INFO - 2022-05-11 10:24:11 --> Loader Class Initialized
INFO - 2022-05-11 10:24:11 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:11 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:11 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:11 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:11 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:11 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:11 --> Model Class Initialized
INFO - 2022-05-11 10:24:11 --> Upload Class Initialized
INFO - 2022-05-11 10:24:11 --> Config Class Initialized
INFO - 2022-05-11 10:24:11 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:11 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:11 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:11 --> URI Class Initialized
INFO - 2022-05-11 10:24:11 --> Router Class Initialized
INFO - 2022-05-11 10:24:11 --> Output Class Initialized
INFO - 2022-05-11 10:24:11 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:11 --> Input Class Initialized
INFO - 2022-05-11 10:24:11 --> Language Class Initialized
INFO - 2022-05-11 10:24:11 --> Language Class Initialized
INFO - 2022-05-11 10:24:11 --> Config Class Initialized
INFO - 2022-05-11 10:24:11 --> Loader Class Initialized
INFO - 2022-05-11 10:24:11 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:11 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:11 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:11 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:11 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:11 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:11 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:11 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:11 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:11 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-11 10:24:11 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:11 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:11 --> Total execution time: 0.0297
INFO - 2022-05-11 10:24:12 --> Config Class Initialized
INFO - 2022-05-11 10:24:12 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:12 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:12 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:12 --> URI Class Initialized
INFO - 2022-05-11 10:24:12 --> Router Class Initialized
INFO - 2022-05-11 10:24:12 --> Output Class Initialized
INFO - 2022-05-11 10:24:12 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:12 --> Input Class Initialized
INFO - 2022-05-11 10:24:12 --> Language Class Initialized
INFO - 2022-05-11 10:24:12 --> Language Class Initialized
INFO - 2022-05-11 10:24:12 --> Config Class Initialized
INFO - 2022-05-11 10:24:12 --> Loader Class Initialized
INFO - 2022-05-11 10:24:12 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:12 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:12 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:12 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:12 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:12 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:24:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:12 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:12 --> Total execution time: 0.0449
INFO - 2022-05-11 10:24:32 --> Config Class Initialized
INFO - 2022-05-11 10:24:32 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:32 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:32 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:32 --> URI Class Initialized
INFO - 2022-05-11 10:24:32 --> Router Class Initialized
INFO - 2022-05-11 10:24:32 --> Output Class Initialized
INFO - 2022-05-11 10:24:32 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:32 --> Input Class Initialized
INFO - 2022-05-11 10:24:32 --> Language Class Initialized
INFO - 2022-05-11 10:24:32 --> Language Class Initialized
INFO - 2022-05-11 10:24:32 --> Config Class Initialized
INFO - 2022-05-11 10:24:32 --> Loader Class Initialized
INFO - 2022-05-11 10:24:32 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:32 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:32 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:32 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:32 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:32 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:24:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:32 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:32 --> Total execution time: 0.0484
INFO - 2022-05-11 10:24:36 --> Config Class Initialized
INFO - 2022-05-11 10:24:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:36 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:36 --> URI Class Initialized
INFO - 2022-05-11 10:24:36 --> Router Class Initialized
INFO - 2022-05-11 10:24:36 --> Output Class Initialized
INFO - 2022-05-11 10:24:36 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:36 --> Input Class Initialized
INFO - 2022-05-11 10:24:36 --> Language Class Initialized
INFO - 2022-05-11 10:24:36 --> Language Class Initialized
INFO - 2022-05-11 10:24:36 --> Config Class Initialized
INFO - 2022-05-11 10:24:36 --> Loader Class Initialized
INFO - 2022-05-11 10:24:36 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:36 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:36 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:36 --> Model Class Initialized
INFO - 2022-05-11 10:24:36 --> Config Class Initialized
INFO - 2022-05-11 10:24:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:36 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:36 --> URI Class Initialized
INFO - 2022-05-11 10:24:36 --> Router Class Initialized
INFO - 2022-05-11 10:24:36 --> Output Class Initialized
INFO - 2022-05-11 10:24:36 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:36 --> Input Class Initialized
INFO - 2022-05-11 10:24:36 --> Language Class Initialized
INFO - 2022-05-11 10:24:36 --> Language Class Initialized
INFO - 2022-05-11 10:24:36 --> Config Class Initialized
INFO - 2022-05-11 10:24:36 --> Loader Class Initialized
INFO - 2022-05-11 10:24:36 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:36 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:36 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:24:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:36 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:36 --> Total execution time: 0.0409
INFO - 2022-05-11 10:24:39 --> Config Class Initialized
INFO - 2022-05-11 10:24:39 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:39 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:39 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:39 --> URI Class Initialized
INFO - 2022-05-11 10:24:39 --> Router Class Initialized
INFO - 2022-05-11 10:24:39 --> Output Class Initialized
INFO - 2022-05-11 10:24:39 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:39 --> Input Class Initialized
INFO - 2022-05-11 10:24:39 --> Language Class Initialized
INFO - 2022-05-11 10:24:39 --> Language Class Initialized
INFO - 2022-05-11 10:24:39 --> Config Class Initialized
INFO - 2022-05-11 10:24:39 --> Loader Class Initialized
INFO - 2022-05-11 10:24:39 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:39 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:39 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:39 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:39 --> Model Class Initialized
INFO - 2022-05-11 10:24:39 --> Config Class Initialized
INFO - 2022-05-11 10:24:39 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:39 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:39 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:39 --> URI Class Initialized
INFO - 2022-05-11 10:24:39 --> Router Class Initialized
INFO - 2022-05-11 10:24:39 --> Output Class Initialized
INFO - 2022-05-11 10:24:39 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:39 --> Input Class Initialized
INFO - 2022-05-11 10:24:39 --> Language Class Initialized
INFO - 2022-05-11 10:24:39 --> Language Class Initialized
INFO - 2022-05-11 10:24:39 --> Config Class Initialized
INFO - 2022-05-11 10:24:39 --> Loader Class Initialized
INFO - 2022-05-11 10:24:39 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:39 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:39 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:39 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:39 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:24:39 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:39 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:39 --> Total execution time: 0.0421
INFO - 2022-05-11 10:24:45 --> Config Class Initialized
INFO - 2022-05-11 10:24:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:45 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:45 --> URI Class Initialized
INFO - 2022-05-11 10:24:45 --> Router Class Initialized
INFO - 2022-05-11 10:24:45 --> Output Class Initialized
INFO - 2022-05-11 10:24:45 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:45 --> Input Class Initialized
INFO - 2022-05-11 10:24:45 --> Language Class Initialized
INFO - 2022-05-11 10:24:45 --> Language Class Initialized
INFO - 2022-05-11 10:24:45 --> Config Class Initialized
INFO - 2022-05-11 10:24:45 --> Loader Class Initialized
INFO - 2022-05-11 10:24:45 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:45 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:45 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:45 --> Model Class Initialized
INFO - 2022-05-11 10:24:46 --> Config Class Initialized
INFO - 2022-05-11 10:24:46 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:46 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:46 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:46 --> URI Class Initialized
INFO - 2022-05-11 10:24:46 --> Router Class Initialized
INFO - 2022-05-11 10:24:46 --> Output Class Initialized
INFO - 2022-05-11 10:24:46 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:46 --> Input Class Initialized
INFO - 2022-05-11 10:24:46 --> Language Class Initialized
INFO - 2022-05-11 10:24:46 --> Language Class Initialized
INFO - 2022-05-11 10:24:46 --> Config Class Initialized
INFO - 2022-05-11 10:24:46 --> Loader Class Initialized
INFO - 2022-05-11 10:24:46 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:46 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:46 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:46 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:46 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:46 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_model.php
DEBUG - 2022-05-11 10:24:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:46 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:46 --> Total execution time: 0.0384
INFO - 2022-05-11 10:24:47 --> Config Class Initialized
INFO - 2022-05-11 10:24:47 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:47 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:47 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:47 --> URI Class Initialized
INFO - 2022-05-11 10:24:47 --> Router Class Initialized
INFO - 2022-05-11 10:24:47 --> Output Class Initialized
INFO - 2022-05-11 10:24:47 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:47 --> Input Class Initialized
INFO - 2022-05-11 10:24:47 --> Language Class Initialized
INFO - 2022-05-11 10:24:47 --> Language Class Initialized
INFO - 2022-05-11 10:24:47 --> Config Class Initialized
INFO - 2022-05-11 10:24:47 --> Loader Class Initialized
INFO - 2022-05-11 10:24:47 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:47 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:47 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:47 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:47 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:47 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 10:24:47 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:47 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:47 --> Total execution time: 0.0499
INFO - 2022-05-11 10:24:54 --> Config Class Initialized
INFO - 2022-05-11 10:24:54 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:54 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:54 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:54 --> URI Class Initialized
INFO - 2022-05-11 10:24:54 --> Router Class Initialized
INFO - 2022-05-11 10:24:54 --> Output Class Initialized
INFO - 2022-05-11 10:24:54 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:54 --> Input Class Initialized
INFO - 2022-05-11 10:24:54 --> Language Class Initialized
INFO - 2022-05-11 10:24:54 --> Language Class Initialized
INFO - 2022-05-11 10:24:54 --> Config Class Initialized
INFO - 2022-05-11 10:24:54 --> Loader Class Initialized
INFO - 2022-05-11 10:24:54 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:54 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:54 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:54 --> Model Class Initialized
INFO - 2022-05-11 10:24:54 --> Config Class Initialized
INFO - 2022-05-11 10:24:54 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:54 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:54 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:54 --> URI Class Initialized
INFO - 2022-05-11 10:24:54 --> Router Class Initialized
INFO - 2022-05-11 10:24:54 --> Output Class Initialized
INFO - 2022-05-11 10:24:54 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:54 --> Input Class Initialized
INFO - 2022-05-11 10:24:54 --> Language Class Initialized
INFO - 2022-05-11 10:24:54 --> Language Class Initialized
INFO - 2022-05-11 10:24:54 --> Config Class Initialized
INFO - 2022-05-11 10:24:54 --> Loader Class Initialized
INFO - 2022-05-11 10:24:54 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:54 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:54 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 10:24:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:54 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:54 --> Total execution time: 0.0666
INFO - 2022-05-11 10:24:59 --> Config Class Initialized
INFO - 2022-05-11 10:24:59 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:59 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:59 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:59 --> URI Class Initialized
INFO - 2022-05-11 10:24:59 --> Router Class Initialized
INFO - 2022-05-11 10:24:59 --> Output Class Initialized
INFO - 2022-05-11 10:24:59 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:59 --> Input Class Initialized
INFO - 2022-05-11 10:24:59 --> Language Class Initialized
INFO - 2022-05-11 10:24:59 --> Language Class Initialized
INFO - 2022-05-11 10:24:59 --> Config Class Initialized
INFO - 2022-05-11 10:24:59 --> Loader Class Initialized
INFO - 2022-05-11 10:24:59 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:59 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:59 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:59 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:59 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:59 --> Model Class Initialized
INFO - 2022-05-11 10:24:59 --> Config Class Initialized
INFO - 2022-05-11 10:24:59 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:24:59 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:24:59 --> Utf8 Class Initialized
INFO - 2022-05-11 10:24:59 --> URI Class Initialized
INFO - 2022-05-11 10:24:59 --> Router Class Initialized
INFO - 2022-05-11 10:24:59 --> Output Class Initialized
INFO - 2022-05-11 10:24:59 --> Security Class Initialized
DEBUG - 2022-05-11 10:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:24:59 --> Input Class Initialized
INFO - 2022-05-11 10:24:59 --> Language Class Initialized
INFO - 2022-05-11 10:24:59 --> Language Class Initialized
INFO - 2022-05-11 10:24:59 --> Config Class Initialized
INFO - 2022-05-11 10:24:59 --> Loader Class Initialized
INFO - 2022-05-11 10:24:59 --> Helper loaded: url_helper
INFO - 2022-05-11 10:24:59 --> Database Driver Class Initialized
INFO - 2022-05-11 10:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:24:59 --> Controller Class Initialized
DEBUG - 2022-05-11 10:24:59 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:24:59 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:24:59 --> Model Class Initialized
DEBUG - 2022-05-11 10:24:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:24:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:24:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-11 10:24:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:24:59 --> Final output sent to browser
DEBUG - 2022-05-11 10:24:59 --> Total execution time: 0.0409
INFO - 2022-05-11 10:25:00 --> Config Class Initialized
INFO - 2022-05-11 10:25:00 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:00 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:00 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:00 --> URI Class Initialized
INFO - 2022-05-11 10:25:00 --> Router Class Initialized
INFO - 2022-05-11 10:25:00 --> Output Class Initialized
INFO - 2022-05-11 10:25:00 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:00 --> Input Class Initialized
INFO - 2022-05-11 10:25:00 --> Language Class Initialized
INFO - 2022-05-11 10:25:00 --> Language Class Initialized
INFO - 2022-05-11 10:25:00 --> Config Class Initialized
INFO - 2022-05-11 10:25:00 --> Loader Class Initialized
INFO - 2022-05-11 10:25:00 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:00 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:00 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:00 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:00 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:00 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:25:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:25:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 10:25:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:25:00 --> Final output sent to browser
DEBUG - 2022-05-11 10:25:00 --> Total execution time: 0.0434
INFO - 2022-05-11 10:25:04 --> Config Class Initialized
INFO - 2022-05-11 10:25:04 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:04 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:04 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:04 --> URI Class Initialized
INFO - 2022-05-11 10:25:04 --> Router Class Initialized
INFO - 2022-05-11 10:25:04 --> Output Class Initialized
INFO - 2022-05-11 10:25:04 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:04 --> Input Class Initialized
INFO - 2022-05-11 10:25:04 --> Language Class Initialized
INFO - 2022-05-11 10:25:04 --> Language Class Initialized
INFO - 2022-05-11 10:25:04 --> Config Class Initialized
INFO - 2022-05-11 10:25:04 --> Loader Class Initialized
INFO - 2022-05-11 10:25:04 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:04 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:04 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:04 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:04 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:04 --> Model Class Initialized
INFO - 2022-05-11 10:25:04 --> Config Class Initialized
INFO - 2022-05-11 10:25:04 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:04 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:04 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:04 --> URI Class Initialized
INFO - 2022-05-11 10:25:04 --> Router Class Initialized
INFO - 2022-05-11 10:25:04 --> Output Class Initialized
INFO - 2022-05-11 10:25:04 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:04 --> Input Class Initialized
INFO - 2022-05-11 10:25:04 --> Language Class Initialized
INFO - 2022-05-11 10:25:04 --> Language Class Initialized
INFO - 2022-05-11 10:25:04 --> Config Class Initialized
INFO - 2022-05-11 10:25:04 --> Loader Class Initialized
INFO - 2022-05-11 10:25:04 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:04 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:04 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:04 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:04 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:04 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:25:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:25:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 10:25:04 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:25:04 --> Final output sent to browser
DEBUG - 2022-05-11 10:25:04 --> Total execution time: 0.0414
INFO - 2022-05-11 10:25:34 --> Config Class Initialized
INFO - 2022-05-11 10:25:34 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:34 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:34 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:34 --> URI Class Initialized
INFO - 2022-05-11 10:25:34 --> Router Class Initialized
INFO - 2022-05-11 10:25:34 --> Output Class Initialized
INFO - 2022-05-11 10:25:34 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:34 --> Input Class Initialized
INFO - 2022-05-11 10:25:34 --> Language Class Initialized
INFO - 2022-05-11 10:25:34 --> Language Class Initialized
INFO - 2022-05-11 10:25:34 --> Config Class Initialized
INFO - 2022-05-11 10:25:34 --> Loader Class Initialized
INFO - 2022-05-11 10:25:34 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:34 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:34 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:34 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:34 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:34 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:34 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:34 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:25:34 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:25:34 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:25:34 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:25:34 --> Final output sent to browser
DEBUG - 2022-05-11 10:25:34 --> Total execution time: 0.0519
INFO - 2022-05-11 10:25:36 --> Config Class Initialized
INFO - 2022-05-11 10:25:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:36 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:36 --> URI Class Initialized
INFO - 2022-05-11 10:25:36 --> Router Class Initialized
INFO - 2022-05-11 10:25:36 --> Output Class Initialized
INFO - 2022-05-11 10:25:36 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:36 --> Input Class Initialized
INFO - 2022-05-11 10:25:36 --> Language Class Initialized
INFO - 2022-05-11 10:25:36 --> Language Class Initialized
INFO - 2022-05-11 10:25:36 --> Config Class Initialized
INFO - 2022-05-11 10:25:36 --> Loader Class Initialized
INFO - 2022-05-11 10:25:36 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:36 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:36 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:25:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:25:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:25:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:25:36 --> Final output sent to browser
DEBUG - 2022-05-11 10:25:36 --> Total execution time: 0.0527
INFO - 2022-05-11 10:25:46 --> Config Class Initialized
INFO - 2022-05-11 10:25:46 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:46 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:46 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:46 --> URI Class Initialized
INFO - 2022-05-11 10:25:46 --> Router Class Initialized
INFO - 2022-05-11 10:25:46 --> Output Class Initialized
INFO - 2022-05-11 10:25:46 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:46 --> Input Class Initialized
INFO - 2022-05-11 10:25:46 --> Language Class Initialized
INFO - 2022-05-11 10:25:46 --> Language Class Initialized
INFO - 2022-05-11 10:25:46 --> Config Class Initialized
INFO - 2022-05-11 10:25:46 --> Loader Class Initialized
INFO - 2022-05-11 10:25:46 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:46 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:46 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:46 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:46 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:46 --> Model Class Initialized
INFO - 2022-05-11 10:25:46 --> Final output sent to browser
DEBUG - 2022-05-11 10:25:46 --> Total execution time: 0.0511
INFO - 2022-05-11 10:25:50 --> Config Class Initialized
INFO - 2022-05-11 10:25:50 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:25:50 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:25:50 --> Utf8 Class Initialized
INFO - 2022-05-11 10:25:50 --> URI Class Initialized
INFO - 2022-05-11 10:25:50 --> Router Class Initialized
INFO - 2022-05-11 10:25:50 --> Output Class Initialized
INFO - 2022-05-11 10:25:50 --> Security Class Initialized
DEBUG - 2022-05-11 10:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:25:50 --> Input Class Initialized
INFO - 2022-05-11 10:25:50 --> Language Class Initialized
INFO - 2022-05-11 10:25:50 --> Language Class Initialized
INFO - 2022-05-11 10:25:50 --> Config Class Initialized
INFO - 2022-05-11 10:25:50 --> Loader Class Initialized
INFO - 2022-05-11 10:25:50 --> Helper loaded: url_helper
INFO - 2022-05-11 10:25:50 --> Database Driver Class Initialized
INFO - 2022-05-11 10:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:25:50 --> Controller Class Initialized
DEBUG - 2022-05-11 10:25:50 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:25:50 --> Model Class Initialized
DEBUG - 2022-05-11 10:25:50 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:25:50 --> Model Class Initialized
INFO - 2022-05-11 10:25:50 --> Final output sent to browser
DEBUG - 2022-05-11 10:25:50 --> Total execution time: 0.0421
INFO - 2022-05-11 10:26:45 --> Config Class Initialized
INFO - 2022-05-11 10:26:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:26:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:26:45 --> Utf8 Class Initialized
INFO - 2022-05-11 10:26:45 --> URI Class Initialized
INFO - 2022-05-11 10:26:45 --> Router Class Initialized
INFO - 2022-05-11 10:26:45 --> Output Class Initialized
INFO - 2022-05-11 10:26:45 --> Security Class Initialized
DEBUG - 2022-05-11 10:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:26:45 --> Input Class Initialized
INFO - 2022-05-11 10:26:45 --> Language Class Initialized
INFO - 2022-05-11 10:26:45 --> Language Class Initialized
INFO - 2022-05-11 10:26:45 --> Config Class Initialized
INFO - 2022-05-11 10:26:45 --> Loader Class Initialized
INFO - 2022-05-11 10:26:45 --> Helper loaded: url_helper
INFO - 2022-05-11 10:26:45 --> Database Driver Class Initialized
INFO - 2022-05-11 10:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:26:45 --> Controller Class Initialized
DEBUG - 2022-05-11 10:26:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:26:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:26:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:26:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:26:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:26:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:26:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:26:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:26:45 --> Final output sent to browser
DEBUG - 2022-05-11 10:26:45 --> Total execution time: 0.0311
INFO - 2022-05-11 10:27:48 --> Config Class Initialized
INFO - 2022-05-11 10:27:48 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:27:48 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:27:48 --> Utf8 Class Initialized
INFO - 2022-05-11 10:27:48 --> URI Class Initialized
INFO - 2022-05-11 10:27:48 --> Router Class Initialized
INFO - 2022-05-11 10:27:48 --> Output Class Initialized
INFO - 2022-05-11 10:27:48 --> Security Class Initialized
DEBUG - 2022-05-11 10:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:27:48 --> Input Class Initialized
INFO - 2022-05-11 10:27:48 --> Language Class Initialized
INFO - 2022-05-11 10:27:48 --> Language Class Initialized
INFO - 2022-05-11 10:27:48 --> Config Class Initialized
INFO - 2022-05-11 10:27:48 --> Loader Class Initialized
INFO - 2022-05-11 10:27:48 --> Helper loaded: url_helper
INFO - 2022-05-11 10:27:48 --> Database Driver Class Initialized
INFO - 2022-05-11 10:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:27:48 --> Controller Class Initialized
DEBUG - 2022-05-11 10:27:48 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:27:48 --> Model Class Initialized
DEBUG - 2022-05-11 10:27:48 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:27:48 --> Model Class Initialized
DEBUG - 2022-05-11 10:27:48 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:27:48 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:27:48 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:27:48 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:27:48 --> Final output sent to browser
DEBUG - 2022-05-11 10:27:48 --> Total execution time: 0.0459
INFO - 2022-05-11 10:28:10 --> Config Class Initialized
INFO - 2022-05-11 10:28:10 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:28:10 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:28:10 --> Utf8 Class Initialized
INFO - 2022-05-11 10:28:10 --> URI Class Initialized
INFO - 2022-05-11 10:28:10 --> Router Class Initialized
INFO - 2022-05-11 10:28:10 --> Output Class Initialized
INFO - 2022-05-11 10:28:10 --> Security Class Initialized
DEBUG - 2022-05-11 10:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:28:10 --> Input Class Initialized
INFO - 2022-05-11 10:28:10 --> Language Class Initialized
INFO - 2022-05-11 10:28:10 --> Language Class Initialized
INFO - 2022-05-11 10:28:10 --> Config Class Initialized
INFO - 2022-05-11 10:28:10 --> Loader Class Initialized
INFO - 2022-05-11 10:28:10 --> Helper loaded: url_helper
INFO - 2022-05-11 10:28:10 --> Database Driver Class Initialized
INFO - 2022-05-11 10:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:28:10 --> Controller Class Initialized
DEBUG - 2022-05-11 10:28:10 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:28:10 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:10 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:28:10 --> Model Class Initialized
INFO - 2022-05-11 10:28:10 --> Final output sent to browser
DEBUG - 2022-05-11 10:28:10 --> Total execution time: 0.0488
INFO - 2022-05-11 10:28:13 --> Config Class Initialized
INFO - 2022-05-11 10:28:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:28:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:28:13 --> Utf8 Class Initialized
INFO - 2022-05-11 10:28:13 --> URI Class Initialized
INFO - 2022-05-11 10:28:13 --> Router Class Initialized
INFO - 2022-05-11 10:28:13 --> Output Class Initialized
INFO - 2022-05-11 10:28:13 --> Security Class Initialized
DEBUG - 2022-05-11 10:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:28:13 --> Input Class Initialized
INFO - 2022-05-11 10:28:13 --> Language Class Initialized
INFO - 2022-05-11 10:28:13 --> Language Class Initialized
INFO - 2022-05-11 10:28:13 --> Config Class Initialized
INFO - 2022-05-11 10:28:13 --> Loader Class Initialized
INFO - 2022-05-11 10:28:13 --> Helper loaded: url_helper
INFO - 2022-05-11 10:28:13 --> Database Driver Class Initialized
INFO - 2022-05-11 10:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:28:13 --> Controller Class Initialized
DEBUG - 2022-05-11 10:28:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:28:13 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:28:13 --> Model Class Initialized
INFO - 2022-05-11 10:28:13 --> Final output sent to browser
DEBUG - 2022-05-11 10:28:13 --> Total execution time: 0.0478
INFO - 2022-05-11 10:28:23 --> Config Class Initialized
INFO - 2022-05-11 10:28:23 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:28:23 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:28:23 --> Utf8 Class Initialized
INFO - 2022-05-11 10:28:23 --> URI Class Initialized
INFO - 2022-05-11 10:28:23 --> Router Class Initialized
INFO - 2022-05-11 10:28:23 --> Output Class Initialized
INFO - 2022-05-11 10:28:23 --> Security Class Initialized
DEBUG - 2022-05-11 10:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:28:23 --> Input Class Initialized
INFO - 2022-05-11 10:28:23 --> Language Class Initialized
INFO - 2022-05-11 10:28:23 --> Language Class Initialized
INFO - 2022-05-11 10:28:23 --> Config Class Initialized
INFO - 2022-05-11 10:28:23 --> Loader Class Initialized
INFO - 2022-05-11 10:28:23 --> Helper loaded: url_helper
INFO - 2022-05-11 10:28:23 --> Database Driver Class Initialized
INFO - 2022-05-11 10:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:28:23 --> Controller Class Initialized
DEBUG - 2022-05-11 10:28:23 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:28:23 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:28:23 --> Model Class Initialized
INFO - 2022-05-11 10:28:23 --> Upload Class Initialized
INFO - 2022-05-11 10:28:23 --> Config Class Initialized
INFO - 2022-05-11 10:28:23 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:28:23 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:28:23 --> Utf8 Class Initialized
INFO - 2022-05-11 10:28:23 --> URI Class Initialized
INFO - 2022-05-11 10:28:23 --> Router Class Initialized
INFO - 2022-05-11 10:28:23 --> Output Class Initialized
INFO - 2022-05-11 10:28:23 --> Security Class Initialized
DEBUG - 2022-05-11 10:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:28:23 --> Input Class Initialized
INFO - 2022-05-11 10:28:23 --> Language Class Initialized
INFO - 2022-05-11 10:28:23 --> Language Class Initialized
INFO - 2022-05-11 10:28:23 --> Config Class Initialized
INFO - 2022-05-11 10:28:23 --> Loader Class Initialized
INFO - 2022-05-11 10:28:23 --> Helper loaded: url_helper
INFO - 2022-05-11 10:28:23 --> Database Driver Class Initialized
INFO - 2022-05-11 10:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:28:23 --> Controller Class Initialized
DEBUG - 2022-05-11 10:28:23 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:28:23 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:28:23 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:28:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:28:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:28:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:28:23 --> Final output sent to browser
DEBUG - 2022-05-11 10:28:23 --> Total execution time: 0.0431
INFO - 2022-05-11 10:28:52 --> Config Class Initialized
INFO - 2022-05-11 10:28:52 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:28:52 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:28:52 --> Utf8 Class Initialized
INFO - 2022-05-11 10:28:52 --> URI Class Initialized
INFO - 2022-05-11 10:28:52 --> Router Class Initialized
INFO - 2022-05-11 10:28:52 --> Output Class Initialized
INFO - 2022-05-11 10:28:52 --> Security Class Initialized
DEBUG - 2022-05-11 10:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:28:52 --> Input Class Initialized
INFO - 2022-05-11 10:28:52 --> Language Class Initialized
INFO - 2022-05-11 10:28:52 --> Language Class Initialized
INFO - 2022-05-11 10:28:52 --> Config Class Initialized
INFO - 2022-05-11 10:28:52 --> Loader Class Initialized
INFO - 2022-05-11 10:28:52 --> Helper loaded: url_helper
INFO - 2022-05-11 10:28:52 --> Database Driver Class Initialized
INFO - 2022-05-11 10:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:28:52 --> Controller Class Initialized
DEBUG - 2022-05-11 10:28:52 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:28:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:28:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:28:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:28:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:28:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:28:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:28:52 --> Final output sent to browser
DEBUG - 2022-05-11 10:28:52 --> Total execution time: 0.0347
INFO - 2022-05-11 10:32:13 --> Config Class Initialized
INFO - 2022-05-11 10:32:13 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:32:13 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:32:13 --> Utf8 Class Initialized
INFO - 2022-05-11 10:32:13 --> URI Class Initialized
DEBUG - 2022-05-11 10:32:13 --> No URI present. Default controller set.
INFO - 2022-05-11 10:32:13 --> Router Class Initialized
INFO - 2022-05-11 10:32:13 --> Output Class Initialized
INFO - 2022-05-11 10:32:13 --> Security Class Initialized
DEBUG - 2022-05-11 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:32:13 --> Input Class Initialized
INFO - 2022-05-11 10:32:13 --> Language Class Initialized
INFO - 2022-05-11 10:32:13 --> Language Class Initialized
INFO - 2022-05-11 10:32:13 --> Config Class Initialized
INFO - 2022-05-11 10:32:13 --> Loader Class Initialized
INFO - 2022-05-11 10:32:13 --> Helper loaded: url_helper
INFO - 2022-05-11 10:32:13 --> Database Driver Class Initialized
INFO - 2022-05-11 10:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:32:13 --> Controller Class Initialized
DEBUG - 2022-05-11 10:32:13 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:32:13 --> Model Class Initialized
DEBUG - 2022-05-11 10:32:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:32:13 --> Model Class Initialized
DEBUG - 2022-05-11 10:32:13 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/login.php
INFO - 2022-05-11 10:32:13 --> Final output sent to browser
DEBUG - 2022-05-11 10:32:13 --> Total execution time: 0.0329
INFO - 2022-05-11 10:32:22 --> Config Class Initialized
INFO - 2022-05-11 10:32:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:32:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:32:22 --> Utf8 Class Initialized
INFO - 2022-05-11 10:32:29 --> Config Class Initialized
INFO - 2022-05-11 10:32:29 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:32:29 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:32:29 --> Utf8 Class Initialized
INFO - 2022-05-11 10:32:29 --> URI Class Initialized
INFO - 2022-05-11 10:32:29 --> Router Class Initialized
INFO - 2022-05-11 10:32:29 --> Output Class Initialized
INFO - 2022-05-11 10:32:29 --> Security Class Initialized
DEBUG - 2022-05-11 10:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:32:29 --> Input Class Initialized
INFO - 2022-05-11 10:32:29 --> Language Class Initialized
INFO - 2022-05-11 10:32:29 --> Language Class Initialized
INFO - 2022-05-11 10:32:29 --> Config Class Initialized
INFO - 2022-05-11 10:32:29 --> Loader Class Initialized
INFO - 2022-05-11 10:32:29 --> Helper loaded: url_helper
INFO - 2022-05-11 10:32:29 --> Database Driver Class Initialized
INFO - 2022-05-11 10:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:32:29 --> Controller Class Initialized
DEBUG - 2022-05-11 10:32:29 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:32:29 --> Model Class Initialized
DEBUG - 2022-05-11 10:32:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:32:29 --> Model Class Initialized
DEBUG - 2022-05-11 10:32:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:32:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:32:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 10:32:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:32:29 --> Final output sent to browser
DEBUG - 2022-05-11 10:32:29 --> Total execution time: 0.0326
INFO - 2022-05-11 10:32:31 --> Config Class Initialized
INFO - 2022-05-11 10:32:31 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:32:31 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:32:31 --> Utf8 Class Initialized
INFO - 2022-05-11 10:32:31 --> URI Class Initialized
INFO - 2022-05-11 10:32:31 --> Router Class Initialized
INFO - 2022-05-11 10:32:31 --> Output Class Initialized
INFO - 2022-05-11 10:32:31 --> Security Class Initialized
DEBUG - 2022-05-11 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:32:31 --> Input Class Initialized
INFO - 2022-05-11 10:32:31 --> Language Class Initialized
INFO - 2022-05-11 10:32:31 --> Language Class Initialized
INFO - 2022-05-11 10:32:31 --> Config Class Initialized
INFO - 2022-05-11 10:32:31 --> Loader Class Initialized
INFO - 2022-05-11 10:32:31 --> Helper loaded: url_helper
INFO - 2022-05-11 10:32:31 --> Database Driver Class Initialized
INFO - 2022-05-11 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:32:31 --> Controller Class Initialized
DEBUG - 2022-05-11 10:32:31 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:32:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:32:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:32:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:32:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:32:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:32:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:32:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:32:31 --> Final output sent to browser
DEBUG - 2022-05-11 10:32:31 --> Total execution time: 0.0448
INFO - 2022-05-11 10:33:40 --> Config Class Initialized
INFO - 2022-05-11 10:33:40 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:33:40 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:33:40 --> Utf8 Class Initialized
INFO - 2022-05-11 10:33:40 --> URI Class Initialized
INFO - 2022-05-11 10:33:40 --> Router Class Initialized
INFO - 2022-05-11 10:33:40 --> Output Class Initialized
INFO - 2022-05-11 10:33:40 --> Security Class Initialized
DEBUG - 2022-05-11 10:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:33:40 --> Input Class Initialized
INFO - 2022-05-11 10:33:40 --> Language Class Initialized
INFO - 2022-05-11 10:33:40 --> Language Class Initialized
INFO - 2022-05-11 10:33:40 --> Config Class Initialized
INFO - 2022-05-11 10:33:40 --> Loader Class Initialized
INFO - 2022-05-11 10:33:40 --> Helper loaded: url_helper
INFO - 2022-05-11 10:33:40 --> Database Driver Class Initialized
INFO - 2022-05-11 10:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:33:40 --> Controller Class Initialized
DEBUG - 2022-05-11 10:33:40 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:33:40 --> Model Class Initialized
DEBUG - 2022-05-11 10:33:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:33:40 --> Model Class Initialized
DEBUG - 2022-05-11 10:33:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:33:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:33:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:33:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:33:40 --> Final output sent to browser
DEBUG - 2022-05-11 10:33:40 --> Total execution time: 0.0316
INFO - 2022-05-11 10:34:45 --> Config Class Initialized
INFO - 2022-05-11 10:34:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:34:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:34:45 --> Utf8 Class Initialized
INFO - 2022-05-11 10:34:45 --> URI Class Initialized
INFO - 2022-05-11 10:34:45 --> Router Class Initialized
INFO - 2022-05-11 10:34:45 --> Output Class Initialized
INFO - 2022-05-11 10:34:45 --> Security Class Initialized
DEBUG - 2022-05-11 10:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:34:45 --> Input Class Initialized
INFO - 2022-05-11 10:34:45 --> Language Class Initialized
INFO - 2022-05-11 10:34:45 --> Language Class Initialized
INFO - 2022-05-11 10:34:45 --> Config Class Initialized
INFO - 2022-05-11 10:34:45 --> Loader Class Initialized
INFO - 2022-05-11 10:34:45 --> Helper loaded: url_helper
INFO - 2022-05-11 10:34:45 --> Database Driver Class Initialized
INFO - 2022-05-11 10:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:34:45 --> Controller Class Initialized
DEBUG - 2022-05-11 10:34:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:34:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:34:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:34:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:34:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:34:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:34:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:34:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:34:45 --> Final output sent to browser
DEBUG - 2022-05-11 10:34:45 --> Total execution time: 0.0493
INFO - 2022-05-11 10:35:05 --> Config Class Initialized
INFO - 2022-05-11 10:35:05 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:35:05 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:35:05 --> Utf8 Class Initialized
INFO - 2022-05-11 10:35:05 --> URI Class Initialized
INFO - 2022-05-11 10:35:05 --> Router Class Initialized
INFO - 2022-05-11 10:35:05 --> Output Class Initialized
INFO - 2022-05-11 10:35:05 --> Security Class Initialized
DEBUG - 2022-05-11 10:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:35:05 --> Input Class Initialized
INFO - 2022-05-11 10:35:05 --> Language Class Initialized
INFO - 2022-05-11 10:35:05 --> Language Class Initialized
INFO - 2022-05-11 10:35:05 --> Config Class Initialized
INFO - 2022-05-11 10:35:05 --> Loader Class Initialized
INFO - 2022-05-11 10:35:05 --> Helper loaded: url_helper
INFO - 2022-05-11 10:35:05 --> Database Driver Class Initialized
INFO - 2022-05-11 10:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:35:05 --> Controller Class Initialized
DEBUG - 2022-05-11 10:35:05 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:35:05 --> Model Class Initialized
DEBUG - 2022-05-11 10:35:05 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:35:05 --> Model Class Initialized
INFO - 2022-05-11 10:35:05 --> Final output sent to browser
DEBUG - 2022-05-11 10:35:05 --> Total execution time: 0.0476
INFO - 2022-05-11 10:35:06 --> Config Class Initialized
INFO - 2022-05-11 10:35:06 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:35:06 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:35:06 --> Utf8 Class Initialized
INFO - 2022-05-11 10:35:06 --> URI Class Initialized
INFO - 2022-05-11 10:35:06 --> Router Class Initialized
INFO - 2022-05-11 10:35:06 --> Output Class Initialized
INFO - 2022-05-11 10:35:06 --> Security Class Initialized
DEBUG - 2022-05-11 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:35:06 --> Input Class Initialized
INFO - 2022-05-11 10:35:06 --> Language Class Initialized
INFO - 2022-05-11 10:35:06 --> Language Class Initialized
INFO - 2022-05-11 10:35:06 --> Config Class Initialized
INFO - 2022-05-11 10:35:06 --> Loader Class Initialized
INFO - 2022-05-11 10:35:06 --> Helper loaded: url_helper
INFO - 2022-05-11 10:35:06 --> Database Driver Class Initialized
INFO - 2022-05-11 10:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:35:06 --> Controller Class Initialized
DEBUG - 2022-05-11 10:35:06 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:35:06 --> Model Class Initialized
DEBUG - 2022-05-11 10:35:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:35:06 --> Model Class Initialized
INFO - 2022-05-11 10:35:06 --> Final output sent to browser
DEBUG - 2022-05-11 10:35:06 --> Total execution time: 0.0298
INFO - 2022-05-11 10:35:59 --> Config Class Initialized
INFO - 2022-05-11 10:35:59 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:35:59 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:35:59 --> Utf8 Class Initialized
INFO - 2022-05-11 10:35:59 --> URI Class Initialized
INFO - 2022-05-11 10:35:59 --> Router Class Initialized
INFO - 2022-05-11 10:35:59 --> Output Class Initialized
INFO - 2022-05-11 10:35:59 --> Security Class Initialized
DEBUG - 2022-05-11 10:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:35:59 --> Input Class Initialized
INFO - 2022-05-11 10:35:59 --> Language Class Initialized
INFO - 2022-05-11 10:35:59 --> Language Class Initialized
INFO - 2022-05-11 10:35:59 --> Config Class Initialized
INFO - 2022-05-11 10:35:59 --> Loader Class Initialized
INFO - 2022-05-11 10:35:59 --> Helper loaded: url_helper
INFO - 2022-05-11 10:35:59 --> Database Driver Class Initialized
INFO - 2022-05-11 10:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:35:59 --> Controller Class Initialized
DEBUG - 2022-05-11 10:35:59 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:35:59 --> Model Class Initialized
DEBUG - 2022-05-11 10:35:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:35:59 --> Model Class Initialized
DEBUG - 2022-05-11 10:35:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:35:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:35:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:35:59 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:35:59 --> Final output sent to browser
DEBUG - 2022-05-11 10:35:59 --> Total execution time: 0.0759
INFO - 2022-05-11 10:42:41 --> Config Class Initialized
INFO - 2022-05-11 10:42:41 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:42:41 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:42:41 --> Utf8 Class Initialized
INFO - 2022-05-11 10:42:41 --> URI Class Initialized
INFO - 2022-05-11 10:42:41 --> Router Class Initialized
INFO - 2022-05-11 10:42:41 --> Output Class Initialized
INFO - 2022-05-11 10:42:41 --> Security Class Initialized
DEBUG - 2022-05-11 10:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:42:41 --> Input Class Initialized
INFO - 2022-05-11 10:42:41 --> Language Class Initialized
INFO - 2022-05-11 10:42:41 --> Language Class Initialized
INFO - 2022-05-11 10:42:41 --> Config Class Initialized
INFO - 2022-05-11 10:42:41 --> Loader Class Initialized
INFO - 2022-05-11 10:42:41 --> Helper loaded: url_helper
INFO - 2022-05-11 10:42:41 --> Database Driver Class Initialized
INFO - 2022-05-11 10:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:42:41 --> Controller Class Initialized
DEBUG - 2022-05-11 10:42:41 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:42:41 --> Model Class Initialized
DEBUG - 2022-05-11 10:42:41 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:42:41 --> Model Class Initialized
DEBUG - 2022-05-11 10:42:41 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:42:41 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:42:41 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:42:41 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:42:41 --> Final output sent to browser
DEBUG - 2022-05-11 10:42:41 --> Total execution time: 0.0466
INFO - 2022-05-11 10:44:03 --> Config Class Initialized
INFO - 2022-05-11 10:44:03 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:44:03 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:44:03 --> Utf8 Class Initialized
INFO - 2022-05-11 10:44:03 --> URI Class Initialized
INFO - 2022-05-11 10:44:03 --> Router Class Initialized
INFO - 2022-05-11 10:44:03 --> Output Class Initialized
INFO - 2022-05-11 10:44:03 --> Security Class Initialized
DEBUG - 2022-05-11 10:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:44:03 --> Input Class Initialized
INFO - 2022-05-11 10:44:03 --> Language Class Initialized
INFO - 2022-05-11 10:44:03 --> Language Class Initialized
INFO - 2022-05-11 10:44:03 --> Config Class Initialized
INFO - 2022-05-11 10:44:03 --> Loader Class Initialized
INFO - 2022-05-11 10:44:03 --> Helper loaded: url_helper
INFO - 2022-05-11 10:44:03 --> Database Driver Class Initialized
INFO - 2022-05-11 10:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:44:03 --> Controller Class Initialized
DEBUG - 2022-05-11 10:44:03 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:44:03 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:44:03 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:44:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:44:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:44:03 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:44:03 --> Final output sent to browser
DEBUG - 2022-05-11 10:44:03 --> Total execution time: 0.0435
INFO - 2022-05-11 10:44:08 --> Config Class Initialized
INFO - 2022-05-11 10:44:08 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:44:08 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:44:08 --> Utf8 Class Initialized
INFO - 2022-05-11 10:44:08 --> URI Class Initialized
INFO - 2022-05-11 10:44:08 --> Router Class Initialized
INFO - 2022-05-11 10:44:08 --> Output Class Initialized
INFO - 2022-05-11 10:44:08 --> Security Class Initialized
DEBUG - 2022-05-11 10:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:44:08 --> Input Class Initialized
INFO - 2022-05-11 10:44:08 --> Language Class Initialized
INFO - 2022-05-11 10:44:08 --> Language Class Initialized
INFO - 2022-05-11 10:44:08 --> Config Class Initialized
INFO - 2022-05-11 10:44:08 --> Loader Class Initialized
INFO - 2022-05-11 10:44:08 --> Helper loaded: url_helper
INFO - 2022-05-11 10:44:08 --> Database Driver Class Initialized
INFO - 2022-05-11 10:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:44:08 --> Controller Class Initialized
DEBUG - 2022-05-11 10:44:08 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:44:08 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:44:08 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:44:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:44:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:44:08 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:44:08 --> Final output sent to browser
DEBUG - 2022-05-11 10:44:08 --> Total execution time: 0.0517
INFO - 2022-05-11 10:44:14 --> Config Class Initialized
INFO - 2022-05-11 10:44:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:44:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:44:14 --> Utf8 Class Initialized
INFO - 2022-05-11 10:44:14 --> URI Class Initialized
INFO - 2022-05-11 10:44:14 --> Router Class Initialized
INFO - 2022-05-11 10:44:14 --> Output Class Initialized
INFO - 2022-05-11 10:44:14 --> Security Class Initialized
DEBUG - 2022-05-11 10:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:44:14 --> Input Class Initialized
INFO - 2022-05-11 10:44:14 --> Language Class Initialized
INFO - 2022-05-11 10:44:14 --> Language Class Initialized
INFO - 2022-05-11 10:44:14 --> Config Class Initialized
INFO - 2022-05-11 10:44:14 --> Loader Class Initialized
INFO - 2022-05-11 10:44:14 --> Helper loaded: url_helper
INFO - 2022-05-11 10:44:14 --> Database Driver Class Initialized
INFO - 2022-05-11 10:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:44:14 --> Controller Class Initialized
DEBUG - 2022-05-11 10:44:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:44:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:44:14 --> Model Class Initialized
INFO - 2022-05-11 10:44:14 --> Final output sent to browser
DEBUG - 2022-05-11 10:44:14 --> Total execution time: 0.0280
INFO - 2022-05-11 10:44:31 --> Config Class Initialized
INFO - 2022-05-11 10:44:31 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:44:31 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:44:31 --> Utf8 Class Initialized
INFO - 2022-05-11 10:44:31 --> URI Class Initialized
INFO - 2022-05-11 10:44:31 --> Router Class Initialized
INFO - 2022-05-11 10:44:31 --> Output Class Initialized
INFO - 2022-05-11 10:44:31 --> Security Class Initialized
DEBUG - 2022-05-11 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:44:31 --> Input Class Initialized
INFO - 2022-05-11 10:44:31 --> Language Class Initialized
INFO - 2022-05-11 10:44:31 --> Language Class Initialized
INFO - 2022-05-11 10:44:31 --> Config Class Initialized
INFO - 2022-05-11 10:44:31 --> Loader Class Initialized
INFO - 2022-05-11 10:44:31 --> Helper loaded: url_helper
INFO - 2022-05-11 10:44:31 --> Database Driver Class Initialized
INFO - 2022-05-11 10:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:44:31 --> Controller Class Initialized
DEBUG - 2022-05-11 10:44:31 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:44:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:44:31 --> Model Class Initialized
INFO - 2022-05-11 10:44:31 --> Upload Class Initialized
INFO - 2022-05-11 10:44:31 --> Config Class Initialized
INFO - 2022-05-11 10:44:31 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:44:31 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:44:31 --> Utf8 Class Initialized
INFO - 2022-05-11 10:44:31 --> URI Class Initialized
INFO - 2022-05-11 10:44:31 --> Router Class Initialized
INFO - 2022-05-11 10:44:31 --> Output Class Initialized
INFO - 2022-05-11 10:44:31 --> Security Class Initialized
DEBUG - 2022-05-11 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:44:31 --> Input Class Initialized
INFO - 2022-05-11 10:44:31 --> Language Class Initialized
INFO - 2022-05-11 10:44:31 --> Language Class Initialized
INFO - 2022-05-11 10:44:31 --> Config Class Initialized
INFO - 2022-05-11 10:44:31 --> Loader Class Initialized
INFO - 2022-05-11 10:44:31 --> Helper loaded: url_helper
INFO - 2022-05-11 10:44:31 --> Database Driver Class Initialized
INFO - 2022-05-11 10:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:44:31 --> Controller Class Initialized
DEBUG - 2022-05-11 10:44:31 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:44:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:44:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:44:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:44:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:44:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:44:31 --> Final output sent to browser
DEBUG - 2022-05-11 10:44:31 --> Total execution time: 0.0504
INFO - 2022-05-11 10:44:58 --> Config Class Initialized
INFO - 2022-05-11 10:44:58 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:44:58 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:44:58 --> Utf8 Class Initialized
INFO - 2022-05-11 10:44:58 --> URI Class Initialized
INFO - 2022-05-11 10:44:58 --> Router Class Initialized
INFO - 2022-05-11 10:44:58 --> Output Class Initialized
INFO - 2022-05-11 10:44:58 --> Security Class Initialized
DEBUG - 2022-05-11 10:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:44:58 --> Input Class Initialized
INFO - 2022-05-11 10:44:58 --> Language Class Initialized
INFO - 2022-05-11 10:44:58 --> Language Class Initialized
INFO - 2022-05-11 10:44:58 --> Config Class Initialized
INFO - 2022-05-11 10:44:58 --> Loader Class Initialized
INFO - 2022-05-11 10:44:58 --> Helper loaded: url_helper
INFO - 2022-05-11 10:44:58 --> Database Driver Class Initialized
INFO - 2022-05-11 10:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:44:58 --> Controller Class Initialized
DEBUG - 2022-05-11 10:44:58 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:44:58 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:58 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:44:58 --> Model Class Initialized
DEBUG - 2022-05-11 10:44:58 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:44:58 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:44:58 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:44:58 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:44:58 --> Final output sent to browser
DEBUG - 2022-05-11 10:44:58 --> Total execution time: 0.0480
INFO - 2022-05-11 10:45:02 --> Config Class Initialized
INFO - 2022-05-11 10:45:02 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:45:02 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:45:02 --> Utf8 Class Initialized
INFO - 2022-05-11 10:45:02 --> URI Class Initialized
INFO - 2022-05-11 10:45:02 --> Router Class Initialized
INFO - 2022-05-11 10:45:02 --> Output Class Initialized
INFO - 2022-05-11 10:45:02 --> Security Class Initialized
DEBUG - 2022-05-11 10:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:45:02 --> Input Class Initialized
INFO - 2022-05-11 10:45:02 --> Language Class Initialized
INFO - 2022-05-11 10:45:02 --> Language Class Initialized
INFO - 2022-05-11 10:45:02 --> Config Class Initialized
INFO - 2022-05-11 10:45:02 --> Loader Class Initialized
INFO - 2022-05-11 10:45:02 --> Helper loaded: url_helper
INFO - 2022-05-11 10:45:02 --> Database Driver Class Initialized
INFO - 2022-05-11 10:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:45:02 --> Controller Class Initialized
DEBUG - 2022-05-11 10:45:02 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:45:02 --> Model Class Initialized
DEBUG - 2022-05-11 10:45:02 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:45:02 --> Model Class Initialized
INFO - 2022-05-11 10:45:02 --> Final output sent to browser
DEBUG - 2022-05-11 10:45:02 --> Total execution time: 0.0424
INFO - 2022-05-11 10:45:22 --> Config Class Initialized
INFO - 2022-05-11 10:45:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:45:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:45:22 --> Utf8 Class Initialized
INFO - 2022-05-11 10:45:22 --> URI Class Initialized
INFO - 2022-05-11 10:45:22 --> Router Class Initialized
INFO - 2022-05-11 10:45:22 --> Output Class Initialized
INFO - 2022-05-11 10:45:22 --> Security Class Initialized
DEBUG - 2022-05-11 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:45:22 --> Input Class Initialized
INFO - 2022-05-11 10:45:22 --> Language Class Initialized
INFO - 2022-05-11 10:45:22 --> Language Class Initialized
INFO - 2022-05-11 10:45:22 --> Config Class Initialized
INFO - 2022-05-11 10:45:22 --> Loader Class Initialized
INFO - 2022-05-11 10:45:22 --> Helper loaded: url_helper
INFO - 2022-05-11 10:45:22 --> Database Driver Class Initialized
INFO - 2022-05-11 10:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:45:22 --> Controller Class Initialized
DEBUG - 2022-05-11 10:45:22 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:45:22 --> Model Class Initialized
DEBUG - 2022-05-11 10:45:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:45:22 --> Model Class Initialized
ERROR - 2022-05-11 10:45:22 --> Severity: Notice --> Undefined index: fuel_type C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 113
ERROR - 2022-05-11 10:45:22 --> Severity: Notice --> Undefined index: vc_name C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-11 10:45:22 --> Severity: Notice --> Undefined index: transmission C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-11 10:45:22 --> Severity: Notice --> Undefined index: seater C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-11 10:45:22 --> Severity: Notice --> Undefined index: bodytype C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 117
ERROR - 2022-05-11 10:45:22 --> Query error: Column 'fuel_type' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (4, NULL, NULL, NULL, NULL, NULL)
INFO - 2022-05-11 10:45:22 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 10:47:22 --> Config Class Initialized
INFO - 2022-05-11 10:47:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:47:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:47:22 --> Utf8 Class Initialized
INFO - 2022-05-11 10:47:22 --> URI Class Initialized
INFO - 2022-05-11 10:47:22 --> Router Class Initialized
INFO - 2022-05-11 10:47:22 --> Output Class Initialized
INFO - 2022-05-11 10:47:22 --> Security Class Initialized
DEBUG - 2022-05-11 10:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:47:22 --> Input Class Initialized
INFO - 2022-05-11 10:47:22 --> Language Class Initialized
INFO - 2022-05-11 10:47:22 --> Language Class Initialized
INFO - 2022-05-11 10:47:22 --> Config Class Initialized
INFO - 2022-05-11 10:47:22 --> Loader Class Initialized
INFO - 2022-05-11 10:47:22 --> Helper loaded: url_helper
INFO - 2022-05-11 10:47:22 --> Database Driver Class Initialized
INFO - 2022-05-11 10:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:47:22 --> Controller Class Initialized
DEBUG - 2022-05-11 10:47:22 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:47:22 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:47:22 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:47:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:47:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 10:47:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:47:22 --> Final output sent to browser
DEBUG - 2022-05-11 10:47:22 --> Total execution time: 0.0289
INFO - 2022-05-11 10:47:31 --> Config Class Initialized
INFO - 2022-05-11 10:47:31 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:47:31 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:47:31 --> Utf8 Class Initialized
INFO - 2022-05-11 10:47:31 --> URI Class Initialized
INFO - 2022-05-11 10:47:31 --> Router Class Initialized
INFO - 2022-05-11 10:47:31 --> Output Class Initialized
INFO - 2022-05-11 10:47:31 --> Security Class Initialized
DEBUG - 2022-05-11 10:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:47:31 --> Input Class Initialized
INFO - 2022-05-11 10:47:31 --> Language Class Initialized
INFO - 2022-05-11 10:47:31 --> Language Class Initialized
INFO - 2022-05-11 10:47:31 --> Config Class Initialized
INFO - 2022-05-11 10:47:31 --> Loader Class Initialized
INFO - 2022-05-11 10:47:31 --> Helper loaded: url_helper
INFO - 2022-05-11 10:47:31 --> Database Driver Class Initialized
INFO - 2022-05-11 10:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:47:31 --> Controller Class Initialized
DEBUG - 2022-05-11 10:47:31 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:47:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:47:31 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:47:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:47:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:47:31 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:47:31 --> Final output sent to browser
DEBUG - 2022-05-11 10:47:31 --> Total execution time: 0.0495
INFO - 2022-05-11 10:47:32 --> Config Class Initialized
INFO - 2022-05-11 10:47:32 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:47:32 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:47:32 --> Utf8 Class Initialized
INFO - 2022-05-11 10:47:32 --> URI Class Initialized
INFO - 2022-05-11 10:47:32 --> Router Class Initialized
INFO - 2022-05-11 10:47:32 --> Output Class Initialized
INFO - 2022-05-11 10:47:32 --> Security Class Initialized
DEBUG - 2022-05-11 10:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:47:32 --> Input Class Initialized
INFO - 2022-05-11 10:47:32 --> Language Class Initialized
INFO - 2022-05-11 10:47:32 --> Language Class Initialized
INFO - 2022-05-11 10:47:32 --> Config Class Initialized
INFO - 2022-05-11 10:47:32 --> Loader Class Initialized
INFO - 2022-05-11 10:47:32 --> Helper loaded: url_helper
INFO - 2022-05-11 10:47:32 --> Database Driver Class Initialized
INFO - 2022-05-11 10:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:47:32 --> Controller Class Initialized
DEBUG - 2022-05-11 10:47:32 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:47:32 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:47:32 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:47:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:47:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:47:32 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:47:32 --> Final output sent to browser
DEBUG - 2022-05-11 10:47:32 --> Total execution time: 0.0497
INFO - 2022-05-11 10:47:36 --> Config Class Initialized
INFO - 2022-05-11 10:47:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:47:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:47:36 --> Utf8 Class Initialized
INFO - 2022-05-11 10:47:36 --> URI Class Initialized
INFO - 2022-05-11 10:47:36 --> Router Class Initialized
INFO - 2022-05-11 10:47:36 --> Output Class Initialized
INFO - 2022-05-11 10:47:36 --> Security Class Initialized
DEBUG - 2022-05-11 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:47:36 --> Input Class Initialized
INFO - 2022-05-11 10:47:36 --> Language Class Initialized
INFO - 2022-05-11 10:47:36 --> Language Class Initialized
INFO - 2022-05-11 10:47:36 --> Config Class Initialized
INFO - 2022-05-11 10:47:36 --> Loader Class Initialized
INFO - 2022-05-11 10:47:36 --> Helper loaded: url_helper
INFO - 2022-05-11 10:47:36 --> Database Driver Class Initialized
INFO - 2022-05-11 10:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:47:36 --> Controller Class Initialized
DEBUG - 2022-05-11 10:47:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:47:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:47:36 --> Model Class Initialized
INFO - 2022-05-11 10:47:36 --> Final output sent to browser
DEBUG - 2022-05-11 10:47:36 --> Total execution time: 0.0414
INFO - 2022-05-11 10:47:42 --> Config Class Initialized
INFO - 2022-05-11 10:47:42 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:47:42 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:47:42 --> Utf8 Class Initialized
INFO - 2022-05-11 10:47:42 --> URI Class Initialized
INFO - 2022-05-11 10:47:42 --> Router Class Initialized
INFO - 2022-05-11 10:47:42 --> Output Class Initialized
INFO - 2022-05-11 10:47:42 --> Security Class Initialized
DEBUG - 2022-05-11 10:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:47:42 --> Input Class Initialized
INFO - 2022-05-11 10:47:42 --> Language Class Initialized
INFO - 2022-05-11 10:47:42 --> Language Class Initialized
INFO - 2022-05-11 10:47:42 --> Config Class Initialized
INFO - 2022-05-11 10:47:42 --> Loader Class Initialized
INFO - 2022-05-11 10:47:42 --> Helper loaded: url_helper
INFO - 2022-05-11 10:47:42 --> Database Driver Class Initialized
INFO - 2022-05-11 10:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:47:42 --> Controller Class Initialized
DEBUG - 2022-05-11 10:47:42 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:47:42 --> Model Class Initialized
DEBUG - 2022-05-11 10:47:42 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:47:42 --> Model Class Initialized
ERROR - 2022-05-11 10:47:42 --> Severity: Notice --> Undefined index: fuel_type C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 113
ERROR - 2022-05-11 10:47:42 --> Severity: Notice --> Undefined index: vc_name C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-11 10:47:42 --> Severity: Notice --> Undefined index: transmission C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-11 10:47:42 --> Severity: Notice --> Undefined index: seater C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-11 10:47:42 --> Severity: Notice --> Undefined index: bodytype C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 117
ERROR - 2022-05-11 10:47:42 --> Query error: Column 'fuel_type' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (5, NULL, NULL, NULL, NULL, NULL)
INFO - 2022-05-11 10:47:42 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 10:49:25 --> Config Class Initialized
INFO - 2022-05-11 10:49:25 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:49:25 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:49:25 --> Utf8 Class Initialized
INFO - 2022-05-11 10:49:25 --> URI Class Initialized
INFO - 2022-05-11 10:49:25 --> Router Class Initialized
INFO - 2022-05-11 10:49:25 --> Output Class Initialized
INFO - 2022-05-11 10:49:25 --> Security Class Initialized
DEBUG - 2022-05-11 10:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:49:25 --> Input Class Initialized
INFO - 2022-05-11 10:49:25 --> Language Class Initialized
INFO - 2022-05-11 10:49:25 --> Language Class Initialized
INFO - 2022-05-11 10:49:25 --> Config Class Initialized
INFO - 2022-05-11 10:49:25 --> Loader Class Initialized
INFO - 2022-05-11 10:49:25 --> Helper loaded: url_helper
INFO - 2022-05-11 10:49:25 --> Database Driver Class Initialized
INFO - 2022-05-11 10:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:49:25 --> Controller Class Initialized
DEBUG - 2022-05-11 10:49:25 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:49:25 --> Model Class Initialized
DEBUG - 2022-05-11 10:49:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:49:25 --> Model Class Initialized
DEBUG - 2022-05-11 10:49:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:49:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:49:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:49:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:49:25 --> Final output sent to browser
DEBUG - 2022-05-11 10:49:25 --> Total execution time: 0.0505
INFO - 2022-05-11 10:49:36 --> Config Class Initialized
INFO - 2022-05-11 10:49:36 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:49:36 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:49:36 --> Utf8 Class Initialized
INFO - 2022-05-11 10:49:36 --> URI Class Initialized
INFO - 2022-05-11 10:49:36 --> Router Class Initialized
INFO - 2022-05-11 10:49:36 --> Output Class Initialized
INFO - 2022-05-11 10:49:36 --> Security Class Initialized
DEBUG - 2022-05-11 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:49:36 --> Input Class Initialized
INFO - 2022-05-11 10:49:36 --> Language Class Initialized
INFO - 2022-05-11 10:49:36 --> Language Class Initialized
INFO - 2022-05-11 10:49:36 --> Config Class Initialized
INFO - 2022-05-11 10:49:36 --> Loader Class Initialized
INFO - 2022-05-11 10:49:36 --> Helper loaded: url_helper
INFO - 2022-05-11 10:49:36 --> Database Driver Class Initialized
INFO - 2022-05-11 10:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:49:36 --> Controller Class Initialized
DEBUG - 2022-05-11 10:49:36 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:49:36 --> Model Class Initialized
DEBUG - 2022-05-11 10:49:36 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:49:36 --> Model Class Initialized
ERROR - 2022-05-11 10:49:36 --> Severity: Notice --> Undefined index: m_id C:\xampp\htdocs\vm\application\modules\admin\models\Admin_model.php 87
ERROR - 2022-05-11 10:49:36 --> Query error: Column 'model' cannot be null - Invalid query: INSERT INTO `vehicle_details` (`category`, `brand`, `model`, `varient`, `price`, `current_on_road`) VALUES ('2', '2', NULL, 'awsdsad', '54', '545454')
INFO - 2022-05-11 10:49:36 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-11 10:50:12 --> Config Class Initialized
INFO - 2022-05-11 10:50:12 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:50:12 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:50:12 --> Utf8 Class Initialized
INFO - 2022-05-11 10:50:12 --> URI Class Initialized
INFO - 2022-05-11 10:50:12 --> Router Class Initialized
INFO - 2022-05-11 10:50:12 --> Output Class Initialized
INFO - 2022-05-11 10:50:12 --> Security Class Initialized
DEBUG - 2022-05-11 10:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:50:12 --> Input Class Initialized
INFO - 2022-05-11 10:50:12 --> Language Class Initialized
INFO - 2022-05-11 10:50:12 --> Language Class Initialized
INFO - 2022-05-11 10:50:12 --> Config Class Initialized
INFO - 2022-05-11 10:50:12 --> Loader Class Initialized
INFO - 2022-05-11 10:50:12 --> Helper loaded: url_helper
INFO - 2022-05-11 10:50:12 --> Database Driver Class Initialized
INFO - 2022-05-11 10:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:50:12 --> Controller Class Initialized
DEBUG - 2022-05-11 10:50:12 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:50:12 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:50:12 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:50:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:50:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:50:12 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:50:12 --> Final output sent to browser
DEBUG - 2022-05-11 10:50:12 --> Total execution time: 0.0497
INFO - 2022-05-11 10:50:21 --> Config Class Initialized
INFO - 2022-05-11 10:50:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:50:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:50:21 --> Utf8 Class Initialized
INFO - 2022-05-11 10:50:21 --> URI Class Initialized
INFO - 2022-05-11 10:50:21 --> Router Class Initialized
INFO - 2022-05-11 10:50:21 --> Output Class Initialized
INFO - 2022-05-11 10:50:21 --> Security Class Initialized
DEBUG - 2022-05-11 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:50:21 --> Input Class Initialized
INFO - 2022-05-11 10:50:21 --> Language Class Initialized
INFO - 2022-05-11 10:50:21 --> Language Class Initialized
INFO - 2022-05-11 10:50:21 --> Config Class Initialized
INFO - 2022-05-11 10:50:21 --> Loader Class Initialized
INFO - 2022-05-11 10:50:21 --> Helper loaded: url_helper
INFO - 2022-05-11 10:50:21 --> Database Driver Class Initialized
INFO - 2022-05-11 10:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:50:21 --> Controller Class Initialized
DEBUG - 2022-05-11 10:50:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:50:21 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:50:21 --> Model Class Initialized
INFO - 2022-05-11 10:50:21 --> Final output sent to browser
DEBUG - 2022-05-11 10:50:21 --> Total execution time: 0.0524
INFO - 2022-05-11 10:50:27 --> Config Class Initialized
INFO - 2022-05-11 10:50:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:50:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:50:27 --> Utf8 Class Initialized
INFO - 2022-05-11 10:50:27 --> URI Class Initialized
INFO - 2022-05-11 10:50:27 --> Router Class Initialized
INFO - 2022-05-11 10:50:27 --> Output Class Initialized
INFO - 2022-05-11 10:50:27 --> Security Class Initialized
DEBUG - 2022-05-11 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:50:27 --> Input Class Initialized
INFO - 2022-05-11 10:50:27 --> Language Class Initialized
INFO - 2022-05-11 10:50:27 --> Language Class Initialized
INFO - 2022-05-11 10:50:27 --> Config Class Initialized
INFO - 2022-05-11 10:50:27 --> Loader Class Initialized
INFO - 2022-05-11 10:50:27 --> Helper loaded: url_helper
INFO - 2022-05-11 10:50:27 --> Database Driver Class Initialized
INFO - 2022-05-11 10:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:50:27 --> Controller Class Initialized
DEBUG - 2022-05-11 10:50:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:50:27 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:50:27 --> Model Class Initialized
INFO - 2022-05-11 10:50:27 --> Upload Class Initialized
INFO - 2022-05-11 10:50:27 --> Config Class Initialized
INFO - 2022-05-11 10:50:27 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:50:27 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:50:27 --> Utf8 Class Initialized
INFO - 2022-05-11 10:50:27 --> URI Class Initialized
INFO - 2022-05-11 10:50:27 --> Router Class Initialized
INFO - 2022-05-11 10:50:27 --> Output Class Initialized
INFO - 2022-05-11 10:50:27 --> Security Class Initialized
DEBUG - 2022-05-11 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:50:27 --> Input Class Initialized
INFO - 2022-05-11 10:50:27 --> Language Class Initialized
INFO - 2022-05-11 10:50:27 --> Language Class Initialized
INFO - 2022-05-11 10:50:27 --> Config Class Initialized
INFO - 2022-05-11 10:50:27 --> Loader Class Initialized
INFO - 2022-05-11 10:50:27 --> Helper loaded: url_helper
INFO - 2022-05-11 10:50:27 --> Database Driver Class Initialized
INFO - 2022-05-11 10:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:50:27 --> Controller Class Initialized
DEBUG - 2022-05-11 10:50:27 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:50:27 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:50:27 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:50:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:50:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:50:27 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:50:27 --> Final output sent to browser
DEBUG - 2022-05-11 10:50:27 --> Total execution time: 0.0501
INFO - 2022-05-11 10:50:38 --> Config Class Initialized
INFO - 2022-05-11 10:50:38 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:50:38 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:50:38 --> Utf8 Class Initialized
INFO - 2022-05-11 10:50:38 --> URI Class Initialized
INFO - 2022-05-11 10:50:38 --> Router Class Initialized
INFO - 2022-05-11 10:50:38 --> Output Class Initialized
INFO - 2022-05-11 10:50:38 --> Security Class Initialized
DEBUG - 2022-05-11 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:50:38 --> Input Class Initialized
INFO - 2022-05-11 10:50:38 --> Language Class Initialized
INFO - 2022-05-11 10:50:38 --> Language Class Initialized
INFO - 2022-05-11 10:50:38 --> Config Class Initialized
INFO - 2022-05-11 10:50:38 --> Loader Class Initialized
INFO - 2022-05-11 10:50:38 --> Helper loaded: url_helper
INFO - 2022-05-11 10:50:38 --> Database Driver Class Initialized
INFO - 2022-05-11 10:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:50:38 --> Controller Class Initialized
DEBUG - 2022-05-11 10:50:38 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:50:38 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:50:38 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:50:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:50:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:50:38 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:50:38 --> Final output sent to browser
DEBUG - 2022-05-11 10:50:38 --> Total execution time: 0.0541
INFO - 2022-05-11 10:50:45 --> Config Class Initialized
INFO - 2022-05-11 10:50:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:50:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:50:45 --> Utf8 Class Initialized
INFO - 2022-05-11 10:50:45 --> URI Class Initialized
INFO - 2022-05-11 10:50:45 --> Router Class Initialized
INFO - 2022-05-11 10:50:45 --> Output Class Initialized
INFO - 2022-05-11 10:50:45 --> Security Class Initialized
DEBUG - 2022-05-11 10:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:50:45 --> Input Class Initialized
INFO - 2022-05-11 10:50:45 --> Language Class Initialized
INFO - 2022-05-11 10:50:45 --> Language Class Initialized
INFO - 2022-05-11 10:50:45 --> Config Class Initialized
INFO - 2022-05-11 10:50:45 --> Loader Class Initialized
INFO - 2022-05-11 10:50:45 --> Helper loaded: url_helper
INFO - 2022-05-11 10:50:45 --> Database Driver Class Initialized
INFO - 2022-05-11 10:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:50:45 --> Controller Class Initialized
DEBUG - 2022-05-11 10:50:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:50:45 --> Model Class Initialized
DEBUG - 2022-05-11 10:50:45 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:50:45 --> Model Class Initialized
INFO - 2022-05-11 10:50:45 --> Final output sent to browser
DEBUG - 2022-05-11 10:50:45 --> Total execution time: 0.0391
INFO - 2022-05-11 10:51:14 --> Config Class Initialized
INFO - 2022-05-11 10:51:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:51:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:51:14 --> Utf8 Class Initialized
INFO - 2022-05-11 10:51:14 --> URI Class Initialized
INFO - 2022-05-11 10:51:14 --> Router Class Initialized
INFO - 2022-05-11 10:51:14 --> Output Class Initialized
INFO - 2022-05-11 10:51:14 --> Security Class Initialized
DEBUG - 2022-05-11 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:51:14 --> Input Class Initialized
INFO - 2022-05-11 10:51:14 --> Language Class Initialized
INFO - 2022-05-11 10:51:14 --> Language Class Initialized
INFO - 2022-05-11 10:51:14 --> Config Class Initialized
INFO - 2022-05-11 10:51:14 --> Loader Class Initialized
INFO - 2022-05-11 10:51:14 --> Helper loaded: url_helper
INFO - 2022-05-11 10:51:14 --> Database Driver Class Initialized
INFO - 2022-05-11 10:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:51:14 --> Controller Class Initialized
DEBUG - 2022-05-11 10:51:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:51:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:51:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:51:14 --> Model Class Initialized
INFO - 2022-05-11 10:51:14 --> Upload Class Initialized
INFO - 2022-05-11 10:51:14 --> Config Class Initialized
INFO - 2022-05-11 10:51:14 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:51:14 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:51:14 --> Utf8 Class Initialized
INFO - 2022-05-11 10:51:14 --> URI Class Initialized
INFO - 2022-05-11 10:51:14 --> Router Class Initialized
INFO - 2022-05-11 10:51:14 --> Output Class Initialized
INFO - 2022-05-11 10:51:14 --> Security Class Initialized
DEBUG - 2022-05-11 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:51:14 --> Input Class Initialized
INFO - 2022-05-11 10:51:14 --> Language Class Initialized
INFO - 2022-05-11 10:51:14 --> Language Class Initialized
INFO - 2022-05-11 10:51:14 --> Config Class Initialized
INFO - 2022-05-11 10:51:14 --> Loader Class Initialized
INFO - 2022-05-11 10:51:14 --> Helper loaded: url_helper
INFO - 2022-05-11 10:51:14 --> Database Driver Class Initialized
INFO - 2022-05-11 10:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:51:14 --> Controller Class Initialized
DEBUG - 2022-05-11 10:51:14 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:51:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:51:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:51:14 --> Model Class Initialized
DEBUG - 2022-05-11 10:51:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:51:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:51:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:51:14 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:51:14 --> Final output sent to browser
DEBUG - 2022-05-11 10:51:14 --> Total execution time: 0.0345
INFO - 2022-05-11 10:51:30 --> Config Class Initialized
INFO - 2022-05-11 10:51:30 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:51:30 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:51:30 --> Utf8 Class Initialized
INFO - 2022-05-11 10:51:30 --> URI Class Initialized
INFO - 2022-05-11 10:51:30 --> Router Class Initialized
INFO - 2022-05-11 10:51:30 --> Output Class Initialized
INFO - 2022-05-11 10:51:30 --> Security Class Initialized
DEBUG - 2022-05-11 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:51:30 --> Input Class Initialized
INFO - 2022-05-11 10:51:30 --> Language Class Initialized
INFO - 2022-05-11 10:51:30 --> Language Class Initialized
INFO - 2022-05-11 10:51:30 --> Config Class Initialized
INFO - 2022-05-11 10:51:30 --> Loader Class Initialized
INFO - 2022-05-11 10:51:30 --> Helper loaded: url_helper
INFO - 2022-05-11 10:51:30 --> Database Driver Class Initialized
INFO - 2022-05-11 10:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:51:30 --> Controller Class Initialized
DEBUG - 2022-05-11 10:51:30 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:51:30 --> Model Class Initialized
DEBUG - 2022-05-11 10:51:30 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:51:30 --> Model Class Initialized
DEBUG - 2022-05-11 10:51:30 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:51:30 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:51:30 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:51:30 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:51:30 --> Final output sent to browser
DEBUG - 2022-05-11 10:51:30 --> Total execution time: 0.0519
INFO - 2022-05-11 10:51:35 --> Config Class Initialized
INFO - 2022-05-11 10:51:35 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:51:35 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:51:35 --> Utf8 Class Initialized
INFO - 2022-05-11 10:51:35 --> URI Class Initialized
INFO - 2022-05-11 10:51:35 --> Router Class Initialized
INFO - 2022-05-11 10:51:35 --> Output Class Initialized
INFO - 2022-05-11 10:51:35 --> Security Class Initialized
DEBUG - 2022-05-11 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:51:35 --> Input Class Initialized
INFO - 2022-05-11 10:51:35 --> Language Class Initialized
INFO - 2022-05-11 10:51:35 --> Language Class Initialized
INFO - 2022-05-11 10:51:35 --> Config Class Initialized
INFO - 2022-05-11 10:51:35 --> Loader Class Initialized
INFO - 2022-05-11 10:51:35 --> Helper loaded: url_helper
INFO - 2022-05-11 10:51:35 --> Database Driver Class Initialized
INFO - 2022-05-11 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:51:35 --> Controller Class Initialized
DEBUG - 2022-05-11 10:51:35 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:51:35 --> Model Class Initialized
DEBUG - 2022-05-11 10:51:35 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:51:35 --> Model Class Initialized
INFO - 2022-05-11 10:51:35 --> Final output sent to browser
DEBUG - 2022-05-11 10:51:35 --> Total execution time: 0.0492
INFO - 2022-05-11 10:52:06 --> Config Class Initialized
INFO - 2022-05-11 10:52:06 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:52:06 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:52:06 --> Utf8 Class Initialized
INFO - 2022-05-11 10:52:06 --> URI Class Initialized
INFO - 2022-05-11 10:52:06 --> Router Class Initialized
INFO - 2022-05-11 10:52:06 --> Output Class Initialized
INFO - 2022-05-11 10:52:06 --> Security Class Initialized
DEBUG - 2022-05-11 10:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:52:06 --> Input Class Initialized
INFO - 2022-05-11 10:52:06 --> Language Class Initialized
INFO - 2022-05-11 10:52:06 --> Language Class Initialized
INFO - 2022-05-11 10:52:06 --> Config Class Initialized
INFO - 2022-05-11 10:52:06 --> Loader Class Initialized
INFO - 2022-05-11 10:52:06 --> Helper loaded: url_helper
INFO - 2022-05-11 10:52:06 --> Database Driver Class Initialized
INFO - 2022-05-11 10:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:52:06 --> Controller Class Initialized
DEBUG - 2022-05-11 10:52:06 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:52:06 --> Model Class Initialized
DEBUG - 2022-05-11 10:52:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:52:06 --> Model Class Initialized
INFO - 2022-05-11 10:52:06 --> Upload Class Initialized
INFO - 2022-05-11 10:52:06 --> Config Class Initialized
INFO - 2022-05-11 10:52:06 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:52:06 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:52:06 --> Utf8 Class Initialized
INFO - 2022-05-11 10:52:06 --> URI Class Initialized
INFO - 2022-05-11 10:52:06 --> Router Class Initialized
INFO - 2022-05-11 10:52:06 --> Output Class Initialized
INFO - 2022-05-11 10:52:06 --> Security Class Initialized
DEBUG - 2022-05-11 10:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:52:06 --> Input Class Initialized
INFO - 2022-05-11 10:52:06 --> Language Class Initialized
INFO - 2022-05-11 10:52:06 --> Language Class Initialized
INFO - 2022-05-11 10:52:06 --> Config Class Initialized
INFO - 2022-05-11 10:52:06 --> Loader Class Initialized
INFO - 2022-05-11 10:52:06 --> Helper loaded: url_helper
INFO - 2022-05-11 10:52:06 --> Database Driver Class Initialized
INFO - 2022-05-11 10:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:52:06 --> Controller Class Initialized
DEBUG - 2022-05-11 10:52:06 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:52:06 --> Model Class Initialized
DEBUG - 2022-05-11 10:52:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:52:06 --> Model Class Initialized
DEBUG - 2022-05-11 10:52:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:52:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:52:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:52:06 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:52:06 --> Final output sent to browser
DEBUG - 2022-05-11 10:52:06 --> Total execution time: 0.0346
INFO - 2022-05-11 10:53:51 --> Config Class Initialized
INFO - 2022-05-11 10:53:51 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:53:51 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:53:51 --> Utf8 Class Initialized
INFO - 2022-05-11 10:53:51 --> URI Class Initialized
INFO - 2022-05-11 10:53:51 --> Router Class Initialized
INFO - 2022-05-11 10:53:51 --> Output Class Initialized
INFO - 2022-05-11 10:53:51 --> Security Class Initialized
DEBUG - 2022-05-11 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:53:51 --> Input Class Initialized
INFO - 2022-05-11 10:53:51 --> Language Class Initialized
INFO - 2022-05-11 10:53:51 --> Language Class Initialized
INFO - 2022-05-11 10:53:51 --> Config Class Initialized
INFO - 2022-05-11 10:53:51 --> Loader Class Initialized
INFO - 2022-05-11 10:53:51 --> Helper loaded: url_helper
INFO - 2022-05-11 10:53:51 --> Database Driver Class Initialized
INFO - 2022-05-11 10:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:53:51 --> Controller Class Initialized
DEBUG - 2022-05-11 10:53:51 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:53:51 --> Model Class Initialized
DEBUG - 2022-05-11 10:53:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:53:51 --> Model Class Initialized
DEBUG - 2022-05-11 10:53:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:53:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:53:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:53:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:53:51 --> Final output sent to browser
DEBUG - 2022-05-11 10:53:51 --> Total execution time: 0.0566
INFO - 2022-05-11 10:53:52 --> Config Class Initialized
INFO - 2022-05-11 10:53:52 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:53:52 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:53:52 --> Utf8 Class Initialized
INFO - 2022-05-11 10:53:52 --> URI Class Initialized
INFO - 2022-05-11 10:53:52 --> Router Class Initialized
INFO - 2022-05-11 10:53:52 --> Output Class Initialized
INFO - 2022-05-11 10:53:52 --> Security Class Initialized
DEBUG - 2022-05-11 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:53:52 --> Input Class Initialized
INFO - 2022-05-11 10:53:52 --> Language Class Initialized
INFO - 2022-05-11 10:53:52 --> Language Class Initialized
INFO - 2022-05-11 10:53:52 --> Config Class Initialized
INFO - 2022-05-11 10:53:52 --> Loader Class Initialized
INFO - 2022-05-11 10:53:52 --> Helper loaded: url_helper
INFO - 2022-05-11 10:53:52 --> Database Driver Class Initialized
INFO - 2022-05-11 10:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:53:52 --> Controller Class Initialized
DEBUG - 2022-05-11 10:53:52 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:53:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:53:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:53:52 --> Model Class Initialized
DEBUG - 2022-05-11 10:53:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:53:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:53:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:53:52 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:53:52 --> Final output sent to browser
DEBUG - 2022-05-11 10:53:52 --> Total execution time: 0.0532
INFO - 2022-05-11 10:53:53 --> Config Class Initialized
INFO - 2022-05-11 10:53:53 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:53:53 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:53:53 --> Utf8 Class Initialized
INFO - 2022-05-11 10:53:53 --> URI Class Initialized
INFO - 2022-05-11 10:53:53 --> Router Class Initialized
INFO - 2022-05-11 10:53:53 --> Output Class Initialized
INFO - 2022-05-11 10:53:53 --> Security Class Initialized
DEBUG - 2022-05-11 10:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:53:53 --> Input Class Initialized
INFO - 2022-05-11 10:53:53 --> Language Class Initialized
INFO - 2022-05-11 10:53:53 --> Language Class Initialized
INFO - 2022-05-11 10:53:53 --> Config Class Initialized
INFO - 2022-05-11 10:53:53 --> Loader Class Initialized
INFO - 2022-05-11 10:53:53 --> Helper loaded: url_helper
INFO - 2022-05-11 10:53:54 --> Database Driver Class Initialized
INFO - 2022-05-11 10:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:53:54 --> Controller Class Initialized
DEBUG - 2022-05-11 10:53:54 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:53:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:53:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:53:54 --> Model Class Initialized
DEBUG - 2022-05-11 10:53:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:53:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:53:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:53:54 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:53:54 --> Final output sent to browser
DEBUG - 2022-05-11 10:53:54 --> Total execution time: 0.0532
INFO - 2022-05-11 10:54:09 --> Config Class Initialized
INFO - 2022-05-11 10:54:09 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:54:09 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:54:09 --> Utf8 Class Initialized
INFO - 2022-05-11 10:54:09 --> URI Class Initialized
INFO - 2022-05-11 10:54:09 --> Router Class Initialized
INFO - 2022-05-11 10:54:09 --> Output Class Initialized
INFO - 2022-05-11 10:54:09 --> Security Class Initialized
DEBUG - 2022-05-11 10:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:54:09 --> Input Class Initialized
INFO - 2022-05-11 10:54:09 --> Language Class Initialized
INFO - 2022-05-11 10:54:09 --> Language Class Initialized
INFO - 2022-05-11 10:54:09 --> Config Class Initialized
INFO - 2022-05-11 10:54:09 --> Loader Class Initialized
INFO - 2022-05-11 10:54:09 --> Helper loaded: url_helper
INFO - 2022-05-11 10:54:09 --> Database Driver Class Initialized
INFO - 2022-05-11 10:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:54:09 --> Controller Class Initialized
DEBUG - 2022-05-11 10:54:09 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:54:09 --> Model Class Initialized
DEBUG - 2022-05-11 10:54:09 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:54:09 --> Model Class Initialized
INFO - 2022-05-11 10:54:09 --> Final output sent to browser
DEBUG - 2022-05-11 10:54:09 --> Total execution time: 0.0487
INFO - 2022-05-11 10:55:26 --> Config Class Initialized
INFO - 2022-05-11 10:55:26 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:55:26 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:55:26 --> Utf8 Class Initialized
INFO - 2022-05-11 10:55:26 --> URI Class Initialized
INFO - 2022-05-11 10:55:26 --> Router Class Initialized
INFO - 2022-05-11 10:55:26 --> Output Class Initialized
INFO - 2022-05-11 10:55:26 --> Security Class Initialized
DEBUG - 2022-05-11 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:55:26 --> Input Class Initialized
INFO - 2022-05-11 10:55:26 --> Language Class Initialized
INFO - 2022-05-11 10:55:26 --> Language Class Initialized
INFO - 2022-05-11 10:55:26 --> Config Class Initialized
INFO - 2022-05-11 10:55:26 --> Loader Class Initialized
INFO - 2022-05-11 10:55:26 --> Helper loaded: url_helper
INFO - 2022-05-11 10:55:26 --> Database Driver Class Initialized
INFO - 2022-05-11 10:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:55:26 --> Controller Class Initialized
DEBUG - 2022-05-11 10:55:26 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:55:26 --> Model Class Initialized
DEBUG - 2022-05-11 10:55:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:55:26 --> Model Class Initialized
DEBUG - 2022-05-11 10:55:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:55:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:55:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:55:26 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:55:26 --> Final output sent to browser
DEBUG - 2022-05-11 10:55:26 --> Total execution time: 0.0301
INFO - 2022-05-11 10:56:17 --> Config Class Initialized
INFO - 2022-05-11 10:56:17 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:56:17 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:56:17 --> Utf8 Class Initialized
INFO - 2022-05-11 10:56:17 --> URI Class Initialized
INFO - 2022-05-11 10:56:17 --> Router Class Initialized
INFO - 2022-05-11 10:56:17 --> Output Class Initialized
INFO - 2022-05-11 10:56:17 --> Security Class Initialized
DEBUG - 2022-05-11 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:56:17 --> Input Class Initialized
INFO - 2022-05-11 10:56:17 --> Language Class Initialized
INFO - 2022-05-11 10:56:17 --> Language Class Initialized
INFO - 2022-05-11 10:56:17 --> Config Class Initialized
INFO - 2022-05-11 10:56:17 --> Loader Class Initialized
INFO - 2022-05-11 10:56:17 --> Helper loaded: url_helper
INFO - 2022-05-11 10:56:17 --> Database Driver Class Initialized
INFO - 2022-05-11 10:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:56:17 --> Controller Class Initialized
DEBUG - 2022-05-11 10:56:17 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:56:17 --> Model Class Initialized
DEBUG - 2022-05-11 10:56:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:56:17 --> Model Class Initialized
DEBUG - 2022-05-11 10:56:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:56:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:56:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:56:17 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:56:17 --> Final output sent to browser
DEBUG - 2022-05-11 10:56:17 --> Total execution time: 0.0537
INFO - 2022-05-11 10:56:22 --> Config Class Initialized
INFO - 2022-05-11 10:56:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:56:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:56:22 --> Utf8 Class Initialized
INFO - 2022-05-11 10:56:22 --> URI Class Initialized
INFO - 2022-05-11 10:56:22 --> Router Class Initialized
INFO - 2022-05-11 10:56:22 --> Output Class Initialized
INFO - 2022-05-11 10:56:22 --> Security Class Initialized
DEBUG - 2022-05-11 10:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:56:22 --> Input Class Initialized
INFO - 2022-05-11 10:56:22 --> Language Class Initialized
INFO - 2022-05-11 10:56:22 --> Language Class Initialized
INFO - 2022-05-11 10:56:22 --> Config Class Initialized
INFO - 2022-05-11 10:56:23 --> Loader Class Initialized
INFO - 2022-05-11 10:56:23 --> Helper loaded: url_helper
INFO - 2022-05-11 10:56:23 --> Database Driver Class Initialized
INFO - 2022-05-11 10:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:56:23 --> Controller Class Initialized
DEBUG - 2022-05-11 10:56:23 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:56:23 --> Model Class Initialized
DEBUG - 2022-05-11 10:56:23 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:56:23 --> Model Class Initialized
INFO - 2022-05-11 10:56:23 --> Final output sent to browser
DEBUG - 2022-05-11 10:56:23 --> Total execution time: 0.0428
INFO - 2022-05-11 10:56:51 --> Config Class Initialized
INFO - 2022-05-11 10:56:51 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:56:51 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:56:51 --> Utf8 Class Initialized
INFO - 2022-05-11 10:56:51 --> URI Class Initialized
INFO - 2022-05-11 10:56:51 --> Router Class Initialized
INFO - 2022-05-11 10:56:51 --> Output Class Initialized
INFO - 2022-05-11 10:56:51 --> Security Class Initialized
DEBUG - 2022-05-11 10:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:56:51 --> Input Class Initialized
INFO - 2022-05-11 10:56:51 --> Language Class Initialized
INFO - 2022-05-11 10:56:51 --> Language Class Initialized
INFO - 2022-05-11 10:56:51 --> Config Class Initialized
INFO - 2022-05-11 10:56:51 --> Loader Class Initialized
INFO - 2022-05-11 10:56:51 --> Helper loaded: url_helper
INFO - 2022-05-11 10:56:51 --> Database Driver Class Initialized
INFO - 2022-05-11 10:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:56:51 --> Controller Class Initialized
DEBUG - 2022-05-11 10:56:51 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:56:51 --> Model Class Initialized
DEBUG - 2022-05-11 10:56:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:56:51 --> Model Class Initialized
INFO - 2022-05-11 10:56:51 --> Upload Class Initialized
INFO - 2022-05-11 10:56:51 --> Config Class Initialized
INFO - 2022-05-11 10:56:51 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:56:51 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:56:51 --> Utf8 Class Initialized
INFO - 2022-05-11 10:56:51 --> URI Class Initialized
INFO - 2022-05-11 10:56:51 --> Router Class Initialized
INFO - 2022-05-11 10:56:51 --> Output Class Initialized
INFO - 2022-05-11 10:56:51 --> Security Class Initialized
DEBUG - 2022-05-11 10:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:56:51 --> Input Class Initialized
INFO - 2022-05-11 10:56:51 --> Language Class Initialized
INFO - 2022-05-11 10:56:51 --> Language Class Initialized
INFO - 2022-05-11 10:56:51 --> Config Class Initialized
INFO - 2022-05-11 10:56:51 --> Loader Class Initialized
INFO - 2022-05-11 10:56:51 --> Helper loaded: url_helper
INFO - 2022-05-11 10:56:51 --> Database Driver Class Initialized
INFO - 2022-05-11 10:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:56:51 --> Controller Class Initialized
DEBUG - 2022-05-11 10:56:51 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:56:51 --> Model Class Initialized
DEBUG - 2022-05-11 10:56:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:56:51 --> Model Class Initialized
DEBUG - 2022-05-11 10:56:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:56:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:56:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:56:51 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:56:51 --> Final output sent to browser
DEBUG - 2022-05-11 10:56:51 --> Total execution time: 0.0665
INFO - 2022-05-11 10:57:19 --> Config Class Initialized
INFO - 2022-05-11 10:57:19 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:57:19 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:57:19 --> Utf8 Class Initialized
INFO - 2022-05-11 10:57:19 --> URI Class Initialized
INFO - 2022-05-11 10:57:19 --> Router Class Initialized
INFO - 2022-05-11 10:57:19 --> Output Class Initialized
INFO - 2022-05-11 10:57:19 --> Security Class Initialized
DEBUG - 2022-05-11 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:57:19 --> Input Class Initialized
INFO - 2022-05-11 10:57:19 --> Language Class Initialized
INFO - 2022-05-11 10:57:19 --> Language Class Initialized
INFO - 2022-05-11 10:57:19 --> Config Class Initialized
INFO - 2022-05-11 10:57:19 --> Loader Class Initialized
INFO - 2022-05-11 10:57:19 --> Helper loaded: url_helper
INFO - 2022-05-11 10:57:19 --> Database Driver Class Initialized
INFO - 2022-05-11 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:57:19 --> Controller Class Initialized
DEBUG - 2022-05-11 10:57:19 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:57:19 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:57:19 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:57:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:57:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:57:19 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:57:19 --> Final output sent to browser
DEBUG - 2022-05-11 10:57:19 --> Total execution time: 0.0487
INFO - 2022-05-11 10:57:21 --> Config Class Initialized
INFO - 2022-05-11 10:57:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:57:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:57:21 --> Utf8 Class Initialized
INFO - 2022-05-11 10:57:21 --> URI Class Initialized
INFO - 2022-05-11 10:57:21 --> Router Class Initialized
INFO - 2022-05-11 10:57:21 --> Output Class Initialized
INFO - 2022-05-11 10:57:21 --> Security Class Initialized
DEBUG - 2022-05-11 10:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:57:21 --> Input Class Initialized
INFO - 2022-05-11 10:57:21 --> Language Class Initialized
INFO - 2022-05-11 10:57:21 --> Language Class Initialized
INFO - 2022-05-11 10:57:21 --> Config Class Initialized
INFO - 2022-05-11 10:57:21 --> Loader Class Initialized
INFO - 2022-05-11 10:57:21 --> Helper loaded: url_helper
INFO - 2022-05-11 10:57:21 --> Database Driver Class Initialized
INFO - 2022-05-11 10:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:57:21 --> Controller Class Initialized
DEBUG - 2022-05-11 10:57:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:57:21 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:57:21 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:57:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:57:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:57:21 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:57:21 --> Final output sent to browser
DEBUG - 2022-05-11 10:57:21 --> Total execution time: 0.0294
INFO - 2022-05-11 10:57:25 --> Config Class Initialized
INFO - 2022-05-11 10:57:25 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:57:25 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:57:25 --> Utf8 Class Initialized
INFO - 2022-05-11 10:57:25 --> URI Class Initialized
INFO - 2022-05-11 10:57:25 --> Router Class Initialized
INFO - 2022-05-11 10:57:25 --> Output Class Initialized
INFO - 2022-05-11 10:57:25 --> Security Class Initialized
DEBUG - 2022-05-11 10:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:57:25 --> Input Class Initialized
INFO - 2022-05-11 10:57:25 --> Language Class Initialized
INFO - 2022-05-11 10:57:25 --> Language Class Initialized
INFO - 2022-05-11 10:57:25 --> Config Class Initialized
INFO - 2022-05-11 10:57:25 --> Loader Class Initialized
INFO - 2022-05-11 10:57:25 --> Helper loaded: url_helper
INFO - 2022-05-11 10:57:25 --> Database Driver Class Initialized
INFO - 2022-05-11 10:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:57:25 --> Controller Class Initialized
DEBUG - 2022-05-11 10:57:25 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:57:25 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:57:25 --> Model Class Initialized
INFO - 2022-05-11 10:57:25 --> Config Class Initialized
INFO - 2022-05-11 10:57:25 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:57:25 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:57:25 --> Utf8 Class Initialized
INFO - 2022-05-11 10:57:25 --> URI Class Initialized
INFO - 2022-05-11 10:57:25 --> Router Class Initialized
INFO - 2022-05-11 10:57:25 --> Output Class Initialized
INFO - 2022-05-11 10:57:25 --> Security Class Initialized
DEBUG - 2022-05-11 10:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:57:25 --> Input Class Initialized
INFO - 2022-05-11 10:57:25 --> Language Class Initialized
INFO - 2022-05-11 10:57:25 --> Language Class Initialized
INFO - 2022-05-11 10:57:25 --> Config Class Initialized
INFO - 2022-05-11 10:57:25 --> Loader Class Initialized
INFO - 2022-05-11 10:57:25 --> Helper loaded: url_helper
INFO - 2022-05-11 10:57:25 --> Database Driver Class Initialized
INFO - 2022-05-11 10:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:57:25 --> Controller Class Initialized
DEBUG - 2022-05-11 10:57:25 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:57:25 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:57:25 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:57:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:57:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:57:25 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:57:25 --> Final output sent to browser
DEBUG - 2022-05-11 10:57:25 --> Total execution time: 0.0408
INFO - 2022-05-11 10:57:53 --> Config Class Initialized
INFO - 2022-05-11 10:57:53 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:57:53 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:57:53 --> Utf8 Class Initialized
INFO - 2022-05-11 10:57:53 --> URI Class Initialized
INFO - 2022-05-11 10:57:53 --> Router Class Initialized
INFO - 2022-05-11 10:57:53 --> Output Class Initialized
INFO - 2022-05-11 10:57:53 --> Security Class Initialized
DEBUG - 2022-05-11 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:57:53 --> Input Class Initialized
INFO - 2022-05-11 10:57:53 --> Language Class Initialized
INFO - 2022-05-11 10:57:53 --> Language Class Initialized
INFO - 2022-05-11 10:57:53 --> Config Class Initialized
INFO - 2022-05-11 10:57:53 --> Loader Class Initialized
INFO - 2022-05-11 10:57:53 --> Helper loaded: url_helper
INFO - 2022-05-11 10:57:53 --> Database Driver Class Initialized
INFO - 2022-05-11 10:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:57:53 --> Controller Class Initialized
DEBUG - 2022-05-11 10:57:53 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:57:53 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:53 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:57:53 --> Model Class Initialized
DEBUG - 2022-05-11 10:57:53 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:57:53 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:57:53 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:57:53 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:57:53 --> Final output sent to browser
DEBUG - 2022-05-11 10:57:53 --> Total execution time: 0.0536
INFO - 2022-05-11 10:58:00 --> Config Class Initialized
INFO - 2022-05-11 10:58:00 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:58:00 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:58:00 --> Utf8 Class Initialized
INFO - 2022-05-11 10:58:00 --> URI Class Initialized
INFO - 2022-05-11 10:58:00 --> Router Class Initialized
INFO - 2022-05-11 10:58:00 --> Output Class Initialized
INFO - 2022-05-11 10:58:00 --> Security Class Initialized
DEBUG - 2022-05-11 10:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:58:00 --> Input Class Initialized
INFO - 2022-05-11 10:58:00 --> Language Class Initialized
INFO - 2022-05-11 10:58:00 --> Language Class Initialized
INFO - 2022-05-11 10:58:00 --> Config Class Initialized
INFO - 2022-05-11 10:58:00 --> Loader Class Initialized
INFO - 2022-05-11 10:58:00 --> Helper loaded: url_helper
INFO - 2022-05-11 10:58:00 --> Database Driver Class Initialized
INFO - 2022-05-11 10:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:58:00 --> Controller Class Initialized
DEBUG - 2022-05-11 10:58:00 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:58:00 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:58:00 --> Model Class Initialized
INFO - 2022-05-11 10:58:00 --> Final output sent to browser
DEBUG - 2022-05-11 10:58:00 --> Total execution time: 0.0402
INFO - 2022-05-11 10:58:37 --> Config Class Initialized
INFO - 2022-05-11 10:58:37 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:58:37 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:58:37 --> Utf8 Class Initialized
INFO - 2022-05-11 10:58:37 --> URI Class Initialized
INFO - 2022-05-11 10:58:37 --> Router Class Initialized
INFO - 2022-05-11 10:58:37 --> Output Class Initialized
INFO - 2022-05-11 10:58:37 --> Security Class Initialized
DEBUG - 2022-05-11 10:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:58:37 --> Input Class Initialized
INFO - 2022-05-11 10:58:37 --> Language Class Initialized
INFO - 2022-05-11 10:58:37 --> Language Class Initialized
INFO - 2022-05-11 10:58:37 --> Config Class Initialized
INFO - 2022-05-11 10:58:37 --> Loader Class Initialized
INFO - 2022-05-11 10:58:37 --> Helper loaded: url_helper
INFO - 2022-05-11 10:58:37 --> Database Driver Class Initialized
INFO - 2022-05-11 10:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:58:37 --> Controller Class Initialized
DEBUG - 2022-05-11 10:58:37 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:58:37 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:58:37 --> Model Class Initialized
INFO - 2022-05-11 10:58:37 --> Upload Class Initialized
INFO - 2022-05-11 10:58:37 --> Config Class Initialized
INFO - 2022-05-11 10:58:37 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:58:37 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:58:37 --> Utf8 Class Initialized
INFO - 2022-05-11 10:58:37 --> URI Class Initialized
INFO - 2022-05-11 10:58:37 --> Router Class Initialized
INFO - 2022-05-11 10:58:37 --> Output Class Initialized
INFO - 2022-05-11 10:58:37 --> Security Class Initialized
DEBUG - 2022-05-11 10:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:58:37 --> Input Class Initialized
INFO - 2022-05-11 10:58:37 --> Language Class Initialized
INFO - 2022-05-11 10:58:37 --> Language Class Initialized
INFO - 2022-05-11 10:58:37 --> Config Class Initialized
INFO - 2022-05-11 10:58:37 --> Loader Class Initialized
INFO - 2022-05-11 10:58:37 --> Helper loaded: url_helper
INFO - 2022-05-11 10:58:37 --> Database Driver Class Initialized
INFO - 2022-05-11 10:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:58:37 --> Controller Class Initialized
DEBUG - 2022-05-11 10:58:37 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:58:37 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:58:37 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:58:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:58:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:58:37 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:58:37 --> Final output sent to browser
DEBUG - 2022-05-11 10:58:37 --> Total execution time: 0.0463
INFO - 2022-05-11 10:58:40 --> Config Class Initialized
INFO - 2022-05-11 10:58:40 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:58:40 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:58:40 --> Utf8 Class Initialized
INFO - 2022-05-11 10:58:40 --> URI Class Initialized
INFO - 2022-05-11 10:58:40 --> Router Class Initialized
INFO - 2022-05-11 10:58:40 --> Output Class Initialized
INFO - 2022-05-11 10:58:40 --> Security Class Initialized
DEBUG - 2022-05-11 10:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:58:40 --> Input Class Initialized
INFO - 2022-05-11 10:58:40 --> Language Class Initialized
INFO - 2022-05-11 10:58:40 --> Language Class Initialized
INFO - 2022-05-11 10:58:40 --> Config Class Initialized
INFO - 2022-05-11 10:58:40 --> Loader Class Initialized
INFO - 2022-05-11 10:58:40 --> Helper loaded: url_helper
INFO - 2022-05-11 10:58:40 --> Database Driver Class Initialized
INFO - 2022-05-11 10:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:58:40 --> Controller Class Initialized
DEBUG - 2022-05-11 10:58:40 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:58:40 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:58:40 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:58:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:58:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:58:40 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:58:40 --> Final output sent to browser
DEBUG - 2022-05-11 10:58:40 --> Total execution time: 0.0407
INFO - 2022-05-11 10:58:46 --> Config Class Initialized
INFO - 2022-05-11 10:58:46 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:58:46 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:58:46 --> Utf8 Class Initialized
INFO - 2022-05-11 10:58:46 --> URI Class Initialized
INFO - 2022-05-11 10:58:46 --> Router Class Initialized
INFO - 2022-05-11 10:58:46 --> Output Class Initialized
INFO - 2022-05-11 10:58:46 --> Security Class Initialized
DEBUG - 2022-05-11 10:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:58:46 --> Input Class Initialized
INFO - 2022-05-11 10:58:46 --> Language Class Initialized
INFO - 2022-05-11 10:58:46 --> Language Class Initialized
INFO - 2022-05-11 10:58:46 --> Config Class Initialized
INFO - 2022-05-11 10:58:46 --> Loader Class Initialized
INFO - 2022-05-11 10:58:46 --> Helper loaded: url_helper
INFO - 2022-05-11 10:58:46 --> Database Driver Class Initialized
INFO - 2022-05-11 10:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:58:46 --> Controller Class Initialized
DEBUG - 2022-05-11 10:58:46 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:58:46 --> Model Class Initialized
DEBUG - 2022-05-11 10:58:46 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:58:46 --> Model Class Initialized
INFO - 2022-05-11 10:58:46 --> Final output sent to browser
DEBUG - 2022-05-11 10:58:46 --> Total execution time: 0.0372
INFO - 2022-05-11 10:59:20 --> Config Class Initialized
INFO - 2022-05-11 10:59:20 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:59:20 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:59:20 --> Utf8 Class Initialized
INFO - 2022-05-11 10:59:20 --> URI Class Initialized
INFO - 2022-05-11 10:59:20 --> Router Class Initialized
INFO - 2022-05-11 10:59:20 --> Output Class Initialized
INFO - 2022-05-11 10:59:20 --> Security Class Initialized
DEBUG - 2022-05-11 10:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:59:20 --> Input Class Initialized
INFO - 2022-05-11 10:59:20 --> Language Class Initialized
INFO - 2022-05-11 10:59:20 --> Language Class Initialized
INFO - 2022-05-11 10:59:20 --> Config Class Initialized
INFO - 2022-05-11 10:59:20 --> Loader Class Initialized
INFO - 2022-05-11 10:59:20 --> Helper loaded: url_helper
INFO - 2022-05-11 10:59:20 --> Database Driver Class Initialized
INFO - 2022-05-11 10:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:59:20 --> Controller Class Initialized
DEBUG - 2022-05-11 10:59:20 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:59:20 --> Model Class Initialized
DEBUG - 2022-05-11 10:59:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:59:20 --> Model Class Initialized
DEBUG - 2022-05-11 10:59:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:59:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:59:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 10:59:20 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:59:20 --> Final output sent to browser
DEBUG - 2022-05-11 10:59:20 --> Total execution time: 0.0307
INFO - 2022-05-11 10:59:57 --> Config Class Initialized
INFO - 2022-05-11 10:59:57 --> Hooks Class Initialized
DEBUG - 2022-05-11 10:59:57 --> UTF-8 Support Enabled
INFO - 2022-05-11 10:59:57 --> Utf8 Class Initialized
INFO - 2022-05-11 10:59:57 --> URI Class Initialized
INFO - 2022-05-11 10:59:57 --> Router Class Initialized
INFO - 2022-05-11 10:59:57 --> Output Class Initialized
INFO - 2022-05-11 10:59:57 --> Security Class Initialized
DEBUG - 2022-05-11 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 10:59:57 --> Input Class Initialized
INFO - 2022-05-11 10:59:57 --> Language Class Initialized
INFO - 2022-05-11 10:59:57 --> Language Class Initialized
INFO - 2022-05-11 10:59:57 --> Config Class Initialized
INFO - 2022-05-11 10:59:57 --> Loader Class Initialized
INFO - 2022-05-11 10:59:57 --> Helper loaded: url_helper
INFO - 2022-05-11 10:59:57 --> Database Driver Class Initialized
INFO - 2022-05-11 10:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 10:59:57 --> Controller Class Initialized
DEBUG - 2022-05-11 10:59:57 --> Admin MX_Controller Initialized
INFO - 2022-05-11 10:59:57 --> Model Class Initialized
DEBUG - 2022-05-11 10:59:57 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 10:59:57 --> Model Class Initialized
DEBUG - 2022-05-11 10:59:57 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 10:59:57 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 10:59:57 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 10:59:57 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 10:59:57 --> Final output sent to browser
DEBUG - 2022-05-11 10:59:57 --> Total execution time: 0.0515
INFO - 2022-05-11 11:00:00 --> Config Class Initialized
INFO - 2022-05-11 11:00:00 --> Hooks Class Initialized
DEBUG - 2022-05-11 11:00:00 --> UTF-8 Support Enabled
INFO - 2022-05-11 11:00:00 --> Utf8 Class Initialized
INFO - 2022-05-11 11:00:00 --> URI Class Initialized
INFO - 2022-05-11 11:00:00 --> Router Class Initialized
INFO - 2022-05-11 11:00:00 --> Output Class Initialized
INFO - 2022-05-11 11:00:00 --> Security Class Initialized
DEBUG - 2022-05-11 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 11:00:00 --> Input Class Initialized
INFO - 2022-05-11 11:00:00 --> Language Class Initialized
INFO - 2022-05-11 11:00:00 --> Language Class Initialized
INFO - 2022-05-11 11:00:00 --> Config Class Initialized
INFO - 2022-05-11 11:00:00 --> Loader Class Initialized
INFO - 2022-05-11 11:00:00 --> Helper loaded: url_helper
INFO - 2022-05-11 11:00:00 --> Database Driver Class Initialized
INFO - 2022-05-11 11:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 11:00:00 --> Controller Class Initialized
DEBUG - 2022-05-11 11:00:00 --> Admin MX_Controller Initialized
INFO - 2022-05-11 11:00:00 --> Model Class Initialized
DEBUG - 2022-05-11 11:00:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 11:00:00 --> Model Class Initialized
DEBUG - 2022-05-11 11:00:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 11:00:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 11:00:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 11:00:00 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 11:00:00 --> Final output sent to browser
DEBUG - 2022-05-11 11:00:00 --> Total execution time: 0.0538
INFO - 2022-05-11 11:00:22 --> Config Class Initialized
INFO - 2022-05-11 11:00:22 --> Hooks Class Initialized
DEBUG - 2022-05-11 11:00:22 --> UTF-8 Support Enabled
INFO - 2022-05-11 11:00:22 --> Utf8 Class Initialized
INFO - 2022-05-11 11:00:22 --> URI Class Initialized
INFO - 2022-05-11 11:00:22 --> Router Class Initialized
INFO - 2022-05-11 11:00:22 --> Output Class Initialized
INFO - 2022-05-11 11:00:22 --> Security Class Initialized
DEBUG - 2022-05-11 11:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 11:00:22 --> Input Class Initialized
INFO - 2022-05-11 11:00:22 --> Language Class Initialized
INFO - 2022-05-11 11:00:22 --> Language Class Initialized
INFO - 2022-05-11 11:00:22 --> Config Class Initialized
INFO - 2022-05-11 11:00:22 --> Loader Class Initialized
INFO - 2022-05-11 11:00:22 --> Helper loaded: url_helper
INFO - 2022-05-11 11:00:22 --> Database Driver Class Initialized
INFO - 2022-05-11 11:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 11:00:22 --> Controller Class Initialized
DEBUG - 2022-05-11 11:00:22 --> Admin MX_Controller Initialized
INFO - 2022-05-11 11:00:22 --> Model Class Initialized
DEBUG - 2022-05-11 11:00:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 11:00:22 --> Model Class Initialized
DEBUG - 2022-05-11 11:00:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 11:00:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 11:00:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 11:00:22 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 11:00:22 --> Final output sent to browser
DEBUG - 2022-05-11 11:00:22 --> Total execution time: 0.0425
INFO - 2022-05-11 11:00:29 --> Config Class Initialized
INFO - 2022-05-11 11:00:29 --> Hooks Class Initialized
DEBUG - 2022-05-11 11:00:29 --> UTF-8 Support Enabled
INFO - 2022-05-11 11:00:29 --> Utf8 Class Initialized
INFO - 2022-05-11 11:00:29 --> URI Class Initialized
INFO - 2022-05-11 11:00:29 --> Router Class Initialized
INFO - 2022-05-11 11:00:29 --> Output Class Initialized
INFO - 2022-05-11 11:00:29 --> Security Class Initialized
DEBUG - 2022-05-11 11:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 11:00:29 --> Input Class Initialized
INFO - 2022-05-11 11:00:29 --> Language Class Initialized
INFO - 2022-05-11 11:00:29 --> Language Class Initialized
INFO - 2022-05-11 11:00:29 --> Config Class Initialized
INFO - 2022-05-11 11:00:29 --> Loader Class Initialized
INFO - 2022-05-11 11:00:29 --> Helper loaded: url_helper
INFO - 2022-05-11 11:00:29 --> Database Driver Class Initialized
INFO - 2022-05-11 11:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 11:00:29 --> Controller Class Initialized
DEBUG - 2022-05-11 11:00:29 --> Admin MX_Controller Initialized
INFO - 2022-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2022-05-11 11:00:29 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 11:00:29 --> Model Class Initialized
INFO - 2022-05-11 11:00:29 --> Final output sent to browser
DEBUG - 2022-05-11 11:00:29 --> Total execution time: 0.0415
INFO - 2022-05-11 11:01:16 --> Config Class Initialized
INFO - 2022-05-11 11:01:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 11:01:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 11:01:16 --> Utf8 Class Initialized
INFO - 2022-05-11 11:01:16 --> URI Class Initialized
INFO - 2022-05-11 11:01:16 --> Router Class Initialized
INFO - 2022-05-11 11:01:16 --> Output Class Initialized
INFO - 2022-05-11 11:01:16 --> Security Class Initialized
DEBUG - 2022-05-11 11:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 11:01:16 --> Input Class Initialized
INFO - 2022-05-11 11:01:16 --> Language Class Initialized
INFO - 2022-05-11 11:01:16 --> Language Class Initialized
INFO - 2022-05-11 11:01:16 --> Config Class Initialized
INFO - 2022-05-11 11:01:16 --> Loader Class Initialized
INFO - 2022-05-11 11:01:16 --> Helper loaded: url_helper
INFO - 2022-05-11 11:01:16 --> Database Driver Class Initialized
INFO - 2022-05-11 11:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 11:01:16 --> Controller Class Initialized
DEBUG - 2022-05-11 11:01:16 --> Admin MX_Controller Initialized
INFO - 2022-05-11 11:01:16 --> Model Class Initialized
DEBUG - 2022-05-11 11:01:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 11:01:16 --> Model Class Initialized
INFO - 2022-05-11 11:01:16 --> Upload Class Initialized
INFO - 2022-05-11 11:01:16 --> Config Class Initialized
INFO - 2022-05-11 11:01:16 --> Hooks Class Initialized
DEBUG - 2022-05-11 11:01:16 --> UTF-8 Support Enabled
INFO - 2022-05-11 11:01:16 --> Utf8 Class Initialized
INFO - 2022-05-11 11:01:16 --> URI Class Initialized
INFO - 2022-05-11 11:01:16 --> Router Class Initialized
INFO - 2022-05-11 11:01:16 --> Output Class Initialized
INFO - 2022-05-11 11:01:16 --> Security Class Initialized
DEBUG - 2022-05-11 11:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 11:01:16 --> Input Class Initialized
INFO - 2022-05-11 11:01:16 --> Language Class Initialized
INFO - 2022-05-11 11:01:16 --> Language Class Initialized
INFO - 2022-05-11 11:01:16 --> Config Class Initialized
INFO - 2022-05-11 11:01:16 --> Loader Class Initialized
INFO - 2022-05-11 11:01:16 --> Helper loaded: url_helper
INFO - 2022-05-11 11:01:16 --> Database Driver Class Initialized
INFO - 2022-05-11 11:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 11:01:16 --> Controller Class Initialized
DEBUG - 2022-05-11 11:01:16 --> Admin MX_Controller Initialized
INFO - 2022-05-11 11:01:16 --> Model Class Initialized
DEBUG - 2022-05-11 11:01:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 11:01:16 --> Model Class Initialized
DEBUG - 2022-05-11 11:01:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 11:01:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 11:01:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 11:01:16 --> File loaded: C:\xampp\htdocs\vm\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 11:01:16 --> Final output sent to browser
DEBUG - 2022-05-11 11:01:16 --> Total execution time: 0.0575
INFO - 2022-05-11 19:40:32 --> Config Class Initialized
INFO - 2022-05-11 19:40:32 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:40:32 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:40:32 --> Utf8 Class Initialized
INFO - 2022-05-11 19:40:32 --> URI Class Initialized
INFO - 2022-05-11 19:40:32 --> Router Class Initialized
INFO - 2022-05-11 19:40:32 --> Output Class Initialized
INFO - 2022-05-11 19:40:32 --> Security Class Initialized
DEBUG - 2022-05-11 19:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:40:32 --> Input Class Initialized
INFO - 2022-05-11 19:40:32 --> Language Class Initialized
INFO - 2022-05-11 19:40:32 --> Language Class Initialized
INFO - 2022-05-11 19:40:32 --> Config Class Initialized
INFO - 2022-05-11 19:40:33 --> Loader Class Initialized
INFO - 2022-05-11 19:40:33 --> Helper loaded: url_helper
INFO - 2022-05-11 19:40:33 --> Database Driver Class Initialized
INFO - 2022-05-11 19:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:40:33 --> Controller Class Initialized
DEBUG - 2022-05-11 19:40:33 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:40:33 --> Model Class Initialized
DEBUG - 2022-05-11 19:40:33 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:40:33 --> Model Class Initialized
DEBUG - 2022-05-11 19:40:33 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 19:40:33 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 19:40:33 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-11 19:40:33 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 19:40:33 --> Final output sent to browser
DEBUG - 2022-05-11 19:40:33 --> Total execution time: 1.2973
INFO - 2022-05-11 19:41:07 --> Config Class Initialized
INFO - 2022-05-11 19:41:07 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:41:07 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:41:07 --> Utf8 Class Initialized
INFO - 2022-05-11 19:41:07 --> URI Class Initialized
INFO - 2022-05-11 19:41:07 --> Router Class Initialized
INFO - 2022-05-11 19:41:07 --> Output Class Initialized
INFO - 2022-05-11 19:41:07 --> Security Class Initialized
DEBUG - 2022-05-11 19:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:41:07 --> Input Class Initialized
INFO - 2022-05-11 19:41:07 --> Language Class Initialized
INFO - 2022-05-11 19:41:07 --> Language Class Initialized
INFO - 2022-05-11 19:41:07 --> Config Class Initialized
INFO - 2022-05-11 19:41:07 --> Loader Class Initialized
INFO - 2022-05-11 19:41:07 --> Helper loaded: url_helper
INFO - 2022-05-11 19:41:07 --> Database Driver Class Initialized
INFO - 2022-05-11 19:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:41:07 --> Controller Class Initialized
DEBUG - 2022-05-11 19:41:07 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:41:07 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:07 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:41:07 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:09 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 19:41:09 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 19:41:09 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 19:41:09 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 19:41:09 --> Final output sent to browser
DEBUG - 2022-05-11 19:41:09 --> Total execution time: 1.5554
INFO - 2022-05-11 19:41:17 --> Config Class Initialized
INFO - 2022-05-11 19:41:17 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:41:17 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:41:17 --> Utf8 Class Initialized
INFO - 2022-05-11 19:41:17 --> URI Class Initialized
INFO - 2022-05-11 19:41:17 --> Router Class Initialized
INFO - 2022-05-11 19:41:17 --> Output Class Initialized
INFO - 2022-05-11 19:41:17 --> Security Class Initialized
DEBUG - 2022-05-11 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:41:17 --> Input Class Initialized
INFO - 2022-05-11 19:41:17 --> Language Class Initialized
INFO - 2022-05-11 19:41:17 --> Language Class Initialized
INFO - 2022-05-11 19:41:17 --> Config Class Initialized
INFO - 2022-05-11 19:41:17 --> Loader Class Initialized
INFO - 2022-05-11 19:41:17 --> Helper loaded: url_helper
INFO - 2022-05-11 19:41:17 --> Database Driver Class Initialized
INFO - 2022-05-11 19:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:41:17 --> Controller Class Initialized
DEBUG - 2022-05-11 19:41:17 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:41:17 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:17 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:41:17 --> Model Class Initialized
INFO - 2022-05-11 19:41:17 --> Config Class Initialized
INFO - 2022-05-11 19:41:17 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:41:17 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:41:17 --> Utf8 Class Initialized
INFO - 2022-05-11 19:41:17 --> URI Class Initialized
INFO - 2022-05-11 19:41:17 --> Router Class Initialized
INFO - 2022-05-11 19:41:17 --> Output Class Initialized
INFO - 2022-05-11 19:41:17 --> Security Class Initialized
DEBUG - 2022-05-11 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:41:17 --> Input Class Initialized
INFO - 2022-05-11 19:41:17 --> Language Class Initialized
INFO - 2022-05-11 19:41:17 --> Language Class Initialized
INFO - 2022-05-11 19:41:17 --> Config Class Initialized
INFO - 2022-05-11 19:41:17 --> Loader Class Initialized
INFO - 2022-05-11 19:41:17 --> Helper loaded: url_helper
INFO - 2022-05-11 19:41:17 --> Database Driver Class Initialized
INFO - 2022-05-11 19:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:41:17 --> Controller Class Initialized
DEBUG - 2022-05-11 19:41:17 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:41:17 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:17 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:41:17 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:17 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 19:41:17 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 19:41:17 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 19:41:17 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 19:41:17 --> Final output sent to browser
DEBUG - 2022-05-11 19:41:17 --> Total execution time: 0.0637
INFO - 2022-05-11 19:41:21 --> Config Class Initialized
INFO - 2022-05-11 19:41:21 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:41:21 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:41:21 --> Utf8 Class Initialized
INFO - 2022-05-11 19:41:21 --> URI Class Initialized
INFO - 2022-05-11 19:41:21 --> Router Class Initialized
INFO - 2022-05-11 19:41:21 --> Output Class Initialized
INFO - 2022-05-11 19:41:21 --> Security Class Initialized
DEBUG - 2022-05-11 19:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:41:21 --> Input Class Initialized
INFO - 2022-05-11 19:41:21 --> Language Class Initialized
INFO - 2022-05-11 19:41:21 --> Language Class Initialized
INFO - 2022-05-11 19:41:21 --> Config Class Initialized
INFO - 2022-05-11 19:41:21 --> Loader Class Initialized
INFO - 2022-05-11 19:41:21 --> Helper loaded: url_helper
INFO - 2022-05-11 19:41:21 --> Database Driver Class Initialized
INFO - 2022-05-11 19:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:41:21 --> Controller Class Initialized
DEBUG - 2022-05-11 19:41:21 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:41:21 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:21 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:41:21 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:21 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 19:41:21 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 19:41:22 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-11 19:41:22 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 19:41:22 --> Final output sent to browser
DEBUG - 2022-05-11 19:41:22 --> Total execution time: 0.1985
INFO - 2022-05-11 19:41:25 --> Config Class Initialized
INFO - 2022-05-11 19:41:25 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:41:25 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:41:25 --> Utf8 Class Initialized
INFO - 2022-05-11 19:41:25 --> URI Class Initialized
INFO - 2022-05-11 19:41:25 --> Router Class Initialized
INFO - 2022-05-11 19:41:25 --> Output Class Initialized
INFO - 2022-05-11 19:41:25 --> Security Class Initialized
DEBUG - 2022-05-11 19:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:41:25 --> Input Class Initialized
INFO - 2022-05-11 19:41:25 --> Language Class Initialized
INFO - 2022-05-11 19:41:25 --> Language Class Initialized
INFO - 2022-05-11 19:41:25 --> Config Class Initialized
INFO - 2022-05-11 19:41:25 --> Loader Class Initialized
INFO - 2022-05-11 19:41:25 --> Helper loaded: url_helper
INFO - 2022-05-11 19:41:25 --> Database Driver Class Initialized
INFO - 2022-05-11 19:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:41:25 --> Controller Class Initialized
DEBUG - 2022-05-11 19:41:25 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:41:25 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:25 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:41:25 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:25 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 19:41:25 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 19:41:25 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-11 19:41:25 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 19:41:25 --> Final output sent to browser
DEBUG - 2022-05-11 19:41:25 --> Total execution time: 0.3015
INFO - 2022-05-11 19:41:42 --> Config Class Initialized
INFO - 2022-05-11 19:41:42 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:41:42 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:41:42 --> Utf8 Class Initialized
INFO - 2022-05-11 19:41:42 --> URI Class Initialized
INFO - 2022-05-11 19:41:42 --> Router Class Initialized
INFO - 2022-05-11 19:41:42 --> Output Class Initialized
INFO - 2022-05-11 19:41:42 --> Security Class Initialized
DEBUG - 2022-05-11 19:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:41:42 --> Input Class Initialized
INFO - 2022-05-11 19:41:42 --> Language Class Initialized
INFO - 2022-05-11 19:41:42 --> Language Class Initialized
INFO - 2022-05-11 19:41:42 --> Config Class Initialized
INFO - 2022-05-11 19:41:42 --> Loader Class Initialized
INFO - 2022-05-11 19:41:42 --> Helper loaded: url_helper
INFO - 2022-05-11 19:41:42 --> Database Driver Class Initialized
INFO - 2022-05-11 19:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:41:42 --> Controller Class Initialized
DEBUG - 2022-05-11 19:41:42 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:41:42 --> Model Class Initialized
DEBUG - 2022-05-11 19:41:42 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:41:42 --> Model Class Initialized
INFO - 2022-05-11 19:41:42 --> Final output sent to browser
DEBUG - 2022-05-11 19:41:42 --> Total execution time: 0.0728
INFO - 2022-05-11 19:42:44 --> Config Class Initialized
INFO - 2022-05-11 19:42:44 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:42:44 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:42:44 --> Utf8 Class Initialized
INFO - 2022-05-11 19:42:44 --> URI Class Initialized
INFO - 2022-05-11 19:42:44 --> Router Class Initialized
INFO - 2022-05-11 19:42:44 --> Output Class Initialized
INFO - 2022-05-11 19:42:44 --> Security Class Initialized
DEBUG - 2022-05-11 19:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:42:44 --> Input Class Initialized
INFO - 2022-05-11 19:42:44 --> Language Class Initialized
INFO - 2022-05-11 19:42:44 --> Language Class Initialized
INFO - 2022-05-11 19:42:44 --> Config Class Initialized
INFO - 2022-05-11 19:42:44 --> Loader Class Initialized
INFO - 2022-05-11 19:42:44 --> Helper loaded: url_helper
INFO - 2022-05-11 19:42:44 --> Database Driver Class Initialized
INFO - 2022-05-11 19:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:42:44 --> Controller Class Initialized
DEBUG - 2022-05-11 19:42:44 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:42:44 --> Model Class Initialized
DEBUG - 2022-05-11 19:42:44 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:42:44 --> Model Class Initialized
INFO - 2022-05-11 19:42:45 --> Upload Class Initialized
INFO - 2022-05-11 19:42:45 --> Config Class Initialized
INFO - 2022-05-11 19:42:45 --> Hooks Class Initialized
DEBUG - 2022-05-11 19:42:45 --> UTF-8 Support Enabled
INFO - 2022-05-11 19:42:45 --> Utf8 Class Initialized
INFO - 2022-05-11 19:42:45 --> URI Class Initialized
INFO - 2022-05-11 19:42:45 --> Router Class Initialized
INFO - 2022-05-11 19:42:45 --> Output Class Initialized
INFO - 2022-05-11 19:42:45 --> Security Class Initialized
DEBUG - 2022-05-11 19:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-11 19:42:45 --> Input Class Initialized
INFO - 2022-05-11 19:42:45 --> Language Class Initialized
INFO - 2022-05-11 19:42:45 --> Language Class Initialized
INFO - 2022-05-11 19:42:45 --> Config Class Initialized
INFO - 2022-05-11 19:42:45 --> Loader Class Initialized
INFO - 2022-05-11 19:42:45 --> Helper loaded: url_helper
INFO - 2022-05-11 19:42:45 --> Database Driver Class Initialized
INFO - 2022-05-11 19:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-11 19:42:45 --> Controller Class Initialized
DEBUG - 2022-05-11 19:42:45 --> Admin MX_Controller Initialized
INFO - 2022-05-11 19:42:45 --> Model Class Initialized
DEBUG - 2022-05-11 19:42:45 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-11 19:42:45 --> Model Class Initialized
DEBUG - 2022-05-11 19:42:45 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-11 19:42:45 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-11 19:42:45 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin/views/vehicle_list.php
DEBUG - 2022-05-11 19:42:45 --> File loaded: D:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-11 19:42:45 --> Final output sent to browser
DEBUG - 2022-05-11 19:42:45 --> Total execution time: 0.1075
