<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> No URI present. Default controller set.
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Loader Class Initialized
INFO - 2022-04-20 12:14:38 --> Helper loaded: url_helper
INFO - 2022-04-20 12:14:38 --> Controller Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:14:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:14:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:14:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:14:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:14:38 --> Final output sent to browser
DEBUG - 2022-04-20 12:14:38 --> Total execution time: 0.0212
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:14:38 --> Config Class Initialized
INFO - 2022-04-20 12:14:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:14:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:14:38 --> Utf8 Class Initialized
INFO - 2022-04-20 12:14:38 --> URI Class Initialized
INFO - 2022-04-20 12:14:38 --> Router Class Initialized
INFO - 2022-04-20 12:14:38 --> Output Class Initialized
INFO - 2022-04-20 12:14:38 --> Security Class Initialized
DEBUG - 2022-04-20 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:14:38 --> Input Class Initialized
INFO - 2022-04-20 12:14:38 --> Language Class Initialized
ERROR - 2022-04-20 12:14:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:30 --> No URI present. Default controller set.
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Loader Class Initialized
INFO - 2022-04-20 12:16:30 --> Helper loaded: url_helper
INFO - 2022-04-20 12:16:30 --> Controller Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:16:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:16:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:16:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:16:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:16:30 --> Final output sent to browser
DEBUG - 2022-04-20 12:16:30 --> Total execution time: 0.0193
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Language Class Initialized
ERROR - 2022-04-20 12:16:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Config Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:30 --> Router Class Initialized
INFO - 2022-04-20 12:16:30 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:30 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:30 --> Security Class Initialized
INFO - 2022-04-20 12:16:30 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:30 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
INFO - 2022-04-20 12:16:31 --> Config Class Initialized
INFO - 2022-04-20 12:16:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:16:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:16:31 --> Utf8 Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> URI Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Router Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Output Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
INFO - 2022-04-20 12:16:31 --> Security Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
DEBUG - 2022-04-20 12:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:16:31 --> Input Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
INFO - 2022-04-20 12:16:31 --> Language Class Initialized
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:16:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:17:33 --> Config Class Initialized
INFO - 2022-04-20 12:17:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:17:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:17:33 --> Utf8 Class Initialized
INFO - 2022-04-20 12:17:33 --> URI Class Initialized
DEBUG - 2022-04-20 12:17:33 --> No URI present. Default controller set.
INFO - 2022-04-20 12:17:33 --> Router Class Initialized
INFO - 2022-04-20 12:17:33 --> Output Class Initialized
INFO - 2022-04-20 12:17:33 --> Security Class Initialized
DEBUG - 2022-04-20 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:17:33 --> Input Class Initialized
INFO - 2022-04-20 12:17:33 --> Language Class Initialized
INFO - 2022-04-20 12:17:33 --> Language Class Initialized
INFO - 2022-04-20 12:17:33 --> Config Class Initialized
INFO - 2022-04-20 12:17:33 --> Loader Class Initialized
INFO - 2022-04-20 12:17:33 --> Helper loaded: url_helper
INFO - 2022-04-20 12:17:33 --> Controller Class Initialized
DEBUG - 2022-04-20 12:17:33 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:17:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:17:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:17:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:17:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:17:33 --> Final output sent to browser
DEBUG - 2022-04-20 12:17:33 --> Total execution time: 0.0192
INFO - 2022-04-20 12:17:33 --> Config Class Initialized
INFO - 2022-04-20 12:17:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:17:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:17:33 --> Utf8 Class Initialized
INFO - 2022-04-20 12:17:33 --> URI Class Initialized
INFO - 2022-04-20 12:17:33 --> Router Class Initialized
INFO - 2022-04-20 12:17:33 --> Output Class Initialized
INFO - 2022-04-20 12:17:33 --> Security Class Initialized
DEBUG - 2022-04-20 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:17:33 --> Input Class Initialized
INFO - 2022-04-20 12:17:33 --> Language Class Initialized
ERROR - 2022-04-20 12:17:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:17:33 --> Config Class Initialized
INFO - 2022-04-20 12:17:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:17:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:17:33 --> Utf8 Class Initialized
INFO - 2022-04-20 12:17:33 --> Config Class Initialized
INFO - 2022-04-20 12:17:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:17:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:17:33 --> Utf8 Class Initialized
INFO - 2022-04-20 12:17:33 --> URI Class Initialized
INFO - 2022-04-20 12:17:33 --> Router Class Initialized
INFO - 2022-04-20 12:17:33 --> URI Class Initialized
INFO - 2022-04-20 12:17:33 --> Router Class Initialized
INFO - 2022-04-20 12:17:33 --> Output Class Initialized
INFO - 2022-04-20 12:17:33 --> Security Class Initialized
DEBUG - 2022-04-20 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:17:33 --> Input Class Initialized
INFO - 2022-04-20 12:17:33 --> Language Class Initialized
ERROR - 2022-04-20 12:17:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:17:33 --> Output Class Initialized
INFO - 2022-04-20 12:17:33 --> Security Class Initialized
DEBUG - 2022-04-20 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:17:33 --> Input Class Initialized
INFO - 2022-04-20 12:17:33 --> Language Class Initialized
ERROR - 2022-04-20 12:17:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:18:50 --> Config Class Initialized
INFO - 2022-04-20 12:18:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:18:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:18:50 --> Utf8 Class Initialized
INFO - 2022-04-20 12:18:50 --> URI Class Initialized
DEBUG - 2022-04-20 12:18:50 --> No URI present. Default controller set.
INFO - 2022-04-20 12:18:50 --> Router Class Initialized
INFO - 2022-04-20 12:18:50 --> Output Class Initialized
INFO - 2022-04-20 12:18:50 --> Security Class Initialized
DEBUG - 2022-04-20 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:18:50 --> Input Class Initialized
INFO - 2022-04-20 12:18:50 --> Language Class Initialized
INFO - 2022-04-20 12:18:50 --> Language Class Initialized
INFO - 2022-04-20 12:18:50 --> Config Class Initialized
INFO - 2022-04-20 12:18:50 --> Loader Class Initialized
INFO - 2022-04-20 12:18:50 --> Helper loaded: url_helper
INFO - 2022-04-20 12:18:50 --> Controller Class Initialized
DEBUG - 2022-04-20 12:18:50 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:18:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:18:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:18:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:18:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:18:50 --> Final output sent to browser
DEBUG - 2022-04-20 12:18:50 --> Total execution time: 0.0181
INFO - 2022-04-20 12:18:50 --> Config Class Initialized
INFO - 2022-04-20 12:18:50 --> Config Class Initialized
INFO - 2022-04-20 12:18:50 --> Hooks Class Initialized
INFO - 2022-04-20 12:18:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:18:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:18:50 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:18:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:18:50 --> Utf8 Class Initialized
INFO - 2022-04-20 12:18:50 --> URI Class Initialized
INFO - 2022-04-20 12:18:50 --> URI Class Initialized
INFO - 2022-04-20 12:18:50 --> Router Class Initialized
INFO - 2022-04-20 12:18:50 --> Router Class Initialized
INFO - 2022-04-20 12:18:50 --> Output Class Initialized
INFO - 2022-04-20 12:18:50 --> Output Class Initialized
INFO - 2022-04-20 12:18:50 --> Security Class Initialized
INFO - 2022-04-20 12:18:50 --> Security Class Initialized
DEBUG - 2022-04-20 12:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:18:50 --> Input Class Initialized
INFO - 2022-04-20 12:18:50 --> Input Class Initialized
INFO - 2022-04-20 12:18:50 --> Language Class Initialized
INFO - 2022-04-20 12:18:50 --> Language Class Initialized
ERROR - 2022-04-20 12:18:50 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:18:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:18:50 --> Config Class Initialized
INFO - 2022-04-20 12:18:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:18:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:18:50 --> Utf8 Class Initialized
INFO - 2022-04-20 12:18:50 --> URI Class Initialized
INFO - 2022-04-20 12:18:50 --> Router Class Initialized
INFO - 2022-04-20 12:18:50 --> Output Class Initialized
INFO - 2022-04-20 12:18:50 --> Security Class Initialized
DEBUG - 2022-04-20 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:18:50 --> Input Class Initialized
INFO - 2022-04-20 12:18:50 --> Language Class Initialized
ERROR - 2022-04-20 12:18:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:19:04 --> Config Class Initialized
INFO - 2022-04-20 12:19:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:19:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:19:04 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:04 --> URI Class Initialized
DEBUG - 2022-04-20 12:19:04 --> No URI present. Default controller set.
INFO - 2022-04-20 12:19:04 --> Router Class Initialized
INFO - 2022-04-20 12:19:04 --> Output Class Initialized
INFO - 2022-04-20 12:19:04 --> Security Class Initialized
DEBUG - 2022-04-20 12:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:04 --> Input Class Initialized
INFO - 2022-04-20 12:19:04 --> Language Class Initialized
INFO - 2022-04-20 12:19:04 --> Language Class Initialized
INFO - 2022-04-20 12:19:04 --> Config Class Initialized
INFO - 2022-04-20 12:19:04 --> Loader Class Initialized
INFO - 2022-04-20 12:19:04 --> Helper loaded: url_helper
INFO - 2022-04-20 12:19:04 --> Controller Class Initialized
DEBUG - 2022-04-20 12:19:04 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:19:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:19:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:19:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:19:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:19:04 --> Final output sent to browser
DEBUG - 2022-04-20 12:19:04 --> Total execution time: 0.0181
INFO - 2022-04-20 12:19:04 --> Config Class Initialized
INFO - 2022-04-20 12:19:04 --> Hooks Class Initialized
INFO - 2022-04-20 12:19:04 --> Config Class Initialized
INFO - 2022-04-20 12:19:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:19:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:19:04 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:04 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:04 --> URI Class Initialized
INFO - 2022-04-20 12:19:04 --> URI Class Initialized
INFO - 2022-04-20 12:19:04 --> Router Class Initialized
INFO - 2022-04-20 12:19:04 --> Output Class Initialized
INFO - 2022-04-20 12:19:04 --> Security Class Initialized
DEBUG - 2022-04-20 12:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:04 --> Input Class Initialized
INFO - 2022-04-20 12:19:04 --> Config Class Initialized
INFO - 2022-04-20 12:19:04 --> Language Class Initialized
INFO - 2022-04-20 12:19:04 --> Hooks Class Initialized
ERROR - 2022-04-20 12:19:04 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:19:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:19:04 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:04 --> URI Class Initialized
INFO - 2022-04-20 12:19:04 --> Router Class Initialized
INFO - 2022-04-20 12:19:04 --> Output Class Initialized
INFO - 2022-04-20 12:19:04 --> Router Class Initialized
INFO - 2022-04-20 12:19:04 --> Security Class Initialized
INFO - 2022-04-20 12:19:04 --> Output Class Initialized
DEBUG - 2022-04-20 12:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:04 --> Input Class Initialized
INFO - 2022-04-20 12:19:04 --> Security Class Initialized
INFO - 2022-04-20 12:19:04 --> Language Class Initialized
ERROR - 2022-04-20 12:19:04 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:04 --> Input Class Initialized
INFO - 2022-04-20 12:19:04 --> Language Class Initialized
ERROR - 2022-04-20 12:19:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:19:48 --> Config Class Initialized
INFO - 2022-04-20 12:19:48 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:19:48 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:19:48 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:48 --> URI Class Initialized
DEBUG - 2022-04-20 12:19:48 --> No URI present. Default controller set.
INFO - 2022-04-20 12:19:48 --> Router Class Initialized
INFO - 2022-04-20 12:19:48 --> Output Class Initialized
INFO - 2022-04-20 12:19:48 --> Security Class Initialized
DEBUG - 2022-04-20 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:48 --> Input Class Initialized
INFO - 2022-04-20 12:19:48 --> Language Class Initialized
INFO - 2022-04-20 12:19:48 --> Language Class Initialized
INFO - 2022-04-20 12:19:48 --> Config Class Initialized
INFO - 2022-04-20 12:19:48 --> Loader Class Initialized
INFO - 2022-04-20 12:19:48 --> Helper loaded: url_helper
INFO - 2022-04-20 12:19:48 --> Controller Class Initialized
DEBUG - 2022-04-20 12:19:48 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:19:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:19:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:19:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:19:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:19:48 --> Final output sent to browser
DEBUG - 2022-04-20 12:19:48 --> Total execution time: 0.0193
INFO - 2022-04-20 12:19:48 --> Config Class Initialized
INFO - 2022-04-20 12:19:48 --> Hooks Class Initialized
INFO - 2022-04-20 12:19:48 --> Config Class Initialized
INFO - 2022-04-20 12:19:48 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:19:48 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:19:48 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:48 --> URI Class Initialized
DEBUG - 2022-04-20 12:19:48 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:19:48 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:48 --> Router Class Initialized
INFO - 2022-04-20 12:19:48 --> URI Class Initialized
INFO - 2022-04-20 12:19:48 --> Output Class Initialized
INFO - 2022-04-20 12:19:48 --> Security Class Initialized
INFO - 2022-04-20 12:19:48 --> Router Class Initialized
INFO - 2022-04-20 12:19:48 --> Config Class Initialized
INFO - 2022-04-20 12:19:48 --> Hooks Class Initialized
INFO - 2022-04-20 12:19:48 --> Output Class Initialized
INFO - 2022-04-20 12:19:48 --> Security Class Initialized
DEBUG - 2022-04-20 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:48 --> Utf8 Class Initialized
INFO - 2022-04-20 12:19:48 --> Input Class Initialized
DEBUG - 2022-04-20 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:48 --> Language Class Initialized
INFO - 2022-04-20 12:19:48 --> Input Class Initialized
INFO - 2022-04-20 12:19:48 --> URI Class Initialized
INFO - 2022-04-20 12:19:48 --> Language Class Initialized
ERROR - 2022-04-20 12:19:48 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:19:48 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:19:48 --> Router Class Initialized
INFO - 2022-04-20 12:19:48 --> Output Class Initialized
INFO - 2022-04-20 12:19:48 --> Security Class Initialized
DEBUG - 2022-04-20 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:19:48 --> Input Class Initialized
INFO - 2022-04-20 12:19:48 --> Language Class Initialized
ERROR - 2022-04-20 12:19:48 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:02 --> Config Class Initialized
INFO - 2022-04-20 12:20:02 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:02 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:02 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:02 --> URI Class Initialized
DEBUG - 2022-04-20 12:20:02 --> No URI present. Default controller set.
INFO - 2022-04-20 12:20:02 --> Router Class Initialized
INFO - 2022-04-20 12:20:02 --> Output Class Initialized
INFO - 2022-04-20 12:20:02 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:02 --> Input Class Initialized
INFO - 2022-04-20 12:20:02 --> Language Class Initialized
INFO - 2022-04-20 12:20:02 --> Language Class Initialized
INFO - 2022-04-20 12:20:02 --> Config Class Initialized
INFO - 2022-04-20 12:20:02 --> Loader Class Initialized
INFO - 2022-04-20 12:20:02 --> Helper loaded: url_helper
INFO - 2022-04-20 12:20:02 --> Controller Class Initialized
DEBUG - 2022-04-20 12:20:02 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:20:02 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:20:02 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:20:02 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:20:02 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:20:02 --> Final output sent to browser
DEBUG - 2022-04-20 12:20:02 --> Total execution time: 0.0193
INFO - 2022-04-20 12:20:02 --> Config Class Initialized
INFO - 2022-04-20 12:20:02 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:02 --> Config Class Initialized
INFO - 2022-04-20 12:20:02 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:20:02 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:02 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:02 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:02 --> URI Class Initialized
INFO - 2022-04-20 12:20:02 --> URI Class Initialized
INFO - 2022-04-20 12:20:02 --> Router Class Initialized
INFO - 2022-04-20 12:20:02 --> Router Class Initialized
INFO - 2022-04-20 12:20:02 --> Output Class Initialized
INFO - 2022-04-20 12:20:02 --> Output Class Initialized
INFO - 2022-04-20 12:20:02 --> Security Class Initialized
INFO - 2022-04-20 12:20:02 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:02 --> Input Class Initialized
DEBUG - 2022-04-20 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:02 --> Input Class Initialized
INFO - 2022-04-20 12:20:02 --> Language Class Initialized
INFO - 2022-04-20 12:20:02 --> Language Class Initialized
ERROR - 2022-04-20 12:20:02 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:02 --> Config Class Initialized
ERROR - 2022-04-20 12:20:02 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:02 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:02 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:02 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:02 --> URI Class Initialized
INFO - 2022-04-20 12:20:02 --> Router Class Initialized
INFO - 2022-04-20 12:20:02 --> Output Class Initialized
INFO - 2022-04-20 12:20:02 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:02 --> Input Class Initialized
INFO - 2022-04-20 12:20:02 --> Language Class Initialized
ERROR - 2022-04-20 12:20:02 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:10 --> Config Class Initialized
INFO - 2022-04-20 12:20:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:10 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:10 --> URI Class Initialized
DEBUG - 2022-04-20 12:20:10 --> No URI present. Default controller set.
INFO - 2022-04-20 12:20:10 --> Router Class Initialized
INFO - 2022-04-20 12:20:10 --> Output Class Initialized
INFO - 2022-04-20 12:20:10 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:10 --> Input Class Initialized
INFO - 2022-04-20 12:20:10 --> Language Class Initialized
INFO - 2022-04-20 12:20:10 --> Language Class Initialized
INFO - 2022-04-20 12:20:10 --> Config Class Initialized
INFO - 2022-04-20 12:20:10 --> Loader Class Initialized
INFO - 2022-04-20 12:20:10 --> Helper loaded: url_helper
INFO - 2022-04-20 12:20:10 --> Controller Class Initialized
DEBUG - 2022-04-20 12:20:10 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:20:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:20:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:20:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:20:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:20:10 --> Final output sent to browser
DEBUG - 2022-04-20 12:20:10 --> Total execution time: 0.0198
INFO - 2022-04-20 12:20:10 --> Config Class Initialized
INFO - 2022-04-20 12:20:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:10 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:10 --> Config Class Initialized
INFO - 2022-04-20 12:20:10 --> URI Class Initialized
INFO - 2022-04-20 12:20:10 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:10 --> Config Class Initialized
INFO - 2022-04-20 12:20:10 --> Router Class Initialized
INFO - 2022-04-20 12:20:10 --> Output Class Initialized
DEBUG - 2022-04-20 12:20:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:10 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:10 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:10 --> Input Class Initialized
INFO - 2022-04-20 12:20:10 --> Language Class Initialized
DEBUG - 2022-04-20 12:20:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:10 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:20:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:10 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:10 --> URI Class Initialized
INFO - 2022-04-20 12:20:10 --> URI Class Initialized
INFO - 2022-04-20 12:20:10 --> Router Class Initialized
INFO - 2022-04-20 12:20:10 --> Router Class Initialized
INFO - 2022-04-20 12:20:10 --> Output Class Initialized
INFO - 2022-04-20 12:20:10 --> Output Class Initialized
INFO - 2022-04-20 12:20:10 --> Security Class Initialized
INFO - 2022-04-20 12:20:10 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:10 --> Input Class Initialized
DEBUG - 2022-04-20 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:10 --> Input Class Initialized
INFO - 2022-04-20 12:20:10 --> Language Class Initialized
INFO - 2022-04-20 12:20:10 --> Language Class Initialized
ERROR - 2022-04-20 12:20:10 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:20:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:34 --> Config Class Initialized
INFO - 2022-04-20 12:20:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:34 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:34 --> URI Class Initialized
DEBUG - 2022-04-20 12:20:34 --> No URI present. Default controller set.
INFO - 2022-04-20 12:20:34 --> Router Class Initialized
INFO - 2022-04-20 12:20:34 --> Output Class Initialized
INFO - 2022-04-20 12:20:34 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:34 --> Input Class Initialized
INFO - 2022-04-20 12:20:34 --> Language Class Initialized
INFO - 2022-04-20 12:20:34 --> Language Class Initialized
INFO - 2022-04-20 12:20:34 --> Config Class Initialized
INFO - 2022-04-20 12:20:34 --> Loader Class Initialized
INFO - 2022-04-20 12:20:34 --> Helper loaded: url_helper
INFO - 2022-04-20 12:20:34 --> Controller Class Initialized
DEBUG - 2022-04-20 12:20:34 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:20:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:20:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:20:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:20:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:20:34 --> Final output sent to browser
DEBUG - 2022-04-20 12:20:34 --> Total execution time: 0.0201
INFO - 2022-04-20 12:20:34 --> Config Class Initialized
INFO - 2022-04-20 12:20:34 --> Config Class Initialized
INFO - 2022-04-20 12:20:34 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:34 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:20:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:34 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:34 --> URI Class Initialized
INFO - 2022-04-20 12:20:34 --> URI Class Initialized
INFO - 2022-04-20 12:20:34 --> Router Class Initialized
INFO - 2022-04-20 12:20:34 --> Router Class Initialized
INFO - 2022-04-20 12:20:34 --> Output Class Initialized
INFO - 2022-04-20 12:20:34 --> Output Class Initialized
INFO - 2022-04-20 12:20:34 --> Security Class Initialized
INFO - 2022-04-20 12:20:34 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:34 --> Input Class Initialized
DEBUG - 2022-04-20 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:34 --> Input Class Initialized
INFO - 2022-04-20 12:20:34 --> Language Class Initialized
INFO - 2022-04-20 12:20:34 --> Language Class Initialized
ERROR - 2022-04-20 12:20:34 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:20:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:34 --> Config Class Initialized
INFO - 2022-04-20 12:20:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:34 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:34 --> URI Class Initialized
INFO - 2022-04-20 12:20:34 --> Router Class Initialized
INFO - 2022-04-20 12:20:34 --> Output Class Initialized
INFO - 2022-04-20 12:20:34 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:34 --> Input Class Initialized
INFO - 2022-04-20 12:20:34 --> Language Class Initialized
ERROR - 2022-04-20 12:20:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:39 --> Config Class Initialized
INFO - 2022-04-20 12:20:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:39 --> URI Class Initialized
DEBUG - 2022-04-20 12:20:39 --> No URI present. Default controller set.
INFO - 2022-04-20 12:20:39 --> Router Class Initialized
INFO - 2022-04-20 12:20:39 --> Output Class Initialized
INFO - 2022-04-20 12:20:39 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:39 --> Input Class Initialized
INFO - 2022-04-20 12:20:39 --> Language Class Initialized
INFO - 2022-04-20 12:20:39 --> Language Class Initialized
INFO - 2022-04-20 12:20:39 --> Config Class Initialized
INFO - 2022-04-20 12:20:39 --> Loader Class Initialized
INFO - 2022-04-20 12:20:39 --> Helper loaded: url_helper
INFO - 2022-04-20 12:20:39 --> Controller Class Initialized
DEBUG - 2022-04-20 12:20:39 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:20:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:20:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:20:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:20:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:20:39 --> Final output sent to browser
DEBUG - 2022-04-20 12:20:39 --> Total execution time: 0.0183
INFO - 2022-04-20 12:20:39 --> Config Class Initialized
INFO - 2022-04-20 12:20:39 --> Config Class Initialized
INFO - 2022-04-20 12:20:39 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:20:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:39 --> URI Class Initialized
INFO - 2022-04-20 12:20:39 --> URI Class Initialized
INFO - 2022-04-20 12:20:39 --> Router Class Initialized
INFO - 2022-04-20 12:20:39 --> Router Class Initialized
INFO - 2022-04-20 12:20:39 --> Output Class Initialized
INFO - 2022-04-20 12:20:39 --> Output Class Initialized
INFO - 2022-04-20 12:20:39 --> Security Class Initialized
INFO - 2022-04-20 12:20:39 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:39 --> Input Class Initialized
DEBUG - 2022-04-20 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:39 --> Input Class Initialized
INFO - 2022-04-20 12:20:39 --> Language Class Initialized
INFO - 2022-04-20 12:20:39 --> Language Class Initialized
ERROR - 2022-04-20 12:20:39 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:20:39 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:39 --> Config Class Initialized
INFO - 2022-04-20 12:20:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:39 --> URI Class Initialized
INFO - 2022-04-20 12:20:39 --> Router Class Initialized
INFO - 2022-04-20 12:20:39 --> Output Class Initialized
INFO - 2022-04-20 12:20:39 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:39 --> Input Class Initialized
INFO - 2022-04-20 12:20:39 --> Language Class Initialized
ERROR - 2022-04-20 12:20:39 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:40 --> Config Class Initialized
INFO - 2022-04-20 12:20:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:40 --> URI Class Initialized
DEBUG - 2022-04-20 12:20:40 --> No URI present. Default controller set.
INFO - 2022-04-20 12:20:40 --> Router Class Initialized
INFO - 2022-04-20 12:20:40 --> Output Class Initialized
INFO - 2022-04-20 12:20:40 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:40 --> Input Class Initialized
INFO - 2022-04-20 12:20:40 --> Language Class Initialized
INFO - 2022-04-20 12:20:40 --> Language Class Initialized
INFO - 2022-04-20 12:20:40 --> Config Class Initialized
INFO - 2022-04-20 12:20:40 --> Loader Class Initialized
INFO - 2022-04-20 12:20:40 --> Helper loaded: url_helper
INFO - 2022-04-20 12:20:40 --> Controller Class Initialized
DEBUG - 2022-04-20 12:20:40 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:20:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:20:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:20:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:20:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:20:40 --> Final output sent to browser
DEBUG - 2022-04-20 12:20:40 --> Total execution time: 0.0200
INFO - 2022-04-20 12:20:40 --> Config Class Initialized
INFO - 2022-04-20 12:20:40 --> Config Class Initialized
INFO - 2022-04-20 12:20:40 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:40 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:40 --> Config Class Initialized
INFO - 2022-04-20 12:20:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:40 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:20:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:40 --> URI Class Initialized
INFO - 2022-04-20 12:20:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:40 --> URI Class Initialized
INFO - 2022-04-20 12:20:40 --> Router Class Initialized
INFO - 2022-04-20 12:20:40 --> Output Class Initialized
INFO - 2022-04-20 12:20:40 --> Router Class Initialized
INFO - 2022-04-20 12:20:40 --> Security Class Initialized
INFO - 2022-04-20 12:20:40 --> Output Class Initialized
DEBUG - 2022-04-20 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:40 --> Input Class Initialized
INFO - 2022-04-20 12:20:40 --> Security Class Initialized
INFO - 2022-04-20 12:20:40 --> Language Class Initialized
ERROR - 2022-04-20 12:20:40 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:40 --> Input Class Initialized
INFO - 2022-04-20 12:20:40 --> Language Class Initialized
DEBUG - 2022-04-20 12:20:40 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:20:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:40 --> URI Class Initialized
INFO - 2022-04-20 12:20:40 --> Router Class Initialized
INFO - 2022-04-20 12:20:40 --> Output Class Initialized
INFO - 2022-04-20 12:20:40 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:40 --> Input Class Initialized
INFO - 2022-04-20 12:20:40 --> Language Class Initialized
ERROR - 2022-04-20 12:20:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:49 --> Config Class Initialized
INFO - 2022-04-20 12:20:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:49 --> URI Class Initialized
DEBUG - 2022-04-20 12:20:49 --> No URI present. Default controller set.
INFO - 2022-04-20 12:20:49 --> Router Class Initialized
INFO - 2022-04-20 12:20:49 --> Output Class Initialized
INFO - 2022-04-20 12:20:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:49 --> Input Class Initialized
INFO - 2022-04-20 12:20:49 --> Language Class Initialized
INFO - 2022-04-20 12:20:49 --> Language Class Initialized
INFO - 2022-04-20 12:20:49 --> Config Class Initialized
INFO - 2022-04-20 12:20:49 --> Loader Class Initialized
INFO - 2022-04-20 12:20:49 --> Helper loaded: url_helper
INFO - 2022-04-20 12:20:49 --> Controller Class Initialized
DEBUG - 2022-04-20 12:20:49 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:20:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:20:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:20:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:20:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:20:49 --> Final output sent to browser
DEBUG - 2022-04-20 12:20:49 --> Total execution time: 0.0196
INFO - 2022-04-20 12:20:49 --> Config Class Initialized
INFO - 2022-04-20 12:20:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:49 --> Config Class Initialized
INFO - 2022-04-20 12:20:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:20:49 --> URI Class Initialized
INFO - 2022-04-20 12:20:49 --> Config Class Initialized
INFO - 2022-04-20 12:20:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:20:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:49 --> Router Class Initialized
DEBUG - 2022-04-20 12:20:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:20:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:20:49 --> Output Class Initialized
INFO - 2022-04-20 12:20:49 --> URI Class Initialized
INFO - 2022-04-20 12:20:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:49 --> Input Class Initialized
INFO - 2022-04-20 12:20:49 --> Language Class Initialized
INFO - 2022-04-20 12:20:49 --> Router Class Initialized
INFO - 2022-04-20 12:20:49 --> URI Class Initialized
ERROR - 2022-04-20 12:20:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:49 --> Output Class Initialized
INFO - 2022-04-20 12:20:49 --> Security Class Initialized
INFO - 2022-04-20 12:20:49 --> Router Class Initialized
DEBUG - 2022-04-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:49 --> Input Class Initialized
INFO - 2022-04-20 12:20:49 --> Language Class Initialized
INFO - 2022-04-20 12:20:49 --> Output Class Initialized
ERROR - 2022-04-20 12:20:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:20:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:20:49 --> Input Class Initialized
INFO - 2022-04-20 12:20:49 --> Language Class Initialized
ERROR - 2022-04-20 12:20:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:21:51 --> Config Class Initialized
INFO - 2022-04-20 12:21:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:21:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:21:51 --> Utf8 Class Initialized
INFO - 2022-04-20 12:21:51 --> URI Class Initialized
DEBUG - 2022-04-20 12:21:51 --> No URI present. Default controller set.
INFO - 2022-04-20 12:21:51 --> Router Class Initialized
INFO - 2022-04-20 12:21:51 --> Output Class Initialized
INFO - 2022-04-20 12:21:51 --> Security Class Initialized
DEBUG - 2022-04-20 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:21:51 --> Input Class Initialized
INFO - 2022-04-20 12:21:51 --> Language Class Initialized
INFO - 2022-04-20 12:21:51 --> Language Class Initialized
INFO - 2022-04-20 12:21:51 --> Config Class Initialized
INFO - 2022-04-20 12:21:51 --> Loader Class Initialized
INFO - 2022-04-20 12:21:51 --> Helper loaded: url_helper
INFO - 2022-04-20 12:21:51 --> Controller Class Initialized
DEBUG - 2022-04-20 12:21:51 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:21:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:21:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:21:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:21:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:21:51 --> Final output sent to browser
DEBUG - 2022-04-20 12:21:51 --> Total execution time: 0.0211
INFO - 2022-04-20 12:21:51 --> Config Class Initialized
INFO - 2022-04-20 12:21:51 --> Hooks Class Initialized
INFO - 2022-04-20 12:21:51 --> Config Class Initialized
INFO - 2022-04-20 12:21:51 --> Hooks Class Initialized
INFO - 2022-04-20 12:21:51 --> Config Class Initialized
INFO - 2022-04-20 12:21:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:21:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:21:51 --> Utf8 Class Initialized
INFO - 2022-04-20 12:21:51 --> URI Class Initialized
DEBUG - 2022-04-20 12:21:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:21:51 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:21:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:21:51 --> URI Class Initialized
INFO - 2022-04-20 12:21:51 --> Utf8 Class Initialized
INFO - 2022-04-20 12:21:51 --> Router Class Initialized
INFO - 2022-04-20 12:21:51 --> URI Class Initialized
INFO - 2022-04-20 12:21:51 --> Output Class Initialized
INFO - 2022-04-20 12:21:51 --> Router Class Initialized
INFO - 2022-04-20 12:21:51 --> Security Class Initialized
DEBUG - 2022-04-20 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:21:51 --> Output Class Initialized
INFO - 2022-04-20 12:21:51 --> Input Class Initialized
INFO - 2022-04-20 12:21:51 --> Language Class Initialized
ERROR - 2022-04-20 12:21:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:21:51 --> Security Class Initialized
DEBUG - 2022-04-20 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:21:51 --> Input Class Initialized
INFO - 2022-04-20 12:21:51 --> Router Class Initialized
INFO - 2022-04-20 12:21:51 --> Language Class Initialized
ERROR - 2022-04-20 12:21:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:21:51 --> Output Class Initialized
INFO - 2022-04-20 12:21:51 --> Security Class Initialized
DEBUG - 2022-04-20 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:21:51 --> Input Class Initialized
INFO - 2022-04-20 12:21:51 --> Language Class Initialized
ERROR - 2022-04-20 12:21:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:23:17 --> Config Class Initialized
INFO - 2022-04-20 12:23:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:23:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:17 --> Utf8 Class Initialized
INFO - 2022-04-20 12:23:17 --> URI Class Initialized
DEBUG - 2022-04-20 12:23:17 --> No URI present. Default controller set.
INFO - 2022-04-20 12:23:17 --> Router Class Initialized
INFO - 2022-04-20 12:23:17 --> Output Class Initialized
INFO - 2022-04-20 12:23:17 --> Security Class Initialized
DEBUG - 2022-04-20 12:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:17 --> Input Class Initialized
INFO - 2022-04-20 12:23:17 --> Language Class Initialized
INFO - 2022-04-20 12:23:17 --> Language Class Initialized
INFO - 2022-04-20 12:23:17 --> Config Class Initialized
INFO - 2022-04-20 12:23:18 --> Loader Class Initialized
INFO - 2022-04-20 12:23:18 --> Helper loaded: url_helper
INFO - 2022-04-20 12:23:18 --> Controller Class Initialized
DEBUG - 2022-04-20 12:23:18 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:23:18 --> Final output sent to browser
DEBUG - 2022-04-20 12:23:18 --> Total execution time: 0.0194
INFO - 2022-04-20 12:23:18 --> Config Class Initialized
INFO - 2022-04-20 12:23:18 --> Hooks Class Initialized
INFO - 2022-04-20 12:23:18 --> Config Class Initialized
INFO - 2022-04-20 12:23:18 --> Hooks Class Initialized
INFO - 2022-04-20 12:23:18 --> Config Class Initialized
INFO - 2022-04-20 12:23:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:18 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:18 --> Utf8 Class Initialized
INFO - 2022-04-20 12:23:18 --> URI Class Initialized
DEBUG - 2022-04-20 12:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:18 --> URI Class Initialized
INFO - 2022-04-20 12:23:18 --> Utf8 Class Initialized
INFO - 2022-04-20 12:23:18 --> URI Class Initialized
INFO - 2022-04-20 12:23:18 --> Router Class Initialized
INFO - 2022-04-20 12:23:18 --> Router Class Initialized
INFO - 2022-04-20 12:23:18 --> Output Class Initialized
INFO - 2022-04-20 12:23:18 --> Output Class Initialized
INFO - 2022-04-20 12:23:18 --> Security Class Initialized
INFO - 2022-04-20 12:23:18 --> Security Class Initialized
DEBUG - 2022-04-20 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:18 --> Input Class Initialized
INFO - 2022-04-20 12:23:18 --> Language Class Initialized
DEBUG - 2022-04-20 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:18 --> Input Class Initialized
ERROR - 2022-04-20 12:23:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:23:18 --> Language Class Initialized
ERROR - 2022-04-20 12:23:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:23:18 --> Router Class Initialized
INFO - 2022-04-20 12:23:18 --> Output Class Initialized
INFO - 2022-04-20 12:23:18 --> Security Class Initialized
DEBUG - 2022-04-20 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:18 --> Input Class Initialized
INFO - 2022-04-20 12:23:18 --> Language Class Initialized
ERROR - 2022-04-20 12:23:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:23:55 --> Config Class Initialized
INFO - 2022-04-20 12:23:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:23:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:55 --> Utf8 Class Initialized
INFO - 2022-04-20 12:23:55 --> URI Class Initialized
DEBUG - 2022-04-20 12:23:55 --> No URI present. Default controller set.
INFO - 2022-04-20 12:23:55 --> Router Class Initialized
INFO - 2022-04-20 12:23:55 --> Output Class Initialized
INFO - 2022-04-20 12:23:55 --> Security Class Initialized
DEBUG - 2022-04-20 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:55 --> Input Class Initialized
INFO - 2022-04-20 12:23:55 --> Language Class Initialized
INFO - 2022-04-20 12:23:55 --> Language Class Initialized
INFO - 2022-04-20 12:23:55 --> Config Class Initialized
INFO - 2022-04-20 12:23:55 --> Loader Class Initialized
INFO - 2022-04-20 12:23:55 --> Helper loaded: url_helper
INFO - 2022-04-20 12:23:55 --> Controller Class Initialized
DEBUG - 2022-04-20 12:23:55 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:23:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:23:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:23:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:23:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:23:55 --> Final output sent to browser
DEBUG - 2022-04-20 12:23:55 --> Total execution time: 0.0201
INFO - 2022-04-20 12:23:55 --> Config Class Initialized
INFO - 2022-04-20 12:23:55 --> Hooks Class Initialized
INFO - 2022-04-20 12:23:55 --> Config Class Initialized
INFO - 2022-04-20 12:23:55 --> Hooks Class Initialized
INFO - 2022-04-20 12:23:55 --> Config Class Initialized
INFO - 2022-04-20 12:23:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:23:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:55 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:23:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:55 --> Utf8 Class Initialized
INFO - 2022-04-20 12:23:55 --> URI Class Initialized
DEBUG - 2022-04-20 12:23:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:23:55 --> Utf8 Class Initialized
INFO - 2022-04-20 12:23:55 --> URI Class Initialized
INFO - 2022-04-20 12:23:55 --> Router Class Initialized
INFO - 2022-04-20 12:23:55 --> URI Class Initialized
INFO - 2022-04-20 12:23:55 --> Router Class Initialized
INFO - 2022-04-20 12:23:55 --> Output Class Initialized
INFO - 2022-04-20 12:23:55 --> Output Class Initialized
INFO - 2022-04-20 12:23:55 --> Security Class Initialized
INFO - 2022-04-20 12:23:55 --> Router Class Initialized
INFO - 2022-04-20 12:23:55 --> Security Class Initialized
DEBUG - 2022-04-20 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:55 --> Input Class Initialized
INFO - 2022-04-20 12:23:55 --> Output Class Initialized
INFO - 2022-04-20 12:23:55 --> Language Class Initialized
DEBUG - 2022-04-20 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:56 --> Input Class Initialized
INFO - 2022-04-20 12:23:56 --> Security Class Initialized
ERROR - 2022-04-20 12:23:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:23:56 --> Language Class Initialized
ERROR - 2022-04-20 12:23:56 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:23:56 --> Input Class Initialized
INFO - 2022-04-20 12:23:56 --> Language Class Initialized
ERROR - 2022-04-20 12:23:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:26:15 --> Config Class Initialized
INFO - 2022-04-20 12:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 12:26:15 --> URI Class Initialized
DEBUG - 2022-04-20 12:26:15 --> No URI present. Default controller set.
INFO - 2022-04-20 12:26:15 --> Router Class Initialized
INFO - 2022-04-20 12:26:15 --> Output Class Initialized
INFO - 2022-04-20 12:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:26:15 --> Input Class Initialized
INFO - 2022-04-20 12:26:15 --> Language Class Initialized
INFO - 2022-04-20 12:26:15 --> Language Class Initialized
INFO - 2022-04-20 12:26:15 --> Config Class Initialized
INFO - 2022-04-20 12:26:15 --> Loader Class Initialized
INFO - 2022-04-20 12:26:15 --> Helper loaded: url_helper
INFO - 2022-04-20 12:26:15 --> Controller Class Initialized
DEBUG - 2022-04-20 12:26:15 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:26:15 --> Final output sent to browser
DEBUG - 2022-04-20 12:26:15 --> Total execution time: 0.0191
INFO - 2022-04-20 12:26:15 --> Config Class Initialized
INFO - 2022-04-20 12:26:15 --> Hooks Class Initialized
INFO - 2022-04-20 12:26:15 --> Config Class Initialized
INFO - 2022-04-20 12:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:26:15 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 12:26:15 --> URI Class Initialized
INFO - 2022-04-20 12:26:15 --> URI Class Initialized
INFO - 2022-04-20 12:26:15 --> Router Class Initialized
INFO - 2022-04-20 12:26:15 --> Router Class Initialized
INFO - 2022-04-20 12:26:15 --> Output Class Initialized
INFO - 2022-04-20 12:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:26:15 --> Output Class Initialized
INFO - 2022-04-20 12:26:15 --> Input Class Initialized
INFO - 2022-04-20 12:26:15 --> Language Class Initialized
INFO - 2022-04-20 12:26:15 --> Security Class Initialized
ERROR - 2022-04-20 12:26:15 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:26:15 --> Input Class Initialized
INFO - 2022-04-20 12:26:15 --> Language Class Initialized
ERROR - 2022-04-20 12:26:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:26:15 --> Config Class Initialized
INFO - 2022-04-20 12:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 12:26:15 --> URI Class Initialized
INFO - 2022-04-20 12:26:15 --> Router Class Initialized
INFO - 2022-04-20 12:26:15 --> Output Class Initialized
INFO - 2022-04-20 12:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:26:15 --> Input Class Initialized
INFO - 2022-04-20 12:26:15 --> Language Class Initialized
ERROR - 2022-04-20 12:26:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:28:27 --> Config Class Initialized
INFO - 2022-04-20 12:28:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:28:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:28:27 --> Utf8 Class Initialized
INFO - 2022-04-20 12:28:27 --> URI Class Initialized
DEBUG - 2022-04-20 12:28:27 --> No URI present. Default controller set.
INFO - 2022-04-20 12:28:27 --> Router Class Initialized
INFO - 2022-04-20 12:28:27 --> Output Class Initialized
INFO - 2022-04-20 12:28:27 --> Security Class Initialized
DEBUG - 2022-04-20 12:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:28:27 --> Input Class Initialized
INFO - 2022-04-20 12:28:27 --> Language Class Initialized
INFO - 2022-04-20 12:28:27 --> Language Class Initialized
INFO - 2022-04-20 12:28:27 --> Config Class Initialized
INFO - 2022-04-20 12:28:27 --> Loader Class Initialized
INFO - 2022-04-20 12:28:27 --> Helper loaded: url_helper
INFO - 2022-04-20 12:28:27 --> Controller Class Initialized
DEBUG - 2022-04-20 12:28:27 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:28:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:28:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:28:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:28:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:28:27 --> Final output sent to browser
DEBUG - 2022-04-20 12:28:27 --> Total execution time: 0.0204
INFO - 2022-04-20 12:28:27 --> Config Class Initialized
INFO - 2022-04-20 12:28:27 --> Hooks Class Initialized
INFO - 2022-04-20 12:28:27 --> Config Class Initialized
INFO - 2022-04-20 12:28:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:28:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:28:27 --> Utf8 Class Initialized
INFO - 2022-04-20 12:28:27 --> Config Class Initialized
INFO - 2022-04-20 12:28:27 --> Hooks Class Initialized
INFO - 2022-04-20 12:28:27 --> URI Class Initialized
INFO - 2022-04-20 12:28:28 --> Router Class Initialized
DEBUG - 2022-04-20 12:28:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:28:28 --> Utf8 Class Initialized
INFO - 2022-04-20 12:28:28 --> Output Class Initialized
INFO - 2022-04-20 12:28:28 --> URI Class Initialized
INFO - 2022-04-20 12:28:28 --> Security Class Initialized
DEBUG - 2022-04-20 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:28:28 --> Input Class Initialized
INFO - 2022-04-20 12:28:28 --> Language Class Initialized
INFO - 2022-04-20 12:28:28 --> Router Class Initialized
ERROR - 2022-04-20 12:28:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:28:28 --> Output Class Initialized
INFO - 2022-04-20 12:28:28 --> Security Class Initialized
DEBUG - 2022-04-20 12:28:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:28:28 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:28:28 --> Input Class Initialized
INFO - 2022-04-20 12:28:28 --> Language Class Initialized
INFO - 2022-04-20 12:28:28 --> URI Class Initialized
ERROR - 2022-04-20 12:28:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:28:28 --> Router Class Initialized
INFO - 2022-04-20 12:28:28 --> Output Class Initialized
INFO - 2022-04-20 12:28:28 --> Security Class Initialized
DEBUG - 2022-04-20 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:28:28 --> Input Class Initialized
INFO - 2022-04-20 12:28:28 --> Language Class Initialized
ERROR - 2022-04-20 12:28:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:29:26 --> Config Class Initialized
INFO - 2022-04-20 12:29:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:29:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:26 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:26 --> URI Class Initialized
DEBUG - 2022-04-20 12:29:26 --> No URI present. Default controller set.
INFO - 2022-04-20 12:29:26 --> Router Class Initialized
INFO - 2022-04-20 12:29:26 --> Output Class Initialized
INFO - 2022-04-20 12:29:26 --> Security Class Initialized
DEBUG - 2022-04-20 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:26 --> Input Class Initialized
INFO - 2022-04-20 12:29:26 --> Language Class Initialized
INFO - 2022-04-20 12:29:26 --> Language Class Initialized
INFO - 2022-04-20 12:29:26 --> Config Class Initialized
INFO - 2022-04-20 12:29:26 --> Loader Class Initialized
INFO - 2022-04-20 12:29:26 --> Helper loaded: url_helper
INFO - 2022-04-20 12:29:26 --> Controller Class Initialized
DEBUG - 2022-04-20 12:29:26 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:29:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:29:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:29:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:29:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:29:26 --> Final output sent to browser
DEBUG - 2022-04-20 12:29:26 --> Total execution time: 0.0189
INFO - 2022-04-20 12:29:26 --> Config Class Initialized
INFO - 2022-04-20 12:29:26 --> Hooks Class Initialized
INFO - 2022-04-20 12:29:26 --> Config Class Initialized
INFO - 2022-04-20 12:29:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:29:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:26 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:29:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:26 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:26 --> URI Class Initialized
INFO - 2022-04-20 12:29:26 --> URI Class Initialized
INFO - 2022-04-20 12:29:26 --> Router Class Initialized
INFO - 2022-04-20 12:29:26 --> Router Class Initialized
INFO - 2022-04-20 12:29:26 --> Output Class Initialized
INFO - 2022-04-20 12:29:26 --> Security Class Initialized
INFO - 2022-04-20 12:29:26 --> Output Class Initialized
DEBUG - 2022-04-20 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:26 --> Input Class Initialized
INFO - 2022-04-20 12:29:26 --> Security Class Initialized
INFO - 2022-04-20 12:29:26 --> Language Class Initialized
DEBUG - 2022-04-20 12:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:29:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:29:26 --> Input Class Initialized
INFO - 2022-04-20 12:29:26 --> Language Class Initialized
ERROR - 2022-04-20 12:29:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:29:26 --> Config Class Initialized
INFO - 2022-04-20 12:29:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:29:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:26 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:26 --> URI Class Initialized
INFO - 2022-04-20 12:29:26 --> Router Class Initialized
INFO - 2022-04-20 12:29:26 --> Output Class Initialized
INFO - 2022-04-20 12:29:26 --> Security Class Initialized
DEBUG - 2022-04-20 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:26 --> Input Class Initialized
INFO - 2022-04-20 12:29:26 --> Language Class Initialized
ERROR - 2022-04-20 12:29:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:29:45 --> Config Class Initialized
INFO - 2022-04-20 12:29:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:29:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:45 --> URI Class Initialized
DEBUG - 2022-04-20 12:29:45 --> No URI present. Default controller set.
INFO - 2022-04-20 12:29:45 --> Router Class Initialized
INFO - 2022-04-20 12:29:45 --> Output Class Initialized
INFO - 2022-04-20 12:29:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:45 --> Input Class Initialized
INFO - 2022-04-20 12:29:45 --> Language Class Initialized
INFO - 2022-04-20 12:29:45 --> Language Class Initialized
INFO - 2022-04-20 12:29:45 --> Config Class Initialized
INFO - 2022-04-20 12:29:45 --> Loader Class Initialized
INFO - 2022-04-20 12:29:45 --> Helper loaded: url_helper
INFO - 2022-04-20 12:29:45 --> Controller Class Initialized
DEBUG - 2022-04-20 12:29:45 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:29:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:29:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:29:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:29:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:29:45 --> Final output sent to browser
DEBUG - 2022-04-20 12:29:45 --> Total execution time: 0.0191
INFO - 2022-04-20 12:29:45 --> Config Class Initialized
INFO - 2022-04-20 12:29:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:29:45 --> Config Class Initialized
INFO - 2022-04-20 12:29:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:29:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:45 --> URI Class Initialized
INFO - 2022-04-20 12:29:45 --> URI Class Initialized
INFO - 2022-04-20 12:29:45 --> Config Class Initialized
INFO - 2022-04-20 12:29:45 --> Router Class Initialized
INFO - 2022-04-20 12:29:45 --> Router Class Initialized
INFO - 2022-04-20 12:29:45 --> Output Class Initialized
INFO - 2022-04-20 12:29:45 --> Output Class Initialized
INFO - 2022-04-20 12:29:45 --> Security Class Initialized
INFO - 2022-04-20 12:29:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:45 --> Input Class Initialized
DEBUG - 2022-04-20 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:45 --> Language Class Initialized
INFO - 2022-04-20 12:29:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:29:45 --> Input Class Initialized
INFO - 2022-04-20 12:29:45 --> Language Class Initialized
ERROR - 2022-04-20 12:29:45 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:29:45 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:29:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:29:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:29:45 --> URI Class Initialized
INFO - 2022-04-20 12:29:45 --> Router Class Initialized
INFO - 2022-04-20 12:29:45 --> Output Class Initialized
INFO - 2022-04-20 12:29:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:29:45 --> Input Class Initialized
INFO - 2022-04-20 12:29:45 --> Language Class Initialized
ERROR - 2022-04-20 12:29:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:30:51 --> Config Class Initialized
INFO - 2022-04-20 12:30:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:30:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:30:51 --> Utf8 Class Initialized
INFO - 2022-04-20 12:30:51 --> URI Class Initialized
INFO - 2022-04-20 12:30:51 --> Router Class Initialized
INFO - 2022-04-20 12:30:51 --> Output Class Initialized
INFO - 2022-04-20 12:30:51 --> Security Class Initialized
DEBUG - 2022-04-20 12:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:30:51 --> Input Class Initialized
INFO - 2022-04-20 12:30:51 --> Language Class Initialized
ERROR - 2022-04-20 12:30:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:47:21 --> Config Class Initialized
INFO - 2022-04-20 12:47:21 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:21 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:21 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:21 --> URI Class Initialized
DEBUG - 2022-04-20 12:47:21 --> No URI present. Default controller set.
INFO - 2022-04-20 12:47:21 --> Router Class Initialized
INFO - 2022-04-20 12:47:21 --> Output Class Initialized
INFO - 2022-04-20 12:47:21 --> Security Class Initialized
DEBUG - 2022-04-20 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:21 --> Input Class Initialized
INFO - 2022-04-20 12:47:21 --> Language Class Initialized
INFO - 2022-04-20 12:47:21 --> Language Class Initialized
INFO - 2022-04-20 12:47:21 --> Config Class Initialized
INFO - 2022-04-20 12:47:21 --> Loader Class Initialized
INFO - 2022-04-20 12:47:21 --> Helper loaded: url_helper
INFO - 2022-04-20 12:47:21 --> Controller Class Initialized
DEBUG - 2022-04-20 12:47:21 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:47:21 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:47:21 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:47:21 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:47:21 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:47:21 --> Final output sent to browser
DEBUG - 2022-04-20 12:47:21 --> Total execution time: 0.0342
INFO - 2022-04-20 12:47:21 --> Config Class Initialized
INFO - 2022-04-20 12:47:21 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:21 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:21 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:21 --> Config Class Initialized
INFO - 2022-04-20 12:47:21 --> Hooks Class Initialized
INFO - 2022-04-20 12:47:21 --> URI Class Initialized
INFO - 2022-04-20 12:47:21 --> Config Class Initialized
INFO - 2022-04-20 12:47:21 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:21 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:21 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:21 --> Router Class Initialized
INFO - 2022-04-20 12:47:21 --> URI Class Initialized
INFO - 2022-04-20 12:47:21 --> Output Class Initialized
DEBUG - 2022-04-20 12:47:21 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:21 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:21 --> Security Class Initialized
INFO - 2022-04-20 12:47:21 --> URI Class Initialized
INFO - 2022-04-20 12:47:21 --> Router Class Initialized
DEBUG - 2022-04-20 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:21 --> Input Class Initialized
INFO - 2022-04-20 12:47:21 --> Language Class Initialized
INFO - 2022-04-20 12:47:21 --> Output Class Initialized
INFO - 2022-04-20 12:47:21 --> Router Class Initialized
ERROR - 2022-04-20 12:47:21 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:47:21 --> Output Class Initialized
INFO - 2022-04-20 12:47:21 --> Security Class Initialized
INFO - 2022-04-20 12:47:21 --> Security Class Initialized
DEBUG - 2022-04-20 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:21 --> Input Class Initialized
DEBUG - 2022-04-20 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:21 --> Input Class Initialized
INFO - 2022-04-20 12:47:21 --> Language Class Initialized
INFO - 2022-04-20 12:47:21 --> Language Class Initialized
ERROR - 2022-04-20 12:47:21 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:47:21 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:47:28 --> Config Class Initialized
INFO - 2022-04-20 12:47:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:28 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:28 --> URI Class Initialized
INFO - 2022-04-20 12:47:28 --> Router Class Initialized
INFO - 2022-04-20 12:47:28 --> Output Class Initialized
INFO - 2022-04-20 12:47:28 --> Security Class Initialized
DEBUG - 2022-04-20 12:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:28 --> Input Class Initialized
INFO - 2022-04-20 12:47:28 --> Language Class Initialized
INFO - 2022-04-20 12:47:28 --> Language Class Initialized
INFO - 2022-04-20 12:47:28 --> Config Class Initialized
INFO - 2022-04-20 12:47:28 --> Loader Class Initialized
INFO - 2022-04-20 12:47:28 --> Helper loaded: url_helper
INFO - 2022-04-20 12:47:28 --> Controller Class Initialized
ERROR - 2022-04-20 12:47:28 --> 404 Page Not Found: ../modules/contact/controllers/Contact/index
INFO - 2022-04-20 12:47:53 --> Config Class Initialized
INFO - 2022-04-20 12:47:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:53 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:53 --> URI Class Initialized
DEBUG - 2022-04-20 12:47:53 --> No URI present. Default controller set.
INFO - 2022-04-20 12:47:53 --> Router Class Initialized
INFO - 2022-04-20 12:47:53 --> Output Class Initialized
INFO - 2022-04-20 12:47:53 --> Security Class Initialized
DEBUG - 2022-04-20 12:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:53 --> Input Class Initialized
INFO - 2022-04-20 12:47:53 --> Language Class Initialized
INFO - 2022-04-20 12:47:53 --> Language Class Initialized
INFO - 2022-04-20 12:47:53 --> Config Class Initialized
INFO - 2022-04-20 12:47:53 --> Loader Class Initialized
INFO - 2022-04-20 12:47:53 --> Helper loaded: url_helper
INFO - 2022-04-20 12:47:53 --> Controller Class Initialized
DEBUG - 2022-04-20 12:47:53 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:47:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:47:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:47:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:47:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:47:53 --> Final output sent to browser
DEBUG - 2022-04-20 12:47:53 --> Total execution time: 0.0190
INFO - 2022-04-20 12:47:53 --> Config Class Initialized
INFO - 2022-04-20 12:47:53 --> Config Class Initialized
INFO - 2022-04-20 12:47:53 --> Hooks Class Initialized
INFO - 2022-04-20 12:47:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:47:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:53 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:53 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:53 --> URI Class Initialized
INFO - 2022-04-20 12:47:53 --> URI Class Initialized
INFO - 2022-04-20 12:47:53 --> Config Class Initialized
INFO - 2022-04-20 12:47:53 --> Router Class Initialized
INFO - 2022-04-20 12:47:53 --> Router Class Initialized
INFO - 2022-04-20 12:47:53 --> Output Class Initialized
INFO - 2022-04-20 12:47:53 --> Output Class Initialized
INFO - 2022-04-20 12:47:53 --> Security Class Initialized
INFO - 2022-04-20 12:47:53 --> Security Class Initialized
DEBUG - 2022-04-20 12:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:53 --> Input Class Initialized
INFO - 2022-04-20 12:47:53 --> Input Class Initialized
INFO - 2022-04-20 12:47:53 --> Language Class Initialized
INFO - 2022-04-20 12:47:53 --> Language Class Initialized
ERROR - 2022-04-20 12:47:53 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:47:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:47:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:47:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:47:53 --> Utf8 Class Initialized
INFO - 2022-04-20 12:47:53 --> URI Class Initialized
INFO - 2022-04-20 12:47:53 --> Router Class Initialized
INFO - 2022-04-20 12:47:53 --> Output Class Initialized
INFO - 2022-04-20 12:47:53 --> Security Class Initialized
DEBUG - 2022-04-20 12:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:47:53 --> Input Class Initialized
INFO - 2022-04-20 12:47:53 --> Language Class Initialized
ERROR - 2022-04-20 12:47:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:48:14 --> Config Class Initialized
INFO - 2022-04-20 12:48:14 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:48:14 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:14 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:14 --> URI Class Initialized
INFO - 2022-04-20 12:48:14 --> Router Class Initialized
INFO - 2022-04-20 12:48:14 --> Output Class Initialized
INFO - 2022-04-20 12:48:14 --> Security Class Initialized
DEBUG - 2022-04-20 12:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:14 --> Input Class Initialized
INFO - 2022-04-20 12:48:14 --> Language Class Initialized
INFO - 2022-04-20 12:48:14 --> Language Class Initialized
INFO - 2022-04-20 12:48:14 --> Config Class Initialized
INFO - 2022-04-20 12:48:14 --> Loader Class Initialized
INFO - 2022-04-20 12:48:14 --> Helper loaded: url_helper
INFO - 2022-04-20 12:48:14 --> Controller Class Initialized
ERROR - 2022-04-20 12:48:14 --> 404 Page Not Found: ../modules/contact/controllers/Contact/index
INFO - 2022-04-20 12:48:40 --> Config Class Initialized
INFO - 2022-04-20 12:48:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:48:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:40 --> URI Class Initialized
DEBUG - 2022-04-20 12:48:40 --> No URI present. Default controller set.
INFO - 2022-04-20 12:48:40 --> Router Class Initialized
INFO - 2022-04-20 12:48:40 --> Output Class Initialized
INFO - 2022-04-20 12:48:40 --> Security Class Initialized
DEBUG - 2022-04-20 12:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:40 --> Input Class Initialized
INFO - 2022-04-20 12:48:40 --> Language Class Initialized
INFO - 2022-04-20 12:48:40 --> Language Class Initialized
INFO - 2022-04-20 12:48:40 --> Config Class Initialized
INFO - 2022-04-20 12:48:40 --> Loader Class Initialized
INFO - 2022-04-20 12:48:40 --> Helper loaded: url_helper
INFO - 2022-04-20 12:48:40 --> Controller Class Initialized
DEBUG - 2022-04-20 12:48:40 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 12:48:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:48:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:48:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 12:48:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:48:40 --> Final output sent to browser
DEBUG - 2022-04-20 12:48:40 --> Total execution time: 0.0198
INFO - 2022-04-20 12:48:40 --> Config Class Initialized
INFO - 2022-04-20 12:48:40 --> Hooks Class Initialized
INFO - 2022-04-20 12:48:40 --> Config Class Initialized
INFO - 2022-04-20 12:48:40 --> Hooks Class Initialized
INFO - 2022-04-20 12:48:40 --> Config Class Initialized
INFO - 2022-04-20 12:48:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:48:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:40 --> URI Class Initialized
INFO - 2022-04-20 12:48:40 --> URI Class Initialized
DEBUG - 2022-04-20 12:48:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:40 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:40 --> Router Class Initialized
INFO - 2022-04-20 12:48:40 --> URI Class Initialized
INFO - 2022-04-20 12:48:40 --> Router Class Initialized
INFO - 2022-04-20 12:48:40 --> Output Class Initialized
INFO - 2022-04-20 12:48:40 --> Output Class Initialized
INFO - 2022-04-20 12:48:40 --> Security Class Initialized
INFO - 2022-04-20 12:48:40 --> Security Class Initialized
INFO - 2022-04-20 12:48:40 --> Router Class Initialized
DEBUG - 2022-04-20 12:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:40 --> Input Class Initialized
DEBUG - 2022-04-20 12:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:40 --> Input Class Initialized
INFO - 2022-04-20 12:48:40 --> Language Class Initialized
INFO - 2022-04-20 12:48:40 --> Output Class Initialized
INFO - 2022-04-20 12:48:40 --> Language Class Initialized
ERROR - 2022-04-20 12:48:40 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:48:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:48:40 --> Security Class Initialized
DEBUG - 2022-04-20 12:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:40 --> Input Class Initialized
INFO - 2022-04-20 12:48:40 --> Language Class Initialized
ERROR - 2022-04-20 12:48:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:48:41 --> Config Class Initialized
INFO - 2022-04-20 12:48:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:48:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:41 --> URI Class Initialized
INFO - 2022-04-20 12:48:41 --> Router Class Initialized
INFO - 2022-04-20 12:48:41 --> Output Class Initialized
INFO - 2022-04-20 12:48:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:41 --> Input Class Initialized
INFO - 2022-04-20 12:48:41 --> Language Class Initialized
INFO - 2022-04-20 12:48:41 --> Language Class Initialized
INFO - 2022-04-20 12:48:41 --> Config Class Initialized
INFO - 2022-04-20 12:48:41 --> Loader Class Initialized
INFO - 2022-04-20 12:48:41 --> Helper loaded: url_helper
INFO - 2022-04-20 12:48:41 --> Controller Class Initialized
DEBUG - 2022-04-20 12:48:41 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 12:48:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:48:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:48:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 12:48:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:48:41 --> Final output sent to browser
DEBUG - 2022-04-20 12:48:41 --> Total execution time: 0.0191
INFO - 2022-04-20 12:48:41 --> Config Class Initialized
INFO - 2022-04-20 12:48:41 --> Hooks Class Initialized
INFO - 2022-04-20 12:48:41 --> Config Class Initialized
INFO - 2022-04-20 12:48:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:48:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:41 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:48:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:41 --> URI Class Initialized
INFO - 2022-04-20 12:48:41 --> URI Class Initialized
INFO - 2022-04-20 12:48:41 --> Router Class Initialized
INFO - 2022-04-20 12:48:41 --> Router Class Initialized
INFO - 2022-04-20 12:48:41 --> Output Class Initialized
INFO - 2022-04-20 12:48:41 --> Output Class Initialized
INFO - 2022-04-20 12:48:41 --> Security Class Initialized
INFO - 2022-04-20 12:48:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:41 --> Input Class Initialized
DEBUG - 2022-04-20 12:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:41 --> Input Class Initialized
INFO - 2022-04-20 12:48:41 --> Language Class Initialized
INFO - 2022-04-20 12:48:41 --> Language Class Initialized
ERROR - 2022-04-20 12:48:41 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:48:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:48:41 --> Config Class Initialized
INFO - 2022-04-20 12:48:41 --> Hooks Class Initialized
INFO - 2022-04-20 12:48:41 --> Config Class Initialized
INFO - 2022-04-20 12:48:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:48:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:48:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:48:41 --> URI Class Initialized
INFO - 2022-04-20 12:48:41 --> URI Class Initialized
INFO - 2022-04-20 12:48:41 --> Router Class Initialized
INFO - 2022-04-20 12:48:41 --> Router Class Initialized
INFO - 2022-04-20 12:48:41 --> Output Class Initialized
INFO - 2022-04-20 12:48:41 --> Output Class Initialized
INFO - 2022-04-20 12:48:41 --> Security Class Initialized
INFO - 2022-04-20 12:48:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:48:41 --> Input Class Initialized
INFO - 2022-04-20 12:48:41 --> Input Class Initialized
INFO - 2022-04-20 12:48:41 --> Language Class Initialized
INFO - 2022-04-20 12:48:41 --> Language Class Initialized
ERROR - 2022-04-20 12:48:41 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:48:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:52:39 --> Config Class Initialized
INFO - 2022-04-20 12:52:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:52:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:52:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:52:39 --> URI Class Initialized
INFO - 2022-04-20 12:52:39 --> Router Class Initialized
INFO - 2022-04-20 12:52:39 --> Output Class Initialized
INFO - 2022-04-20 12:52:39 --> Security Class Initialized
DEBUG - 2022-04-20 12:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:52:39 --> Input Class Initialized
INFO - 2022-04-20 12:52:39 --> Language Class Initialized
INFO - 2022-04-20 12:52:39 --> Language Class Initialized
INFO - 2022-04-20 12:52:39 --> Config Class Initialized
INFO - 2022-04-20 12:52:39 --> Loader Class Initialized
INFO - 2022-04-20 12:52:39 --> Helper loaded: url_helper
INFO - 2022-04-20 12:52:39 --> Controller Class Initialized
DEBUG - 2022-04-20 12:52:39 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 12:52:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:52:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:52:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 12:52:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:52:39 --> Final output sent to browser
DEBUG - 2022-04-20 12:52:39 --> Total execution time: 0.0195
INFO - 2022-04-20 12:52:39 --> Config Class Initialized
INFO - 2022-04-20 12:52:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:52:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:52:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:52:39 --> URI Class Initialized
INFO - 2022-04-20 12:52:39 --> Router Class Initialized
INFO - 2022-04-20 12:52:39 --> Config Class Initialized
INFO - 2022-04-20 12:52:39 --> Config Class Initialized
INFO - 2022-04-20 12:52:39 --> Hooks Class Initialized
INFO - 2022-04-20 12:52:39 --> Hooks Class Initialized
INFO - 2022-04-20 12:52:39 --> Config Class Initialized
INFO - 2022-04-20 12:52:39 --> Hooks Class Initialized
INFO - 2022-04-20 12:52:39 --> Output Class Initialized
DEBUG - 2022-04-20 12:52:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:52:39 --> Security Class Initialized
DEBUG - 2022-04-20 12:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:52:39 --> Input Class Initialized
INFO - 2022-04-20 12:52:39 --> Language Class Initialized
DEBUG - 2022-04-20 12:52:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:52:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:52:39 --> URI Class Initialized
INFO - 2022-04-20 12:52:39 --> Router Class Initialized
INFO - 2022-04-20 12:52:39 --> Output Class Initialized
INFO - 2022-04-20 12:52:39 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:52:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:52:39 --> Utf8 Class Initialized
INFO - 2022-04-20 12:52:39 --> Security Class Initialized
INFO - 2022-04-20 12:52:39 --> URI Class Initialized
INFO - 2022-04-20 12:52:39 --> URI Class Initialized
DEBUG - 2022-04-20 12:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:52:39 --> Input Class Initialized
INFO - 2022-04-20 12:52:39 --> Language Class Initialized
ERROR - 2022-04-20 12:52:39 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:52:39 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:52:39 --> Router Class Initialized
INFO - 2022-04-20 12:52:39 --> Router Class Initialized
INFO - 2022-04-20 12:52:39 --> Output Class Initialized
INFO - 2022-04-20 12:52:39 --> Output Class Initialized
INFO - 2022-04-20 12:52:39 --> Security Class Initialized
INFO - 2022-04-20 12:52:39 --> Security Class Initialized
DEBUG - 2022-04-20 12:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:52:39 --> Input Class Initialized
INFO - 2022-04-20 12:52:39 --> Input Class Initialized
INFO - 2022-04-20 12:52:39 --> Language Class Initialized
INFO - 2022-04-20 12:52:39 --> Language Class Initialized
ERROR - 2022-04-20 12:52:39 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:52:39 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:09 --> Config Class Initialized
INFO - 2022-04-20 12:54:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:09 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:09 --> URI Class Initialized
INFO - 2022-04-20 12:54:09 --> Router Class Initialized
INFO - 2022-04-20 12:54:09 --> Output Class Initialized
INFO - 2022-04-20 12:54:09 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:09 --> Input Class Initialized
INFO - 2022-04-20 12:54:09 --> Language Class Initialized
INFO - 2022-04-20 12:54:09 --> Language Class Initialized
INFO - 2022-04-20 12:54:09 --> Config Class Initialized
INFO - 2022-04-20 12:54:09 --> Loader Class Initialized
INFO - 2022-04-20 12:54:09 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:09 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:09 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 12:54:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:54:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 12:54:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:54:09 --> Final output sent to browser
DEBUG - 2022-04-20 12:54:09 --> Total execution time: 0.0187
INFO - 2022-04-20 12:54:09 --> Config Class Initialized
INFO - 2022-04-20 12:54:09 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:09 --> Config Class Initialized
INFO - 2022-04-20 12:54:09 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:09 --> Config Class Initialized
INFO - 2022-04-20 12:54:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:09 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:09 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:09 --> URI Class Initialized
INFO - 2022-04-20 12:54:09 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:09 --> URI Class Initialized
INFO - 2022-04-20 12:54:09 --> URI Class Initialized
INFO - 2022-04-20 12:54:09 --> Router Class Initialized
INFO - 2022-04-20 12:54:09 --> Router Class Initialized
INFO - 2022-04-20 12:54:09 --> Router Class Initialized
INFO - 2022-04-20 12:54:09 --> Output Class Initialized
INFO - 2022-04-20 12:54:09 --> Output Class Initialized
INFO - 2022-04-20 12:54:09 --> Security Class Initialized
INFO - 2022-04-20 12:54:09 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:09 --> Input Class Initialized
INFO - 2022-04-20 12:54:09 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:09 --> Input Class Initialized
ERROR - 2022-04-20 12:54:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:09 --> Language Class Initialized
ERROR - 2022-04-20 12:54:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:09 --> Output Class Initialized
INFO - 2022-04-20 12:54:09 --> Config Class Initialized
INFO - 2022-04-20 12:54:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:09 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:09 --> URI Class Initialized
INFO - 2022-04-20 12:54:09 --> Security Class Initialized
INFO - 2022-04-20 12:54:09 --> Router Class Initialized
INFO - 2022-04-20 12:54:09 --> Output Class Initialized
INFO - 2022-04-20 12:54:09 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:09 --> Input Class Initialized
INFO - 2022-04-20 12:54:09 --> Input Class Initialized
INFO - 2022-04-20 12:54:09 --> Language Class Initialized
INFO - 2022-04-20 12:54:09 --> Language Class Initialized
ERROR - 2022-04-20 12:54:09 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Loader Class Initialized
INFO - 2022-04-20 12:54:11 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:11 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:11 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:54:11 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:11 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:54:11 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:54:11 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:54:11 --> Final output sent to browser
DEBUG - 2022-04-20 12:54:11 --> Total execution time: 0.0189
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Config Class Initialized
INFO - 2022-04-20 12:54:11 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:11 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:11 --> URI Class Initialized
INFO - 2022-04-20 12:54:11 --> Router Class Initialized
INFO - 2022-04-20 12:54:11 --> Output Class Initialized
INFO - 2022-04-20 12:54:11 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:11 --> Input Class Initialized
INFO - 2022-04-20 12:54:11 --> Language Class Initialized
ERROR - 2022-04-20 12:54:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Loader Class Initialized
INFO - 2022-04-20 12:54:25 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:25 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:25 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:54:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:54:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:54:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:54:25 --> Final output sent to browser
DEBUG - 2022-04-20 12:54:25 --> Total execution time: 0.0205
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Config Class Initialized
INFO - 2022-04-20 12:54:25 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
INFO - 2022-04-20 12:54:25 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:25 --> URI Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
INFO - 2022-04-20 12:54:25 --> Output Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:25 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:25 --> Input Class Initialized
INFO - 2022-04-20 12:54:25 --> Language Class Initialized
ERROR - 2022-04-20 12:54:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:26 --> Config Class Initialized
INFO - 2022-04-20 12:54:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:26 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:26 --> URI Class Initialized
INFO - 2022-04-20 12:54:26 --> Router Class Initialized
INFO - 2022-04-20 12:54:26 --> Output Class Initialized
INFO - 2022-04-20 12:54:26 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:26 --> Input Class Initialized
INFO - 2022-04-20 12:54:26 --> Language Class Initialized
INFO - 2022-04-20 12:54:26 --> Language Class Initialized
INFO - 2022-04-20 12:54:26 --> Config Class Initialized
INFO - 2022-04-20 12:54:26 --> Loader Class Initialized
INFO - 2022-04-20 12:54:26 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:26 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:26 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 12:54:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Loader Class Initialized
INFO - 2022-04-20 12:54:44 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:44 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:44 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:54:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:54:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:54:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:54:44 --> Final output sent to browser
DEBUG - 2022-04-20 12:54:44 --> Total execution time: 0.0191
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Config Class Initialized
INFO - 2022-04-20 12:54:44 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:44 --> URI Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
INFO - 2022-04-20 12:54:44 --> Router Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:44 --> Output Class Initialized
INFO - 2022-04-20 12:54:44 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:44 --> Input Class Initialized
INFO - 2022-04-20 12:54:44 --> Language Class Initialized
ERROR - 2022-04-20 12:54:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Loader Class Initialized
INFO - 2022-04-20 12:54:45 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:45 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 12:54:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:54:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 12:54:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:54:45 --> Final output sent to browser
DEBUG - 2022-04-20 12:54:45 --> Total execution time: 0.0198
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
INFO - 2022-04-20 12:54:45 --> Router Class Initialized
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Output Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:45 --> Input Class Initialized
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Language Class Initialized
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:45 --> Config Class Initialized
INFO - 2022-04-20 12:54:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:54:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:45 --> URI Class Initialized
INFO - 2022-04-20 12:54:46 --> Router Class Initialized
INFO - 2022-04-20 12:54:46 --> Router Class Initialized
INFO - 2022-04-20 12:54:46 --> Output Class Initialized
INFO - 2022-04-20 12:54:46 --> Config Class Initialized
INFO - 2022-04-20 12:54:46 --> Config Class Initialized
INFO - 2022-04-20 12:54:46 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:46 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:46 --> Output Class Initialized
INFO - 2022-04-20 12:54:46 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:46 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:46 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:46 --> Input Class Initialized
INFO - 2022-04-20 12:54:46 --> URI Class Initialized
INFO - 2022-04-20 12:54:46 --> Language Class Initialized
ERROR - 2022-04-20 12:54:46 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:46 --> Router Class Initialized
INFO - 2022-04-20 12:54:46 --> Output Class Initialized
INFO - 2022-04-20 12:54:46 --> Security Class Initialized
INFO - 2022-04-20 12:54:46 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:46 --> Input Class Initialized
INFO - 2022-04-20 12:54:46 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:46 --> Input Class Initialized
ERROR - 2022-04-20 12:54:46 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:46 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:46 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:54:46 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:46 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:46 --> URI Class Initialized
INFO - 2022-04-20 12:54:46 --> Router Class Initialized
INFO - 2022-04-20 12:54:46 --> Output Class Initialized
INFO - 2022-04-20 12:54:46 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:46 --> Input Class Initialized
INFO - 2022-04-20 12:54:46 --> Language Class Initialized
ERROR - 2022-04-20 12:54:46 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Loader Class Initialized
INFO - 2022-04-20 12:54:49 --> Helper loaded: url_helper
INFO - 2022-04-20 12:54:49 --> Controller Class Initialized
DEBUG - 2022-04-20 12:54:49 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:54:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:54:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:54:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:54:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:54:49 --> Final output sent to browser
DEBUG - 2022-04-20 12:54:49 --> Total execution time: 0.0202
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Config Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Hooks Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
DEBUG - 2022-04-20 12:54:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:54:49 --> Utf8 Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> URI Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Router Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Output Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:54:49 --> Security Class Initialized
DEBUG - 2022-04-20 12:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:54:49 --> Input Class Initialized
INFO - 2022-04-20 12:54:49 --> Language Class Initialized
ERROR - 2022-04-20 12:54:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Loader Class Initialized
INFO - 2022-04-20 12:55:52 --> Helper loaded: url_helper
INFO - 2022-04-20 12:55:52 --> Controller Class Initialized
DEBUG - 2022-04-20 12:55:52 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:55:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:55:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:55:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:55:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:55:52 --> Final output sent to browser
DEBUG - 2022-04-20 12:55:52 --> Total execution time: 0.0189
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:52 --> Config Class Initialized
INFO - 2022-04-20 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:52 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:52 --> URI Class Initialized
INFO - 2022-04-20 12:55:52 --> Router Class Initialized
INFO - 2022-04-20 12:55:52 --> Output Class Initialized
INFO - 2022-04-20 12:55:52 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:52 --> Input Class Initialized
INFO - 2022-04-20 12:55:52 --> Language Class Initialized
ERROR - 2022-04-20 12:55:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Loader Class Initialized
INFO - 2022-04-20 12:55:56 --> Helper loaded: url_helper
INFO - 2022-04-20 12:55:56 --> Controller Class Initialized
DEBUG - 2022-04-20 12:55:56 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:55:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:55:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:55:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:55:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:55:56 --> Final output sent to browser
DEBUG - 2022-04-20 12:55:56 --> Total execution time: 0.0176
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Config Class Initialized
INFO - 2022-04-20 12:55:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
DEBUG - 2022-04-20 12:55:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:55:56 --> Utf8 Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:55:56 --> URI Class Initialized
INFO - 2022-04-20 12:55:56 --> Router Class Initialized
INFO - 2022-04-20 12:55:56 --> Output Class Initialized
INFO - 2022-04-20 12:55:56 --> Security Class Initialized
DEBUG - 2022-04-20 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:55:56 --> Input Class Initialized
INFO - 2022-04-20 12:55:56 --> Language Class Initialized
ERROR - 2022-04-20 12:55:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Loader Class Initialized
INFO - 2022-04-20 12:57:13 --> Helper loaded: url_helper
INFO - 2022-04-20 12:57:13 --> Controller Class Initialized
DEBUG - 2022-04-20 12:57:13 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:57:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:57:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:57:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:57:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:57:13 --> Final output sent to browser
DEBUG - 2022-04-20 12:57:13 --> Total execution time: 0.0197
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Config Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:57:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> URI Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> Router Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
INFO - 2022-04-20 12:57:13 --> Output Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
INFO - 2022-04-20 12:57:13 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
DEBUG - 2022-04-20 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:13 --> Input Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
INFO - 2022-04-20 12:57:13 --> Language Class Initialized
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:57:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Loader Class Initialized
INFO - 2022-04-20 12:57:16 --> Helper loaded: url_helper
INFO - 2022-04-20 12:57:16 --> Controller Class Initialized
DEBUG - 2022-04-20 12:57:16 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:57:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:57:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:57:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:57:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:57:16 --> Final output sent to browser
DEBUG - 2022-04-20 12:57:16 --> Total execution time: 0.0195
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:16 --> Config Class Initialized
INFO - 2022-04-20 12:57:16 --> Hooks Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:57:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:16 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:16 --> URI Class Initialized
INFO - 2022-04-20 12:57:16 --> Router Class Initialized
INFO - 2022-04-20 12:57:16 --> Output Class Initialized
INFO - 2022-04-20 12:57:16 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:16 --> Input Class Initialized
INFO - 2022-04-20 12:57:16 --> Language Class Initialized
ERROR - 2022-04-20 12:57:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Loader Class Initialized
INFO - 2022-04-20 12:57:41 --> Helper loaded: url_helper
INFO - 2022-04-20 12:57:41 --> Controller Class Initialized
DEBUG - 2022-04-20 12:57:41 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:57:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:57:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:57:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:57:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:57:41 --> Final output sent to browser
DEBUG - 2022-04-20 12:57:41 --> Total execution time: 0.0195
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:57:41 --> Config Class Initialized
INFO - 2022-04-20 12:57:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:57:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:57:41 --> Utf8 Class Initialized
INFO - 2022-04-20 12:57:41 --> URI Class Initialized
INFO - 2022-04-20 12:57:41 --> Router Class Initialized
INFO - 2022-04-20 12:57:41 --> Output Class Initialized
INFO - 2022-04-20 12:57:41 --> Security Class Initialized
DEBUG - 2022-04-20 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:57:41 --> Input Class Initialized
INFO - 2022-04-20 12:57:41 --> Language Class Initialized
ERROR - 2022-04-20 12:57:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:58:24 --> Config Class Initialized
INFO - 2022-04-20 12:58:24 --> Hooks Class Initialized
DEBUG - 2022-04-20 12:58:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:58:24 --> Utf8 Class Initialized
INFO - 2022-04-20 12:58:24 --> URI Class Initialized
INFO - 2022-04-20 12:58:24 --> Router Class Initialized
INFO - 2022-04-20 12:58:24 --> Output Class Initialized
INFO - 2022-04-20 12:58:24 --> Security Class Initialized
DEBUG - 2022-04-20 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:58:24 --> Input Class Initialized
INFO - 2022-04-20 12:58:24 --> Language Class Initialized
INFO - 2022-04-20 12:58:24 --> Language Class Initialized
INFO - 2022-04-20 12:58:24 --> Config Class Initialized
INFO - 2022-04-20 12:58:24 --> Loader Class Initialized
INFO - 2022-04-20 12:58:24 --> Helper loaded: url_helper
INFO - 2022-04-20 12:58:24 --> Controller Class Initialized
DEBUG - 2022-04-20 12:58:24 --> About MX_Controller Initialized
DEBUG - 2022-04-20 12:58:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 12:58:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 12:58:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 12:58:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 12:58:24 --> Final output sent to browser
DEBUG - 2022-04-20 12:58:24 --> Total execution time: 0.0189
INFO - 2022-04-20 12:58:24 --> Config Class Initialized
INFO - 2022-04-20 12:58:24 --> Hooks Class Initialized
INFO - 2022-04-20 12:58:24 --> Config Class Initialized
INFO - 2022-04-20 12:58:24 --> Hooks Class Initialized
INFO - 2022-04-20 12:58:24 --> Config Class Initialized
DEBUG - 2022-04-20 12:58:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:58:24 --> Hooks Class Initialized
INFO - 2022-04-20 12:58:24 --> Utf8 Class Initialized
DEBUG - 2022-04-20 12:58:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:58:24 --> Utf8 Class Initialized
INFO - 2022-04-20 12:58:24 --> URI Class Initialized
INFO - 2022-04-20 12:58:24 --> URI Class Initialized
DEBUG - 2022-04-20 12:58:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 12:58:24 --> Utf8 Class Initialized
INFO - 2022-04-20 12:58:24 --> URI Class Initialized
INFO - 2022-04-20 12:58:24 --> Router Class Initialized
INFO - 2022-04-20 12:58:24 --> Router Class Initialized
INFO - 2022-04-20 12:58:24 --> Output Class Initialized
INFO - 2022-04-20 12:58:24 --> Output Class Initialized
INFO - 2022-04-20 12:58:24 --> Router Class Initialized
INFO - 2022-04-20 12:58:24 --> Security Class Initialized
INFO - 2022-04-20 12:58:24 --> Output Class Initialized
INFO - 2022-04-20 12:58:24 --> Security Class Initialized
DEBUG - 2022-04-20 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:58:24 --> Input Class Initialized
DEBUG - 2022-04-20 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:58:24 --> Input Class Initialized
INFO - 2022-04-20 12:58:24 --> Language Class Initialized
INFO - 2022-04-20 12:58:24 --> Language Class Initialized
ERROR - 2022-04-20 12:58:24 --> 404 Page Not Found: /index
ERROR - 2022-04-20 12:58:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 12:58:24 --> Security Class Initialized
DEBUG - 2022-04-20 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 12:58:24 --> Input Class Initialized
INFO - 2022-04-20 12:58:24 --> Language Class Initialized
ERROR - 2022-04-20 12:58:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:03 --> Config Class Initialized
INFO - 2022-04-20 13:02:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:03 --> URI Class Initialized
INFO - 2022-04-20 13:02:03 --> Router Class Initialized
INFO - 2022-04-20 13:02:03 --> Output Class Initialized
INFO - 2022-04-20 13:02:03 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:03 --> Input Class Initialized
INFO - 2022-04-20 13:02:03 --> Language Class Initialized
INFO - 2022-04-20 13:02:03 --> Language Class Initialized
INFO - 2022-04-20 13:02:03 --> Config Class Initialized
INFO - 2022-04-20 13:02:03 --> Loader Class Initialized
INFO - 2022-04-20 13:02:03 --> Helper loaded: url_helper
INFO - 2022-04-20 13:02:03 --> Controller Class Initialized
DEBUG - 2022-04-20 13:02:03 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:02:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:02:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:02:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:02:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:02:03 --> Final output sent to browser
DEBUG - 2022-04-20 13:02:03 --> Total execution time: 0.0214
INFO - 2022-04-20 13:02:03 --> Config Class Initialized
INFO - 2022-04-20 13:02:03 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:03 --> Config Class Initialized
INFO - 2022-04-20 13:02:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:03 --> URI Class Initialized
DEBUG - 2022-04-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:03 --> URI Class Initialized
INFO - 2022-04-20 13:02:03 --> Router Class Initialized
INFO - 2022-04-20 13:02:03 --> Output Class Initialized
INFO - 2022-04-20 13:02:03 --> Router Class Initialized
INFO - 2022-04-20 13:02:03 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:03 --> Input Class Initialized
INFO - 2022-04-20 13:02:03 --> Output Class Initialized
INFO - 2022-04-20 13:02:03 --> Config Class Initialized
INFO - 2022-04-20 13:02:03 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:03 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:03 --> Input Class Initialized
DEBUG - 2022-04-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:03 --> Language Class Initialized
INFO - 2022-04-20 13:02:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:03 --> URI Class Initialized
ERROR - 2022-04-20 13:02:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:03 --> Router Class Initialized
INFO - 2022-04-20 13:02:03 --> Output Class Initialized
INFO - 2022-04-20 13:02:03 --> Language Class Initialized
INFO - 2022-04-20 13:02:03 --> Security Class Initialized
ERROR - 2022-04-20 13:02:03 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:03 --> Input Class Initialized
INFO - 2022-04-20 13:02:03 --> Config Class Initialized
INFO - 2022-04-20 13:02:03 --> Language Class Initialized
ERROR - 2022-04-20 13:02:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:03 --> URI Class Initialized
INFO - 2022-04-20 13:02:03 --> Router Class Initialized
INFO - 2022-04-20 13:02:03 --> Output Class Initialized
INFO - 2022-04-20 13:02:03 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:03 --> Input Class Initialized
INFO - 2022-04-20 13:02:03 --> Language Class Initialized
ERROR - 2022-04-20 13:02:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Loader Class Initialized
INFO - 2022-04-20 13:02:08 --> Helper loaded: url_helper
INFO - 2022-04-20 13:02:08 --> Controller Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:02:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:02:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:02:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:02:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:02:08 --> Final output sent to browser
DEBUG - 2022-04-20 13:02:08 --> Total execution time: 0.0187
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:02:08 --> Config Class Initialized
INFO - 2022-04-20 13:02:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:02:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:02:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:02:08 --> URI Class Initialized
INFO - 2022-04-20 13:02:08 --> Router Class Initialized
INFO - 2022-04-20 13:02:08 --> Output Class Initialized
INFO - 2022-04-20 13:02:08 --> Security Class Initialized
DEBUG - 2022-04-20 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:02:08 --> Input Class Initialized
INFO - 2022-04-20 13:02:08 --> Language Class Initialized
ERROR - 2022-04-20 13:02:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:00 --> Config Class Initialized
INFO - 2022-04-20 13:03:00 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:00 --> URI Class Initialized
INFO - 2022-04-20 13:03:00 --> Router Class Initialized
INFO - 2022-04-20 13:03:00 --> Output Class Initialized
INFO - 2022-04-20 13:03:00 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:00 --> Input Class Initialized
INFO - 2022-04-20 13:03:00 --> Language Class Initialized
INFO - 2022-04-20 13:03:00 --> Language Class Initialized
INFO - 2022-04-20 13:03:00 --> Config Class Initialized
INFO - 2022-04-20 13:03:00 --> Loader Class Initialized
INFO - 2022-04-20 13:03:00 --> Helper loaded: url_helper
INFO - 2022-04-20 13:03:00 --> Controller Class Initialized
DEBUG - 2022-04-20 13:03:00 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:03:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:03:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:03:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:03:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:03:00 --> Final output sent to browser
DEBUG - 2022-04-20 13:03:00 --> Total execution time: 0.0193
INFO - 2022-04-20 13:03:00 --> Config Class Initialized
INFO - 2022-04-20 13:03:00 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:00 --> Config Class Initialized
INFO - 2022-04-20 13:03:00 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:00 --> Config Class Initialized
INFO - 2022-04-20 13:03:00 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:00 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:03:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:00 --> URI Class Initialized
INFO - 2022-04-20 13:03:00 --> URI Class Initialized
INFO - 2022-04-20 13:03:00 --> Router Class Initialized
INFO - 2022-04-20 13:03:00 --> Router Class Initialized
INFO - 2022-04-20 13:03:00 --> Output Class Initialized
INFO - 2022-04-20 13:03:00 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:00 --> Input Class Initialized
INFO - 2022-04-20 13:03:00 --> Language Class Initialized
ERROR - 2022-04-20 13:03:00 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:00 --> Output Class Initialized
INFO - 2022-04-20 13:03:00 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:03:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:00 --> Input Class Initialized
INFO - 2022-04-20 13:03:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:00 --> Language Class Initialized
INFO - 2022-04-20 13:03:00 --> URI Class Initialized
ERROR - 2022-04-20 13:03:00 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:00 --> Router Class Initialized
INFO - 2022-04-20 13:03:00 --> Output Class Initialized
INFO - 2022-04-20 13:03:00 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:00 --> Input Class Initialized
INFO - 2022-04-20 13:03:00 --> Language Class Initialized
ERROR - 2022-04-20 13:03:00 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:10 --> Config Class Initialized
INFO - 2022-04-20 13:03:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:10 --> URI Class Initialized
INFO - 2022-04-20 13:03:10 --> Router Class Initialized
INFO - 2022-04-20 13:03:10 --> Output Class Initialized
INFO - 2022-04-20 13:03:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:10 --> Input Class Initialized
INFO - 2022-04-20 13:03:10 --> Language Class Initialized
INFO - 2022-04-20 13:03:10 --> Language Class Initialized
INFO - 2022-04-20 13:03:10 --> Config Class Initialized
INFO - 2022-04-20 13:03:10 --> Loader Class Initialized
INFO - 2022-04-20 13:03:10 --> Helper loaded: url_helper
INFO - 2022-04-20 13:03:10 --> Controller Class Initialized
DEBUG - 2022-04-20 13:03:10 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:03:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:03:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:03:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:03:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:03:10 --> Final output sent to browser
DEBUG - 2022-04-20 13:03:10 --> Total execution time: 0.0193
INFO - 2022-04-20 13:03:10 --> Config Class Initialized
INFO - 2022-04-20 13:03:10 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:10 --> Config Class Initialized
INFO - 2022-04-20 13:03:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:10 --> Config Class Initialized
INFO - 2022-04-20 13:03:10 --> URI Class Initialized
INFO - 2022-04-20 13:03:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:10 --> URI Class Initialized
DEBUG - 2022-04-20 13:03:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:10 --> URI Class Initialized
INFO - 2022-04-20 13:03:10 --> Router Class Initialized
INFO - 2022-04-20 13:03:10 --> Output Class Initialized
INFO - 2022-04-20 13:03:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:10 --> Input Class Initialized
INFO - 2022-04-20 13:03:10 --> Router Class Initialized
INFO - 2022-04-20 13:03:10 --> Language Class Initialized
INFO - 2022-04-20 13:03:10 --> Output Class Initialized
ERROR - 2022-04-20 13:03:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:10 --> Security Class Initialized
INFO - 2022-04-20 13:03:10 --> Router Class Initialized
DEBUG - 2022-04-20 13:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:10 --> Input Class Initialized
INFO - 2022-04-20 13:03:10 --> Language Class Initialized
INFO - 2022-04-20 13:03:10 --> Output Class Initialized
ERROR - 2022-04-20 13:03:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:10 --> Input Class Initialized
INFO - 2022-04-20 13:03:10 --> Language Class Initialized
ERROR - 2022-04-20 13:03:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:15 --> Config Class Initialized
INFO - 2022-04-20 13:03:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:15 --> URI Class Initialized
INFO - 2022-04-20 13:03:15 --> Router Class Initialized
INFO - 2022-04-20 13:03:15 --> Output Class Initialized
INFO - 2022-04-20 13:03:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:15 --> Input Class Initialized
INFO - 2022-04-20 13:03:15 --> Language Class Initialized
INFO - 2022-04-20 13:03:15 --> Language Class Initialized
INFO - 2022-04-20 13:03:15 --> Config Class Initialized
INFO - 2022-04-20 13:03:15 --> Loader Class Initialized
INFO - 2022-04-20 13:03:15 --> Helper loaded: url_helper
INFO - 2022-04-20 13:03:15 --> Controller Class Initialized
DEBUG - 2022-04-20 13:03:15 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:03:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:03:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:03:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:03:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:03:15 --> Final output sent to browser
DEBUG - 2022-04-20 13:03:15 --> Total execution time: 0.0191
INFO - 2022-04-20 13:03:15 --> Config Class Initialized
INFO - 2022-04-20 13:03:15 --> Config Class Initialized
INFO - 2022-04-20 13:03:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:15 --> Config Class Initialized
INFO - 2022-04-20 13:03:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:15 --> URI Class Initialized
DEBUG - 2022-04-20 13:03:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:15 --> Router Class Initialized
INFO - 2022-04-20 13:03:15 --> URI Class Initialized
DEBUG - 2022-04-20 13:03:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:15 --> Output Class Initialized
INFO - 2022-04-20 13:03:15 --> Router Class Initialized
INFO - 2022-04-20 13:03:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:15 --> Output Class Initialized
INFO - 2022-04-20 13:03:15 --> Input Class Initialized
INFO - 2022-04-20 13:03:15 --> Language Class Initialized
INFO - 2022-04-20 13:03:15 --> Security Class Initialized
ERROR - 2022-04-20 13:03:15 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:15 --> Input Class Initialized
INFO - 2022-04-20 13:03:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:15 --> Language Class Initialized
INFO - 2022-04-20 13:03:15 --> URI Class Initialized
ERROR - 2022-04-20 13:03:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:15 --> Router Class Initialized
INFO - 2022-04-20 13:03:15 --> Output Class Initialized
INFO - 2022-04-20 13:03:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:15 --> Input Class Initialized
INFO - 2022-04-20 13:03:15 --> Language Class Initialized
ERROR - 2022-04-20 13:03:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Loader Class Initialized
INFO - 2022-04-20 13:03:17 --> Helper loaded: url_helper
INFO - 2022-04-20 13:03:17 --> Controller Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:03:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:03:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:03:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:03:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:03:17 --> Final output sent to browser
DEBUG - 2022-04-20 13:03:17 --> Total execution time: 0.0187
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:03:17 --> Config Class Initialized
INFO - 2022-04-20 13:03:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:03:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:03:17 --> Utf8 Class Initialized
INFO - 2022-04-20 13:03:17 --> URI Class Initialized
INFO - 2022-04-20 13:03:17 --> Router Class Initialized
INFO - 2022-04-20 13:03:17 --> Output Class Initialized
INFO - 2022-04-20 13:03:17 --> Security Class Initialized
DEBUG - 2022-04-20 13:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:03:17 --> Input Class Initialized
INFO - 2022-04-20 13:03:17 --> Language Class Initialized
ERROR - 2022-04-20 13:03:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:06 --> Config Class Initialized
INFO - 2022-04-20 13:04:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:06 --> URI Class Initialized
INFO - 2022-04-20 13:04:06 --> Router Class Initialized
INFO - 2022-04-20 13:04:06 --> Output Class Initialized
INFO - 2022-04-20 13:04:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:06 --> Input Class Initialized
INFO - 2022-04-20 13:04:06 --> Language Class Initialized
INFO - 2022-04-20 13:04:06 --> Language Class Initialized
INFO - 2022-04-20 13:04:06 --> Config Class Initialized
INFO - 2022-04-20 13:04:06 --> Loader Class Initialized
INFO - 2022-04-20 13:04:06 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:06 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:06 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:04:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:04:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:06 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:06 --> Total execution time: 0.0198
INFO - 2022-04-20 13:04:06 --> Config Class Initialized
INFO - 2022-04-20 13:04:06 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:06 --> Config Class Initialized
INFO - 2022-04-20 13:04:06 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:06 --> Config Class Initialized
INFO - 2022-04-20 13:04:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:06 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:04:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:06 --> URI Class Initialized
INFO - 2022-04-20 13:04:06 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:04:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:06 --> URI Class Initialized
INFO - 2022-04-20 13:04:06 --> URI Class Initialized
INFO - 2022-04-20 13:04:06 --> Router Class Initialized
INFO - 2022-04-20 13:04:06 --> Router Class Initialized
INFO - 2022-04-20 13:04:06 --> Output Class Initialized
INFO - 2022-04-20 13:04:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:06 --> Input Class Initialized
INFO - 2022-04-20 13:04:06 --> Language Class Initialized
INFO - 2022-04-20 13:04:06 --> Output Class Initialized
ERROR - 2022-04-20 13:04:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:06 --> Input Class Initialized
INFO - 2022-04-20 13:04:06 --> Language Class Initialized
ERROR - 2022-04-20 13:04:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:06 --> Router Class Initialized
INFO - 2022-04-20 13:04:06 --> Output Class Initialized
INFO - 2022-04-20 13:04:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:06 --> Input Class Initialized
INFO - 2022-04-20 13:04:06 --> Language Class Initialized
ERROR - 2022-04-20 13:04:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:12 --> Config Class Initialized
INFO - 2022-04-20 13:04:12 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:12 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:12 --> URI Class Initialized
INFO - 2022-04-20 13:04:12 --> Router Class Initialized
INFO - 2022-04-20 13:04:12 --> Output Class Initialized
INFO - 2022-04-20 13:04:12 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:12 --> Input Class Initialized
INFO - 2022-04-20 13:04:12 --> Language Class Initialized
INFO - 2022-04-20 13:04:12 --> Language Class Initialized
INFO - 2022-04-20 13:04:12 --> Config Class Initialized
INFO - 2022-04-20 13:04:12 --> Loader Class Initialized
INFO - 2022-04-20 13:04:12 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:12 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:12 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:04:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:04:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:12 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:12 --> Total execution time: 0.0197
INFO - 2022-04-20 13:04:12 --> Config Class Initialized
INFO - 2022-04-20 13:04:12 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:12 --> Config Class Initialized
INFO - 2022-04-20 13:04:12 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:12 --> Config Class Initialized
INFO - 2022-04-20 13:04:12 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:04:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:12 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:12 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:12 --> URI Class Initialized
INFO - 2022-04-20 13:04:12 --> URI Class Initialized
DEBUG - 2022-04-20 13:04:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:12 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:12 --> Router Class Initialized
INFO - 2022-04-20 13:04:12 --> URI Class Initialized
INFO - 2022-04-20 13:04:12 --> Output Class Initialized
INFO - 2022-04-20 13:04:12 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:12 --> Router Class Initialized
INFO - 2022-04-20 13:04:12 --> Input Class Initialized
INFO - 2022-04-20 13:04:12 --> Language Class Initialized
INFO - 2022-04-20 13:04:12 --> Output Class Initialized
ERROR - 2022-04-20 13:04:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:12 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:12 --> Input Class Initialized
INFO - 2022-04-20 13:04:12 --> Router Class Initialized
INFO - 2022-04-20 13:04:12 --> Language Class Initialized
ERROR - 2022-04-20 13:04:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:12 --> Output Class Initialized
INFO - 2022-04-20 13:04:12 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:12 --> Input Class Initialized
INFO - 2022-04-20 13:04:12 --> Language Class Initialized
ERROR - 2022-04-20 13:04:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:13 --> Config Class Initialized
INFO - 2022-04-20 13:04:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:13 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:13 --> URI Class Initialized
INFO - 2022-04-20 13:04:13 --> Router Class Initialized
INFO - 2022-04-20 13:04:13 --> Output Class Initialized
INFO - 2022-04-20 13:04:13 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:13 --> Input Class Initialized
INFO - 2022-04-20 13:04:13 --> Language Class Initialized
INFO - 2022-04-20 13:04:13 --> Language Class Initialized
INFO - 2022-04-20 13:04:13 --> Config Class Initialized
INFO - 2022-04-20 13:04:13 --> Loader Class Initialized
INFO - 2022-04-20 13:04:13 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:13 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:13 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:04:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:04:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:13 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:13 --> Total execution time: 0.0190
INFO - 2022-04-20 13:04:13 --> Config Class Initialized
INFO - 2022-04-20 13:04:13 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:13 --> Config Class Initialized
INFO - 2022-04-20 13:04:13 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:13 --> Config Class Initialized
INFO - 2022-04-20 13:04:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:04:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:13 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:04:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:13 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:13 --> URI Class Initialized
INFO - 2022-04-20 13:04:13 --> URI Class Initialized
INFO - 2022-04-20 13:04:13 --> Router Class Initialized
INFO - 2022-04-20 13:04:13 --> Router Class Initialized
INFO - 2022-04-20 13:04:13 --> Output Class Initialized
INFO - 2022-04-20 13:04:13 --> Security Class Initialized
INFO - 2022-04-20 13:04:13 --> Output Class Initialized
INFO - 2022-04-20 13:04:13 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:13 --> Input Class Initialized
INFO - 2022-04-20 13:04:13 --> Language Class Initialized
DEBUG - 2022-04-20 13:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:04:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:13 --> Input Class Initialized
INFO - 2022-04-20 13:04:13 --> Language Class Initialized
INFO - 2022-04-20 13:04:13 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:04:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:14 --> URI Class Initialized
INFO - 2022-04-20 13:04:14 --> Router Class Initialized
INFO - 2022-04-20 13:04:14 --> Output Class Initialized
INFO - 2022-04-20 13:04:14 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:14 --> Input Class Initialized
INFO - 2022-04-20 13:04:14 --> Language Class Initialized
ERROR - 2022-04-20 13:04:14 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:14 --> Config Class Initialized
INFO - 2022-04-20 13:04:14 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:14 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:14 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:14 --> URI Class Initialized
INFO - 2022-04-20 13:04:14 --> Router Class Initialized
INFO - 2022-04-20 13:04:14 --> Output Class Initialized
INFO - 2022-04-20 13:04:14 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:14 --> Input Class Initialized
INFO - 2022-04-20 13:04:14 --> Language Class Initialized
INFO - 2022-04-20 13:04:14 --> Language Class Initialized
INFO - 2022-04-20 13:04:14 --> Config Class Initialized
INFO - 2022-04-20 13:04:14 --> Loader Class Initialized
INFO - 2022-04-20 13:04:14 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:14 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:14 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:04:14 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:14 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:14 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:04:14 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:14 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:14 --> Total execution time: 0.0190
INFO - 2022-04-20 13:04:14 --> Config Class Initialized
INFO - 2022-04-20 13:04:14 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:14 --> Config Class Initialized
INFO - 2022-04-20 13:04:14 --> Config Class Initialized
INFO - 2022-04-20 13:04:14 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:14 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:14 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:14 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:04:14 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:14 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:14 --> URI Class Initialized
INFO - 2022-04-20 13:04:14 --> URI Class Initialized
INFO - 2022-04-20 13:04:14 --> Router Class Initialized
INFO - 2022-04-20 13:04:14 --> Router Class Initialized
INFO - 2022-04-20 13:04:14 --> Output Class Initialized
INFO - 2022-04-20 13:04:14 --> Security Class Initialized
INFO - 2022-04-20 13:04:14 --> Output Class Initialized
DEBUG - 2022-04-20 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:14 --> Security Class Initialized
INFO - 2022-04-20 13:04:14 --> Input Class Initialized
INFO - 2022-04-20 13:04:14 --> Language Class Initialized
DEBUG - 2022-04-20 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:14 --> Input Class Initialized
ERROR - 2022-04-20 13:04:14 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:14 --> Language Class Initialized
ERROR - 2022-04-20 13:04:14 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:04:14 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:14 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:14 --> URI Class Initialized
INFO - 2022-04-20 13:04:14 --> Router Class Initialized
INFO - 2022-04-20 13:04:14 --> Output Class Initialized
INFO - 2022-04-20 13:04:14 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:14 --> Input Class Initialized
INFO - 2022-04-20 13:04:14 --> Language Class Initialized
ERROR - 2022-04-20 13:04:14 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:15 --> Config Class Initialized
INFO - 2022-04-20 13:04:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:15 --> URI Class Initialized
INFO - 2022-04-20 13:04:15 --> Router Class Initialized
INFO - 2022-04-20 13:04:15 --> Output Class Initialized
INFO - 2022-04-20 13:04:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:15 --> Input Class Initialized
INFO - 2022-04-20 13:04:15 --> Language Class Initialized
INFO - 2022-04-20 13:04:15 --> Language Class Initialized
INFO - 2022-04-20 13:04:15 --> Config Class Initialized
INFO - 2022-04-20 13:04:15 --> Loader Class Initialized
INFO - 2022-04-20 13:04:15 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:15 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:15 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:04:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:04:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:15 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:15 --> Total execution time: 0.0196
INFO - 2022-04-20 13:04:15 --> Config Class Initialized
INFO - 2022-04-20 13:04:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:15 --> Config Class Initialized
INFO - 2022-04-20 13:04:15 --> Config Class Initialized
INFO - 2022-04-20 13:04:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:15 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:04:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:15 --> URI Class Initialized
INFO - 2022-04-20 13:04:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:15 --> URI Class Initialized
INFO - 2022-04-20 13:04:15 --> Router Class Initialized
INFO - 2022-04-20 13:04:15 --> Router Class Initialized
INFO - 2022-04-20 13:04:15 --> Output Class Initialized
INFO - 2022-04-20 13:04:15 --> Security Class Initialized
INFO - 2022-04-20 13:04:15 --> Output Class Initialized
DEBUG - 2022-04-20 13:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:15 --> Security Class Initialized
INFO - 2022-04-20 13:04:15 --> Input Class Initialized
INFO - 2022-04-20 13:04:15 --> Language Class Initialized
DEBUG - 2022-04-20 13:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:15 --> Input Class Initialized
ERROR - 2022-04-20 13:04:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:15 --> Language Class Initialized
ERROR - 2022-04-20 13:04:15 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:04:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:15 --> URI Class Initialized
INFO - 2022-04-20 13:04:15 --> Router Class Initialized
INFO - 2022-04-20 13:04:15 --> Output Class Initialized
INFO - 2022-04-20 13:04:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:15 --> Input Class Initialized
INFO - 2022-04-20 13:04:15 --> Language Class Initialized
ERROR - 2022-04-20 13:04:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:25 --> Config Class Initialized
INFO - 2022-04-20 13:04:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:25 --> URI Class Initialized
INFO - 2022-04-20 13:04:25 --> Router Class Initialized
INFO - 2022-04-20 13:04:25 --> Output Class Initialized
INFO - 2022-04-20 13:04:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:25 --> Input Class Initialized
INFO - 2022-04-20 13:04:25 --> Language Class Initialized
INFO - 2022-04-20 13:04:25 --> Language Class Initialized
INFO - 2022-04-20 13:04:25 --> Config Class Initialized
INFO - 2022-04-20 13:04:25 --> Loader Class Initialized
INFO - 2022-04-20 13:04:25 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:25 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:25 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:04:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:04:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:25 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:25 --> Total execution time: 0.0182
INFO - 2022-04-20 13:04:25 --> Config Class Initialized
INFO - 2022-04-20 13:04:25 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:25 --> Config Class Initialized
INFO - 2022-04-20 13:04:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:25 --> URI Class Initialized
DEBUG - 2022-04-20 13:04:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:25 --> Router Class Initialized
INFO - 2022-04-20 13:04:25 --> URI Class Initialized
INFO - 2022-04-20 13:04:25 --> Output Class Initialized
INFO - 2022-04-20 13:04:25 --> Security Class Initialized
INFO - 2022-04-20 13:04:25 --> Router Class Initialized
DEBUG - 2022-04-20 13:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:25 --> Input Class Initialized
INFO - 2022-04-20 13:04:25 --> Language Class Initialized
INFO - 2022-04-20 13:04:25 --> Output Class Initialized
ERROR - 2022-04-20 13:04:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:25 --> Input Class Initialized
INFO - 2022-04-20 13:04:25 --> Language Class Initialized
ERROR - 2022-04-20 13:04:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:25 --> Config Class Initialized
INFO - 2022-04-20 13:04:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:25 --> URI Class Initialized
INFO - 2022-04-20 13:04:25 --> Router Class Initialized
INFO - 2022-04-20 13:04:25 --> Output Class Initialized
INFO - 2022-04-20 13:04:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:25 --> Input Class Initialized
INFO - 2022-04-20 13:04:25 --> Language Class Initialized
ERROR - 2022-04-20 13:04:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:27 --> Config Class Initialized
INFO - 2022-04-20 13:04:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:27 --> URI Class Initialized
DEBUG - 2022-04-20 13:04:27 --> No URI present. Default controller set.
INFO - 2022-04-20 13:04:27 --> Router Class Initialized
INFO - 2022-04-20 13:04:27 --> Output Class Initialized
INFO - 2022-04-20 13:04:27 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:27 --> Input Class Initialized
INFO - 2022-04-20 13:04:27 --> Language Class Initialized
INFO - 2022-04-20 13:04:27 --> Language Class Initialized
INFO - 2022-04-20 13:04:27 --> Config Class Initialized
INFO - 2022-04-20 13:04:27 --> Loader Class Initialized
INFO - 2022-04-20 13:04:27 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:27 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:27 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:04:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:04:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:27 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:27 --> Total execution time: 0.0207
INFO - 2022-04-20 13:04:27 --> Config Class Initialized
INFO - 2022-04-20 13:04:27 --> Config Class Initialized
INFO - 2022-04-20 13:04:27 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:27 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:27 --> Config Class Initialized
INFO - 2022-04-20 13:04:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:04:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:27 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:04:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:27 --> URI Class Initialized
INFO - 2022-04-20 13:04:27 --> URI Class Initialized
INFO - 2022-04-20 13:04:27 --> URI Class Initialized
INFO - 2022-04-20 13:04:27 --> Router Class Initialized
INFO - 2022-04-20 13:04:27 --> Router Class Initialized
INFO - 2022-04-20 13:04:27 --> Router Class Initialized
INFO - 2022-04-20 13:04:27 --> Output Class Initialized
INFO - 2022-04-20 13:04:27 --> Output Class Initialized
INFO - 2022-04-20 13:04:27 --> Output Class Initialized
INFO - 2022-04-20 13:04:27 --> Security Class Initialized
INFO - 2022-04-20 13:04:27 --> Security Class Initialized
INFO - 2022-04-20 13:04:27 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:27 --> Input Class Initialized
INFO - 2022-04-20 13:04:27 --> Input Class Initialized
INFO - 2022-04-20 13:04:27 --> Language Class Initialized
DEBUG - 2022-04-20 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:27 --> Language Class Initialized
INFO - 2022-04-20 13:04:27 --> Input Class Initialized
INFO - 2022-04-20 13:04:27 --> Language Class Initialized
ERROR - 2022-04-20 13:04:27 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:04:27 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:04:27 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:39 --> Config Class Initialized
INFO - 2022-04-20 13:04:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:39 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:39 --> URI Class Initialized
INFO - 2022-04-20 13:04:39 --> Router Class Initialized
INFO - 2022-04-20 13:04:39 --> Output Class Initialized
INFO - 2022-04-20 13:04:39 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:39 --> Input Class Initialized
INFO - 2022-04-20 13:04:39 --> Language Class Initialized
INFO - 2022-04-20 13:04:39 --> Language Class Initialized
INFO - 2022-04-20 13:04:39 --> Config Class Initialized
INFO - 2022-04-20 13:04:39 --> Loader Class Initialized
INFO - 2022-04-20 13:04:39 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:39 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:39 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:04:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:04:39 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:39 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:39 --> Total execution time: 0.0208
INFO - 2022-04-20 13:04:39 --> Config Class Initialized
INFO - 2022-04-20 13:04:39 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:39 --> Config Class Initialized
INFO - 2022-04-20 13:04:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:39 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:39 --> URI Class Initialized
DEBUG - 2022-04-20 13:04:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:39 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:39 --> URI Class Initialized
INFO - 2022-04-20 13:04:39 --> Router Class Initialized
INFO - 2022-04-20 13:04:39 --> Config Class Initialized
INFO - 2022-04-20 13:04:39 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:39 --> Output Class Initialized
INFO - 2022-04-20 13:04:39 --> Router Class Initialized
INFO - 2022-04-20 13:04:39 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:39 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:39 --> Output Class Initialized
DEBUG - 2022-04-20 13:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:39 --> Input Class Initialized
INFO - 2022-04-20 13:04:39 --> Language Class Initialized
INFO - 2022-04-20 13:04:39 --> Security Class Initialized
INFO - 2022-04-20 13:04:39 --> URI Class Initialized
ERROR - 2022-04-20 13:04:39 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:39 --> Input Class Initialized
INFO - 2022-04-20 13:04:39 --> Language Class Initialized
INFO - 2022-04-20 13:04:39 --> Router Class Initialized
ERROR - 2022-04-20 13:04:39 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:39 --> Output Class Initialized
INFO - 2022-04-20 13:04:39 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:39 --> Input Class Initialized
INFO - 2022-04-20 13:04:39 --> Language Class Initialized
ERROR - 2022-04-20 13:04:39 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:40 --> Config Class Initialized
INFO - 2022-04-20 13:04:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:40 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:40 --> URI Class Initialized
INFO - 2022-04-20 13:04:40 --> Router Class Initialized
INFO - 2022-04-20 13:04:40 --> Output Class Initialized
INFO - 2022-04-20 13:04:40 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:40 --> Input Class Initialized
INFO - 2022-04-20 13:04:40 --> Language Class Initialized
INFO - 2022-04-20 13:04:40 --> Language Class Initialized
INFO - 2022-04-20 13:04:40 --> Config Class Initialized
INFO - 2022-04-20 13:04:40 --> Loader Class Initialized
INFO - 2022-04-20 13:04:40 --> Helper loaded: url_helper
INFO - 2022-04-20 13:04:40 --> Controller Class Initialized
DEBUG - 2022-04-20 13:04:40 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:04:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:04:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:04:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:04:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:04:40 --> Final output sent to browser
DEBUG - 2022-04-20 13:04:40 --> Total execution time: 0.0178
INFO - 2022-04-20 13:04:40 --> Config Class Initialized
INFO - 2022-04-20 13:04:40 --> Config Class Initialized
INFO - 2022-04-20 13:04:40 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:04:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:40 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:40 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:40 --> Config Class Initialized
INFO - 2022-04-20 13:04:40 --> URI Class Initialized
INFO - 2022-04-20 13:04:40 --> Hooks Class Initialized
INFO - 2022-04-20 13:04:40 --> URI Class Initialized
DEBUG - 2022-04-20 13:04:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:04:40 --> Utf8 Class Initialized
INFO - 2022-04-20 13:04:40 --> Router Class Initialized
INFO - 2022-04-20 13:04:40 --> URI Class Initialized
INFO - 2022-04-20 13:04:40 --> Output Class Initialized
INFO - 2022-04-20 13:04:40 --> Security Class Initialized
DEBUG - 2022-04-20 13:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:40 --> Router Class Initialized
INFO - 2022-04-20 13:04:40 --> Input Class Initialized
INFO - 2022-04-20 13:04:40 --> Language Class Initialized
ERROR - 2022-04-20 13:04:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:04:40 --> Output Class Initialized
INFO - 2022-04-20 13:04:40 --> Security Class Initialized
INFO - 2022-04-20 13:04:40 --> Router Class Initialized
DEBUG - 2022-04-20 13:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:40 --> Output Class Initialized
INFO - 2022-04-20 13:04:40 --> Input Class Initialized
INFO - 2022-04-20 13:04:40 --> Language Class Initialized
INFO - 2022-04-20 13:04:40 --> Security Class Initialized
ERROR - 2022-04-20 13:04:40 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:04:40 --> Input Class Initialized
INFO - 2022-04-20 13:04:40 --> Language Class Initialized
ERROR - 2022-04-20 13:04:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:05:05 --> Config Class Initialized
INFO - 2022-04-20 13:05:05 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:05:05 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:05:05 --> Utf8 Class Initialized
INFO - 2022-04-20 13:05:05 --> URI Class Initialized
INFO - 2022-04-20 13:05:05 --> Router Class Initialized
INFO - 2022-04-20 13:05:05 --> Output Class Initialized
INFO - 2022-04-20 13:05:05 --> Security Class Initialized
DEBUG - 2022-04-20 13:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:05:05 --> Input Class Initialized
INFO - 2022-04-20 13:05:05 --> Language Class Initialized
INFO - 2022-04-20 13:05:06 --> Language Class Initialized
INFO - 2022-04-20 13:05:06 --> Config Class Initialized
INFO - 2022-04-20 13:05:06 --> Loader Class Initialized
INFO - 2022-04-20 13:05:06 --> Helper loaded: url_helper
INFO - 2022-04-20 13:05:06 --> Controller Class Initialized
DEBUG - 2022-04-20 13:05:06 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:05:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:05:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:05:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:05:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:05:06 --> Final output sent to browser
DEBUG - 2022-04-20 13:05:06 --> Total execution time: 0.0188
INFO - 2022-04-20 13:05:06 --> Config Class Initialized
INFO - 2022-04-20 13:05:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:05:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:05:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:05:06 --> Config Class Initialized
INFO - 2022-04-20 13:05:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:05:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:05:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:05:06 --> Config Class Initialized
INFO - 2022-04-20 13:05:06 --> Hooks Class Initialized
INFO - 2022-04-20 13:05:06 --> URI Class Initialized
INFO - 2022-04-20 13:05:06 --> URI Class Initialized
DEBUG - 2022-04-20 13:05:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:05:06 --> Router Class Initialized
INFO - 2022-04-20 13:05:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:05:06 --> Router Class Initialized
INFO - 2022-04-20 13:05:06 --> URI Class Initialized
INFO - 2022-04-20 13:05:06 --> Output Class Initialized
INFO - 2022-04-20 13:05:06 --> Output Class Initialized
INFO - 2022-04-20 13:05:06 --> Security Class Initialized
INFO - 2022-04-20 13:05:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:05:06 --> Input Class Initialized
INFO - 2022-04-20 13:05:06 --> Language Class Initialized
DEBUG - 2022-04-20 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:05:06 --> Input Class Initialized
ERROR - 2022-04-20 13:05:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:05:06 --> Language Class Initialized
INFO - 2022-04-20 13:05:06 --> Router Class Initialized
ERROR - 2022-04-20 13:05:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:05:06 --> Output Class Initialized
INFO - 2022-04-20 13:05:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:05:06 --> Input Class Initialized
INFO - 2022-04-20 13:05:06 --> Language Class Initialized
ERROR - 2022-04-20 13:05:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:07:48 --> Config Class Initialized
INFO - 2022-04-20 13:07:48 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:07:48 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:07:48 --> Utf8 Class Initialized
INFO - 2022-04-20 13:07:48 --> URI Class Initialized
DEBUG - 2022-04-20 13:07:48 --> No URI present. Default controller set.
INFO - 2022-04-20 13:07:48 --> Router Class Initialized
INFO - 2022-04-20 13:07:48 --> Output Class Initialized
INFO - 2022-04-20 13:07:48 --> Security Class Initialized
DEBUG - 2022-04-20 13:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:07:48 --> Input Class Initialized
INFO - 2022-04-20 13:07:48 --> Language Class Initialized
INFO - 2022-04-20 13:07:48 --> Language Class Initialized
INFO - 2022-04-20 13:07:48 --> Config Class Initialized
INFO - 2022-04-20 13:07:48 --> Loader Class Initialized
INFO - 2022-04-20 13:07:48 --> Helper loaded: url_helper
INFO - 2022-04-20 13:07:48 --> Controller Class Initialized
DEBUG - 2022-04-20 13:07:48 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:07:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:07:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:07:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:07:48 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:07:48 --> Final output sent to browser
DEBUG - 2022-04-20 13:07:48 --> Total execution time: 0.0194
INFO - 2022-04-20 13:07:49 --> Config Class Initialized
INFO - 2022-04-20 13:07:49 --> Hooks Class Initialized
INFO - 2022-04-20 13:07:49 --> Config Class Initialized
INFO - 2022-04-20 13:07:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:07:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:07:49 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:07:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:07:49 --> Utf8 Class Initialized
INFO - 2022-04-20 13:07:49 --> URI Class Initialized
INFO - 2022-04-20 13:07:49 --> URI Class Initialized
INFO - 2022-04-20 13:07:49 --> Router Class Initialized
INFO - 2022-04-20 13:07:49 --> Router Class Initialized
INFO - 2022-04-20 13:07:49 --> Output Class Initialized
INFO - 2022-04-20 13:07:49 --> Security Class Initialized
INFO - 2022-04-20 13:07:49 --> Output Class Initialized
DEBUG - 2022-04-20 13:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:07:49 --> Input Class Initialized
INFO - 2022-04-20 13:07:49 --> Security Class Initialized
INFO - 2022-04-20 13:07:49 --> Language Class Initialized
DEBUG - 2022-04-20 13:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:07:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:07:49 --> Input Class Initialized
INFO - 2022-04-20 13:07:49 --> Language Class Initialized
INFO - 2022-04-20 13:07:49 --> Config Class Initialized
INFO - 2022-04-20 13:07:49 --> Hooks Class Initialized
ERROR - 2022-04-20 13:07:49 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:07:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:07:49 --> Utf8 Class Initialized
INFO - 2022-04-20 13:07:49 --> URI Class Initialized
INFO - 2022-04-20 13:07:49 --> Router Class Initialized
INFO - 2022-04-20 13:07:49 --> Output Class Initialized
INFO - 2022-04-20 13:07:49 --> Security Class Initialized
DEBUG - 2022-04-20 13:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:07:49 --> Input Class Initialized
INFO - 2022-04-20 13:07:49 --> Language Class Initialized
ERROR - 2022-04-20 13:07:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:08:28 --> Config Class Initialized
INFO - 2022-04-20 13:08:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:08:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:28 --> URI Class Initialized
DEBUG - 2022-04-20 13:08:28 --> No URI present. Default controller set.
INFO - 2022-04-20 13:08:28 --> Router Class Initialized
INFO - 2022-04-20 13:08:28 --> Output Class Initialized
INFO - 2022-04-20 13:08:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:28 --> Input Class Initialized
INFO - 2022-04-20 13:08:28 --> Language Class Initialized
INFO - 2022-04-20 13:08:28 --> Language Class Initialized
INFO - 2022-04-20 13:08:28 --> Config Class Initialized
INFO - 2022-04-20 13:08:28 --> Loader Class Initialized
INFO - 2022-04-20 13:08:28 --> Helper loaded: url_helper
INFO - 2022-04-20 13:08:28 --> Controller Class Initialized
DEBUG - 2022-04-20 13:08:28 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:08:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:08:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:08:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:08:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:08:28 --> Final output sent to browser
DEBUG - 2022-04-20 13:08:28 --> Total execution time: 0.0193
INFO - 2022-04-20 13:08:28 --> Config Class Initialized
INFO - 2022-04-20 13:08:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:08:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:28 --> Config Class Initialized
INFO - 2022-04-20 13:08:28 --> Hooks Class Initialized
INFO - 2022-04-20 13:08:28 --> URI Class Initialized
DEBUG - 2022-04-20 13:08:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:28 --> Config Class Initialized
INFO - 2022-04-20 13:08:28 --> Hooks Class Initialized
INFO - 2022-04-20 13:08:28 --> Router Class Initialized
INFO - 2022-04-20 13:08:28 --> URI Class Initialized
INFO - 2022-04-20 13:08:28 --> Router Class Initialized
INFO - 2022-04-20 13:08:28 --> Output Class Initialized
INFO - 2022-04-20 13:08:28 --> Output Class Initialized
INFO - 2022-04-20 13:08:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:28 --> Input Class Initialized
INFO - 2022-04-20 13:08:28 --> Language Class Initialized
ERROR - 2022-04-20 13:08:28 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:08:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:28 --> URI Class Initialized
INFO - 2022-04-20 13:08:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:28 --> Input Class Initialized
INFO - 2022-04-20 13:08:28 --> Language Class Initialized
INFO - 2022-04-20 13:08:28 --> Router Class Initialized
ERROR - 2022-04-20 13:08:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:08:28 --> Output Class Initialized
INFO - 2022-04-20 13:08:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:28 --> Input Class Initialized
INFO - 2022-04-20 13:08:28 --> Language Class Initialized
ERROR - 2022-04-20 13:08:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:08:44 --> Config Class Initialized
INFO - 2022-04-20 13:08:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:08:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:44 --> URI Class Initialized
INFO - 2022-04-20 13:08:44 --> Router Class Initialized
INFO - 2022-04-20 13:08:44 --> Output Class Initialized
INFO - 2022-04-20 13:08:44 --> Security Class Initialized
DEBUG - 2022-04-20 13:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:44 --> Input Class Initialized
INFO - 2022-04-20 13:08:44 --> Language Class Initialized
INFO - 2022-04-20 13:08:44 --> Language Class Initialized
INFO - 2022-04-20 13:08:44 --> Config Class Initialized
INFO - 2022-04-20 13:08:44 --> Loader Class Initialized
INFO - 2022-04-20 13:08:44 --> Helper loaded: url_helper
INFO - 2022-04-20 13:08:44 --> Controller Class Initialized
DEBUG - 2022-04-20 13:08:44 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:08:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:08:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:08:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:08:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:08:44 --> Final output sent to browser
DEBUG - 2022-04-20 13:08:44 --> Total execution time: 0.0193
INFO - 2022-04-20 13:08:44 --> Config Class Initialized
INFO - 2022-04-20 13:08:44 --> Config Class Initialized
INFO - 2022-04-20 13:08:44 --> Hooks Class Initialized
INFO - 2022-04-20 13:08:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:08:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:44 --> URI Class Initialized
INFO - 2022-04-20 13:08:44 --> URI Class Initialized
INFO - 2022-04-20 13:08:44 --> Router Class Initialized
INFO - 2022-04-20 13:08:44 --> Output Class Initialized
INFO - 2022-04-20 13:08:44 --> Router Class Initialized
INFO - 2022-04-20 13:08:44 --> Security Class Initialized
INFO - 2022-04-20 13:08:44 --> Config Class Initialized
INFO - 2022-04-20 13:08:44 --> Output Class Initialized
INFO - 2022-04-20 13:08:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:44 --> Input Class Initialized
INFO - 2022-04-20 13:08:44 --> Security Class Initialized
INFO - 2022-04-20 13:08:44 --> Language Class Initialized
DEBUG - 2022-04-20 13:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:44 --> Input Class Initialized
ERROR - 2022-04-20 13:08:44 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:08:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:08:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:08:44 --> Language Class Initialized
INFO - 2022-04-20 13:08:44 --> URI Class Initialized
ERROR - 2022-04-20 13:08:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:08:44 --> Router Class Initialized
INFO - 2022-04-20 13:08:44 --> Output Class Initialized
INFO - 2022-04-20 13:08:44 --> Security Class Initialized
DEBUG - 2022-04-20 13:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:08:44 --> Input Class Initialized
INFO - 2022-04-20 13:08:44 --> Language Class Initialized
ERROR - 2022-04-20 13:08:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Loader Class Initialized
INFO - 2022-04-20 13:10:53 --> Helper loaded: url_helper
INFO - 2022-04-20 13:10:53 --> Controller Class Initialized
DEBUG - 2022-04-20 13:10:53 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:10:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:10:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:10:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:10:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:10:53 --> Final output sent to browser
DEBUG - 2022-04-20 13:10:53 --> Total execution time: 0.0220
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Config Class Initialized
INFO - 2022-04-20 13:10:53 --> Hooks Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
DEBUG - 2022-04-20 13:10:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:10:53 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
INFO - 2022-04-20 13:10:53 --> URI Class Initialized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
INFO - 2022-04-20 13:10:53 --> Router Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:10:53 --> Output Class Initialized
INFO - 2022-04-20 13:10:53 --> Security Class Initialized
DEBUG - 2022-04-20 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:10:53 --> Input Class Initialized
INFO - 2022-04-20 13:10:53 --> Language Class Initialized
ERROR - 2022-04-20 13:10:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:14:52 --> Config Class Initialized
INFO - 2022-04-20 13:14:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:14:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:14:52 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:52 --> URI Class Initialized
INFO - 2022-04-20 13:14:52 --> Router Class Initialized
INFO - 2022-04-20 13:14:52 --> Output Class Initialized
INFO - 2022-04-20 13:14:52 --> Security Class Initialized
DEBUG - 2022-04-20 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:52 --> Input Class Initialized
INFO - 2022-04-20 13:14:52 --> Language Class Initialized
INFO - 2022-04-20 13:14:52 --> Language Class Initialized
INFO - 2022-04-20 13:14:52 --> Config Class Initialized
INFO - 2022-04-20 13:14:52 --> Loader Class Initialized
INFO - 2022-04-20 13:14:52 --> Helper loaded: url_helper
INFO - 2022-04-20 13:14:52 --> Controller Class Initialized
DEBUG - 2022-04-20 13:14:52 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:14:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:14:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:14:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:14:52 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:14:52 --> Final output sent to browser
DEBUG - 2022-04-20 13:14:52 --> Total execution time: 0.0192
INFO - 2022-04-20 13:14:52 --> Config Class Initialized
INFO - 2022-04-20 13:14:52 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:14:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:14:52 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:52 --> Config Class Initialized
INFO - 2022-04-20 13:14:52 --> Hooks Class Initialized
INFO - 2022-04-20 13:14:52 --> URI Class Initialized
DEBUG - 2022-04-20 13:14:52 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:14:52 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:52 --> URI Class Initialized
INFO - 2022-04-20 13:14:52 --> Router Class Initialized
INFO - 2022-04-20 13:14:52 --> Router Class Initialized
INFO - 2022-04-20 13:14:52 --> Output Class Initialized
INFO - 2022-04-20 13:14:52 --> Output Class Initialized
INFO - 2022-04-20 13:14:52 --> Security Class Initialized
INFO - 2022-04-20 13:14:52 --> Security Class Initialized
DEBUG - 2022-04-20 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:52 --> Input Class Initialized
DEBUG - 2022-04-20 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:52 --> Input Class Initialized
INFO - 2022-04-20 13:14:52 --> Language Class Initialized
INFO - 2022-04-20 13:14:52 --> Config Class Initialized
INFO - 2022-04-20 13:14:52 --> Hooks Class Initialized
INFO - 2022-04-20 13:14:52 --> Language Class Initialized
ERROR - 2022-04-20 13:14:52 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:14:52 --> UTF-8 Support Enabled
ERROR - 2022-04-20 13:14:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:14:52 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:52 --> URI Class Initialized
INFO - 2022-04-20 13:14:52 --> Router Class Initialized
INFO - 2022-04-20 13:14:52 --> Output Class Initialized
INFO - 2022-04-20 13:14:52 --> Security Class Initialized
DEBUG - 2022-04-20 13:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:52 --> Input Class Initialized
INFO - 2022-04-20 13:14:52 --> Language Class Initialized
ERROR - 2022-04-20 13:14:52 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:14:59 --> Config Class Initialized
INFO - 2022-04-20 13:14:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:14:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:14:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:59 --> URI Class Initialized
INFO - 2022-04-20 13:14:59 --> Router Class Initialized
INFO - 2022-04-20 13:14:59 --> Output Class Initialized
INFO - 2022-04-20 13:14:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:59 --> Input Class Initialized
INFO - 2022-04-20 13:14:59 --> Language Class Initialized
INFO - 2022-04-20 13:14:59 --> Language Class Initialized
INFO - 2022-04-20 13:14:59 --> Config Class Initialized
INFO - 2022-04-20 13:14:59 --> Loader Class Initialized
INFO - 2022-04-20 13:14:59 --> Helper loaded: url_helper
INFO - 2022-04-20 13:14:59 --> Controller Class Initialized
DEBUG - 2022-04-20 13:14:59 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:14:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:14:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:14:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:14:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:14:59 --> Final output sent to browser
DEBUG - 2022-04-20 13:14:59 --> Total execution time: 0.0190
INFO - 2022-04-20 13:14:59 --> Config Class Initialized
INFO - 2022-04-20 13:14:59 --> Hooks Class Initialized
INFO - 2022-04-20 13:14:59 --> Config Class Initialized
INFO - 2022-04-20 13:14:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:14:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:14:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:59 --> URI Class Initialized
INFO - 2022-04-20 13:14:59 --> URI Class Initialized
INFO - 2022-04-20 13:14:59 --> Router Class Initialized
INFO - 2022-04-20 13:14:59 --> Router Class Initialized
INFO - 2022-04-20 13:14:59 --> Output Class Initialized
INFO - 2022-04-20 13:14:59 --> Security Class Initialized
INFO - 2022-04-20 13:14:59 --> Output Class Initialized
DEBUG - 2022-04-20 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:59 --> Input Class Initialized
INFO - 2022-04-20 13:14:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:59 --> Language Class Initialized
INFO - 2022-04-20 13:14:59 --> Input Class Initialized
INFO - 2022-04-20 13:14:59 --> Config Class Initialized
INFO - 2022-04-20 13:14:59 --> Hooks Class Initialized
INFO - 2022-04-20 13:14:59 --> Language Class Initialized
ERROR - 2022-04-20 13:14:59 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:14:59 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:14:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:14:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:14:59 --> URI Class Initialized
INFO - 2022-04-20 13:14:59 --> Router Class Initialized
INFO - 2022-04-20 13:14:59 --> Output Class Initialized
INFO - 2022-04-20 13:14:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:14:59 --> Input Class Initialized
INFO - 2022-04-20 13:14:59 --> Language Class Initialized
ERROR - 2022-04-20 13:14:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:15:04 --> Config Class Initialized
INFO - 2022-04-20 13:15:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:15:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:15:04 --> URI Class Initialized
INFO - 2022-04-20 13:15:04 --> Router Class Initialized
INFO - 2022-04-20 13:15:04 --> Output Class Initialized
INFO - 2022-04-20 13:15:04 --> Security Class Initialized
DEBUG - 2022-04-20 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:04 --> Input Class Initialized
INFO - 2022-04-20 13:15:04 --> Language Class Initialized
INFO - 2022-04-20 13:15:04 --> Language Class Initialized
INFO - 2022-04-20 13:15:04 --> Config Class Initialized
INFO - 2022-04-20 13:15:04 --> Loader Class Initialized
INFO - 2022-04-20 13:15:04 --> Helper loaded: url_helper
INFO - 2022-04-20 13:15:04 --> Controller Class Initialized
DEBUG - 2022-04-20 13:15:04 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:15:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:15:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:15:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:15:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:15:04 --> Final output sent to browser
DEBUG - 2022-04-20 13:15:04 --> Total execution time: 0.0186
INFO - 2022-04-20 13:15:04 --> Config Class Initialized
INFO - 2022-04-20 13:15:04 --> Hooks Class Initialized
INFO - 2022-04-20 13:15:04 --> Config Class Initialized
INFO - 2022-04-20 13:15:04 --> Hooks Class Initialized
INFO - 2022-04-20 13:15:04 --> Config Class Initialized
INFO - 2022-04-20 13:15:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:15:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:04 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:15:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:15:04 --> URI Class Initialized
DEBUG - 2022-04-20 13:15:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:04 --> URI Class Initialized
INFO - 2022-04-20 13:15:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:15:04 --> URI Class Initialized
INFO - 2022-04-20 13:15:04 --> Router Class Initialized
INFO - 2022-04-20 13:15:04 --> Router Class Initialized
INFO - 2022-04-20 13:15:04 --> Output Class Initialized
INFO - 2022-04-20 13:15:04 --> Router Class Initialized
INFO - 2022-04-20 13:15:04 --> Output Class Initialized
INFO - 2022-04-20 13:15:04 --> Security Class Initialized
INFO - 2022-04-20 13:15:04 --> Security Class Initialized
DEBUG - 2022-04-20 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:04 --> Output Class Initialized
INFO - 2022-04-20 13:15:04 --> Input Class Initialized
INFO - 2022-04-20 13:15:04 --> Language Class Initialized
DEBUG - 2022-04-20 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:04 --> Input Class Initialized
INFO - 2022-04-20 13:15:04 --> Security Class Initialized
INFO - 2022-04-20 13:15:04 --> Language Class Initialized
ERROR - 2022-04-20 13:15:04 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:15:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:15:04 --> Input Class Initialized
INFO - 2022-04-20 13:15:04 --> Language Class Initialized
ERROR - 2022-04-20 13:15:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:15:10 --> Config Class Initialized
INFO - 2022-04-20 13:15:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:15:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:15:10 --> URI Class Initialized
INFO - 2022-04-20 13:15:10 --> Router Class Initialized
INFO - 2022-04-20 13:15:10 --> Output Class Initialized
INFO - 2022-04-20 13:15:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:10 --> Input Class Initialized
INFO - 2022-04-20 13:15:10 --> Language Class Initialized
INFO - 2022-04-20 13:15:10 --> Language Class Initialized
INFO - 2022-04-20 13:15:10 --> Config Class Initialized
INFO - 2022-04-20 13:15:10 --> Loader Class Initialized
INFO - 2022-04-20 13:15:10 --> Helper loaded: url_helper
INFO - 2022-04-20 13:15:10 --> Controller Class Initialized
DEBUG - 2022-04-20 13:15:10 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:15:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:15:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:15:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:15:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:15:10 --> Final output sent to browser
DEBUG - 2022-04-20 13:15:10 --> Total execution time: 0.0210
INFO - 2022-04-20 13:15:10 --> Config Class Initialized
INFO - 2022-04-20 13:15:10 --> Hooks Class Initialized
INFO - 2022-04-20 13:15:10 --> Config Class Initialized
INFO - 2022-04-20 13:15:10 --> Hooks Class Initialized
INFO - 2022-04-20 13:15:10 --> Config Class Initialized
INFO - 2022-04-20 13:15:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:15:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:10 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:15:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:15:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:15:10 --> URI Class Initialized
INFO - 2022-04-20 13:15:10 --> URI Class Initialized
INFO - 2022-04-20 13:15:10 --> Router Class Initialized
INFO - 2022-04-20 13:15:10 --> Router Class Initialized
INFO - 2022-04-20 13:15:10 --> Output Class Initialized
INFO - 2022-04-20 13:15:10 --> Output Class Initialized
INFO - 2022-04-20 13:15:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:10 --> Security Class Initialized
INFO - 2022-04-20 13:15:10 --> Input Class Initialized
INFO - 2022-04-20 13:15:10 --> Language Class Initialized
DEBUG - 2022-04-20 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:10 --> Input Class Initialized
ERROR - 2022-04-20 13:15:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:15:10 --> Language Class Initialized
DEBUG - 2022-04-20 13:15:10 --> UTF-8 Support Enabled
ERROR - 2022-04-20 13:15:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:15:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:15:10 --> URI Class Initialized
INFO - 2022-04-20 13:15:10 --> Router Class Initialized
INFO - 2022-04-20 13:15:10 --> Output Class Initialized
INFO - 2022-04-20 13:15:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:15:10 --> Input Class Initialized
INFO - 2022-04-20 13:15:10 --> Language Class Initialized
ERROR - 2022-04-20 13:15:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:23:18 --> Config Class Initialized
INFO - 2022-04-20 13:23:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:23:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:23:18 --> URI Class Initialized
INFO - 2022-04-20 13:23:18 --> Router Class Initialized
INFO - 2022-04-20 13:23:18 --> Output Class Initialized
INFO - 2022-04-20 13:23:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:23:18 --> Input Class Initialized
INFO - 2022-04-20 13:23:18 --> Language Class Initialized
INFO - 2022-04-20 13:23:18 --> Language Class Initialized
INFO - 2022-04-20 13:23:18 --> Config Class Initialized
INFO - 2022-04-20 13:23:18 --> Loader Class Initialized
INFO - 2022-04-20 13:23:18 --> Helper loaded: url_helper
INFO - 2022-04-20 13:23:18 --> Controller Class Initialized
DEBUG - 2022-04-20 13:23:18 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:23:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:23:18 --> Final output sent to browser
DEBUG - 2022-04-20 13:23:18 --> Total execution time: 0.0199
INFO - 2022-04-20 13:23:18 --> Config Class Initialized
INFO - 2022-04-20 13:23:18 --> Hooks Class Initialized
INFO - 2022-04-20 13:23:18 --> Config Class Initialized
INFO - 2022-04-20 13:23:18 --> Hooks Class Initialized
INFO - 2022-04-20 13:23:18 --> Config Class Initialized
INFO - 2022-04-20 13:23:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:23:18 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:23:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:23:18 --> URI Class Initialized
DEBUG - 2022-04-20 13:23:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:23:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:23:18 --> URI Class Initialized
INFO - 2022-04-20 13:23:18 --> Router Class Initialized
INFO - 2022-04-20 13:23:18 --> Output Class Initialized
INFO - 2022-04-20 13:23:18 --> Router Class Initialized
INFO - 2022-04-20 13:23:18 --> Security Class Initialized
INFO - 2022-04-20 13:23:18 --> URI Class Initialized
INFO - 2022-04-20 13:23:18 --> Output Class Initialized
DEBUG - 2022-04-20 13:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:23:18 --> Input Class Initialized
INFO - 2022-04-20 13:23:18 --> Security Class Initialized
INFO - 2022-04-20 13:23:18 --> Language Class Initialized
INFO - 2022-04-20 13:23:18 --> Router Class Initialized
DEBUG - 2022-04-20 13:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:23:18 --> Input Class Initialized
ERROR - 2022-04-20 13:23:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:23:18 --> Language Class Initialized
ERROR - 2022-04-20 13:23:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:23:18 --> Output Class Initialized
INFO - 2022-04-20 13:23:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:23:18 --> Input Class Initialized
INFO - 2022-04-20 13:23:18 --> Language Class Initialized
ERROR - 2022-04-20 13:23:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:04 --> Config Class Initialized
INFO - 2022-04-20 13:24:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:04 --> URI Class Initialized
INFO - 2022-04-20 13:24:04 --> Router Class Initialized
INFO - 2022-04-20 13:24:04 --> Output Class Initialized
INFO - 2022-04-20 13:24:04 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:04 --> Input Class Initialized
INFO - 2022-04-20 13:24:04 --> Language Class Initialized
INFO - 2022-04-20 13:24:04 --> Language Class Initialized
INFO - 2022-04-20 13:24:04 --> Config Class Initialized
INFO - 2022-04-20 13:24:04 --> Loader Class Initialized
INFO - 2022-04-20 13:24:04 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:04 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:04 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:24:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:24:04 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:04 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:04 --> Total execution time: 0.0188
INFO - 2022-04-20 13:24:04 --> Config Class Initialized
INFO - 2022-04-20 13:24:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:04 --> Config Class Initialized
INFO - 2022-04-20 13:24:04 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:04 --> URI Class Initialized
DEBUG - 2022-04-20 13:24:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:04 --> Router Class Initialized
INFO - 2022-04-20 13:24:04 --> URI Class Initialized
INFO - 2022-04-20 13:24:04 --> Output Class Initialized
INFO - 2022-04-20 13:24:04 --> Security Class Initialized
INFO - 2022-04-20 13:24:04 --> Router Class Initialized
DEBUG - 2022-04-20 13:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:04 --> Input Class Initialized
INFO - 2022-04-20 13:24:04 --> Output Class Initialized
INFO - 2022-04-20 13:24:04 --> Language Class Initialized
INFO - 2022-04-20 13:24:04 --> Security Class Initialized
ERROR - 2022-04-20 13:24:04 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:04 --> Input Class Initialized
INFO - 2022-04-20 13:24:04 --> Language Class Initialized
ERROR - 2022-04-20 13:24:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:04 --> Config Class Initialized
INFO - 2022-04-20 13:24:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:04 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:04 --> URI Class Initialized
INFO - 2022-04-20 13:24:04 --> Router Class Initialized
INFO - 2022-04-20 13:24:04 --> Output Class Initialized
INFO - 2022-04-20 13:24:04 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:04 --> Input Class Initialized
INFO - 2022-04-20 13:24:04 --> Language Class Initialized
ERROR - 2022-04-20 13:24:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:07 --> Config Class Initialized
INFO - 2022-04-20 13:24:07 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:07 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:07 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:07 --> URI Class Initialized
DEBUG - 2022-04-20 13:24:07 --> No URI present. Default controller set.
INFO - 2022-04-20 13:24:07 --> Router Class Initialized
INFO - 2022-04-20 13:24:07 --> Output Class Initialized
INFO - 2022-04-20 13:24:07 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:07 --> Input Class Initialized
INFO - 2022-04-20 13:24:07 --> Language Class Initialized
INFO - 2022-04-20 13:24:07 --> Language Class Initialized
INFO - 2022-04-20 13:24:07 --> Config Class Initialized
INFO - 2022-04-20 13:24:07 --> Loader Class Initialized
INFO - 2022-04-20 13:24:07 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:07 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:07 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:24:07 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:07 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:07 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:24:07 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:07 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:07 --> Total execution time: 0.0186
INFO - 2022-04-20 13:24:07 --> Config Class Initialized
INFO - 2022-04-20 13:24:07 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:07 --> Config Class Initialized
INFO - 2022-04-20 13:24:07 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:07 --> Config Class Initialized
INFO - 2022-04-20 13:24:07 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:24:07 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:07 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:07 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:24:07 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:07 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:07 --> URI Class Initialized
INFO - 2022-04-20 13:24:07 --> URI Class Initialized
INFO - 2022-04-20 13:24:07 --> URI Class Initialized
INFO - 2022-04-20 13:24:07 --> Router Class Initialized
INFO - 2022-04-20 13:24:07 --> Router Class Initialized
INFO - 2022-04-20 13:24:07 --> Output Class Initialized
INFO - 2022-04-20 13:24:07 --> Output Class Initialized
INFO - 2022-04-20 13:24:07 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:07 --> Security Class Initialized
INFO - 2022-04-20 13:24:07 --> Input Class Initialized
INFO - 2022-04-20 13:24:07 --> Language Class Initialized
DEBUG - 2022-04-20 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:07 --> Input Class Initialized
ERROR - 2022-04-20 13:24:07 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:07 --> Language Class Initialized
ERROR - 2022-04-20 13:24:07 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:07 --> Router Class Initialized
INFO - 2022-04-20 13:24:07 --> Output Class Initialized
INFO - 2022-04-20 13:24:07 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:07 --> Input Class Initialized
INFO - 2022-04-20 13:24:07 --> Language Class Initialized
ERROR - 2022-04-20 13:24:07 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:18 --> Config Class Initialized
INFO - 2022-04-20 13:24:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:18 --> URI Class Initialized
INFO - 2022-04-20 13:24:18 --> Router Class Initialized
INFO - 2022-04-20 13:24:18 --> Output Class Initialized
INFO - 2022-04-20 13:24:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:18 --> Input Class Initialized
INFO - 2022-04-20 13:24:18 --> Language Class Initialized
INFO - 2022-04-20 13:24:18 --> Language Class Initialized
INFO - 2022-04-20 13:24:18 --> Config Class Initialized
INFO - 2022-04-20 13:24:18 --> Loader Class Initialized
INFO - 2022-04-20 13:24:18 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:18 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:18 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:24:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:24:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:18 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:18 --> Total execution time: 0.0199
INFO - 2022-04-20 13:24:18 --> Config Class Initialized
INFO - 2022-04-20 13:24:18 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:18 --> Config Class Initialized
INFO - 2022-04-20 13:24:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:18 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:24:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:18 --> URI Class Initialized
INFO - 2022-04-20 13:24:18 --> URI Class Initialized
INFO - 2022-04-20 13:24:18 --> Router Class Initialized
INFO - 2022-04-20 13:24:18 --> Router Class Initialized
INFO - 2022-04-20 13:24:18 --> Output Class Initialized
INFO - 2022-04-20 13:24:18 --> Output Class Initialized
INFO - 2022-04-20 13:24:18 --> Config Class Initialized
INFO - 2022-04-20 13:24:18 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:18 --> Security Class Initialized
INFO - 2022-04-20 13:24:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:18 --> Input Class Initialized
INFO - 2022-04-20 13:24:18 --> Input Class Initialized
INFO - 2022-04-20 13:24:18 --> Language Class Initialized
INFO - 2022-04-20 13:24:18 --> Language Class Initialized
ERROR - 2022-04-20 13:24:18 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:24:18 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:24:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:18 --> URI Class Initialized
INFO - 2022-04-20 13:24:19 --> Router Class Initialized
INFO - 2022-04-20 13:24:19 --> Output Class Initialized
INFO - 2022-04-20 13:24:19 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:19 --> Input Class Initialized
INFO - 2022-04-20 13:24:19 --> Language Class Initialized
ERROR - 2022-04-20 13:24:19 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:23 --> Config Class Initialized
INFO - 2022-04-20 13:24:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:23 --> URI Class Initialized
INFO - 2022-04-20 13:24:23 --> Router Class Initialized
INFO - 2022-04-20 13:24:23 --> Output Class Initialized
INFO - 2022-04-20 13:24:23 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:23 --> Input Class Initialized
INFO - 2022-04-20 13:24:23 --> Language Class Initialized
INFO - 2022-04-20 13:24:23 --> Language Class Initialized
INFO - 2022-04-20 13:24:23 --> Config Class Initialized
INFO - 2022-04-20 13:24:23 --> Loader Class Initialized
INFO - 2022-04-20 13:24:23 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:23 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:23 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:24:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:24:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:23 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:23 --> Total execution time: 0.0190
INFO - 2022-04-20 13:24:23 --> Config Class Initialized
INFO - 2022-04-20 13:24:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:23 --> URI Class Initialized
INFO - 2022-04-20 13:24:23 --> Config Class Initialized
INFO - 2022-04-20 13:24:23 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:23 --> Router Class Initialized
INFO - 2022-04-20 13:24:23 --> Output Class Initialized
DEBUG - 2022-04-20 13:24:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:23 --> Security Class Initialized
INFO - 2022-04-20 13:24:23 --> URI Class Initialized
DEBUG - 2022-04-20 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:23 --> Input Class Initialized
INFO - 2022-04-20 13:24:23 --> Router Class Initialized
INFO - 2022-04-20 13:24:23 --> Language Class Initialized
ERROR - 2022-04-20 13:24:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:23 --> Output Class Initialized
INFO - 2022-04-20 13:24:23 --> Security Class Initialized
INFO - 2022-04-20 13:24:23 --> Config Class Initialized
INFO - 2022-04-20 13:24:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:23 --> Input Class Initialized
INFO - 2022-04-20 13:24:23 --> Language Class Initialized
ERROR - 2022-04-20 13:24:23 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:24:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:23 --> URI Class Initialized
INFO - 2022-04-20 13:24:23 --> Router Class Initialized
INFO - 2022-04-20 13:24:23 --> Output Class Initialized
INFO - 2022-04-20 13:24:23 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:23 --> Input Class Initialized
INFO - 2022-04-20 13:24:23 --> Language Class Initialized
ERROR - 2022-04-20 13:24:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:26 --> Config Class Initialized
INFO - 2022-04-20 13:24:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:26 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:26 --> URI Class Initialized
INFO - 2022-04-20 13:24:26 --> Router Class Initialized
INFO - 2022-04-20 13:24:26 --> Output Class Initialized
INFO - 2022-04-20 13:24:26 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:26 --> Input Class Initialized
INFO - 2022-04-20 13:24:26 --> Language Class Initialized
INFO - 2022-04-20 13:24:26 --> Language Class Initialized
INFO - 2022-04-20 13:24:26 --> Config Class Initialized
INFO - 2022-04-20 13:24:26 --> Loader Class Initialized
INFO - 2022-04-20 13:24:26 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:26 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:26 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:24:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:24:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:26 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:26 --> Total execution time: 0.0208
INFO - 2022-04-20 13:24:26 --> Config Class Initialized
INFO - 2022-04-20 13:24:26 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:26 --> Config Class Initialized
INFO - 2022-04-20 13:24:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:26 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:24:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:26 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:26 --> URI Class Initialized
INFO - 2022-04-20 13:24:26 --> URI Class Initialized
INFO - 2022-04-20 13:24:26 --> Router Class Initialized
INFO - 2022-04-20 13:24:26 --> Router Class Initialized
INFO - 2022-04-20 13:24:26 --> Output Class Initialized
INFO - 2022-04-20 13:24:26 --> Output Class Initialized
INFO - 2022-04-20 13:24:26 --> Security Class Initialized
INFO - 2022-04-20 13:24:26 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:26 --> Input Class Initialized
DEBUG - 2022-04-20 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:26 --> Input Class Initialized
INFO - 2022-04-20 13:24:26 --> Config Class Initialized
INFO - 2022-04-20 13:24:26 --> Language Class Initialized
INFO - 2022-04-20 13:24:26 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:26 --> Language Class Initialized
ERROR - 2022-04-20 13:24:26 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:24:26 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:24:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:26 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:26 --> URI Class Initialized
INFO - 2022-04-20 13:24:26 --> Router Class Initialized
INFO - 2022-04-20 13:24:26 --> Output Class Initialized
INFO - 2022-04-20 13:24:26 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:26 --> Input Class Initialized
INFO - 2022-04-20 13:24:26 --> Language Class Initialized
ERROR - 2022-04-20 13:24:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:27 --> Config Class Initialized
INFO - 2022-04-20 13:24:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:27 --> URI Class Initialized
INFO - 2022-04-20 13:24:27 --> Router Class Initialized
INFO - 2022-04-20 13:24:27 --> Output Class Initialized
INFO - 2022-04-20 13:24:27 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:27 --> Input Class Initialized
INFO - 2022-04-20 13:24:27 --> Language Class Initialized
INFO - 2022-04-20 13:24:27 --> Language Class Initialized
INFO - 2022-04-20 13:24:27 --> Config Class Initialized
INFO - 2022-04-20 13:24:27 --> Loader Class Initialized
INFO - 2022-04-20 13:24:27 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:27 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:27 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:24:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:24:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:27 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:27 --> Total execution time: 0.0186
INFO - 2022-04-20 13:24:27 --> Config Class Initialized
INFO - 2022-04-20 13:24:27 --> Config Class Initialized
INFO - 2022-04-20 13:24:27 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:24:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:27 --> URI Class Initialized
INFO - 2022-04-20 13:24:27 --> URI Class Initialized
INFO - 2022-04-20 13:24:27 --> Config Class Initialized
INFO - 2022-04-20 13:24:27 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:27 --> Router Class Initialized
INFO - 2022-04-20 13:24:27 --> Router Class Initialized
DEBUG - 2022-04-20 13:24:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:27 --> Output Class Initialized
INFO - 2022-04-20 13:24:27 --> Output Class Initialized
INFO - 2022-04-20 13:24:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:27 --> Security Class Initialized
INFO - 2022-04-20 13:24:27 --> URI Class Initialized
INFO - 2022-04-20 13:24:27 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:27 --> Input Class Initialized
DEBUG - 2022-04-20 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:27 --> Input Class Initialized
INFO - 2022-04-20 13:24:27 --> Language Class Initialized
INFO - 2022-04-20 13:24:27 --> Router Class Initialized
ERROR - 2022-04-20 13:24:27 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:27 --> Output Class Initialized
INFO - 2022-04-20 13:24:27 --> Language Class Initialized
INFO - 2022-04-20 13:24:27 --> Security Class Initialized
ERROR - 2022-04-20 13:24:27 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:27 --> Input Class Initialized
INFO - 2022-04-20 13:24:27 --> Language Class Initialized
ERROR - 2022-04-20 13:24:27 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:28 --> Config Class Initialized
INFO - 2022-04-20 13:24:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:28 --> URI Class Initialized
DEBUG - 2022-04-20 13:24:28 --> No URI present. Default controller set.
INFO - 2022-04-20 13:24:28 --> Router Class Initialized
INFO - 2022-04-20 13:24:28 --> Output Class Initialized
INFO - 2022-04-20 13:24:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:28 --> Input Class Initialized
INFO - 2022-04-20 13:24:28 --> Language Class Initialized
INFO - 2022-04-20 13:24:28 --> Language Class Initialized
INFO - 2022-04-20 13:24:28 --> Config Class Initialized
INFO - 2022-04-20 13:24:28 --> Loader Class Initialized
INFO - 2022-04-20 13:24:28 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:28 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:28 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:24:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:24:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:28 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:28 --> Total execution time: 0.0189
INFO - 2022-04-20 13:24:28 --> Config Class Initialized
INFO - 2022-04-20 13:24:28 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:28 --> Config Class Initialized
INFO - 2022-04-20 13:24:28 --> Config Class Initialized
INFO - 2022-04-20 13:24:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:28 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:24:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:28 --> URI Class Initialized
INFO - 2022-04-20 13:24:28 --> URI Class Initialized
INFO - 2022-04-20 13:24:28 --> Router Class Initialized
INFO - 2022-04-20 13:24:28 --> Router Class Initialized
INFO - 2022-04-20 13:24:28 --> Output Class Initialized
INFO - 2022-04-20 13:24:28 --> Output Class Initialized
INFO - 2022-04-20 13:24:28 --> Security Class Initialized
INFO - 2022-04-20 13:24:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:28 --> Input Class Initialized
INFO - 2022-04-20 13:24:28 --> Language Class Initialized
DEBUG - 2022-04-20 13:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:28 --> Input Class Initialized
INFO - 2022-04-20 13:24:28 --> Language Class Initialized
ERROR - 2022-04-20 13:24:28 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:24:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:28 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:28 --> URI Class Initialized
INFO - 2022-04-20 13:24:28 --> Router Class Initialized
INFO - 2022-04-20 13:24:28 --> Output Class Initialized
INFO - 2022-04-20 13:24:28 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:28 --> Input Class Initialized
INFO - 2022-04-20 13:24:28 --> Language Class Initialized
ERROR - 2022-04-20 13:24:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:56 --> Config Class Initialized
INFO - 2022-04-20 13:24:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:56 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:56 --> URI Class Initialized
DEBUG - 2022-04-20 13:24:56 --> No URI present. Default controller set.
INFO - 2022-04-20 13:24:56 --> Router Class Initialized
INFO - 2022-04-20 13:24:56 --> Output Class Initialized
INFO - 2022-04-20 13:24:56 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:56 --> Input Class Initialized
INFO - 2022-04-20 13:24:56 --> Language Class Initialized
INFO - 2022-04-20 13:24:56 --> Language Class Initialized
INFO - 2022-04-20 13:24:56 --> Config Class Initialized
INFO - 2022-04-20 13:24:56 --> Loader Class Initialized
INFO - 2022-04-20 13:24:56 --> Helper loaded: url_helper
INFO - 2022-04-20 13:24:56 --> Controller Class Initialized
DEBUG - 2022-04-20 13:24:56 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:24:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:24:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:24:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:24:56 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:24:56 --> Final output sent to browser
DEBUG - 2022-04-20 13:24:56 --> Total execution time: 0.0197
INFO - 2022-04-20 13:24:56 --> Config Class Initialized
INFO - 2022-04-20 13:24:56 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:24:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:56 --> Config Class Initialized
INFO - 2022-04-20 13:24:56 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:56 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:56 --> URI Class Initialized
INFO - 2022-04-20 13:24:56 --> Config Class Initialized
INFO - 2022-04-20 13:24:56 --> Hooks Class Initialized
INFO - 2022-04-20 13:24:56 --> Router Class Initialized
DEBUG - 2022-04-20 13:24:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:56 --> Output Class Initialized
INFO - 2022-04-20 13:24:56 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:56 --> URI Class Initialized
INFO - 2022-04-20 13:24:56 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:56 --> Input Class Initialized
INFO - 2022-04-20 13:24:56 --> Language Class Initialized
INFO - 2022-04-20 13:24:56 --> Router Class Initialized
ERROR - 2022-04-20 13:24:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:56 --> Output Class Initialized
DEBUG - 2022-04-20 13:24:56 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:24:56 --> Utf8 Class Initialized
INFO - 2022-04-20 13:24:56 --> Security Class Initialized
INFO - 2022-04-20 13:24:56 --> URI Class Initialized
DEBUG - 2022-04-20 13:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:56 --> Input Class Initialized
INFO - 2022-04-20 13:24:56 --> Language Class Initialized
ERROR - 2022-04-20 13:24:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:24:56 --> Router Class Initialized
INFO - 2022-04-20 13:24:56 --> Output Class Initialized
INFO - 2022-04-20 13:24:56 --> Security Class Initialized
DEBUG - 2022-04-20 13:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:24:56 --> Input Class Initialized
INFO - 2022-04-20 13:24:56 --> Language Class Initialized
ERROR - 2022-04-20 13:24:56 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:25:27 --> Config Class Initialized
INFO - 2022-04-20 13:25:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:25:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:25:27 --> URI Class Initialized
INFO - 2022-04-20 13:25:27 --> Router Class Initialized
INFO - 2022-04-20 13:25:27 --> Output Class Initialized
INFO - 2022-04-20 13:25:27 --> Security Class Initialized
DEBUG - 2022-04-20 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:27 --> Input Class Initialized
INFO - 2022-04-20 13:25:27 --> Language Class Initialized
INFO - 2022-04-20 13:25:27 --> Language Class Initialized
INFO - 2022-04-20 13:25:27 --> Config Class Initialized
INFO - 2022-04-20 13:25:27 --> Loader Class Initialized
INFO - 2022-04-20 13:25:27 --> Helper loaded: url_helper
INFO - 2022-04-20 13:25:27 --> Controller Class Initialized
DEBUG - 2022-04-20 13:25:27 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:25:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:25:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:25:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:25:27 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:25:27 --> Final output sent to browser
DEBUG - 2022-04-20 13:25:27 --> Total execution time: 0.0210
INFO - 2022-04-20 13:25:27 --> Config Class Initialized
INFO - 2022-04-20 13:25:27 --> Hooks Class Initialized
INFO - 2022-04-20 13:25:27 --> Config Class Initialized
INFO - 2022-04-20 13:25:27 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:25:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:25:27 --> Utf8 Class Initialized
INFO - 2022-04-20 13:25:27 --> URI Class Initialized
INFO - 2022-04-20 13:25:27 --> URI Class Initialized
INFO - 2022-04-20 13:25:27 --> Config Class Initialized
INFO - 2022-04-20 13:25:27 --> Router Class Initialized
INFO - 2022-04-20 13:25:27 --> Router Class Initialized
INFO - 2022-04-20 13:25:27 --> Hooks Class Initialized
INFO - 2022-04-20 13:25:27 --> Output Class Initialized
INFO - 2022-04-20 13:25:27 --> Output Class Initialized
INFO - 2022-04-20 13:25:27 --> Security Class Initialized
DEBUG - 2022-04-20 13:25:27 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:27 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:27 --> Input Class Initialized
INFO - 2022-04-20 13:25:27 --> URI Class Initialized
INFO - 2022-04-20 13:25:27 --> Language Class Initialized
INFO - 2022-04-20 13:25:27 --> Router Class Initialized
ERROR - 2022-04-20 13:25:27 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:25:27 --> Security Class Initialized
INFO - 2022-04-20 13:25:27 --> Output Class Initialized
DEBUG - 2022-04-20 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:27 --> Security Class Initialized
INFO - 2022-04-20 13:25:27 --> Input Class Initialized
INFO - 2022-04-20 13:25:27 --> Language Class Initialized
DEBUG - 2022-04-20 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:27 --> Input Class Initialized
ERROR - 2022-04-20 13:25:27 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:25:27 --> Language Class Initialized
ERROR - 2022-04-20 13:25:27 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:25:33 --> Config Class Initialized
INFO - 2022-04-20 13:25:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:25:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:33 --> Utf8 Class Initialized
INFO - 2022-04-20 13:25:33 --> URI Class Initialized
DEBUG - 2022-04-20 13:25:33 --> No URI present. Default controller set.
INFO - 2022-04-20 13:25:33 --> Router Class Initialized
INFO - 2022-04-20 13:25:33 --> Output Class Initialized
INFO - 2022-04-20 13:25:33 --> Security Class Initialized
DEBUG - 2022-04-20 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:33 --> Input Class Initialized
INFO - 2022-04-20 13:25:33 --> Language Class Initialized
INFO - 2022-04-20 13:25:33 --> Language Class Initialized
INFO - 2022-04-20 13:25:33 --> Config Class Initialized
INFO - 2022-04-20 13:25:33 --> Loader Class Initialized
INFO - 2022-04-20 13:25:33 --> Helper loaded: url_helper
INFO - 2022-04-20 13:25:33 --> Controller Class Initialized
DEBUG - 2022-04-20 13:25:33 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:25:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:25:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:25:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:25:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:25:33 --> Final output sent to browser
DEBUG - 2022-04-20 13:25:33 --> Total execution time: 0.0212
INFO - 2022-04-20 13:25:33 --> Config Class Initialized
INFO - 2022-04-20 13:25:33 --> Config Class Initialized
INFO - 2022-04-20 13:25:33 --> Hooks Class Initialized
INFO - 2022-04-20 13:25:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:25:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:33 --> Utf8 Class Initialized
INFO - 2022-04-20 13:25:33 --> URI Class Initialized
INFO - 2022-04-20 13:25:33 --> Config Class Initialized
INFO - 2022-04-20 13:25:33 --> Hooks Class Initialized
INFO - 2022-04-20 13:25:33 --> Router Class Initialized
INFO - 2022-04-20 13:25:33 --> Output Class Initialized
DEBUG - 2022-04-20 13:25:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:33 --> Utf8 Class Initialized
INFO - 2022-04-20 13:25:33 --> Security Class Initialized
INFO - 2022-04-20 13:25:33 --> URI Class Initialized
DEBUG - 2022-04-20 13:25:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:25:33 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:33 --> Input Class Initialized
INFO - 2022-04-20 13:25:33 --> URI Class Initialized
INFO - 2022-04-20 13:25:33 --> Language Class Initialized
INFO - 2022-04-20 13:25:33 --> Router Class Initialized
ERROR - 2022-04-20 13:25:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:25:33 --> Output Class Initialized
INFO - 2022-04-20 13:25:33 --> Router Class Initialized
INFO - 2022-04-20 13:25:33 --> Security Class Initialized
INFO - 2022-04-20 13:25:33 --> Output Class Initialized
DEBUG - 2022-04-20 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:33 --> Input Class Initialized
INFO - 2022-04-20 13:25:33 --> Security Class Initialized
INFO - 2022-04-20 13:25:33 --> Language Class Initialized
ERROR - 2022-04-20 13:25:33 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:25:33 --> Input Class Initialized
INFO - 2022-04-20 13:25:33 --> Language Class Initialized
ERROR - 2022-04-20 13:25:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:34 --> Config Class Initialized
INFO - 2022-04-20 13:26:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:34 --> URI Class Initialized
DEBUG - 2022-04-20 13:26:34 --> No URI present. Default controller set.
INFO - 2022-04-20 13:26:34 --> Router Class Initialized
INFO - 2022-04-20 13:26:34 --> Output Class Initialized
INFO - 2022-04-20 13:26:34 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:34 --> Input Class Initialized
INFO - 2022-04-20 13:26:34 --> Language Class Initialized
INFO - 2022-04-20 13:26:34 --> Language Class Initialized
INFO - 2022-04-20 13:26:34 --> Config Class Initialized
INFO - 2022-04-20 13:26:34 --> Loader Class Initialized
INFO - 2022-04-20 13:26:34 --> Helper loaded: url_helper
INFO - 2022-04-20 13:26:34 --> Controller Class Initialized
DEBUG - 2022-04-20 13:26:34 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:26:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:26:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:26:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:26:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:26:34 --> Final output sent to browser
DEBUG - 2022-04-20 13:26:34 --> Total execution time: 0.0189
INFO - 2022-04-20 13:26:34 --> Config Class Initialized
INFO - 2022-04-20 13:26:34 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:34 --> Config Class Initialized
INFO - 2022-04-20 13:26:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:34 --> Config Class Initialized
INFO - 2022-04-20 13:26:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:34 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:34 --> URI Class Initialized
DEBUG - 2022-04-20 13:26:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:34 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:26:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:34 --> URI Class Initialized
INFO - 2022-04-20 13:26:34 --> Router Class Initialized
INFO - 2022-04-20 13:26:34 --> URI Class Initialized
INFO - 2022-04-20 13:26:34 --> Output Class Initialized
INFO - 2022-04-20 13:26:34 --> Router Class Initialized
INFO - 2022-04-20 13:26:34 --> Security Class Initialized
INFO - 2022-04-20 13:26:34 --> Router Class Initialized
INFO - 2022-04-20 13:26:34 --> Output Class Initialized
DEBUG - 2022-04-20 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:34 --> Input Class Initialized
INFO - 2022-04-20 13:26:34 --> Security Class Initialized
INFO - 2022-04-20 13:26:34 --> Output Class Initialized
INFO - 2022-04-20 13:26:34 --> Language Class Initialized
DEBUG - 2022-04-20 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:34 --> Input Class Initialized
INFO - 2022-04-20 13:26:34 --> Security Class Initialized
ERROR - 2022-04-20 13:26:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:34 --> Language Class Initialized
ERROR - 2022-04-20 13:26:34 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:34 --> Input Class Initialized
INFO - 2022-04-20 13:26:34 --> Language Class Initialized
ERROR - 2022-04-20 13:26:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:38 --> Config Class Initialized
INFO - 2022-04-20 13:26:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:38 --> URI Class Initialized
INFO - 2022-04-20 13:26:38 --> Router Class Initialized
INFO - 2022-04-20 13:26:38 --> Output Class Initialized
INFO - 2022-04-20 13:26:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:38 --> Input Class Initialized
INFO - 2022-04-20 13:26:38 --> Language Class Initialized
INFO - 2022-04-20 13:26:38 --> Language Class Initialized
INFO - 2022-04-20 13:26:38 --> Config Class Initialized
INFO - 2022-04-20 13:26:38 --> Loader Class Initialized
INFO - 2022-04-20 13:26:38 --> Helper loaded: url_helper
INFO - 2022-04-20 13:26:38 --> Controller Class Initialized
DEBUG - 2022-04-20 13:26:38 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:26:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:26:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:26:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:26:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:26:38 --> Final output sent to browser
DEBUG - 2022-04-20 13:26:38 --> Total execution time: 0.0185
INFO - 2022-04-20 13:26:38 --> Config Class Initialized
INFO - 2022-04-20 13:26:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:38 --> Config Class Initialized
INFO - 2022-04-20 13:26:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:38 --> Config Class Initialized
INFO - 2022-04-20 13:26:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:38 --> URI Class Initialized
INFO - 2022-04-20 13:26:38 --> URI Class Initialized
INFO - 2022-04-20 13:26:38 --> Router Class Initialized
INFO - 2022-04-20 13:26:38 --> Router Class Initialized
INFO - 2022-04-20 13:26:38 --> Output Class Initialized
INFO - 2022-04-20 13:26:38 --> Output Class Initialized
INFO - 2022-04-20 13:26:38 --> Security Class Initialized
INFO - 2022-04-20 13:26:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:38 --> Input Class Initialized
DEBUG - 2022-04-20 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:38 --> Language Class Initialized
INFO - 2022-04-20 13:26:38 --> Input Class Initialized
INFO - 2022-04-20 13:26:38 --> Language Class Initialized
ERROR - 2022-04-20 13:26:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:26:38 --> UTF-8 Support Enabled
ERROR - 2022-04-20 13:26:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:38 --> URI Class Initialized
INFO - 2022-04-20 13:26:38 --> Router Class Initialized
INFO - 2022-04-20 13:26:38 --> Output Class Initialized
INFO - 2022-04-20 13:26:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:38 --> Input Class Initialized
INFO - 2022-04-20 13:26:38 --> Language Class Initialized
ERROR - 2022-04-20 13:26:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:41 --> Config Class Initialized
INFO - 2022-04-20 13:26:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:41 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:41 --> URI Class Initialized
INFO - 2022-04-20 13:26:41 --> Router Class Initialized
INFO - 2022-04-20 13:26:41 --> Output Class Initialized
INFO - 2022-04-20 13:26:41 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:41 --> Input Class Initialized
INFO - 2022-04-20 13:26:41 --> Language Class Initialized
INFO - 2022-04-20 13:26:41 --> Language Class Initialized
INFO - 2022-04-20 13:26:41 --> Config Class Initialized
INFO - 2022-04-20 13:26:41 --> Loader Class Initialized
INFO - 2022-04-20 13:26:41 --> Helper loaded: url_helper
INFO - 2022-04-20 13:26:41 --> Controller Class Initialized
DEBUG - 2022-04-20 13:26:41 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:26:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:26:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:26:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:26:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:26:41 --> Final output sent to browser
DEBUG - 2022-04-20 13:26:41 --> Total execution time: 0.0200
INFO - 2022-04-20 13:26:41 --> Config Class Initialized
INFO - 2022-04-20 13:26:41 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:41 --> Config Class Initialized
INFO - 2022-04-20 13:26:41 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:41 --> Config Class Initialized
INFO - 2022-04-20 13:26:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:41 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:26:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:41 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:41 --> URI Class Initialized
INFO - 2022-04-20 13:26:41 --> URI Class Initialized
DEBUG - 2022-04-20 13:26:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:41 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:41 --> URI Class Initialized
INFO - 2022-04-20 13:26:41 --> Router Class Initialized
INFO - 2022-04-20 13:26:41 --> Router Class Initialized
INFO - 2022-04-20 13:26:41 --> Output Class Initialized
INFO - 2022-04-20 13:26:41 --> Router Class Initialized
INFO - 2022-04-20 13:26:41 --> Output Class Initialized
INFO - 2022-04-20 13:26:41 --> Security Class Initialized
INFO - 2022-04-20 13:26:41 --> Output Class Initialized
INFO - 2022-04-20 13:26:41 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:41 --> Input Class Initialized
INFO - 2022-04-20 13:26:41 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:41 --> Input Class Initialized
DEBUG - 2022-04-20 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:41 --> Input Class Initialized
INFO - 2022-04-20 13:26:41 --> Language Class Initialized
INFO - 2022-04-20 13:26:41 --> Language Class Initialized
INFO - 2022-04-20 13:26:41 --> Language Class Initialized
ERROR - 2022-04-20 13:26:41 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:26:41 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:26:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:44 --> Config Class Initialized
INFO - 2022-04-20 13:26:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:44 --> URI Class Initialized
INFO - 2022-04-20 13:26:44 --> Router Class Initialized
INFO - 2022-04-20 13:26:44 --> Output Class Initialized
INFO - 2022-04-20 13:26:44 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:44 --> Input Class Initialized
INFO - 2022-04-20 13:26:44 --> Language Class Initialized
INFO - 2022-04-20 13:26:44 --> Language Class Initialized
INFO - 2022-04-20 13:26:44 --> Config Class Initialized
INFO - 2022-04-20 13:26:44 --> Loader Class Initialized
INFO - 2022-04-20 13:26:44 --> Helper loaded: url_helper
INFO - 2022-04-20 13:26:44 --> Controller Class Initialized
DEBUG - 2022-04-20 13:26:44 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:26:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:26:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:26:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:26:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:26:44 --> Final output sent to browser
DEBUG - 2022-04-20 13:26:44 --> Total execution time: 0.0193
INFO - 2022-04-20 13:26:44 --> Config Class Initialized
INFO - 2022-04-20 13:26:44 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:44 --> Config Class Initialized
INFO - 2022-04-20 13:26:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:26:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:44 --> URI Class Initialized
DEBUG - 2022-04-20 13:26:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:26:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:44 --> URI Class Initialized
INFO - 2022-04-20 13:26:44 --> Router Class Initialized
INFO - 2022-04-20 13:26:44 --> Router Class Initialized
INFO - 2022-04-20 13:26:44 --> Output Class Initialized
INFO - 2022-04-20 13:26:44 --> Security Class Initialized
INFO - 2022-04-20 13:26:44 --> Output Class Initialized
DEBUG - 2022-04-20 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:44 --> Security Class Initialized
INFO - 2022-04-20 13:26:44 --> Input Class Initialized
INFO - 2022-04-20 13:26:44 --> Config Class Initialized
INFO - 2022-04-20 13:26:44 --> Hooks Class Initialized
INFO - 2022-04-20 13:26:44 --> Language Class Initialized
DEBUG - 2022-04-20 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:44 --> Input Class Initialized
ERROR - 2022-04-20 13:26:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:44 --> Language Class Initialized
DEBUG - 2022-04-20 13:26:44 --> UTF-8 Support Enabled
ERROR - 2022-04-20 13:26:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:26:44 --> Utf8 Class Initialized
INFO - 2022-04-20 13:26:44 --> URI Class Initialized
INFO - 2022-04-20 13:26:44 --> Router Class Initialized
INFO - 2022-04-20 13:26:44 --> Output Class Initialized
INFO - 2022-04-20 13:26:44 --> Security Class Initialized
DEBUG - 2022-04-20 13:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:26:44 --> Input Class Initialized
INFO - 2022-04-20 13:26:44 --> Language Class Initialized
ERROR - 2022-04-20 13:26:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:29:57 --> Config Class Initialized
INFO - 2022-04-20 13:29:57 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:29:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:29:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:29:57 --> URI Class Initialized
DEBUG - 2022-04-20 13:29:57 --> No URI present. Default controller set.
INFO - 2022-04-20 13:29:57 --> Router Class Initialized
INFO - 2022-04-20 13:29:57 --> Output Class Initialized
INFO - 2022-04-20 13:29:57 --> Security Class Initialized
DEBUG - 2022-04-20 13:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:29:57 --> Input Class Initialized
INFO - 2022-04-20 13:29:57 --> Language Class Initialized
INFO - 2022-04-20 13:29:57 --> Language Class Initialized
INFO - 2022-04-20 13:29:57 --> Config Class Initialized
INFO - 2022-04-20 13:29:57 --> Loader Class Initialized
INFO - 2022-04-20 13:29:57 --> Helper loaded: url_helper
INFO - 2022-04-20 13:29:57 --> Controller Class Initialized
DEBUG - 2022-04-20 13:29:57 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:29:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:29:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:29:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:29:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:29:57 --> Final output sent to browser
DEBUG - 2022-04-20 13:29:57 --> Total execution time: 0.0189
INFO - 2022-04-20 13:29:57 --> Config Class Initialized
INFO - 2022-04-20 13:29:57 --> Hooks Class Initialized
INFO - 2022-04-20 13:29:57 --> Config Class Initialized
INFO - 2022-04-20 13:29:57 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:29:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:29:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:29:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:29:57 --> URI Class Initialized
INFO - 2022-04-20 13:29:57 --> URI Class Initialized
INFO - 2022-04-20 13:29:57 --> Config Class Initialized
INFO - 2022-04-20 13:29:57 --> Hooks Class Initialized
INFO - 2022-04-20 13:29:57 --> Router Class Initialized
DEBUG - 2022-04-20 13:29:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:29:57 --> Output Class Initialized
INFO - 2022-04-20 13:29:57 --> Security Class Initialized
DEBUG - 2022-04-20 13:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:29:57 --> Router Class Initialized
INFO - 2022-04-20 13:29:57 --> Input Class Initialized
INFO - 2022-04-20 13:29:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:29:57 --> Language Class Initialized
INFO - 2022-04-20 13:29:57 --> URI Class Initialized
ERROR - 2022-04-20 13:29:57 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:29:57 --> Router Class Initialized
INFO - 2022-04-20 13:29:57 --> Output Class Initialized
INFO - 2022-04-20 13:29:57 --> Output Class Initialized
INFO - 2022-04-20 13:29:57 --> Security Class Initialized
INFO - 2022-04-20 13:29:57 --> Security Class Initialized
DEBUG - 2022-04-20 13:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:29:57 --> Input Class Initialized
INFO - 2022-04-20 13:29:57 --> Input Class Initialized
INFO - 2022-04-20 13:29:57 --> Language Class Initialized
INFO - 2022-04-20 13:29:57 --> Language Class Initialized
ERROR - 2022-04-20 13:29:57 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:29:57 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:30:08 --> Config Class Initialized
INFO - 2022-04-20 13:30:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:30:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:08 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:08 --> URI Class Initialized
INFO - 2022-04-20 13:30:08 --> Router Class Initialized
INFO - 2022-04-20 13:30:08 --> Output Class Initialized
INFO - 2022-04-20 13:30:08 --> Security Class Initialized
DEBUG - 2022-04-20 13:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:08 --> Input Class Initialized
INFO - 2022-04-20 13:30:08 --> Language Class Initialized
INFO - 2022-04-20 13:30:08 --> Language Class Initialized
INFO - 2022-04-20 13:30:08 --> Config Class Initialized
INFO - 2022-04-20 13:30:08 --> Loader Class Initialized
INFO - 2022-04-20 13:30:08 --> Helper loaded: url_helper
INFO - 2022-04-20 13:30:08 --> Controller Class Initialized
DEBUG - 2022-04-20 13:30:08 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:30:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:30:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:30:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:30:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:30:08 --> Final output sent to browser
DEBUG - 2022-04-20 13:30:08 --> Total execution time: 0.0197
INFO - 2022-04-20 13:30:09 --> Config Class Initialized
INFO - 2022-04-20 13:30:09 --> Config Class Initialized
INFO - 2022-04-20 13:30:09 --> Hooks Class Initialized
INFO - 2022-04-20 13:30:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:30:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:09 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:30:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:09 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:09 --> URI Class Initialized
INFO - 2022-04-20 13:30:09 --> URI Class Initialized
INFO - 2022-04-20 13:30:09 --> Router Class Initialized
INFO - 2022-04-20 13:30:09 --> Config Class Initialized
INFO - 2022-04-20 13:30:09 --> Router Class Initialized
INFO - 2022-04-20 13:30:09 --> Hooks Class Initialized
INFO - 2022-04-20 13:30:09 --> Output Class Initialized
INFO - 2022-04-20 13:30:09 --> Output Class Initialized
INFO - 2022-04-20 13:30:09 --> Security Class Initialized
DEBUG - 2022-04-20 13:30:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:09 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:09 --> Security Class Initialized
DEBUG - 2022-04-20 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:09 --> Input Class Initialized
INFO - 2022-04-20 13:30:09 --> URI Class Initialized
DEBUG - 2022-04-20 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:09 --> Input Class Initialized
INFO - 2022-04-20 13:30:09 --> Language Class Initialized
INFO - 2022-04-20 13:30:09 --> Language Class Initialized
ERROR - 2022-04-20 13:30:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:30:09 --> Router Class Initialized
ERROR - 2022-04-20 13:30:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:30:09 --> Output Class Initialized
INFO - 2022-04-20 13:30:09 --> Security Class Initialized
DEBUG - 2022-04-20 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:09 --> Input Class Initialized
INFO - 2022-04-20 13:30:09 --> Language Class Initialized
ERROR - 2022-04-20 13:30:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:30:23 --> Config Class Initialized
INFO - 2022-04-20 13:30:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:23 --> URI Class Initialized
INFO - 2022-04-20 13:30:23 --> Router Class Initialized
INFO - 2022-04-20 13:30:23 --> Output Class Initialized
INFO - 2022-04-20 13:30:23 --> Security Class Initialized
DEBUG - 2022-04-20 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:23 --> Input Class Initialized
INFO - 2022-04-20 13:30:23 --> Language Class Initialized
INFO - 2022-04-20 13:30:23 --> Language Class Initialized
INFO - 2022-04-20 13:30:23 --> Config Class Initialized
INFO - 2022-04-20 13:30:23 --> Loader Class Initialized
INFO - 2022-04-20 13:30:23 --> Helper loaded: url_helper
INFO - 2022-04-20 13:30:23 --> Controller Class Initialized
DEBUG - 2022-04-20 13:30:23 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:30:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:30:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:30:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:30:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:30:23 --> Final output sent to browser
DEBUG - 2022-04-20 13:30:23 --> Total execution time: 0.0197
INFO - 2022-04-20 13:30:23 --> Config Class Initialized
INFO - 2022-04-20 13:30:23 --> Hooks Class Initialized
INFO - 2022-04-20 13:30:23 --> Config Class Initialized
INFO - 2022-04-20 13:30:23 --> Config Class Initialized
INFO - 2022-04-20 13:30:23 --> Hooks Class Initialized
INFO - 2022-04-20 13:30:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:23 --> URI Class Initialized
DEBUG - 2022-04-20 13:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:30:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:30:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:23 --> Utf8 Class Initialized
INFO - 2022-04-20 13:30:23 --> URI Class Initialized
INFO - 2022-04-20 13:30:23 --> URI Class Initialized
INFO - 2022-04-20 13:30:23 --> Router Class Initialized
INFO - 2022-04-20 13:30:23 --> Output Class Initialized
INFO - 2022-04-20 13:30:23 --> Router Class Initialized
INFO - 2022-04-20 13:30:23 --> Router Class Initialized
INFO - 2022-04-20 13:30:23 --> Security Class Initialized
INFO - 2022-04-20 13:30:23 --> Output Class Initialized
INFO - 2022-04-20 13:30:23 --> Output Class Initialized
DEBUG - 2022-04-20 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:23 --> Input Class Initialized
INFO - 2022-04-20 13:30:23 --> Security Class Initialized
INFO - 2022-04-20 13:30:23 --> Security Class Initialized
INFO - 2022-04-20 13:30:23 --> Language Class Initialized
DEBUG - 2022-04-20 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:23 --> Input Class Initialized
ERROR - 2022-04-20 13:30:23 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:30:23 --> Input Class Initialized
INFO - 2022-04-20 13:30:23 --> Language Class Initialized
INFO - 2022-04-20 13:30:23 --> Language Class Initialized
ERROR - 2022-04-20 13:30:23 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:30:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:34:37 --> Config Class Initialized
INFO - 2022-04-20 13:34:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:37 --> URI Class Initialized
INFO - 2022-04-20 13:34:37 --> Router Class Initialized
INFO - 2022-04-20 13:34:37 --> Output Class Initialized
INFO - 2022-04-20 13:34:37 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:37 --> Input Class Initialized
INFO - 2022-04-20 13:34:37 --> Language Class Initialized
INFO - 2022-04-20 13:34:37 --> Language Class Initialized
INFO - 2022-04-20 13:34:37 --> Config Class Initialized
INFO - 2022-04-20 13:34:37 --> Loader Class Initialized
INFO - 2022-04-20 13:34:37 --> Helper loaded: url_helper
INFO - 2022-04-20 13:34:37 --> Controller Class Initialized
DEBUG - 2022-04-20 13:34:37 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:34:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:34:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:34:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:34:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:34:37 --> Final output sent to browser
DEBUG - 2022-04-20 13:34:37 --> Total execution time: 0.0184
INFO - 2022-04-20 13:34:37 --> Config Class Initialized
INFO - 2022-04-20 13:34:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:37 --> Config Class Initialized
INFO - 2022-04-20 13:34:37 --> Hooks Class Initialized
INFO - 2022-04-20 13:34:37 --> Config Class Initialized
INFO - 2022-04-20 13:34:37 --> Hooks Class Initialized
INFO - 2022-04-20 13:34:37 --> URI Class Initialized
DEBUG - 2022-04-20 13:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:34:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:37 --> URI Class Initialized
INFO - 2022-04-20 13:34:37 --> URI Class Initialized
INFO - 2022-04-20 13:34:37 --> Router Class Initialized
INFO - 2022-04-20 13:34:37 --> Router Class Initialized
INFO - 2022-04-20 13:34:37 --> Router Class Initialized
INFO - 2022-04-20 13:34:37 --> Output Class Initialized
INFO - 2022-04-20 13:34:37 --> Output Class Initialized
INFO - 2022-04-20 13:34:37 --> Output Class Initialized
INFO - 2022-04-20 13:34:37 --> Security Class Initialized
INFO - 2022-04-20 13:34:37 --> Security Class Initialized
INFO - 2022-04-20 13:34:37 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:37 --> Input Class Initialized
INFO - 2022-04-20 13:34:37 --> Input Class Initialized
INFO - 2022-04-20 13:34:37 --> Input Class Initialized
INFO - 2022-04-20 13:34:37 --> Language Class Initialized
INFO - 2022-04-20 13:34:37 --> Language Class Initialized
INFO - 2022-04-20 13:34:37 --> Language Class Initialized
ERROR - 2022-04-20 13:34:37 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:34:37 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:34:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:34:54 --> Config Class Initialized
INFO - 2022-04-20 13:34:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:54 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:54 --> URI Class Initialized
INFO - 2022-04-20 13:34:54 --> Router Class Initialized
INFO - 2022-04-20 13:34:54 --> Output Class Initialized
INFO - 2022-04-20 13:34:54 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:54 --> Input Class Initialized
INFO - 2022-04-20 13:34:54 --> Language Class Initialized
INFO - 2022-04-20 13:34:54 --> Language Class Initialized
INFO - 2022-04-20 13:34:54 --> Config Class Initialized
INFO - 2022-04-20 13:34:54 --> Loader Class Initialized
INFO - 2022-04-20 13:34:54 --> Helper loaded: url_helper
INFO - 2022-04-20 13:34:54 --> Controller Class Initialized
DEBUG - 2022-04-20 13:34:54 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:34:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:34:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:34:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:34:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:34:54 --> Final output sent to browser
DEBUG - 2022-04-20 13:34:54 --> Total execution time: 0.0178
INFO - 2022-04-20 13:34:54 --> Config Class Initialized
INFO - 2022-04-20 13:34:54 --> Config Class Initialized
INFO - 2022-04-20 13:34:54 --> Hooks Class Initialized
INFO - 2022-04-20 13:34:54 --> Hooks Class Initialized
INFO - 2022-04-20 13:34:54 --> Config Class Initialized
INFO - 2022-04-20 13:34:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:54 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:34:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:54 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:34:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:54 --> URI Class Initialized
INFO - 2022-04-20 13:34:54 --> URI Class Initialized
INFO - 2022-04-20 13:34:54 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:54 --> URI Class Initialized
INFO - 2022-04-20 13:34:54 --> Router Class Initialized
INFO - 2022-04-20 13:34:54 --> Router Class Initialized
INFO - 2022-04-20 13:34:54 --> Output Class Initialized
INFO - 2022-04-20 13:34:54 --> Security Class Initialized
INFO - 2022-04-20 13:34:54 --> Output Class Initialized
DEBUG - 2022-04-20 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:54 --> Input Class Initialized
INFO - 2022-04-20 13:34:54 --> Security Class Initialized
INFO - 2022-04-20 13:34:54 --> Language Class Initialized
DEBUG - 2022-04-20 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:54 --> Input Class Initialized
ERROR - 2022-04-20 13:34:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:34:54 --> Language Class Initialized
ERROR - 2022-04-20 13:34:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:34:54 --> Router Class Initialized
INFO - 2022-04-20 13:34:54 --> Output Class Initialized
INFO - 2022-04-20 13:34:54 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:54 --> Input Class Initialized
INFO - 2022-04-20 13:34:54 --> Language Class Initialized
ERROR - 2022-04-20 13:34:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:34:57 --> Config Class Initialized
INFO - 2022-04-20 13:34:57 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:57 --> URI Class Initialized
DEBUG - 2022-04-20 13:34:57 --> No URI present. Default controller set.
INFO - 2022-04-20 13:34:57 --> Router Class Initialized
INFO - 2022-04-20 13:34:57 --> Output Class Initialized
INFO - 2022-04-20 13:34:57 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:57 --> Input Class Initialized
INFO - 2022-04-20 13:34:57 --> Language Class Initialized
INFO - 2022-04-20 13:34:57 --> Language Class Initialized
INFO - 2022-04-20 13:34:57 --> Config Class Initialized
INFO - 2022-04-20 13:34:57 --> Loader Class Initialized
INFO - 2022-04-20 13:34:57 --> Helper loaded: url_helper
INFO - 2022-04-20 13:34:57 --> Controller Class Initialized
DEBUG - 2022-04-20 13:34:57 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:34:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:34:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:34:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:34:57 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:34:57 --> Final output sent to browser
DEBUG - 2022-04-20 13:34:57 --> Total execution time: 0.0187
INFO - 2022-04-20 13:34:57 --> Config Class Initialized
INFO - 2022-04-20 13:34:57 --> Config Class Initialized
INFO - 2022-04-20 13:34:57 --> Hooks Class Initialized
INFO - 2022-04-20 13:34:57 --> Config Class Initialized
INFO - 2022-04-20 13:34:57 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:57 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:34:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:57 --> URI Class Initialized
INFO - 2022-04-20 13:34:57 --> URI Class Initialized
INFO - 2022-04-20 13:34:57 --> Router Class Initialized
INFO - 2022-04-20 13:34:57 --> Router Class Initialized
INFO - 2022-04-20 13:34:57 --> Output Class Initialized
INFO - 2022-04-20 13:34:57 --> Output Class Initialized
INFO - 2022-04-20 13:34:57 --> Security Class Initialized
INFO - 2022-04-20 13:34:57 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:57 --> Input Class Initialized
INFO - 2022-04-20 13:34:57 --> Input Class Initialized
INFO - 2022-04-20 13:34:57 --> Language Class Initialized
INFO - 2022-04-20 13:34:57 --> Language Class Initialized
ERROR - 2022-04-20 13:34:57 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:34:57 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:34:57 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:34:57 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:34:57 --> Utf8 Class Initialized
INFO - 2022-04-20 13:34:57 --> URI Class Initialized
INFO - 2022-04-20 13:34:57 --> Router Class Initialized
INFO - 2022-04-20 13:34:57 --> Output Class Initialized
INFO - 2022-04-20 13:34:57 --> Security Class Initialized
DEBUG - 2022-04-20 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:34:57 --> Input Class Initialized
INFO - 2022-04-20 13:34:57 --> Language Class Initialized
ERROR - 2022-04-20 13:34:57 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:35:00 --> Config Class Initialized
INFO - 2022-04-20 13:35:00 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:35:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:35:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:35:00 --> URI Class Initialized
INFO - 2022-04-20 13:35:00 --> Router Class Initialized
INFO - 2022-04-20 13:35:00 --> Output Class Initialized
INFO - 2022-04-20 13:35:00 --> Security Class Initialized
DEBUG - 2022-04-20 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:35:00 --> Input Class Initialized
INFO - 2022-04-20 13:35:00 --> Language Class Initialized
INFO - 2022-04-20 13:35:00 --> Language Class Initialized
INFO - 2022-04-20 13:35:00 --> Config Class Initialized
INFO - 2022-04-20 13:35:00 --> Loader Class Initialized
INFO - 2022-04-20 13:35:00 --> Helper loaded: url_helper
INFO - 2022-04-20 13:35:00 --> Controller Class Initialized
DEBUG - 2022-04-20 13:35:00 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:35:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:35:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:35:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:35:00 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:35:00 --> Final output sent to browser
DEBUG - 2022-04-20 13:35:00 --> Total execution time: 0.0189
INFO - 2022-04-20 13:35:00 --> Config Class Initialized
INFO - 2022-04-20 13:35:00 --> Hooks Class Initialized
INFO - 2022-04-20 13:35:00 --> Config Class Initialized
INFO - 2022-04-20 13:35:00 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:35:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:35:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:35:00 --> URI Class Initialized
INFO - 2022-04-20 13:35:00 --> Config Class Initialized
INFO - 2022-04-20 13:35:00 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:35:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:35:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:35:00 --> Router Class Initialized
DEBUG - 2022-04-20 13:35:00 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:35:00 --> Utf8 Class Initialized
INFO - 2022-04-20 13:35:00 --> URI Class Initialized
INFO - 2022-04-20 13:35:00 --> Output Class Initialized
INFO - 2022-04-20 13:35:00 --> URI Class Initialized
INFO - 2022-04-20 13:35:00 --> Security Class Initialized
INFO - 2022-04-20 13:35:00 --> Router Class Initialized
DEBUG - 2022-04-20 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:35:00 --> Input Class Initialized
INFO - 2022-04-20 13:35:00 --> Router Class Initialized
INFO - 2022-04-20 13:35:00 --> Language Class Initialized
INFO - 2022-04-20 13:35:00 --> Output Class Initialized
INFO - 2022-04-20 13:35:00 --> Output Class Initialized
ERROR - 2022-04-20 13:35:00 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:35:00 --> Security Class Initialized
INFO - 2022-04-20 13:35:00 --> Security Class Initialized
DEBUG - 2022-04-20 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:35:00 --> Input Class Initialized
DEBUG - 2022-04-20 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:35:00 --> Language Class Initialized
INFO - 2022-04-20 13:35:00 --> Input Class Initialized
INFO - 2022-04-20 13:35:00 --> Language Class Initialized
ERROR - 2022-04-20 13:35:00 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:35:00 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:18 --> Config Class Initialized
INFO - 2022-04-20 13:36:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:18 --> URI Class Initialized
INFO - 2022-04-20 13:36:18 --> Router Class Initialized
INFO - 2022-04-20 13:36:18 --> Output Class Initialized
INFO - 2022-04-20 13:36:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:18 --> Input Class Initialized
INFO - 2022-04-20 13:36:18 --> Language Class Initialized
INFO - 2022-04-20 13:36:18 --> Language Class Initialized
INFO - 2022-04-20 13:36:18 --> Config Class Initialized
INFO - 2022-04-20 13:36:18 --> Loader Class Initialized
INFO - 2022-04-20 13:36:18 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:18 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:18 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:18 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:18 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:18 --> Total execution time: 0.0212
INFO - 2022-04-20 13:36:18 --> Config Class Initialized
INFO - 2022-04-20 13:36:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:18 --> Config Class Initialized
INFO - 2022-04-20 13:36:18 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:18 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:18 --> Router Class Initialized
INFO - 2022-04-20 13:36:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:18 --> URI Class Initialized
INFO - 2022-04-20 13:36:18 --> Output Class Initialized
INFO - 2022-04-20 13:36:18 --> Config Class Initialized
INFO - 2022-04-20 13:36:18 --> Security Class Initialized
INFO - 2022-04-20 13:36:18 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:18 --> Input Class Initialized
INFO - 2022-04-20 13:36:18 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:18 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:36:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:18 --> URI Class Initialized
INFO - 2022-04-20 13:36:18 --> Config Class Initialized
INFO - 2022-04-20 13:36:18 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:18 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:18 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:18 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:18 --> Output Class Initialized
INFO - 2022-04-20 13:36:18 --> URI Class Initialized
INFO - 2022-04-20 13:36:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:18 --> Input Class Initialized
INFO - 2022-04-20 13:36:18 --> Router Class Initialized
INFO - 2022-04-20 13:36:18 --> Language Class Initialized
ERROR - 2022-04-20 13:36:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:18 --> Output Class Initialized
INFO - 2022-04-20 13:36:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:18 --> Input Class Initialized
INFO - 2022-04-20 13:36:18 --> Router Class Initialized
INFO - 2022-04-20 13:36:18 --> Language Class Initialized
ERROR - 2022-04-20 13:36:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:18 --> Output Class Initialized
INFO - 2022-04-20 13:36:18 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:18 --> Input Class Initialized
INFO - 2022-04-20 13:36:18 --> Language Class Initialized
ERROR - 2022-04-20 13:36:18 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:20 --> Config Class Initialized
INFO - 2022-04-20 13:36:20 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:20 --> URI Class Initialized
INFO - 2022-04-20 13:36:20 --> Router Class Initialized
INFO - 2022-04-20 13:36:20 --> Output Class Initialized
INFO - 2022-04-20 13:36:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:20 --> Input Class Initialized
INFO - 2022-04-20 13:36:20 --> Language Class Initialized
INFO - 2022-04-20 13:36:20 --> Language Class Initialized
INFO - 2022-04-20 13:36:20 --> Config Class Initialized
INFO - 2022-04-20 13:36:20 --> Loader Class Initialized
INFO - 2022-04-20 13:36:20 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:20 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:20 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:20 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:20 --> Total execution time: 0.0195
INFO - 2022-04-20 13:36:20 --> Config Class Initialized
INFO - 2022-04-20 13:36:20 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:20 --> Config Class Initialized
INFO - 2022-04-20 13:36:20 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:20 --> Config Class Initialized
INFO - 2022-04-20 13:36:20 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:36:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:20 --> Config Class Initialized
INFO - 2022-04-20 13:36:20 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:20 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:20 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:20 --> URI Class Initialized
INFO - 2022-04-20 13:36:20 --> URI Class Initialized
INFO - 2022-04-20 13:36:20 --> Router Class Initialized
INFO - 2022-04-20 13:36:20 --> Router Class Initialized
INFO - 2022-04-20 13:36:20 --> Output Class Initialized
INFO - 2022-04-20 13:36:20 --> Output Class Initialized
INFO - 2022-04-20 13:36:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:20 --> Input Class Initialized
INFO - 2022-04-20 13:36:20 --> Security Class Initialized
INFO - 2022-04-20 13:36:20 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:36:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:20 --> Input Class Initialized
INFO - 2022-04-20 13:36:20 --> Language Class Initialized
INFO - 2022-04-20 13:36:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:20 --> Router Class Initialized
ERROR - 2022-04-20 13:36:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:20 --> URI Class Initialized
INFO - 2022-04-20 13:36:20 --> Output Class Initialized
INFO - 2022-04-20 13:36:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:20 --> Input Class Initialized
INFO - 2022-04-20 13:36:20 --> Language Class Initialized
INFO - 2022-04-20 13:36:20 --> Router Class Initialized
ERROR - 2022-04-20 13:36:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:20 --> Output Class Initialized
INFO - 2022-04-20 13:36:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:20 --> Input Class Initialized
INFO - 2022-04-20 13:36:20 --> Language Class Initialized
ERROR - 2022-04-20 13:36:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:25 --> Config Class Initialized
INFO - 2022-04-20 13:36:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:25 --> URI Class Initialized
INFO - 2022-04-20 13:36:25 --> Router Class Initialized
INFO - 2022-04-20 13:36:25 --> Output Class Initialized
INFO - 2022-04-20 13:36:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:25 --> Input Class Initialized
INFO - 2022-04-20 13:36:25 --> Language Class Initialized
INFO - 2022-04-20 13:36:25 --> Language Class Initialized
INFO - 2022-04-20 13:36:25 --> Config Class Initialized
INFO - 2022-04-20 13:36:25 --> Loader Class Initialized
INFO - 2022-04-20 13:36:25 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:25 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:25 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:25 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:25 --> Total execution time: 0.0187
INFO - 2022-04-20 13:36:25 --> Config Class Initialized
INFO - 2022-04-20 13:36:25 --> Config Class Initialized
INFO - 2022-04-20 13:36:25 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:36:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:25 --> URI Class Initialized
INFO - 2022-04-20 13:36:25 --> URI Class Initialized
INFO - 2022-04-20 13:36:25 --> Config Class Initialized
INFO - 2022-04-20 13:36:25 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:25 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:25 --> Router Class Initialized
INFO - 2022-04-20 13:36:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:25 --> URI Class Initialized
INFO - 2022-04-20 13:36:25 --> Output Class Initialized
INFO - 2022-04-20 13:36:25 --> Output Class Initialized
INFO - 2022-04-20 13:36:25 --> Security Class Initialized
INFO - 2022-04-20 13:36:25 --> Security Class Initialized
INFO - 2022-04-20 13:36:25 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:25 --> Output Class Initialized
INFO - 2022-04-20 13:36:25 --> Input Class Initialized
INFO - 2022-04-20 13:36:25 --> Input Class Initialized
INFO - 2022-04-20 13:36:25 --> Language Class Initialized
INFO - 2022-04-20 13:36:25 --> Security Class Initialized
INFO - 2022-04-20 13:36:25 --> Language Class Initialized
ERROR - 2022-04-20 13:36:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:25 --> Input Class Initialized
INFO - 2022-04-20 13:36:25 --> Language Class Initialized
ERROR - 2022-04-20 13:36:25 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:25 --> Config Class Initialized
INFO - 2022-04-20 13:36:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:25 --> URI Class Initialized
INFO - 2022-04-20 13:36:25 --> Router Class Initialized
INFO - 2022-04-20 13:36:25 --> Output Class Initialized
INFO - 2022-04-20 13:36:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:25 --> Input Class Initialized
INFO - 2022-04-20 13:36:25 --> Language Class Initialized
ERROR - 2022-04-20 13:36:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:26 --> Config Class Initialized
INFO - 2022-04-20 13:36:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:26 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:26 --> URI Class Initialized
INFO - 2022-04-20 13:36:26 --> Router Class Initialized
INFO - 2022-04-20 13:36:26 --> Output Class Initialized
INFO - 2022-04-20 13:36:26 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:26 --> Input Class Initialized
INFO - 2022-04-20 13:36:26 --> Language Class Initialized
INFO - 2022-04-20 13:36:26 --> Language Class Initialized
INFO - 2022-04-20 13:36:26 --> Config Class Initialized
INFO - 2022-04-20 13:36:26 --> Loader Class Initialized
INFO - 2022-04-20 13:36:26 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:26 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:26 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:26 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:26 --> Total execution time: 0.0176
INFO - 2022-04-20 13:36:26 --> Config Class Initialized
INFO - 2022-04-20 13:36:26 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:26 --> Config Class Initialized
INFO - 2022-04-20 13:36:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:26 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:26 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:26 --> Router Class Initialized
INFO - 2022-04-20 13:36:26 --> Output Class Initialized
INFO - 2022-04-20 13:36:26 --> Security Class Initialized
INFO - 2022-04-20 13:36:26 --> Config Class Initialized
INFO - 2022-04-20 13:36:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:26 --> Input Class Initialized
INFO - 2022-04-20 13:36:26 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:26 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:36:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:26 --> URI Class Initialized
INFO - 2022-04-20 13:36:26 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:26 --> URI Class Initialized
INFO - 2022-04-20 13:36:26 --> Router Class Initialized
INFO - 2022-04-20 13:36:26 --> Output Class Initialized
INFO - 2022-04-20 13:36:26 --> Router Class Initialized
INFO - 2022-04-20 13:36:26 --> Security Class Initialized
INFO - 2022-04-20 13:36:26 --> Config Class Initialized
INFO - 2022-04-20 13:36:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:26 --> Output Class Initialized
INFO - 2022-04-20 13:36:26 --> Input Class Initialized
INFO - 2022-04-20 13:36:26 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:26 --> Security Class Initialized
INFO - 2022-04-20 13:36:26 --> Utf8 Class Initialized
ERROR - 2022-04-20 13:36:26 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:26 --> URI Class Initialized
INFO - 2022-04-20 13:36:26 --> Input Class Initialized
INFO - 2022-04-20 13:36:26 --> Language Class Initialized
ERROR - 2022-04-20 13:36:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:26 --> Router Class Initialized
INFO - 2022-04-20 13:36:26 --> Output Class Initialized
INFO - 2022-04-20 13:36:26 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:26 --> Input Class Initialized
INFO - 2022-04-20 13:36:26 --> Language Class Initialized
ERROR - 2022-04-20 13:36:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Loader Class Initialized
INFO - 2022-04-20 13:36:30 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:30 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:30 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:30 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:30 --> Total execution time: 0.0183
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Loader Class Initialized
INFO - 2022-04-20 13:36:30 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:30 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:30 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:30 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:30 --> Total execution time: 0.0201
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Loader Class Initialized
INFO - 2022-04-20 13:36:30 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:30 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:30 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:30 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:30 --> Total execution time: 0.0212
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
ERROR - 2022-04-20 13:36:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:30 --> URI Class Initialized
INFO - 2022-04-20 13:36:30 --> Router Class Initialized
INFO - 2022-04-20 13:36:30 --> Output Class Initialized
INFO - 2022-04-20 13:36:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:30 --> Input Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Language Class Initialized
INFO - 2022-04-20 13:36:30 --> Config Class Initialized
INFO - 2022-04-20 13:36:30 --> Loader Class Initialized
INFO - 2022-04-20 13:36:30 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:30 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:30 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:30 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:30 --> Total execution time: 0.0202
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Loader Class Initialized
INFO - 2022-04-20 13:36:31 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:31 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:31 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:31 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:31 --> Total execution time: 0.0207
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Loader Class Initialized
INFO - 2022-04-20 13:36:31 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:31 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:31 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:31 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:31 --> Total execution time: 0.0201
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Config Class Initialized
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:31 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:31 --> URI Class Initialized
INFO - 2022-04-20 13:36:31 --> Router Class Initialized
INFO - 2022-04-20 13:36:31 --> Output Class Initialized
INFO - 2022-04-20 13:36:31 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:31 --> Input Class Initialized
INFO - 2022-04-20 13:36:31 --> Language Class Initialized
ERROR - 2022-04-20 13:36:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:34 --> Config Class Initialized
INFO - 2022-04-20 13:36:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:34 --> URI Class Initialized
INFO - 2022-04-20 13:36:34 --> Router Class Initialized
INFO - 2022-04-20 13:36:34 --> Output Class Initialized
INFO - 2022-04-20 13:36:34 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:34 --> Input Class Initialized
INFO - 2022-04-20 13:36:34 --> Language Class Initialized
INFO - 2022-04-20 13:36:34 --> Language Class Initialized
INFO - 2022-04-20 13:36:34 --> Config Class Initialized
INFO - 2022-04-20 13:36:34 --> Loader Class Initialized
INFO - 2022-04-20 13:36:34 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:34 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:34 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:34 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:34 --> Total execution time: 0.0186
INFO - 2022-04-20 13:36:34 --> Config Class Initialized
INFO - 2022-04-20 13:36:34 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:34 --> Config Class Initialized
INFO - 2022-04-20 13:36:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:34 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:34 --> URI Class Initialized
INFO - 2022-04-20 13:36:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:34 --> URI Class Initialized
INFO - 2022-04-20 13:36:34 --> Router Class Initialized
INFO - 2022-04-20 13:36:34 --> Router Class Initialized
INFO - 2022-04-20 13:36:34 --> Output Class Initialized
INFO - 2022-04-20 13:36:34 --> Security Class Initialized
INFO - 2022-04-20 13:36:34 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:34 --> Security Class Initialized
INFO - 2022-04-20 13:36:34 --> Input Class Initialized
INFO - 2022-04-20 13:36:34 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:34 --> Input Class Initialized
ERROR - 2022-04-20 13:36:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:34 --> Language Class Initialized
ERROR - 2022-04-20 13:36:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:34 --> Config Class Initialized
INFO - 2022-04-20 13:36:34 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:34 --> Config Class Initialized
INFO - 2022-04-20 13:36:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:34 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:34 --> URI Class Initialized
INFO - 2022-04-20 13:36:34 --> URI Class Initialized
INFO - 2022-04-20 13:36:34 --> Router Class Initialized
INFO - 2022-04-20 13:36:34 --> Router Class Initialized
INFO - 2022-04-20 13:36:34 --> Output Class Initialized
INFO - 2022-04-20 13:36:34 --> Security Class Initialized
INFO - 2022-04-20 13:36:34 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:34 --> Security Class Initialized
INFO - 2022-04-20 13:36:34 --> Input Class Initialized
INFO - 2022-04-20 13:36:34 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:34 --> Input Class Initialized
INFO - 2022-04-20 13:36:34 --> Language Class Initialized
ERROR - 2022-04-20 13:36:34 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Loader Class Initialized
INFO - 2022-04-20 13:36:37 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:37 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:37 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:37 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:37 --> Total execution time: 0.0192
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Loader Class Initialized
INFO - 2022-04-20 13:36:37 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:37 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:37 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:37 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:37 --> Total execution time: 0.0193
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Config Class Initialized
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:37 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> URI Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
INFO - 2022-04-20 13:36:37 --> Router Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
INFO - 2022-04-20 13:36:37 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
INFO - 2022-04-20 13:36:37 --> Security Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:37 --> Input Class Initialized
INFO - 2022-04-20 13:36:37 --> Language Class Initialized
ERROR - 2022-04-20 13:36:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Loader Class Initialized
INFO - 2022-04-20 13:36:38 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:38 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:38 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:38 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:38 --> Total execution time: 0.0204
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Loader Class Initialized
INFO - 2022-04-20 13:36:38 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:38 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:38 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:38 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:38 --> Total execution time: 0.0198
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Loader Class Initialized
INFO - 2022-04-20 13:36:38 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:38 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:38 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:38 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:38 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:38 --> Total execution time: 0.0209
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
INFO - 2022-04-20 13:36:38 --> Config Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:36:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
INFO - 2022-04-20 13:36:38 --> URI Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
INFO - 2022-04-20 13:36:38 --> Router Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:38 --> Output Class Initialized
INFO - 2022-04-20 13:36:38 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:38 --> Input Class Initialized
INFO - 2022-04-20 13:36:38 --> Language Class Initialized
ERROR - 2022-04-20 13:36:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:59 --> URI Class Initialized
INFO - 2022-04-20 13:36:59 --> Router Class Initialized
INFO - 2022-04-20 13:36:59 --> Output Class Initialized
INFO - 2022-04-20 13:36:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:59 --> Input Class Initialized
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Loader Class Initialized
INFO - 2022-04-20 13:36:59 --> Helper loaded: url_helper
INFO - 2022-04-20 13:36:59 --> Controller Class Initialized
DEBUG - 2022-04-20 13:36:59 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:36:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:36:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:36:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:36:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:36:59 --> Final output sent to browser
DEBUG - 2022-04-20 13:36:59 --> Total execution time: 0.0195
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:59 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:59 --> URI Class Initialized
INFO - 2022-04-20 13:36:59 --> Router Class Initialized
INFO - 2022-04-20 13:36:59 --> Router Class Initialized
INFO - 2022-04-20 13:36:59 --> Output Class Initialized
INFO - 2022-04-20 13:36:59 --> Security Class Initialized
INFO - 2022-04-20 13:36:59 --> Output Class Initialized
DEBUG - 2022-04-20 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:59 --> Input Class Initialized
INFO - 2022-04-20 13:36:59 --> Security Class Initialized
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
DEBUG - 2022-04-20 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:59 --> Input Class Initialized
ERROR - 2022-04-20 13:36:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
ERROR - 2022-04-20 13:36:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:36:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:59 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:36:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:59 --> URI Class Initialized
INFO - 2022-04-20 13:36:59 --> URI Class Initialized
INFO - 2022-04-20 13:36:59 --> Router Class Initialized
INFO - 2022-04-20 13:36:59 --> Config Class Initialized
INFO - 2022-04-20 13:36:59 --> Router Class Initialized
INFO - 2022-04-20 13:36:59 --> Hooks Class Initialized
INFO - 2022-04-20 13:36:59 --> Output Class Initialized
INFO - 2022-04-20 13:36:59 --> Output Class Initialized
INFO - 2022-04-20 13:36:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:36:59 --> Utf8 Class Initialized
INFO - 2022-04-20 13:36:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:59 --> Input Class Initialized
INFO - 2022-04-20 13:36:59 --> URI Class Initialized
DEBUG - 2022-04-20 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
INFO - 2022-04-20 13:36:59 --> Input Class Initialized
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
ERROR - 2022-04-20 13:36:59 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:36:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:36:59 --> Router Class Initialized
INFO - 2022-04-20 13:36:59 --> Output Class Initialized
INFO - 2022-04-20 13:36:59 --> Security Class Initialized
DEBUG - 2022-04-20 13:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:36:59 --> Input Class Initialized
INFO - 2022-04-20 13:36:59 --> Language Class Initialized
ERROR - 2022-04-20 13:36:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:37:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:20 --> URI Class Initialized
INFO - 2022-04-20 13:37:20 --> Router Class Initialized
INFO - 2022-04-20 13:37:20 --> Output Class Initialized
INFO - 2022-04-20 13:37:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:20 --> Input Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Loader Class Initialized
INFO - 2022-04-20 13:37:20 --> Helper loaded: url_helper
INFO - 2022-04-20 13:37:20 --> Controller Class Initialized
DEBUG - 2022-04-20 13:37:20 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:37:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:37:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:37:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:37:20 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:37:20 --> Final output sent to browser
DEBUG - 2022-04-20 13:37:20 --> Total execution time: 0.0203
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:37:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:20 --> URI Class Initialized
INFO - 2022-04-20 13:37:20 --> Router Class Initialized
INFO - 2022-04-20 13:37:20 --> Output Class Initialized
INFO - 2022-04-20 13:37:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:20 --> Input Class Initialized
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Hooks Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
ERROR - 2022-04-20 13:37:20 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:37:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:20 --> URI Class Initialized
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Hooks Class Initialized
INFO - 2022-04-20 13:37:20 --> Router Class Initialized
DEBUG - 2022-04-20 13:37:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:20 --> Output Class Initialized
INFO - 2022-04-20 13:37:20 --> URI Class Initialized
INFO - 2022-04-20 13:37:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:20 --> Input Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
INFO - 2022-04-20 13:37:20 --> Router Class Initialized
ERROR - 2022-04-20 13:37:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:37:20 --> Output Class Initialized
INFO - 2022-04-20 13:37:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:20 --> Input Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
ERROR - 2022-04-20 13:37:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:37:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:20 --> URI Class Initialized
INFO - 2022-04-20 13:37:20 --> Router Class Initialized
INFO - 2022-04-20 13:37:20 --> Output Class Initialized
INFO - 2022-04-20 13:37:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:20 --> Input Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
ERROR - 2022-04-20 13:37:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:37:20 --> Config Class Initialized
INFO - 2022-04-20 13:37:20 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:37:20 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:20 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:20 --> URI Class Initialized
INFO - 2022-04-20 13:37:20 --> Router Class Initialized
INFO - 2022-04-20 13:37:20 --> Output Class Initialized
INFO - 2022-04-20 13:37:20 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:20 --> Input Class Initialized
INFO - 2022-04-20 13:37:20 --> Language Class Initialized
ERROR - 2022-04-20 13:37:20 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:37:25 --> Config Class Initialized
INFO - 2022-04-20 13:37:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:37:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:25 --> URI Class Initialized
INFO - 2022-04-20 13:37:25 --> Router Class Initialized
INFO - 2022-04-20 13:37:25 --> Output Class Initialized
INFO - 2022-04-20 13:37:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:25 --> Input Class Initialized
INFO - 2022-04-20 13:37:25 --> Language Class Initialized
INFO - 2022-04-20 13:37:25 --> Language Class Initialized
INFO - 2022-04-20 13:37:25 --> Config Class Initialized
INFO - 2022-04-20 13:37:25 --> Loader Class Initialized
INFO - 2022-04-20 13:37:25 --> Helper loaded: url_helper
INFO - 2022-04-20 13:37:25 --> Controller Class Initialized
DEBUG - 2022-04-20 13:37:25 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:37:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:37:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:37:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:37:25 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:37:25 --> Final output sent to browser
DEBUG - 2022-04-20 13:37:25 --> Total execution time: 0.0208
INFO - 2022-04-20 13:37:25 --> Config Class Initialized
INFO - 2022-04-20 13:37:25 --> Hooks Class Initialized
INFO - 2022-04-20 13:37:25 --> Config Class Initialized
INFO - 2022-04-20 13:37:25 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:37:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:25 --> URI Class Initialized
INFO - 2022-04-20 13:37:25 --> Router Class Initialized
INFO - 2022-04-20 13:37:25 --> Config Class Initialized
INFO - 2022-04-20 13:37:25 --> Hooks Class Initialized
INFO - 2022-04-20 13:37:25 --> Output Class Initialized
INFO - 2022-04-20 13:37:25 --> Security Class Initialized
DEBUG - 2022-04-20 13:37:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:25 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:25 --> Input Class Initialized
INFO - 2022-04-20 13:37:25 --> URI Class Initialized
INFO - 2022-04-20 13:37:25 --> Language Class Initialized
ERROR - 2022-04-20 13:37:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:37:25 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:37:25 --> Utf8 Class Initialized
INFO - 2022-04-20 13:37:25 --> Router Class Initialized
INFO - 2022-04-20 13:37:25 --> URI Class Initialized
INFO - 2022-04-20 13:37:25 --> Output Class Initialized
INFO - 2022-04-20 13:37:25 --> Security Class Initialized
INFO - 2022-04-20 13:37:25 --> Router Class Initialized
DEBUG - 2022-04-20 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:25 --> Input Class Initialized
INFO - 2022-04-20 13:37:25 --> Output Class Initialized
INFO - 2022-04-20 13:37:25 --> Language Class Initialized
INFO - 2022-04-20 13:37:25 --> Security Class Initialized
ERROR - 2022-04-20 13:37:25 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:37:25 --> Input Class Initialized
INFO - 2022-04-20 13:37:25 --> Language Class Initialized
ERROR - 2022-04-20 13:37:25 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:03 --> Config Class Initialized
INFO - 2022-04-20 13:39:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:03 --> URI Class Initialized
INFO - 2022-04-20 13:39:03 --> Router Class Initialized
INFO - 2022-04-20 13:39:03 --> Output Class Initialized
INFO - 2022-04-20 13:39:03 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:03 --> Input Class Initialized
INFO - 2022-04-20 13:39:03 --> Language Class Initialized
INFO - 2022-04-20 13:39:03 --> Language Class Initialized
INFO - 2022-04-20 13:39:03 --> Config Class Initialized
INFO - 2022-04-20 13:39:03 --> Loader Class Initialized
INFO - 2022-04-20 13:39:03 --> Helper loaded: url_helper
INFO - 2022-04-20 13:39:03 --> Controller Class Initialized
DEBUG - 2022-04-20 13:39:03 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:39:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:39:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:39:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:39:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:39:03 --> Final output sent to browser
DEBUG - 2022-04-20 13:39:03 --> Total execution time: 0.0182
INFO - 2022-04-20 13:39:03 --> Config Class Initialized
INFO - 2022-04-20 13:39:03 --> Hooks Class Initialized
INFO - 2022-04-20 13:39:03 --> Config Class Initialized
INFO - 2022-04-20 13:39:03 --> Hooks Class Initialized
INFO - 2022-04-20 13:39:03 --> Config Class Initialized
INFO - 2022-04-20 13:39:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:03 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:03 --> URI Class Initialized
INFO - 2022-04-20 13:39:03 --> URI Class Initialized
DEBUG - 2022-04-20 13:39:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:03 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:03 --> URI Class Initialized
INFO - 2022-04-20 13:39:03 --> Router Class Initialized
INFO - 2022-04-20 13:39:03 --> Output Class Initialized
INFO - 2022-04-20 13:39:03 --> Router Class Initialized
INFO - 2022-04-20 13:39:03 --> Security Class Initialized
INFO - 2022-04-20 13:39:03 --> Output Class Initialized
DEBUG - 2022-04-20 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:03 --> Input Class Initialized
INFO - 2022-04-20 13:39:03 --> Security Class Initialized
INFO - 2022-04-20 13:39:03 --> Language Class Initialized
DEBUG - 2022-04-20 13:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:39:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:03 --> Input Class Initialized
INFO - 2022-04-20 13:39:03 --> Language Class Initialized
ERROR - 2022-04-20 13:39:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:03 --> Router Class Initialized
INFO - 2022-04-20 13:39:03 --> Output Class Initialized
INFO - 2022-04-20 13:39:03 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:03 --> Input Class Initialized
INFO - 2022-04-20 13:39:03 --> Language Class Initialized
ERROR - 2022-04-20 13:39:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:06 --> URI Class Initialized
INFO - 2022-04-20 13:39:06 --> Router Class Initialized
INFO - 2022-04-20 13:39:06 --> Output Class Initialized
INFO - 2022-04-20 13:39:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:06 --> Input Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Loader Class Initialized
INFO - 2022-04-20 13:39:06 --> Helper loaded: url_helper
INFO - 2022-04-20 13:39:06 --> Controller Class Initialized
DEBUG - 2022-04-20 13:39:06 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 13:39:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:39:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:39:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 13:39:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:39:06 --> Final output sent to browser
DEBUG - 2022-04-20 13:39:06 --> Total execution time: 0.0187
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Hooks Class Initialized
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:06 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:06 --> URI Class Initialized
INFO - 2022-04-20 13:39:06 --> URI Class Initialized
INFO - 2022-04-20 13:39:06 --> Router Class Initialized
INFO - 2022-04-20 13:39:06 --> Router Class Initialized
INFO - 2022-04-20 13:39:06 --> Output Class Initialized
INFO - 2022-04-20 13:39:06 --> Output Class Initialized
INFO - 2022-04-20 13:39:06 --> Security Class Initialized
INFO - 2022-04-20 13:39:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:06 --> Input Class Initialized
DEBUG - 2022-04-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:06 --> Input Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
ERROR - 2022-04-20 13:39:06 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:39:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:06 --> URI Class Initialized
INFO - 2022-04-20 13:39:06 --> Router Class Initialized
INFO - 2022-04-20 13:39:06 --> Output Class Initialized
INFO - 2022-04-20 13:39:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:06 --> Input Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
ERROR - 2022-04-20 13:39:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:06 --> URI Class Initialized
INFO - 2022-04-20 13:39:06 --> Router Class Initialized
INFO - 2022-04-20 13:39:06 --> Output Class Initialized
INFO - 2022-04-20 13:39:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:06 --> Input Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
ERROR - 2022-04-20 13:39:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:06 --> Config Class Initialized
INFO - 2022-04-20 13:39:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:06 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:06 --> URI Class Initialized
INFO - 2022-04-20 13:39:06 --> Router Class Initialized
INFO - 2022-04-20 13:39:06 --> Output Class Initialized
INFO - 2022-04-20 13:39:06 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:06 --> Input Class Initialized
INFO - 2022-04-20 13:39:06 --> Language Class Initialized
ERROR - 2022-04-20 13:39:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:39:10 --> Config Class Initialized
INFO - 2022-04-20 13:39:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:10 --> URI Class Initialized
DEBUG - 2022-04-20 13:39:10 --> No URI present. Default controller set.
INFO - 2022-04-20 13:39:10 --> Router Class Initialized
INFO - 2022-04-20 13:39:10 --> Output Class Initialized
INFO - 2022-04-20 13:39:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:10 --> Input Class Initialized
INFO - 2022-04-20 13:39:10 --> Language Class Initialized
INFO - 2022-04-20 13:39:10 --> Language Class Initialized
INFO - 2022-04-20 13:39:10 --> Config Class Initialized
INFO - 2022-04-20 13:39:10 --> Loader Class Initialized
INFO - 2022-04-20 13:39:10 --> Helper loaded: url_helper
INFO - 2022-04-20 13:39:10 --> Controller Class Initialized
DEBUG - 2022-04-20 13:39:10 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:39:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:39:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:39:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:39:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:39:10 --> Final output sent to browser
DEBUG - 2022-04-20 13:39:10 --> Total execution time: 0.0197
INFO - 2022-04-20 13:39:10 --> Config Class Initialized
INFO - 2022-04-20 13:39:10 --> Config Class Initialized
INFO - 2022-04-20 13:39:10 --> Config Class Initialized
INFO - 2022-04-20 13:39:10 --> Hooks Class Initialized
INFO - 2022-04-20 13:39:10 --> Hooks Class Initialized
INFO - 2022-04-20 13:39:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:39:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:39:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:10 --> Utf8 Class Initialized
INFO - 2022-04-20 13:39:10 --> URI Class Initialized
INFO - 2022-04-20 13:39:10 --> URI Class Initialized
INFO - 2022-04-20 13:39:10 --> URI Class Initialized
INFO - 2022-04-20 13:39:10 --> Router Class Initialized
INFO - 2022-04-20 13:39:10 --> Router Class Initialized
INFO - 2022-04-20 13:39:10 --> Router Class Initialized
INFO - 2022-04-20 13:39:10 --> Output Class Initialized
INFO - 2022-04-20 13:39:10 --> Output Class Initialized
INFO - 2022-04-20 13:39:10 --> Output Class Initialized
INFO - 2022-04-20 13:39:10 --> Security Class Initialized
INFO - 2022-04-20 13:39:10 --> Security Class Initialized
INFO - 2022-04-20 13:39:10 --> Security Class Initialized
DEBUG - 2022-04-20 13:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:10 --> Input Class Initialized
DEBUG - 2022-04-20 13:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:39:10 --> Input Class Initialized
INFO - 2022-04-20 13:39:10 --> Input Class Initialized
INFO - 2022-04-20 13:39:10 --> Language Class Initialized
INFO - 2022-04-20 13:39:10 --> Language Class Initialized
INFO - 2022-04-20 13:39:10 --> Language Class Initialized
ERROR - 2022-04-20 13:39:10 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:39:10 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:39:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:40:34 --> Config Class Initialized
INFO - 2022-04-20 13:40:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:40:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:40:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:40:34 --> URI Class Initialized
DEBUG - 2022-04-20 13:40:34 --> No URI present. Default controller set.
INFO - 2022-04-20 13:40:34 --> Router Class Initialized
INFO - 2022-04-20 13:40:34 --> Output Class Initialized
INFO - 2022-04-20 13:40:34 --> Security Class Initialized
DEBUG - 2022-04-20 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:40:34 --> Input Class Initialized
INFO - 2022-04-20 13:40:34 --> Language Class Initialized
INFO - 2022-04-20 13:40:34 --> Language Class Initialized
INFO - 2022-04-20 13:40:34 --> Config Class Initialized
INFO - 2022-04-20 13:40:34 --> Loader Class Initialized
INFO - 2022-04-20 13:40:34 --> Helper loaded: url_helper
INFO - 2022-04-20 13:40:34 --> Controller Class Initialized
DEBUG - 2022-04-20 13:40:34 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:40:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:40:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:40:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:40:34 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:40:34 --> Final output sent to browser
DEBUG - 2022-04-20 13:40:34 --> Total execution time: 0.0199
INFO - 2022-04-20 13:40:34 --> Config Class Initialized
INFO - 2022-04-20 13:40:34 --> Hooks Class Initialized
INFO - 2022-04-20 13:40:34 --> Config Class Initialized
INFO - 2022-04-20 13:40:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:40:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:40:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:40:34 --> Config Class Initialized
DEBUG - 2022-04-20 13:40:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:40:34 --> URI Class Initialized
INFO - 2022-04-20 13:40:34 --> Hooks Class Initialized
INFO - 2022-04-20 13:40:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:40:34 --> URI Class Initialized
DEBUG - 2022-04-20 13:40:34 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:40:34 --> Utf8 Class Initialized
INFO - 2022-04-20 13:40:34 --> URI Class Initialized
INFO - 2022-04-20 13:40:34 --> Router Class Initialized
INFO - 2022-04-20 13:40:34 --> Router Class Initialized
INFO - 2022-04-20 13:40:34 --> Router Class Initialized
INFO - 2022-04-20 13:40:34 --> Output Class Initialized
INFO - 2022-04-20 13:40:34 --> Output Class Initialized
INFO - 2022-04-20 13:40:34 --> Output Class Initialized
INFO - 2022-04-20 13:40:34 --> Security Class Initialized
INFO - 2022-04-20 13:40:34 --> Security Class Initialized
DEBUG - 2022-04-20 13:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:40:34 --> Input Class Initialized
INFO - 2022-04-20 13:40:34 --> Input Class Initialized
INFO - 2022-04-20 13:40:34 --> Security Class Initialized
INFO - 2022-04-20 13:40:34 --> Language Class Initialized
INFO - 2022-04-20 13:40:34 --> Language Class Initialized
DEBUG - 2022-04-20 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:40:34 --> Input Class Initialized
ERROR - 2022-04-20 13:40:34 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:40:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:40:34 --> Language Class Initialized
ERROR - 2022-04-20 13:40:34 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:41:16 --> Config Class Initialized
INFO - 2022-04-20 13:41:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:41:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:41:16 --> Utf8 Class Initialized
INFO - 2022-04-20 13:41:16 --> URI Class Initialized
DEBUG - 2022-04-20 13:41:16 --> No URI present. Default controller set.
INFO - 2022-04-20 13:41:16 --> Router Class Initialized
INFO - 2022-04-20 13:41:16 --> Output Class Initialized
INFO - 2022-04-20 13:41:16 --> Security Class Initialized
DEBUG - 2022-04-20 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:41:16 --> Input Class Initialized
INFO - 2022-04-20 13:41:16 --> Language Class Initialized
INFO - 2022-04-20 13:41:16 --> Language Class Initialized
INFO - 2022-04-20 13:41:16 --> Config Class Initialized
INFO - 2022-04-20 13:41:16 --> Loader Class Initialized
INFO - 2022-04-20 13:41:16 --> Helper loaded: url_helper
INFO - 2022-04-20 13:41:16 --> Controller Class Initialized
DEBUG - 2022-04-20 13:41:16 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:41:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:41:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:41:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:41:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:41:16 --> Final output sent to browser
DEBUG - 2022-04-20 13:41:16 --> Total execution time: 0.0194
INFO - 2022-04-20 13:41:16 --> Config Class Initialized
INFO - 2022-04-20 13:41:16 --> Config Class Initialized
INFO - 2022-04-20 13:41:16 --> Hooks Class Initialized
INFO - 2022-04-20 13:41:16 --> Hooks Class Initialized
INFO - 2022-04-20 13:41:16 --> Config Class Initialized
INFO - 2022-04-20 13:41:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:41:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:41:16 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:41:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:41:16 --> Utf8 Class Initialized
DEBUG - 2022-04-20 13:41:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:41:16 --> URI Class Initialized
INFO - 2022-04-20 13:41:16 --> Utf8 Class Initialized
INFO - 2022-04-20 13:41:16 --> URI Class Initialized
INFO - 2022-04-20 13:41:16 --> Router Class Initialized
INFO - 2022-04-20 13:41:16 --> Router Class Initialized
INFO - 2022-04-20 13:41:16 --> Output Class Initialized
INFO - 2022-04-20 13:41:16 --> Output Class Initialized
INFO - 2022-04-20 13:41:16 --> Security Class Initialized
INFO - 2022-04-20 13:41:16 --> Security Class Initialized
DEBUG - 2022-04-20 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:41:16 --> Input Class Initialized
DEBUG - 2022-04-20 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:41:16 --> Language Class Initialized
ERROR - 2022-04-20 13:41:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:41:16 --> Input Class Initialized
INFO - 2022-04-20 13:41:16 --> Language Class Initialized
INFO - 2022-04-20 13:41:16 --> URI Class Initialized
ERROR - 2022-04-20 13:41:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:41:16 --> Router Class Initialized
INFO - 2022-04-20 13:41:16 --> Output Class Initialized
INFO - 2022-04-20 13:41:16 --> Security Class Initialized
DEBUG - 2022-04-20 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:41:16 --> Input Class Initialized
INFO - 2022-04-20 13:41:16 --> Language Class Initialized
ERROR - 2022-04-20 13:41:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:46:34 --> Config Class Initialized
INFO - 2022-04-20 13:46:34 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:46:35 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:46:35 --> Utf8 Class Initialized
INFO - 2022-04-20 13:46:35 --> URI Class Initialized
DEBUG - 2022-04-20 13:46:35 --> No URI present. Default controller set.
INFO - 2022-04-20 13:46:35 --> Router Class Initialized
INFO - 2022-04-20 13:46:35 --> Output Class Initialized
INFO - 2022-04-20 13:46:35 --> Security Class Initialized
DEBUG - 2022-04-20 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:46:35 --> Input Class Initialized
INFO - 2022-04-20 13:46:35 --> Language Class Initialized
INFO - 2022-04-20 13:46:35 --> Language Class Initialized
INFO - 2022-04-20 13:46:35 --> Config Class Initialized
INFO - 2022-04-20 13:46:35 --> Loader Class Initialized
INFO - 2022-04-20 13:46:35 --> Helper loaded: url_helper
INFO - 2022-04-20 13:46:35 --> Controller Class Initialized
DEBUG - 2022-04-20 13:46:35 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:46:35 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:46:35 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:46:35 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:46:35 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:46:35 --> Final output sent to browser
DEBUG - 2022-04-20 13:46:35 --> Total execution time: 0.0207
INFO - 2022-04-20 13:46:35 --> Config Class Initialized
INFO - 2022-04-20 13:46:35 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:46:35 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:46:35 --> Config Class Initialized
INFO - 2022-04-20 13:46:35 --> Hooks Class Initialized
INFO - 2022-04-20 13:46:35 --> Config Class Initialized
INFO - 2022-04-20 13:46:35 --> Utf8 Class Initialized
INFO - 2022-04-20 13:46:35 --> Hooks Class Initialized
INFO - 2022-04-20 13:46:35 --> URI Class Initialized
DEBUG - 2022-04-20 13:46:35 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:46:35 --> Utf8 Class Initialized
INFO - 2022-04-20 13:46:35 --> URI Class Initialized
INFO - 2022-04-20 13:46:35 --> Router Class Initialized
INFO - 2022-04-20 13:46:35 --> Output Class Initialized
INFO - 2022-04-20 13:46:35 --> Router Class Initialized
INFO - 2022-04-20 13:46:35 --> Security Class Initialized
INFO - 2022-04-20 13:46:35 --> Output Class Initialized
DEBUG - 2022-04-20 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:46:35 --> Input Class Initialized
INFO - 2022-04-20 13:46:35 --> Language Class Initialized
INFO - 2022-04-20 13:46:35 --> Security Class Initialized
ERROR - 2022-04-20 13:46:35 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 13:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:46:35 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:46:35 --> Input Class Initialized
INFO - 2022-04-20 13:46:35 --> Utf8 Class Initialized
INFO - 2022-04-20 13:46:35 --> Language Class Initialized
INFO - 2022-04-20 13:46:35 --> URI Class Initialized
ERROR - 2022-04-20 13:46:35 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:46:35 --> Router Class Initialized
INFO - 2022-04-20 13:46:35 --> Output Class Initialized
INFO - 2022-04-20 13:46:35 --> Security Class Initialized
DEBUG - 2022-04-20 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:46:35 --> Input Class Initialized
INFO - 2022-04-20 13:46:35 --> Language Class Initialized
ERROR - 2022-04-20 13:46:35 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:54:30 --> Config Class Initialized
INFO - 2022-04-20 13:54:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:54:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:54:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:54:30 --> URI Class Initialized
INFO - 2022-04-20 13:54:30 --> Router Class Initialized
INFO - 2022-04-20 13:54:30 --> Output Class Initialized
INFO - 2022-04-20 13:54:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:54:30 --> Input Class Initialized
INFO - 2022-04-20 13:54:30 --> Language Class Initialized
INFO - 2022-04-20 13:54:30 --> Language Class Initialized
INFO - 2022-04-20 13:54:30 --> Config Class Initialized
INFO - 2022-04-20 13:54:30 --> Loader Class Initialized
INFO - 2022-04-20 13:54:30 --> Helper loaded: url_helper
INFO - 2022-04-20 13:54:30 --> Controller Class Initialized
DEBUG - 2022-04-20 13:54:30 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 13:54:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:54:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:54:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 13:54:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:54:30 --> Final output sent to browser
DEBUG - 2022-04-20 13:54:30 --> Total execution time: 0.0202
INFO - 2022-04-20 13:54:30 --> Config Class Initialized
INFO - 2022-04-20 13:54:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:54:30 --> Config Class Initialized
INFO - 2022-04-20 13:54:30 --> Config Class Initialized
INFO - 2022-04-20 13:54:30 --> Hooks Class Initialized
INFO - 2022-04-20 13:54:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:54:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:54:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:54:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:54:30 --> URI Class Initialized
INFO - 2022-04-20 13:54:30 --> URI Class Initialized
INFO - 2022-04-20 13:54:30 --> Router Class Initialized
INFO - 2022-04-20 13:54:30 --> Router Class Initialized
INFO - 2022-04-20 13:54:30 --> Output Class Initialized
INFO - 2022-04-20 13:54:30 --> Output Class Initialized
INFO - 2022-04-20 13:54:30 --> Security Class Initialized
INFO - 2022-04-20 13:54:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:54:30 --> Input Class Initialized
INFO - 2022-04-20 13:54:30 --> Utf8 Class Initialized
INFO - 2022-04-20 13:54:30 --> Language Class Initialized
DEBUG - 2022-04-20 13:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:54:30 --> Input Class Initialized
INFO - 2022-04-20 13:54:30 --> URI Class Initialized
INFO - 2022-04-20 13:54:30 --> Language Class Initialized
ERROR - 2022-04-20 13:54:30 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:54:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:54:30 --> Router Class Initialized
INFO - 2022-04-20 13:54:30 --> Output Class Initialized
INFO - 2022-04-20 13:54:30 --> Security Class Initialized
DEBUG - 2022-04-20 13:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:54:30 --> Input Class Initialized
INFO - 2022-04-20 13:54:30 --> Language Class Initialized
ERROR - 2022-04-20 13:54:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:55:45 --> Config Class Initialized
INFO - 2022-04-20 13:55:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:55:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:55:45 --> Utf8 Class Initialized
INFO - 2022-04-20 13:55:45 --> URI Class Initialized
DEBUG - 2022-04-20 13:55:45 --> No URI present. Default controller set.
INFO - 2022-04-20 13:55:45 --> Router Class Initialized
INFO - 2022-04-20 13:55:45 --> Output Class Initialized
INFO - 2022-04-20 13:55:45 --> Security Class Initialized
DEBUG - 2022-04-20 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:55:45 --> Input Class Initialized
INFO - 2022-04-20 13:55:45 --> Language Class Initialized
INFO - 2022-04-20 13:55:45 --> Language Class Initialized
INFO - 2022-04-20 13:55:45 --> Config Class Initialized
INFO - 2022-04-20 13:55:45 --> Loader Class Initialized
INFO - 2022-04-20 13:55:45 --> Helper loaded: url_helper
INFO - 2022-04-20 13:55:45 --> Controller Class Initialized
DEBUG - 2022-04-20 13:55:45 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:55:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:55:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:55:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:55:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:55:45 --> Final output sent to browser
DEBUG - 2022-04-20 13:55:45 --> Total execution time: 0.0194
INFO - 2022-04-20 13:55:45 --> Config Class Initialized
INFO - 2022-04-20 13:55:45 --> Config Class Initialized
INFO - 2022-04-20 13:55:45 --> Hooks Class Initialized
INFO - 2022-04-20 13:55:45 --> Config Class Initialized
INFO - 2022-04-20 13:55:45 --> Hooks Class Initialized
INFO - 2022-04-20 13:55:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:55:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:55:45 --> Utf8 Class Initialized
INFO - 2022-04-20 13:55:45 --> Utf8 Class Initialized
INFO - 2022-04-20 13:55:45 --> Utf8 Class Initialized
INFO - 2022-04-20 13:55:45 --> URI Class Initialized
INFO - 2022-04-20 13:55:45 --> URI Class Initialized
INFO - 2022-04-20 13:55:45 --> URI Class Initialized
INFO - 2022-04-20 13:55:45 --> Router Class Initialized
INFO - 2022-04-20 13:55:45 --> Router Class Initialized
INFO - 2022-04-20 13:55:45 --> Router Class Initialized
INFO - 2022-04-20 13:55:45 --> Output Class Initialized
INFO - 2022-04-20 13:55:45 --> Output Class Initialized
INFO - 2022-04-20 13:55:45 --> Security Class Initialized
INFO - 2022-04-20 13:55:45 --> Output Class Initialized
INFO - 2022-04-20 13:55:45 --> Security Class Initialized
DEBUG - 2022-04-20 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:55:45 --> Security Class Initialized
INFO - 2022-04-20 13:55:45 --> Input Class Initialized
DEBUG - 2022-04-20 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:55:45 --> Input Class Initialized
INFO - 2022-04-20 13:55:45 --> Language Class Initialized
INFO - 2022-04-20 13:55:45 --> Language Class Initialized
DEBUG - 2022-04-20 13:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 13:55:45 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:55:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:55:45 --> Input Class Initialized
INFO - 2022-04-20 13:55:45 --> Language Class Initialized
ERROR - 2022-04-20 13:55:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:58:36 --> Config Class Initialized
INFO - 2022-04-20 13:58:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:58:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:58:36 --> Utf8 Class Initialized
INFO - 2022-04-20 13:58:36 --> URI Class Initialized
INFO - 2022-04-20 13:58:36 --> Router Class Initialized
INFO - 2022-04-20 13:58:36 --> Output Class Initialized
INFO - 2022-04-20 13:58:36 --> Security Class Initialized
DEBUG - 2022-04-20 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:58:36 --> Input Class Initialized
INFO - 2022-04-20 13:58:36 --> Language Class Initialized
INFO - 2022-04-20 13:58:36 --> Language Class Initialized
INFO - 2022-04-20 13:58:36 --> Config Class Initialized
INFO - 2022-04-20 13:58:36 --> Loader Class Initialized
INFO - 2022-04-20 13:58:36 --> Helper loaded: url_helper
INFO - 2022-04-20 13:58:36 --> Controller Class Initialized
DEBUG - 2022-04-20 13:58:36 --> About MX_Controller Initialized
DEBUG - 2022-04-20 13:58:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:58:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:58:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 13:58:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:58:36 --> Final output sent to browser
DEBUG - 2022-04-20 13:58:36 --> Total execution time: 0.0206
INFO - 2022-04-20 13:58:36 --> Config Class Initialized
INFO - 2022-04-20 13:58:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:58:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:58:36 --> Utf8 Class Initialized
INFO - 2022-04-20 13:58:36 --> Config Class Initialized
INFO - 2022-04-20 13:58:36 --> URI Class Initialized
INFO - 2022-04-20 13:58:36 --> Config Class Initialized
INFO - 2022-04-20 13:58:36 --> Router Class Initialized
INFO - 2022-04-20 13:58:36 --> Hooks Class Initialized
INFO - 2022-04-20 13:58:36 --> Hooks Class Initialized
INFO - 2022-04-20 13:58:36 --> Output Class Initialized
INFO - 2022-04-20 13:58:36 --> Security Class Initialized
DEBUG - 2022-04-20 13:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:58:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:58:36 --> Utf8 Class Initialized
INFO - 2022-04-20 13:58:36 --> Input Class Initialized
INFO - 2022-04-20 13:58:36 --> Utf8 Class Initialized
INFO - 2022-04-20 13:58:36 --> Language Class Initialized
INFO - 2022-04-20 13:58:36 --> URI Class Initialized
INFO - 2022-04-20 13:58:36 --> URI Class Initialized
ERROR - 2022-04-20 13:58:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:58:36 --> Router Class Initialized
INFO - 2022-04-20 13:58:36 --> Router Class Initialized
INFO - 2022-04-20 13:58:36 --> Output Class Initialized
INFO - 2022-04-20 13:58:36 --> Output Class Initialized
INFO - 2022-04-20 13:58:36 --> Security Class Initialized
INFO - 2022-04-20 13:58:36 --> Security Class Initialized
DEBUG - 2022-04-20 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:58:36 --> Input Class Initialized
DEBUG - 2022-04-20 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:58:36 --> Input Class Initialized
INFO - 2022-04-20 13:58:36 --> Language Class Initialized
INFO - 2022-04-20 13:58:36 --> Language Class Initialized
ERROR - 2022-04-20 13:58:36 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:58:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:59:15 --> Config Class Initialized
INFO - 2022-04-20 13:59:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 13:59:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:59:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:59:15 --> URI Class Initialized
DEBUG - 2022-04-20 13:59:15 --> No URI present. Default controller set.
INFO - 2022-04-20 13:59:15 --> Router Class Initialized
INFO - 2022-04-20 13:59:15 --> Output Class Initialized
INFO - 2022-04-20 13:59:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:59:15 --> Input Class Initialized
INFO - 2022-04-20 13:59:15 --> Language Class Initialized
INFO - 2022-04-20 13:59:15 --> Language Class Initialized
INFO - 2022-04-20 13:59:15 --> Config Class Initialized
INFO - 2022-04-20 13:59:15 --> Loader Class Initialized
INFO - 2022-04-20 13:59:15 --> Helper loaded: url_helper
INFO - 2022-04-20 13:59:15 --> Controller Class Initialized
DEBUG - 2022-04-20 13:59:15 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 13:59:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 13:59:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 13:59:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 13:59:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 13:59:15 --> Final output sent to browser
DEBUG - 2022-04-20 13:59:15 --> Total execution time: 0.0206
INFO - 2022-04-20 13:59:15 --> Config Class Initialized
INFO - 2022-04-20 13:59:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:59:15 --> Config Class Initialized
INFO - 2022-04-20 13:59:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:59:15 --> Config Class Initialized
DEBUG - 2022-04-20 13:59:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:59:15 --> Hooks Class Initialized
INFO - 2022-04-20 13:59:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:59:15 --> URI Class Initialized
DEBUG - 2022-04-20 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 13:59:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 13:59:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:59:15 --> Utf8 Class Initialized
INFO - 2022-04-20 13:59:15 --> URI Class Initialized
INFO - 2022-04-20 13:59:15 --> Router Class Initialized
INFO - 2022-04-20 13:59:15 --> URI Class Initialized
INFO - 2022-04-20 13:59:15 --> Output Class Initialized
INFO - 2022-04-20 13:59:15 --> Security Class Initialized
INFO - 2022-04-20 13:59:15 --> Router Class Initialized
INFO - 2022-04-20 13:59:15 --> Router Class Initialized
DEBUG - 2022-04-20 13:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:59:15 --> Input Class Initialized
INFO - 2022-04-20 13:59:15 --> Output Class Initialized
INFO - 2022-04-20 13:59:15 --> Language Class Initialized
INFO - 2022-04-20 13:59:15 --> Output Class Initialized
INFO - 2022-04-20 13:59:15 --> Security Class Initialized
ERROR - 2022-04-20 13:59:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 13:59:15 --> Security Class Initialized
DEBUG - 2022-04-20 13:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 13:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 13:59:15 --> Input Class Initialized
INFO - 2022-04-20 13:59:15 --> Input Class Initialized
INFO - 2022-04-20 13:59:15 --> Language Class Initialized
INFO - 2022-04-20 13:59:15 --> Language Class Initialized
ERROR - 2022-04-20 13:59:15 --> 404 Page Not Found: /index
ERROR - 2022-04-20 13:59:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:00:24 --> Config Class Initialized
INFO - 2022-04-20 14:00:24 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:00:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:00:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:00:24 --> URI Class Initialized
DEBUG - 2022-04-20 14:00:24 --> No URI present. Default controller set.
INFO - 2022-04-20 14:00:24 --> Router Class Initialized
INFO - 2022-04-20 14:00:24 --> Output Class Initialized
INFO - 2022-04-20 14:00:24 --> Security Class Initialized
DEBUG - 2022-04-20 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:00:24 --> Input Class Initialized
INFO - 2022-04-20 14:00:24 --> Language Class Initialized
INFO - 2022-04-20 14:00:24 --> Language Class Initialized
INFO - 2022-04-20 14:00:24 --> Config Class Initialized
INFO - 2022-04-20 14:00:24 --> Loader Class Initialized
INFO - 2022-04-20 14:00:24 --> Helper loaded: url_helper
INFO - 2022-04-20 14:00:24 --> Controller Class Initialized
DEBUG - 2022-04-20 14:00:24 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:00:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:00:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:00:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:00:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:00:24 --> Final output sent to browser
DEBUG - 2022-04-20 14:00:24 --> Total execution time: 0.0201
INFO - 2022-04-20 14:00:24 --> Config Class Initialized
INFO - 2022-04-20 14:00:24 --> Config Class Initialized
INFO - 2022-04-20 14:00:24 --> Hooks Class Initialized
INFO - 2022-04-20 14:00:24 --> Hooks Class Initialized
INFO - 2022-04-20 14:00:24 --> Config Class Initialized
INFO - 2022-04-20 14:00:24 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:00:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:00:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:00:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:00:24 --> URI Class Initialized
INFO - 2022-04-20 14:00:24 --> URI Class Initialized
DEBUG - 2022-04-20 14:00:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:00:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:00:24 --> URI Class Initialized
INFO - 2022-04-20 14:00:24 --> Router Class Initialized
INFO - 2022-04-20 14:00:24 --> Router Class Initialized
INFO - 2022-04-20 14:00:24 --> Router Class Initialized
INFO - 2022-04-20 14:00:24 --> Output Class Initialized
INFO - 2022-04-20 14:00:24 --> Output Class Initialized
INFO - 2022-04-20 14:00:24 --> Security Class Initialized
INFO - 2022-04-20 14:00:24 --> Security Class Initialized
DEBUG - 2022-04-20 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:00:24 --> Input Class Initialized
DEBUG - 2022-04-20 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:00:24 --> Input Class Initialized
INFO - 2022-04-20 14:00:24 --> Language Class Initialized
INFO - 2022-04-20 14:00:24 --> Language Class Initialized
ERROR - 2022-04-20 14:00:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:00:24 --> Output Class Initialized
ERROR - 2022-04-20 14:00:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:00:24 --> Security Class Initialized
DEBUG - 2022-04-20 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:00:24 --> Input Class Initialized
INFO - 2022-04-20 14:00:24 --> Language Class Initialized
ERROR - 2022-04-20 14:00:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:02:09 --> Config Class Initialized
INFO - 2022-04-20 14:02:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:02:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:02:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:02:09 --> URI Class Initialized
DEBUG - 2022-04-20 14:02:09 --> No URI present. Default controller set.
INFO - 2022-04-20 14:02:09 --> Router Class Initialized
INFO - 2022-04-20 14:02:09 --> Output Class Initialized
INFO - 2022-04-20 14:02:09 --> Security Class Initialized
DEBUG - 2022-04-20 14:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:02:09 --> Input Class Initialized
INFO - 2022-04-20 14:02:09 --> Language Class Initialized
INFO - 2022-04-20 14:02:09 --> Language Class Initialized
INFO - 2022-04-20 14:02:09 --> Config Class Initialized
INFO - 2022-04-20 14:02:09 --> Loader Class Initialized
INFO - 2022-04-20 14:02:09 --> Helper loaded: url_helper
INFO - 2022-04-20 14:02:09 --> Controller Class Initialized
DEBUG - 2022-04-20 14:02:09 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:02:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:02:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:02:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:02:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:02:09 --> Final output sent to browser
DEBUG - 2022-04-20 14:02:09 --> Total execution time: 0.0209
INFO - 2022-04-20 14:02:09 --> Config Class Initialized
INFO - 2022-04-20 14:02:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:02:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:02:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:02:09 --> Config Class Initialized
INFO - 2022-04-20 14:02:09 --> URI Class Initialized
INFO - 2022-04-20 14:02:09 --> Hooks Class Initialized
INFO - 2022-04-20 14:02:09 --> Router Class Initialized
DEBUG - 2022-04-20 14:02:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:02:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:02:09 --> Output Class Initialized
INFO - 2022-04-20 14:02:09 --> Config Class Initialized
INFO - 2022-04-20 14:02:09 --> Hooks Class Initialized
INFO - 2022-04-20 14:02:09 --> Security Class Initialized
DEBUG - 2022-04-20 14:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:02:09 --> Input Class Initialized
DEBUG - 2022-04-20 14:02:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:02:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:02:09 --> Language Class Initialized
INFO - 2022-04-20 14:02:09 --> URI Class Initialized
ERROR - 2022-04-20 14:02:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:02:09 --> Router Class Initialized
INFO - 2022-04-20 14:02:09 --> URI Class Initialized
INFO - 2022-04-20 14:02:09 --> Output Class Initialized
INFO - 2022-04-20 14:02:09 --> Security Class Initialized
INFO - 2022-04-20 14:02:09 --> Router Class Initialized
DEBUG - 2022-04-20 14:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:02:09 --> Input Class Initialized
INFO - 2022-04-20 14:02:09 --> Language Class Initialized
INFO - 2022-04-20 14:02:09 --> Output Class Initialized
ERROR - 2022-04-20 14:02:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:02:09 --> Security Class Initialized
DEBUG - 2022-04-20 14:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:02:09 --> Input Class Initialized
INFO - 2022-04-20 14:02:09 --> Language Class Initialized
ERROR - 2022-04-20 14:02:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:03:36 --> Config Class Initialized
INFO - 2022-04-20 14:03:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:03:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:36 --> URI Class Initialized
DEBUG - 2022-04-20 14:03:36 --> No URI present. Default controller set.
INFO - 2022-04-20 14:03:36 --> Router Class Initialized
INFO - 2022-04-20 14:03:36 --> Output Class Initialized
INFO - 2022-04-20 14:03:36 --> Security Class Initialized
DEBUG - 2022-04-20 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:36 --> Input Class Initialized
INFO - 2022-04-20 14:03:36 --> Language Class Initialized
INFO - 2022-04-20 14:03:36 --> Language Class Initialized
INFO - 2022-04-20 14:03:36 --> Config Class Initialized
INFO - 2022-04-20 14:03:36 --> Loader Class Initialized
INFO - 2022-04-20 14:03:36 --> Helper loaded: url_helper
INFO - 2022-04-20 14:03:36 --> Controller Class Initialized
DEBUG - 2022-04-20 14:03:36 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:03:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:03:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:03:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:03:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:03:36 --> Final output sent to browser
DEBUG - 2022-04-20 14:03:36 --> Total execution time: 0.0203
INFO - 2022-04-20 14:03:36 --> Config Class Initialized
INFO - 2022-04-20 14:03:36 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:36 --> Config Class Initialized
INFO - 2022-04-20 14:03:36 --> Config Class Initialized
INFO - 2022-04-20 14:03:36 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:03:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:36 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:03:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:36 --> URI Class Initialized
DEBUG - 2022-04-20 14:03:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:36 --> URI Class Initialized
INFO - 2022-04-20 14:03:36 --> URI Class Initialized
INFO - 2022-04-20 14:03:36 --> Router Class Initialized
INFO - 2022-04-20 14:03:36 --> Router Class Initialized
INFO - 2022-04-20 14:03:36 --> Output Class Initialized
INFO - 2022-04-20 14:03:36 --> Router Class Initialized
INFO - 2022-04-20 14:03:36 --> Output Class Initialized
INFO - 2022-04-20 14:03:36 --> Security Class Initialized
INFO - 2022-04-20 14:03:36 --> Output Class Initialized
DEBUG - 2022-04-20 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:36 --> Security Class Initialized
INFO - 2022-04-20 14:03:36 --> Input Class Initialized
INFO - 2022-04-20 14:03:36 --> Security Class Initialized
INFO - 2022-04-20 14:03:36 --> Language Class Initialized
DEBUG - 2022-04-20 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:36 --> Input Class Initialized
DEBUG - 2022-04-20 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:36 --> Language Class Initialized
ERROR - 2022-04-20 14:03:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:03:36 --> Input Class Initialized
INFO - 2022-04-20 14:03:36 --> Language Class Initialized
ERROR - 2022-04-20 14:03:36 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:03:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:03:43 --> Config Class Initialized
INFO - 2022-04-20 14:03:43 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:03:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:43 --> URI Class Initialized
INFO - 2022-04-20 14:03:43 --> Router Class Initialized
INFO - 2022-04-20 14:03:43 --> Output Class Initialized
INFO - 2022-04-20 14:03:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:43 --> Input Class Initialized
INFO - 2022-04-20 14:03:43 --> Language Class Initialized
INFO - 2022-04-20 14:03:43 --> Language Class Initialized
INFO - 2022-04-20 14:03:43 --> Config Class Initialized
INFO - 2022-04-20 14:03:43 --> Loader Class Initialized
INFO - 2022-04-20 14:03:43 --> Helper loaded: url_helper
INFO - 2022-04-20 14:03:43 --> Controller Class Initialized
DEBUG - 2022-04-20 14:03:43 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:03:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:03:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:03:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:03:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:03:43 --> Final output sent to browser
DEBUG - 2022-04-20 14:03:43 --> Total execution time: 0.0184
INFO - 2022-04-20 14:03:43 --> Config Class Initialized
INFO - 2022-04-20 14:03:43 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:43 --> Config Class Initialized
DEBUG - 2022-04-20 14:03:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:43 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:43 --> URI Class Initialized
INFO - 2022-04-20 14:03:43 --> Router Class Initialized
DEBUG - 2022-04-20 14:03:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:43 --> Output Class Initialized
INFO - 2022-04-20 14:03:43 --> URI Class Initialized
INFO - 2022-04-20 14:03:43 --> Security Class Initialized
INFO - 2022-04-20 14:03:43 --> Config Class Initialized
INFO - 2022-04-20 14:03:43 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:43 --> Router Class Initialized
DEBUG - 2022-04-20 14:03:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:43 --> URI Class Initialized
INFO - 2022-04-20 14:03:43 --> Output Class Initialized
INFO - 2022-04-20 14:03:43 --> Security Class Initialized
INFO - 2022-04-20 14:03:43 --> Router Class Initialized
DEBUG - 2022-04-20 14:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:43 --> Output Class Initialized
INFO - 2022-04-20 14:03:43 --> Input Class Initialized
INFO - 2022-04-20 14:03:43 --> Language Class Initialized
DEBUG - 2022-04-20 14:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:43 --> Security Class Initialized
INFO - 2022-04-20 14:03:43 --> Input Class Initialized
INFO - 2022-04-20 14:03:43 --> Language Class Initialized
ERROR - 2022-04-20 14:03:43 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:43 --> Input Class Initialized
ERROR - 2022-04-20 14:03:43 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:03:43 --> Language Class Initialized
ERROR - 2022-04-20 14:03:43 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:03:50 --> Config Class Initialized
INFO - 2022-04-20 14:03:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:03:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:50 --> URI Class Initialized
INFO - 2022-04-20 14:03:50 --> Router Class Initialized
INFO - 2022-04-20 14:03:50 --> Output Class Initialized
INFO - 2022-04-20 14:03:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:50 --> Input Class Initialized
INFO - 2022-04-20 14:03:50 --> Language Class Initialized
INFO - 2022-04-20 14:03:50 --> Language Class Initialized
INFO - 2022-04-20 14:03:50 --> Config Class Initialized
INFO - 2022-04-20 14:03:50 --> Loader Class Initialized
INFO - 2022-04-20 14:03:50 --> Helper loaded: url_helper
INFO - 2022-04-20 14:03:50 --> Controller Class Initialized
DEBUG - 2022-04-20 14:03:50 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:03:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:03:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:03:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:03:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:03:50 --> Final output sent to browser
DEBUG - 2022-04-20 14:03:50 --> Total execution time: 0.0177
INFO - 2022-04-20 14:03:50 --> Config Class Initialized
INFO - 2022-04-20 14:03:50 --> Config Class Initialized
INFO - 2022-04-20 14:03:50 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:03:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:50 --> URI Class Initialized
INFO - 2022-04-20 14:03:50 --> URI Class Initialized
INFO - 2022-04-20 14:03:50 --> Router Class Initialized
INFO - 2022-04-20 14:03:50 --> Router Class Initialized
INFO - 2022-04-20 14:03:50 --> Output Class Initialized
INFO - 2022-04-20 14:03:50 --> Output Class Initialized
INFO - 2022-04-20 14:03:50 --> Security Class Initialized
INFO - 2022-04-20 14:03:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:50 --> Input Class Initialized
DEBUG - 2022-04-20 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:50 --> Input Class Initialized
INFO - 2022-04-20 14:03:50 --> Config Class Initialized
INFO - 2022-04-20 14:03:50 --> Language Class Initialized
INFO - 2022-04-20 14:03:50 --> Hooks Class Initialized
INFO - 2022-04-20 14:03:50 --> Language Class Initialized
ERROR - 2022-04-20 14:03:50 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:03:50 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:03:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:03:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:03:50 --> URI Class Initialized
INFO - 2022-04-20 14:03:50 --> Router Class Initialized
INFO - 2022-04-20 14:03:50 --> Output Class Initialized
INFO - 2022-04-20 14:03:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:03:50 --> Input Class Initialized
INFO - 2022-04-20 14:03:50 --> Language Class Initialized
ERROR - 2022-04-20 14:03:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:50 --> Config Class Initialized
INFO - 2022-04-20 14:04:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:50 --> URI Class Initialized
INFO - 2022-04-20 14:04:50 --> Router Class Initialized
INFO - 2022-04-20 14:04:50 --> Output Class Initialized
INFO - 2022-04-20 14:04:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:50 --> Input Class Initialized
INFO - 2022-04-20 14:04:50 --> Language Class Initialized
INFO - 2022-04-20 14:04:50 --> Language Class Initialized
INFO - 2022-04-20 14:04:50 --> Config Class Initialized
INFO - 2022-04-20 14:04:50 --> Loader Class Initialized
INFO - 2022-04-20 14:04:50 --> Helper loaded: url_helper
INFO - 2022-04-20 14:04:50 --> Controller Class Initialized
DEBUG - 2022-04-20 14:04:50 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:04:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:04:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:04:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:04:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:04:50 --> Final output sent to browser
DEBUG - 2022-04-20 14:04:50 --> Total execution time: 0.0204
INFO - 2022-04-20 14:04:50 --> Config Class Initialized
INFO - 2022-04-20 14:04:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:50 --> Config Class Initialized
INFO - 2022-04-20 14:04:50 --> Hooks Class Initialized
INFO - 2022-04-20 14:04:50 --> URI Class Initialized
INFO - 2022-04-20 14:04:50 --> Config Class Initialized
INFO - 2022-04-20 14:04:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:50 --> Router Class Initialized
INFO - 2022-04-20 14:04:50 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:04:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:50 --> Output Class Initialized
INFO - 2022-04-20 14:04:50 --> URI Class Initialized
INFO - 2022-04-20 14:04:50 --> URI Class Initialized
INFO - 2022-04-20 14:04:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:50 --> Router Class Initialized
INFO - 2022-04-20 14:04:50 --> Input Class Initialized
INFO - 2022-04-20 14:04:50 --> Language Class Initialized
INFO - 2022-04-20 14:04:50 --> Output Class Initialized
ERROR - 2022-04-20 14:04:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:50 --> Input Class Initialized
INFO - 2022-04-20 14:04:50 --> Language Class Initialized
INFO - 2022-04-20 14:04:50 --> Router Class Initialized
ERROR - 2022-04-20 14:04:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:50 --> Output Class Initialized
INFO - 2022-04-20 14:04:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:50 --> Input Class Initialized
INFO - 2022-04-20 14:04:50 --> Language Class Initialized
ERROR - 2022-04-20 14:04:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:54 --> URI Class Initialized
INFO - 2022-04-20 14:04:54 --> Router Class Initialized
INFO - 2022-04-20 14:04:54 --> Output Class Initialized
INFO - 2022-04-20 14:04:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:54 --> Input Class Initialized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Loader Class Initialized
INFO - 2022-04-20 14:04:54 --> Helper loaded: url_helper
INFO - 2022-04-20 14:04:54 --> Controller Class Initialized
DEBUG - 2022-04-20 14:04:54 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:04:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:04:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:04:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:04:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:04:54 --> Final output sent to browser
DEBUG - 2022-04-20 14:04:54 --> Total execution time: 0.0189
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Hooks Class Initialized
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Hooks Class Initialized
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:04:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:54 --> URI Class Initialized
INFO - 2022-04-20 14:04:54 --> URI Class Initialized
INFO - 2022-04-20 14:04:54 --> Router Class Initialized
INFO - 2022-04-20 14:04:54 --> Router Class Initialized
DEBUG - 2022-04-20 14:04:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:54 --> URI Class Initialized
INFO - 2022-04-20 14:04:54 --> Output Class Initialized
INFO - 2022-04-20 14:04:54 --> Output Class Initialized
INFO - 2022-04-20 14:04:54 --> Security Class Initialized
INFO - 2022-04-20 14:04:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:54 --> Router Class Initialized
INFO - 2022-04-20 14:04:54 --> Input Class Initialized
DEBUG - 2022-04-20 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
INFO - 2022-04-20 14:04:54 --> Input Class Initialized
INFO - 2022-04-20 14:04:54 --> Output Class Initialized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
ERROR - 2022-04-20 14:04:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:54 --> Security Class Initialized
ERROR - 2022-04-20 14:04:54 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:54 --> Input Class Initialized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
ERROR - 2022-04-20 14:04:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:54 --> URI Class Initialized
INFO - 2022-04-20 14:04:54 --> Router Class Initialized
INFO - 2022-04-20 14:04:54 --> Output Class Initialized
INFO - 2022-04-20 14:04:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:54 --> Input Class Initialized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
ERROR - 2022-04-20 14:04:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:04:54 --> Config Class Initialized
INFO - 2022-04-20 14:04:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:04:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:04:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:04:54 --> URI Class Initialized
INFO - 2022-04-20 14:04:54 --> Router Class Initialized
INFO - 2022-04-20 14:04:54 --> Output Class Initialized
INFO - 2022-04-20 14:04:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:04:54 --> Input Class Initialized
INFO - 2022-04-20 14:04:54 --> Language Class Initialized
ERROR - 2022-04-20 14:04:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:05:03 --> Config Class Initialized
INFO - 2022-04-20 14:05:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:05:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:05:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:05:03 --> URI Class Initialized
INFO - 2022-04-20 14:05:03 --> Router Class Initialized
INFO - 2022-04-20 14:05:03 --> Output Class Initialized
INFO - 2022-04-20 14:05:03 --> Security Class Initialized
DEBUG - 2022-04-20 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:05:03 --> Input Class Initialized
INFO - 2022-04-20 14:05:03 --> Language Class Initialized
INFO - 2022-04-20 14:05:03 --> Language Class Initialized
INFO - 2022-04-20 14:05:03 --> Config Class Initialized
INFO - 2022-04-20 14:05:03 --> Loader Class Initialized
INFO - 2022-04-20 14:05:03 --> Helper loaded: url_helper
INFO - 2022-04-20 14:05:03 --> Controller Class Initialized
DEBUG - 2022-04-20 14:05:03 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:05:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:05:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:05:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:05:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:05:03 --> Final output sent to browser
DEBUG - 2022-04-20 14:05:03 --> Total execution time: 0.0192
INFO - 2022-04-20 14:05:03 --> Config Class Initialized
INFO - 2022-04-20 14:05:03 --> Hooks Class Initialized
INFO - 2022-04-20 14:05:03 --> Config Class Initialized
INFO - 2022-04-20 14:05:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:05:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:05:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:05:03 --> URI Class Initialized
DEBUG - 2022-04-20 14:05:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:05:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:05:03 --> URI Class Initialized
INFO - 2022-04-20 14:05:03 --> Router Class Initialized
INFO - 2022-04-20 14:05:03 --> Router Class Initialized
INFO - 2022-04-20 14:05:03 --> Output Class Initialized
INFO - 2022-04-20 14:05:03 --> Security Class Initialized
INFO - 2022-04-20 14:05:03 --> Output Class Initialized
INFO - 2022-04-20 14:05:03 --> Security Class Initialized
DEBUG - 2022-04-20 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:05:03 --> Input Class Initialized
INFO - 2022-04-20 14:05:03 --> Language Class Initialized
DEBUG - 2022-04-20 14:05:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 14:05:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:05:03 --> Config Class Initialized
INFO - 2022-04-20 14:05:03 --> Hooks Class Initialized
INFO - 2022-04-20 14:05:03 --> Input Class Initialized
INFO - 2022-04-20 14:05:03 --> Language Class Initialized
DEBUG - 2022-04-20 14:05:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:05:03 --> Utf8 Class Initialized
ERROR - 2022-04-20 14:05:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:05:03 --> URI Class Initialized
INFO - 2022-04-20 14:05:03 --> Router Class Initialized
INFO - 2022-04-20 14:05:04 --> Output Class Initialized
INFO - 2022-04-20 14:05:04 --> Security Class Initialized
DEBUG - 2022-04-20 14:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:05:04 --> Input Class Initialized
INFO - 2022-04-20 14:05:04 --> Language Class Initialized
ERROR - 2022-04-20 14:05:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:05:04 --> Config Class Initialized
INFO - 2022-04-20 14:05:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:05:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:05:04 --> Utf8 Class Initialized
INFO - 2022-04-20 14:05:04 --> URI Class Initialized
INFO - 2022-04-20 14:05:04 --> Router Class Initialized
INFO - 2022-04-20 14:05:04 --> Output Class Initialized
INFO - 2022-04-20 14:05:04 --> Security Class Initialized
DEBUG - 2022-04-20 14:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:05:04 --> Input Class Initialized
INFO - 2022-04-20 14:05:04 --> Language Class Initialized
ERROR - 2022-04-20 14:05:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:05:04 --> Config Class Initialized
INFO - 2022-04-20 14:05:04 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:05:04 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:05:04 --> Utf8 Class Initialized
INFO - 2022-04-20 14:05:04 --> URI Class Initialized
INFO - 2022-04-20 14:05:04 --> Router Class Initialized
INFO - 2022-04-20 14:05:04 --> Output Class Initialized
INFO - 2022-04-20 14:05:04 --> Security Class Initialized
DEBUG - 2022-04-20 14:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:05:04 --> Input Class Initialized
INFO - 2022-04-20 14:05:04 --> Language Class Initialized
ERROR - 2022-04-20 14:05:04 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:10 --> Config Class Initialized
INFO - 2022-04-20 14:07:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:10 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:10 --> URI Class Initialized
INFO - 2022-04-20 14:07:10 --> Router Class Initialized
INFO - 2022-04-20 14:07:10 --> Output Class Initialized
INFO - 2022-04-20 14:07:10 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:10 --> Input Class Initialized
INFO - 2022-04-20 14:07:10 --> Language Class Initialized
INFO - 2022-04-20 14:07:10 --> Language Class Initialized
INFO - 2022-04-20 14:07:10 --> Config Class Initialized
INFO - 2022-04-20 14:07:10 --> Loader Class Initialized
INFO - 2022-04-20 14:07:10 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:10 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:10 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:07:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:07:10 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:10 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:10 --> Total execution time: 0.0198
INFO - 2022-04-20 14:07:10 --> Config Class Initialized
INFO - 2022-04-20 14:07:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:10 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:10 --> Config Class Initialized
INFO - 2022-04-20 14:07:10 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:10 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:10 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:10 --> Router Class Initialized
INFO - 2022-04-20 14:07:10 --> URI Class Initialized
INFO - 2022-04-20 14:07:10 --> Output Class Initialized
INFO - 2022-04-20 14:07:10 --> Security Class Initialized
INFO - 2022-04-20 14:07:10 --> Router Class Initialized
DEBUG - 2022-04-20 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:10 --> Input Class Initialized
INFO - 2022-04-20 14:07:10 --> Output Class Initialized
INFO - 2022-04-20 14:07:10 --> Language Class Initialized
INFO - 2022-04-20 14:07:10 --> Security Class Initialized
ERROR - 2022-04-20 14:07:10 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:10 --> Input Class Initialized
INFO - 2022-04-20 14:07:10 --> Language Class Initialized
ERROR - 2022-04-20 14:07:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:10 --> Config Class Initialized
INFO - 2022-04-20 14:07:10 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:10 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:10 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:10 --> URI Class Initialized
INFO - 2022-04-20 14:07:10 --> Router Class Initialized
INFO - 2022-04-20 14:07:10 --> Output Class Initialized
INFO - 2022-04-20 14:07:10 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:10 --> Input Class Initialized
INFO - 2022-04-20 14:07:10 --> Language Class Initialized
ERROR - 2022-04-20 14:07:10 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:11 --> Config Class Initialized
INFO - 2022-04-20 14:07:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:11 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:11 --> URI Class Initialized
INFO - 2022-04-20 14:07:11 --> Router Class Initialized
INFO - 2022-04-20 14:07:11 --> Output Class Initialized
INFO - 2022-04-20 14:07:11 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:11 --> Input Class Initialized
INFO - 2022-04-20 14:07:11 --> Language Class Initialized
ERROR - 2022-04-20 14:07:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:11 --> Config Class Initialized
INFO - 2022-04-20 14:07:11 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:11 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:11 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:11 --> URI Class Initialized
INFO - 2022-04-20 14:07:11 --> Router Class Initialized
INFO - 2022-04-20 14:07:11 --> Output Class Initialized
INFO - 2022-04-20 14:07:11 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:11 --> Input Class Initialized
INFO - 2022-04-20 14:07:11 --> Language Class Initialized
ERROR - 2022-04-20 14:07:11 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:37 --> Config Class Initialized
INFO - 2022-04-20 14:07:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:37 --> URI Class Initialized
INFO - 2022-04-20 14:07:37 --> Router Class Initialized
INFO - 2022-04-20 14:07:37 --> Output Class Initialized
INFO - 2022-04-20 14:07:37 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:37 --> Input Class Initialized
INFO - 2022-04-20 14:07:37 --> Language Class Initialized
INFO - 2022-04-20 14:07:37 --> Language Class Initialized
INFO - 2022-04-20 14:07:37 --> Config Class Initialized
INFO - 2022-04-20 14:07:37 --> Loader Class Initialized
INFO - 2022-04-20 14:07:37 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:37 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:37 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:07:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:07:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:37 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:37 --> Total execution time: 0.0181
INFO - 2022-04-20 14:07:37 --> Config Class Initialized
INFO - 2022-04-20 14:07:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:37 --> Config Class Initialized
INFO - 2022-04-20 14:07:37 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:37 --> Config Class Initialized
INFO - 2022-04-20 14:07:37 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:37 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:07:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:37 --> Router Class Initialized
INFO - 2022-04-20 14:07:37 --> URI Class Initialized
INFO - 2022-04-20 14:07:37 --> URI Class Initialized
INFO - 2022-04-20 14:07:37 --> Output Class Initialized
INFO - 2022-04-20 14:07:37 --> Router Class Initialized
INFO - 2022-04-20 14:07:37 --> Router Class Initialized
INFO - 2022-04-20 14:07:37 --> Security Class Initialized
INFO - 2022-04-20 14:07:37 --> Output Class Initialized
INFO - 2022-04-20 14:07:37 --> Output Class Initialized
INFO - 2022-04-20 14:07:37 --> Security Class Initialized
INFO - 2022-04-20 14:07:37 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:37 --> Input Class Initialized
INFO - 2022-04-20 14:07:37 --> Input Class Initialized
INFO - 2022-04-20 14:07:37 --> Language Class Initialized
INFO - 2022-04-20 14:07:37 --> Language Class Initialized
ERROR - 2022-04-20 14:07:37 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:07:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:37 --> Input Class Initialized
INFO - 2022-04-20 14:07:37 --> Language Class Initialized
ERROR - 2022-04-20 14:07:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:38 --> Config Class Initialized
INFO - 2022-04-20 14:07:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:38 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:38 --> URI Class Initialized
INFO - 2022-04-20 14:07:38 --> Router Class Initialized
INFO - 2022-04-20 14:07:38 --> Output Class Initialized
INFO - 2022-04-20 14:07:38 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:38 --> Input Class Initialized
INFO - 2022-04-20 14:07:38 --> Language Class Initialized
ERROR - 2022-04-20 14:07:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:38 --> Config Class Initialized
INFO - 2022-04-20 14:07:38 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:38 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:38 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:38 --> URI Class Initialized
INFO - 2022-04-20 14:07:38 --> Router Class Initialized
INFO - 2022-04-20 14:07:38 --> Output Class Initialized
INFO - 2022-04-20 14:07:38 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:38 --> Input Class Initialized
INFO - 2022-04-20 14:07:38 --> Language Class Initialized
ERROR - 2022-04-20 14:07:38 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:45 --> Config Class Initialized
INFO - 2022-04-20 14:07:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:45 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:45 --> URI Class Initialized
INFO - 2022-04-20 14:07:45 --> Router Class Initialized
INFO - 2022-04-20 14:07:45 --> Output Class Initialized
INFO - 2022-04-20 14:07:45 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:45 --> Input Class Initialized
INFO - 2022-04-20 14:07:45 --> Language Class Initialized
INFO - 2022-04-20 14:07:45 --> Language Class Initialized
INFO - 2022-04-20 14:07:45 --> Config Class Initialized
INFO - 2022-04-20 14:07:45 --> Loader Class Initialized
INFO - 2022-04-20 14:07:45 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:45 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:45 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 14:07:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 14:07:45 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:45 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:45 --> Total execution time: 0.0191
INFO - 2022-04-20 14:07:45 --> Config Class Initialized
INFO - 2022-04-20 14:07:45 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:45 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:45 --> URI Class Initialized
INFO - 2022-04-20 14:07:45 --> Router Class Initialized
INFO - 2022-04-20 14:07:45 --> Output Class Initialized
INFO - 2022-04-20 14:07:45 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:45 --> Input Class Initialized
INFO - 2022-04-20 14:07:45 --> Config Class Initialized
INFO - 2022-04-20 14:07:45 --> Config Class Initialized
INFO - 2022-04-20 14:07:45 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:45 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:45 --> Language Class Initialized
ERROR - 2022-04-20 14:07:45 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:07:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:45 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:45 --> URI Class Initialized
INFO - 2022-04-20 14:07:45 --> Router Class Initialized
DEBUG - 2022-04-20 14:07:45 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:45 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:45 --> Output Class Initialized
INFO - 2022-04-20 14:07:45 --> Security Class Initialized
INFO - 2022-04-20 14:07:45 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:45 --> Input Class Initialized
INFO - 2022-04-20 14:07:45 --> Language Class Initialized
ERROR - 2022-04-20 14:07:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:45 --> Router Class Initialized
INFO - 2022-04-20 14:07:45 --> Output Class Initialized
INFO - 2022-04-20 14:07:45 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:45 --> Input Class Initialized
INFO - 2022-04-20 14:07:45 --> Language Class Initialized
ERROR - 2022-04-20 14:07:45 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:53 --> Config Class Initialized
INFO - 2022-04-20 14:07:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:53 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:53 --> URI Class Initialized
INFO - 2022-04-20 14:07:53 --> Router Class Initialized
INFO - 2022-04-20 14:07:53 --> Output Class Initialized
INFO - 2022-04-20 14:07:53 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:53 --> Input Class Initialized
INFO - 2022-04-20 14:07:53 --> Language Class Initialized
INFO - 2022-04-20 14:07:53 --> Language Class Initialized
INFO - 2022-04-20 14:07:53 --> Config Class Initialized
INFO - 2022-04-20 14:07:53 --> Loader Class Initialized
INFO - 2022-04-20 14:07:53 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:53 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:53 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:07:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:07:53 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:53 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:53 --> Total execution time: 0.0184
INFO - 2022-04-20 14:07:53 --> Config Class Initialized
INFO - 2022-04-20 14:07:53 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:53 --> Config Class Initialized
INFO - 2022-04-20 14:07:53 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:53 --> Config Class Initialized
INFO - 2022-04-20 14:07:53 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:53 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:53 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:53 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:53 --> URI Class Initialized
INFO - 2022-04-20 14:07:53 --> Router Class Initialized
INFO - 2022-04-20 14:07:53 --> Output Class Initialized
INFO - 2022-04-20 14:07:53 --> Router Class Initialized
INFO - 2022-04-20 14:07:53 --> Security Class Initialized
INFO - 2022-04-20 14:07:53 --> Output Class Initialized
DEBUG - 2022-04-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:53 --> Input Class Initialized
INFO - 2022-04-20 14:07:53 --> Security Class Initialized
INFO - 2022-04-20 14:07:53 --> Language Class Initialized
DEBUG - 2022-04-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:53 --> Input Class Initialized
ERROR - 2022-04-20 14:07:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:53 --> Language Class Initialized
ERROR - 2022-04-20 14:07:53 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:07:53 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:53 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:53 --> URI Class Initialized
INFO - 2022-04-20 14:07:53 --> Router Class Initialized
INFO - 2022-04-20 14:07:53 --> Output Class Initialized
INFO - 2022-04-20 14:07:53 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:53 --> Input Class Initialized
INFO - 2022-04-20 14:07:53 --> Language Class Initialized
ERROR - 2022-04-20 14:07:53 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:54 --> Config Class Initialized
INFO - 2022-04-20 14:07:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:54 --> URI Class Initialized
INFO - 2022-04-20 14:07:54 --> Router Class Initialized
INFO - 2022-04-20 14:07:54 --> Output Class Initialized
INFO - 2022-04-20 14:07:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:54 --> Input Class Initialized
INFO - 2022-04-20 14:07:54 --> Language Class Initialized
INFO - 2022-04-20 14:07:54 --> Language Class Initialized
INFO - 2022-04-20 14:07:54 --> Config Class Initialized
INFO - 2022-04-20 14:07:54 --> Loader Class Initialized
INFO - 2022-04-20 14:07:54 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:54 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:54 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 14:07:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 14:07:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:54 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:54 --> Total execution time: 0.0194
INFO - 2022-04-20 14:07:54 --> Config Class Initialized
INFO - 2022-04-20 14:07:54 --> Config Class Initialized
INFO - 2022-04-20 14:07:54 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:07:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:54 --> URI Class Initialized
INFO - 2022-04-20 14:07:54 --> URI Class Initialized
INFO - 2022-04-20 14:07:54 --> Config Class Initialized
INFO - 2022-04-20 14:07:54 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:54 --> Router Class Initialized
INFO - 2022-04-20 14:07:54 --> Router Class Initialized
INFO - 2022-04-20 14:07:54 --> Output Class Initialized
INFO - 2022-04-20 14:07:54 --> Output Class Initialized
DEBUG - 2022-04-20 14:07:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:54 --> Security Class Initialized
INFO - 2022-04-20 14:07:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:54 --> Input Class Initialized
INFO - 2022-04-20 14:07:54 --> Input Class Initialized
INFO - 2022-04-20 14:07:54 --> Language Class Initialized
INFO - 2022-04-20 14:07:54 --> Language Class Initialized
ERROR - 2022-04-20 14:07:54 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:07:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:54 --> URI Class Initialized
INFO - 2022-04-20 14:07:54 --> Router Class Initialized
INFO - 2022-04-20 14:07:54 --> Output Class Initialized
INFO - 2022-04-20 14:07:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:54 --> Input Class Initialized
INFO - 2022-04-20 14:07:54 --> Language Class Initialized
ERROR - 2022-04-20 14:07:54 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:55 --> URI Class Initialized
INFO - 2022-04-20 14:07:55 --> Router Class Initialized
INFO - 2022-04-20 14:07:55 --> Output Class Initialized
INFO - 2022-04-20 14:07:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:55 --> Input Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Loader Class Initialized
INFO - 2022-04-20 14:07:55 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:55 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:55 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:07:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:07:55 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:55 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:55 --> Total execution time: 0.0197
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:55 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:55 --> URI Class Initialized
INFO - 2022-04-20 14:07:55 --> Router Class Initialized
INFO - 2022-04-20 14:07:55 --> Output Class Initialized
INFO - 2022-04-20 14:07:55 --> Router Class Initialized
INFO - 2022-04-20 14:07:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:55 --> Input Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
INFO - 2022-04-20 14:07:55 --> Output Class Initialized
ERROR - 2022-04-20 14:07:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:55 --> Input Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
DEBUG - 2022-04-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:55 --> Utf8 Class Initialized
ERROR - 2022-04-20 14:07:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:55 --> URI Class Initialized
INFO - 2022-04-20 14:07:55 --> Router Class Initialized
INFO - 2022-04-20 14:07:55 --> Output Class Initialized
INFO - 2022-04-20 14:07:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:55 --> Input Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
ERROR - 2022-04-20 14:07:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:55 --> URI Class Initialized
INFO - 2022-04-20 14:07:55 --> Router Class Initialized
INFO - 2022-04-20 14:07:55 --> Output Class Initialized
INFO - 2022-04-20 14:07:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:55 --> Input Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
ERROR - 2022-04-20 14:07:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:55 --> Config Class Initialized
INFO - 2022-04-20 14:07:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:55 --> URI Class Initialized
INFO - 2022-04-20 14:07:55 --> Router Class Initialized
INFO - 2022-04-20 14:07:55 --> Output Class Initialized
INFO - 2022-04-20 14:07:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:55 --> Input Class Initialized
INFO - 2022-04-20 14:07:55 --> Language Class Initialized
ERROR - 2022-04-20 14:07:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:58 --> Config Class Initialized
INFO - 2022-04-20 14:07:58 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:58 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:58 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:58 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:58 --> No URI present. Default controller set.
INFO - 2022-04-20 14:07:58 --> Router Class Initialized
INFO - 2022-04-20 14:07:58 --> Output Class Initialized
INFO - 2022-04-20 14:07:58 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:58 --> Input Class Initialized
INFO - 2022-04-20 14:07:58 --> Language Class Initialized
INFO - 2022-04-20 14:07:58 --> Language Class Initialized
INFO - 2022-04-20 14:07:58 --> Config Class Initialized
INFO - 2022-04-20 14:07:58 --> Loader Class Initialized
INFO - 2022-04-20 14:07:58 --> Helper loaded: url_helper
INFO - 2022-04-20 14:07:58 --> Controller Class Initialized
DEBUG - 2022-04-20 14:07:58 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:07:58 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:07:58 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:07:58 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:07:58 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:07:58 --> Final output sent to browser
DEBUG - 2022-04-20 14:07:58 --> Total execution time: 0.0206
INFO - 2022-04-20 14:07:58 --> Config Class Initialized
INFO - 2022-04-20 14:07:58 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:58 --> Config Class Initialized
INFO - 2022-04-20 14:07:58 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:07:58 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:58 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:58 --> URI Class Initialized
INFO - 2022-04-20 14:07:58 --> Config Class Initialized
INFO - 2022-04-20 14:07:58 --> Hooks Class Initialized
INFO - 2022-04-20 14:07:58 --> Router Class Initialized
INFO - 2022-04-20 14:07:58 --> Output Class Initialized
DEBUG - 2022-04-20 14:07:58 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:07:58 --> Security Class Initialized
INFO - 2022-04-20 14:07:58 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:58 --> URI Class Initialized
DEBUG - 2022-04-20 14:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:58 --> Input Class Initialized
INFO - 2022-04-20 14:07:58 --> Utf8 Class Initialized
INFO - 2022-04-20 14:07:58 --> Language Class Initialized
INFO - 2022-04-20 14:07:58 --> Router Class Initialized
INFO - 2022-04-20 14:07:58 --> URI Class Initialized
ERROR - 2022-04-20 14:07:58 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:58 --> Output Class Initialized
INFO - 2022-04-20 14:07:58 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:58 --> Input Class Initialized
INFO - 2022-04-20 14:07:58 --> Router Class Initialized
INFO - 2022-04-20 14:07:58 --> Language Class Initialized
ERROR - 2022-04-20 14:07:58 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:07:58 --> Output Class Initialized
INFO - 2022-04-20 14:07:58 --> Security Class Initialized
DEBUG - 2022-04-20 14:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:07:58 --> Input Class Initialized
INFO - 2022-04-20 14:07:58 --> Language Class Initialized
ERROR - 2022-04-20 14:07:58 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:10:51 --> Config Class Initialized
INFO - 2022-04-20 14:10:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:10:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:10:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:10:51 --> URI Class Initialized
DEBUG - 2022-04-20 14:10:51 --> No URI present. Default controller set.
INFO - 2022-04-20 14:10:51 --> Router Class Initialized
INFO - 2022-04-20 14:10:51 --> Output Class Initialized
INFO - 2022-04-20 14:10:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:10:51 --> Input Class Initialized
INFO - 2022-04-20 14:10:51 --> Language Class Initialized
INFO - 2022-04-20 14:10:51 --> Language Class Initialized
INFO - 2022-04-20 14:10:51 --> Config Class Initialized
INFO - 2022-04-20 14:10:51 --> Loader Class Initialized
INFO - 2022-04-20 14:10:51 --> Helper loaded: url_helper
INFO - 2022-04-20 14:10:51 --> Controller Class Initialized
DEBUG - 2022-04-20 14:10:51 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:10:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:10:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:10:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:10:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:10:51 --> Final output sent to browser
DEBUG - 2022-04-20 14:10:51 --> Total execution time: 0.0190
INFO - 2022-04-20 14:10:51 --> Config Class Initialized
INFO - 2022-04-20 14:10:51 --> Hooks Class Initialized
INFO - 2022-04-20 14:10:51 --> Config Class Initialized
INFO - 2022-04-20 14:10:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:10:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:10:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:10:51 --> URI Class Initialized
INFO - 2022-04-20 14:10:51 --> Config Class Initialized
INFO - 2022-04-20 14:10:51 --> Hooks Class Initialized
INFO - 2022-04-20 14:10:51 --> Router Class Initialized
INFO - 2022-04-20 14:10:51 --> Output Class Initialized
INFO - 2022-04-20 14:10:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:10:51 --> Input Class Initialized
INFO - 2022-04-20 14:10:51 --> Language Class Initialized
DEBUG - 2022-04-20 14:10:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:10:51 --> Utf8 Class Initialized
ERROR - 2022-04-20 14:10:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:10:51 --> URI Class Initialized
DEBUG - 2022-04-20 14:10:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:10:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:10:51 --> Router Class Initialized
INFO - 2022-04-20 14:10:51 --> URI Class Initialized
INFO - 2022-04-20 14:10:51 --> Output Class Initialized
INFO - 2022-04-20 14:10:51 --> Security Class Initialized
INFO - 2022-04-20 14:10:51 --> Router Class Initialized
DEBUG - 2022-04-20 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:10:51 --> Input Class Initialized
INFO - 2022-04-20 14:10:51 --> Language Class Initialized
INFO - 2022-04-20 14:10:51 --> Output Class Initialized
ERROR - 2022-04-20 14:10:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:10:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:10:51 --> Input Class Initialized
INFO - 2022-04-20 14:10:51 --> Language Class Initialized
ERROR - 2022-04-20 14:10:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:11:08 --> Config Class Initialized
INFO - 2022-04-20 14:11:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:11:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:11:08 --> Utf8 Class Initialized
INFO - 2022-04-20 14:11:08 --> URI Class Initialized
DEBUG - 2022-04-20 14:11:08 --> No URI present. Default controller set.
INFO - 2022-04-20 14:11:08 --> Router Class Initialized
INFO - 2022-04-20 14:11:08 --> Output Class Initialized
INFO - 2022-04-20 14:11:08 --> Security Class Initialized
DEBUG - 2022-04-20 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:11:08 --> Input Class Initialized
INFO - 2022-04-20 14:11:08 --> Language Class Initialized
INFO - 2022-04-20 14:11:08 --> Language Class Initialized
INFO - 2022-04-20 14:11:08 --> Config Class Initialized
INFO - 2022-04-20 14:11:08 --> Loader Class Initialized
INFO - 2022-04-20 14:11:08 --> Helper loaded: url_helper
INFO - 2022-04-20 14:11:08 --> Controller Class Initialized
DEBUG - 2022-04-20 14:11:08 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:11:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:11:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:11:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:11:08 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:11:08 --> Final output sent to browser
DEBUG - 2022-04-20 14:11:08 --> Total execution time: 0.0193
INFO - 2022-04-20 14:11:08 --> Config Class Initialized
INFO - 2022-04-20 14:11:08 --> Hooks Class Initialized
INFO - 2022-04-20 14:11:08 --> Config Class Initialized
INFO - 2022-04-20 14:11:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:11:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:11:08 --> Utf8 Class Initialized
INFO - 2022-04-20 14:11:08 --> URI Class Initialized
DEBUG - 2022-04-20 14:11:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:11:08 --> Utf8 Class Initialized
INFO - 2022-04-20 14:11:08 --> URI Class Initialized
INFO - 2022-04-20 14:11:08 --> Router Class Initialized
INFO - 2022-04-20 14:11:08 --> Output Class Initialized
INFO - 2022-04-20 14:11:08 --> Router Class Initialized
INFO - 2022-04-20 14:11:08 --> Security Class Initialized
INFO - 2022-04-20 14:11:08 --> Output Class Initialized
DEBUG - 2022-04-20 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:11:08 --> Input Class Initialized
INFO - 2022-04-20 14:11:08 --> Security Class Initialized
INFO - 2022-04-20 14:11:08 --> Language Class Initialized
DEBUG - 2022-04-20 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:11:08 --> Input Class Initialized
ERROR - 2022-04-20 14:11:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:11:08 --> Language Class Initialized
ERROR - 2022-04-20 14:11:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:11:08 --> Config Class Initialized
INFO - 2022-04-20 14:11:08 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:11:08 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:11:08 --> Utf8 Class Initialized
INFO - 2022-04-20 14:11:08 --> URI Class Initialized
INFO - 2022-04-20 14:11:08 --> Router Class Initialized
INFO - 2022-04-20 14:11:08 --> Output Class Initialized
INFO - 2022-04-20 14:11:08 --> Security Class Initialized
DEBUG - 2022-04-20 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:11:08 --> Input Class Initialized
INFO - 2022-04-20 14:11:08 --> Language Class Initialized
ERROR - 2022-04-20 14:11:08 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:15:28 --> Config Class Initialized
INFO - 2022-04-20 14:15:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:15:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:15:28 --> Utf8 Class Initialized
INFO - 2022-04-20 14:15:28 --> URI Class Initialized
DEBUG - 2022-04-20 14:15:28 --> No URI present. Default controller set.
INFO - 2022-04-20 14:15:28 --> Router Class Initialized
INFO - 2022-04-20 14:15:28 --> Output Class Initialized
INFO - 2022-04-20 14:15:28 --> Security Class Initialized
DEBUG - 2022-04-20 14:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:15:28 --> Input Class Initialized
INFO - 2022-04-20 14:15:28 --> Language Class Initialized
INFO - 2022-04-20 14:15:28 --> Language Class Initialized
INFO - 2022-04-20 14:15:28 --> Config Class Initialized
INFO - 2022-04-20 14:15:28 --> Loader Class Initialized
INFO - 2022-04-20 14:15:28 --> Helper loaded: url_helper
INFO - 2022-04-20 14:15:28 --> Controller Class Initialized
DEBUG - 2022-04-20 14:15:28 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:15:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:15:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:15:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:15:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:15:28 --> Final output sent to browser
DEBUG - 2022-04-20 14:15:28 --> Total execution time: 0.0183
INFO - 2022-04-20 14:15:28 --> Config Class Initialized
INFO - 2022-04-20 14:15:28 --> Config Class Initialized
INFO - 2022-04-20 14:15:28 --> Config Class Initialized
INFO - 2022-04-20 14:15:28 --> Hooks Class Initialized
INFO - 2022-04-20 14:15:28 --> Hooks Class Initialized
INFO - 2022-04-20 14:15:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:15:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:15:28 --> Utf8 Class Initialized
INFO - 2022-04-20 14:15:28 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:15:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:15:28 --> Utf8 Class Initialized
INFO - 2022-04-20 14:15:28 --> URI Class Initialized
INFO - 2022-04-20 14:15:28 --> URI Class Initialized
INFO - 2022-04-20 14:15:28 --> URI Class Initialized
INFO - 2022-04-20 14:15:28 --> Router Class Initialized
INFO - 2022-04-20 14:15:28 --> Router Class Initialized
INFO - 2022-04-20 14:15:28 --> Router Class Initialized
INFO - 2022-04-20 14:15:28 --> Output Class Initialized
INFO - 2022-04-20 14:15:28 --> Output Class Initialized
INFO - 2022-04-20 14:15:28 --> Output Class Initialized
INFO - 2022-04-20 14:15:28 --> Security Class Initialized
INFO - 2022-04-20 14:15:28 --> Security Class Initialized
INFO - 2022-04-20 14:15:28 --> Security Class Initialized
DEBUG - 2022-04-20 14:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:15:28 --> Input Class Initialized
DEBUG - 2022-04-20 14:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:15:28 --> Language Class Initialized
INFO - 2022-04-20 14:15:28 --> Input Class Initialized
DEBUG - 2022-04-20 14:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:15:28 --> Input Class Initialized
INFO - 2022-04-20 14:15:28 --> Language Class Initialized
ERROR - 2022-04-20 14:15:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:15:28 --> Language Class Initialized
ERROR - 2022-04-20 14:15:28 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:15:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:18:43 --> Config Class Initialized
INFO - 2022-04-20 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:18:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:18:43 --> URI Class Initialized
DEBUG - 2022-04-20 14:18:43 --> No URI present. Default controller set.
INFO - 2022-04-20 14:18:43 --> Router Class Initialized
INFO - 2022-04-20 14:18:43 --> Output Class Initialized
INFO - 2022-04-20 14:18:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:18:43 --> Input Class Initialized
INFO - 2022-04-20 14:18:43 --> Language Class Initialized
INFO - 2022-04-20 14:18:43 --> Language Class Initialized
INFO - 2022-04-20 14:18:43 --> Config Class Initialized
INFO - 2022-04-20 14:18:43 --> Loader Class Initialized
INFO - 2022-04-20 14:18:43 --> Helper loaded: url_helper
INFO - 2022-04-20 14:18:43 --> Controller Class Initialized
DEBUG - 2022-04-20 14:18:43 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:18:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:18:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:18:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:18:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:18:43 --> Final output sent to browser
DEBUG - 2022-04-20 14:18:43 --> Total execution time: 0.0202
INFO - 2022-04-20 14:18:43 --> Config Class Initialized
INFO - 2022-04-20 14:18:43 --> Config Class Initialized
INFO - 2022-04-20 14:18:43 --> Hooks Class Initialized
INFO - 2022-04-20 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:18:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:18:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:18:43 --> URI Class Initialized
INFO - 2022-04-20 14:18:43 --> URI Class Initialized
INFO - 2022-04-20 14:18:43 --> Router Class Initialized
INFO - 2022-04-20 14:18:43 --> Config Class Initialized
INFO - 2022-04-20 14:18:43 --> Hooks Class Initialized
INFO - 2022-04-20 14:18:43 --> Output Class Initialized
INFO - 2022-04-20 14:18:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:18:43 --> Input Class Initialized
INFO - 2022-04-20 14:18:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:18:43 --> Language Class Initialized
INFO - 2022-04-20 14:18:43 --> URI Class Initialized
ERROR - 2022-04-20 14:18:43 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:18:43 --> Router Class Initialized
INFO - 2022-04-20 14:18:43 --> Output Class Initialized
INFO - 2022-04-20 14:18:43 --> Router Class Initialized
INFO - 2022-04-20 14:18:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:18:43 --> Input Class Initialized
INFO - 2022-04-20 14:18:43 --> Output Class Initialized
INFO - 2022-04-20 14:18:43 --> Language Class Initialized
INFO - 2022-04-20 14:18:43 --> Security Class Initialized
ERROR - 2022-04-20 14:18:43 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:18:43 --> Input Class Initialized
INFO - 2022-04-20 14:18:43 --> Language Class Initialized
ERROR - 2022-04-20 14:18:43 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:03 --> Config Class Initialized
INFO - 2022-04-20 14:19:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:03 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:03 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:03 --> Router Class Initialized
INFO - 2022-04-20 14:19:03 --> Output Class Initialized
INFO - 2022-04-20 14:19:03 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:03 --> Input Class Initialized
INFO - 2022-04-20 14:19:03 --> Language Class Initialized
INFO - 2022-04-20 14:19:03 --> Language Class Initialized
INFO - 2022-04-20 14:19:03 --> Config Class Initialized
INFO - 2022-04-20 14:19:03 --> Loader Class Initialized
INFO - 2022-04-20 14:19:03 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:03 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:03 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:03 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:03 --> Total execution time: 0.0196
INFO - 2022-04-20 14:19:03 --> Config Class Initialized
INFO - 2022-04-20 14:19:03 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:03 --> Config Class Initialized
INFO - 2022-04-20 14:19:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:03 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:03 --> Config Class Initialized
INFO - 2022-04-20 14:19:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:03 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:03 --> Router Class Initialized
INFO - 2022-04-20 14:19:03 --> URI Class Initialized
INFO - 2022-04-20 14:19:03 --> Output Class Initialized
DEBUG - 2022-04-20 14:19:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:03 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:03 --> Router Class Initialized
INFO - 2022-04-20 14:19:03 --> Security Class Initialized
INFO - 2022-04-20 14:19:03 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:03 --> Output Class Initialized
INFO - 2022-04-20 14:19:03 --> Input Class Initialized
INFO - 2022-04-20 14:19:03 --> Language Class Initialized
INFO - 2022-04-20 14:19:03 --> Security Class Initialized
INFO - 2022-04-20 14:19:03 --> Router Class Initialized
ERROR - 2022-04-20 14:19:03 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:03 --> Input Class Initialized
INFO - 2022-04-20 14:19:03 --> Language Class Initialized
INFO - 2022-04-20 14:19:03 --> Output Class Initialized
ERROR - 2022-04-20 14:19:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:03 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:03 --> Input Class Initialized
INFO - 2022-04-20 14:19:03 --> Language Class Initialized
ERROR - 2022-04-20 14:19:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:15 --> Config Class Initialized
INFO - 2022-04-20 14:19:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:15 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:15 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:15 --> Router Class Initialized
INFO - 2022-04-20 14:19:15 --> Output Class Initialized
INFO - 2022-04-20 14:19:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:15 --> Input Class Initialized
INFO - 2022-04-20 14:19:15 --> Language Class Initialized
INFO - 2022-04-20 14:19:15 --> Language Class Initialized
INFO - 2022-04-20 14:19:15 --> Config Class Initialized
INFO - 2022-04-20 14:19:15 --> Loader Class Initialized
INFO - 2022-04-20 14:19:15 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:15 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:15 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:15 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:15 --> Total execution time: 0.0202
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
ERROR - 2022-04-20 14:19:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
ERROR - 2022-04-20 14:19:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
ERROR - 2022-04-20 14:19:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:16 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Loader Class Initialized
INFO - 2022-04-20 14:19:16 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:16 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:16 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:16 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:16 --> Total execution time: 0.0200
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:16 --> Language Class Initialized
ERROR - 2022-04-20 14:19:16 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:19:16 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:16 --> Config Class Initialized
INFO - 2022-04-20 14:19:16 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:16 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:16 --> URI Class Initialized
INFO - 2022-04-20 14:19:16 --> Router Class Initialized
INFO - 2022-04-20 14:19:16 --> Output Class Initialized
INFO - 2022-04-20 14:19:16 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:16 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0193
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0198
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0183
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0205
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0199
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0209
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> No URI present. Default controller set.
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Loader Class Initialized
INFO - 2022-04-20 14:19:17 --> Helper loaded: url_helper
INFO - 2022-04-20 14:19:17 --> Controller Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:19:17 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:19:17 --> Final output sent to browser
DEBUG - 2022-04-20 14:19:17 --> Total execution time: 0.0211
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:19:17 --> Config Class Initialized
INFO - 2022-04-20 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:19:17 --> Utf8 Class Initialized
INFO - 2022-04-20 14:19:17 --> URI Class Initialized
INFO - 2022-04-20 14:19:17 --> Router Class Initialized
INFO - 2022-04-20 14:19:17 --> Output Class Initialized
INFO - 2022-04-20 14:19:17 --> Security Class Initialized
DEBUG - 2022-04-20 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:19:17 --> Input Class Initialized
INFO - 2022-04-20 14:19:17 --> Language Class Initialized
ERROR - 2022-04-20 14:19:17 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:22 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Loader Class Initialized
INFO - 2022-04-20 14:21:22 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:22 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:22 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:22 --> Total execution time: 0.0195
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:22 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Loader Class Initialized
INFO - 2022-04-20 14:21:22 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:22 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:22 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:22 --> Total execution time: 0.0202
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:22 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Loader Class Initialized
INFO - 2022-04-20 14:21:22 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:22 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:22 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:22 --> Total execution time: 0.0202
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:22 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Loader Class Initialized
INFO - 2022-04-20 14:21:22 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:22 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:22 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:22 --> Total execution time: 0.0215
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
ERROR - 2022-04-20 14:21:22 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:22 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:22 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:22 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:22 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:22 --> Router Class Initialized
INFO - 2022-04-20 14:21:22 --> Output Class Initialized
INFO - 2022-04-20 14:21:22 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:22 --> Input Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Language Class Initialized
INFO - 2022-04-20 14:21:22 --> Config Class Initialized
INFO - 2022-04-20 14:21:22 --> Loader Class Initialized
INFO - 2022-04-20 14:21:22 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:22 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:22 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:22 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:22 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:22 --> Total execution time: 0.0209
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:23 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Loader Class Initialized
INFO - 2022-04-20 14:21:23 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:23 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:23 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:23 --> Total execution time: 0.0215
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:23 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Loader Class Initialized
INFO - 2022-04-20 14:21:23 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:23 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:23 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:23 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:23 --> Total execution time: 0.0199
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
INFO - 2022-04-20 14:21:23 --> Config Class Initialized
INFO - 2022-04-20 14:21:23 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:21:23 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:23 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
INFO - 2022-04-20 14:21:23 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:23 --> Router Class Initialized
INFO - 2022-04-20 14:21:23 --> Output Class Initialized
INFO - 2022-04-20 14:21:23 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:23 --> Input Class Initialized
INFO - 2022-04-20 14:21:23 --> Language Class Initialized
ERROR - 2022-04-20 14:21:23 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:29 --> Config Class Initialized
INFO - 2022-04-20 14:21:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:29 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:29 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:29 --> Router Class Initialized
INFO - 2022-04-20 14:21:29 --> Output Class Initialized
INFO - 2022-04-20 14:21:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:29 --> Input Class Initialized
INFO - 2022-04-20 14:21:29 --> Language Class Initialized
INFO - 2022-04-20 14:21:29 --> Language Class Initialized
INFO - 2022-04-20 14:21:29 --> Config Class Initialized
INFO - 2022-04-20 14:21:29 --> Loader Class Initialized
INFO - 2022-04-20 14:21:29 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:29 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:29 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:29 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:29 --> Total execution time: 0.0196
INFO - 2022-04-20 14:21:29 --> Config Class Initialized
INFO - 2022-04-20 14:21:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:29 --> Config Class Initialized
INFO - 2022-04-20 14:21:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:29 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:29 --> Config Class Initialized
INFO - 2022-04-20 14:21:29 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:29 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:29 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:29 --> URI Class Initialized
INFO - 2022-04-20 14:21:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:29 --> Router Class Initialized
INFO - 2022-04-20 14:21:29 --> Router Class Initialized
INFO - 2022-04-20 14:21:29 --> Output Class Initialized
INFO - 2022-04-20 14:21:29 --> Output Class Initialized
INFO - 2022-04-20 14:21:29 --> URI Class Initialized
INFO - 2022-04-20 14:21:29 --> Security Class Initialized
INFO - 2022-04-20 14:21:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:29 --> Input Class Initialized
INFO - 2022-04-20 14:21:29 --> Router Class Initialized
INFO - 2022-04-20 14:21:29 --> Input Class Initialized
INFO - 2022-04-20 14:21:29 --> Language Class Initialized
INFO - 2022-04-20 14:21:29 --> Language Class Initialized
ERROR - 2022-04-20 14:21:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:29 --> Output Class Initialized
ERROR - 2022-04-20 14:21:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:29 --> Input Class Initialized
INFO - 2022-04-20 14:21:29 --> Language Class Initialized
ERROR - 2022-04-20 14:21:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:30 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:30 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:30 --> Router Class Initialized
INFO - 2022-04-20 14:21:30 --> Output Class Initialized
INFO - 2022-04-20 14:21:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:30 --> Input Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Loader Class Initialized
INFO - 2022-04-20 14:21:30 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:30 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:30 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:30 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:30 --> Total execution time: 0.0188
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:30 --> URI Class Initialized
INFO - 2022-04-20 14:21:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:30 --> URI Class Initialized
INFO - 2022-04-20 14:21:30 --> Router Class Initialized
INFO - 2022-04-20 14:21:30 --> Output Class Initialized
INFO - 2022-04-20 14:21:30 --> Router Class Initialized
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:30 --> Output Class Initialized
INFO - 2022-04-20 14:21:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:30 --> Security Class Initialized
INFO - 2022-04-20 14:21:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:30 --> Input Class Initialized
INFO - 2022-04-20 14:21:30 --> Input Class Initialized
INFO - 2022-04-20 14:21:30 --> URI Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
ERROR - 2022-04-20 14:21:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:30 --> Router Class Initialized
ERROR - 2022-04-20 14:21:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:30 --> Output Class Initialized
INFO - 2022-04-20 14:21:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:30 --> Input Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
ERROR - 2022-04-20 14:21:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:30 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:30 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:30 --> Router Class Initialized
INFO - 2022-04-20 14:21:30 --> Output Class Initialized
INFO - 2022-04-20 14:21:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:30 --> Input Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
INFO - 2022-04-20 14:21:30 --> Language Class Initialized
INFO - 2022-04-20 14:21:30 --> Config Class Initialized
INFO - 2022-04-20 14:21:30 --> Loader Class Initialized
INFO - 2022-04-20 14:21:30 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:30 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:30 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:30 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:30 --> Total execution time: 0.0209
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:31 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Loader Class Initialized
INFO - 2022-04-20 14:21:31 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:31 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:31 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:31 --> Total execution time: 0.0206
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:31 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Loader Class Initialized
INFO - 2022-04-20 14:21:31 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:31 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:31 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:31 --> Total execution time: 0.0228
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
DEBUG - 2022-04-20 14:21:31 --> No URI present. Default controller set.
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Loader Class Initialized
INFO - 2022-04-20 14:21:31 --> Helper loaded: url_helper
INFO - 2022-04-20 14:21:31 --> Controller Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:21:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:21:31 --> Final output sent to browser
DEBUG - 2022-04-20 14:21:31 --> Total execution time: 0.0184
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:21:31 --> Config Class Initialized
INFO - 2022-04-20 14:21:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:21:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:21:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> URI Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Router Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Output Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:21:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:21:31 --> Input Class Initialized
INFO - 2022-04-20 14:21:31 --> Language Class Initialized
ERROR - 2022-04-20 14:21:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:26:13 --> Config Class Initialized
INFO - 2022-04-20 14:26:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:26:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:13 --> URI Class Initialized
DEBUG - 2022-04-20 14:26:13 --> No URI present. Default controller set.
INFO - 2022-04-20 14:26:13 --> Router Class Initialized
INFO - 2022-04-20 14:26:13 --> Output Class Initialized
INFO - 2022-04-20 14:26:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:13 --> Input Class Initialized
INFO - 2022-04-20 14:26:13 --> Language Class Initialized
INFO - 2022-04-20 14:26:13 --> Language Class Initialized
INFO - 2022-04-20 14:26:13 --> Config Class Initialized
INFO - 2022-04-20 14:26:13 --> Loader Class Initialized
INFO - 2022-04-20 14:26:13 --> Helper loaded: url_helper
INFO - 2022-04-20 14:26:13 --> Controller Class Initialized
DEBUG - 2022-04-20 14:26:13 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:26:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:26:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:26:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:26:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:26:13 --> Final output sent to browser
DEBUG - 2022-04-20 14:26:13 --> Total execution time: 0.0196
INFO - 2022-04-20 14:26:13 --> Config Class Initialized
INFO - 2022-04-20 14:26:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:26:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:13 --> Config Class Initialized
INFO - 2022-04-20 14:26:13 --> Hooks Class Initialized
INFO - 2022-04-20 14:26:13 --> URI Class Initialized
DEBUG - 2022-04-20 14:26:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:13 --> URI Class Initialized
INFO - 2022-04-20 14:26:13 --> Config Class Initialized
INFO - 2022-04-20 14:26:13 --> Router Class Initialized
INFO - 2022-04-20 14:26:13 --> Router Class Initialized
INFO - 2022-04-20 14:26:13 --> Hooks Class Initialized
INFO - 2022-04-20 14:26:13 --> Output Class Initialized
INFO - 2022-04-20 14:26:13 --> Output Class Initialized
INFO - 2022-04-20 14:26:13 --> Security Class Initialized
INFO - 2022-04-20 14:26:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:13 --> Input Class Initialized
INFO - 2022-04-20 14:26:13 --> Input Class Initialized
INFO - 2022-04-20 14:26:13 --> Language Class Initialized
INFO - 2022-04-20 14:26:13 --> Language Class Initialized
ERROR - 2022-04-20 14:26:13 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:26:13 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:26:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:13 --> URI Class Initialized
INFO - 2022-04-20 14:26:13 --> Router Class Initialized
INFO - 2022-04-20 14:26:13 --> Output Class Initialized
INFO - 2022-04-20 14:26:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:13 --> Input Class Initialized
INFO - 2022-04-20 14:26:13 --> Language Class Initialized
ERROR - 2022-04-20 14:26:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:15 --> URI Class Initialized
INFO - 2022-04-20 14:26:15 --> Router Class Initialized
INFO - 2022-04-20 14:26:15 --> Output Class Initialized
INFO - 2022-04-20 14:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:15 --> Input Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Loader Class Initialized
INFO - 2022-04-20 14:26:15 --> Helper loaded: url_helper
INFO - 2022-04-20 14:26:15 --> Controller Class Initialized
DEBUG - 2022-04-20 14:26:15 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:26:15 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:26:15 --> Final output sent to browser
DEBUG - 2022-04-20 14:26:15 --> Total execution time: 0.0194
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:15 --> URI Class Initialized
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Hooks Class Initialized
INFO - 2022-04-20 14:26:15 --> Router Class Initialized
DEBUG - 2022-04-20 14:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:15 --> Output Class Initialized
INFO - 2022-04-20 14:26:15 --> URI Class Initialized
INFO - 2022-04-20 14:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:15 --> Input Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
INFO - 2022-04-20 14:26:15 --> Router Class Initialized
ERROR - 2022-04-20 14:26:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:26:15 --> Output Class Initialized
INFO - 2022-04-20 14:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:15 --> Input Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Hooks Class Initialized
ERROR - 2022-04-20 14:26:15 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:15 --> URI Class Initialized
INFO - 2022-04-20 14:26:15 --> Router Class Initialized
INFO - 2022-04-20 14:26:15 --> Output Class Initialized
INFO - 2022-04-20 14:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:15 --> Input Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
ERROR - 2022-04-20 14:26:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:15 --> URI Class Initialized
INFO - 2022-04-20 14:26:15 --> Router Class Initialized
INFO - 2022-04-20 14:26:15 --> Output Class Initialized
INFO - 2022-04-20 14:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:15 --> Input Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
ERROR - 2022-04-20 14:26:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:26:15 --> Config Class Initialized
INFO - 2022-04-20 14:26:15 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:26:15 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:26:15 --> Utf8 Class Initialized
INFO - 2022-04-20 14:26:15 --> URI Class Initialized
INFO - 2022-04-20 14:26:15 --> Router Class Initialized
INFO - 2022-04-20 14:26:15 --> Output Class Initialized
INFO - 2022-04-20 14:26:15 --> Security Class Initialized
DEBUG - 2022-04-20 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:26:15 --> Input Class Initialized
INFO - 2022-04-20 14:26:15 --> Language Class Initialized
ERROR - 2022-04-20 14:26:15 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:51 --> URI Class Initialized
INFO - 2022-04-20 14:27:51 --> Router Class Initialized
INFO - 2022-04-20 14:27:51 --> Output Class Initialized
INFO - 2022-04-20 14:27:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:51 --> Input Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Loader Class Initialized
INFO - 2022-04-20 14:27:51 --> Helper loaded: url_helper
INFO - 2022-04-20 14:27:51 --> Controller Class Initialized
DEBUG - 2022-04-20 14:27:51 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:27:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:27:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:27:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:27:51 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:27:51 --> Final output sent to browser
DEBUG - 2022-04-20 14:27:51 --> Total execution time: 0.0203
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Hooks Class Initialized
INFO - 2022-04-20 14:27:51 --> URI Class Initialized
DEBUG - 2022-04-20 14:27:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:51 --> Router Class Initialized
INFO - 2022-04-20 14:27:51 --> URI Class Initialized
INFO - 2022-04-20 14:27:51 --> Output Class Initialized
INFO - 2022-04-20 14:27:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:51 --> Router Class Initialized
INFO - 2022-04-20 14:27:51 --> Input Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
INFO - 2022-04-20 14:27:51 --> Output Class Initialized
ERROR - 2022-04-20 14:27:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:51 --> Input Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
ERROR - 2022-04-20 14:27:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:51 --> URI Class Initialized
INFO - 2022-04-20 14:27:51 --> Router Class Initialized
INFO - 2022-04-20 14:27:51 --> Output Class Initialized
INFO - 2022-04-20 14:27:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:51 --> Input Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
ERROR - 2022-04-20 14:27:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:51 --> URI Class Initialized
INFO - 2022-04-20 14:27:51 --> Router Class Initialized
INFO - 2022-04-20 14:27:51 --> Output Class Initialized
INFO - 2022-04-20 14:27:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:51 --> Input Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
ERROR - 2022-04-20 14:27:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:51 --> Config Class Initialized
INFO - 2022-04-20 14:27:51 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:51 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:51 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:51 --> URI Class Initialized
INFO - 2022-04-20 14:27:51 --> Router Class Initialized
INFO - 2022-04-20 14:27:51 --> Output Class Initialized
INFO - 2022-04-20 14:27:51 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:51 --> Input Class Initialized
INFO - 2022-04-20 14:27:51 --> Language Class Initialized
ERROR - 2022-04-20 14:27:51 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:54 --> Config Class Initialized
INFO - 2022-04-20 14:27:54 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:54 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:54 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:54 --> URI Class Initialized
DEBUG - 2022-04-20 14:27:54 --> No URI present. Default controller set.
INFO - 2022-04-20 14:27:54 --> Router Class Initialized
INFO - 2022-04-20 14:27:54 --> Output Class Initialized
INFO - 2022-04-20 14:27:54 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:54 --> Input Class Initialized
INFO - 2022-04-20 14:27:54 --> Language Class Initialized
INFO - 2022-04-20 14:27:54 --> Language Class Initialized
INFO - 2022-04-20 14:27:54 --> Config Class Initialized
INFO - 2022-04-20 14:27:54 --> Loader Class Initialized
INFO - 2022-04-20 14:27:54 --> Helper loaded: url_helper
INFO - 2022-04-20 14:27:54 --> Controller Class Initialized
DEBUG - 2022-04-20 14:27:54 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:27:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:27:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:27:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:27:54 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:27:54 --> Final output sent to browser
DEBUG - 2022-04-20 14:27:54 --> Total execution time: 0.0208
INFO - 2022-04-20 14:27:55 --> Config Class Initialized
INFO - 2022-04-20 14:27:55 --> Config Class Initialized
INFO - 2022-04-20 14:27:55 --> Hooks Class Initialized
INFO - 2022-04-20 14:27:55 --> Hooks Class Initialized
INFO - 2022-04-20 14:27:55 --> Config Class Initialized
INFO - 2022-04-20 14:27:55 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:27:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:55 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:27:55 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:27:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:55 --> URI Class Initialized
INFO - 2022-04-20 14:27:55 --> URI Class Initialized
INFO - 2022-04-20 14:27:55 --> Utf8 Class Initialized
INFO - 2022-04-20 14:27:55 --> Router Class Initialized
INFO - 2022-04-20 14:27:55 --> Output Class Initialized
INFO - 2022-04-20 14:27:55 --> URI Class Initialized
INFO - 2022-04-20 14:27:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:55 --> Input Class Initialized
INFO - 2022-04-20 14:27:55 --> Language Class Initialized
ERROR - 2022-04-20 14:27:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:27:55 --> Router Class Initialized
INFO - 2022-04-20 14:27:55 --> Router Class Initialized
INFO - 2022-04-20 14:27:55 --> Output Class Initialized
INFO - 2022-04-20 14:27:55 --> Output Class Initialized
INFO - 2022-04-20 14:27:55 --> Security Class Initialized
INFO - 2022-04-20 14:27:55 --> Security Class Initialized
DEBUG - 2022-04-20 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:55 --> Input Class Initialized
DEBUG - 2022-04-20 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:27:55 --> Input Class Initialized
INFO - 2022-04-20 14:27:55 --> Language Class Initialized
INFO - 2022-04-20 14:27:55 --> Language Class Initialized
ERROR - 2022-04-20 14:27:55 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:27:55 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:28:43 --> Config Class Initialized
INFO - 2022-04-20 14:28:43 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:28:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:28:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:28:43 --> URI Class Initialized
DEBUG - 2022-04-20 14:28:43 --> No URI present. Default controller set.
INFO - 2022-04-20 14:28:43 --> Router Class Initialized
INFO - 2022-04-20 14:28:43 --> Output Class Initialized
INFO - 2022-04-20 14:28:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:28:43 --> Input Class Initialized
INFO - 2022-04-20 14:28:43 --> Language Class Initialized
INFO - 2022-04-20 14:28:43 --> Language Class Initialized
INFO - 2022-04-20 14:28:43 --> Config Class Initialized
INFO - 2022-04-20 14:28:43 --> Loader Class Initialized
INFO - 2022-04-20 14:28:43 --> Helper loaded: url_helper
INFO - 2022-04-20 14:28:43 --> Controller Class Initialized
DEBUG - 2022-04-20 14:28:43 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:28:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:28:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:28:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:28:43 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:28:43 --> Final output sent to browser
DEBUG - 2022-04-20 14:28:43 --> Total execution time: 0.0201
INFO - 2022-04-20 14:28:43 --> Config Class Initialized
INFO - 2022-04-20 14:28:43 --> Hooks Class Initialized
INFO - 2022-04-20 14:28:43 --> Config Class Initialized
INFO - 2022-04-20 14:28:43 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:28:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:28:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:28:43 --> URI Class Initialized
DEBUG - 2022-04-20 14:28:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:28:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:28:43 --> URI Class Initialized
INFO - 2022-04-20 14:28:43 --> Router Class Initialized
INFO - 2022-04-20 14:28:43 --> Router Class Initialized
INFO - 2022-04-20 14:28:43 --> Output Class Initialized
INFO - 2022-04-20 14:28:43 --> Output Class Initialized
INFO - 2022-04-20 14:28:43 --> Security Class Initialized
INFO - 2022-04-20 14:28:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:28:43 --> Input Class Initialized
DEBUG - 2022-04-20 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:28:43 --> Language Class Initialized
INFO - 2022-04-20 14:28:43 --> Input Class Initialized
INFO - 2022-04-20 14:28:43 --> Language Class Initialized
ERROR - 2022-04-20 14:28:43 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:28:43 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:28:43 --> Config Class Initialized
INFO - 2022-04-20 14:28:43 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:28:43 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:28:43 --> Utf8 Class Initialized
INFO - 2022-04-20 14:28:43 --> URI Class Initialized
INFO - 2022-04-20 14:28:43 --> Router Class Initialized
INFO - 2022-04-20 14:28:43 --> Output Class Initialized
INFO - 2022-04-20 14:28:43 --> Security Class Initialized
DEBUG - 2022-04-20 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:28:43 --> Input Class Initialized
INFO - 2022-04-20 14:28:43 --> Language Class Initialized
ERROR - 2022-04-20 14:28:43 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:30:41 --> Config Class Initialized
INFO - 2022-04-20 14:30:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:30:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:30:41 --> Utf8 Class Initialized
INFO - 2022-04-20 14:30:41 --> URI Class Initialized
DEBUG - 2022-04-20 14:30:41 --> No URI present. Default controller set.
INFO - 2022-04-20 14:30:41 --> Router Class Initialized
INFO - 2022-04-20 14:30:41 --> Output Class Initialized
INFO - 2022-04-20 14:30:41 --> Security Class Initialized
DEBUG - 2022-04-20 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:30:41 --> Input Class Initialized
INFO - 2022-04-20 14:30:41 --> Language Class Initialized
INFO - 2022-04-20 14:30:41 --> Language Class Initialized
INFO - 2022-04-20 14:30:41 --> Config Class Initialized
INFO - 2022-04-20 14:30:41 --> Loader Class Initialized
INFO - 2022-04-20 14:30:41 --> Helper loaded: url_helper
INFO - 2022-04-20 14:30:41 --> Controller Class Initialized
DEBUG - 2022-04-20 14:30:41 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:30:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:30:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:30:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:30:41 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:30:41 --> Final output sent to browser
DEBUG - 2022-04-20 14:30:41 --> Total execution time: 0.0191
INFO - 2022-04-20 14:30:41 --> Config Class Initialized
INFO - 2022-04-20 14:30:41 --> Config Class Initialized
INFO - 2022-04-20 14:30:41 --> Hooks Class Initialized
INFO - 2022-04-20 14:30:41 --> Config Class Initialized
INFO - 2022-04-20 14:30:41 --> Hooks Class Initialized
INFO - 2022-04-20 14:30:41 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:30:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:30:41 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:30:41 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:30:41 --> Utf8 Class Initialized
INFO - 2022-04-20 14:30:41 --> Utf8 Class Initialized
INFO - 2022-04-20 14:30:41 --> URI Class Initialized
INFO - 2022-04-20 14:30:41 --> URI Class Initialized
INFO - 2022-04-20 14:30:41 --> URI Class Initialized
INFO - 2022-04-20 14:30:41 --> Router Class Initialized
INFO - 2022-04-20 14:30:41 --> Router Class Initialized
INFO - 2022-04-20 14:30:41 --> Router Class Initialized
INFO - 2022-04-20 14:30:41 --> Output Class Initialized
INFO - 2022-04-20 14:30:41 --> Output Class Initialized
INFO - 2022-04-20 14:30:41 --> Security Class Initialized
DEBUG - 2022-04-20 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:30:41 --> Input Class Initialized
INFO - 2022-04-20 14:30:41 --> Language Class Initialized
ERROR - 2022-04-20 14:30:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:30:41 --> Security Class Initialized
INFO - 2022-04-20 14:30:41 --> Output Class Initialized
DEBUG - 2022-04-20 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:30:41 --> Input Class Initialized
INFO - 2022-04-20 14:30:41 --> Security Class Initialized
INFO - 2022-04-20 14:30:41 --> Language Class Initialized
DEBUG - 2022-04-20 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:30:41 --> Input Class Initialized
ERROR - 2022-04-20 14:30:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:30:41 --> Language Class Initialized
ERROR - 2022-04-20 14:30:41 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:31:26 --> Config Class Initialized
INFO - 2022-04-20 14:31:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:31:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:26 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:26 --> URI Class Initialized
DEBUG - 2022-04-20 14:31:26 --> No URI present. Default controller set.
INFO - 2022-04-20 14:31:26 --> Router Class Initialized
INFO - 2022-04-20 14:31:26 --> Output Class Initialized
INFO - 2022-04-20 14:31:26 --> Security Class Initialized
DEBUG - 2022-04-20 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:26 --> Input Class Initialized
INFO - 2022-04-20 14:31:26 --> Language Class Initialized
INFO - 2022-04-20 14:31:26 --> Language Class Initialized
INFO - 2022-04-20 14:31:26 --> Config Class Initialized
INFO - 2022-04-20 14:31:26 --> Loader Class Initialized
INFO - 2022-04-20 14:31:26 --> Helper loaded: url_helper
INFO - 2022-04-20 14:31:26 --> Controller Class Initialized
DEBUG - 2022-04-20 14:31:26 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:31:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:31:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:31:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:31:26 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:31:26 --> Final output sent to browser
DEBUG - 2022-04-20 14:31:26 --> Total execution time: 0.0197
INFO - 2022-04-20 14:31:26 --> Config Class Initialized
INFO - 2022-04-20 14:31:26 --> Hooks Class Initialized
INFO - 2022-04-20 14:31:26 --> Config Class Initialized
INFO - 2022-04-20 14:31:26 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:31:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:26 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:31:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:26 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:26 --> URI Class Initialized
INFO - 2022-04-20 14:31:26 --> URI Class Initialized
INFO - 2022-04-20 14:31:26 --> Config Class Initialized
INFO - 2022-04-20 14:31:26 --> Hooks Class Initialized
INFO - 2022-04-20 14:31:26 --> Router Class Initialized
INFO - 2022-04-20 14:31:26 --> Router Class Initialized
INFO - 2022-04-20 14:31:26 --> Output Class Initialized
DEBUG - 2022-04-20 14:31:26 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:26 --> Output Class Initialized
INFO - 2022-04-20 14:31:26 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:26 --> Security Class Initialized
INFO - 2022-04-20 14:31:26 --> Security Class Initialized
INFO - 2022-04-20 14:31:26 --> URI Class Initialized
DEBUG - 2022-04-20 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:26 --> Input Class Initialized
DEBUG - 2022-04-20 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:26 --> Language Class Initialized
INFO - 2022-04-20 14:31:26 --> Input Class Initialized
INFO - 2022-04-20 14:31:26 --> Language Class Initialized
ERROR - 2022-04-20 14:31:26 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:31:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:31:26 --> Router Class Initialized
INFO - 2022-04-20 14:31:26 --> Output Class Initialized
INFO - 2022-04-20 14:31:26 --> Security Class Initialized
DEBUG - 2022-04-20 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:26 --> Input Class Initialized
INFO - 2022-04-20 14:31:26 --> Language Class Initialized
ERROR - 2022-04-20 14:31:26 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:31:37 --> Config Class Initialized
INFO - 2022-04-20 14:31:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:31:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:37 --> URI Class Initialized
INFO - 2022-04-20 14:31:37 --> Router Class Initialized
INFO - 2022-04-20 14:31:37 --> Output Class Initialized
INFO - 2022-04-20 14:31:37 --> Security Class Initialized
DEBUG - 2022-04-20 14:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:37 --> Input Class Initialized
INFO - 2022-04-20 14:31:37 --> Language Class Initialized
INFO - 2022-04-20 14:31:37 --> Language Class Initialized
INFO - 2022-04-20 14:31:37 --> Config Class Initialized
INFO - 2022-04-20 14:31:37 --> Loader Class Initialized
INFO - 2022-04-20 14:31:37 --> Helper loaded: url_helper
INFO - 2022-04-20 14:31:37 --> Controller Class Initialized
DEBUG - 2022-04-20 14:31:37 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:31:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:31:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:31:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:31:37 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:31:37 --> Final output sent to browser
DEBUG - 2022-04-20 14:31:37 --> Total execution time: 0.0215
INFO - 2022-04-20 14:31:37 --> Config Class Initialized
INFO - 2022-04-20 14:31:37 --> Hooks Class Initialized
INFO - 2022-04-20 14:31:37 --> Config Class Initialized
INFO - 2022-04-20 14:31:37 --> Hooks Class Initialized
INFO - 2022-04-20 14:31:37 --> Config Class Initialized
INFO - 2022-04-20 14:31:37 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:31:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:37 --> URI Class Initialized
INFO - 2022-04-20 14:31:37 --> URI Class Initialized
DEBUG - 2022-04-20 14:31:37 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:31:37 --> Utf8 Class Initialized
INFO - 2022-04-20 14:31:37 --> URI Class Initialized
INFO - 2022-04-20 14:31:37 --> Router Class Initialized
INFO - 2022-04-20 14:31:37 --> Router Class Initialized
INFO - 2022-04-20 14:31:37 --> Output Class Initialized
INFO - 2022-04-20 14:31:37 --> Router Class Initialized
INFO - 2022-04-20 14:31:37 --> Output Class Initialized
INFO - 2022-04-20 14:31:37 --> Security Class Initialized
INFO - 2022-04-20 14:31:37 --> Security Class Initialized
INFO - 2022-04-20 14:31:37 --> Output Class Initialized
DEBUG - 2022-04-20 14:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:37 --> Input Class Initialized
DEBUG - 2022-04-20 14:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:31:37 --> Security Class Initialized
INFO - 2022-04-20 14:31:37 --> Language Class Initialized
INFO - 2022-04-20 14:31:37 --> Input Class Initialized
DEBUG - 2022-04-20 14:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 14:31:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:31:37 --> Input Class Initialized
INFO - 2022-04-20 14:31:37 --> Language Class Initialized
INFO - 2022-04-20 14:31:37 --> Language Class Initialized
ERROR - 2022-04-20 14:31:37 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:31:37 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Loader Class Initialized
INFO - 2022-04-20 14:32:29 --> Helper loaded: url_helper
INFO - 2022-04-20 14:32:29 --> Controller Class Initialized
DEBUG - 2022-04-20 14:32:29 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:32:29 --> Final output sent to browser
DEBUG - 2022-04-20 14:32:29 --> Total execution time: 0.0201
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
ERROR - 2022-04-20 14:32:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
ERROR - 2022-04-20 14:32:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
ERROR - 2022-04-20 14:32:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Loader Class Initialized
INFO - 2022-04-20 14:32:29 --> Helper loaded: url_helper
INFO - 2022-04-20 14:32:29 --> Controller Class Initialized
DEBUG - 2022-04-20 14:32:29 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:32:29 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:32:29 --> Final output sent to browser
DEBUG - 2022-04-20 14:32:29 --> Total execution time: 0.0184
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
ERROR - 2022-04-20 14:32:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:29 --> Config Class Initialized
INFO - 2022-04-20 14:32:29 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:29 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:29 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:29 --> URI Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
INFO - 2022-04-20 14:32:29 --> Router Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
INFO - 2022-04-20 14:32:29 --> Output Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
INFO - 2022-04-20 14:32:29 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
DEBUG - 2022-04-20 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
INFO - 2022-04-20 14:32:29 --> Input Class Initialized
INFO - 2022-04-20 14:32:29 --> Language Class Initialized
ERROR - 2022-04-20 14:32:29 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:32:29 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Loader Class Initialized
INFO - 2022-04-20 14:32:30 --> Helper loaded: url_helper
INFO - 2022-04-20 14:32:30 --> Controller Class Initialized
DEBUG - 2022-04-20 14:32:30 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:32:30 --> Final output sent to browser
DEBUG - 2022-04-20 14:32:30 --> Total execution time: 0.0205
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Loader Class Initialized
INFO - 2022-04-20 14:32:30 --> Helper loaded: url_helper
INFO - 2022-04-20 14:32:30 --> Controller Class Initialized
DEBUG - 2022-04-20 14:32:30 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:32:30 --> Final output sent to browser
DEBUG - 2022-04-20 14:32:30 --> Total execution time: 0.0183
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Loader Class Initialized
INFO - 2022-04-20 14:32:30 --> Helper loaded: url_helper
INFO - 2022-04-20 14:32:30 --> Controller Class Initialized
DEBUG - 2022-04-20 14:32:30 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:32:30 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:32:30 --> Final output sent to browser
DEBUG - 2022-04-20 14:32:30 --> Total execution time: 0.0211
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> Config Class Initialized
INFO - 2022-04-20 14:32:30 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
DEBUG - 2022-04-20 14:32:30 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
INFO - 2022-04-20 14:32:30 --> URI Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
INFO - 2022-04-20 14:32:30 --> Router Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Output Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
INFO - 2022-04-20 14:32:30 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
DEBUG - 2022-04-20 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
INFO - 2022-04-20 14:32:30 --> Input Class Initialized
INFO - 2022-04-20 14:32:30 --> Language Class Initialized
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:32:30 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:40 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:40 --> URI Class Initialized
INFO - 2022-04-20 14:32:40 --> Router Class Initialized
INFO - 2022-04-20 14:32:40 --> Output Class Initialized
INFO - 2022-04-20 14:32:40 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:40 --> Input Class Initialized
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Loader Class Initialized
INFO - 2022-04-20 14:32:40 --> Helper loaded: url_helper
INFO - 2022-04-20 14:32:40 --> Controller Class Initialized
DEBUG - 2022-04-20 14:32:40 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:32:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:32:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:32:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:32:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:32:40 --> Final output sent to browser
DEBUG - 2022-04-20 14:32:40 --> Total execution time: 0.0190
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:40 --> Hooks Class Initialized
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:32:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:40 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:40 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:40 --> URI Class Initialized
INFO - 2022-04-20 14:32:40 --> URI Class Initialized
DEBUG - 2022-04-20 14:32:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:40 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:40 --> URI Class Initialized
INFO - 2022-04-20 14:32:40 --> Router Class Initialized
INFO - 2022-04-20 14:32:40 --> Output Class Initialized
INFO - 2022-04-20 14:32:40 --> Router Class Initialized
INFO - 2022-04-20 14:32:40 --> Security Class Initialized
INFO - 2022-04-20 14:32:40 --> Output Class Initialized
DEBUG - 2022-04-20 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:40 --> Input Class Initialized
INFO - 2022-04-20 14:32:40 --> Security Class Initialized
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
DEBUG - 2022-04-20 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:40 --> Input Class Initialized
ERROR - 2022-04-20 14:32:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
ERROR - 2022-04-20 14:32:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:40 --> Router Class Initialized
INFO - 2022-04-20 14:32:40 --> Output Class Initialized
INFO - 2022-04-20 14:32:40 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:40 --> Input Class Initialized
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
ERROR - 2022-04-20 14:32:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:40 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:40 --> URI Class Initialized
INFO - 2022-04-20 14:32:40 --> Router Class Initialized
INFO - 2022-04-20 14:32:40 --> Output Class Initialized
INFO - 2022-04-20 14:32:40 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:40 --> Input Class Initialized
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
ERROR - 2022-04-20 14:32:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:32:40 --> Config Class Initialized
INFO - 2022-04-20 14:32:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:32:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:32:40 --> Utf8 Class Initialized
INFO - 2022-04-20 14:32:40 --> URI Class Initialized
INFO - 2022-04-20 14:32:40 --> Router Class Initialized
INFO - 2022-04-20 14:32:40 --> Output Class Initialized
INFO - 2022-04-20 14:32:40 --> Security Class Initialized
DEBUG - 2022-04-20 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:32:40 --> Input Class Initialized
INFO - 2022-04-20 14:32:40 --> Language Class Initialized
ERROR - 2022-04-20 14:32:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:37:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:37:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:37:50 --> URI Class Initialized
INFO - 2022-04-20 14:37:50 --> Router Class Initialized
INFO - 2022-04-20 14:37:50 --> Output Class Initialized
INFO - 2022-04-20 14:37:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:37:50 --> Input Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Loader Class Initialized
INFO - 2022-04-20 14:37:50 --> Helper loaded: url_helper
INFO - 2022-04-20 14:37:50 --> Controller Class Initialized
DEBUG - 2022-04-20 14:37:50 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 14:37:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:37:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:37:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 14:37:50 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:37:50 --> Final output sent to browser
DEBUG - 2022-04-20 14:37:50 --> Total execution time: 0.0334
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:37:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:37:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:37:50 --> URI Class Initialized
INFO - 2022-04-20 14:37:50 --> Router Class Initialized
INFO - 2022-04-20 14:37:50 --> Output Class Initialized
INFO - 2022-04-20 14:37:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:37:50 --> Input Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Hooks Class Initialized
ERROR - 2022-04-20 14:37:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:37:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:37:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:37:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:37:50 --> URI Class Initialized
INFO - 2022-04-20 14:37:50 --> URI Class Initialized
INFO - 2022-04-20 14:37:50 --> Router Class Initialized
INFO - 2022-04-20 14:37:50 --> Router Class Initialized
INFO - 2022-04-20 14:37:50 --> Output Class Initialized
INFO - 2022-04-20 14:37:50 --> Output Class Initialized
INFO - 2022-04-20 14:37:50 --> Security Class Initialized
INFO - 2022-04-20 14:37:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:37:50 --> Input Class Initialized
DEBUG - 2022-04-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:37:50 --> Input Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
ERROR - 2022-04-20 14:37:50 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:37:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:37:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:37:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:37:50 --> URI Class Initialized
INFO - 2022-04-20 14:37:50 --> Router Class Initialized
INFO - 2022-04-20 14:37:50 --> Output Class Initialized
INFO - 2022-04-20 14:37:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:37:50 --> Input Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
ERROR - 2022-04-20 14:37:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:37:50 --> Config Class Initialized
INFO - 2022-04-20 14:37:50 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:37:50 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:37:50 --> Utf8 Class Initialized
INFO - 2022-04-20 14:37:50 --> URI Class Initialized
INFO - 2022-04-20 14:37:50 --> Router Class Initialized
INFO - 2022-04-20 14:37:50 --> Output Class Initialized
INFO - 2022-04-20 14:37:50 --> Security Class Initialized
DEBUG - 2022-04-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:37:50 --> Input Class Initialized
INFO - 2022-04-20 14:37:50 --> Language Class Initialized
ERROR - 2022-04-20 14:37:50 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:38:05 --> Config Class Initialized
INFO - 2022-04-20 14:38:05 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:38:05 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:05 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:05 --> URI Class Initialized
DEBUG - 2022-04-20 14:38:05 --> No URI present. Default controller set.
INFO - 2022-04-20 14:38:05 --> Router Class Initialized
INFO - 2022-04-20 14:38:05 --> Output Class Initialized
INFO - 2022-04-20 14:38:05 --> Security Class Initialized
DEBUG - 2022-04-20 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:05 --> Input Class Initialized
INFO - 2022-04-20 14:38:05 --> Language Class Initialized
INFO - 2022-04-20 14:38:05 --> Language Class Initialized
INFO - 2022-04-20 14:38:05 --> Config Class Initialized
INFO - 2022-04-20 14:38:05 --> Loader Class Initialized
INFO - 2022-04-20 14:38:05 --> Helper loaded: url_helper
INFO - 2022-04-20 14:38:05 --> Controller Class Initialized
DEBUG - 2022-04-20 14:38:05 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 14:38:05 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:38:05 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:38:05 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 14:38:05 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:38:05 --> Final output sent to browser
DEBUG - 2022-04-20 14:38:05 --> Total execution time: 0.0226
INFO - 2022-04-20 14:38:06 --> Config Class Initialized
INFO - 2022-04-20 14:38:06 --> Hooks Class Initialized
INFO - 2022-04-20 14:38:06 --> Config Class Initialized
INFO - 2022-04-20 14:38:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:38:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:06 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:06 --> URI Class Initialized
DEBUG - 2022-04-20 14:38:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:06 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:06 --> URI Class Initialized
INFO - 2022-04-20 14:38:06 --> Router Class Initialized
INFO - 2022-04-20 14:38:06 --> Config Class Initialized
INFO - 2022-04-20 14:38:06 --> Hooks Class Initialized
INFO - 2022-04-20 14:38:06 --> Output Class Initialized
INFO - 2022-04-20 14:38:06 --> Router Class Initialized
INFO - 2022-04-20 14:38:06 --> Security Class Initialized
INFO - 2022-04-20 14:38:06 --> Output Class Initialized
DEBUG - 2022-04-20 14:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:06 --> Input Class Initialized
INFO - 2022-04-20 14:38:06 --> Security Class Initialized
INFO - 2022-04-20 14:38:06 --> Language Class Initialized
DEBUG - 2022-04-20 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:06 --> Input Class Initialized
ERROR - 2022-04-20 14:38:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:38:06 --> Language Class Initialized
ERROR - 2022-04-20 14:38:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:38:06 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:06 --> URI Class Initialized
INFO - 2022-04-20 14:38:06 --> Router Class Initialized
INFO - 2022-04-20 14:38:06 --> Output Class Initialized
INFO - 2022-04-20 14:38:06 --> Security Class Initialized
DEBUG - 2022-04-20 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:06 --> Input Class Initialized
INFO - 2022-04-20 14:38:06 --> Language Class Initialized
ERROR - 2022-04-20 14:38:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:38:19 --> Config Class Initialized
INFO - 2022-04-20 14:38:19 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:38:19 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:19 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:19 --> URI Class Initialized
INFO - 2022-04-20 14:38:19 --> Router Class Initialized
INFO - 2022-04-20 14:38:19 --> Output Class Initialized
INFO - 2022-04-20 14:38:19 --> Security Class Initialized
DEBUG - 2022-04-20 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:19 --> Input Class Initialized
INFO - 2022-04-20 14:38:19 --> Language Class Initialized
INFO - 2022-04-20 14:38:19 --> Language Class Initialized
INFO - 2022-04-20 14:38:19 --> Config Class Initialized
INFO - 2022-04-20 14:38:19 --> Loader Class Initialized
INFO - 2022-04-20 14:38:19 --> Helper loaded: url_helper
INFO - 2022-04-20 14:38:19 --> Controller Class Initialized
DEBUG - 2022-04-20 14:38:19 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:38:19 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:38:19 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:38:19 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:38:19 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:38:19 --> Final output sent to browser
DEBUG - 2022-04-20 14:38:19 --> Total execution time: 0.0220
INFO - 2022-04-20 14:38:19 --> Config Class Initialized
INFO - 2022-04-20 14:38:19 --> Config Class Initialized
INFO - 2022-04-20 14:38:19 --> Hooks Class Initialized
INFO - 2022-04-20 14:38:19 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:38:19 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:19 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:19 --> URI Class Initialized
INFO - 2022-04-20 14:38:19 --> Config Class Initialized
INFO - 2022-04-20 14:38:19 --> Hooks Class Initialized
INFO - 2022-04-20 14:38:19 --> Router Class Initialized
INFO - 2022-04-20 14:38:19 --> Output Class Initialized
DEBUG - 2022-04-20 14:38:19 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:19 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:19 --> Security Class Initialized
INFO - 2022-04-20 14:38:19 --> URI Class Initialized
DEBUG - 2022-04-20 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:19 --> Input Class Initialized
INFO - 2022-04-20 14:38:19 --> Language Class Initialized
ERROR - 2022-04-20 14:38:19 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:38:19 --> Router Class Initialized
INFO - 2022-04-20 14:38:19 --> Output Class Initialized
DEBUG - 2022-04-20 14:38:19 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:38:19 --> Utf8 Class Initialized
INFO - 2022-04-20 14:38:19 --> Security Class Initialized
INFO - 2022-04-20 14:38:19 --> URI Class Initialized
DEBUG - 2022-04-20 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:19 --> Input Class Initialized
INFO - 2022-04-20 14:38:19 --> Language Class Initialized
INFO - 2022-04-20 14:38:19 --> Router Class Initialized
ERROR - 2022-04-20 14:38:19 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:38:19 --> Output Class Initialized
INFO - 2022-04-20 14:38:19 --> Security Class Initialized
DEBUG - 2022-04-20 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:38:19 --> Input Class Initialized
INFO - 2022-04-20 14:38:19 --> Language Class Initialized
ERROR - 2022-04-20 14:38:19 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:39:47 --> Config Class Initialized
INFO - 2022-04-20 14:39:47 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:39:47 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:39:47 --> Utf8 Class Initialized
INFO - 2022-04-20 14:39:47 --> URI Class Initialized
INFO - 2022-04-20 14:39:47 --> Router Class Initialized
INFO - 2022-04-20 14:39:47 --> Output Class Initialized
INFO - 2022-04-20 14:39:47 --> Security Class Initialized
DEBUG - 2022-04-20 14:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:39:47 --> Input Class Initialized
INFO - 2022-04-20 14:39:47 --> Language Class Initialized
INFO - 2022-04-20 14:39:47 --> Language Class Initialized
INFO - 2022-04-20 14:39:47 --> Config Class Initialized
INFO - 2022-04-20 14:39:47 --> Loader Class Initialized
INFO - 2022-04-20 14:39:47 --> Helper loaded: url_helper
INFO - 2022-04-20 14:39:47 --> Controller Class Initialized
DEBUG - 2022-04-20 14:39:47 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:39:47 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:39:47 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:39:47 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:39:47 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:39:47 --> Final output sent to browser
DEBUG - 2022-04-20 14:39:47 --> Total execution time: 0.0193
INFO - 2022-04-20 14:39:47 --> Config Class Initialized
INFO - 2022-04-20 14:39:47 --> Hooks Class Initialized
INFO - 2022-04-20 14:39:47 --> Config Class Initialized
DEBUG - 2022-04-20 14:39:47 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:39:47 --> Utf8 Class Initialized
INFO - 2022-04-20 14:39:47 --> Config Class Initialized
INFO - 2022-04-20 14:39:47 --> Hooks Class Initialized
INFO - 2022-04-20 14:39:47 --> URI Class Initialized
INFO - 2022-04-20 14:39:47 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:39:47 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:39:47 --> Utf8 Class Initialized
INFO - 2022-04-20 14:39:47 --> Router Class Initialized
INFO - 2022-04-20 14:39:47 --> URI Class Initialized
INFO - 2022-04-20 14:39:47 --> Output Class Initialized
INFO - 2022-04-20 14:39:47 --> Security Class Initialized
DEBUG - 2022-04-20 14:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:39:47 --> Input Class Initialized
INFO - 2022-04-20 14:39:47 --> Router Class Initialized
INFO - 2022-04-20 14:39:47 --> Language Class Initialized
ERROR - 2022-04-20 14:39:47 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:39:47 --> Output Class Initialized
INFO - 2022-04-20 14:39:47 --> Security Class Initialized
DEBUG - 2022-04-20 14:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:39:47 --> Input Class Initialized
INFO - 2022-04-20 14:39:47 --> Language Class Initialized
DEBUG - 2022-04-20 14:39:47 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:39:47 --> Utf8 Class Initialized
ERROR - 2022-04-20 14:39:47 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:39:47 --> URI Class Initialized
INFO - 2022-04-20 14:39:47 --> Router Class Initialized
INFO - 2022-04-20 14:39:47 --> Output Class Initialized
INFO - 2022-04-20 14:39:47 --> Security Class Initialized
DEBUG - 2022-04-20 14:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:39:47 --> Input Class Initialized
INFO - 2022-04-20 14:39:47 --> Language Class Initialized
ERROR - 2022-04-20 14:39:47 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:40:06 --> Config Class Initialized
INFO - 2022-04-20 14:40:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:40:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:06 --> Utf8 Class Initialized
INFO - 2022-04-20 14:40:06 --> URI Class Initialized
INFO - 2022-04-20 14:40:06 --> Router Class Initialized
INFO - 2022-04-20 14:40:06 --> Output Class Initialized
INFO - 2022-04-20 14:40:06 --> Security Class Initialized
DEBUG - 2022-04-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:06 --> Input Class Initialized
INFO - 2022-04-20 14:40:06 --> Language Class Initialized
INFO - 2022-04-20 14:40:06 --> Language Class Initialized
INFO - 2022-04-20 14:40:06 --> Config Class Initialized
INFO - 2022-04-20 14:40:06 --> Loader Class Initialized
INFO - 2022-04-20 14:40:06 --> Helper loaded: url_helper
INFO - 2022-04-20 14:40:06 --> Controller Class Initialized
DEBUG - 2022-04-20 14:40:06 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:40:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:40:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:40:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:40:06 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:40:06 --> Final output sent to browser
DEBUG - 2022-04-20 14:40:06 --> Total execution time: 0.0189
INFO - 2022-04-20 14:40:06 --> Config Class Initialized
INFO - 2022-04-20 14:40:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:40:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:06 --> Utf8 Class Initialized
INFO - 2022-04-20 14:40:06 --> Config Class Initialized
INFO - 2022-04-20 14:40:06 --> Hooks Class Initialized
INFO - 2022-04-20 14:40:06 --> URI Class Initialized
INFO - 2022-04-20 14:40:06 --> Config Class Initialized
INFO - 2022-04-20 14:40:06 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:40:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:06 --> Utf8 Class Initialized
INFO - 2022-04-20 14:40:06 --> Router Class Initialized
INFO - 2022-04-20 14:40:06 --> URI Class Initialized
INFO - 2022-04-20 14:40:06 --> Output Class Initialized
DEBUG - 2022-04-20 14:40:06 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:06 --> Security Class Initialized
INFO - 2022-04-20 14:40:06 --> Router Class Initialized
DEBUG - 2022-04-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:06 --> Input Class Initialized
INFO - 2022-04-20 14:40:06 --> Language Class Initialized
INFO - 2022-04-20 14:40:06 --> Output Class Initialized
ERROR - 2022-04-20 14:40:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:40:06 --> Security Class Initialized
INFO - 2022-04-20 14:40:06 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:06 --> Input Class Initialized
INFO - 2022-04-20 14:40:06 --> Language Class Initialized
INFO - 2022-04-20 14:40:06 --> URI Class Initialized
ERROR - 2022-04-20 14:40:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:40:06 --> Router Class Initialized
INFO - 2022-04-20 14:40:06 --> Output Class Initialized
INFO - 2022-04-20 14:40:06 --> Security Class Initialized
DEBUG - 2022-04-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:06 --> Input Class Initialized
INFO - 2022-04-20 14:40:06 --> Language Class Initialized
ERROR - 2022-04-20 14:40:06 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:40:33 --> Config Class Initialized
INFO - 2022-04-20 14:40:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:40:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:33 --> Utf8 Class Initialized
INFO - 2022-04-20 14:40:33 --> URI Class Initialized
INFO - 2022-04-20 14:40:33 --> Router Class Initialized
INFO - 2022-04-20 14:40:33 --> Output Class Initialized
INFO - 2022-04-20 14:40:33 --> Security Class Initialized
DEBUG - 2022-04-20 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:33 --> Input Class Initialized
INFO - 2022-04-20 14:40:33 --> Language Class Initialized
INFO - 2022-04-20 14:40:33 --> Language Class Initialized
INFO - 2022-04-20 14:40:33 --> Config Class Initialized
INFO - 2022-04-20 14:40:33 --> Loader Class Initialized
INFO - 2022-04-20 14:40:33 --> Helper loaded: url_helper
INFO - 2022-04-20 14:40:33 --> Controller Class Initialized
DEBUG - 2022-04-20 14:40:33 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:40:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:40:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:40:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:40:33 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:40:33 --> Final output sent to browser
DEBUG - 2022-04-20 14:40:33 --> Total execution time: 0.0185
INFO - 2022-04-20 14:40:33 --> Config Class Initialized
INFO - 2022-04-20 14:40:33 --> Config Class Initialized
INFO - 2022-04-20 14:40:33 --> Hooks Class Initialized
INFO - 2022-04-20 14:40:33 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:40:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:33 --> Utf8 Class Initialized
INFO - 2022-04-20 14:40:33 --> Config Class Initialized
INFO - 2022-04-20 14:40:33 --> Hooks Class Initialized
INFO - 2022-04-20 14:40:33 --> URI Class Initialized
DEBUG - 2022-04-20 14:40:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:33 --> Utf8 Class Initialized
INFO - 2022-04-20 14:40:33 --> Router Class Initialized
INFO - 2022-04-20 14:40:33 --> URI Class Initialized
INFO - 2022-04-20 14:40:33 --> Output Class Initialized
INFO - 2022-04-20 14:40:33 --> Security Class Initialized
INFO - 2022-04-20 14:40:33 --> Router Class Initialized
DEBUG - 2022-04-20 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:33 --> Input Class Initialized
INFO - 2022-04-20 14:40:33 --> Language Class Initialized
INFO - 2022-04-20 14:40:33 --> Output Class Initialized
ERROR - 2022-04-20 14:40:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:40:33 --> Security Class Initialized
DEBUG - 2022-04-20 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:33 --> Input Class Initialized
INFO - 2022-04-20 14:40:33 --> Language Class Initialized
DEBUG - 2022-04-20 14:40:33 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:40:33 --> Utf8 Class Initialized
ERROR - 2022-04-20 14:40:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:40:33 --> URI Class Initialized
INFO - 2022-04-20 14:40:33 --> Router Class Initialized
INFO - 2022-04-20 14:40:33 --> Output Class Initialized
INFO - 2022-04-20 14:40:33 --> Security Class Initialized
DEBUG - 2022-04-20 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:40:33 --> Input Class Initialized
INFO - 2022-04-20 14:40:33 --> Language Class Initialized
ERROR - 2022-04-20 14:40:33 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:09 --> Config Class Initialized
INFO - 2022-04-20 14:41:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:09 --> URI Class Initialized
INFO - 2022-04-20 14:41:09 --> Router Class Initialized
INFO - 2022-04-20 14:41:09 --> Output Class Initialized
INFO - 2022-04-20 14:41:09 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:09 --> Input Class Initialized
INFO - 2022-04-20 14:41:09 --> Language Class Initialized
INFO - 2022-04-20 14:41:09 --> Language Class Initialized
INFO - 2022-04-20 14:41:09 --> Config Class Initialized
INFO - 2022-04-20 14:41:09 --> Loader Class Initialized
INFO - 2022-04-20 14:41:09 --> Helper loaded: url_helper
INFO - 2022-04-20 14:41:09 --> Controller Class Initialized
DEBUG - 2022-04-20 14:41:09 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:41:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:41:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:41:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:41:09 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:41:09 --> Final output sent to browser
DEBUG - 2022-04-20 14:41:09 --> Total execution time: 0.0202
INFO - 2022-04-20 14:41:09 --> Config Class Initialized
INFO - 2022-04-20 14:41:09 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:09 --> Config Class Initialized
INFO - 2022-04-20 14:41:09 --> Config Class Initialized
INFO - 2022-04-20 14:41:09 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:09 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:09 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 14:41:09 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:09 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:09 --> URI Class Initialized
INFO - 2022-04-20 14:41:09 --> URI Class Initialized
INFO - 2022-04-20 14:41:09 --> URI Class Initialized
INFO - 2022-04-20 14:41:09 --> Router Class Initialized
INFO - 2022-04-20 14:41:09 --> Router Class Initialized
INFO - 2022-04-20 14:41:09 --> Output Class Initialized
INFO - 2022-04-20 14:41:09 --> Router Class Initialized
INFO - 2022-04-20 14:41:09 --> Security Class Initialized
INFO - 2022-04-20 14:41:09 --> Output Class Initialized
INFO - 2022-04-20 14:41:09 --> Output Class Initialized
DEBUG - 2022-04-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:09 --> Input Class Initialized
INFO - 2022-04-20 14:41:09 --> Security Class Initialized
INFO - 2022-04-20 14:41:09 --> Security Class Initialized
INFO - 2022-04-20 14:41:09 --> Language Class Initialized
DEBUG - 2022-04-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:09 --> Input Class Initialized
DEBUG - 2022-04-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 14:41:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:09 --> Input Class Initialized
INFO - 2022-04-20 14:41:09 --> Language Class Initialized
INFO - 2022-04-20 14:41:09 --> Language Class Initialized
ERROR - 2022-04-20 14:41:09 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:41:09 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:24 --> Config Class Initialized
INFO - 2022-04-20 14:41:24 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:24 --> URI Class Initialized
INFO - 2022-04-20 14:41:24 --> Router Class Initialized
INFO - 2022-04-20 14:41:24 --> Output Class Initialized
INFO - 2022-04-20 14:41:24 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:24 --> Input Class Initialized
INFO - 2022-04-20 14:41:24 --> Language Class Initialized
INFO - 2022-04-20 14:41:24 --> Language Class Initialized
INFO - 2022-04-20 14:41:24 --> Config Class Initialized
INFO - 2022-04-20 14:41:24 --> Loader Class Initialized
INFO - 2022-04-20 14:41:24 --> Helper loaded: url_helper
INFO - 2022-04-20 14:41:24 --> Controller Class Initialized
DEBUG - 2022-04-20 14:41:24 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:41:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:41:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:41:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:41:24 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:41:24 --> Final output sent to browser
DEBUG - 2022-04-20 14:41:24 --> Total execution time: 0.0187
INFO - 2022-04-20 14:41:24 --> Config Class Initialized
INFO - 2022-04-20 14:41:24 --> Config Class Initialized
INFO - 2022-04-20 14:41:24 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:24 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:24 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:41:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:24 --> URI Class Initialized
INFO - 2022-04-20 14:41:24 --> URI Class Initialized
INFO - 2022-04-20 14:41:24 --> Router Class Initialized
INFO - 2022-04-20 14:41:24 --> Config Class Initialized
INFO - 2022-04-20 14:41:24 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:24 --> Output Class Initialized
INFO - 2022-04-20 14:41:24 --> Security Class Initialized
INFO - 2022-04-20 14:41:24 --> Router Class Initialized
DEBUG - 2022-04-20 14:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 14:41:24 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:24 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:24 --> Output Class Initialized
INFO - 2022-04-20 14:41:24 --> URI Class Initialized
INFO - 2022-04-20 14:41:24 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:24 --> Input Class Initialized
INFO - 2022-04-20 14:41:24 --> Language Class Initialized
INFO - 2022-04-20 14:41:24 --> Router Class Initialized
ERROR - 2022-04-20 14:41:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:24 --> Output Class Initialized
INFO - 2022-04-20 14:41:24 --> Input Class Initialized
INFO - 2022-04-20 14:41:24 --> Security Class Initialized
INFO - 2022-04-20 14:41:24 --> Language Class Initialized
DEBUG - 2022-04-20 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:24 --> Input Class Initialized
ERROR - 2022-04-20 14:41:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:24 --> Language Class Initialized
ERROR - 2022-04-20 14:41:24 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:36 --> Config Class Initialized
INFO - 2022-04-20 14:41:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:36 --> URI Class Initialized
INFO - 2022-04-20 14:41:36 --> Router Class Initialized
INFO - 2022-04-20 14:41:36 --> Output Class Initialized
INFO - 2022-04-20 14:41:36 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:36 --> Input Class Initialized
INFO - 2022-04-20 14:41:36 --> Language Class Initialized
INFO - 2022-04-20 14:41:36 --> Language Class Initialized
INFO - 2022-04-20 14:41:36 --> Config Class Initialized
INFO - 2022-04-20 14:41:36 --> Loader Class Initialized
INFO - 2022-04-20 14:41:36 --> Helper loaded: url_helper
INFO - 2022-04-20 14:41:36 --> Controller Class Initialized
DEBUG - 2022-04-20 14:41:36 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:41:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:41:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:41:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:41:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:41:36 --> Final output sent to browser
DEBUG - 2022-04-20 14:41:36 --> Total execution time: 0.0186
INFO - 2022-04-20 14:41:36 --> Config Class Initialized
INFO - 2022-04-20 14:41:36 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:36 --> Config Class Initialized
DEBUG - 2022-04-20 14:41:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:36 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:36 --> Config Class Initialized
INFO - 2022-04-20 14:41:36 --> URI Class Initialized
INFO - 2022-04-20 14:41:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:36 --> Router Class Initialized
INFO - 2022-04-20 14:41:36 --> URI Class Initialized
DEBUG - 2022-04-20 14:41:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:36 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:36 --> Output Class Initialized
INFO - 2022-04-20 14:41:36 --> URI Class Initialized
INFO - 2022-04-20 14:41:36 --> Security Class Initialized
INFO - 2022-04-20 14:41:36 --> Router Class Initialized
DEBUG - 2022-04-20 14:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:36 --> Input Class Initialized
INFO - 2022-04-20 14:41:36 --> Output Class Initialized
INFO - 2022-04-20 14:41:36 --> Language Class Initialized
INFO - 2022-04-20 14:41:36 --> Router Class Initialized
INFO - 2022-04-20 14:41:36 --> Security Class Initialized
ERROR - 2022-04-20 14:41:36 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:36 --> Output Class Initialized
INFO - 2022-04-20 14:41:36 --> Input Class Initialized
INFO - 2022-04-20 14:41:36 --> Language Class Initialized
INFO - 2022-04-20 14:41:36 --> Security Class Initialized
ERROR - 2022-04-20 14:41:36 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:36 --> Input Class Initialized
INFO - 2022-04-20 14:41:36 --> Language Class Initialized
ERROR - 2022-04-20 14:41:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:42 --> Config Class Initialized
INFO - 2022-04-20 14:41:42 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:42 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:42 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:42 --> URI Class Initialized
INFO - 2022-04-20 14:41:42 --> Router Class Initialized
INFO - 2022-04-20 14:41:42 --> Output Class Initialized
INFO - 2022-04-20 14:41:42 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:42 --> Input Class Initialized
INFO - 2022-04-20 14:41:42 --> Language Class Initialized
INFO - 2022-04-20 14:41:42 --> Language Class Initialized
INFO - 2022-04-20 14:41:42 --> Config Class Initialized
INFO - 2022-04-20 14:41:42 --> Loader Class Initialized
INFO - 2022-04-20 14:41:42 --> Helper loaded: url_helper
INFO - 2022-04-20 14:41:42 --> Controller Class Initialized
DEBUG - 2022-04-20 14:41:42 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:41:42 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:41:42 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:41:42 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:41:42 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:41:42 --> Final output sent to browser
DEBUG - 2022-04-20 14:41:42 --> Total execution time: 0.0197
INFO - 2022-04-20 14:41:42 --> Config Class Initialized
INFO - 2022-04-20 14:41:42 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:41:42 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:42 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:42 --> Config Class Initialized
INFO - 2022-04-20 14:41:42 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:42 --> URI Class Initialized
INFO - 2022-04-20 14:41:42 --> Router Class Initialized
DEBUG - 2022-04-20 14:41:42 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:41:42 --> Utf8 Class Initialized
INFO - 2022-04-20 14:41:42 --> URI Class Initialized
INFO - 2022-04-20 14:41:42 --> Config Class Initialized
INFO - 2022-04-20 14:41:42 --> Router Class Initialized
INFO - 2022-04-20 14:41:42 --> Hooks Class Initialized
INFO - 2022-04-20 14:41:42 --> Output Class Initialized
INFO - 2022-04-20 14:41:42 --> Output Class Initialized
INFO - 2022-04-20 14:41:42 --> Security Class Initialized
INFO - 2022-04-20 14:41:42 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:42 --> Input Class Initialized
DEBUG - 2022-04-20 14:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:42 --> Input Class Initialized
INFO - 2022-04-20 14:41:42 --> Language Class Initialized
INFO - 2022-04-20 14:41:42 --> Language Class Initialized
DEBUG - 2022-04-20 14:41:42 --> UTF-8 Support Enabled
ERROR - 2022-04-20 14:41:42 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:42 --> Utf8 Class Initialized
ERROR - 2022-04-20 14:41:42 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:41:42 --> URI Class Initialized
INFO - 2022-04-20 14:41:42 --> Router Class Initialized
INFO - 2022-04-20 14:41:42 --> Output Class Initialized
INFO - 2022-04-20 14:41:42 --> Security Class Initialized
DEBUG - 2022-04-20 14:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:41:42 --> Input Class Initialized
INFO - 2022-04-20 14:41:42 --> Language Class Initialized
ERROR - 2022-04-20 14:41:42 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:42:01 --> Config Class Initialized
INFO - 2022-04-20 14:42:01 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:42:01 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:01 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:01 --> URI Class Initialized
INFO - 2022-04-20 14:42:01 --> Router Class Initialized
INFO - 2022-04-20 14:42:01 --> Output Class Initialized
INFO - 2022-04-20 14:42:01 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:01 --> Input Class Initialized
INFO - 2022-04-20 14:42:01 --> Language Class Initialized
INFO - 2022-04-20 14:42:01 --> Language Class Initialized
INFO - 2022-04-20 14:42:01 --> Config Class Initialized
INFO - 2022-04-20 14:42:01 --> Loader Class Initialized
INFO - 2022-04-20 14:42:01 --> Helper loaded: url_helper
INFO - 2022-04-20 14:42:01 --> Controller Class Initialized
DEBUG - 2022-04-20 14:42:01 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:42:01 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:42:01 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:42:01 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:42:01 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:42:01 --> Final output sent to browser
DEBUG - 2022-04-20 14:42:01 --> Total execution time: 0.0185
INFO - 2022-04-20 14:42:01 --> Config Class Initialized
INFO - 2022-04-20 14:42:01 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:42:01 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:01 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:01 --> URI Class Initialized
INFO - 2022-04-20 14:42:01 --> Router Class Initialized
INFO - 2022-04-20 14:42:01 --> Output Class Initialized
INFO - 2022-04-20 14:42:01 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:01 --> Input Class Initialized
INFO - 2022-04-20 14:42:01 --> Language Class Initialized
INFO - 2022-04-20 14:42:01 --> Config Class Initialized
INFO - 2022-04-20 14:42:01 --> Hooks Class Initialized
ERROR - 2022-04-20 14:42:01 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:42:01 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:01 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:01 --> URI Class Initialized
INFO - 2022-04-20 14:42:01 --> Router Class Initialized
INFO - 2022-04-20 14:42:01 --> Output Class Initialized
INFO - 2022-04-20 14:42:01 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:01 --> Input Class Initialized
INFO - 2022-04-20 14:42:01 --> Config Class Initialized
INFO - 2022-04-20 14:42:01 --> Hooks Class Initialized
INFO - 2022-04-20 14:42:01 --> Language Class Initialized
ERROR - 2022-04-20 14:42:01 --> 404 Page Not Found: /index
DEBUG - 2022-04-20 14:42:01 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:01 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:01 --> URI Class Initialized
INFO - 2022-04-20 14:42:01 --> Router Class Initialized
INFO - 2022-04-20 14:42:01 --> Output Class Initialized
INFO - 2022-04-20 14:42:01 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:01 --> Input Class Initialized
INFO - 2022-04-20 14:42:01 --> Language Class Initialized
ERROR - 2022-04-20 14:42:01 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:42:44 --> Config Class Initialized
INFO - 2022-04-20 14:42:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:44 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:44 --> URI Class Initialized
INFO - 2022-04-20 14:42:44 --> Router Class Initialized
INFO - 2022-04-20 14:42:44 --> Output Class Initialized
INFO - 2022-04-20 14:42:44 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:44 --> Input Class Initialized
INFO - 2022-04-20 14:42:44 --> Language Class Initialized
INFO - 2022-04-20 14:42:44 --> Language Class Initialized
INFO - 2022-04-20 14:42:44 --> Config Class Initialized
INFO - 2022-04-20 14:42:44 --> Loader Class Initialized
INFO - 2022-04-20 14:42:44 --> Helper loaded: url_helper
INFO - 2022-04-20 14:42:44 --> Controller Class Initialized
DEBUG - 2022-04-20 14:42:44 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:42:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:42:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:42:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:42:44 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:42:44 --> Final output sent to browser
DEBUG - 2022-04-20 14:42:44 --> Total execution time: 0.0221
INFO - 2022-04-20 14:42:44 --> Config Class Initialized
INFO - 2022-04-20 14:42:44 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:44 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:44 --> Config Class Initialized
INFO - 2022-04-20 14:42:44 --> URI Class Initialized
INFO - 2022-04-20 14:42:44 --> Hooks Class Initialized
INFO - 2022-04-20 14:42:44 --> Config Class Initialized
INFO - 2022-04-20 14:42:44 --> Hooks Class Initialized
INFO - 2022-04-20 14:42:44 --> Router Class Initialized
DEBUG - 2022-04-20 14:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:44 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:42:44 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:42:44 --> Utf8 Class Initialized
INFO - 2022-04-20 14:42:44 --> Output Class Initialized
INFO - 2022-04-20 14:42:44 --> URI Class Initialized
INFO - 2022-04-20 14:42:44 --> URI Class Initialized
INFO - 2022-04-20 14:42:44 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:44 --> Input Class Initialized
INFO - 2022-04-20 14:42:44 --> Language Class Initialized
INFO - 2022-04-20 14:42:44 --> Router Class Initialized
INFO - 2022-04-20 14:42:44 --> Router Class Initialized
INFO - 2022-04-20 14:42:44 --> Output Class Initialized
ERROR - 2022-04-20 14:42:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:42:44 --> Output Class Initialized
INFO - 2022-04-20 14:42:44 --> Security Class Initialized
INFO - 2022-04-20 14:42:44 --> Security Class Initialized
DEBUG - 2022-04-20 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:44 --> Input Class Initialized
DEBUG - 2022-04-20 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:42:44 --> Language Class Initialized
INFO - 2022-04-20 14:42:44 --> Input Class Initialized
ERROR - 2022-04-20 14:42:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:42:44 --> Language Class Initialized
ERROR - 2022-04-20 14:42:44 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:43:13 --> Config Class Initialized
INFO - 2022-04-20 14:43:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:43:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:43:13 --> URI Class Initialized
INFO - 2022-04-20 14:43:13 --> Router Class Initialized
INFO - 2022-04-20 14:43:13 --> Output Class Initialized
INFO - 2022-04-20 14:43:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:13 --> Input Class Initialized
INFO - 2022-04-20 14:43:13 --> Language Class Initialized
INFO - 2022-04-20 14:43:13 --> Language Class Initialized
INFO - 2022-04-20 14:43:13 --> Config Class Initialized
INFO - 2022-04-20 14:43:13 --> Loader Class Initialized
INFO - 2022-04-20 14:43:13 --> Helper loaded: url_helper
INFO - 2022-04-20 14:43:13 --> Controller Class Initialized
DEBUG - 2022-04-20 14:43:13 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:43:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:43:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:43:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:43:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:43:13 --> Final output sent to browser
DEBUG - 2022-04-20 14:43:13 --> Total execution time: 0.0198
INFO - 2022-04-20 14:43:13 --> Config Class Initialized
INFO - 2022-04-20 14:43:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:43:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:43:13 --> Config Class Initialized
INFO - 2022-04-20 14:43:13 --> Hooks Class Initialized
INFO - 2022-04-20 14:43:13 --> URI Class Initialized
INFO - 2022-04-20 14:43:13 --> Config Class Initialized
INFO - 2022-04-20 14:43:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:43:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:13 --> Router Class Initialized
INFO - 2022-04-20 14:43:13 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:43:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:43:13 --> URI Class Initialized
INFO - 2022-04-20 14:43:13 --> Output Class Initialized
INFO - 2022-04-20 14:43:13 --> URI Class Initialized
INFO - 2022-04-20 14:43:13 --> Security Class Initialized
INFO - 2022-04-20 14:43:13 --> Router Class Initialized
DEBUG - 2022-04-20 14:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:13 --> Input Class Initialized
INFO - 2022-04-20 14:43:13 --> Router Class Initialized
INFO - 2022-04-20 14:43:13 --> Language Class Initialized
INFO - 2022-04-20 14:43:13 --> Output Class Initialized
ERROR - 2022-04-20 14:43:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:43:13 --> Output Class Initialized
INFO - 2022-04-20 14:43:13 --> Security Class Initialized
INFO - 2022-04-20 14:43:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:13 --> Input Class Initialized
DEBUG - 2022-04-20 14:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:13 --> Input Class Initialized
INFO - 2022-04-20 14:43:13 --> Language Class Initialized
INFO - 2022-04-20 14:43:13 --> Language Class Initialized
ERROR - 2022-04-20 14:43:13 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:43:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:43:31 --> Config Class Initialized
INFO - 2022-04-20 14:43:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:43:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:43:31 --> URI Class Initialized
INFO - 2022-04-20 14:43:31 --> Router Class Initialized
INFO - 2022-04-20 14:43:31 --> Output Class Initialized
INFO - 2022-04-20 14:43:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:31 --> Input Class Initialized
INFO - 2022-04-20 14:43:31 --> Language Class Initialized
INFO - 2022-04-20 14:43:31 --> Language Class Initialized
INFO - 2022-04-20 14:43:31 --> Config Class Initialized
INFO - 2022-04-20 14:43:31 --> Loader Class Initialized
INFO - 2022-04-20 14:43:31 --> Helper loaded: url_helper
INFO - 2022-04-20 14:43:31 --> Controller Class Initialized
DEBUG - 2022-04-20 14:43:31 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:43:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:43:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:43:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:43:31 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:43:31 --> Final output sent to browser
DEBUG - 2022-04-20 14:43:31 --> Total execution time: 0.0203
INFO - 2022-04-20 14:43:31 --> Config Class Initialized
INFO - 2022-04-20 14:43:31 --> Hooks Class Initialized
INFO - 2022-04-20 14:43:31 --> Config Class Initialized
INFO - 2022-04-20 14:43:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:43:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:31 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:43:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:43:31 --> URI Class Initialized
INFO - 2022-04-20 14:43:31 --> URI Class Initialized
INFO - 2022-04-20 14:43:31 --> Router Class Initialized
INFO - 2022-04-20 14:43:31 --> Router Class Initialized
INFO - 2022-04-20 14:43:31 --> Output Class Initialized
INFO - 2022-04-20 14:43:31 --> Output Class Initialized
INFO - 2022-04-20 14:43:31 --> Security Class Initialized
INFO - 2022-04-20 14:43:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:31 --> Input Class Initialized
DEBUG - 2022-04-20 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:31 --> Input Class Initialized
INFO - 2022-04-20 14:43:31 --> Language Class Initialized
INFO - 2022-04-20 14:43:31 --> Language Class Initialized
ERROR - 2022-04-20 14:43:31 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:43:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:43:31 --> Config Class Initialized
INFO - 2022-04-20 14:43:31 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:43:31 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:43:31 --> Utf8 Class Initialized
INFO - 2022-04-20 14:43:31 --> URI Class Initialized
INFO - 2022-04-20 14:43:31 --> Router Class Initialized
INFO - 2022-04-20 14:43:31 --> Output Class Initialized
INFO - 2022-04-20 14:43:31 --> Security Class Initialized
DEBUG - 2022-04-20 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:43:31 --> Input Class Initialized
INFO - 2022-04-20 14:43:31 --> Language Class Initialized
ERROR - 2022-04-20 14:43:31 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:44:28 --> Config Class Initialized
INFO - 2022-04-20 14:44:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:44:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:44:28 --> Utf8 Class Initialized
INFO - 2022-04-20 14:44:28 --> URI Class Initialized
INFO - 2022-04-20 14:44:28 --> Router Class Initialized
INFO - 2022-04-20 14:44:28 --> Output Class Initialized
INFO - 2022-04-20 14:44:28 --> Security Class Initialized
DEBUG - 2022-04-20 14:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:44:28 --> Input Class Initialized
INFO - 2022-04-20 14:44:28 --> Language Class Initialized
INFO - 2022-04-20 14:44:28 --> Language Class Initialized
INFO - 2022-04-20 14:44:28 --> Config Class Initialized
INFO - 2022-04-20 14:44:28 --> Loader Class Initialized
INFO - 2022-04-20 14:44:28 --> Helper loaded: url_helper
INFO - 2022-04-20 14:44:28 --> Controller Class Initialized
DEBUG - 2022-04-20 14:44:28 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:44:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:44:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:44:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:44:28 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:44:28 --> Final output sent to browser
DEBUG - 2022-04-20 14:44:28 --> Total execution time: 0.0185
INFO - 2022-04-20 14:44:28 --> Config Class Initialized
INFO - 2022-04-20 14:44:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:44:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:44:28 --> Utf8 Class Initialized
INFO - 2022-04-20 14:44:28 --> URI Class Initialized
INFO - 2022-04-20 14:44:28 --> Config Class Initialized
INFO - 2022-04-20 14:44:28 --> Hooks Class Initialized
INFO - 2022-04-20 14:44:28 --> Router Class Initialized
INFO - 2022-04-20 14:44:28 --> Config Class Initialized
INFO - 2022-04-20 14:44:28 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:44:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:44:28 --> Output Class Initialized
INFO - 2022-04-20 14:44:28 --> Security Class Initialized
INFO - 2022-04-20 14:44:28 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:44:28 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:44:28 --> Utf8 Class Initialized
DEBUG - 2022-04-20 14:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:44:28 --> Input Class Initialized
INFO - 2022-04-20 14:44:28 --> URI Class Initialized
INFO - 2022-04-20 14:44:28 --> URI Class Initialized
INFO - 2022-04-20 14:44:28 --> Language Class Initialized
ERROR - 2022-04-20 14:44:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:44:28 --> Router Class Initialized
INFO - 2022-04-20 14:44:28 --> Router Class Initialized
INFO - 2022-04-20 14:44:28 --> Output Class Initialized
INFO - 2022-04-20 14:44:28 --> Output Class Initialized
INFO - 2022-04-20 14:44:28 --> Security Class Initialized
INFO - 2022-04-20 14:44:28 --> Security Class Initialized
DEBUG - 2022-04-20 14:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:44:28 --> Input Class Initialized
DEBUG - 2022-04-20 14:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:44:28 --> Language Class Initialized
INFO - 2022-04-20 14:44:28 --> Input Class Initialized
INFO - 2022-04-20 14:44:28 --> Language Class Initialized
ERROR - 2022-04-20 14:44:28 --> 404 Page Not Found: /index
ERROR - 2022-04-20 14:44:28 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:45:13 --> Config Class Initialized
INFO - 2022-04-20 14:45:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:45:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:45:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:45:13 --> URI Class Initialized
INFO - 2022-04-20 14:45:13 --> Router Class Initialized
INFO - 2022-04-20 14:45:13 --> Output Class Initialized
INFO - 2022-04-20 14:45:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:45:13 --> Input Class Initialized
INFO - 2022-04-20 14:45:13 --> Language Class Initialized
INFO - 2022-04-20 14:45:13 --> Language Class Initialized
INFO - 2022-04-20 14:45:13 --> Config Class Initialized
INFO - 2022-04-20 14:45:13 --> Loader Class Initialized
INFO - 2022-04-20 14:45:13 --> Helper loaded: url_helper
INFO - 2022-04-20 14:45:13 --> Controller Class Initialized
DEBUG - 2022-04-20 14:45:13 --> About MX_Controller Initialized
DEBUG - 2022-04-20 14:45:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 14:45:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 14:45:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/about/views/about_view.php
DEBUG - 2022-04-20 14:45:13 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 14:45:13 --> Final output sent to browser
DEBUG - 2022-04-20 14:45:13 --> Total execution time: 0.0189
INFO - 2022-04-20 14:45:13 --> Config Class Initialized
INFO - 2022-04-20 14:45:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:45:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:45:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:45:13 --> Config Class Initialized
INFO - 2022-04-20 14:45:13 --> Hooks Class Initialized
INFO - 2022-04-20 14:45:13 --> URI Class Initialized
DEBUG - 2022-04-20 14:45:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:45:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:45:13 --> Router Class Initialized
INFO - 2022-04-20 14:45:13 --> URI Class Initialized
INFO - 2022-04-20 14:45:13 --> Output Class Initialized
INFO - 2022-04-20 14:45:13 --> Router Class Initialized
INFO - 2022-04-20 14:45:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:45:13 --> Input Class Initialized
INFO - 2022-04-20 14:45:13 --> Output Class Initialized
INFO - 2022-04-20 14:45:13 --> Language Class Initialized
ERROR - 2022-04-20 14:45:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:45:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:45:13 --> Input Class Initialized
INFO - 2022-04-20 14:45:13 --> Language Class Initialized
INFO - 2022-04-20 14:45:13 --> Config Class Initialized
ERROR - 2022-04-20 14:45:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 14:45:13 --> Hooks Class Initialized
DEBUG - 2022-04-20 14:45:13 --> UTF-8 Support Enabled
INFO - 2022-04-20 14:45:13 --> Utf8 Class Initialized
INFO - 2022-04-20 14:45:13 --> URI Class Initialized
INFO - 2022-04-20 14:45:13 --> Router Class Initialized
INFO - 2022-04-20 14:45:13 --> Output Class Initialized
INFO - 2022-04-20 14:45:13 --> Security Class Initialized
DEBUG - 2022-04-20 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 14:45:13 --> Input Class Initialized
INFO - 2022-04-20 14:45:13 --> Language Class Initialized
ERROR - 2022-04-20 14:45:13 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:06:49 --> Config Class Initialized
INFO - 2022-04-20 15:06:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:06:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:06:49 --> Utf8 Class Initialized
INFO - 2022-04-20 15:06:49 --> URI Class Initialized
INFO - 2022-04-20 15:06:49 --> Router Class Initialized
INFO - 2022-04-20 15:06:49 --> Output Class Initialized
INFO - 2022-04-20 15:06:49 --> Security Class Initialized
DEBUG - 2022-04-20 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:06:49 --> Input Class Initialized
INFO - 2022-04-20 15:06:49 --> Language Class Initialized
INFO - 2022-04-20 15:06:49 --> Language Class Initialized
INFO - 2022-04-20 15:06:49 --> Config Class Initialized
INFO - 2022-04-20 15:06:49 --> Loader Class Initialized
INFO - 2022-04-20 15:06:49 --> Helper loaded: url_helper
INFO - 2022-04-20 15:06:49 --> Controller Class Initialized
DEBUG - 2022-04-20 15:06:49 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 15:06:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:06:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:06:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 15:06:49 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:06:49 --> Final output sent to browser
DEBUG - 2022-04-20 15:06:49 --> Total execution time: 0.0215
INFO - 2022-04-20 15:06:49 --> Config Class Initialized
INFO - 2022-04-20 15:06:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:06:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:06:49 --> Utf8 Class Initialized
INFO - 2022-04-20 15:06:49 --> URI Class Initialized
INFO - 2022-04-20 15:06:49 --> Config Class Initialized
INFO - 2022-04-20 15:06:49 --> Hooks Class Initialized
INFO - 2022-04-20 15:06:49 --> Router Class Initialized
DEBUG - 2022-04-20 15:06:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:06:49 --> Utf8 Class Initialized
INFO - 2022-04-20 15:06:49 --> Output Class Initialized
INFO - 2022-04-20 15:06:49 --> URI Class Initialized
INFO - 2022-04-20 15:06:49 --> Security Class Initialized
DEBUG - 2022-04-20 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:06:49 --> Input Class Initialized
INFO - 2022-04-20 15:06:49 --> Language Class Initialized
INFO - 2022-04-20 15:06:49 --> Router Class Initialized
ERROR - 2022-04-20 15:06:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:06:49 --> Output Class Initialized
INFO - 2022-04-20 15:06:49 --> Security Class Initialized
DEBUG - 2022-04-20 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:06:49 --> Input Class Initialized
INFO - 2022-04-20 15:06:49 --> Language Class Initialized
ERROR - 2022-04-20 15:06:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:06:49 --> Config Class Initialized
INFO - 2022-04-20 15:06:49 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:06:49 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:06:49 --> Utf8 Class Initialized
INFO - 2022-04-20 15:06:49 --> URI Class Initialized
INFO - 2022-04-20 15:06:49 --> Router Class Initialized
INFO - 2022-04-20 15:06:49 --> Output Class Initialized
INFO - 2022-04-20 15:06:49 --> Security Class Initialized
DEBUG - 2022-04-20 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:06:49 --> Input Class Initialized
INFO - 2022-04-20 15:06:49 --> Language Class Initialized
ERROR - 2022-04-20 15:06:49 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:11:12 --> Config Class Initialized
INFO - 2022-04-20 15:11:12 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:11:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:11:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:11:12 --> URI Class Initialized
INFO - 2022-04-20 15:11:12 --> Router Class Initialized
INFO - 2022-04-20 15:11:12 --> Output Class Initialized
INFO - 2022-04-20 15:11:12 --> Security Class Initialized
DEBUG - 2022-04-20 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:11:12 --> Input Class Initialized
INFO - 2022-04-20 15:11:12 --> Language Class Initialized
INFO - 2022-04-20 15:11:12 --> Language Class Initialized
INFO - 2022-04-20 15:11:12 --> Config Class Initialized
INFO - 2022-04-20 15:11:12 --> Loader Class Initialized
INFO - 2022-04-20 15:11:12 --> Helper loaded: url_helper
INFO - 2022-04-20 15:11:12 --> Controller Class Initialized
DEBUG - 2022-04-20 15:11:12 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 15:11:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:11:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:11:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 15:11:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:11:12 --> Final output sent to browser
DEBUG - 2022-04-20 15:11:12 --> Total execution time: 0.0180
INFO - 2022-04-20 15:11:12 --> Config Class Initialized
INFO - 2022-04-20 15:11:12 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:11:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:11:12 --> Config Class Initialized
INFO - 2022-04-20 15:11:12 --> Hooks Class Initialized
INFO - 2022-04-20 15:11:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:11:12 --> Config Class Initialized
INFO - 2022-04-20 15:11:12 --> Hooks Class Initialized
INFO - 2022-04-20 15:11:12 --> URI Class Initialized
DEBUG - 2022-04-20 15:11:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:11:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:11:12 --> URI Class Initialized
INFO - 2022-04-20 15:11:12 --> Router Class Initialized
INFO - 2022-04-20 15:11:12 --> Router Class Initialized
INFO - 2022-04-20 15:11:12 --> Output Class Initialized
DEBUG - 2022-04-20 15:11:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:11:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:11:12 --> Output Class Initialized
INFO - 2022-04-20 15:11:12 --> Security Class Initialized
INFO - 2022-04-20 15:11:12 --> URI Class Initialized
DEBUG - 2022-04-20 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:11:12 --> Input Class Initialized
INFO - 2022-04-20 15:11:12 --> Security Class Initialized
INFO - 2022-04-20 15:11:12 --> Language Class Initialized
DEBUG - 2022-04-20 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:11:12 --> Input Class Initialized
INFO - 2022-04-20 15:11:12 --> Router Class Initialized
ERROR - 2022-04-20 15:11:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:11:12 --> Language Class Initialized
INFO - 2022-04-20 15:11:12 --> Output Class Initialized
ERROR - 2022-04-20 15:11:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:11:12 --> Security Class Initialized
DEBUG - 2022-04-20 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:11:12 --> Input Class Initialized
INFO - 2022-04-20 15:11:12 --> Language Class Initialized
ERROR - 2022-04-20 15:11:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:12:12 --> Config Class Initialized
INFO - 2022-04-20 15:12:12 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:12:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:12:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:12:12 --> URI Class Initialized
INFO - 2022-04-20 15:12:12 --> Router Class Initialized
INFO - 2022-04-20 15:12:12 --> Output Class Initialized
INFO - 2022-04-20 15:12:12 --> Security Class Initialized
DEBUG - 2022-04-20 15:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:12:12 --> Input Class Initialized
INFO - 2022-04-20 15:12:12 --> Language Class Initialized
INFO - 2022-04-20 15:12:12 --> Language Class Initialized
INFO - 2022-04-20 15:12:12 --> Config Class Initialized
INFO - 2022-04-20 15:12:12 --> Loader Class Initialized
INFO - 2022-04-20 15:12:12 --> Helper loaded: url_helper
INFO - 2022-04-20 15:12:12 --> Controller Class Initialized
DEBUG - 2022-04-20 15:12:12 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 15:12:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:12:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:12:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 15:12:12 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:12:12 --> Final output sent to browser
DEBUG - 2022-04-20 15:12:12 --> Total execution time: 0.0186
INFO - 2022-04-20 15:12:12 --> Config Class Initialized
INFO - 2022-04-20 15:12:12 --> Hooks Class Initialized
INFO - 2022-04-20 15:12:12 --> Config Class Initialized
INFO - 2022-04-20 15:12:12 --> Hooks Class Initialized
INFO - 2022-04-20 15:12:12 --> Config Class Initialized
INFO - 2022-04-20 15:12:12 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:12:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:12:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:12:12 --> URI Class Initialized
DEBUG - 2022-04-20 15:12:12 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:12:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:12:12 --> Router Class Initialized
INFO - 2022-04-20 15:12:12 --> URI Class Initialized
INFO - 2022-04-20 15:12:12 --> Output Class Initialized
INFO - 2022-04-20 15:12:12 --> Security Class Initialized
INFO - 2022-04-20 15:12:12 --> Router Class Initialized
DEBUG - 2022-04-20 15:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:12:12 --> Input Class Initialized
INFO - 2022-04-20 15:12:12 --> Output Class Initialized
INFO - 2022-04-20 15:12:12 --> Language Class Initialized
ERROR - 2022-04-20 15:12:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:12:12 --> Security Class Initialized
DEBUG - 2022-04-20 15:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:12:12 --> Input Class Initialized
INFO - 2022-04-20 15:12:12 --> Language Class Initialized
DEBUG - 2022-04-20 15:12:12 --> UTF-8 Support Enabled
ERROR - 2022-04-20 15:12:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:12:12 --> Utf8 Class Initialized
INFO - 2022-04-20 15:12:12 --> URI Class Initialized
INFO - 2022-04-20 15:12:12 --> Router Class Initialized
INFO - 2022-04-20 15:12:12 --> Output Class Initialized
INFO - 2022-04-20 15:12:12 --> Security Class Initialized
DEBUG - 2022-04-20 15:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:12:12 --> Input Class Initialized
INFO - 2022-04-20 15:12:12 --> Language Class Initialized
ERROR - 2022-04-20 15:12:12 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:36 --> Config Class Initialized
INFO - 2022-04-20 15:15:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:36 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:36 --> URI Class Initialized
INFO - 2022-04-20 15:15:36 --> Router Class Initialized
INFO - 2022-04-20 15:15:36 --> Output Class Initialized
INFO - 2022-04-20 15:15:36 --> Security Class Initialized
DEBUG - 2022-04-20 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:36 --> Input Class Initialized
INFO - 2022-04-20 15:15:36 --> Language Class Initialized
INFO - 2022-04-20 15:15:36 --> Language Class Initialized
INFO - 2022-04-20 15:15:36 --> Config Class Initialized
INFO - 2022-04-20 15:15:36 --> Loader Class Initialized
INFO - 2022-04-20 15:15:36 --> Helper loaded: url_helper
INFO - 2022-04-20 15:15:36 --> Controller Class Initialized
DEBUG - 2022-04-20 15:15:36 --> Product MX_Controller Initialized
DEBUG - 2022-04-20 15:15:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:15:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:15:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/product/views/product_view.php
DEBUG - 2022-04-20 15:15:36 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:15:36 --> Final output sent to browser
DEBUG - 2022-04-20 15:15:36 --> Total execution time: 0.0199
INFO - 2022-04-20 15:15:36 --> Config Class Initialized
INFO - 2022-04-20 15:15:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:36 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:36 --> URI Class Initialized
INFO - 2022-04-20 15:15:36 --> Router Class Initialized
INFO - 2022-04-20 15:15:36 --> Output Class Initialized
INFO - 2022-04-20 15:15:36 --> Config Class Initialized
INFO - 2022-04-20 15:15:36 --> Hooks Class Initialized
INFO - 2022-04-20 15:15:36 --> Security Class Initialized
DEBUG - 2022-04-20 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:36 --> Input Class Initialized
INFO - 2022-04-20 15:15:36 --> Language Class Initialized
INFO - 2022-04-20 15:15:36 --> Config Class Initialized
INFO - 2022-04-20 15:15:36 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:36 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:36 --> URI Class Initialized
DEBUG - 2022-04-20 15:15:36 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:36 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:36 --> URI Class Initialized
INFO - 2022-04-20 15:15:36 --> Router Class Initialized
INFO - 2022-04-20 15:15:36 --> Output Class Initialized
INFO - 2022-04-20 15:15:36 --> Router Class Initialized
INFO - 2022-04-20 15:15:36 --> Security Class Initialized
INFO - 2022-04-20 15:15:36 --> Output Class Initialized
DEBUG - 2022-04-20 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:36 --> Input Class Initialized
INFO - 2022-04-20 15:15:36 --> Security Class Initialized
INFO - 2022-04-20 15:15:36 --> Language Class Initialized
DEBUG - 2022-04-20 15:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:15:36 --> 404 Page Not Found: /index
ERROR - 2022-04-20 15:15:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:36 --> Input Class Initialized
INFO - 2022-04-20 15:15:36 --> Language Class Initialized
ERROR - 2022-04-20 15:15:36 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:39 --> Config Class Initialized
INFO - 2022-04-20 15:15:39 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:39 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:39 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:39 --> URI Class Initialized
DEBUG - 2022-04-20 15:15:40 --> No URI present. Default controller set.
INFO - 2022-04-20 15:15:40 --> Router Class Initialized
INFO - 2022-04-20 15:15:40 --> Output Class Initialized
INFO - 2022-04-20 15:15:40 --> Security Class Initialized
DEBUG - 2022-04-20 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:40 --> Input Class Initialized
INFO - 2022-04-20 15:15:40 --> Language Class Initialized
INFO - 2022-04-20 15:15:40 --> Language Class Initialized
INFO - 2022-04-20 15:15:40 --> Config Class Initialized
INFO - 2022-04-20 15:15:40 --> Loader Class Initialized
INFO - 2022-04-20 15:15:40 --> Helper loaded: url_helper
INFO - 2022-04-20 15:15:40 --> Controller Class Initialized
DEBUG - 2022-04-20 15:15:40 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 15:15:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:15:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:15:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 15:15:40 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:15:40 --> Final output sent to browser
DEBUG - 2022-04-20 15:15:40 --> Total execution time: 0.0217
INFO - 2022-04-20 15:15:40 --> Config Class Initialized
INFO - 2022-04-20 15:15:40 --> Config Class Initialized
INFO - 2022-04-20 15:15:40 --> Hooks Class Initialized
INFO - 2022-04-20 15:15:40 --> Config Class Initialized
INFO - 2022-04-20 15:15:40 --> Hooks Class Initialized
INFO - 2022-04-20 15:15:40 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:15:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:40 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:40 --> Utf8 Class Initialized
DEBUG - 2022-04-20 15:15:40 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:40 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:40 --> URI Class Initialized
INFO - 2022-04-20 15:15:40 --> URI Class Initialized
INFO - 2022-04-20 15:15:40 --> URI Class Initialized
INFO - 2022-04-20 15:15:40 --> Router Class Initialized
INFO - 2022-04-20 15:15:40 --> Router Class Initialized
INFO - 2022-04-20 15:15:40 --> Output Class Initialized
INFO - 2022-04-20 15:15:40 --> Output Class Initialized
INFO - 2022-04-20 15:15:40 --> Router Class Initialized
INFO - 2022-04-20 15:15:40 --> Security Class Initialized
INFO - 2022-04-20 15:15:40 --> Security Class Initialized
INFO - 2022-04-20 15:15:40 --> Output Class Initialized
DEBUG - 2022-04-20 15:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:40 --> Input Class Initialized
INFO - 2022-04-20 15:15:40 --> Input Class Initialized
INFO - 2022-04-20 15:15:40 --> Security Class Initialized
INFO - 2022-04-20 15:15:40 --> Language Class Initialized
INFO - 2022-04-20 15:15:40 --> Language Class Initialized
DEBUG - 2022-04-20 15:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:15:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:40 --> Input Class Initialized
ERROR - 2022-04-20 15:15:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:40 --> Language Class Initialized
ERROR - 2022-04-20 15:15:40 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:59 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:59 --> URI Class Initialized
INFO - 2022-04-20 15:15:59 --> Router Class Initialized
INFO - 2022-04-20 15:15:59 --> Output Class Initialized
INFO - 2022-04-20 15:15:59 --> Security Class Initialized
DEBUG - 2022-04-20 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:59 --> Input Class Initialized
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Loader Class Initialized
INFO - 2022-04-20 15:15:59 --> Helper loaded: url_helper
INFO - 2022-04-20 15:15:59 --> Controller Class Initialized
DEBUG - 2022-04-20 15:15:59 --> contact MX_Controller Initialized
DEBUG - 2022-04-20 15:15:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:15:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:15:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/contact/views/contact_view.php
DEBUG - 2022-04-20 15:15:59 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:15:59 --> Final output sent to browser
DEBUG - 2022-04-20 15:15:59 --> Total execution time: 0.0201
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Hooks Class Initialized
INFO - 2022-04-20 15:15:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:15:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:59 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:59 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Hooks Class Initialized
INFO - 2022-04-20 15:15:59 --> URI Class Initialized
INFO - 2022-04-20 15:15:59 --> URI Class Initialized
DEBUG - 2022-04-20 15:15:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:59 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:59 --> Router Class Initialized
INFO - 2022-04-20 15:15:59 --> Router Class Initialized
INFO - 2022-04-20 15:15:59 --> URI Class Initialized
INFO - 2022-04-20 15:15:59 --> Output Class Initialized
INFO - 2022-04-20 15:15:59 --> Output Class Initialized
INFO - 2022-04-20 15:15:59 --> Security Class Initialized
INFO - 2022-04-20 15:15:59 --> Router Class Initialized
DEBUG - 2022-04-20 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:59 --> Security Class Initialized
INFO - 2022-04-20 15:15:59 --> Input Class Initialized
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
INFO - 2022-04-20 15:15:59 --> Output Class Initialized
DEBUG - 2022-04-20 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:59 --> Input Class Initialized
ERROR - 2022-04-20 15:15:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:59 --> Security Class Initialized
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
DEBUG - 2022-04-20 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:59 --> Input Class Initialized
ERROR - 2022-04-20 15:15:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
ERROR - 2022-04-20 15:15:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:59 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:59 --> URI Class Initialized
INFO - 2022-04-20 15:15:59 --> Router Class Initialized
INFO - 2022-04-20 15:15:59 --> Output Class Initialized
INFO - 2022-04-20 15:15:59 --> Security Class Initialized
DEBUG - 2022-04-20 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:59 --> Input Class Initialized
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
ERROR - 2022-04-20 15:15:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:15:59 --> Config Class Initialized
INFO - 2022-04-20 15:15:59 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:15:59 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:15:59 --> Utf8 Class Initialized
INFO - 2022-04-20 15:15:59 --> URI Class Initialized
INFO - 2022-04-20 15:15:59 --> Router Class Initialized
INFO - 2022-04-20 15:15:59 --> Output Class Initialized
INFO - 2022-04-20 15:15:59 --> Security Class Initialized
DEBUG - 2022-04-20 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:15:59 --> Input Class Initialized
INFO - 2022-04-20 15:15:59 --> Language Class Initialized
ERROR - 2022-04-20 15:15:59 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:16:03 --> Config Class Initialized
INFO - 2022-04-20 15:16:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:16:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:16:03 --> Utf8 Class Initialized
INFO - 2022-04-20 15:16:03 --> URI Class Initialized
DEBUG - 2022-04-20 15:16:03 --> No URI present. Default controller set.
INFO - 2022-04-20 15:16:03 --> Router Class Initialized
INFO - 2022-04-20 15:16:03 --> Output Class Initialized
INFO - 2022-04-20 15:16:03 --> Security Class Initialized
DEBUG - 2022-04-20 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:16:03 --> Input Class Initialized
INFO - 2022-04-20 15:16:03 --> Language Class Initialized
INFO - 2022-04-20 15:16:03 --> Language Class Initialized
INFO - 2022-04-20 15:16:03 --> Config Class Initialized
INFO - 2022-04-20 15:16:03 --> Loader Class Initialized
INFO - 2022-04-20 15:16:03 --> Helper loaded: url_helper
INFO - 2022-04-20 15:16:03 --> Controller Class Initialized
DEBUG - 2022-04-20 15:16:03 --> Home MX_Controller Initialized
DEBUG - 2022-04-20 15:16:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/head.php
DEBUG - 2022-04-20 15:16:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/header.php
DEBUG - 2022-04-20 15:16:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/home/views/home_view.php
DEBUG - 2022-04-20 15:16:03 --> File loaded: C:\xampp\htdocs\saheli\application\modules/common/views/footer.php
INFO - 2022-04-20 15:16:03 --> Final output sent to browser
DEBUG - 2022-04-20 15:16:03 --> Total execution time: 0.0189
INFO - 2022-04-20 15:16:03 --> Config Class Initialized
INFO - 2022-04-20 15:16:03 --> Config Class Initialized
INFO - 2022-04-20 15:16:03 --> Hooks Class Initialized
INFO - 2022-04-20 15:16:03 --> Hooks Class Initialized
DEBUG - 2022-04-20 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:16:03 --> UTF-8 Support Enabled
INFO - 2022-04-20 15:16:03 --> Utf8 Class Initialized
INFO - 2022-04-20 15:16:03 --> Utf8 Class Initialized
INFO - 2022-04-20 15:16:03 --> URI Class Initialized
INFO - 2022-04-20 15:16:03 --> URI Class Initialized
INFO - 2022-04-20 15:16:03 --> Router Class Initialized
INFO - 2022-04-20 15:16:03 --> Router Class Initialized
INFO - 2022-04-20 15:16:03 --> Config Class Initialized
INFO - 2022-04-20 15:16:03 --> Hooks Class Initialized
INFO - 2022-04-20 15:16:03 --> Output Class Initialized
INFO - 2022-04-20 15:16:03 --> Output Class Initialized
INFO - 2022-04-20 15:16:03 --> Security Class Initialized
INFO - 2022-04-20 15:16:03 --> Security Class Initialized
DEBUG - 2022-04-20 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:16:03 --> Utf8 Class Initialized
DEBUG - 2022-04-20 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:16:03 --> Input Class Initialized
INFO - 2022-04-20 15:16:03 --> Input Class Initialized
INFO - 2022-04-20 15:16:03 --> URI Class Initialized
INFO - 2022-04-20 15:16:03 --> Language Class Initialized
INFO - 2022-04-20 15:16:03 --> Language Class Initialized
ERROR - 2022-04-20 15:16:03 --> 404 Page Not Found: /index
ERROR - 2022-04-20 15:16:03 --> 404 Page Not Found: /index
INFO - 2022-04-20 15:16:03 --> Router Class Initialized
INFO - 2022-04-20 15:16:03 --> Output Class Initialized
INFO - 2022-04-20 15:16:03 --> Security Class Initialized
DEBUG - 2022-04-20 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-20 15:16:03 --> Input Class Initialized
INFO - 2022-04-20 15:16:03 --> Language Class Initialized
ERROR - 2022-04-20 15:16:03 --> 404 Page Not Found: /index
