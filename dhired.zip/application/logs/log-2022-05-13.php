<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-13 07:24:39 --> Config Class Initialized
INFO - 2022-05-13 07:24:39 --> Hooks Class Initialized
DEBUG - 2022-05-13 07:24:39 --> UTF-8 Support Enabled
INFO - 2022-05-13 07:24:39 --> Utf8 Class Initialized
INFO - 2022-05-13 07:24:39 --> URI Class Initialized
DEBUG - 2022-05-13 07:24:39 --> No URI present. Default controller set.
INFO - 2022-05-13 07:24:39 --> Router Class Initialized
INFO - 2022-05-13 07:24:39 --> Output Class Initialized
INFO - 2022-05-13 07:24:39 --> Security Class Initialized
DEBUG - 2022-05-13 07:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 07:24:39 --> Input Class Initialized
INFO - 2022-05-13 07:24:39 --> Language Class Initialized
INFO - 2022-05-13 07:24:39 --> Language Class Initialized
INFO - 2022-05-13 07:24:39 --> Config Class Initialized
INFO - 2022-05-13 07:24:39 --> Loader Class Initialized
INFO - 2022-05-13 07:24:39 --> Helper loaded: url_helper
INFO - 2022-05-13 07:24:39 --> Database Driver Class Initialized
ERROR - 2022-05-13 07:24:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'motodeal' C:\xampp\htdocs\motodeal\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2022-05-13 07:24:39 --> Unable to connect to the database
INFO - 2022-05-13 07:24:39 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-13 07:26:04 --> Config Class Initialized
INFO - 2022-05-13 07:26:04 --> Hooks Class Initialized
DEBUG - 2022-05-13 07:26:04 --> UTF-8 Support Enabled
INFO - 2022-05-13 07:26:04 --> Utf8 Class Initialized
INFO - 2022-05-13 07:26:04 --> URI Class Initialized
DEBUG - 2022-05-13 07:26:04 --> No URI present. Default controller set.
INFO - 2022-05-13 07:26:04 --> Router Class Initialized
INFO - 2022-05-13 07:26:04 --> Output Class Initialized
INFO - 2022-05-13 07:26:04 --> Security Class Initialized
DEBUG - 2022-05-13 07:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 07:26:04 --> Input Class Initialized
INFO - 2022-05-13 07:26:04 --> Language Class Initialized
INFO - 2022-05-13 07:26:04 --> Language Class Initialized
INFO - 2022-05-13 07:26:04 --> Config Class Initialized
INFO - 2022-05-13 07:26:04 --> Loader Class Initialized
INFO - 2022-05-13 07:26:04 --> Helper loaded: url_helper
INFO - 2022-05-13 07:26:04 --> Database Driver Class Initialized
INFO - 2022-05-13 07:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 07:26:04 --> Controller Class Initialized
DEBUG - 2022-05-13 07:26:04 --> Admin MX_Controller Initialized
INFO - 2022-05-13 07:26:04 --> Model Class Initialized
DEBUG - 2022-05-13 07:26:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 07:26:04 --> Model Class Initialized
DEBUG - 2022-05-13 07:26:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-13 07:26:04 --> Final output sent to browser
DEBUG - 2022-05-13 07:26:04 --> Total execution time: 0.0393
INFO - 2022-05-13 07:26:12 --> Config Class Initialized
INFO - 2022-05-13 07:26:12 --> Hooks Class Initialized
DEBUG - 2022-05-13 07:26:12 --> UTF-8 Support Enabled
INFO - 2022-05-13 07:26:12 --> Utf8 Class Initialized
INFO - 2022-05-13 07:26:12 --> URI Class Initialized
INFO - 2022-05-13 07:26:12 --> Router Class Initialized
INFO - 2022-05-13 07:26:12 --> Output Class Initialized
INFO - 2022-05-13 07:26:12 --> Security Class Initialized
DEBUG - 2022-05-13 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 07:26:12 --> Input Class Initialized
INFO - 2022-05-13 07:26:12 --> Language Class Initialized
INFO - 2022-05-13 07:26:12 --> Language Class Initialized
INFO - 2022-05-13 07:26:12 --> Config Class Initialized
INFO - 2022-05-13 07:26:12 --> Loader Class Initialized
INFO - 2022-05-13 07:26:12 --> Helper loaded: url_helper
INFO - 2022-05-13 07:26:12 --> Database Driver Class Initialized
INFO - 2022-05-13 07:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 07:26:12 --> Controller Class Initialized
DEBUG - 2022-05-13 07:26:12 --> Admin MX_Controller Initialized
INFO - 2022-05-13 07:26:12 --> Model Class Initialized
DEBUG - 2022-05-13 07:26:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 07:26:12 --> Model Class Initialized
DEBUG - 2022-05-13 07:26:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 07:26:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 07:26:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-13 07:26:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 07:26:12 --> Final output sent to browser
DEBUG - 2022-05-13 07:26:12 --> Total execution time: 0.0529
INFO - 2022-05-13 07:26:17 --> Config Class Initialized
INFO - 2022-05-13 07:26:17 --> Hooks Class Initialized
DEBUG - 2022-05-13 07:26:17 --> UTF-8 Support Enabled
INFO - 2022-05-13 07:26:17 --> Utf8 Class Initialized
INFO - 2022-05-13 07:26:17 --> URI Class Initialized
INFO - 2022-05-13 07:26:17 --> Router Class Initialized
INFO - 2022-05-13 07:26:17 --> Output Class Initialized
INFO - 2022-05-13 07:26:17 --> Security Class Initialized
DEBUG - 2022-05-13 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 07:26:17 --> Input Class Initialized
INFO - 2022-05-13 07:26:17 --> Language Class Initialized
INFO - 2022-05-13 07:26:17 --> Language Class Initialized
INFO - 2022-05-13 07:26:17 --> Config Class Initialized
INFO - 2022-05-13 07:26:17 --> Loader Class Initialized
INFO - 2022-05-13 07:26:17 --> Helper loaded: url_helper
INFO - 2022-05-13 07:26:17 --> Database Driver Class Initialized
INFO - 2022-05-13 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 07:26:17 --> Controller Class Initialized
DEBUG - 2022-05-13 07:26:17 --> Admin MX_Controller Initialized
INFO - 2022-05-13 07:26:17 --> Model Class Initialized
DEBUG - 2022-05-13 07:26:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 07:26:17 --> Model Class Initialized
DEBUG - 2022-05-13 07:26:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 07:26:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 07:26:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 07:26:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 07:26:17 --> Final output sent to browser
DEBUG - 2022-05-13 07:26:17 --> Total execution time: 0.0391
INFO - 2022-05-13 07:27:20 --> Config Class Initialized
INFO - 2022-05-13 07:27:20 --> Hooks Class Initialized
DEBUG - 2022-05-13 07:27:20 --> UTF-8 Support Enabled
INFO - 2022-05-13 07:27:20 --> Utf8 Class Initialized
INFO - 2022-05-13 07:27:20 --> URI Class Initialized
INFO - 2022-05-13 07:27:20 --> Router Class Initialized
INFO - 2022-05-13 07:27:20 --> Output Class Initialized
INFO - 2022-05-13 07:27:20 --> Security Class Initialized
DEBUG - 2022-05-13 07:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 07:27:20 --> Input Class Initialized
INFO - 2022-05-13 07:27:20 --> Language Class Initialized
INFO - 2022-05-13 07:27:20 --> Language Class Initialized
INFO - 2022-05-13 07:27:20 --> Config Class Initialized
INFO - 2022-05-13 07:27:20 --> Loader Class Initialized
INFO - 2022-05-13 07:27:20 --> Helper loaded: url_helper
INFO - 2022-05-13 07:27:20 --> Database Driver Class Initialized
INFO - 2022-05-13 07:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 07:27:20 --> Controller Class Initialized
DEBUG - 2022-05-13 07:27:20 --> Admin MX_Controller Initialized
INFO - 2022-05-13 07:27:20 --> Model Class Initialized
DEBUG - 2022-05-13 07:27:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 07:27:20 --> Model Class Initialized
DEBUG - 2022-05-13 07:27:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 07:27:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 07:27:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 07:27:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 07:27:20 --> Final output sent to browser
DEBUG - 2022-05-13 07:27:20 --> Total execution time: 0.0557
INFO - 2022-05-13 14:07:19 --> Config Class Initialized
INFO - 2022-05-13 14:07:19 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:07:19 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:07:19 --> Utf8 Class Initialized
INFO - 2022-05-13 14:07:19 --> URI Class Initialized
DEBUG - 2022-05-13 14:07:19 --> No URI present. Default controller set.
INFO - 2022-05-13 14:07:19 --> Router Class Initialized
INFO - 2022-05-13 14:07:19 --> Output Class Initialized
INFO - 2022-05-13 14:07:19 --> Security Class Initialized
DEBUG - 2022-05-13 14:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:07:20 --> Input Class Initialized
INFO - 2022-05-13 14:07:20 --> Language Class Initialized
INFO - 2022-05-13 14:07:20 --> Language Class Initialized
INFO - 2022-05-13 14:07:20 --> Config Class Initialized
INFO - 2022-05-13 14:07:20 --> Loader Class Initialized
INFO - 2022-05-13 14:07:20 --> Helper loaded: url_helper
INFO - 2022-05-13 14:07:20 --> Database Driver Class Initialized
INFO - 2022-05-13 14:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:07:20 --> Controller Class Initialized
DEBUG - 2022-05-13 14:07:20 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:07:20 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:07:20 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-13 14:07:20 --> Final output sent to browser
DEBUG - 2022-05-13 14:07:20 --> Total execution time: 0.4312
INFO - 2022-05-13 14:07:31 --> Config Class Initialized
INFO - 2022-05-13 14:07:31 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:07:31 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:07:31 --> Utf8 Class Initialized
INFO - 2022-05-13 14:07:31 --> URI Class Initialized
DEBUG - 2022-05-13 14:07:31 --> No URI present. Default controller set.
INFO - 2022-05-13 14:07:31 --> Router Class Initialized
INFO - 2022-05-13 14:07:31 --> Output Class Initialized
INFO - 2022-05-13 14:07:31 --> Security Class Initialized
DEBUG - 2022-05-13 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:07:31 --> Input Class Initialized
INFO - 2022-05-13 14:07:31 --> Language Class Initialized
INFO - 2022-05-13 14:07:31 --> Language Class Initialized
INFO - 2022-05-13 14:07:31 --> Config Class Initialized
INFO - 2022-05-13 14:07:31 --> Loader Class Initialized
INFO - 2022-05-13 14:07:31 --> Helper loaded: url_helper
INFO - 2022-05-13 14:07:31 --> Database Driver Class Initialized
INFO - 2022-05-13 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:07:31 --> Controller Class Initialized
DEBUG - 2022-05-13 14:07:31 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:07:31 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:07:31 --> Model Class Initialized
INFO - 2022-05-13 14:07:31 --> Config Class Initialized
INFO - 2022-05-13 14:07:31 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:07:31 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:07:31 --> Utf8 Class Initialized
INFO - 2022-05-13 14:07:31 --> URI Class Initialized
INFO - 2022-05-13 14:07:31 --> Router Class Initialized
INFO - 2022-05-13 14:07:31 --> Output Class Initialized
INFO - 2022-05-13 14:07:31 --> Security Class Initialized
DEBUG - 2022-05-13 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:07:31 --> Input Class Initialized
INFO - 2022-05-13 14:07:31 --> Language Class Initialized
INFO - 2022-05-13 14:07:31 --> Language Class Initialized
INFO - 2022-05-13 14:07:31 --> Config Class Initialized
INFO - 2022-05-13 14:07:31 --> Loader Class Initialized
INFO - 2022-05-13 14:07:31 --> Helper loaded: url_helper
INFO - 2022-05-13 14:07:31 --> Database Driver Class Initialized
INFO - 2022-05-13 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:07:31 --> Controller Class Initialized
DEBUG - 2022-05-13 14:07:31 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:07:31 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:07:31 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:07:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:07:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-13 14:07:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:07:32 --> Final output sent to browser
DEBUG - 2022-05-13 14:07:32 --> Total execution time: 0.0917
INFO - 2022-05-13 14:07:35 --> Config Class Initialized
INFO - 2022-05-13 14:07:35 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:07:35 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:07:35 --> Utf8 Class Initialized
INFO - 2022-05-13 14:07:35 --> URI Class Initialized
INFO - 2022-05-13 14:07:35 --> Router Class Initialized
INFO - 2022-05-13 14:07:35 --> Output Class Initialized
INFO - 2022-05-13 14:07:35 --> Security Class Initialized
DEBUG - 2022-05-13 14:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:07:35 --> Input Class Initialized
INFO - 2022-05-13 14:07:35 --> Language Class Initialized
INFO - 2022-05-13 14:07:35 --> Language Class Initialized
INFO - 2022-05-13 14:07:35 --> Config Class Initialized
INFO - 2022-05-13 14:07:35 --> Loader Class Initialized
INFO - 2022-05-13 14:07:35 --> Helper loaded: url_helper
INFO - 2022-05-13 14:07:35 --> Database Driver Class Initialized
INFO - 2022-05-13 14:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:07:35 --> Controller Class Initialized
DEBUG - 2022-05-13 14:07:35 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:07:35 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:07:35 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:07:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:07:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-13 14:07:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:07:35 --> Final output sent to browser
DEBUG - 2022-05-13 14:07:35 --> Total execution time: 0.0863
INFO - 2022-05-13 14:07:38 --> Config Class Initialized
INFO - 2022-05-13 14:07:38 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:07:38 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:07:38 --> Utf8 Class Initialized
INFO - 2022-05-13 14:07:38 --> URI Class Initialized
INFO - 2022-05-13 14:07:38 --> Router Class Initialized
INFO - 2022-05-13 14:07:38 --> Output Class Initialized
INFO - 2022-05-13 14:07:38 --> Security Class Initialized
DEBUG - 2022-05-13 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:07:38 --> Input Class Initialized
INFO - 2022-05-13 14:07:38 --> Language Class Initialized
INFO - 2022-05-13 14:07:38 --> Language Class Initialized
INFO - 2022-05-13 14:07:38 --> Config Class Initialized
INFO - 2022-05-13 14:07:38 --> Loader Class Initialized
INFO - 2022-05-13 14:07:38 --> Helper loaded: url_helper
INFO - 2022-05-13 14:07:38 --> Database Driver Class Initialized
INFO - 2022-05-13 14:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:07:38 --> Controller Class Initialized
DEBUG - 2022-05-13 14:07:38 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:07:38 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:07:38 --> Model Class Initialized
DEBUG - 2022-05-13 14:07:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:07:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:07:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:07:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:07:38 --> Final output sent to browser
DEBUG - 2022-05-13 14:07:38 --> Total execution time: 0.0452
INFO - 2022-05-13 14:10:23 --> Config Class Initialized
INFO - 2022-05-13 14:10:23 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:10:23 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:10:23 --> Utf8 Class Initialized
INFO - 2022-05-13 14:10:23 --> URI Class Initialized
DEBUG - 2022-05-13 14:10:23 --> No URI present. Default controller set.
INFO - 2022-05-13 14:10:23 --> Router Class Initialized
INFO - 2022-05-13 14:10:23 --> Output Class Initialized
INFO - 2022-05-13 14:10:23 --> Security Class Initialized
DEBUG - 2022-05-13 14:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:10:23 --> Input Class Initialized
INFO - 2022-05-13 14:10:23 --> Language Class Initialized
INFO - 2022-05-13 14:10:23 --> Language Class Initialized
INFO - 2022-05-13 14:10:23 --> Config Class Initialized
INFO - 2022-05-13 14:10:23 --> Loader Class Initialized
INFO - 2022-05-13 14:10:23 --> Helper loaded: url_helper
INFO - 2022-05-13 14:10:23 --> Database Driver Class Initialized
INFO - 2022-05-13 14:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:10:23 --> Controller Class Initialized
DEBUG - 2022-05-13 14:10:23 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:10:23 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:10:23 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-13 14:10:23 --> Final output sent to browser
DEBUG - 2022-05-13 14:10:23 --> Total execution time: 0.0486
INFO - 2022-05-13 14:10:29 --> Config Class Initialized
INFO - 2022-05-13 14:10:29 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:10:29 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:10:29 --> Utf8 Class Initialized
INFO - 2022-05-13 14:10:29 --> URI Class Initialized
DEBUG - 2022-05-13 14:10:29 --> No URI present. Default controller set.
INFO - 2022-05-13 14:10:29 --> Router Class Initialized
INFO - 2022-05-13 14:10:29 --> Output Class Initialized
INFO - 2022-05-13 14:10:29 --> Security Class Initialized
DEBUG - 2022-05-13 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:10:29 --> Input Class Initialized
INFO - 2022-05-13 14:10:29 --> Language Class Initialized
INFO - 2022-05-13 14:10:29 --> Language Class Initialized
INFO - 2022-05-13 14:10:29 --> Config Class Initialized
INFO - 2022-05-13 14:10:29 --> Loader Class Initialized
INFO - 2022-05-13 14:10:29 --> Helper loaded: url_helper
INFO - 2022-05-13 14:10:29 --> Database Driver Class Initialized
INFO - 2022-05-13 14:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:10:29 --> Controller Class Initialized
DEBUG - 2022-05-13 14:10:29 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:10:29 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:10:29 --> Model Class Initialized
INFO - 2022-05-13 14:10:29 --> Config Class Initialized
INFO - 2022-05-13 14:10:29 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:10:29 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:10:29 --> Utf8 Class Initialized
INFO - 2022-05-13 14:10:29 --> URI Class Initialized
INFO - 2022-05-13 14:10:29 --> Router Class Initialized
INFO - 2022-05-13 14:10:29 --> Output Class Initialized
INFO - 2022-05-13 14:10:29 --> Security Class Initialized
DEBUG - 2022-05-13 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:10:29 --> Input Class Initialized
INFO - 2022-05-13 14:10:29 --> Language Class Initialized
INFO - 2022-05-13 14:10:29 --> Language Class Initialized
INFO - 2022-05-13 14:10:29 --> Config Class Initialized
INFO - 2022-05-13 14:10:29 --> Loader Class Initialized
INFO - 2022-05-13 14:10:29 --> Helper loaded: url_helper
INFO - 2022-05-13 14:10:29 --> Database Driver Class Initialized
INFO - 2022-05-13 14:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:10:29 --> Controller Class Initialized
DEBUG - 2022-05-13 14:10:29 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:10:29 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:10:29 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:10:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:10:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-13 14:10:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:10:29 --> Final output sent to browser
DEBUG - 2022-05-13 14:10:29 --> Total execution time: 0.0283
INFO - 2022-05-13 14:10:35 --> Config Class Initialized
INFO - 2022-05-13 14:10:35 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:10:35 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:10:35 --> Utf8 Class Initialized
INFO - 2022-05-13 14:10:35 --> URI Class Initialized
INFO - 2022-05-13 14:10:35 --> Router Class Initialized
INFO - 2022-05-13 14:10:35 --> Output Class Initialized
INFO - 2022-05-13 14:10:35 --> Security Class Initialized
DEBUG - 2022-05-13 14:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:10:35 --> Input Class Initialized
INFO - 2022-05-13 14:10:35 --> Language Class Initialized
INFO - 2022-05-13 14:10:35 --> Language Class Initialized
INFO - 2022-05-13 14:10:35 --> Config Class Initialized
INFO - 2022-05-13 14:10:35 --> Loader Class Initialized
INFO - 2022-05-13 14:10:35 --> Helper loaded: url_helper
INFO - 2022-05-13 14:10:35 --> Database Driver Class Initialized
INFO - 2022-05-13 14:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:10:35 --> Controller Class Initialized
DEBUG - 2022-05-13 14:10:35 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:10:35 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:10:35 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:10:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:10:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:10:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:10:35 --> Final output sent to browser
DEBUG - 2022-05-13 14:10:35 --> Total execution time: 0.0425
INFO - 2022-05-13 14:10:58 --> Config Class Initialized
INFO - 2022-05-13 14:10:58 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:10:58 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:10:58 --> Utf8 Class Initialized
INFO - 2022-05-13 14:10:58 --> URI Class Initialized
INFO - 2022-05-13 14:10:58 --> Router Class Initialized
INFO - 2022-05-13 14:10:58 --> Output Class Initialized
INFO - 2022-05-13 14:10:58 --> Security Class Initialized
DEBUG - 2022-05-13 14:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:10:58 --> Input Class Initialized
INFO - 2022-05-13 14:10:58 --> Language Class Initialized
INFO - 2022-05-13 14:10:58 --> Language Class Initialized
INFO - 2022-05-13 14:10:58 --> Config Class Initialized
INFO - 2022-05-13 14:10:58 --> Loader Class Initialized
INFO - 2022-05-13 14:10:58 --> Helper loaded: url_helper
INFO - 2022-05-13 14:10:58 --> Database Driver Class Initialized
INFO - 2022-05-13 14:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:10:58 --> Controller Class Initialized
DEBUG - 2022-05-13 14:10:58 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:10:58 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:58 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:10:58 --> Model Class Initialized
DEBUG - 2022-05-13 14:10:58 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:10:58 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:10:58 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:10:58 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:10:58 --> Final output sent to browser
DEBUG - 2022-05-13 14:10:58 --> Total execution time: 0.0499
INFO - 2022-05-13 14:28:47 --> Config Class Initialized
INFO - 2022-05-13 14:28:47 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:28:47 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:28:47 --> Utf8 Class Initialized
INFO - 2022-05-13 14:28:47 --> URI Class Initialized
DEBUG - 2022-05-13 14:28:47 --> No URI present. Default controller set.
INFO - 2022-05-13 14:28:47 --> Router Class Initialized
INFO - 2022-05-13 14:28:47 --> Output Class Initialized
INFO - 2022-05-13 14:28:47 --> Security Class Initialized
DEBUG - 2022-05-13 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:28:47 --> Input Class Initialized
INFO - 2022-05-13 14:28:47 --> Language Class Initialized
INFO - 2022-05-13 14:28:47 --> Language Class Initialized
INFO - 2022-05-13 14:28:47 --> Config Class Initialized
INFO - 2022-05-13 14:28:47 --> Loader Class Initialized
INFO - 2022-05-13 14:28:47 --> Helper loaded: url_helper
INFO - 2022-05-13 14:28:47 --> Database Driver Class Initialized
INFO - 2022-05-13 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:28:47 --> Controller Class Initialized
DEBUG - 2022-05-13 14:28:47 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:28:47 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:28:47 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-13 14:28:47 --> Final output sent to browser
DEBUG - 2022-05-13 14:28:47 --> Total execution time: 0.0298
INFO - 2022-05-13 14:28:47 --> Config Class Initialized
INFO - 2022-05-13 14:28:47 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:28:47 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:28:47 --> Utf8 Class Initialized
INFO - 2022-05-13 14:28:47 --> URI Class Initialized
DEBUG - 2022-05-13 14:28:47 --> No URI present. Default controller set.
INFO - 2022-05-13 14:28:47 --> Router Class Initialized
INFO - 2022-05-13 14:28:47 --> Output Class Initialized
INFO - 2022-05-13 14:28:47 --> Security Class Initialized
DEBUG - 2022-05-13 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:28:47 --> Input Class Initialized
INFO - 2022-05-13 14:28:47 --> Language Class Initialized
INFO - 2022-05-13 14:28:47 --> Language Class Initialized
INFO - 2022-05-13 14:28:47 --> Config Class Initialized
INFO - 2022-05-13 14:28:47 --> Loader Class Initialized
INFO - 2022-05-13 14:28:47 --> Helper loaded: url_helper
INFO - 2022-05-13 14:28:47 --> Database Driver Class Initialized
INFO - 2022-05-13 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:28:47 --> Controller Class Initialized
DEBUG - 2022-05-13 14:28:47 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:28:47 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:28:47 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-13 14:28:47 --> Final output sent to browser
DEBUG - 2022-05-13 14:28:47 --> Total execution time: 0.0288
INFO - 2022-05-13 14:28:54 --> Config Class Initialized
INFO - 2022-05-13 14:28:54 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:28:54 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:28:54 --> Utf8 Class Initialized
INFO - 2022-05-13 14:28:54 --> URI Class Initialized
INFO - 2022-05-13 14:28:54 --> Router Class Initialized
INFO - 2022-05-13 14:28:54 --> Output Class Initialized
INFO - 2022-05-13 14:28:54 --> Security Class Initialized
DEBUG - 2022-05-13 14:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:28:54 --> Input Class Initialized
INFO - 2022-05-13 14:28:54 --> Language Class Initialized
INFO - 2022-05-13 14:28:54 --> Language Class Initialized
INFO - 2022-05-13 14:28:54 --> Config Class Initialized
INFO - 2022-05-13 14:28:54 --> Loader Class Initialized
INFO - 2022-05-13 14:28:54 --> Helper loaded: url_helper
INFO - 2022-05-13 14:28:54 --> Database Driver Class Initialized
INFO - 2022-05-13 14:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:28:54 --> Controller Class Initialized
DEBUG - 2022-05-13 14:28:54 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:28:54 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:28:54 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:28:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:28:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-13 14:28:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:28:54 --> Final output sent to browser
DEBUG - 2022-05-13 14:28:54 --> Total execution time: 0.0278
INFO - 2022-05-13 14:28:56 --> Config Class Initialized
INFO - 2022-05-13 14:28:56 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:28:56 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:28:56 --> Utf8 Class Initialized
INFO - 2022-05-13 14:28:56 --> URI Class Initialized
INFO - 2022-05-13 14:28:56 --> Router Class Initialized
INFO - 2022-05-13 14:28:56 --> Output Class Initialized
INFO - 2022-05-13 14:28:56 --> Security Class Initialized
DEBUG - 2022-05-13 14:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:28:56 --> Input Class Initialized
INFO - 2022-05-13 14:28:56 --> Language Class Initialized
INFO - 2022-05-13 14:28:56 --> Language Class Initialized
INFO - 2022-05-13 14:28:56 --> Config Class Initialized
INFO - 2022-05-13 14:28:56 --> Loader Class Initialized
INFO - 2022-05-13 14:28:56 --> Helper loaded: url_helper
INFO - 2022-05-13 14:28:56 --> Database Driver Class Initialized
INFO - 2022-05-13 14:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:28:56 --> Controller Class Initialized
DEBUG - 2022-05-13 14:28:56 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:28:56 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:28:56 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:28:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:28:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:28:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:28:56 --> Final output sent to browser
DEBUG - 2022-05-13 14:28:56 --> Total execution time: 0.0390
INFO - 2022-05-13 14:28:59 --> Config Class Initialized
INFO - 2022-05-13 14:28:59 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:28:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:28:59 --> Utf8 Class Initialized
INFO - 2022-05-13 14:28:59 --> URI Class Initialized
INFO - 2022-05-13 14:28:59 --> Router Class Initialized
INFO - 2022-05-13 14:28:59 --> Output Class Initialized
INFO - 2022-05-13 14:28:59 --> Security Class Initialized
DEBUG - 2022-05-13 14:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:28:59 --> Input Class Initialized
INFO - 2022-05-13 14:28:59 --> Language Class Initialized
INFO - 2022-05-13 14:28:59 --> Language Class Initialized
INFO - 2022-05-13 14:28:59 --> Config Class Initialized
INFO - 2022-05-13 14:28:59 --> Loader Class Initialized
INFO - 2022-05-13 14:28:59 --> Helper loaded: url_helper
INFO - 2022-05-13 14:28:59 --> Database Driver Class Initialized
INFO - 2022-05-13 14:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:28:59 --> Controller Class Initialized
DEBUG - 2022-05-13 14:28:59 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:28:59 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:28:59 --> Model Class Initialized
DEBUG - 2022-05-13 14:28:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:28:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:28:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:28:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:28:59 --> Final output sent to browser
DEBUG - 2022-05-13 14:28:59 --> Total execution time: 0.0544
INFO - 2022-05-13 14:29:00 --> Config Class Initialized
INFO - 2022-05-13 14:29:00 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:29:00 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:29:00 --> Utf8 Class Initialized
INFO - 2022-05-13 14:29:00 --> URI Class Initialized
INFO - 2022-05-13 14:29:00 --> Router Class Initialized
INFO - 2022-05-13 14:29:00 --> Output Class Initialized
INFO - 2022-05-13 14:29:00 --> Security Class Initialized
DEBUG - 2022-05-13 14:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:29:00 --> Input Class Initialized
INFO - 2022-05-13 14:29:00 --> Language Class Initialized
INFO - 2022-05-13 14:29:00 --> Language Class Initialized
INFO - 2022-05-13 14:29:00 --> Config Class Initialized
INFO - 2022-05-13 14:29:00 --> Loader Class Initialized
INFO - 2022-05-13 14:29:00 --> Helper loaded: url_helper
INFO - 2022-05-13 14:29:00 --> Database Driver Class Initialized
INFO - 2022-05-13 14:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:29:01 --> Controller Class Initialized
DEBUG - 2022-05-13 14:29:01 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:29:01 --> Model Class Initialized
DEBUG - 2022-05-13 14:29:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:29:01 --> Model Class Initialized
DEBUG - 2022-05-13 14:29:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:29:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:29:01 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\edit_category.php 83
DEBUG - 2022-05-13 14:29:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:29:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:29:01 --> Final output sent to browser
DEBUG - 2022-05-13 14:29:01 --> Total execution time: 0.0939
INFO - 2022-05-13 14:30:14 --> Config Class Initialized
INFO - 2022-05-13 14:30:14 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:30:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:30:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:30:14 --> URI Class Initialized
INFO - 2022-05-13 14:30:14 --> Router Class Initialized
INFO - 2022-05-13 14:30:14 --> Output Class Initialized
INFO - 2022-05-13 14:30:14 --> Security Class Initialized
DEBUG - 2022-05-13 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:30:14 --> Input Class Initialized
INFO - 2022-05-13 14:30:14 --> Language Class Initialized
INFO - 2022-05-13 14:30:14 --> Language Class Initialized
INFO - 2022-05-13 14:30:14 --> Config Class Initialized
INFO - 2022-05-13 14:30:14 --> Loader Class Initialized
INFO - 2022-05-13 14:30:14 --> Helper loaded: url_helper
INFO - 2022-05-13 14:30:15 --> Database Driver Class Initialized
INFO - 2022-05-13 14:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:30:15 --> Controller Class Initialized
DEBUG - 2022-05-13 14:30:15 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:30:15 --> Model Class Initialized
DEBUG - 2022-05-13 14:30:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:30:15 --> Model Class Initialized
DEBUG - 2022-05-13 14:30:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:30:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:30:15 --> Severity: Notice --> Undefined index: c_name C:\xampp\htdocs\motodeal\application\modules\admin\views\edit_category.php 41
DEBUG - 2022-05-13 14:30:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:30:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:30:15 --> Final output sent to browser
DEBUG - 2022-05-13 14:30:15 --> Total execution time: 0.0455
INFO - 2022-05-13 14:31:14 --> Config Class Initialized
INFO - 2022-05-13 14:31:14 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:31:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:31:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:31:14 --> URI Class Initialized
INFO - 2022-05-13 14:31:14 --> Router Class Initialized
INFO - 2022-05-13 14:31:14 --> Output Class Initialized
INFO - 2022-05-13 14:31:14 --> Security Class Initialized
DEBUG - 2022-05-13 14:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:31:14 --> Input Class Initialized
INFO - 2022-05-13 14:31:14 --> Language Class Initialized
INFO - 2022-05-13 14:31:14 --> Language Class Initialized
INFO - 2022-05-13 14:31:14 --> Config Class Initialized
INFO - 2022-05-13 14:31:14 --> Loader Class Initialized
INFO - 2022-05-13 14:31:14 --> Helper loaded: url_helper
INFO - 2022-05-13 14:31:14 --> Database Driver Class Initialized
INFO - 2022-05-13 14:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:31:14 --> Controller Class Initialized
DEBUG - 2022-05-13 14:31:14 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:31:14 --> Model Class Initialized
DEBUG - 2022-05-13 14:31:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:31:14 --> Model Class Initialized
DEBUG - 2022-05-13 14:31:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:31:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:31:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:31:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:31:14 --> Final output sent to browser
DEBUG - 2022-05-13 14:31:14 --> Total execution time: 0.0530
INFO - 2022-05-13 14:32:11 --> Config Class Initialized
INFO - 2022-05-13 14:32:11 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:32:11 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:32:11 --> Utf8 Class Initialized
INFO - 2022-05-13 14:32:11 --> URI Class Initialized
INFO - 2022-05-13 14:32:11 --> Router Class Initialized
INFO - 2022-05-13 14:32:11 --> Output Class Initialized
INFO - 2022-05-13 14:32:11 --> Security Class Initialized
DEBUG - 2022-05-13 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:32:11 --> Input Class Initialized
INFO - 2022-05-13 14:32:11 --> Language Class Initialized
INFO - 2022-05-13 14:32:11 --> Language Class Initialized
INFO - 2022-05-13 14:32:11 --> Config Class Initialized
INFO - 2022-05-13 14:32:11 --> Loader Class Initialized
INFO - 2022-05-13 14:32:11 --> Helper loaded: url_helper
INFO - 2022-05-13 14:32:11 --> Database Driver Class Initialized
INFO - 2022-05-13 14:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:32:11 --> Controller Class Initialized
DEBUG - 2022-05-13 14:32:11 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:32:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:32:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:32:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:32:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:32:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:32:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:32:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:32:11 --> Final output sent to browser
DEBUG - 2022-05-13 14:32:11 --> Total execution time: 0.0509
INFO - 2022-05-13 14:34:44 --> Config Class Initialized
INFO - 2022-05-13 14:34:44 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:34:44 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:34:44 --> Utf8 Class Initialized
INFO - 2022-05-13 14:34:44 --> URI Class Initialized
INFO - 2022-05-13 14:34:44 --> Router Class Initialized
INFO - 2022-05-13 14:34:44 --> Output Class Initialized
INFO - 2022-05-13 14:34:44 --> Security Class Initialized
DEBUG - 2022-05-13 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:34:44 --> Input Class Initialized
INFO - 2022-05-13 14:34:44 --> Language Class Initialized
INFO - 2022-05-13 14:34:44 --> Language Class Initialized
INFO - 2022-05-13 14:34:44 --> Config Class Initialized
INFO - 2022-05-13 14:34:44 --> Loader Class Initialized
INFO - 2022-05-13 14:34:44 --> Helper loaded: url_helper
INFO - 2022-05-13 14:34:44 --> Database Driver Class Initialized
INFO - 2022-05-13 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:34:44 --> Controller Class Initialized
DEBUG - 2022-05-13 14:34:44 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:34:44 --> Model Class Initialized
DEBUG - 2022-05-13 14:34:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:34:44 --> Model Class Initialized
DEBUG - 2022-05-13 14:34:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:34:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-13 14:39:25 --> Config Class Initialized
INFO - 2022-05-13 14:39:25 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:39:25 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:39:25 --> Utf8 Class Initialized
INFO - 2022-05-13 14:39:25 --> URI Class Initialized
INFO - 2022-05-13 14:39:25 --> Router Class Initialized
INFO - 2022-05-13 14:39:25 --> Output Class Initialized
INFO - 2022-05-13 14:39:25 --> Security Class Initialized
DEBUG - 2022-05-13 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:39:25 --> Input Class Initialized
INFO - 2022-05-13 14:39:25 --> Language Class Initialized
INFO - 2022-05-13 14:39:25 --> Language Class Initialized
INFO - 2022-05-13 14:39:25 --> Config Class Initialized
INFO - 2022-05-13 14:39:25 --> Loader Class Initialized
INFO - 2022-05-13 14:39:25 --> Helper loaded: url_helper
INFO - 2022-05-13 14:39:25 --> Database Driver Class Initialized
INFO - 2022-05-13 14:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:39:25 --> Controller Class Initialized
DEBUG - 2022-05-13 14:39:25 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:39:25 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:39:25 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:39:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:39:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:39:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:39:25 --> Final output sent to browser
DEBUG - 2022-05-13 14:39:25 --> Total execution time: 0.0501
INFO - 2022-05-13 14:39:26 --> Config Class Initialized
INFO - 2022-05-13 14:39:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:39:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:39:26 --> Utf8 Class Initialized
INFO - 2022-05-13 14:39:26 --> URI Class Initialized
INFO - 2022-05-13 14:39:26 --> Router Class Initialized
INFO - 2022-05-13 14:39:26 --> Output Class Initialized
INFO - 2022-05-13 14:39:26 --> Security Class Initialized
DEBUG - 2022-05-13 14:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:39:26 --> Input Class Initialized
INFO - 2022-05-13 14:39:26 --> Language Class Initialized
INFO - 2022-05-13 14:39:26 --> Language Class Initialized
INFO - 2022-05-13 14:39:26 --> Config Class Initialized
INFO - 2022-05-13 14:39:26 --> Loader Class Initialized
INFO - 2022-05-13 14:39:26 --> Helper loaded: url_helper
INFO - 2022-05-13 14:39:26 --> Database Driver Class Initialized
INFO - 2022-05-13 14:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:39:26 --> Controller Class Initialized
DEBUG - 2022-05-13 14:39:26 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:39:26 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:39:26 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:39:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:39:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:39:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:39:26 --> Final output sent to browser
DEBUG - 2022-05-13 14:39:26 --> Total execution time: 0.0452
INFO - 2022-05-13 14:39:28 --> Config Class Initialized
INFO - 2022-05-13 14:39:28 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:39:28 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:39:28 --> Utf8 Class Initialized
INFO - 2022-05-13 14:39:28 --> URI Class Initialized
INFO - 2022-05-13 14:39:28 --> Router Class Initialized
INFO - 2022-05-13 14:39:28 --> Output Class Initialized
INFO - 2022-05-13 14:39:28 --> Security Class Initialized
DEBUG - 2022-05-13 14:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:39:28 --> Input Class Initialized
INFO - 2022-05-13 14:39:28 --> Language Class Initialized
INFO - 2022-05-13 14:39:28 --> Language Class Initialized
INFO - 2022-05-13 14:39:28 --> Config Class Initialized
INFO - 2022-05-13 14:39:28 --> Loader Class Initialized
INFO - 2022-05-13 14:39:28 --> Helper loaded: url_helper
INFO - 2022-05-13 14:39:28 --> Database Driver Class Initialized
INFO - 2022-05-13 14:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:39:28 --> Controller Class Initialized
DEBUG - 2022-05-13 14:39:28 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:39:28 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:39:28 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:39:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:39:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:39:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:39:28 --> Final output sent to browser
DEBUG - 2022-05-13 14:39:28 --> Total execution time: 0.0501
INFO - 2022-05-13 14:39:31 --> Config Class Initialized
INFO - 2022-05-13 14:39:31 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:39:31 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:39:31 --> Utf8 Class Initialized
INFO - 2022-05-13 14:39:31 --> URI Class Initialized
INFO - 2022-05-13 14:39:31 --> Router Class Initialized
INFO - 2022-05-13 14:39:31 --> Output Class Initialized
INFO - 2022-05-13 14:39:31 --> Security Class Initialized
DEBUG - 2022-05-13 14:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:39:31 --> Input Class Initialized
INFO - 2022-05-13 14:39:31 --> Language Class Initialized
INFO - 2022-05-13 14:39:31 --> Language Class Initialized
INFO - 2022-05-13 14:39:31 --> Config Class Initialized
INFO - 2022-05-13 14:39:31 --> Loader Class Initialized
INFO - 2022-05-13 14:39:31 --> Helper loaded: url_helper
INFO - 2022-05-13 14:39:31 --> Database Driver Class Initialized
INFO - 2022-05-13 14:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:39:31 --> Controller Class Initialized
DEBUG - 2022-05-13 14:39:31 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:39:31 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:39:31 --> Model Class Initialized
INFO - 2022-05-13 14:39:31 --> Config Class Initialized
INFO - 2022-05-13 14:39:31 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:39:31 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:39:31 --> Utf8 Class Initialized
INFO - 2022-05-13 14:39:31 --> URI Class Initialized
INFO - 2022-05-13 14:39:31 --> Router Class Initialized
INFO - 2022-05-13 14:39:31 --> Output Class Initialized
INFO - 2022-05-13 14:39:31 --> Security Class Initialized
DEBUG - 2022-05-13 14:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:39:31 --> Input Class Initialized
INFO - 2022-05-13 14:39:31 --> Language Class Initialized
INFO - 2022-05-13 14:39:31 --> Language Class Initialized
INFO - 2022-05-13 14:39:31 --> Config Class Initialized
INFO - 2022-05-13 14:39:31 --> Loader Class Initialized
INFO - 2022-05-13 14:39:31 --> Helper loaded: url_helper
INFO - 2022-05-13 14:39:31 --> Database Driver Class Initialized
INFO - 2022-05-13 14:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:39:31 --> Controller Class Initialized
DEBUG - 2022-05-13 14:39:31 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:39:31 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:39:31 --> Model Class Initialized
DEBUG - 2022-05-13 14:39:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:39:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:39:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:39:31 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:39:31 --> Final output sent to browser
DEBUG - 2022-05-13 14:39:31 --> Total execution time: 0.0432
INFO - 2022-05-13 14:40:08 --> Config Class Initialized
INFO - 2022-05-13 14:40:08 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:08 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:08 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:08 --> URI Class Initialized
INFO - 2022-05-13 14:40:08 --> Router Class Initialized
INFO - 2022-05-13 14:40:08 --> Output Class Initialized
INFO - 2022-05-13 14:40:08 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:08 --> Input Class Initialized
INFO - 2022-05-13 14:40:08 --> Language Class Initialized
INFO - 2022-05-13 14:40:08 --> Language Class Initialized
INFO - 2022-05-13 14:40:08 --> Config Class Initialized
INFO - 2022-05-13 14:40:08 --> Loader Class Initialized
INFO - 2022-05-13 14:40:08 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:08 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:08 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:08 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:08 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:08 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:40:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:40:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:40:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:40:08 --> Final output sent to browser
DEBUG - 2022-05-13 14:40:08 --> Total execution time: 0.0313
INFO - 2022-05-13 14:40:09 --> Config Class Initialized
INFO - 2022-05-13 14:40:09 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:09 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:09 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:09 --> URI Class Initialized
INFO - 2022-05-13 14:40:09 --> Router Class Initialized
INFO - 2022-05-13 14:40:09 --> Output Class Initialized
INFO - 2022-05-13 14:40:09 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:09 --> Input Class Initialized
INFO - 2022-05-13 14:40:09 --> Language Class Initialized
INFO - 2022-05-13 14:40:09 --> Language Class Initialized
INFO - 2022-05-13 14:40:09 --> Config Class Initialized
INFO - 2022-05-13 14:40:09 --> Loader Class Initialized
INFO - 2022-05-13 14:40:09 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:09 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:09 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:09 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:09 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:09 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:09 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:09 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:40:09 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:40:09 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:40:09 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:40:09 --> Final output sent to browser
DEBUG - 2022-05-13 14:40:09 --> Total execution time: 0.0475
INFO - 2022-05-13 14:40:11 --> Config Class Initialized
INFO - 2022-05-13 14:40:11 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:11 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:11 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:11 --> URI Class Initialized
INFO - 2022-05-13 14:40:11 --> Router Class Initialized
INFO - 2022-05-13 14:40:11 --> Output Class Initialized
INFO - 2022-05-13 14:40:11 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:11 --> Input Class Initialized
INFO - 2022-05-13 14:40:11 --> Language Class Initialized
INFO - 2022-05-13 14:40:11 --> Language Class Initialized
INFO - 2022-05-13 14:40:11 --> Config Class Initialized
INFO - 2022-05-13 14:40:11 --> Loader Class Initialized
INFO - 2022-05-13 14:40:11 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:11 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:11 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:11 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:11 --> Model Class Initialized
INFO - 2022-05-13 14:40:11 --> Config Class Initialized
INFO - 2022-05-13 14:40:11 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:11 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:11 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:11 --> URI Class Initialized
INFO - 2022-05-13 14:40:11 --> Router Class Initialized
INFO - 2022-05-13 14:40:11 --> Output Class Initialized
INFO - 2022-05-13 14:40:11 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:11 --> Input Class Initialized
INFO - 2022-05-13 14:40:11 --> Language Class Initialized
INFO - 2022-05-13 14:40:11 --> Language Class Initialized
INFO - 2022-05-13 14:40:11 --> Config Class Initialized
INFO - 2022-05-13 14:40:11 --> Loader Class Initialized
INFO - 2022-05-13 14:40:11 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:11 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:11 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:11 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:40:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:40:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:40:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:40:11 --> Final output sent to browser
DEBUG - 2022-05-13 14:40:11 --> Total execution time: 0.0376
INFO - 2022-05-13 14:40:13 --> Config Class Initialized
INFO - 2022-05-13 14:40:13 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:13 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:13 --> URI Class Initialized
INFO - 2022-05-13 14:40:13 --> Router Class Initialized
INFO - 2022-05-13 14:40:13 --> Output Class Initialized
INFO - 2022-05-13 14:40:13 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:13 --> Input Class Initialized
INFO - 2022-05-13 14:40:13 --> Language Class Initialized
INFO - 2022-05-13 14:40:13 --> Language Class Initialized
INFO - 2022-05-13 14:40:13 --> Config Class Initialized
INFO - 2022-05-13 14:40:13 --> Loader Class Initialized
INFO - 2022-05-13 14:40:13 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:13 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:13 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:13 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:13 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:13 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:40:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:40:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_category.php
DEBUG - 2022-05-13 14:40:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:40:13 --> Final output sent to browser
DEBUG - 2022-05-13 14:40:13 --> Total execution time: 0.0546
INFO - 2022-05-13 14:40:15 --> Config Class Initialized
INFO - 2022-05-13 14:40:15 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:15 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:15 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:15 --> URI Class Initialized
INFO - 2022-05-13 14:40:15 --> Router Class Initialized
INFO - 2022-05-13 14:40:15 --> Output Class Initialized
INFO - 2022-05-13 14:40:15 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:15 --> Input Class Initialized
INFO - 2022-05-13 14:40:15 --> Language Class Initialized
INFO - 2022-05-13 14:40:15 --> Language Class Initialized
INFO - 2022-05-13 14:40:15 --> Config Class Initialized
INFO - 2022-05-13 14:40:15 --> Loader Class Initialized
INFO - 2022-05-13 14:40:15 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:15 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:15 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:15 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:15 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:15 --> Model Class Initialized
INFO - 2022-05-13 14:40:15 --> Config Class Initialized
INFO - 2022-05-13 14:40:15 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:15 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:15 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:15 --> URI Class Initialized
INFO - 2022-05-13 14:40:15 --> Router Class Initialized
INFO - 2022-05-13 14:40:15 --> Output Class Initialized
INFO - 2022-05-13 14:40:15 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:15 --> Input Class Initialized
INFO - 2022-05-13 14:40:15 --> Language Class Initialized
INFO - 2022-05-13 14:40:15 --> Language Class Initialized
INFO - 2022-05-13 14:40:15 --> Config Class Initialized
INFO - 2022-05-13 14:40:15 --> Loader Class Initialized
INFO - 2022-05-13 14:40:15 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:15 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:15 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:15 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:15 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:15 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:40:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:40:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:40:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:40:15 --> Final output sent to browser
DEBUG - 2022-05-13 14:40:15 --> Total execution time: 0.0314
INFO - 2022-05-13 14:40:17 --> Config Class Initialized
INFO - 2022-05-13 14:40:17 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:40:17 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:40:17 --> Utf8 Class Initialized
INFO - 2022-05-13 14:40:17 --> URI Class Initialized
INFO - 2022-05-13 14:40:17 --> Router Class Initialized
INFO - 2022-05-13 14:40:17 --> Output Class Initialized
INFO - 2022-05-13 14:40:17 --> Security Class Initialized
DEBUG - 2022-05-13 14:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:40:17 --> Input Class Initialized
INFO - 2022-05-13 14:40:17 --> Language Class Initialized
INFO - 2022-05-13 14:40:17 --> Language Class Initialized
INFO - 2022-05-13 14:40:17 --> Config Class Initialized
INFO - 2022-05-13 14:40:17 --> Loader Class Initialized
INFO - 2022-05-13 14:40:17 --> Helper loaded: url_helper
INFO - 2022-05-13 14:40:17 --> Database Driver Class Initialized
INFO - 2022-05-13 14:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:40:17 --> Controller Class Initialized
DEBUG - 2022-05-13 14:40:17 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:40:17 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:40:17 --> Model Class Initialized
DEBUG - 2022-05-13 14:40:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:40:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:40:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:40:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:40:17 --> Final output sent to browser
DEBUG - 2022-05-13 14:40:17 --> Total execution time: 0.0501
INFO - 2022-05-13 14:41:11 --> Config Class Initialized
INFO - 2022-05-13 14:41:11 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:41:11 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:41:11 --> Utf8 Class Initialized
INFO - 2022-05-13 14:41:11 --> URI Class Initialized
INFO - 2022-05-13 14:41:11 --> Router Class Initialized
INFO - 2022-05-13 14:41:11 --> Output Class Initialized
INFO - 2022-05-13 14:41:11 --> Security Class Initialized
DEBUG - 2022-05-13 14:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:41:11 --> Input Class Initialized
INFO - 2022-05-13 14:41:11 --> Language Class Initialized
INFO - 2022-05-13 14:41:11 --> Language Class Initialized
INFO - 2022-05-13 14:41:11 --> Config Class Initialized
INFO - 2022-05-13 14:41:11 --> Loader Class Initialized
INFO - 2022-05-13 14:41:11 --> Helper loaded: url_helper
INFO - 2022-05-13 14:41:11 --> Database Driver Class Initialized
INFO - 2022-05-13 14:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:41:11 --> Controller Class Initialized
DEBUG - 2022-05-13 14:41:11 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:41:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:41:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:41:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:41:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:41:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:41:11 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
DEBUG - 2022-05-13 14:41:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:41:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:41:11 --> Final output sent to browser
DEBUG - 2022-05-13 14:41:11 --> Total execution time: 0.0531
INFO - 2022-05-13 14:41:45 --> Config Class Initialized
INFO - 2022-05-13 14:41:45 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:41:45 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:41:45 --> Utf8 Class Initialized
INFO - 2022-05-13 14:41:45 --> URI Class Initialized
INFO - 2022-05-13 14:41:45 --> Router Class Initialized
INFO - 2022-05-13 14:41:45 --> Output Class Initialized
INFO - 2022-05-13 14:41:45 --> Security Class Initialized
DEBUG - 2022-05-13 14:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:41:45 --> Input Class Initialized
INFO - 2022-05-13 14:41:45 --> Language Class Initialized
INFO - 2022-05-13 14:41:45 --> Language Class Initialized
INFO - 2022-05-13 14:41:45 --> Config Class Initialized
INFO - 2022-05-13 14:41:45 --> Loader Class Initialized
INFO - 2022-05-13 14:41:45 --> Helper loaded: url_helper
INFO - 2022-05-13 14:41:45 --> Database Driver Class Initialized
INFO - 2022-05-13 14:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:41:45 --> Controller Class Initialized
DEBUG - 2022-05-13 14:41:45 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:41:45 --> Model Class Initialized
DEBUG - 2022-05-13 14:41:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:41:45 --> Model Class Initialized
DEBUG - 2022-05-13 14:41:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:41:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:41:45 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
DEBUG - 2022-05-13 14:41:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:41:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:41:45 --> Final output sent to browser
DEBUG - 2022-05-13 14:41:45 --> Total execution time: 0.0406
INFO - 2022-05-13 14:42:02 --> Config Class Initialized
INFO - 2022-05-13 14:42:02 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:02 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:02 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:02 --> URI Class Initialized
INFO - 2022-05-13 14:42:02 --> Router Class Initialized
INFO - 2022-05-13 14:42:02 --> Output Class Initialized
INFO - 2022-05-13 14:42:02 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:02 --> Input Class Initialized
INFO - 2022-05-13 14:42:02 --> Language Class Initialized
INFO - 2022-05-13 14:42:02 --> Language Class Initialized
INFO - 2022-05-13 14:42:02 --> Config Class Initialized
INFO - 2022-05-13 14:42:02 --> Loader Class Initialized
INFO - 2022-05-13 14:42:02 --> Helper loaded: url_helper
INFO - 2022-05-13 14:42:02 --> Database Driver Class Initialized
INFO - 2022-05-13 14:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:42:02 --> Controller Class Initialized
DEBUG - 2022-05-13 14:42:02 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:42:02 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:42:02 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:42:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:42:02 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
DEBUG - 2022-05-13 14:42:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:42:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:42:02 --> Final output sent to browser
DEBUG - 2022-05-13 14:42:02 --> Total execution time: 0.0427
INFO - 2022-05-13 14:42:07 --> Config Class Initialized
INFO - 2022-05-13 14:42:07 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:07 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:07 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:07 --> URI Class Initialized
INFO - 2022-05-13 14:42:07 --> Router Class Initialized
INFO - 2022-05-13 14:42:07 --> Output Class Initialized
INFO - 2022-05-13 14:42:07 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:07 --> Input Class Initialized
INFO - 2022-05-13 14:42:07 --> Language Class Initialized
INFO - 2022-05-13 14:42:07 --> Language Class Initialized
INFO - 2022-05-13 14:42:07 --> Config Class Initialized
INFO - 2022-05-13 14:42:07 --> Loader Class Initialized
INFO - 2022-05-13 14:42:07 --> Helper loaded: url_helper
INFO - 2022-05-13 14:42:07 --> Database Driver Class Initialized
INFO - 2022-05-13 14:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:42:07 --> Controller Class Initialized
DEBUG - 2022-05-13 14:42:07 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:42:07 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:42:07 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:42:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:42:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:42:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:42:07 --> Final output sent to browser
DEBUG - 2022-05-13 14:42:07 --> Total execution time: 0.0509
INFO - 2022-05-13 14:42:11 --> Config Class Initialized
INFO - 2022-05-13 14:42:11 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:11 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:11 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:11 --> URI Class Initialized
INFO - 2022-05-13 14:42:11 --> Router Class Initialized
INFO - 2022-05-13 14:42:11 --> Output Class Initialized
INFO - 2022-05-13 14:42:11 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:11 --> Input Class Initialized
INFO - 2022-05-13 14:42:11 --> Language Class Initialized
INFO - 2022-05-13 14:42:11 --> Language Class Initialized
INFO - 2022-05-13 14:42:11 --> Config Class Initialized
INFO - 2022-05-13 14:42:11 --> Loader Class Initialized
INFO - 2022-05-13 14:42:11 --> Helper loaded: url_helper
INFO - 2022-05-13 14:42:11 --> Database Driver Class Initialized
INFO - 2022-05-13 14:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:42:11 --> Controller Class Initialized
DEBUG - 2022-05-13 14:42:11 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:42:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:42:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:42:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:42:11 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
DEBUG - 2022-05-13 14:42:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:42:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:42:11 --> Final output sent to browser
DEBUG - 2022-05-13 14:42:11 --> Total execution time: 0.0559
INFO - 2022-05-13 14:42:18 --> Config Class Initialized
INFO - 2022-05-13 14:42:18 --> Hooks Class Initialized
INFO - 2022-05-13 14:42:18 --> Config Class Initialized
INFO - 2022-05-13 14:42:18 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:18 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:18 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:18 --> URI Class Initialized
INFO - 2022-05-13 14:42:18 --> Router Class Initialized
INFO - 2022-05-13 14:42:18 --> Output Class Initialized
INFO - 2022-05-13 14:42:18 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:18 --> Input Class Initialized
INFO - 2022-05-13 14:42:18 --> Language Class Initialized
ERROR - 2022-05-13 14:42:18 --> 404 Page Not Found: /index
DEBUG - 2022-05-13 14:42:18 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:18 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:18 --> URI Class Initialized
INFO - 2022-05-13 14:42:18 --> Router Class Initialized
INFO - 2022-05-13 14:42:18 --> Output Class Initialized
INFO - 2022-05-13 14:42:18 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:18 --> Input Class Initialized
INFO - 2022-05-13 14:42:18 --> Language Class Initialized
ERROR - 2022-05-13 14:42:18 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:42:18 --> Config Class Initialized
INFO - 2022-05-13 14:42:18 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:18 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:18 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:18 --> URI Class Initialized
INFO - 2022-05-13 14:42:18 --> Router Class Initialized
INFO - 2022-05-13 14:42:18 --> Output Class Initialized
INFO - 2022-05-13 14:42:18 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:18 --> Input Class Initialized
INFO - 2022-05-13 14:42:18 --> Language Class Initialized
ERROR - 2022-05-13 14:42:18 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:42:49 --> Config Class Initialized
INFO - 2022-05-13 14:42:49 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:49 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:49 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:49 --> URI Class Initialized
INFO - 2022-05-13 14:42:49 --> Router Class Initialized
INFO - 2022-05-13 14:42:49 --> Output Class Initialized
INFO - 2022-05-13 14:42:49 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:49 --> Input Class Initialized
INFO - 2022-05-13 14:42:49 --> Language Class Initialized
INFO - 2022-05-13 14:42:49 --> Language Class Initialized
INFO - 2022-05-13 14:42:49 --> Config Class Initialized
INFO - 2022-05-13 14:42:49 --> Loader Class Initialized
INFO - 2022-05-13 14:42:49 --> Helper loaded: url_helper
INFO - 2022-05-13 14:42:49 --> Database Driver Class Initialized
INFO - 2022-05-13 14:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:42:49 --> Controller Class Initialized
DEBUG - 2022-05-13 14:42:49 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:42:49 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:42:49 --> Model Class Initialized
DEBUG - 2022-05-13 14:42:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:42:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:42:49 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
DEBUG - 2022-05-13 14:42:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:42:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:42:49 --> Final output sent to browser
DEBUG - 2022-05-13 14:42:49 --> Total execution time: 0.0345
INFO - 2022-05-13 14:42:49 --> Config Class Initialized
INFO - 2022-05-13 14:42:49 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:49 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:49 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:49 --> URI Class Initialized
INFO - 2022-05-13 14:42:49 --> Router Class Initialized
INFO - 2022-05-13 14:42:49 --> Output Class Initialized
INFO - 2022-05-13 14:42:49 --> Security Class Initialized
DEBUG - 2022-05-13 14:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:49 --> Input Class Initialized
INFO - 2022-05-13 14:42:49 --> Language Class Initialized
ERROR - 2022-05-13 14:42:49 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:42:50 --> Config Class Initialized
INFO - 2022-05-13 14:42:50 --> Hooks Class Initialized
INFO - 2022-05-13 14:42:50 --> Config Class Initialized
INFO - 2022-05-13 14:42:50 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:42:50 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:50 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:50 --> URI Class Initialized
DEBUG - 2022-05-13 14:42:50 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:42:50 --> Utf8 Class Initialized
INFO - 2022-05-13 14:42:50 --> URI Class Initialized
INFO - 2022-05-13 14:42:50 --> Router Class Initialized
INFO - 2022-05-13 14:42:50 --> Router Class Initialized
INFO - 2022-05-13 14:42:50 --> Output Class Initialized
INFO - 2022-05-13 14:42:50 --> Security Class Initialized
INFO - 2022-05-13 14:42:50 --> Output Class Initialized
DEBUG - 2022-05-13 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:50 --> Security Class Initialized
INFO - 2022-05-13 14:42:50 --> Input Class Initialized
INFO - 2022-05-13 14:42:50 --> Language Class Initialized
DEBUG - 2022-05-13 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:42:50 --> Input Class Initialized
INFO - 2022-05-13 14:42:50 --> Language Class Initialized
ERROR - 2022-05-13 14:42:50 --> 404 Page Not Found: /index
ERROR - 2022-05-13 14:42:50 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:43:16 --> Config Class Initialized
INFO - 2022-05-13 14:43:16 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:43:16 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:43:16 --> Utf8 Class Initialized
INFO - 2022-05-13 14:43:16 --> URI Class Initialized
INFO - 2022-05-13 14:43:16 --> Router Class Initialized
INFO - 2022-05-13 14:43:16 --> Output Class Initialized
INFO - 2022-05-13 14:43:16 --> Security Class Initialized
DEBUG - 2022-05-13 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:43:16 --> Input Class Initialized
INFO - 2022-05-13 14:43:16 --> Language Class Initialized
INFO - 2022-05-13 14:43:16 --> Language Class Initialized
INFO - 2022-05-13 14:43:16 --> Config Class Initialized
INFO - 2022-05-13 14:43:16 --> Loader Class Initialized
INFO - 2022-05-13 14:43:16 --> Helper loaded: url_helper
INFO - 2022-05-13 14:43:16 --> Database Driver Class Initialized
INFO - 2022-05-13 14:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:43:16 --> Controller Class Initialized
DEBUG - 2022-05-13 14:43:16 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:43:16 --> Model Class Initialized
DEBUG - 2022-05-13 14:43:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:43:16 --> Model Class Initialized
DEBUG - 2022-05-13 14:43:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:43:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:43:16 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
DEBUG - 2022-05-13 14:43:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:43:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:43:16 --> Final output sent to browser
DEBUG - 2022-05-13 14:43:16 --> Total execution time: 0.0376
INFO - 2022-05-13 14:43:16 --> Config Class Initialized
INFO - 2022-05-13 14:43:16 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:43:16 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:43:16 --> Utf8 Class Initialized
INFO - 2022-05-13 14:43:16 --> URI Class Initialized
INFO - 2022-05-13 14:43:16 --> Router Class Initialized
INFO - 2022-05-13 14:43:16 --> Output Class Initialized
INFO - 2022-05-13 14:43:16 --> Security Class Initialized
DEBUG - 2022-05-13 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:43:16 --> Input Class Initialized
INFO - 2022-05-13 14:43:16 --> Language Class Initialized
ERROR - 2022-05-13 14:43:16 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:43:16 --> Config Class Initialized
INFO - 2022-05-13 14:43:16 --> Hooks Class Initialized
INFO - 2022-05-13 14:43:16 --> Config Class Initialized
DEBUG - 2022-05-13 14:43:16 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:43:16 --> Hooks Class Initialized
INFO - 2022-05-13 14:43:16 --> Utf8 Class Initialized
INFO - 2022-05-13 14:43:16 --> URI Class Initialized
DEBUG - 2022-05-13 14:43:16 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:43:16 --> Utf8 Class Initialized
INFO - 2022-05-13 14:43:16 --> URI Class Initialized
INFO - 2022-05-13 14:43:16 --> Router Class Initialized
INFO - 2022-05-13 14:43:16 --> Output Class Initialized
INFO - 2022-05-13 14:43:16 --> Router Class Initialized
INFO - 2022-05-13 14:43:16 --> Security Class Initialized
INFO - 2022-05-13 14:43:16 --> Output Class Initialized
DEBUG - 2022-05-13 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:43:16 --> Input Class Initialized
INFO - 2022-05-13 14:43:16 --> Security Class Initialized
INFO - 2022-05-13 14:43:16 --> Language Class Initialized
ERROR - 2022-05-13 14:43:16 --> 404 Page Not Found: /index
DEBUG - 2022-05-13 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:43:16 --> Input Class Initialized
INFO - 2022-05-13 14:43:16 --> Language Class Initialized
ERROR - 2022-05-13 14:43:16 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:43:45 --> Config Class Initialized
INFO - 2022-05-13 14:43:45 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:43:45 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:43:45 --> Utf8 Class Initialized
INFO - 2022-05-13 14:43:45 --> URI Class Initialized
INFO - 2022-05-13 14:43:45 --> Router Class Initialized
INFO - 2022-05-13 14:43:45 --> Output Class Initialized
INFO - 2022-05-13 14:43:45 --> Security Class Initialized
DEBUG - 2022-05-13 14:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:43:45 --> Input Class Initialized
INFO - 2022-05-13 14:43:45 --> Language Class Initialized
INFO - 2022-05-13 14:43:45 --> Language Class Initialized
INFO - 2022-05-13 14:43:45 --> Config Class Initialized
INFO - 2022-05-13 14:43:45 --> Loader Class Initialized
INFO - 2022-05-13 14:43:45 --> Helper loaded: url_helper
INFO - 2022-05-13 14:43:45 --> Database Driver Class Initialized
INFO - 2022-05-13 14:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:43:45 --> Controller Class Initialized
DEBUG - 2022-05-13 14:43:45 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:43:45 --> Model Class Initialized
DEBUG - 2022-05-13 14:43:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:43:45 --> Model Class Initialized
DEBUG - 2022-05-13 14:43:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:43:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:43:45 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:43:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:43:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:43:45 --> Final output sent to browser
DEBUG - 2022-05-13 14:43:45 --> Total execution time: 0.0320
INFO - 2022-05-13 14:43:52 --> Config Class Initialized
INFO - 2022-05-13 14:43:52 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:43:52 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:43:52 --> Utf8 Class Initialized
INFO - 2022-05-13 14:43:52 --> URI Class Initialized
INFO - 2022-05-13 14:43:52 --> Router Class Initialized
INFO - 2022-05-13 14:43:52 --> Output Class Initialized
INFO - 2022-05-13 14:43:52 --> Security Class Initialized
DEBUG - 2022-05-13 14:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:43:52 --> Input Class Initialized
INFO - 2022-05-13 14:43:52 --> Language Class Initialized
INFO - 2022-05-13 14:43:52 --> Language Class Initialized
INFO - 2022-05-13 14:43:52 --> Config Class Initialized
INFO - 2022-05-13 14:43:52 --> Loader Class Initialized
INFO - 2022-05-13 14:43:52 --> Helper loaded: url_helper
INFO - 2022-05-13 14:43:52 --> Database Driver Class Initialized
INFO - 2022-05-13 14:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:43:52 --> Controller Class Initialized
DEBUG - 2022-05-13 14:43:52 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:43:52 --> Model Class Initialized
DEBUG - 2022-05-13 14:43:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:43:52 --> Model Class Initialized
DEBUG - 2022-05-13 14:43:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:43:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:43:52 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:43:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:43:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:43:52 --> Final output sent to browser
DEBUG - 2022-05-13 14:43:52 --> Total execution time: 0.0460
INFO - 2022-05-13 14:44:00 --> Config Class Initialized
INFO - 2022-05-13 14:44:00 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:44:00 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:00 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:00 --> URI Class Initialized
INFO - 2022-05-13 14:44:00 --> Router Class Initialized
INFO - 2022-05-13 14:44:00 --> Output Class Initialized
INFO - 2022-05-13 14:44:00 --> Security Class Initialized
DEBUG - 2022-05-13 14:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:00 --> Input Class Initialized
INFO - 2022-05-13 14:44:00 --> Language Class Initialized
INFO - 2022-05-13 14:44:00 --> Language Class Initialized
INFO - 2022-05-13 14:44:00 --> Config Class Initialized
INFO - 2022-05-13 14:44:00 --> Loader Class Initialized
INFO - 2022-05-13 14:44:00 --> Helper loaded: url_helper
INFO - 2022-05-13 14:44:00 --> Database Driver Class Initialized
INFO - 2022-05-13 14:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:44:00 --> Controller Class Initialized
DEBUG - 2022-05-13 14:44:00 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:44:00 --> Model Class Initialized
DEBUG - 2022-05-13 14:44:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:44:00 --> Model Class Initialized
DEBUG - 2022-05-13 14:44:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:44:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:44:00 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:44:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:44:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:44:00 --> Final output sent to browser
DEBUG - 2022-05-13 14:44:00 --> Total execution time: 0.0553
INFO - 2022-05-13 14:44:05 --> Config Class Initialized
INFO - 2022-05-13 14:44:05 --> Hooks Class Initialized
INFO - 2022-05-13 14:44:05 --> Config Class Initialized
INFO - 2022-05-13 14:44:05 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:44:05 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:05 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:05 --> URI Class Initialized
DEBUG - 2022-05-13 14:44:05 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:05 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:05 --> URI Class Initialized
INFO - 2022-05-13 14:44:05 --> Router Class Initialized
INFO - 2022-05-13 14:44:05 --> Router Class Initialized
INFO - 2022-05-13 14:44:05 --> Output Class Initialized
INFO - 2022-05-13 14:44:05 --> Security Class Initialized
INFO - 2022-05-13 14:44:05 --> Output Class Initialized
DEBUG - 2022-05-13 14:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:05 --> Security Class Initialized
INFO - 2022-05-13 14:44:05 --> Input Class Initialized
INFO - 2022-05-13 14:44:05 --> Language Class Initialized
DEBUG - 2022-05-13 14:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:05 --> Input Class Initialized
ERROR - 2022-05-13 14:44:05 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:44:05 --> Language Class Initialized
ERROR - 2022-05-13 14:44:05 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:44:05 --> Config Class Initialized
INFO - 2022-05-13 14:44:05 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:44:05 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:05 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:05 --> URI Class Initialized
INFO - 2022-05-13 14:44:05 --> Router Class Initialized
INFO - 2022-05-13 14:44:05 --> Output Class Initialized
INFO - 2022-05-13 14:44:05 --> Security Class Initialized
DEBUG - 2022-05-13 14:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:05 --> Input Class Initialized
INFO - 2022-05-13 14:44:05 --> Language Class Initialized
ERROR - 2022-05-13 14:44:05 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:44:48 --> Config Class Initialized
INFO - 2022-05-13 14:44:48 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:44:48 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:48 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:48 --> URI Class Initialized
INFO - 2022-05-13 14:44:48 --> Router Class Initialized
INFO - 2022-05-13 14:44:48 --> Output Class Initialized
INFO - 2022-05-13 14:44:48 --> Security Class Initialized
DEBUG - 2022-05-13 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:48 --> Input Class Initialized
INFO - 2022-05-13 14:44:48 --> Language Class Initialized
INFO - 2022-05-13 14:44:48 --> Language Class Initialized
INFO - 2022-05-13 14:44:48 --> Config Class Initialized
INFO - 2022-05-13 14:44:48 --> Loader Class Initialized
INFO - 2022-05-13 14:44:48 --> Helper loaded: url_helper
INFO - 2022-05-13 14:44:48 --> Database Driver Class Initialized
INFO - 2022-05-13 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:44:48 --> Controller Class Initialized
DEBUG - 2022-05-13 14:44:48 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:44:48 --> Model Class Initialized
DEBUG - 2022-05-13 14:44:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:44:48 --> Model Class Initialized
DEBUG - 2022-05-13 14:44:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:44:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:44:48 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:44:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:44:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:44:48 --> Final output sent to browser
DEBUG - 2022-05-13 14:44:48 --> Total execution time: 0.0364
INFO - 2022-05-13 14:44:48 --> Config Class Initialized
INFO - 2022-05-13 14:44:48 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:44:48 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:48 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:48 --> URI Class Initialized
INFO - 2022-05-13 14:44:48 --> Router Class Initialized
INFO - 2022-05-13 14:44:48 --> Output Class Initialized
INFO - 2022-05-13 14:44:48 --> Security Class Initialized
DEBUG - 2022-05-13 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:48 --> Input Class Initialized
INFO - 2022-05-13 14:44:48 --> Language Class Initialized
ERROR - 2022-05-13 14:44:48 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:44:49 --> Config Class Initialized
INFO - 2022-05-13 14:44:49 --> Hooks Class Initialized
INFO - 2022-05-13 14:44:49 --> Config Class Initialized
INFO - 2022-05-13 14:44:49 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 14:44:49 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:44:49 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:49 --> URI Class Initialized
INFO - 2022-05-13 14:44:49 --> Utf8 Class Initialized
INFO - 2022-05-13 14:44:49 --> Router Class Initialized
INFO - 2022-05-13 14:44:49 --> URI Class Initialized
INFO - 2022-05-13 14:44:49 --> Output Class Initialized
INFO - 2022-05-13 14:44:49 --> Security Class Initialized
INFO - 2022-05-13 14:44:49 --> Router Class Initialized
DEBUG - 2022-05-13 14:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:49 --> Input Class Initialized
INFO - 2022-05-13 14:44:49 --> Language Class Initialized
INFO - 2022-05-13 14:44:49 --> Output Class Initialized
ERROR - 2022-05-13 14:44:49 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:44:49 --> Security Class Initialized
DEBUG - 2022-05-13 14:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:44:49 --> Input Class Initialized
INFO - 2022-05-13 14:44:49 --> Language Class Initialized
ERROR - 2022-05-13 14:44:49 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:45:26 --> Config Class Initialized
INFO - 2022-05-13 14:45:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:45:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:26 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:26 --> URI Class Initialized
INFO - 2022-05-13 14:45:26 --> Router Class Initialized
INFO - 2022-05-13 14:45:26 --> Output Class Initialized
INFO - 2022-05-13 14:45:26 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:26 --> Input Class Initialized
INFO - 2022-05-13 14:45:26 --> Language Class Initialized
INFO - 2022-05-13 14:45:26 --> Language Class Initialized
INFO - 2022-05-13 14:45:26 --> Config Class Initialized
INFO - 2022-05-13 14:45:26 --> Loader Class Initialized
INFO - 2022-05-13 14:45:26 --> Helper loaded: url_helper
INFO - 2022-05-13 14:45:26 --> Database Driver Class Initialized
INFO - 2022-05-13 14:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:45:26 --> Controller Class Initialized
DEBUG - 2022-05-13 14:45:26 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:45:26 --> Model Class Initialized
DEBUG - 2022-05-13 14:45:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:45:26 --> Model Class Initialized
DEBUG - 2022-05-13 14:45:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:45:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:45:26 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:45:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:45:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:45:26 --> Final output sent to browser
DEBUG - 2022-05-13 14:45:26 --> Total execution time: 0.0471
INFO - 2022-05-13 14:45:26 --> Config Class Initialized
INFO - 2022-05-13 14:45:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:45:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:26 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:26 --> URI Class Initialized
INFO - 2022-05-13 14:45:26 --> Router Class Initialized
INFO - 2022-05-13 14:45:26 --> Output Class Initialized
INFO - 2022-05-13 14:45:26 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:26 --> Input Class Initialized
INFO - 2022-05-13 14:45:26 --> Language Class Initialized
ERROR - 2022-05-13 14:45:26 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:45:26 --> Config Class Initialized
INFO - 2022-05-13 14:45:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:45:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:26 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:26 --> URI Class Initialized
INFO - 2022-05-13 14:45:26 --> Router Class Initialized
INFO - 2022-05-13 14:45:26 --> Output Class Initialized
INFO - 2022-05-13 14:45:26 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:26 --> Input Class Initialized
INFO - 2022-05-13 14:45:26 --> Language Class Initialized
ERROR - 2022-05-13 14:45:26 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:45:26 --> Config Class Initialized
INFO - 2022-05-13 14:45:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:45:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:26 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:26 --> URI Class Initialized
INFO - 2022-05-13 14:45:26 --> Router Class Initialized
INFO - 2022-05-13 14:45:26 --> Output Class Initialized
INFO - 2022-05-13 14:45:26 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:26 --> Input Class Initialized
INFO - 2022-05-13 14:45:26 --> Language Class Initialized
ERROR - 2022-05-13 14:45:26 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:45:52 --> Config Class Initialized
INFO - 2022-05-13 14:45:52 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:45:52 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:52 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:52 --> URI Class Initialized
INFO - 2022-05-13 14:45:52 --> Router Class Initialized
INFO - 2022-05-13 14:45:52 --> Output Class Initialized
INFO - 2022-05-13 14:45:52 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:52 --> Input Class Initialized
INFO - 2022-05-13 14:45:52 --> Language Class Initialized
INFO - 2022-05-13 14:45:52 --> Language Class Initialized
INFO - 2022-05-13 14:45:52 --> Config Class Initialized
INFO - 2022-05-13 14:45:52 --> Loader Class Initialized
INFO - 2022-05-13 14:45:52 --> Helper loaded: url_helper
INFO - 2022-05-13 14:45:52 --> Database Driver Class Initialized
INFO - 2022-05-13 14:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:45:52 --> Controller Class Initialized
DEBUG - 2022-05-13 14:45:52 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:45:52 --> Model Class Initialized
DEBUG - 2022-05-13 14:45:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:45:52 --> Model Class Initialized
DEBUG - 2022-05-13 14:45:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:45:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:45:52 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:45:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:45:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:45:52 --> Final output sent to browser
DEBUG - 2022-05-13 14:45:52 --> Total execution time: 0.0458
INFO - 2022-05-13 14:45:52 --> Config Class Initialized
INFO - 2022-05-13 14:45:52 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:45:52 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:52 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:52 --> URI Class Initialized
INFO - 2022-05-13 14:45:52 --> Router Class Initialized
INFO - 2022-05-13 14:45:52 --> Output Class Initialized
INFO - 2022-05-13 14:45:52 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:52 --> Input Class Initialized
INFO - 2022-05-13 14:45:52 --> Language Class Initialized
ERROR - 2022-05-13 14:45:52 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:45:52 --> Config Class Initialized
INFO - 2022-05-13 14:45:52 --> Hooks Class Initialized
INFO - 2022-05-13 14:45:52 --> Config Class Initialized
DEBUG - 2022-05-13 14:45:52 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:52 --> Hooks Class Initialized
INFO - 2022-05-13 14:45:52 --> Utf8 Class Initialized
DEBUG - 2022-05-13 14:45:52 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:45:52 --> URI Class Initialized
INFO - 2022-05-13 14:45:52 --> Utf8 Class Initialized
INFO - 2022-05-13 14:45:52 --> URI Class Initialized
INFO - 2022-05-13 14:45:52 --> Router Class Initialized
INFO - 2022-05-13 14:45:52 --> Router Class Initialized
INFO - 2022-05-13 14:45:52 --> Output Class Initialized
INFO - 2022-05-13 14:45:52 --> Output Class Initialized
INFO - 2022-05-13 14:45:52 --> Security Class Initialized
INFO - 2022-05-13 14:45:52 --> Security Class Initialized
DEBUG - 2022-05-13 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:52 --> Input Class Initialized
DEBUG - 2022-05-13 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:45:52 --> Input Class Initialized
INFO - 2022-05-13 14:45:52 --> Language Class Initialized
INFO - 2022-05-13 14:45:52 --> Language Class Initialized
ERROR - 2022-05-13 14:45:52 --> 404 Page Not Found: /index
ERROR - 2022-05-13 14:45:52 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:12 --> Config Class Initialized
INFO - 2022-05-13 14:46:12 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:12 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:12 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:12 --> URI Class Initialized
INFO - 2022-05-13 14:46:12 --> Router Class Initialized
INFO - 2022-05-13 14:46:12 --> Output Class Initialized
INFO - 2022-05-13 14:46:12 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:12 --> Input Class Initialized
INFO - 2022-05-13 14:46:12 --> Language Class Initialized
INFO - 2022-05-13 14:46:12 --> Language Class Initialized
INFO - 2022-05-13 14:46:12 --> Config Class Initialized
INFO - 2022-05-13 14:46:12 --> Loader Class Initialized
INFO - 2022-05-13 14:46:12 --> Helper loaded: url_helper
INFO - 2022-05-13 14:46:12 --> Database Driver Class Initialized
INFO - 2022-05-13 14:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:46:12 --> Controller Class Initialized
DEBUG - 2022-05-13 14:46:12 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:46:12 --> Model Class Initialized
DEBUG - 2022-05-13 14:46:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:46:12 --> Model Class Initialized
DEBUG - 2022-05-13 14:46:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:46:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:46:12 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:46:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:46:12 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:46:12 --> Final output sent to browser
DEBUG - 2022-05-13 14:46:12 --> Total execution time: 0.0459
INFO - 2022-05-13 14:46:13 --> Config Class Initialized
INFO - 2022-05-13 14:46:13 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:13 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:13 --> URI Class Initialized
INFO - 2022-05-13 14:46:13 --> Router Class Initialized
INFO - 2022-05-13 14:46:13 --> Output Class Initialized
INFO - 2022-05-13 14:46:13 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:13 --> Input Class Initialized
INFO - 2022-05-13 14:46:13 --> Language Class Initialized
ERROR - 2022-05-13 14:46:13 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:13 --> Config Class Initialized
INFO - 2022-05-13 14:46:13 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:13 --> Config Class Initialized
INFO - 2022-05-13 14:46:13 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:13 --> Hooks Class Initialized
INFO - 2022-05-13 14:46:13 --> URI Class Initialized
DEBUG - 2022-05-13 14:46:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:13 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:13 --> URI Class Initialized
INFO - 2022-05-13 14:46:13 --> Router Class Initialized
INFO - 2022-05-13 14:46:13 --> Output Class Initialized
INFO - 2022-05-13 14:46:13 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:13 --> Input Class Initialized
INFO - 2022-05-13 14:46:13 --> Language Class Initialized
ERROR - 2022-05-13 14:46:13 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:13 --> Router Class Initialized
INFO - 2022-05-13 14:46:13 --> Output Class Initialized
INFO - 2022-05-13 14:46:13 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:13 --> Input Class Initialized
INFO - 2022-05-13 14:46:13 --> Language Class Initialized
ERROR - 2022-05-13 14:46:13 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:24 --> Config Class Initialized
INFO - 2022-05-13 14:46:24 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:24 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:24 --> URI Class Initialized
INFO - 2022-05-13 14:46:24 --> Router Class Initialized
INFO - 2022-05-13 14:46:24 --> Output Class Initialized
INFO - 2022-05-13 14:46:24 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:24 --> Input Class Initialized
INFO - 2022-05-13 14:46:24 --> Language Class Initialized
INFO - 2022-05-13 14:46:24 --> Language Class Initialized
INFO - 2022-05-13 14:46:24 --> Config Class Initialized
INFO - 2022-05-13 14:46:24 --> Loader Class Initialized
INFO - 2022-05-13 14:46:24 --> Helper loaded: url_helper
INFO - 2022-05-13 14:46:24 --> Database Driver Class Initialized
INFO - 2022-05-13 14:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:46:24 --> Controller Class Initialized
DEBUG - 2022-05-13 14:46:24 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:46:24 --> Model Class Initialized
DEBUG - 2022-05-13 14:46:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:46:24 --> Model Class Initialized
DEBUG - 2022-05-13 14:46:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:46:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:46:24 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 68
DEBUG - 2022-05-13 14:46:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:46:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:46:24 --> Final output sent to browser
DEBUG - 2022-05-13 14:46:24 --> Total execution time: 0.0347
INFO - 2022-05-13 14:46:24 --> Config Class Initialized
INFO - 2022-05-13 14:46:24 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:24 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:24 --> URI Class Initialized
INFO - 2022-05-13 14:46:24 --> Router Class Initialized
INFO - 2022-05-13 14:46:24 --> Output Class Initialized
INFO - 2022-05-13 14:46:24 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:24 --> Input Class Initialized
INFO - 2022-05-13 14:46:24 --> Language Class Initialized
ERROR - 2022-05-13 14:46:24 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:24 --> Config Class Initialized
INFO - 2022-05-13 14:46:24 --> Hooks Class Initialized
INFO - 2022-05-13 14:46:24 --> Config Class Initialized
INFO - 2022-05-13 14:46:24 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:24 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:24 --> URI Class Initialized
DEBUG - 2022-05-13 14:46:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:24 --> Router Class Initialized
INFO - 2022-05-13 14:46:24 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:24 --> Output Class Initialized
INFO - 2022-05-13 14:46:24 --> URI Class Initialized
INFO - 2022-05-13 14:46:24 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:24 --> Input Class Initialized
INFO - 2022-05-13 14:46:24 --> Language Class Initialized
INFO - 2022-05-13 14:46:24 --> Router Class Initialized
ERROR - 2022-05-13 14:46:24 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:24 --> Output Class Initialized
INFO - 2022-05-13 14:46:24 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:24 --> Input Class Initialized
INFO - 2022-05-13 14:46:24 --> Language Class Initialized
ERROR - 2022-05-13 14:46:24 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:47 --> Config Class Initialized
INFO - 2022-05-13 14:46:47 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:47 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:47 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:47 --> URI Class Initialized
INFO - 2022-05-13 14:46:47 --> Router Class Initialized
INFO - 2022-05-13 14:46:47 --> Output Class Initialized
INFO - 2022-05-13 14:46:47 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:47 --> Input Class Initialized
INFO - 2022-05-13 14:46:47 --> Language Class Initialized
INFO - 2022-05-13 14:46:47 --> Language Class Initialized
INFO - 2022-05-13 14:46:47 --> Config Class Initialized
INFO - 2022-05-13 14:46:47 --> Loader Class Initialized
INFO - 2022-05-13 14:46:47 --> Helper loaded: url_helper
INFO - 2022-05-13 14:46:47 --> Database Driver Class Initialized
INFO - 2022-05-13 14:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:46:47 --> Controller Class Initialized
DEBUG - 2022-05-13 14:46:47 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:46:47 --> Model Class Initialized
DEBUG - 2022-05-13 14:46:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:46:47 --> Model Class Initialized
DEBUG - 2022-05-13 14:46:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:46:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:46:47 --> Severity: Notice --> Undefined variable: l C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
DEBUG - 2022-05-13 14:46:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:46:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:46:47 --> Final output sent to browser
DEBUG - 2022-05-13 14:46:47 --> Total execution time: 0.0329
INFO - 2022-05-13 14:46:47 --> Config Class Initialized
INFO - 2022-05-13 14:46:47 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:47 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:47 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:47 --> URI Class Initialized
INFO - 2022-05-13 14:46:47 --> Router Class Initialized
INFO - 2022-05-13 14:46:47 --> Output Class Initialized
INFO - 2022-05-13 14:46:47 --> Security Class Initialized
DEBUG - 2022-05-13 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:47 --> Input Class Initialized
INFO - 2022-05-13 14:46:47 --> Language Class Initialized
ERROR - 2022-05-13 14:46:47 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:47 --> Config Class Initialized
INFO - 2022-05-13 14:46:47 --> Hooks Class Initialized
INFO - 2022-05-13 14:46:47 --> Config Class Initialized
INFO - 2022-05-13 14:46:47 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:46:47 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:47 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:47 --> URI Class Initialized
DEBUG - 2022-05-13 14:46:47 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:46:47 --> Utf8 Class Initialized
INFO - 2022-05-13 14:46:47 --> URI Class Initialized
INFO - 2022-05-13 14:46:47 --> Router Class Initialized
INFO - 2022-05-13 14:46:47 --> Router Class Initialized
INFO - 2022-05-13 14:46:47 --> Output Class Initialized
INFO - 2022-05-13 14:46:47 --> Security Class Initialized
INFO - 2022-05-13 14:46:47 --> Output Class Initialized
DEBUG - 2022-05-13 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:47 --> Security Class Initialized
INFO - 2022-05-13 14:46:47 --> Input Class Initialized
INFO - 2022-05-13 14:46:47 --> Language Class Initialized
DEBUG - 2022-05-13 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:46:47 --> Input Class Initialized
ERROR - 2022-05-13 14:46:47 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:46:47 --> Language Class Initialized
ERROR - 2022-05-13 14:46:47 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:50:27 --> Config Class Initialized
INFO - 2022-05-13 14:50:27 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:50:27 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:50:27 --> Utf8 Class Initialized
INFO - 2022-05-13 14:50:27 --> URI Class Initialized
INFO - 2022-05-13 14:50:27 --> Router Class Initialized
INFO - 2022-05-13 14:50:27 --> Output Class Initialized
INFO - 2022-05-13 14:50:27 --> Security Class Initialized
DEBUG - 2022-05-13 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:50:27 --> Input Class Initialized
INFO - 2022-05-13 14:50:27 --> Language Class Initialized
INFO - 2022-05-13 14:50:27 --> Language Class Initialized
INFO - 2022-05-13 14:50:27 --> Config Class Initialized
INFO - 2022-05-13 14:50:27 --> Loader Class Initialized
INFO - 2022-05-13 14:50:27 --> Helper loaded: url_helper
INFO - 2022-05-13 14:50:27 --> Database Driver Class Initialized
INFO - 2022-05-13 14:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:50:27 --> Controller Class Initialized
DEBUG - 2022-05-13 14:50:27 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:50:27 --> Model Class Initialized
DEBUG - 2022-05-13 14:50:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:50:27 --> Model Class Initialized
DEBUG - 2022-05-13 14:50:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:50:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 69
ERROR - 2022-05-13 14:50:27 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
DEBUG - 2022-05-13 14:50:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:50:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:50:27 --> Final output sent to browser
DEBUG - 2022-05-13 14:50:27 --> Total execution time: 0.0635
INFO - 2022-05-13 14:51:11 --> Config Class Initialized
INFO - 2022-05-13 14:51:11 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:51:11 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:51:11 --> Utf8 Class Initialized
INFO - 2022-05-13 14:51:11 --> URI Class Initialized
INFO - 2022-05-13 14:51:11 --> Router Class Initialized
INFO - 2022-05-13 14:51:11 --> Output Class Initialized
INFO - 2022-05-13 14:51:11 --> Security Class Initialized
DEBUG - 2022-05-13 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:51:11 --> Input Class Initialized
INFO - 2022-05-13 14:51:11 --> Language Class Initialized
INFO - 2022-05-13 14:51:11 --> Language Class Initialized
INFO - 2022-05-13 14:51:11 --> Config Class Initialized
INFO - 2022-05-13 14:51:11 --> Loader Class Initialized
INFO - 2022-05-13 14:51:11 --> Helper loaded: url_helper
INFO - 2022-05-13 14:51:11 --> Database Driver Class Initialized
INFO - 2022-05-13 14:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:51:11 --> Controller Class Initialized
DEBUG - 2022-05-13 14:51:11 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:51:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:51:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:51:11 --> Model Class Initialized
DEBUG - 2022-05-13 14:51:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:51:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 70
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_logo C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 71
ERROR - 2022-05-13 14:51:11 --> Severity: Notice --> Undefined index: b_name C:\xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 72
DEBUG - 2022-05-13 14:51:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:51:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:51:11 --> Final output sent to browser
DEBUG - 2022-05-13 14:51:11 --> Total execution time: 0.0641
INFO - 2022-05-13 14:51:58 --> Config Class Initialized
INFO - 2022-05-13 14:51:58 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:51:58 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:51:58 --> Utf8 Class Initialized
INFO - 2022-05-13 14:51:58 --> URI Class Initialized
INFO - 2022-05-13 14:51:58 --> Router Class Initialized
INFO - 2022-05-13 14:51:58 --> Output Class Initialized
INFO - 2022-05-13 14:51:58 --> Security Class Initialized
DEBUG - 2022-05-13 14:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:51:58 --> Input Class Initialized
INFO - 2022-05-13 14:51:58 --> Language Class Initialized
INFO - 2022-05-13 14:51:58 --> Language Class Initialized
INFO - 2022-05-13 14:51:58 --> Config Class Initialized
INFO - 2022-05-13 14:51:58 --> Loader Class Initialized
INFO - 2022-05-13 14:51:58 --> Helper loaded: url_helper
INFO - 2022-05-13 14:51:58 --> Database Driver Class Initialized
INFO - 2022-05-13 14:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:51:58 --> Controller Class Initialized
DEBUG - 2022-05-13 14:51:58 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:51:58 --> Model Class Initialized
DEBUG - 2022-05-13 14:51:58 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:51:58 --> Model Class Initialized
DEBUG - 2022-05-13 14:51:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:51:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:51:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:51:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:51:59 --> Final output sent to browser
DEBUG - 2022-05-13 14:51:59 --> Total execution time: 0.0469
INFO - 2022-05-13 14:53:14 --> Config Class Initialized
INFO - 2022-05-13 14:53:14 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:53:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:53:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:53:14 --> URI Class Initialized
INFO - 2022-05-13 14:53:14 --> Router Class Initialized
INFO - 2022-05-13 14:53:14 --> Output Class Initialized
INFO - 2022-05-13 14:53:14 --> Security Class Initialized
DEBUG - 2022-05-13 14:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:53:14 --> Input Class Initialized
INFO - 2022-05-13 14:53:14 --> Language Class Initialized
INFO - 2022-05-13 14:53:14 --> Language Class Initialized
INFO - 2022-05-13 14:53:14 --> Config Class Initialized
INFO - 2022-05-13 14:53:14 --> Loader Class Initialized
INFO - 2022-05-13 14:53:14 --> Helper loaded: url_helper
INFO - 2022-05-13 14:53:14 --> Database Driver Class Initialized
INFO - 2022-05-13 14:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:53:14 --> Controller Class Initialized
DEBUG - 2022-05-13 14:53:14 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:53:14 --> Model Class Initialized
DEBUG - 2022-05-13 14:53:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:53:14 --> Model Class Initialized
DEBUG - 2022-05-13 14:53:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:53:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:53:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:53:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:53:14 --> Final output sent to browser
DEBUG - 2022-05-13 14:53:14 --> Total execution time: 0.0556
INFO - 2022-05-13 14:53:14 --> Config Class Initialized
INFO - 2022-05-13 14:53:14 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:53:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:53:14 --> Config Class Initialized
INFO - 2022-05-13 14:53:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:53:14 --> Hooks Class Initialized
INFO - 2022-05-13 14:53:14 --> URI Class Initialized
DEBUG - 2022-05-13 14:53:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:53:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:53:14 --> Router Class Initialized
INFO - 2022-05-13 14:53:14 --> URI Class Initialized
INFO - 2022-05-13 14:53:14 --> Output Class Initialized
INFO - 2022-05-13 14:53:14 --> Security Class Initialized
DEBUG - 2022-05-13 14:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:53:14 --> Input Class Initialized
INFO - 2022-05-13 14:53:14 --> Language Class Initialized
INFO - 2022-05-13 14:53:14 --> Config Class Initialized
INFO - 2022-05-13 14:53:14 --> Hooks Class Initialized
ERROR - 2022-05-13 14:53:14 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:53:14 --> Router Class Initialized
DEBUG - 2022-05-13 14:53:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:53:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:53:14 --> URI Class Initialized
INFO - 2022-05-13 14:53:14 --> Output Class Initialized
INFO - 2022-05-13 14:53:14 --> Router Class Initialized
INFO - 2022-05-13 14:53:14 --> Security Class Initialized
INFO - 2022-05-13 14:53:14 --> Output Class Initialized
DEBUG - 2022-05-13 14:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:53:14 --> Security Class Initialized
INFO - 2022-05-13 14:53:14 --> Input Class Initialized
DEBUG - 2022-05-13 14:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:53:14 --> Language Class Initialized
INFO - 2022-05-13 14:53:14 --> Input Class Initialized
INFO - 2022-05-13 14:53:14 --> Language Class Initialized
ERROR - 2022-05-13 14:53:14 --> 404 Page Not Found: /index
ERROR - 2022-05-13 14:53:14 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:53:14 --> Config Class Initialized
INFO - 2022-05-13 14:53:14 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:53:14 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:53:14 --> Utf8 Class Initialized
INFO - 2022-05-13 14:53:14 --> URI Class Initialized
INFO - 2022-05-13 14:53:14 --> Router Class Initialized
INFO - 2022-05-13 14:53:14 --> Output Class Initialized
INFO - 2022-05-13 14:53:14 --> Security Class Initialized
DEBUG - 2022-05-13 14:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:53:14 --> Input Class Initialized
INFO - 2022-05-13 14:53:14 --> Language Class Initialized
ERROR - 2022-05-13 14:53:14 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:53:35 --> Config Class Initialized
INFO - 2022-05-13 14:53:35 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:53:35 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:53:35 --> Utf8 Class Initialized
INFO - 2022-05-13 14:53:35 --> URI Class Initialized
INFO - 2022-05-13 14:53:35 --> Router Class Initialized
INFO - 2022-05-13 14:53:35 --> Output Class Initialized
INFO - 2022-05-13 14:53:35 --> Security Class Initialized
DEBUG - 2022-05-13 14:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:53:35 --> Input Class Initialized
INFO - 2022-05-13 14:53:35 --> Language Class Initialized
INFO - 2022-05-13 14:53:35 --> Language Class Initialized
INFO - 2022-05-13 14:53:35 --> Config Class Initialized
INFO - 2022-05-13 14:53:35 --> Loader Class Initialized
INFO - 2022-05-13 14:53:35 --> Helper loaded: url_helper
INFO - 2022-05-13 14:53:35 --> Database Driver Class Initialized
INFO - 2022-05-13 14:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:53:35 --> Controller Class Initialized
DEBUG - 2022-05-13 14:53:35 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:53:35 --> Model Class Initialized
DEBUG - 2022-05-13 14:53:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:53:35 --> Model Class Initialized
DEBUG - 2022-05-13 14:53:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:53:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:53:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-13 14:53:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:53:35 --> Final output sent to browser
DEBUG - 2022-05-13 14:53:35 --> Total execution time: 0.0491
INFO - 2022-05-13 14:57:59 --> Config Class Initialized
INFO - 2022-05-13 14:57:59 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:57:59 --> Utf8 Class Initialized
INFO - 2022-05-13 14:57:59 --> URI Class Initialized
INFO - 2022-05-13 14:57:59 --> Router Class Initialized
INFO - 2022-05-13 14:57:59 --> Output Class Initialized
INFO - 2022-05-13 14:57:59 --> Security Class Initialized
DEBUG - 2022-05-13 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:57:59 --> Input Class Initialized
INFO - 2022-05-13 14:57:59 --> Language Class Initialized
INFO - 2022-05-13 14:57:59 --> Language Class Initialized
INFO - 2022-05-13 14:57:59 --> Config Class Initialized
INFO - 2022-05-13 14:57:59 --> Loader Class Initialized
INFO - 2022-05-13 14:57:59 --> Helper loaded: url_helper
INFO - 2022-05-13 14:57:59 --> Database Driver Class Initialized
INFO - 2022-05-13 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:57:59 --> Controller Class Initialized
DEBUG - 2022-05-13 14:57:59 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:57:59 --> Model Class Initialized
DEBUG - 2022-05-13 14:57:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:57:59 --> Model Class Initialized
DEBUG - 2022-05-13 14:57:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:57:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:57:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:57:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:57:59 --> Final output sent to browser
DEBUG - 2022-05-13 14:57:59 --> Total execution time: 0.0529
INFO - 2022-05-13 14:57:59 --> Config Class Initialized
INFO - 2022-05-13 14:57:59 --> Hooks Class Initialized
INFO - 2022-05-13 14:57:59 --> Config Class Initialized
INFO - 2022-05-13 14:57:59 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:57:59 --> Utf8 Class Initialized
DEBUG - 2022-05-13 14:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:57:59 --> Utf8 Class Initialized
INFO - 2022-05-13 14:57:59 --> URI Class Initialized
INFO - 2022-05-13 14:57:59 --> URI Class Initialized
INFO - 2022-05-13 14:57:59 --> Router Class Initialized
INFO - 2022-05-13 14:57:59 --> Router Class Initialized
INFO - 2022-05-13 14:57:59 --> Output Class Initialized
INFO - 2022-05-13 14:57:59 --> Output Class Initialized
INFO - 2022-05-13 14:57:59 --> Config Class Initialized
INFO - 2022-05-13 14:57:59 --> Hooks Class Initialized
INFO - 2022-05-13 14:57:59 --> Security Class Initialized
INFO - 2022-05-13 14:57:59 --> Security Class Initialized
DEBUG - 2022-05-13 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:57:59 --> Input Class Initialized
DEBUG - 2022-05-13 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:57:59 --> Input Class Initialized
INFO - 2022-05-13 14:57:59 --> Language Class Initialized
DEBUG - 2022-05-13 14:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:57:59 --> Language Class Initialized
INFO - 2022-05-13 14:57:59 --> Utf8 Class Initialized
ERROR - 2022-05-13 14:57:59 --> 404 Page Not Found: /index
ERROR - 2022-05-13 14:57:59 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:57:59 --> URI Class Initialized
INFO - 2022-05-13 14:57:59 --> Router Class Initialized
INFO - 2022-05-13 14:57:59 --> Output Class Initialized
INFO - 2022-05-13 14:57:59 --> Security Class Initialized
INFO - 2022-05-13 14:57:59 --> Config Class Initialized
INFO - 2022-05-13 14:57:59 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:57:59 --> Input Class Initialized
INFO - 2022-05-13 14:57:59 --> Language Class Initialized
ERROR - 2022-05-13 14:57:59 --> 404 Page Not Found: /index
DEBUG - 2022-05-13 14:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:57:59 --> Utf8 Class Initialized
INFO - 2022-05-13 14:57:59 --> URI Class Initialized
INFO - 2022-05-13 14:57:59 --> Router Class Initialized
INFO - 2022-05-13 14:57:59 --> Output Class Initialized
INFO - 2022-05-13 14:57:59 --> Security Class Initialized
DEBUG - 2022-05-13 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:57:59 --> Input Class Initialized
INFO - 2022-05-13 14:57:59 --> Language Class Initialized
ERROR - 2022-05-13 14:57:59 --> 404 Page Not Found: /index
INFO - 2022-05-13 14:58:30 --> Config Class Initialized
INFO - 2022-05-13 14:58:30 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:58:30 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:58:30 --> Utf8 Class Initialized
INFO - 2022-05-13 14:58:30 --> URI Class Initialized
INFO - 2022-05-13 14:58:30 --> Router Class Initialized
INFO - 2022-05-13 14:58:30 --> Output Class Initialized
INFO - 2022-05-13 14:58:30 --> Security Class Initialized
DEBUG - 2022-05-13 14:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:58:30 --> Input Class Initialized
INFO - 2022-05-13 14:58:30 --> Language Class Initialized
INFO - 2022-05-13 14:58:30 --> Language Class Initialized
INFO - 2022-05-13 14:58:30 --> Config Class Initialized
INFO - 2022-05-13 14:58:30 --> Loader Class Initialized
INFO - 2022-05-13 14:58:30 --> Helper loaded: url_helper
INFO - 2022-05-13 14:58:30 --> Database Driver Class Initialized
INFO - 2022-05-13 14:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:58:30 --> Controller Class Initialized
DEBUG - 2022-05-13 14:58:30 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:58:30 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:58:30 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:58:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:58:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:58:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:58:30 --> Final output sent to browser
DEBUG - 2022-05-13 14:58:30 --> Total execution time: 0.0298
INFO - 2022-05-13 14:58:33 --> Config Class Initialized
INFO - 2022-05-13 14:58:33 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:58:33 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:58:33 --> Utf8 Class Initialized
INFO - 2022-05-13 14:58:33 --> URI Class Initialized
INFO - 2022-05-13 14:58:33 --> Router Class Initialized
INFO - 2022-05-13 14:58:33 --> Output Class Initialized
INFO - 2022-05-13 14:58:33 --> Security Class Initialized
DEBUG - 2022-05-13 14:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:58:33 --> Input Class Initialized
INFO - 2022-05-13 14:58:33 --> Language Class Initialized
INFO - 2022-05-13 14:58:33 --> Language Class Initialized
INFO - 2022-05-13 14:58:33 --> Config Class Initialized
INFO - 2022-05-13 14:58:33 --> Loader Class Initialized
INFO - 2022-05-13 14:58:33 --> Helper loaded: url_helper
INFO - 2022-05-13 14:58:33 --> Database Driver Class Initialized
INFO - 2022-05-13 14:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:58:33 --> Controller Class Initialized
DEBUG - 2022-05-13 14:58:33 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:58:33 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:58:33 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:58:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:58:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:58:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:58:33 --> Final output sent to browser
DEBUG - 2022-05-13 14:58:33 --> Total execution time: 0.0314
INFO - 2022-05-13 14:58:40 --> Config Class Initialized
INFO - 2022-05-13 14:58:40 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:58:40 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:58:40 --> Utf8 Class Initialized
INFO - 2022-05-13 14:58:40 --> URI Class Initialized
INFO - 2022-05-13 14:58:40 --> Router Class Initialized
INFO - 2022-05-13 14:58:40 --> Output Class Initialized
INFO - 2022-05-13 14:58:40 --> Security Class Initialized
DEBUG - 2022-05-13 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:58:40 --> Input Class Initialized
INFO - 2022-05-13 14:58:40 --> Language Class Initialized
INFO - 2022-05-13 14:58:40 --> Language Class Initialized
INFO - 2022-05-13 14:58:40 --> Config Class Initialized
INFO - 2022-05-13 14:58:40 --> Loader Class Initialized
INFO - 2022-05-13 14:58:40 --> Helper loaded: url_helper
INFO - 2022-05-13 14:58:40 --> Database Driver Class Initialized
INFO - 2022-05-13 14:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:58:40 --> Controller Class Initialized
DEBUG - 2022-05-13 14:58:40 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:58:40 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:58:40 --> Model Class Initialized
INFO - 2022-05-13 14:58:40 --> Upload Class Initialized
INFO - 2022-05-13 14:58:40 --> Config Class Initialized
INFO - 2022-05-13 14:58:40 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:58:40 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:58:40 --> Utf8 Class Initialized
INFO - 2022-05-13 14:58:40 --> URI Class Initialized
INFO - 2022-05-13 14:58:40 --> Router Class Initialized
INFO - 2022-05-13 14:58:40 --> Output Class Initialized
INFO - 2022-05-13 14:58:40 --> Security Class Initialized
DEBUG - 2022-05-13 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:58:40 --> Input Class Initialized
INFO - 2022-05-13 14:58:40 --> Language Class Initialized
INFO - 2022-05-13 14:58:40 --> Language Class Initialized
INFO - 2022-05-13 14:58:40 --> Config Class Initialized
INFO - 2022-05-13 14:58:40 --> Loader Class Initialized
INFO - 2022-05-13 14:58:40 --> Helper loaded: url_helper
INFO - 2022-05-13 14:58:40 --> Database Driver Class Initialized
INFO - 2022-05-13 14:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:58:40 --> Controller Class Initialized
DEBUG - 2022-05-13 14:58:40 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:58:40 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:58:40 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:58:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:58:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:58:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:58:40 --> Final output sent to browser
DEBUG - 2022-05-13 14:58:40 --> Total execution time: 0.0452
INFO - 2022-05-13 14:58:48 --> Config Class Initialized
INFO - 2022-05-13 14:58:48 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:58:48 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:58:48 --> Utf8 Class Initialized
INFO - 2022-05-13 14:58:48 --> URI Class Initialized
INFO - 2022-05-13 14:58:48 --> Router Class Initialized
INFO - 2022-05-13 14:58:48 --> Output Class Initialized
INFO - 2022-05-13 14:58:48 --> Security Class Initialized
DEBUG - 2022-05-13 14:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:58:48 --> Input Class Initialized
INFO - 2022-05-13 14:58:48 --> Language Class Initialized
INFO - 2022-05-13 14:58:48 --> Language Class Initialized
INFO - 2022-05-13 14:58:48 --> Config Class Initialized
INFO - 2022-05-13 14:58:48 --> Loader Class Initialized
INFO - 2022-05-13 14:58:48 --> Helper loaded: url_helper
INFO - 2022-05-13 14:58:48 --> Database Driver Class Initialized
INFO - 2022-05-13 14:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:58:48 --> Controller Class Initialized
DEBUG - 2022-05-13 14:58:48 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:58:48 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:58:48 --> Model Class Initialized
INFO - 2022-05-13 14:58:48 --> Upload Class Initialized
INFO - 2022-05-13 14:58:48 --> Config Class Initialized
INFO - 2022-05-13 14:58:48 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:58:48 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:58:48 --> Utf8 Class Initialized
INFO - 2022-05-13 14:58:48 --> URI Class Initialized
INFO - 2022-05-13 14:58:48 --> Router Class Initialized
INFO - 2022-05-13 14:58:48 --> Output Class Initialized
INFO - 2022-05-13 14:58:48 --> Security Class Initialized
DEBUG - 2022-05-13 14:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:58:48 --> Input Class Initialized
INFO - 2022-05-13 14:58:48 --> Language Class Initialized
INFO - 2022-05-13 14:58:48 --> Language Class Initialized
INFO - 2022-05-13 14:58:48 --> Config Class Initialized
INFO - 2022-05-13 14:58:48 --> Loader Class Initialized
INFO - 2022-05-13 14:58:48 --> Helper loaded: url_helper
INFO - 2022-05-13 14:58:48 --> Database Driver Class Initialized
INFO - 2022-05-13 14:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:58:48 --> Controller Class Initialized
DEBUG - 2022-05-13 14:58:48 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:58:48 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:58:48 --> Model Class Initialized
DEBUG - 2022-05-13 14:58:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:58:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:58:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:58:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:58:48 --> Final output sent to browser
DEBUG - 2022-05-13 14:58:48 --> Total execution time: 0.0638
INFO - 2022-05-13 14:59:10 --> Config Class Initialized
INFO - 2022-05-13 14:59:10 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:59:10 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:59:10 --> Utf8 Class Initialized
INFO - 2022-05-13 14:59:10 --> URI Class Initialized
INFO - 2022-05-13 14:59:10 --> Router Class Initialized
INFO - 2022-05-13 14:59:10 --> Output Class Initialized
INFO - 2022-05-13 14:59:10 --> Security Class Initialized
DEBUG - 2022-05-13 14:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:59:10 --> Input Class Initialized
INFO - 2022-05-13 14:59:10 --> Language Class Initialized
INFO - 2022-05-13 14:59:10 --> Language Class Initialized
INFO - 2022-05-13 14:59:10 --> Config Class Initialized
INFO - 2022-05-13 14:59:10 --> Loader Class Initialized
INFO - 2022-05-13 14:59:10 --> Helper loaded: url_helper
INFO - 2022-05-13 14:59:10 --> Database Driver Class Initialized
INFO - 2022-05-13 14:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:59:10 --> Controller Class Initialized
DEBUG - 2022-05-13 14:59:10 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:59:10 --> Model Class Initialized
DEBUG - 2022-05-13 14:59:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:59:10 --> Model Class Initialized
INFO - 2022-05-13 14:59:10 --> Upload Class Initialized
INFO - 2022-05-13 14:59:10 --> Config Class Initialized
INFO - 2022-05-13 14:59:10 --> Hooks Class Initialized
DEBUG - 2022-05-13 14:59:10 --> UTF-8 Support Enabled
INFO - 2022-05-13 14:59:10 --> Utf8 Class Initialized
INFO - 2022-05-13 14:59:10 --> URI Class Initialized
INFO - 2022-05-13 14:59:10 --> Router Class Initialized
INFO - 2022-05-13 14:59:10 --> Output Class Initialized
INFO - 2022-05-13 14:59:10 --> Security Class Initialized
DEBUG - 2022-05-13 14:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 14:59:10 --> Input Class Initialized
INFO - 2022-05-13 14:59:10 --> Language Class Initialized
INFO - 2022-05-13 14:59:10 --> Language Class Initialized
INFO - 2022-05-13 14:59:10 --> Config Class Initialized
INFO - 2022-05-13 14:59:10 --> Loader Class Initialized
INFO - 2022-05-13 14:59:10 --> Helper loaded: url_helper
INFO - 2022-05-13 14:59:10 --> Database Driver Class Initialized
INFO - 2022-05-13 14:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 14:59:10 --> Controller Class Initialized
DEBUG - 2022-05-13 14:59:10 --> Admin MX_Controller Initialized
INFO - 2022-05-13 14:59:10 --> Model Class Initialized
DEBUG - 2022-05-13 14:59:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 14:59:10 --> Model Class Initialized
DEBUG - 2022-05-13 14:59:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 14:59:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 14:59:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 14:59:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 14:59:10 --> Final output sent to browser
DEBUG - 2022-05-13 14:59:10 --> Total execution time: 0.0295
INFO - 2022-05-13 15:00:05 --> Config Class Initialized
INFO - 2022-05-13 15:00:05 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:00:05 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:00:05 --> Utf8 Class Initialized
INFO - 2022-05-13 15:00:05 --> URI Class Initialized
INFO - 2022-05-13 15:00:05 --> Router Class Initialized
INFO - 2022-05-13 15:00:05 --> Output Class Initialized
INFO - 2022-05-13 15:00:05 --> Security Class Initialized
DEBUG - 2022-05-13 15:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:00:05 --> Input Class Initialized
INFO - 2022-05-13 15:00:05 --> Language Class Initialized
INFO - 2022-05-13 15:00:05 --> Language Class Initialized
INFO - 2022-05-13 15:00:05 --> Config Class Initialized
INFO - 2022-05-13 15:00:05 --> Loader Class Initialized
INFO - 2022-05-13 15:00:05 --> Helper loaded: url_helper
INFO - 2022-05-13 15:00:05 --> Database Driver Class Initialized
INFO - 2022-05-13 15:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:00:05 --> Controller Class Initialized
DEBUG - 2022-05-13 15:00:05 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:00:05 --> Model Class Initialized
DEBUG - 2022-05-13 15:00:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:00:05 --> Model Class Initialized
DEBUG - 2022-05-13 15:00:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:00:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:00:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:00:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:00:05 --> Final output sent to browser
DEBUG - 2022-05-13 15:00:05 --> Total execution time: 0.0464
INFO - 2022-05-13 15:04:44 --> Config Class Initialized
INFO - 2022-05-13 15:04:44 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:04:44 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:04:44 --> Utf8 Class Initialized
INFO - 2022-05-13 15:04:44 --> URI Class Initialized
INFO - 2022-05-13 15:04:44 --> Router Class Initialized
INFO - 2022-05-13 15:04:44 --> Output Class Initialized
INFO - 2022-05-13 15:04:44 --> Security Class Initialized
DEBUG - 2022-05-13 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:04:44 --> Input Class Initialized
INFO - 2022-05-13 15:04:44 --> Language Class Initialized
INFO - 2022-05-13 15:04:44 --> Language Class Initialized
INFO - 2022-05-13 15:04:44 --> Config Class Initialized
INFO - 2022-05-13 15:04:44 --> Loader Class Initialized
INFO - 2022-05-13 15:04:44 --> Helper loaded: url_helper
INFO - 2022-05-13 15:04:44 --> Database Driver Class Initialized
INFO - 2022-05-13 15:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:04:44 --> Controller Class Initialized
DEBUG - 2022-05-13 15:04:44 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:04:44 --> Model Class Initialized
DEBUG - 2022-05-13 15:04:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:04:44 --> Model Class Initialized
DEBUG - 2022-05-13 15:04:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:04:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:04:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:04:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:04:44 --> Final output sent to browser
DEBUG - 2022-05-13 15:04:44 --> Total execution time: 0.0474
INFO - 2022-05-13 15:04:46 --> Config Class Initialized
INFO - 2022-05-13 15:04:46 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:04:46 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:04:46 --> Utf8 Class Initialized
INFO - 2022-05-13 15:04:46 --> URI Class Initialized
INFO - 2022-05-13 15:04:46 --> Router Class Initialized
INFO - 2022-05-13 15:04:46 --> Output Class Initialized
INFO - 2022-05-13 15:04:46 --> Security Class Initialized
DEBUG - 2022-05-13 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:04:46 --> Input Class Initialized
INFO - 2022-05-13 15:04:46 --> Language Class Initialized
INFO - 2022-05-13 15:04:46 --> Language Class Initialized
INFO - 2022-05-13 15:04:46 --> Config Class Initialized
INFO - 2022-05-13 15:04:46 --> Loader Class Initialized
INFO - 2022-05-13 15:04:46 --> Helper loaded: url_helper
INFO - 2022-05-13 15:04:46 --> Database Driver Class Initialized
INFO - 2022-05-13 15:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:04:46 --> Controller Class Initialized
DEBUG - 2022-05-13 15:04:46 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:04:46 --> Model Class Initialized
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:04:46 --> Model Class Initialized
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:04:46 --> Final output sent to browser
DEBUG - 2022-05-13 15:04:46 --> Total execution time: 0.0466
INFO - 2022-05-13 15:04:46 --> Config Class Initialized
INFO - 2022-05-13 15:04:46 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:04:46 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:04:46 --> Utf8 Class Initialized
INFO - 2022-05-13 15:04:46 --> URI Class Initialized
INFO - 2022-05-13 15:04:46 --> Router Class Initialized
INFO - 2022-05-13 15:04:46 --> Output Class Initialized
INFO - 2022-05-13 15:04:46 --> Security Class Initialized
DEBUG - 2022-05-13 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:04:46 --> Input Class Initialized
INFO - 2022-05-13 15:04:46 --> Language Class Initialized
INFO - 2022-05-13 15:04:46 --> Language Class Initialized
INFO - 2022-05-13 15:04:46 --> Config Class Initialized
INFO - 2022-05-13 15:04:46 --> Loader Class Initialized
INFO - 2022-05-13 15:04:46 --> Helper loaded: url_helper
INFO - 2022-05-13 15:04:46 --> Database Driver Class Initialized
INFO - 2022-05-13 15:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:04:46 --> Controller Class Initialized
DEBUG - 2022-05-13 15:04:46 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:04:46 --> Model Class Initialized
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:04:46 --> Model Class Initialized
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-13 15:04:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\motodeal\application\modules\admin\views\edit_brand.php 36
ERROR - 2022-05-13 15:04:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\motodeal\application\modules\admin\views\edit_brand.php 43
ERROR - 2022-05-13 15:04:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\motodeal\application\modules\admin\views\edit_brand.php 43
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:04:46 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:04:46 --> Final output sent to browser
DEBUG - 2022-05-13 15:04:46 --> Total execution time: 0.0598
INFO - 2022-05-13 15:05:55 --> Config Class Initialized
INFO - 2022-05-13 15:05:55 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:05:55 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:05:55 --> Utf8 Class Initialized
INFO - 2022-05-13 15:05:55 --> URI Class Initialized
INFO - 2022-05-13 15:05:55 --> Router Class Initialized
INFO - 2022-05-13 15:05:55 --> Output Class Initialized
INFO - 2022-05-13 15:05:55 --> Security Class Initialized
DEBUG - 2022-05-13 15:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:05:55 --> Input Class Initialized
INFO - 2022-05-13 15:05:55 --> Language Class Initialized
INFO - 2022-05-13 15:05:55 --> Language Class Initialized
INFO - 2022-05-13 15:05:55 --> Config Class Initialized
INFO - 2022-05-13 15:05:55 --> Loader Class Initialized
INFO - 2022-05-13 15:05:55 --> Helper loaded: url_helper
INFO - 2022-05-13 15:05:55 --> Database Driver Class Initialized
INFO - 2022-05-13 15:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:05:55 --> Controller Class Initialized
DEBUG - 2022-05-13 15:05:55 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:05:55 --> Model Class Initialized
DEBUG - 2022-05-13 15:05:55 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:05:55 --> Model Class Initialized
DEBUG - 2022-05-13 15:05:55 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:05:55 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:05:55 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:05:55 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:05:55 --> Final output sent to browser
DEBUG - 2022-05-13 15:05:55 --> Total execution time: 0.0417
INFO - 2022-05-13 15:05:59 --> Config Class Initialized
INFO - 2022-05-13 15:05:59 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:05:59 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:05:59 --> Utf8 Class Initialized
INFO - 2022-05-13 15:05:59 --> URI Class Initialized
INFO - 2022-05-13 15:05:59 --> Router Class Initialized
INFO - 2022-05-13 15:05:59 --> Output Class Initialized
INFO - 2022-05-13 15:05:59 --> Security Class Initialized
DEBUG - 2022-05-13 15:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:05:59 --> Input Class Initialized
INFO - 2022-05-13 15:05:59 --> Language Class Initialized
INFO - 2022-05-13 15:05:59 --> Language Class Initialized
INFO - 2022-05-13 15:05:59 --> Config Class Initialized
INFO - 2022-05-13 15:05:59 --> Loader Class Initialized
INFO - 2022-05-13 15:05:59 --> Helper loaded: url_helper
INFO - 2022-05-13 15:05:59 --> Database Driver Class Initialized
INFO - 2022-05-13 15:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:05:59 --> Controller Class Initialized
DEBUG - 2022-05-13 15:05:59 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:05:59 --> Model Class Initialized
DEBUG - 2022-05-13 15:05:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:05:59 --> Model Class Initialized
DEBUG - 2022-05-13 15:05:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:05:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:05:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:05:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:05:59 --> Final output sent to browser
DEBUG - 2022-05-13 15:05:59 --> Total execution time: 0.0298
INFO - 2022-05-13 15:13:43 --> Config Class Initialized
INFO - 2022-05-13 15:13:43 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:13:43 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:13:43 --> Utf8 Class Initialized
INFO - 2022-05-13 15:13:43 --> URI Class Initialized
INFO - 2022-05-13 15:13:43 --> Router Class Initialized
INFO - 2022-05-13 15:13:43 --> Output Class Initialized
INFO - 2022-05-13 15:13:43 --> Security Class Initialized
DEBUG - 2022-05-13 15:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:13:43 --> Input Class Initialized
INFO - 2022-05-13 15:13:43 --> Language Class Initialized
INFO - 2022-05-13 15:13:43 --> Language Class Initialized
INFO - 2022-05-13 15:13:43 --> Config Class Initialized
INFO - 2022-05-13 15:13:43 --> Loader Class Initialized
INFO - 2022-05-13 15:13:43 --> Helper loaded: url_helper
INFO - 2022-05-13 15:13:43 --> Database Driver Class Initialized
INFO - 2022-05-13 15:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:13:43 --> Controller Class Initialized
DEBUG - 2022-05-13 15:13:43 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:13:43 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:13:43 --> Model Class Initialized
ERROR - 2022-05-13 15:13:43 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 84
INFO - 2022-05-13 15:13:43 --> Config Class Initialized
INFO - 2022-05-13 15:13:43 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:13:43 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:13:43 --> Utf8 Class Initialized
INFO - 2022-05-13 15:13:43 --> URI Class Initialized
INFO - 2022-05-13 15:13:43 --> Router Class Initialized
INFO - 2022-05-13 15:13:43 --> Output Class Initialized
INFO - 2022-05-13 15:13:43 --> Security Class Initialized
DEBUG - 2022-05-13 15:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:13:43 --> Input Class Initialized
INFO - 2022-05-13 15:13:43 --> Language Class Initialized
INFO - 2022-05-13 15:13:43 --> Language Class Initialized
INFO - 2022-05-13 15:13:43 --> Config Class Initialized
INFO - 2022-05-13 15:13:43 --> Loader Class Initialized
INFO - 2022-05-13 15:13:43 --> Helper loaded: url_helper
INFO - 2022-05-13 15:13:43 --> Database Driver Class Initialized
INFO - 2022-05-13 15:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:13:43 --> Controller Class Initialized
DEBUG - 2022-05-13 15:13:43 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:13:43 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:13:43 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:13:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:13:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:13:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:13:43 --> Final output sent to browser
DEBUG - 2022-05-13 15:13:43 --> Total execution time: 0.0423
INFO - 2022-05-13 15:13:48 --> Config Class Initialized
INFO - 2022-05-13 15:13:48 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:13:48 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:13:48 --> Utf8 Class Initialized
INFO - 2022-05-13 15:13:48 --> URI Class Initialized
INFO - 2022-05-13 15:13:48 --> Router Class Initialized
INFO - 2022-05-13 15:13:48 --> Output Class Initialized
INFO - 2022-05-13 15:13:48 --> Security Class Initialized
DEBUG - 2022-05-13 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:13:48 --> Input Class Initialized
INFO - 2022-05-13 15:13:48 --> Language Class Initialized
INFO - 2022-05-13 15:13:48 --> Language Class Initialized
INFO - 2022-05-13 15:13:48 --> Config Class Initialized
INFO - 2022-05-13 15:13:48 --> Loader Class Initialized
INFO - 2022-05-13 15:13:48 --> Helper loaded: url_helper
INFO - 2022-05-13 15:13:48 --> Database Driver Class Initialized
INFO - 2022-05-13 15:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:13:48 --> Controller Class Initialized
DEBUG - 2022-05-13 15:13:48 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:13:48 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:13:48 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:13:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:13:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:13:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:13:48 --> Final output sent to browser
DEBUG - 2022-05-13 15:13:48 --> Total execution time: 0.0300
INFO - 2022-05-13 15:13:50 --> Config Class Initialized
INFO - 2022-05-13 15:13:50 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:13:50 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:13:50 --> Utf8 Class Initialized
INFO - 2022-05-13 15:13:50 --> URI Class Initialized
INFO - 2022-05-13 15:13:50 --> Router Class Initialized
INFO - 2022-05-13 15:13:50 --> Output Class Initialized
INFO - 2022-05-13 15:13:50 --> Security Class Initialized
DEBUG - 2022-05-13 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:13:50 --> Input Class Initialized
INFO - 2022-05-13 15:13:50 --> Language Class Initialized
INFO - 2022-05-13 15:13:50 --> Language Class Initialized
INFO - 2022-05-13 15:13:50 --> Config Class Initialized
INFO - 2022-05-13 15:13:50 --> Loader Class Initialized
INFO - 2022-05-13 15:13:50 --> Helper loaded: url_helper
INFO - 2022-05-13 15:13:50 --> Database Driver Class Initialized
INFO - 2022-05-13 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:13:50 --> Controller Class Initialized
DEBUG - 2022-05-13 15:13:50 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:13:50 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:13:50 --> Model Class Initialized
ERROR - 2022-05-13 15:13:50 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 84
INFO - 2022-05-13 15:13:50 --> Config Class Initialized
INFO - 2022-05-13 15:13:50 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:13:50 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:13:50 --> Utf8 Class Initialized
INFO - 2022-05-13 15:13:50 --> URI Class Initialized
INFO - 2022-05-13 15:13:50 --> Router Class Initialized
INFO - 2022-05-13 15:13:50 --> Output Class Initialized
INFO - 2022-05-13 15:13:50 --> Security Class Initialized
DEBUG - 2022-05-13 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:13:50 --> Input Class Initialized
INFO - 2022-05-13 15:13:50 --> Language Class Initialized
INFO - 2022-05-13 15:13:50 --> Language Class Initialized
INFO - 2022-05-13 15:13:50 --> Config Class Initialized
INFO - 2022-05-13 15:13:50 --> Loader Class Initialized
INFO - 2022-05-13 15:13:50 --> Helper loaded: url_helper
INFO - 2022-05-13 15:13:50 --> Database Driver Class Initialized
INFO - 2022-05-13 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:13:50 --> Controller Class Initialized
DEBUG - 2022-05-13 15:13:50 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:13:50 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:13:50 --> Model Class Initialized
DEBUG - 2022-05-13 15:13:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:13:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:13:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:13:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:13:50 --> Final output sent to browser
DEBUG - 2022-05-13 15:13:50 --> Total execution time: 0.0419
INFO - 2022-05-13 15:14:24 --> Config Class Initialized
INFO - 2022-05-13 15:14:24 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:14:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:14:24 --> Utf8 Class Initialized
INFO - 2022-05-13 15:14:24 --> URI Class Initialized
INFO - 2022-05-13 15:14:24 --> Router Class Initialized
INFO - 2022-05-13 15:14:24 --> Output Class Initialized
INFO - 2022-05-13 15:14:24 --> Security Class Initialized
DEBUG - 2022-05-13 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:14:24 --> Input Class Initialized
INFO - 2022-05-13 15:14:24 --> Language Class Initialized
INFO - 2022-05-13 15:14:24 --> Language Class Initialized
INFO - 2022-05-13 15:14:24 --> Config Class Initialized
INFO - 2022-05-13 15:14:24 --> Loader Class Initialized
INFO - 2022-05-13 15:14:24 --> Helper loaded: url_helper
INFO - 2022-05-13 15:14:24 --> Database Driver Class Initialized
INFO - 2022-05-13 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:14:24 --> Controller Class Initialized
DEBUG - 2022-05-13 15:14:24 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:14:24 --> Model Class Initialized
DEBUG - 2022-05-13 15:14:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:14:24 --> Model Class Initialized
DEBUG - 2022-05-13 15:14:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:14:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:14:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:14:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:14:24 --> Final output sent to browser
DEBUG - 2022-05-13 15:14:24 --> Total execution time: 0.0435
INFO - 2022-05-13 15:14:25 --> Config Class Initialized
INFO - 2022-05-13 15:14:25 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:14:25 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:14:25 --> Utf8 Class Initialized
INFO - 2022-05-13 15:14:25 --> URI Class Initialized
INFO - 2022-05-13 15:14:25 --> Router Class Initialized
INFO - 2022-05-13 15:14:25 --> Output Class Initialized
INFO - 2022-05-13 15:14:25 --> Security Class Initialized
DEBUG - 2022-05-13 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:14:25 --> Input Class Initialized
INFO - 2022-05-13 15:14:25 --> Language Class Initialized
INFO - 2022-05-13 15:14:25 --> Language Class Initialized
INFO - 2022-05-13 15:14:25 --> Config Class Initialized
INFO - 2022-05-13 15:14:25 --> Loader Class Initialized
INFO - 2022-05-13 15:14:25 --> Helper loaded: url_helper
INFO - 2022-05-13 15:14:25 --> Database Driver Class Initialized
INFO - 2022-05-13 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:14:25 --> Controller Class Initialized
DEBUG - 2022-05-13 15:14:25 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:14:25 --> Model Class Initialized
DEBUG - 2022-05-13 15:14:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:14:25 --> Model Class Initialized
DEBUG - 2022-05-13 15:14:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:14:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:14:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:14:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:14:25 --> Final output sent to browser
DEBUG - 2022-05-13 15:14:25 --> Total execution time: 0.0550
INFO - 2022-05-13 15:14:27 --> Config Class Initialized
INFO - 2022-05-13 15:14:27 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:14:27 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:14:27 --> Utf8 Class Initialized
INFO - 2022-05-13 15:14:27 --> URI Class Initialized
INFO - 2022-05-13 15:14:27 --> Router Class Initialized
INFO - 2022-05-13 15:14:27 --> Output Class Initialized
INFO - 2022-05-13 15:14:27 --> Security Class Initialized
DEBUG - 2022-05-13 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:14:27 --> Input Class Initialized
INFO - 2022-05-13 15:14:27 --> Language Class Initialized
INFO - 2022-05-13 15:14:27 --> Language Class Initialized
INFO - 2022-05-13 15:14:27 --> Config Class Initialized
INFO - 2022-05-13 15:14:27 --> Loader Class Initialized
INFO - 2022-05-13 15:14:27 --> Helper loaded: url_helper
INFO - 2022-05-13 15:14:27 --> Database Driver Class Initialized
INFO - 2022-05-13 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:14:27 --> Controller Class Initialized
DEBUG - 2022-05-13 15:14:27 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:14:27 --> Model Class Initialized
DEBUG - 2022-05-13 15:14:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:14:27 --> Model Class Initialized
INFO - 2022-05-13 15:15:25 --> Config Class Initialized
INFO - 2022-05-13 15:15:25 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:25 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:25 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:25 --> URI Class Initialized
INFO - 2022-05-13 15:15:25 --> Router Class Initialized
INFO - 2022-05-13 15:15:25 --> Output Class Initialized
INFO - 2022-05-13 15:15:25 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:25 --> Input Class Initialized
INFO - 2022-05-13 15:15:25 --> Language Class Initialized
INFO - 2022-05-13 15:15:25 --> Language Class Initialized
INFO - 2022-05-13 15:15:25 --> Config Class Initialized
INFO - 2022-05-13 15:15:25 --> Loader Class Initialized
INFO - 2022-05-13 15:15:25 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:25 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:25 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:25 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:25 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:25 --> Model Class Initialized
ERROR - 2022-05-13 15:15:25 --> Severity: Notice --> Undefined index: b_id C:\xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 84
INFO - 2022-05-13 15:15:25 --> Config Class Initialized
INFO - 2022-05-13 15:15:25 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:25 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:25 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:25 --> URI Class Initialized
INFO - 2022-05-13 15:15:25 --> Router Class Initialized
INFO - 2022-05-13 15:15:25 --> Output Class Initialized
INFO - 2022-05-13 15:15:25 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:25 --> Input Class Initialized
INFO - 2022-05-13 15:15:25 --> Language Class Initialized
INFO - 2022-05-13 15:15:25 --> Language Class Initialized
INFO - 2022-05-13 15:15:25 --> Config Class Initialized
INFO - 2022-05-13 15:15:25 --> Loader Class Initialized
INFO - 2022-05-13 15:15:25 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:25 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:25 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:25 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:25 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:25 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:15:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:15:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:15:25 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:15:25 --> Final output sent to browser
DEBUG - 2022-05-13 15:15:25 --> Total execution time: 0.0415
INFO - 2022-05-13 15:15:28 --> Config Class Initialized
INFO - 2022-05-13 15:15:28 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:28 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:28 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:28 --> URI Class Initialized
INFO - 2022-05-13 15:15:28 --> Router Class Initialized
INFO - 2022-05-13 15:15:28 --> Output Class Initialized
INFO - 2022-05-13 15:15:28 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:28 --> Input Class Initialized
INFO - 2022-05-13 15:15:28 --> Language Class Initialized
INFO - 2022-05-13 15:15:28 --> Language Class Initialized
INFO - 2022-05-13 15:15:28 --> Config Class Initialized
INFO - 2022-05-13 15:15:28 --> Loader Class Initialized
INFO - 2022-05-13 15:15:28 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:28 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:28 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:28 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:28 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:28 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:15:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:15:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:15:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:15:28 --> Final output sent to browser
DEBUG - 2022-05-13 15:15:28 --> Total execution time: 0.0419
INFO - 2022-05-13 15:15:29 --> Config Class Initialized
INFO - 2022-05-13 15:15:29 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:29 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:29 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:29 --> URI Class Initialized
INFO - 2022-05-13 15:15:29 --> Router Class Initialized
INFO - 2022-05-13 15:15:29 --> Output Class Initialized
INFO - 2022-05-13 15:15:29 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:29 --> Input Class Initialized
INFO - 2022-05-13 15:15:29 --> Language Class Initialized
INFO - 2022-05-13 15:15:29 --> Language Class Initialized
INFO - 2022-05-13 15:15:29 --> Config Class Initialized
INFO - 2022-05-13 15:15:29 --> Loader Class Initialized
INFO - 2022-05-13 15:15:29 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:29 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:29 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:29 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:29 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:29 --> Model Class Initialized
INFO - 2022-05-13 15:15:29 --> Config Class Initialized
INFO - 2022-05-13 15:15:29 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:29 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:29 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:29 --> URI Class Initialized
INFO - 2022-05-13 15:15:29 --> Router Class Initialized
INFO - 2022-05-13 15:15:29 --> Output Class Initialized
INFO - 2022-05-13 15:15:29 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:29 --> Input Class Initialized
INFO - 2022-05-13 15:15:29 --> Language Class Initialized
INFO - 2022-05-13 15:15:29 --> Language Class Initialized
INFO - 2022-05-13 15:15:29 --> Config Class Initialized
INFO - 2022-05-13 15:15:29 --> Loader Class Initialized
INFO - 2022-05-13 15:15:29 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:30 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:30 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:30 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:30 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:30 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:15:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:15:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:15:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:15:30 --> Final output sent to browser
DEBUG - 2022-05-13 15:15:30 --> Total execution time: 0.0304
INFO - 2022-05-13 15:15:36 --> Config Class Initialized
INFO - 2022-05-13 15:15:36 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:36 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:36 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:36 --> URI Class Initialized
INFO - 2022-05-13 15:15:36 --> Router Class Initialized
INFO - 2022-05-13 15:15:37 --> Output Class Initialized
INFO - 2022-05-13 15:15:37 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:37 --> Input Class Initialized
INFO - 2022-05-13 15:15:37 --> Language Class Initialized
INFO - 2022-05-13 15:15:37 --> Language Class Initialized
INFO - 2022-05-13 15:15:37 --> Config Class Initialized
INFO - 2022-05-13 15:15:37 --> Loader Class Initialized
INFO - 2022-05-13 15:15:37 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:37 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:37 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:37 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:37 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:37 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:15:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:15:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:15:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:15:37 --> Final output sent to browser
DEBUG - 2022-05-13 15:15:37 --> Total execution time: 0.0490
INFO - 2022-05-13 15:15:41 --> Config Class Initialized
INFO - 2022-05-13 15:15:41 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:15:41 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:15:41 --> Utf8 Class Initialized
INFO - 2022-05-13 15:15:41 --> URI Class Initialized
INFO - 2022-05-13 15:15:41 --> Router Class Initialized
INFO - 2022-05-13 15:15:41 --> Output Class Initialized
INFO - 2022-05-13 15:15:41 --> Security Class Initialized
DEBUG - 2022-05-13 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:15:41 --> Input Class Initialized
INFO - 2022-05-13 15:15:41 --> Language Class Initialized
INFO - 2022-05-13 15:15:41 --> Language Class Initialized
INFO - 2022-05-13 15:15:41 --> Config Class Initialized
INFO - 2022-05-13 15:15:41 --> Loader Class Initialized
INFO - 2022-05-13 15:15:41 --> Helper loaded: url_helper
INFO - 2022-05-13 15:15:41 --> Database Driver Class Initialized
INFO - 2022-05-13 15:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:15:41 --> Controller Class Initialized
DEBUG - 2022-05-13 15:15:41 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:15:41 --> Model Class Initialized
DEBUG - 2022-05-13 15:15:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:15:41 --> Model Class Initialized
INFO - 2022-05-13 15:15:41 --> Upload Class Initialized
ERROR - 2022-05-13 15:15:41 --> Query error: Unknown column 'logo' in 'field list' - Invalid query: UPDATE `brand` SET `b_id` = '3', `b_name` = 'brand 3a', `logo` = '13May20226868.png'
WHERE `b_id` = '3'
INFO - 2022-05-13 15:15:41 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-13 15:16:05 --> Config Class Initialized
INFO - 2022-05-13 15:16:05 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:05 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:05 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:05 --> URI Class Initialized
INFO - 2022-05-13 15:16:05 --> Router Class Initialized
INFO - 2022-05-13 15:16:05 --> Output Class Initialized
INFO - 2022-05-13 15:16:05 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:05 --> Input Class Initialized
INFO - 2022-05-13 15:16:05 --> Language Class Initialized
INFO - 2022-05-13 15:16:05 --> Language Class Initialized
INFO - 2022-05-13 15:16:05 --> Config Class Initialized
INFO - 2022-05-13 15:16:05 --> Loader Class Initialized
INFO - 2022-05-13 15:16:05 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:05 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:05 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:05 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:05 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:05 --> Model Class Initialized
INFO - 2022-05-13 15:16:05 --> Upload Class Initialized
INFO - 2022-05-13 15:16:05 --> Config Class Initialized
INFO - 2022-05-13 15:16:05 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:05 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:05 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:05 --> URI Class Initialized
INFO - 2022-05-13 15:16:05 --> Router Class Initialized
INFO - 2022-05-13 15:16:05 --> Output Class Initialized
INFO - 2022-05-13 15:16:05 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:05 --> Input Class Initialized
INFO - 2022-05-13 15:16:05 --> Language Class Initialized
INFO - 2022-05-13 15:16:05 --> Language Class Initialized
INFO - 2022-05-13 15:16:05 --> Config Class Initialized
INFO - 2022-05-13 15:16:05 --> Loader Class Initialized
INFO - 2022-05-13 15:16:05 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:05 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:05 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:05 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:05 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:05 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:16:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:16:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:16:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:16:05 --> Final output sent to browser
DEBUG - 2022-05-13 15:16:05 --> Total execution time: 0.0532
INFO - 2022-05-13 15:16:08 --> Config Class Initialized
INFO - 2022-05-13 15:16:08 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:08 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:08 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:08 --> URI Class Initialized
INFO - 2022-05-13 15:16:08 --> Router Class Initialized
INFO - 2022-05-13 15:16:08 --> Output Class Initialized
INFO - 2022-05-13 15:16:08 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:08 --> Input Class Initialized
INFO - 2022-05-13 15:16:08 --> Language Class Initialized
INFO - 2022-05-13 15:16:08 --> Language Class Initialized
INFO - 2022-05-13 15:16:08 --> Config Class Initialized
INFO - 2022-05-13 15:16:08 --> Loader Class Initialized
INFO - 2022-05-13 15:16:08 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:08 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:08 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:08 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:08 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:08 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:16:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:16:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:16:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:16:08 --> Final output sent to browser
DEBUG - 2022-05-13 15:16:08 --> Total execution time: 0.0389
INFO - 2022-05-13 15:16:13 --> Config Class Initialized
INFO - 2022-05-13 15:16:13 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:13 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:13 --> URI Class Initialized
INFO - 2022-05-13 15:16:13 --> Router Class Initialized
INFO - 2022-05-13 15:16:13 --> Output Class Initialized
INFO - 2022-05-13 15:16:13 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:13 --> Input Class Initialized
INFO - 2022-05-13 15:16:13 --> Language Class Initialized
INFO - 2022-05-13 15:16:13 --> Language Class Initialized
INFO - 2022-05-13 15:16:13 --> Config Class Initialized
INFO - 2022-05-13 15:16:13 --> Loader Class Initialized
INFO - 2022-05-13 15:16:13 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:13 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:13 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:13 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:13 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:13 --> Model Class Initialized
INFO - 2022-05-13 15:16:13 --> Upload Class Initialized
INFO - 2022-05-13 15:16:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-05-13 15:16:13 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2022-05-13 15:16:13 --> Config Class Initialized
INFO - 2022-05-13 15:16:13 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:13 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:13 --> URI Class Initialized
INFO - 2022-05-13 15:16:13 --> Router Class Initialized
INFO - 2022-05-13 15:16:13 --> Output Class Initialized
INFO - 2022-05-13 15:16:13 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:13 --> Input Class Initialized
INFO - 2022-05-13 15:16:13 --> Language Class Initialized
INFO - 2022-05-13 15:16:13 --> Language Class Initialized
INFO - 2022-05-13 15:16:13 --> Config Class Initialized
INFO - 2022-05-13 15:16:13 --> Loader Class Initialized
INFO - 2022-05-13 15:16:13 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:13 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:13 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:13 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:13 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:13 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:16:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:16:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:16:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:16:13 --> Final output sent to browser
DEBUG - 2022-05-13 15:16:13 --> Total execution time: 0.0475
INFO - 2022-05-13 15:16:13 --> Config Class Initialized
INFO - 2022-05-13 15:16:13 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:13 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:13 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:13 --> URI Class Initialized
INFO - 2022-05-13 15:16:13 --> Router Class Initialized
INFO - 2022-05-13 15:16:13 --> Output Class Initialized
INFO - 2022-05-13 15:16:13 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:13 --> Input Class Initialized
INFO - 2022-05-13 15:16:13 --> Language Class Initialized
ERROR - 2022-05-13 15:16:13 --> 404 Page Not Found: /index
INFO - 2022-05-13 15:16:43 --> Config Class Initialized
INFO - 2022-05-13 15:16:43 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:43 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:43 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:43 --> URI Class Initialized
INFO - 2022-05-13 15:16:43 --> Router Class Initialized
INFO - 2022-05-13 15:16:43 --> Output Class Initialized
INFO - 2022-05-13 15:16:43 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:43 --> Input Class Initialized
INFO - 2022-05-13 15:16:43 --> Language Class Initialized
INFO - 2022-05-13 15:16:43 --> Language Class Initialized
INFO - 2022-05-13 15:16:43 --> Config Class Initialized
INFO - 2022-05-13 15:16:43 --> Loader Class Initialized
INFO - 2022-05-13 15:16:43 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:44 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:44 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:44 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:44 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:44 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:16:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:16:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:16:44 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:16:44 --> Final output sent to browser
DEBUG - 2022-05-13 15:16:44 --> Total execution time: 0.0417
INFO - 2022-05-13 15:16:52 --> Config Class Initialized
INFO - 2022-05-13 15:16:52 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:16:52 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:16:52 --> Utf8 Class Initialized
INFO - 2022-05-13 15:16:52 --> URI Class Initialized
INFO - 2022-05-13 15:16:52 --> Router Class Initialized
INFO - 2022-05-13 15:16:52 --> Output Class Initialized
INFO - 2022-05-13 15:16:52 --> Security Class Initialized
DEBUG - 2022-05-13 15:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:16:52 --> Input Class Initialized
INFO - 2022-05-13 15:16:52 --> Language Class Initialized
INFO - 2022-05-13 15:16:52 --> Language Class Initialized
INFO - 2022-05-13 15:16:52 --> Config Class Initialized
INFO - 2022-05-13 15:16:52 --> Loader Class Initialized
INFO - 2022-05-13 15:16:52 --> Helper loaded: url_helper
INFO - 2022-05-13 15:16:52 --> Database Driver Class Initialized
INFO - 2022-05-13 15:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:16:52 --> Controller Class Initialized
DEBUG - 2022-05-13 15:16:52 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:16:52 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:16:52 --> Model Class Initialized
DEBUG - 2022-05-13 15:16:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:16:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:16:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:16:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:16:52 --> Final output sent to browser
DEBUG - 2022-05-13 15:16:52 --> Total execution time: 0.0300
INFO - 2022-05-13 15:17:07 --> Config Class Initialized
INFO - 2022-05-13 15:17:07 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:07 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:07 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:07 --> URI Class Initialized
INFO - 2022-05-13 15:17:07 --> Router Class Initialized
INFO - 2022-05-13 15:17:07 --> Output Class Initialized
INFO - 2022-05-13 15:17:07 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:07 --> Input Class Initialized
INFO - 2022-05-13 15:17:07 --> Language Class Initialized
INFO - 2022-05-13 15:17:07 --> Language Class Initialized
INFO - 2022-05-13 15:17:07 --> Config Class Initialized
INFO - 2022-05-13 15:17:07 --> Loader Class Initialized
INFO - 2022-05-13 15:17:07 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:07 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:07 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:07 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:07 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:07 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:07 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:07 --> Total execution time: 0.0296
INFO - 2022-05-13 15:17:10 --> Config Class Initialized
INFO - 2022-05-13 15:17:10 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:10 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:10 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:10 --> URI Class Initialized
INFO - 2022-05-13 15:17:10 --> Router Class Initialized
INFO - 2022-05-13 15:17:10 --> Output Class Initialized
INFO - 2022-05-13 15:17:10 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:10 --> Input Class Initialized
INFO - 2022-05-13 15:17:10 --> Language Class Initialized
INFO - 2022-05-13 15:17:10 --> Language Class Initialized
INFO - 2022-05-13 15:17:10 --> Config Class Initialized
INFO - 2022-05-13 15:17:10 --> Loader Class Initialized
INFO - 2022-05-13 15:17:10 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:10 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:10 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:10 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:10 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:10 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:10 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:10 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:10 --> Total execution time: 0.0378
INFO - 2022-05-13 15:17:24 --> Config Class Initialized
INFO - 2022-05-13 15:17:24 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:24 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:24 --> URI Class Initialized
INFO - 2022-05-13 15:17:24 --> Router Class Initialized
INFO - 2022-05-13 15:17:24 --> Output Class Initialized
INFO - 2022-05-13 15:17:24 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:24 --> Input Class Initialized
INFO - 2022-05-13 15:17:24 --> Language Class Initialized
INFO - 2022-05-13 15:17:24 --> Language Class Initialized
INFO - 2022-05-13 15:17:24 --> Config Class Initialized
INFO - 2022-05-13 15:17:24 --> Loader Class Initialized
INFO - 2022-05-13 15:17:24 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:24 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:24 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:24 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:24 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:24 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:17:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:24 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:24 --> Total execution time: 0.0501
INFO - 2022-05-13 15:17:24 --> Config Class Initialized
INFO - 2022-05-13 15:17:24 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:24 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:24 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:24 --> URI Class Initialized
INFO - 2022-05-13 15:17:24 --> Router Class Initialized
INFO - 2022-05-13 15:17:24 --> Output Class Initialized
INFO - 2022-05-13 15:17:24 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:24 --> Input Class Initialized
INFO - 2022-05-13 15:17:24 --> Language Class Initialized
ERROR - 2022-05-13 15:17:24 --> 404 Page Not Found: /index
INFO - 2022-05-13 15:17:26 --> Config Class Initialized
INFO - 2022-05-13 15:17:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:26 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:26 --> URI Class Initialized
INFO - 2022-05-13 15:17:26 --> Router Class Initialized
INFO - 2022-05-13 15:17:26 --> Output Class Initialized
INFO - 2022-05-13 15:17:26 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:26 --> Input Class Initialized
INFO - 2022-05-13 15:17:26 --> Language Class Initialized
INFO - 2022-05-13 15:17:26 --> Language Class Initialized
INFO - 2022-05-13 15:17:26 --> Config Class Initialized
INFO - 2022-05-13 15:17:26 --> Loader Class Initialized
INFO - 2022-05-13 15:17:26 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:26 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:26 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:26 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:26 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:26 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:26 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:26 --> Total execution time: 0.0403
INFO - 2022-05-13 15:17:28 --> Config Class Initialized
INFO - 2022-05-13 15:17:28 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:28 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:28 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:28 --> URI Class Initialized
INFO - 2022-05-13 15:17:28 --> Router Class Initialized
INFO - 2022-05-13 15:17:28 --> Output Class Initialized
INFO - 2022-05-13 15:17:28 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:28 --> Input Class Initialized
INFO - 2022-05-13 15:17:28 --> Language Class Initialized
INFO - 2022-05-13 15:17:28 --> Language Class Initialized
INFO - 2022-05-13 15:17:28 --> Config Class Initialized
INFO - 2022-05-13 15:17:28 --> Loader Class Initialized
INFO - 2022-05-13 15:17:28 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:28 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:28 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:28 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:28 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:28 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:17:28 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:28 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:28 --> Total execution time: 0.0517
INFO - 2022-05-13 15:17:29 --> Config Class Initialized
INFO - 2022-05-13 15:17:29 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:29 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:29 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:29 --> URI Class Initialized
INFO - 2022-05-13 15:17:29 --> Router Class Initialized
INFO - 2022-05-13 15:17:29 --> Output Class Initialized
INFO - 2022-05-13 15:17:29 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:29 --> Input Class Initialized
INFO - 2022-05-13 15:17:29 --> Language Class Initialized
INFO - 2022-05-13 15:17:29 --> Language Class Initialized
INFO - 2022-05-13 15:17:29 --> Config Class Initialized
INFO - 2022-05-13 15:17:29 --> Loader Class Initialized
INFO - 2022-05-13 15:17:29 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:29 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:29 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:29 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:29 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:29 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:29 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:29 --> Total execution time: 0.0430
INFO - 2022-05-13 15:17:33 --> Config Class Initialized
INFO - 2022-05-13 15:17:33 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:33 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:33 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:33 --> URI Class Initialized
INFO - 2022-05-13 15:17:33 --> Router Class Initialized
INFO - 2022-05-13 15:17:33 --> Output Class Initialized
INFO - 2022-05-13 15:17:33 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:33 --> Input Class Initialized
INFO - 2022-05-13 15:17:33 --> Language Class Initialized
INFO - 2022-05-13 15:17:33 --> Language Class Initialized
INFO - 2022-05-13 15:17:33 --> Config Class Initialized
INFO - 2022-05-13 15:17:33 --> Loader Class Initialized
INFO - 2022-05-13 15:17:33 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:33 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:33 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:33 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:33 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:33 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:33 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:33 --> Total execution time: 0.0290
INFO - 2022-05-13 15:17:34 --> Config Class Initialized
INFO - 2022-05-13 15:17:34 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:34 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:34 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:34 --> URI Class Initialized
INFO - 2022-05-13 15:17:34 --> Router Class Initialized
INFO - 2022-05-13 15:17:34 --> Output Class Initialized
INFO - 2022-05-13 15:17:34 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:34 --> Input Class Initialized
INFO - 2022-05-13 15:17:34 --> Language Class Initialized
INFO - 2022-05-13 15:17:34 --> Language Class Initialized
INFO - 2022-05-13 15:17:34 --> Config Class Initialized
INFO - 2022-05-13 15:17:34 --> Loader Class Initialized
INFO - 2022-05-13 15:17:34 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:34 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:34 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:34 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:34 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:34 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:34 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:34 --> Total execution time: 0.0508
INFO - 2022-05-13 15:17:37 --> Config Class Initialized
INFO - 2022-05-13 15:17:37 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:37 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:37 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:37 --> URI Class Initialized
INFO - 2022-05-13 15:17:37 --> Router Class Initialized
INFO - 2022-05-13 15:17:37 --> Output Class Initialized
INFO - 2022-05-13 15:17:37 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:37 --> Input Class Initialized
INFO - 2022-05-13 15:17:37 --> Language Class Initialized
INFO - 2022-05-13 15:17:37 --> Language Class Initialized
INFO - 2022-05-13 15:17:37 --> Config Class Initialized
INFO - 2022-05-13 15:17:37 --> Loader Class Initialized
INFO - 2022-05-13 15:17:37 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:37 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:37 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:37 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:37 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:37 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:17:37 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:37 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:37 --> Total execution time: 0.0496
INFO - 2022-05-13 15:17:38 --> Config Class Initialized
INFO - 2022-05-13 15:17:38 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:17:38 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:17:38 --> Utf8 Class Initialized
INFO - 2022-05-13 15:17:38 --> URI Class Initialized
INFO - 2022-05-13 15:17:38 --> Router Class Initialized
INFO - 2022-05-13 15:17:38 --> Output Class Initialized
INFO - 2022-05-13 15:17:38 --> Security Class Initialized
DEBUG - 2022-05-13 15:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:17:38 --> Input Class Initialized
INFO - 2022-05-13 15:17:38 --> Language Class Initialized
INFO - 2022-05-13 15:17:38 --> Language Class Initialized
INFO - 2022-05-13 15:17:38 --> Config Class Initialized
INFO - 2022-05-13 15:17:38 --> Loader Class Initialized
INFO - 2022-05-13 15:17:38 --> Helper loaded: url_helper
INFO - 2022-05-13 15:17:38 --> Database Driver Class Initialized
INFO - 2022-05-13 15:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:17:38 --> Controller Class Initialized
DEBUG - 2022-05-13 15:17:38 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:17:38 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:17:38 --> Model Class Initialized
DEBUG - 2022-05-13 15:17:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:17:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:17:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:17:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:17:38 --> Final output sent to browser
DEBUG - 2022-05-13 15:17:38 --> Total execution time: 0.0507
INFO - 2022-05-13 15:18:20 --> Config Class Initialized
INFO - 2022-05-13 15:18:20 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:18:20 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:18:20 --> Utf8 Class Initialized
INFO - 2022-05-13 15:18:20 --> URI Class Initialized
INFO - 2022-05-13 15:18:20 --> Router Class Initialized
INFO - 2022-05-13 15:18:20 --> Output Class Initialized
INFO - 2022-05-13 15:18:20 --> Security Class Initialized
DEBUG - 2022-05-13 15:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:18:20 --> Input Class Initialized
INFO - 2022-05-13 15:18:20 --> Language Class Initialized
INFO - 2022-05-13 15:18:20 --> Language Class Initialized
INFO - 2022-05-13 15:18:20 --> Config Class Initialized
INFO - 2022-05-13 15:18:20 --> Loader Class Initialized
INFO - 2022-05-13 15:18:20 --> Helper loaded: url_helper
INFO - 2022-05-13 15:18:20 --> Database Driver Class Initialized
INFO - 2022-05-13 15:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:18:20 --> Controller Class Initialized
DEBUG - 2022-05-13 15:18:20 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:18:20 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:18:20 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:18:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:18:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:18:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:18:20 --> Final output sent to browser
DEBUG - 2022-05-13 15:18:20 --> Total execution time: 0.0431
INFO - 2022-05-13 15:18:34 --> Config Class Initialized
INFO - 2022-05-13 15:18:34 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:18:34 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:18:34 --> Utf8 Class Initialized
INFO - 2022-05-13 15:18:34 --> URI Class Initialized
INFO - 2022-05-13 15:18:34 --> Router Class Initialized
INFO - 2022-05-13 15:18:34 --> Output Class Initialized
INFO - 2022-05-13 15:18:34 --> Security Class Initialized
DEBUG - 2022-05-13 15:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:18:34 --> Input Class Initialized
INFO - 2022-05-13 15:18:34 --> Language Class Initialized
INFO - 2022-05-13 15:18:34 --> Language Class Initialized
INFO - 2022-05-13 15:18:34 --> Config Class Initialized
INFO - 2022-05-13 15:18:34 --> Loader Class Initialized
INFO - 2022-05-13 15:18:34 --> Helper loaded: url_helper
INFO - 2022-05-13 15:18:34 --> Database Driver Class Initialized
INFO - 2022-05-13 15:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:18:34 --> Controller Class Initialized
DEBUG - 2022-05-13 15:18:34 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:18:34 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:18:34 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:18:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:18:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:18:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:18:34 --> Final output sent to browser
DEBUG - 2022-05-13 15:18:34 --> Total execution time: 0.0433
INFO - 2022-05-13 15:18:36 --> Config Class Initialized
INFO - 2022-05-13 15:18:36 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:18:36 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:18:36 --> Utf8 Class Initialized
INFO - 2022-05-13 15:18:36 --> URI Class Initialized
INFO - 2022-05-13 15:18:36 --> Router Class Initialized
INFO - 2022-05-13 15:18:36 --> Output Class Initialized
INFO - 2022-05-13 15:18:36 --> Security Class Initialized
DEBUG - 2022-05-13 15:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:18:36 --> Input Class Initialized
INFO - 2022-05-13 15:18:36 --> Language Class Initialized
INFO - 2022-05-13 15:18:36 --> Language Class Initialized
INFO - 2022-05-13 15:18:36 --> Config Class Initialized
INFO - 2022-05-13 15:18:36 --> Loader Class Initialized
INFO - 2022-05-13 15:18:36 --> Helper loaded: url_helper
INFO - 2022-05-13 15:18:36 --> Database Driver Class Initialized
INFO - 2022-05-13 15:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:18:36 --> Controller Class Initialized
DEBUG - 2022-05-13 15:18:36 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:18:36 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:18:36 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:18:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:18:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:18:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:18:36 --> Final output sent to browser
DEBUG - 2022-05-13 15:18:36 --> Total execution time: 0.0414
INFO - 2022-05-13 15:18:56 --> Config Class Initialized
INFO - 2022-05-13 15:18:56 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:18:56 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:18:56 --> Utf8 Class Initialized
INFO - 2022-05-13 15:18:56 --> URI Class Initialized
INFO - 2022-05-13 15:18:56 --> Router Class Initialized
INFO - 2022-05-13 15:18:56 --> Output Class Initialized
INFO - 2022-05-13 15:18:56 --> Security Class Initialized
DEBUG - 2022-05-13 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:18:56 --> Input Class Initialized
INFO - 2022-05-13 15:18:56 --> Language Class Initialized
INFO - 2022-05-13 15:18:56 --> Language Class Initialized
INFO - 2022-05-13 15:18:56 --> Config Class Initialized
INFO - 2022-05-13 15:18:56 --> Loader Class Initialized
INFO - 2022-05-13 15:18:56 --> Helper loaded: url_helper
INFO - 2022-05-13 15:18:56 --> Database Driver Class Initialized
INFO - 2022-05-13 15:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:18:56 --> Controller Class Initialized
DEBUG - 2022-05-13 15:18:56 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:18:56 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:18:56 --> Model Class Initialized
DEBUG - 2022-05-13 15:18:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:18:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:18:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:18:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:18:56 --> Final output sent to browser
DEBUG - 2022-05-13 15:18:56 --> Total execution time: 0.0542
INFO - 2022-05-13 15:20:15 --> Config Class Initialized
INFO - 2022-05-13 15:20:15 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:20:15 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:20:15 --> Utf8 Class Initialized
INFO - 2022-05-13 15:20:15 --> URI Class Initialized
INFO - 2022-05-13 15:20:15 --> Router Class Initialized
INFO - 2022-05-13 15:20:15 --> Output Class Initialized
INFO - 2022-05-13 15:20:15 --> Security Class Initialized
DEBUG - 2022-05-13 15:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:20:15 --> Input Class Initialized
INFO - 2022-05-13 15:20:15 --> Language Class Initialized
INFO - 2022-05-13 15:20:15 --> Language Class Initialized
INFO - 2022-05-13 15:20:15 --> Config Class Initialized
INFO - 2022-05-13 15:20:15 --> Loader Class Initialized
INFO - 2022-05-13 15:20:15 --> Helper loaded: url_helper
INFO - 2022-05-13 15:20:15 --> Database Driver Class Initialized
INFO - 2022-05-13 15:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:20:15 --> Controller Class Initialized
DEBUG - 2022-05-13 15:20:15 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:20:15 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:20:15 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:20:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:20:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:20:15 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:20:15 --> Final output sent to browser
DEBUG - 2022-05-13 15:20:15 --> Total execution time: 0.0385
INFO - 2022-05-13 15:20:19 --> Config Class Initialized
INFO - 2022-05-13 15:20:19 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:20:19 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:20:19 --> Utf8 Class Initialized
INFO - 2022-05-13 15:20:19 --> URI Class Initialized
INFO - 2022-05-13 15:20:19 --> Router Class Initialized
INFO - 2022-05-13 15:20:19 --> Output Class Initialized
INFO - 2022-05-13 15:20:19 --> Security Class Initialized
DEBUG - 2022-05-13 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:20:19 --> Input Class Initialized
INFO - 2022-05-13 15:20:19 --> Language Class Initialized
INFO - 2022-05-13 15:20:19 --> Language Class Initialized
INFO - 2022-05-13 15:20:19 --> Config Class Initialized
INFO - 2022-05-13 15:20:19 --> Loader Class Initialized
INFO - 2022-05-13 15:20:19 --> Helper loaded: url_helper
INFO - 2022-05-13 15:20:19 --> Database Driver Class Initialized
INFO - 2022-05-13 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:20:19 --> Controller Class Initialized
DEBUG - 2022-05-13 15:20:19 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:20:19 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:20:19 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-13 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:20:19 --> Final output sent to browser
DEBUG - 2022-05-13 15:20:19 --> Total execution time: 0.0509
INFO - 2022-05-13 15:20:20 --> Config Class Initialized
INFO - 2022-05-13 15:20:20 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:20:20 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:20:20 --> Utf8 Class Initialized
INFO - 2022-05-13 15:20:20 --> URI Class Initialized
INFO - 2022-05-13 15:20:20 --> Router Class Initialized
INFO - 2022-05-13 15:20:20 --> Output Class Initialized
INFO - 2022-05-13 15:20:20 --> Security Class Initialized
DEBUG - 2022-05-13 15:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:20:20 --> Input Class Initialized
INFO - 2022-05-13 15:20:20 --> Language Class Initialized
INFO - 2022-05-13 15:20:20 --> Language Class Initialized
INFO - 2022-05-13 15:20:20 --> Config Class Initialized
INFO - 2022-05-13 15:20:20 --> Loader Class Initialized
INFO - 2022-05-13 15:20:20 --> Helper loaded: url_helper
INFO - 2022-05-13 15:20:20 --> Database Driver Class Initialized
INFO - 2022-05-13 15:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:20:20 --> Controller Class Initialized
DEBUG - 2022-05-13 15:20:20 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:20:20 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:20:20 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:20:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:20:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:20:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:20:20 --> Final output sent to browser
DEBUG - 2022-05-13 15:20:20 --> Total execution time: 0.0425
INFO - 2022-05-13 15:20:26 --> Config Class Initialized
INFO - 2022-05-13 15:20:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:20:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:20:26 --> Utf8 Class Initialized
INFO - 2022-05-13 15:20:26 --> URI Class Initialized
INFO - 2022-05-13 15:20:26 --> Router Class Initialized
INFO - 2022-05-13 15:20:26 --> Output Class Initialized
INFO - 2022-05-13 15:20:26 --> Security Class Initialized
DEBUG - 2022-05-13 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:20:26 --> Input Class Initialized
INFO - 2022-05-13 15:20:26 --> Language Class Initialized
INFO - 2022-05-13 15:20:26 --> Language Class Initialized
INFO - 2022-05-13 15:20:26 --> Config Class Initialized
INFO - 2022-05-13 15:20:26 --> Loader Class Initialized
INFO - 2022-05-13 15:20:26 --> Helper loaded: url_helper
INFO - 2022-05-13 15:20:26 --> Database Driver Class Initialized
INFO - 2022-05-13 15:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:20:26 --> Controller Class Initialized
DEBUG - 2022-05-13 15:20:26 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:20:26 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:20:26 --> Model Class Initialized
DEBUG - 2022-05-13 15:20:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:20:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:20:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:20:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:20:26 --> Final output sent to browser
DEBUG - 2022-05-13 15:20:26 --> Total execution time: 0.0512
INFO - 2022-05-13 15:21:26 --> Config Class Initialized
INFO - 2022-05-13 15:21:26 --> Hooks Class Initialized
DEBUG - 2022-05-13 15:21:26 --> UTF-8 Support Enabled
INFO - 2022-05-13 15:21:26 --> Utf8 Class Initialized
INFO - 2022-05-13 15:21:26 --> URI Class Initialized
INFO - 2022-05-13 15:21:26 --> Router Class Initialized
INFO - 2022-05-13 15:21:26 --> Output Class Initialized
INFO - 2022-05-13 15:21:26 --> Security Class Initialized
DEBUG - 2022-05-13 15:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-13 15:21:26 --> Input Class Initialized
INFO - 2022-05-13 15:21:26 --> Language Class Initialized
INFO - 2022-05-13 15:21:26 --> Language Class Initialized
INFO - 2022-05-13 15:21:26 --> Config Class Initialized
INFO - 2022-05-13 15:21:26 --> Loader Class Initialized
INFO - 2022-05-13 15:21:26 --> Helper loaded: url_helper
INFO - 2022-05-13 15:21:26 --> Database Driver Class Initialized
INFO - 2022-05-13 15:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-13 15:21:26 --> Controller Class Initialized
DEBUG - 2022-05-13 15:21:26 --> Admin MX_Controller Initialized
INFO - 2022-05-13 15:21:26 --> Model Class Initialized
DEBUG - 2022-05-13 15:21:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-13 15:21:26 --> Model Class Initialized
DEBUG - 2022-05-13 15:21:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-13 15:21:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-13 15:21:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/edit_brand.php
DEBUG - 2022-05-13 15:21:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-13 15:21:26 --> Final output sent to browser
DEBUG - 2022-05-13 15:21:26 --> Total execution time: 0.0443
