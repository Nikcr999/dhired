<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-07 18:02:34 --> Config Class Initialized
INFO - 2022-06-07 18:02:34 --> Hooks Class Initialized
DEBUG - 2022-06-07 18:02:34 --> UTF-8 Support Enabled
INFO - 2022-06-07 18:02:34 --> Utf8 Class Initialized
INFO - 2022-06-07 18:02:34 --> URI Class Initialized
DEBUG - 2022-06-07 18:02:34 --> No URI present. Default controller set.
INFO - 2022-06-07 18:02:34 --> Router Class Initialized
INFO - 2022-06-07 18:02:34 --> Output Class Initialized
INFO - 2022-06-07 18:02:34 --> Security Class Initialized
DEBUG - 2022-06-07 18:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-07 18:02:34 --> Input Class Initialized
INFO - 2022-06-07 18:02:34 --> Language Class Initialized
INFO - 2022-06-07 18:02:34 --> Language Class Initialized
INFO - 2022-06-07 18:02:34 --> Config Class Initialized
INFO - 2022-06-07 18:02:34 --> Loader Class Initialized
INFO - 2022-06-07 18:02:34 --> Helper loaded: url_helper
INFO - 2022-06-07 18:02:34 --> Database Driver Class Initialized
INFO - 2022-06-07 18:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-07 18:02:35 --> Model Class Initialized
DEBUG - 2022-06-07 18:02:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-07 18:02:35 --> Model Class Initialized
INFO - 2022-06-07 18:02:35 --> Controller Class Initialized
DEBUG - 2022-06-07 18:02:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-07 18:02:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-07 18:02:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-07 18:02:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-07 18:02:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-07 18:02:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-07 18:02:35 --> Final output sent to browser
DEBUG - 2022-06-07 18:02:35 --> Total execution time: 0.1543
