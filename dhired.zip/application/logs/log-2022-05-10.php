<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-10 07:01:08 --> Config Class Initialized
INFO - 2022-05-10 07:01:08 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:01:08 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:01:08 --> Utf8 Class Initialized
INFO - 2022-05-10 07:01:08 --> URI Class Initialized
INFO - 2022-05-10 07:01:08 --> Router Class Initialized
INFO - 2022-05-10 07:01:08 --> Output Class Initialized
INFO - 2022-05-10 07:01:08 --> Security Class Initialized
DEBUG - 2022-05-10 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:01:08 --> Input Class Initialized
INFO - 2022-05-10 07:01:08 --> Language Class Initialized
INFO - 2022-05-10 07:01:08 --> Language Class Initialized
INFO - 2022-05-10 07:01:08 --> Config Class Initialized
INFO - 2022-05-10 07:01:08 --> Loader Class Initialized
INFO - 2022-05-10 07:01:09 --> Helper loaded: url_helper
INFO - 2022-05-10 07:01:09 --> Database Driver Class Initialized
ERROR - 2022-05-10 07:01:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'motodeal' C:\xampp\htdocs\motodeal\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2022-05-10 07:01:09 --> Unable to connect to the database
INFO - 2022-05-10 07:01:09 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 07:01:41 --> Config Class Initialized
INFO - 2022-05-10 07:01:41 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:01:41 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:01:41 --> Utf8 Class Initialized
INFO - 2022-05-10 07:01:41 --> URI Class Initialized
INFO - 2022-05-10 07:01:41 --> Router Class Initialized
INFO - 2022-05-10 07:01:41 --> Output Class Initialized
INFO - 2022-05-10 07:01:41 --> Security Class Initialized
DEBUG - 2022-05-10 07:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:01:41 --> Input Class Initialized
INFO - 2022-05-10 07:01:41 --> Language Class Initialized
INFO - 2022-05-10 07:01:41 --> Language Class Initialized
INFO - 2022-05-10 07:01:41 --> Config Class Initialized
INFO - 2022-05-10 07:01:41 --> Loader Class Initialized
INFO - 2022-05-10 07:01:41 --> Helper loaded: url_helper
INFO - 2022-05-10 07:01:41 --> Database Driver Class Initialized
INFO - 2022-05-10 07:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:01:41 --> Controller Class Initialized
DEBUG - 2022-05-10 07:01:41 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:01:41 --> Model Class Initialized
DEBUG - 2022-05-10 07:01:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:01:41 --> Model Class Initialized
DEBUG - 2022-05-10 07:01:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:01:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:01:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 07:01:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:01:41 --> Final output sent to browser
DEBUG - 2022-05-10 07:01:41 --> Total execution time: 0.1091
INFO - 2022-05-10 07:01:43 --> Config Class Initialized
INFO - 2022-05-10 07:01:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:01:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:01:43 --> Utf8 Class Initialized
INFO - 2022-05-10 07:01:43 --> URI Class Initialized
INFO - 2022-05-10 07:01:43 --> Router Class Initialized
INFO - 2022-05-10 07:01:43 --> Output Class Initialized
INFO - 2022-05-10 07:01:43 --> Security Class Initialized
DEBUG - 2022-05-10 07:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:01:43 --> Input Class Initialized
INFO - 2022-05-10 07:01:43 --> Language Class Initialized
INFO - 2022-05-10 07:01:43 --> Language Class Initialized
INFO - 2022-05-10 07:01:43 --> Config Class Initialized
INFO - 2022-05-10 07:01:43 --> Loader Class Initialized
INFO - 2022-05-10 07:01:43 --> Helper loaded: url_helper
INFO - 2022-05-10 07:01:43 --> Database Driver Class Initialized
INFO - 2022-05-10 07:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:01:43 --> Controller Class Initialized
DEBUG - 2022-05-10 07:01:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:01:43 --> Model Class Initialized
DEBUG - 2022-05-10 07:01:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:01:43 --> Model Class Initialized
DEBUG - 2022-05-10 07:01:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:01:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:01:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:01:43 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:01:43 --> Final output sent to browser
DEBUG - 2022-05-10 07:01:43 --> Total execution time: 0.0696
INFO - 2022-05-10 07:02:52 --> Config Class Initialized
INFO - 2022-05-10 07:02:52 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:02:52 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:02:52 --> Utf8 Class Initialized
INFO - 2022-05-10 07:02:52 --> URI Class Initialized
INFO - 2022-05-10 07:02:52 --> Router Class Initialized
INFO - 2022-05-10 07:02:52 --> Output Class Initialized
INFO - 2022-05-10 07:02:52 --> Security Class Initialized
DEBUG - 2022-05-10 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:02:52 --> Input Class Initialized
INFO - 2022-05-10 07:02:52 --> Language Class Initialized
INFO - 2022-05-10 07:02:52 --> Language Class Initialized
INFO - 2022-05-10 07:02:52 --> Config Class Initialized
INFO - 2022-05-10 07:02:52 --> Loader Class Initialized
INFO - 2022-05-10 07:02:52 --> Helper loaded: url_helper
INFO - 2022-05-10 07:02:52 --> Database Driver Class Initialized
INFO - 2022-05-10 07:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:02:52 --> Controller Class Initialized
DEBUG - 2022-05-10 07:02:52 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:02:52 --> Model Class Initialized
DEBUG - 2022-05-10 07:02:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:02:52 --> Model Class Initialized
DEBUG - 2022-05-10 07:02:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:02:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:02:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:02:52 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:02:52 --> Final output sent to browser
DEBUG - 2022-05-10 07:02:52 --> Total execution time: 0.0450
INFO - 2022-05-10 07:06:11 --> Config Class Initialized
INFO - 2022-05-10 07:06:11 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:06:11 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:06:11 --> Utf8 Class Initialized
INFO - 2022-05-10 07:06:11 --> URI Class Initialized
INFO - 2022-05-10 07:06:11 --> Router Class Initialized
INFO - 2022-05-10 07:06:11 --> Output Class Initialized
INFO - 2022-05-10 07:06:11 --> Security Class Initialized
DEBUG - 2022-05-10 07:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:06:11 --> Input Class Initialized
INFO - 2022-05-10 07:06:11 --> Language Class Initialized
INFO - 2022-05-10 07:06:11 --> Language Class Initialized
INFO - 2022-05-10 07:06:11 --> Config Class Initialized
INFO - 2022-05-10 07:06:11 --> Loader Class Initialized
INFO - 2022-05-10 07:06:11 --> Helper loaded: url_helper
INFO - 2022-05-10 07:06:11 --> Database Driver Class Initialized
INFO - 2022-05-10 07:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:06:11 --> Controller Class Initialized
DEBUG - 2022-05-10 07:06:11 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:06:11 --> Model Class Initialized
DEBUG - 2022-05-10 07:06:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:06:11 --> Model Class Initialized
DEBUG - 2022-05-10 07:06:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:06:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:06:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:06:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:06:11 --> Final output sent to browser
DEBUG - 2022-05-10 07:06:11 --> Total execution time: 0.0678
INFO - 2022-05-10 07:06:59 --> Config Class Initialized
INFO - 2022-05-10 07:06:59 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:06:59 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:06:59 --> Utf8 Class Initialized
INFO - 2022-05-10 07:06:59 --> URI Class Initialized
INFO - 2022-05-10 07:06:59 --> Router Class Initialized
INFO - 2022-05-10 07:06:59 --> Output Class Initialized
INFO - 2022-05-10 07:06:59 --> Security Class Initialized
DEBUG - 2022-05-10 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:06:59 --> Input Class Initialized
INFO - 2022-05-10 07:06:59 --> Language Class Initialized
INFO - 2022-05-10 07:06:59 --> Language Class Initialized
INFO - 2022-05-10 07:06:59 --> Config Class Initialized
INFO - 2022-05-10 07:06:59 --> Loader Class Initialized
INFO - 2022-05-10 07:06:59 --> Helper loaded: url_helper
INFO - 2022-05-10 07:06:59 --> Database Driver Class Initialized
INFO - 2022-05-10 07:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:06:59 --> Controller Class Initialized
DEBUG - 2022-05-10 07:06:59 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:06:59 --> Model Class Initialized
DEBUG - 2022-05-10 07:06:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:06:59 --> Model Class Initialized
DEBUG - 2022-05-10 07:06:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:06:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:06:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:06:59 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:06:59 --> Final output sent to browser
DEBUG - 2022-05-10 07:06:59 --> Total execution time: 0.0506
INFO - 2022-05-10 07:10:57 --> Config Class Initialized
INFO - 2022-05-10 07:10:57 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:10:57 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:10:57 --> Utf8 Class Initialized
INFO - 2022-05-10 07:10:57 --> URI Class Initialized
INFO - 2022-05-10 07:10:57 --> Router Class Initialized
INFO - 2022-05-10 07:10:57 --> Output Class Initialized
INFO - 2022-05-10 07:10:57 --> Security Class Initialized
DEBUG - 2022-05-10 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:10:57 --> Input Class Initialized
INFO - 2022-05-10 07:10:57 --> Language Class Initialized
INFO - 2022-05-10 07:10:57 --> Language Class Initialized
INFO - 2022-05-10 07:10:57 --> Config Class Initialized
INFO - 2022-05-10 07:10:57 --> Loader Class Initialized
INFO - 2022-05-10 07:10:57 --> Helper loaded: url_helper
INFO - 2022-05-10 07:10:57 --> Database Driver Class Initialized
INFO - 2022-05-10 07:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:10:57 --> Controller Class Initialized
DEBUG - 2022-05-10 07:10:57 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:10:57 --> Model Class Initialized
DEBUG - 2022-05-10 07:10:57 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:10:57 --> Model Class Initialized
DEBUG - 2022-05-10 07:10:57 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:10:57 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:10:57 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:10:57 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:10:57 --> Final output sent to browser
DEBUG - 2022-05-10 07:10:57 --> Total execution time: 0.0450
INFO - 2022-05-10 07:10:59 --> Config Class Initialized
INFO - 2022-05-10 07:10:59 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:10:59 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:10:59 --> Utf8 Class Initialized
INFO - 2022-05-10 07:10:59 --> URI Class Initialized
INFO - 2022-05-10 07:10:59 --> Router Class Initialized
INFO - 2022-05-10 07:10:59 --> Output Class Initialized
INFO - 2022-05-10 07:10:59 --> Security Class Initialized
DEBUG - 2022-05-10 07:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:10:59 --> Input Class Initialized
INFO - 2022-05-10 07:10:59 --> Language Class Initialized
INFO - 2022-05-10 07:10:59 --> Language Class Initialized
INFO - 2022-05-10 07:10:59 --> Config Class Initialized
INFO - 2022-05-10 07:10:59 --> Loader Class Initialized
INFO - 2022-05-10 07:10:59 --> Helper loaded: url_helper
INFO - 2022-05-10 07:10:59 --> Database Driver Class Initialized
INFO - 2022-05-10 07:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:10:59 --> Controller Class Initialized
ERROR - 2022-05-10 07:10:59 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 07:11:51 --> Config Class Initialized
INFO - 2022-05-10 07:11:51 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:11:51 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:11:51 --> Utf8 Class Initialized
INFO - 2022-05-10 07:11:51 --> URI Class Initialized
INFO - 2022-05-10 07:11:51 --> Router Class Initialized
INFO - 2022-05-10 07:11:51 --> Output Class Initialized
INFO - 2022-05-10 07:11:51 --> Security Class Initialized
DEBUG - 2022-05-10 07:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:11:51 --> Input Class Initialized
INFO - 2022-05-10 07:11:51 --> Language Class Initialized
INFO - 2022-05-10 07:11:51 --> Language Class Initialized
INFO - 2022-05-10 07:11:51 --> Config Class Initialized
INFO - 2022-05-10 07:11:51 --> Loader Class Initialized
INFO - 2022-05-10 07:11:51 --> Helper loaded: url_helper
INFO - 2022-05-10 07:11:51 --> Database Driver Class Initialized
INFO - 2022-05-10 07:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:11:51 --> Controller Class Initialized
DEBUG - 2022-05-10 07:11:51 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:11:51 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:51 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:11:51 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:51 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:11:51 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:11:51 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:11:51 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:11:51 --> Final output sent to browser
DEBUG - 2022-05-10 07:11:51 --> Total execution time: 0.0518
INFO - 2022-05-10 07:11:53 --> Config Class Initialized
INFO - 2022-05-10 07:11:53 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:11:53 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:11:53 --> Utf8 Class Initialized
INFO - 2022-05-10 07:11:53 --> URI Class Initialized
INFO - 2022-05-10 07:11:53 --> Router Class Initialized
INFO - 2022-05-10 07:11:53 --> Output Class Initialized
INFO - 2022-05-10 07:11:53 --> Security Class Initialized
DEBUG - 2022-05-10 07:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:11:53 --> Input Class Initialized
INFO - 2022-05-10 07:11:53 --> Language Class Initialized
INFO - 2022-05-10 07:11:53 --> Language Class Initialized
INFO - 2022-05-10 07:11:53 --> Config Class Initialized
INFO - 2022-05-10 07:11:53 --> Loader Class Initialized
INFO - 2022-05-10 07:11:53 --> Helper loaded: url_helper
INFO - 2022-05-10 07:11:53 --> Database Driver Class Initialized
INFO - 2022-05-10 07:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:11:53 --> Controller Class Initialized
DEBUG - 2022-05-10 07:11:53 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:11:53 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:11:53 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:11:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:11:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:11:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:11:53 --> Final output sent to browser
DEBUG - 2022-05-10 07:11:53 --> Total execution time: 0.0509
INFO - 2022-05-10 07:11:54 --> Config Class Initialized
INFO - 2022-05-10 07:11:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:11:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:11:54 --> Utf8 Class Initialized
INFO - 2022-05-10 07:11:54 --> URI Class Initialized
INFO - 2022-05-10 07:11:54 --> Router Class Initialized
INFO - 2022-05-10 07:11:54 --> Output Class Initialized
INFO - 2022-05-10 07:11:54 --> Security Class Initialized
DEBUG - 2022-05-10 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:11:54 --> Input Class Initialized
INFO - 2022-05-10 07:11:54 --> Language Class Initialized
INFO - 2022-05-10 07:11:54 --> Language Class Initialized
INFO - 2022-05-10 07:11:54 --> Config Class Initialized
INFO - 2022-05-10 07:11:54 --> Loader Class Initialized
INFO - 2022-05-10 07:11:54 --> Helper loaded: url_helper
INFO - 2022-05-10 07:11:54 --> Database Driver Class Initialized
INFO - 2022-05-10 07:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:11:54 --> Controller Class Initialized
DEBUG - 2022-05-10 07:11:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:11:54 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:11:54 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:11:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:11:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:11:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:11:54 --> Final output sent to browser
DEBUG - 2022-05-10 07:11:54 --> Total execution time: 0.0402
INFO - 2022-05-10 07:11:56 --> Config Class Initialized
INFO - 2022-05-10 07:11:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:11:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:11:56 --> Utf8 Class Initialized
INFO - 2022-05-10 07:11:56 --> URI Class Initialized
INFO - 2022-05-10 07:11:56 --> Router Class Initialized
INFO - 2022-05-10 07:11:56 --> Output Class Initialized
INFO - 2022-05-10 07:11:56 --> Security Class Initialized
DEBUG - 2022-05-10 07:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:11:56 --> Input Class Initialized
INFO - 2022-05-10 07:11:56 --> Language Class Initialized
INFO - 2022-05-10 07:11:56 --> Language Class Initialized
INFO - 2022-05-10 07:11:56 --> Config Class Initialized
INFO - 2022-05-10 07:11:56 --> Loader Class Initialized
INFO - 2022-05-10 07:11:56 --> Helper loaded: url_helper
INFO - 2022-05-10 07:11:56 --> Database Driver Class Initialized
INFO - 2022-05-10 07:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:11:56 --> Controller Class Initialized
DEBUG - 2022-05-10 07:11:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 07:11:56 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 07:11:56 --> Model Class Initialized
DEBUG - 2022-05-10 07:11:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 07:11:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 07:11:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 07:11:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 07:11:56 --> Final output sent to browser
DEBUG - 2022-05-10 07:11:56 --> Total execution time: 0.0441
INFO - 2022-05-10 07:11:58 --> Config Class Initialized
INFO - 2022-05-10 07:11:58 --> Hooks Class Initialized
DEBUG - 2022-05-10 07:11:58 --> UTF-8 Support Enabled
INFO - 2022-05-10 07:11:58 --> Utf8 Class Initialized
INFO - 2022-05-10 07:11:58 --> URI Class Initialized
INFO - 2022-05-10 07:11:58 --> Router Class Initialized
INFO - 2022-05-10 07:11:58 --> Output Class Initialized
INFO - 2022-05-10 07:11:58 --> Security Class Initialized
DEBUG - 2022-05-10 07:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 07:11:58 --> Input Class Initialized
INFO - 2022-05-10 07:11:58 --> Language Class Initialized
INFO - 2022-05-10 07:11:58 --> Language Class Initialized
INFO - 2022-05-10 07:11:58 --> Config Class Initialized
INFO - 2022-05-10 07:11:58 --> Loader Class Initialized
INFO - 2022-05-10 07:11:58 --> Helper loaded: url_helper
INFO - 2022-05-10 07:11:58 --> Database Driver Class Initialized
INFO - 2022-05-10 07:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 07:11:58 --> Controller Class Initialized
ERROR - 2022-05-10 07:11:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 13:20:37 --> Config Class Initialized
INFO - 2022-05-10 13:20:37 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:20:37 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:20:37 --> Utf8 Class Initialized
INFO - 2022-05-10 13:20:37 --> URI Class Initialized
DEBUG - 2022-05-10 13:20:37 --> No URI present. Default controller set.
INFO - 2022-05-10 13:20:37 --> Router Class Initialized
INFO - 2022-05-10 13:20:37 --> Output Class Initialized
INFO - 2022-05-10 13:20:37 --> Security Class Initialized
DEBUG - 2022-05-10 13:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:20:37 --> Input Class Initialized
INFO - 2022-05-10 13:20:37 --> Language Class Initialized
INFO - 2022-05-10 13:20:37 --> Language Class Initialized
INFO - 2022-05-10 13:20:37 --> Config Class Initialized
INFO - 2022-05-10 13:20:37 --> Loader Class Initialized
INFO - 2022-05-10 13:20:37 --> Helper loaded: url_helper
INFO - 2022-05-10 13:20:37 --> Database Driver Class Initialized
INFO - 2022-05-10 13:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:20:38 --> Controller Class Initialized
DEBUG - 2022-05-10 13:20:38 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:20:38 --> Model Class Initialized
DEBUG - 2022-05-10 13:20:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:20:38 --> Model Class Initialized
DEBUG - 2022-05-10 13:20:38 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 13:20:38 --> Final output sent to browser
DEBUG - 2022-05-10 13:20:38 --> Total execution time: 0.4549
INFO - 2022-05-10 13:20:48 --> Config Class Initialized
INFO - 2022-05-10 13:20:48 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:20:48 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:20:48 --> Utf8 Class Initialized
INFO - 2022-05-10 13:20:48 --> URI Class Initialized
INFO - 2022-05-10 13:20:48 --> Router Class Initialized
INFO - 2022-05-10 13:20:48 --> Output Class Initialized
INFO - 2022-05-10 13:20:48 --> Security Class Initialized
DEBUG - 2022-05-10 13:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:20:48 --> Input Class Initialized
INFO - 2022-05-10 13:20:48 --> Language Class Initialized
INFO - 2022-05-10 13:20:48 --> Language Class Initialized
INFO - 2022-05-10 13:20:48 --> Config Class Initialized
INFO - 2022-05-10 13:20:48 --> Loader Class Initialized
INFO - 2022-05-10 13:20:48 --> Helper loaded: url_helper
INFO - 2022-05-10 13:20:48 --> Database Driver Class Initialized
INFO - 2022-05-10 13:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:20:48 --> Controller Class Initialized
DEBUG - 2022-05-10 13:20:48 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:20:48 --> Model Class Initialized
DEBUG - 2022-05-10 13:20:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:20:48 --> Model Class Initialized
DEBUG - 2022-05-10 13:20:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:20:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:20:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 13:20:48 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:20:48 --> Final output sent to browser
DEBUG - 2022-05-10 13:20:48 --> Total execution time: 0.0534
INFO - 2022-05-10 13:20:50 --> Config Class Initialized
INFO - 2022-05-10 13:20:50 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:20:50 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:20:50 --> Utf8 Class Initialized
INFO - 2022-05-10 13:20:50 --> URI Class Initialized
INFO - 2022-05-10 13:20:50 --> Router Class Initialized
INFO - 2022-05-10 13:20:50 --> Output Class Initialized
INFO - 2022-05-10 13:20:50 --> Security Class Initialized
DEBUG - 2022-05-10 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:20:50 --> Input Class Initialized
INFO - 2022-05-10 13:20:50 --> Language Class Initialized
INFO - 2022-05-10 13:20:50 --> Language Class Initialized
INFO - 2022-05-10 13:20:50 --> Config Class Initialized
INFO - 2022-05-10 13:20:50 --> Loader Class Initialized
INFO - 2022-05-10 13:20:50 --> Helper loaded: url_helper
INFO - 2022-05-10 13:20:50 --> Database Driver Class Initialized
INFO - 2022-05-10 13:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:20:50 --> Controller Class Initialized
DEBUG - 2022-05-10 13:20:50 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:20:50 --> Model Class Initialized
DEBUG - 2022-05-10 13:20:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:20:50 --> Model Class Initialized
DEBUG - 2022-05-10 13:20:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:20:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:20:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:20:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:20:50 --> Final output sent to browser
DEBUG - 2022-05-10 13:20:50 --> Total execution time: 0.1282
INFO - 2022-05-10 13:22:20 --> Config Class Initialized
INFO - 2022-05-10 13:22:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:22:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:22:20 --> Utf8 Class Initialized
INFO - 2022-05-10 13:22:20 --> URI Class Initialized
INFO - 2022-05-10 13:22:20 --> Router Class Initialized
INFO - 2022-05-10 13:22:20 --> Output Class Initialized
INFO - 2022-05-10 13:22:20 --> Security Class Initialized
DEBUG - 2022-05-10 13:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:22:20 --> Input Class Initialized
INFO - 2022-05-10 13:22:20 --> Language Class Initialized
INFO - 2022-05-10 13:22:20 --> Language Class Initialized
INFO - 2022-05-10 13:22:20 --> Config Class Initialized
INFO - 2022-05-10 13:22:20 --> Loader Class Initialized
INFO - 2022-05-10 13:22:20 --> Helper loaded: url_helper
INFO - 2022-05-10 13:22:20 --> Database Driver Class Initialized
INFO - 2022-05-10 13:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:22:20 --> Controller Class Initialized
DEBUG - 2022-05-10 13:22:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:22:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:22:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:22:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:22:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:22:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:22:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:22:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:22:20 --> Final output sent to browser
DEBUG - 2022-05-10 13:22:20 --> Total execution time: 0.0487
INFO - 2022-05-10 13:22:23 --> Config Class Initialized
INFO - 2022-05-10 13:22:23 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:22:23 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:22:23 --> Utf8 Class Initialized
INFO - 2022-05-10 13:22:23 --> URI Class Initialized
INFO - 2022-05-10 13:22:23 --> Router Class Initialized
INFO - 2022-05-10 13:22:23 --> Output Class Initialized
INFO - 2022-05-10 13:22:23 --> Security Class Initialized
DEBUG - 2022-05-10 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:22:23 --> Input Class Initialized
INFO - 2022-05-10 13:22:23 --> Language Class Initialized
INFO - 2022-05-10 13:22:23 --> Language Class Initialized
INFO - 2022-05-10 13:22:23 --> Config Class Initialized
INFO - 2022-05-10 13:22:23 --> Loader Class Initialized
INFO - 2022-05-10 13:22:23 --> Helper loaded: url_helper
INFO - 2022-05-10 13:22:23 --> Database Driver Class Initialized
INFO - 2022-05-10 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:22:23 --> Controller Class Initialized
DEBUG - 2022-05-10 13:22:23 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:22:23 --> Model Class Initialized
DEBUG - 2022-05-10 13:22:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:22:23 --> Model Class Initialized
DEBUG - 2022-05-10 13:22:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:22:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:22:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:22:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:22:23 --> Final output sent to browser
DEBUG - 2022-05-10 13:22:23 --> Total execution time: 0.0431
INFO - 2022-05-10 13:22:34 --> Config Class Initialized
INFO - 2022-05-10 13:22:34 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:22:34 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:22:34 --> Utf8 Class Initialized
INFO - 2022-05-10 13:22:34 --> URI Class Initialized
INFO - 2022-05-10 13:22:34 --> Router Class Initialized
INFO - 2022-05-10 13:22:34 --> Output Class Initialized
INFO - 2022-05-10 13:22:34 --> Security Class Initialized
DEBUG - 2022-05-10 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:22:34 --> Input Class Initialized
INFO - 2022-05-10 13:22:34 --> Language Class Initialized
INFO - 2022-05-10 13:22:34 --> Language Class Initialized
INFO - 2022-05-10 13:22:34 --> Config Class Initialized
INFO - 2022-05-10 13:22:34 --> Loader Class Initialized
INFO - 2022-05-10 13:22:34 --> Helper loaded: url_helper
INFO - 2022-05-10 13:22:34 --> Database Driver Class Initialized
INFO - 2022-05-10 13:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:22:34 --> Controller Class Initialized
DEBUG - 2022-05-10 13:22:34 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:22:34 --> Model Class Initialized
DEBUG - 2022-05-10 13:22:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:22:34 --> Model Class Initialized
DEBUG - 2022-05-10 13:22:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:22:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:22:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:22:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:22:34 --> Final output sent to browser
DEBUG - 2022-05-10 13:22:34 --> Total execution time: 0.0472
INFO - 2022-05-10 13:25:45 --> Config Class Initialized
INFO - 2022-05-10 13:25:45 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:25:45 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:25:45 --> Utf8 Class Initialized
INFO - 2022-05-10 13:25:45 --> URI Class Initialized
INFO - 2022-05-10 13:25:45 --> Router Class Initialized
INFO - 2022-05-10 13:25:45 --> Output Class Initialized
INFO - 2022-05-10 13:25:45 --> Security Class Initialized
DEBUG - 2022-05-10 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:25:45 --> Input Class Initialized
INFO - 2022-05-10 13:25:45 --> Language Class Initialized
INFO - 2022-05-10 13:25:45 --> Language Class Initialized
INFO - 2022-05-10 13:25:45 --> Config Class Initialized
INFO - 2022-05-10 13:25:45 --> Loader Class Initialized
INFO - 2022-05-10 13:25:45 --> Helper loaded: url_helper
INFO - 2022-05-10 13:25:45 --> Database Driver Class Initialized
INFO - 2022-05-10 13:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:25:45 --> Controller Class Initialized
DEBUG - 2022-05-10 13:25:45 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:25:45 --> Model Class Initialized
DEBUG - 2022-05-10 13:25:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:25:45 --> Model Class Initialized
DEBUG - 2022-05-10 13:25:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:25:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:25:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:25:45 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:25:45 --> Final output sent to browser
DEBUG - 2022-05-10 13:25:45 --> Total execution time: 0.0547
INFO - 2022-05-10 13:28:32 --> Config Class Initialized
INFO - 2022-05-10 13:28:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:28:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:28:32 --> Utf8 Class Initialized
INFO - 2022-05-10 13:28:32 --> URI Class Initialized
INFO - 2022-05-10 13:28:32 --> Router Class Initialized
INFO - 2022-05-10 13:28:32 --> Output Class Initialized
INFO - 2022-05-10 13:28:32 --> Security Class Initialized
DEBUG - 2022-05-10 13:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:28:32 --> Input Class Initialized
INFO - 2022-05-10 13:28:32 --> Language Class Initialized
INFO - 2022-05-10 13:28:32 --> Language Class Initialized
INFO - 2022-05-10 13:28:32 --> Config Class Initialized
INFO - 2022-05-10 13:28:32 --> Loader Class Initialized
INFO - 2022-05-10 13:28:32 --> Helper loaded: url_helper
INFO - 2022-05-10 13:28:32 --> Database Driver Class Initialized
INFO - 2022-05-10 13:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:28:32 --> Controller Class Initialized
DEBUG - 2022-05-10 13:28:32 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:28:32 --> Model Class Initialized
DEBUG - 2022-05-10 13:28:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:28:32 --> Model Class Initialized
DEBUG - 2022-05-10 13:28:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:28:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:28:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:28:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:28:32 --> Final output sent to browser
DEBUG - 2022-05-10 13:28:32 --> Total execution time: 0.0403
INFO - 2022-05-10 13:29:17 --> Config Class Initialized
INFO - 2022-05-10 13:29:17 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:29:17 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:29:17 --> Utf8 Class Initialized
INFO - 2022-05-10 13:29:17 --> URI Class Initialized
INFO - 2022-05-10 13:29:17 --> Router Class Initialized
INFO - 2022-05-10 13:29:17 --> Output Class Initialized
INFO - 2022-05-10 13:29:17 --> Security Class Initialized
DEBUG - 2022-05-10 13:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:29:17 --> Input Class Initialized
INFO - 2022-05-10 13:29:17 --> Language Class Initialized
INFO - 2022-05-10 13:29:17 --> Language Class Initialized
INFO - 2022-05-10 13:29:17 --> Config Class Initialized
INFO - 2022-05-10 13:29:17 --> Loader Class Initialized
INFO - 2022-05-10 13:29:17 --> Helper loaded: url_helper
INFO - 2022-05-10 13:29:17 --> Database Driver Class Initialized
INFO - 2022-05-10 13:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:29:17 --> Controller Class Initialized
DEBUG - 2022-05-10 13:29:17 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:29:17 --> Model Class Initialized
DEBUG - 2022-05-10 13:29:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:29:17 --> Model Class Initialized
DEBUG - 2022-05-10 13:29:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:29:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:29:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:29:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:29:17 --> Final output sent to browser
DEBUG - 2022-05-10 13:29:17 --> Total execution time: 0.0692
INFO - 2022-05-10 13:31:03 --> Config Class Initialized
INFO - 2022-05-10 13:31:03 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:31:03 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:31:03 --> Utf8 Class Initialized
INFO - 2022-05-10 13:31:03 --> URI Class Initialized
INFO - 2022-05-10 13:31:03 --> Router Class Initialized
INFO - 2022-05-10 13:31:03 --> Output Class Initialized
INFO - 2022-05-10 13:31:03 --> Security Class Initialized
DEBUG - 2022-05-10 13:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:31:03 --> Input Class Initialized
INFO - 2022-05-10 13:31:03 --> Language Class Initialized
INFO - 2022-05-10 13:31:03 --> Language Class Initialized
INFO - 2022-05-10 13:31:03 --> Config Class Initialized
INFO - 2022-05-10 13:31:03 --> Loader Class Initialized
INFO - 2022-05-10 13:31:03 --> Helper loaded: url_helper
INFO - 2022-05-10 13:31:03 --> Database Driver Class Initialized
INFO - 2022-05-10 13:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:31:03 --> Controller Class Initialized
DEBUG - 2022-05-10 13:31:03 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:31:03 --> Model Class Initialized
DEBUG - 2022-05-10 13:31:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:31:03 --> Model Class Initialized
DEBUG - 2022-05-10 13:31:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:31:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:31:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:31:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:31:03 --> Final output sent to browser
DEBUG - 2022-05-10 13:31:03 --> Total execution time: 0.0470
INFO - 2022-05-10 13:32:07 --> Config Class Initialized
INFO - 2022-05-10 13:32:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:32:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:32:07 --> Utf8 Class Initialized
INFO - 2022-05-10 13:32:07 --> URI Class Initialized
INFO - 2022-05-10 13:32:07 --> Router Class Initialized
INFO - 2022-05-10 13:32:07 --> Output Class Initialized
INFO - 2022-05-10 13:32:07 --> Security Class Initialized
DEBUG - 2022-05-10 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:32:07 --> Input Class Initialized
INFO - 2022-05-10 13:32:07 --> Language Class Initialized
INFO - 2022-05-10 13:32:07 --> Language Class Initialized
INFO - 2022-05-10 13:32:07 --> Config Class Initialized
INFO - 2022-05-10 13:32:07 --> Loader Class Initialized
INFO - 2022-05-10 13:32:07 --> Helper loaded: url_helper
INFO - 2022-05-10 13:32:07 --> Database Driver Class Initialized
INFO - 2022-05-10 13:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:32:07 --> Controller Class Initialized
DEBUG - 2022-05-10 13:32:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:32:07 --> Model Class Initialized
DEBUG - 2022-05-10 13:32:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:32:07 --> Model Class Initialized
DEBUG - 2022-05-10 13:32:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:32:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:32:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:32:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:32:07 --> Final output sent to browser
DEBUG - 2022-05-10 13:32:07 --> Total execution time: 0.0526
INFO - 2022-05-10 13:34:14 --> Config Class Initialized
INFO - 2022-05-10 13:34:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:34:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:34:14 --> Utf8 Class Initialized
INFO - 2022-05-10 13:34:14 --> URI Class Initialized
INFO - 2022-05-10 13:34:14 --> Router Class Initialized
INFO - 2022-05-10 13:34:14 --> Output Class Initialized
INFO - 2022-05-10 13:34:14 --> Security Class Initialized
DEBUG - 2022-05-10 13:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:34:14 --> Input Class Initialized
INFO - 2022-05-10 13:34:14 --> Language Class Initialized
INFO - 2022-05-10 13:34:14 --> Language Class Initialized
INFO - 2022-05-10 13:34:14 --> Config Class Initialized
INFO - 2022-05-10 13:34:14 --> Loader Class Initialized
INFO - 2022-05-10 13:34:14 --> Helper loaded: url_helper
INFO - 2022-05-10 13:34:14 --> Database Driver Class Initialized
INFO - 2022-05-10 13:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:34:14 --> Controller Class Initialized
DEBUG - 2022-05-10 13:34:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:34:14 --> Model Class Initialized
DEBUG - 2022-05-10 13:34:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:34:14 --> Model Class Initialized
DEBUG - 2022-05-10 13:34:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:34:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:34:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:34:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:34:14 --> Final output sent to browser
DEBUG - 2022-05-10 13:34:14 --> Total execution time: 0.0532
INFO - 2022-05-10 13:34:47 --> Config Class Initialized
INFO - 2022-05-10 13:34:47 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:34:47 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:34:47 --> Utf8 Class Initialized
INFO - 2022-05-10 13:34:47 --> URI Class Initialized
INFO - 2022-05-10 13:34:47 --> Router Class Initialized
INFO - 2022-05-10 13:34:47 --> Output Class Initialized
INFO - 2022-05-10 13:34:47 --> Security Class Initialized
DEBUG - 2022-05-10 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:34:47 --> Input Class Initialized
INFO - 2022-05-10 13:34:47 --> Language Class Initialized
INFO - 2022-05-10 13:34:47 --> Language Class Initialized
INFO - 2022-05-10 13:34:47 --> Config Class Initialized
INFO - 2022-05-10 13:34:47 --> Loader Class Initialized
INFO - 2022-05-10 13:34:47 --> Helper loaded: url_helper
INFO - 2022-05-10 13:34:47 --> Database Driver Class Initialized
INFO - 2022-05-10 13:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:34:47 --> Controller Class Initialized
DEBUG - 2022-05-10 13:34:47 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:34:47 --> Model Class Initialized
DEBUG - 2022-05-10 13:34:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:34:47 --> Model Class Initialized
DEBUG - 2022-05-10 13:34:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:34:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:34:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:34:47 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:34:47 --> Final output sent to browser
DEBUG - 2022-05-10 13:34:47 --> Total execution time: 0.0419
INFO - 2022-05-10 13:35:00 --> Config Class Initialized
INFO - 2022-05-10 13:35:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:35:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:35:00 --> Utf8 Class Initialized
INFO - 2022-05-10 13:35:00 --> URI Class Initialized
INFO - 2022-05-10 13:35:00 --> Router Class Initialized
INFO - 2022-05-10 13:35:00 --> Output Class Initialized
INFO - 2022-05-10 13:35:00 --> Security Class Initialized
DEBUG - 2022-05-10 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:35:00 --> Input Class Initialized
INFO - 2022-05-10 13:35:00 --> Language Class Initialized
INFO - 2022-05-10 13:35:00 --> Language Class Initialized
INFO - 2022-05-10 13:35:00 --> Config Class Initialized
INFO - 2022-05-10 13:35:00 --> Loader Class Initialized
INFO - 2022-05-10 13:35:00 --> Helper loaded: url_helper
INFO - 2022-05-10 13:35:00 --> Database Driver Class Initialized
INFO - 2022-05-10 13:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:35:00 --> Controller Class Initialized
DEBUG - 2022-05-10 13:35:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:35:00 --> Model Class Initialized
DEBUG - 2022-05-10 13:35:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:35:00 --> Model Class Initialized
DEBUG - 2022-05-10 13:35:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:35:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:35:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:35:00 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:35:00 --> Final output sent to browser
DEBUG - 2022-05-10 13:35:00 --> Total execution time: 0.0495
INFO - 2022-05-10 13:37:02 --> Config Class Initialized
INFO - 2022-05-10 13:37:02 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:37:02 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:37:02 --> Utf8 Class Initialized
INFO - 2022-05-10 13:37:02 --> URI Class Initialized
INFO - 2022-05-10 13:37:02 --> Router Class Initialized
INFO - 2022-05-10 13:37:02 --> Output Class Initialized
INFO - 2022-05-10 13:37:02 --> Security Class Initialized
DEBUG - 2022-05-10 13:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:37:02 --> Input Class Initialized
INFO - 2022-05-10 13:37:02 --> Language Class Initialized
INFO - 2022-05-10 13:37:02 --> Language Class Initialized
INFO - 2022-05-10 13:37:02 --> Config Class Initialized
INFO - 2022-05-10 13:37:02 --> Loader Class Initialized
INFO - 2022-05-10 13:37:02 --> Helper loaded: url_helper
INFO - 2022-05-10 13:37:02 --> Database Driver Class Initialized
INFO - 2022-05-10 13:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:37:02 --> Controller Class Initialized
DEBUG - 2022-05-10 13:37:02 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:37:02 --> Model Class Initialized
DEBUG - 2022-05-10 13:37:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:37:02 --> Model Class Initialized
DEBUG - 2022-05-10 13:37:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:37:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:37:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:37:02 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:37:02 --> Final output sent to browser
DEBUG - 2022-05-10 13:37:02 --> Total execution time: 0.0479
INFO - 2022-05-10 13:39:20 --> Config Class Initialized
INFO - 2022-05-10 13:39:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:39:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:39:20 --> Utf8 Class Initialized
INFO - 2022-05-10 13:39:20 --> URI Class Initialized
INFO - 2022-05-10 13:39:20 --> Router Class Initialized
INFO - 2022-05-10 13:39:20 --> Output Class Initialized
INFO - 2022-05-10 13:39:20 --> Security Class Initialized
DEBUG - 2022-05-10 13:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:39:20 --> Input Class Initialized
INFO - 2022-05-10 13:39:20 --> Language Class Initialized
INFO - 2022-05-10 13:39:20 --> Language Class Initialized
INFO - 2022-05-10 13:39:20 --> Config Class Initialized
INFO - 2022-05-10 13:39:20 --> Loader Class Initialized
INFO - 2022-05-10 13:39:20 --> Helper loaded: url_helper
INFO - 2022-05-10 13:39:20 --> Database Driver Class Initialized
INFO - 2022-05-10 13:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:39:20 --> Controller Class Initialized
DEBUG - 2022-05-10 13:39:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:39:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:39:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:39:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:39:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:39:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:39:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:39:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:39:20 --> Final output sent to browser
DEBUG - 2022-05-10 13:39:20 --> Total execution time: 0.0332
INFO - 2022-05-10 13:39:41 --> Config Class Initialized
INFO - 2022-05-10 13:39:41 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:39:41 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:39:41 --> Utf8 Class Initialized
INFO - 2022-05-10 13:39:41 --> URI Class Initialized
INFO - 2022-05-10 13:39:41 --> Router Class Initialized
INFO - 2022-05-10 13:39:41 --> Output Class Initialized
INFO - 2022-05-10 13:39:41 --> Security Class Initialized
DEBUG - 2022-05-10 13:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:39:41 --> Input Class Initialized
INFO - 2022-05-10 13:39:41 --> Language Class Initialized
INFO - 2022-05-10 13:39:41 --> Language Class Initialized
INFO - 2022-05-10 13:39:41 --> Config Class Initialized
INFO - 2022-05-10 13:39:41 --> Loader Class Initialized
INFO - 2022-05-10 13:39:41 --> Helper loaded: url_helper
INFO - 2022-05-10 13:39:41 --> Database Driver Class Initialized
INFO - 2022-05-10 13:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:39:41 --> Controller Class Initialized
DEBUG - 2022-05-10 13:39:41 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:39:41 --> Model Class Initialized
DEBUG - 2022-05-10 13:39:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:39:41 --> Model Class Initialized
DEBUG - 2022-05-10 13:39:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:39:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:39:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:39:41 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:39:41 --> Final output sent to browser
DEBUG - 2022-05-10 13:39:41 --> Total execution time: 0.0305
INFO - 2022-05-10 13:40:33 --> Config Class Initialized
INFO - 2022-05-10 13:40:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:40:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:40:33 --> Utf8 Class Initialized
INFO - 2022-05-10 13:40:33 --> URI Class Initialized
INFO - 2022-05-10 13:40:33 --> Router Class Initialized
INFO - 2022-05-10 13:40:33 --> Output Class Initialized
INFO - 2022-05-10 13:40:33 --> Security Class Initialized
DEBUG - 2022-05-10 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:40:33 --> Input Class Initialized
INFO - 2022-05-10 13:40:33 --> Language Class Initialized
INFO - 2022-05-10 13:40:33 --> Language Class Initialized
INFO - 2022-05-10 13:40:33 --> Config Class Initialized
INFO - 2022-05-10 13:40:33 --> Loader Class Initialized
INFO - 2022-05-10 13:40:33 --> Helper loaded: url_helper
INFO - 2022-05-10 13:40:33 --> Database Driver Class Initialized
INFO - 2022-05-10 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:40:33 --> Controller Class Initialized
DEBUG - 2022-05-10 13:40:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:40:33 --> Model Class Initialized
DEBUG - 2022-05-10 13:40:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:40:33 --> Model Class Initialized
DEBUG - 2022-05-10 13:40:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:40:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:40:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:40:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:40:33 --> Final output sent to browser
DEBUG - 2022-05-10 13:40:33 --> Total execution time: 0.0302
INFO - 2022-05-10 13:42:03 --> Config Class Initialized
INFO - 2022-05-10 13:42:03 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:42:03 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:42:03 --> Utf8 Class Initialized
INFO - 2022-05-10 13:42:03 --> URI Class Initialized
INFO - 2022-05-10 13:42:03 --> Router Class Initialized
INFO - 2022-05-10 13:42:03 --> Output Class Initialized
INFO - 2022-05-10 13:42:03 --> Security Class Initialized
DEBUG - 2022-05-10 13:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:42:03 --> Input Class Initialized
INFO - 2022-05-10 13:42:03 --> Language Class Initialized
INFO - 2022-05-10 13:42:03 --> Language Class Initialized
INFO - 2022-05-10 13:42:03 --> Config Class Initialized
INFO - 2022-05-10 13:42:03 --> Loader Class Initialized
INFO - 2022-05-10 13:42:03 --> Helper loaded: url_helper
INFO - 2022-05-10 13:42:03 --> Database Driver Class Initialized
INFO - 2022-05-10 13:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:42:03 --> Controller Class Initialized
DEBUG - 2022-05-10 13:42:03 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:42:03 --> Model Class Initialized
DEBUG - 2022-05-10 13:42:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:42:03 --> Model Class Initialized
DEBUG - 2022-05-10 13:42:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:42:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:42:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:42:03 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:42:03 --> Final output sent to browser
DEBUG - 2022-05-10 13:42:03 --> Total execution time: 0.0422
INFO - 2022-05-10 13:42:20 --> Config Class Initialized
INFO - 2022-05-10 13:42:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:42:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:42:20 --> Utf8 Class Initialized
INFO - 2022-05-10 13:42:20 --> URI Class Initialized
INFO - 2022-05-10 13:42:20 --> Router Class Initialized
INFO - 2022-05-10 13:42:20 --> Output Class Initialized
INFO - 2022-05-10 13:42:20 --> Security Class Initialized
DEBUG - 2022-05-10 13:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:42:20 --> Input Class Initialized
INFO - 2022-05-10 13:42:20 --> Language Class Initialized
INFO - 2022-05-10 13:42:20 --> Language Class Initialized
INFO - 2022-05-10 13:42:20 --> Config Class Initialized
INFO - 2022-05-10 13:42:20 --> Loader Class Initialized
INFO - 2022-05-10 13:42:20 --> Helper loaded: url_helper
INFO - 2022-05-10 13:42:20 --> Database Driver Class Initialized
INFO - 2022-05-10 13:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:42:20 --> Controller Class Initialized
DEBUG - 2022-05-10 13:42:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:42:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:42:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:42:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:42:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:42:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:42:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:42:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:42:20 --> Final output sent to browser
DEBUG - 2022-05-10 13:42:20 --> Total execution time: 0.0485
INFO - 2022-05-10 13:42:29 --> Config Class Initialized
INFO - 2022-05-10 13:42:29 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:42:29 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:42:29 --> Utf8 Class Initialized
INFO - 2022-05-10 13:42:29 --> URI Class Initialized
INFO - 2022-05-10 13:42:29 --> Router Class Initialized
INFO - 2022-05-10 13:42:29 --> Output Class Initialized
INFO - 2022-05-10 13:42:29 --> Security Class Initialized
DEBUG - 2022-05-10 13:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:42:29 --> Input Class Initialized
INFO - 2022-05-10 13:42:29 --> Language Class Initialized
INFO - 2022-05-10 13:42:29 --> Language Class Initialized
INFO - 2022-05-10 13:42:29 --> Config Class Initialized
INFO - 2022-05-10 13:42:29 --> Loader Class Initialized
INFO - 2022-05-10 13:42:29 --> Helper loaded: url_helper
INFO - 2022-05-10 13:42:29 --> Database Driver Class Initialized
INFO - 2022-05-10 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:42:29 --> Controller Class Initialized
DEBUG - 2022-05-10 13:42:29 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:42:29 --> Model Class Initialized
DEBUG - 2022-05-10 13:42:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:42:29 --> Model Class Initialized
DEBUG - 2022-05-10 13:42:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:42:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:42:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:42:29 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:42:29 --> Final output sent to browser
DEBUG - 2022-05-10 13:42:29 --> Total execution time: 0.0554
INFO - 2022-05-10 13:44:18 --> Config Class Initialized
INFO - 2022-05-10 13:44:18 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:44:18 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:44:18 --> Utf8 Class Initialized
INFO - 2022-05-10 13:44:18 --> URI Class Initialized
DEBUG - 2022-05-10 13:44:18 --> No URI present. Default controller set.
INFO - 2022-05-10 13:44:18 --> Router Class Initialized
INFO - 2022-05-10 13:44:18 --> Output Class Initialized
INFO - 2022-05-10 13:44:18 --> Security Class Initialized
DEBUG - 2022-05-10 13:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:44:18 --> Input Class Initialized
INFO - 2022-05-10 13:44:18 --> Language Class Initialized
INFO - 2022-05-10 13:44:18 --> Language Class Initialized
INFO - 2022-05-10 13:44:18 --> Config Class Initialized
INFO - 2022-05-10 13:44:18 --> Loader Class Initialized
INFO - 2022-05-10 13:44:18 --> Helper loaded: url_helper
INFO - 2022-05-10 13:44:18 --> Database Driver Class Initialized
INFO - 2022-05-10 13:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:44:18 --> Controller Class Initialized
DEBUG - 2022-05-10 13:44:18 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:44:18 --> Model Class Initialized
DEBUG - 2022-05-10 13:44:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:44:18 --> Model Class Initialized
DEBUG - 2022-05-10 13:44:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 13:44:18 --> Final output sent to browser
DEBUG - 2022-05-10 13:44:18 --> Total execution time: 0.0488
INFO - 2022-05-10 13:44:24 --> Config Class Initialized
INFO - 2022-05-10 13:44:24 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:44:24 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:44:24 --> Utf8 Class Initialized
INFO - 2022-05-10 13:44:24 --> URI Class Initialized
INFO - 2022-05-10 13:44:24 --> Router Class Initialized
INFO - 2022-05-10 13:44:24 --> Output Class Initialized
INFO - 2022-05-10 13:44:24 --> Security Class Initialized
DEBUG - 2022-05-10 13:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:44:24 --> Input Class Initialized
INFO - 2022-05-10 13:44:24 --> Language Class Initialized
INFO - 2022-05-10 13:44:24 --> Language Class Initialized
INFO - 2022-05-10 13:44:24 --> Config Class Initialized
INFO - 2022-05-10 13:44:24 --> Loader Class Initialized
INFO - 2022-05-10 13:44:24 --> Helper loaded: url_helper
INFO - 2022-05-10 13:44:24 --> Database Driver Class Initialized
INFO - 2022-05-10 13:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:44:24 --> Controller Class Initialized
DEBUG - 2022-05-10 13:44:24 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:44:24 --> Model Class Initialized
DEBUG - 2022-05-10 13:44:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:44:24 --> Model Class Initialized
DEBUG - 2022-05-10 13:44:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:44:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:44:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:44:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:44:24 --> Final output sent to browser
DEBUG - 2022-05-10 13:44:24 --> Total execution time: 0.0531
INFO - 2022-05-10 13:44:27 --> Config Class Initialized
INFO - 2022-05-10 13:44:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:44:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:44:27 --> Utf8 Class Initialized
INFO - 2022-05-10 13:44:27 --> URI Class Initialized
INFO - 2022-05-10 13:44:27 --> Router Class Initialized
INFO - 2022-05-10 13:44:27 --> Output Class Initialized
INFO - 2022-05-10 13:44:27 --> Security Class Initialized
DEBUG - 2022-05-10 13:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:44:27 --> Input Class Initialized
INFO - 2022-05-10 13:44:27 --> Language Class Initialized
INFO - 2022-05-10 13:44:27 --> Language Class Initialized
INFO - 2022-05-10 13:44:27 --> Config Class Initialized
INFO - 2022-05-10 13:44:27 --> Loader Class Initialized
INFO - 2022-05-10 13:44:27 --> Helper loaded: url_helper
INFO - 2022-05-10 13:44:27 --> Database Driver Class Initialized
INFO - 2022-05-10 13:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:44:27 --> Controller Class Initialized
ERROR - 2022-05-10 13:44:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 13:50:56 --> Config Class Initialized
INFO - 2022-05-10 13:50:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:50:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:50:56 --> Utf8 Class Initialized
INFO - 2022-05-10 13:50:56 --> URI Class Initialized
INFO - 2022-05-10 13:50:56 --> Router Class Initialized
INFO - 2022-05-10 13:50:56 --> Output Class Initialized
INFO - 2022-05-10 13:50:56 --> Security Class Initialized
DEBUG - 2022-05-10 13:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:50:56 --> Input Class Initialized
INFO - 2022-05-10 13:50:56 --> Language Class Initialized
INFO - 2022-05-10 13:50:56 --> Language Class Initialized
INFO - 2022-05-10 13:50:56 --> Config Class Initialized
INFO - 2022-05-10 13:50:56 --> Loader Class Initialized
INFO - 2022-05-10 13:50:56 --> Helper loaded: url_helper
INFO - 2022-05-10 13:50:56 --> Database Driver Class Initialized
INFO - 2022-05-10 13:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:50:56 --> Controller Class Initialized
DEBUG - 2022-05-10 13:50:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:50:56 --> Model Class Initialized
DEBUG - 2022-05-10 13:50:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:50:56 --> Model Class Initialized
DEBUG - 2022-05-10 13:50:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:50:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:50:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:50:56 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:50:56 --> Final output sent to browser
DEBUG - 2022-05-10 13:50:56 --> Total execution time: 0.0330
INFO - 2022-05-10 13:51:33 --> Config Class Initialized
INFO - 2022-05-10 13:51:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:51:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:51:33 --> Utf8 Class Initialized
INFO - 2022-05-10 13:51:33 --> URI Class Initialized
INFO - 2022-05-10 13:51:33 --> Router Class Initialized
INFO - 2022-05-10 13:51:33 --> Output Class Initialized
INFO - 2022-05-10 13:51:33 --> Security Class Initialized
DEBUG - 2022-05-10 13:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:51:33 --> Input Class Initialized
INFO - 2022-05-10 13:51:33 --> Language Class Initialized
INFO - 2022-05-10 13:51:33 --> Language Class Initialized
INFO - 2022-05-10 13:51:33 --> Config Class Initialized
INFO - 2022-05-10 13:51:33 --> Loader Class Initialized
INFO - 2022-05-10 13:51:33 --> Helper loaded: url_helper
INFO - 2022-05-10 13:51:33 --> Database Driver Class Initialized
INFO - 2022-05-10 13:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:51:33 --> Controller Class Initialized
DEBUG - 2022-05-10 13:51:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:51:33 --> Model Class Initialized
DEBUG - 2022-05-10 13:51:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:51:33 --> Model Class Initialized
DEBUG - 2022-05-10 13:51:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:51:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:51:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:51:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:51:33 --> Final output sent to browser
DEBUG - 2022-05-10 13:51:33 --> Total execution time: 0.0436
INFO - 2022-05-10 13:52:26 --> Config Class Initialized
INFO - 2022-05-10 13:52:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:52:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:52:26 --> Utf8 Class Initialized
INFO - 2022-05-10 13:52:26 --> URI Class Initialized
INFO - 2022-05-10 13:52:26 --> Router Class Initialized
INFO - 2022-05-10 13:52:26 --> Output Class Initialized
INFO - 2022-05-10 13:52:26 --> Security Class Initialized
DEBUG - 2022-05-10 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:52:26 --> Input Class Initialized
INFO - 2022-05-10 13:52:26 --> Language Class Initialized
INFO - 2022-05-10 13:52:26 --> Language Class Initialized
INFO - 2022-05-10 13:52:26 --> Config Class Initialized
INFO - 2022-05-10 13:52:26 --> Loader Class Initialized
INFO - 2022-05-10 13:52:26 --> Helper loaded: url_helper
INFO - 2022-05-10 13:52:26 --> Database Driver Class Initialized
INFO - 2022-05-10 13:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:52:26 --> Controller Class Initialized
DEBUG - 2022-05-10 13:52:26 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:52:26 --> Model Class Initialized
DEBUG - 2022-05-10 13:52:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:52:26 --> Model Class Initialized
DEBUG - 2022-05-10 13:52:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:52:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:52:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:52:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:52:26 --> Final output sent to browser
DEBUG - 2022-05-10 13:52:26 --> Total execution time: 0.0422
INFO - 2022-05-10 13:53:07 --> Config Class Initialized
INFO - 2022-05-10 13:53:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:53:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:53:07 --> Utf8 Class Initialized
INFO - 2022-05-10 13:53:07 --> URI Class Initialized
INFO - 2022-05-10 13:53:07 --> Router Class Initialized
INFO - 2022-05-10 13:53:07 --> Output Class Initialized
INFO - 2022-05-10 13:53:07 --> Security Class Initialized
DEBUG - 2022-05-10 13:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:53:07 --> Input Class Initialized
INFO - 2022-05-10 13:53:07 --> Language Class Initialized
INFO - 2022-05-10 13:53:07 --> Language Class Initialized
INFO - 2022-05-10 13:53:07 --> Config Class Initialized
INFO - 2022-05-10 13:53:07 --> Loader Class Initialized
INFO - 2022-05-10 13:53:07 --> Helper loaded: url_helper
INFO - 2022-05-10 13:53:07 --> Database Driver Class Initialized
INFO - 2022-05-10 13:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:53:07 --> Controller Class Initialized
DEBUG - 2022-05-10 13:53:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:53:07 --> Model Class Initialized
DEBUG - 2022-05-10 13:53:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:53:07 --> Model Class Initialized
DEBUG - 2022-05-10 13:53:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:53:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:53:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:53:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:53:07 --> Final output sent to browser
DEBUG - 2022-05-10 13:53:07 --> Total execution time: 0.0555
INFO - 2022-05-10 13:54:14 --> Config Class Initialized
INFO - 2022-05-10 13:54:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:54:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:54:14 --> Utf8 Class Initialized
INFO - 2022-05-10 13:54:14 --> URI Class Initialized
INFO - 2022-05-10 13:54:14 --> Router Class Initialized
INFO - 2022-05-10 13:54:14 --> Output Class Initialized
INFO - 2022-05-10 13:54:14 --> Security Class Initialized
DEBUG - 2022-05-10 13:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:54:14 --> Input Class Initialized
INFO - 2022-05-10 13:54:14 --> Language Class Initialized
INFO - 2022-05-10 13:54:14 --> Language Class Initialized
INFO - 2022-05-10 13:54:14 --> Config Class Initialized
INFO - 2022-05-10 13:54:14 --> Loader Class Initialized
INFO - 2022-05-10 13:54:14 --> Helper loaded: url_helper
INFO - 2022-05-10 13:54:14 --> Database Driver Class Initialized
INFO - 2022-05-10 13:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:54:14 --> Controller Class Initialized
DEBUG - 2022-05-10 13:54:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:54:14 --> Model Class Initialized
DEBUG - 2022-05-10 13:54:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:54:14 --> Model Class Initialized
DEBUG - 2022-05-10 13:54:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:54:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:54:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:54:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:54:14 --> Final output sent to browser
DEBUG - 2022-05-10 13:54:14 --> Total execution time: 0.0541
INFO - 2022-05-10 13:54:50 --> Config Class Initialized
INFO - 2022-05-10 13:54:50 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:54:50 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:54:50 --> Utf8 Class Initialized
INFO - 2022-05-10 13:54:50 --> URI Class Initialized
INFO - 2022-05-10 13:54:50 --> Router Class Initialized
INFO - 2022-05-10 13:54:50 --> Output Class Initialized
INFO - 2022-05-10 13:54:50 --> Security Class Initialized
DEBUG - 2022-05-10 13:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:54:50 --> Input Class Initialized
INFO - 2022-05-10 13:54:50 --> Language Class Initialized
INFO - 2022-05-10 13:54:50 --> Language Class Initialized
INFO - 2022-05-10 13:54:50 --> Config Class Initialized
INFO - 2022-05-10 13:54:50 --> Loader Class Initialized
INFO - 2022-05-10 13:54:50 --> Helper loaded: url_helper
INFO - 2022-05-10 13:54:50 --> Database Driver Class Initialized
INFO - 2022-05-10 13:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:54:50 --> Controller Class Initialized
DEBUG - 2022-05-10 13:54:50 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:54:50 --> Model Class Initialized
DEBUG - 2022-05-10 13:54:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:54:50 --> Model Class Initialized
DEBUG - 2022-05-10 13:54:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:54:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:54:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:54:50 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:54:50 --> Final output sent to browser
DEBUG - 2022-05-10 13:54:50 --> Total execution time: 0.0518
INFO - 2022-05-10 13:56:16 --> Config Class Initialized
INFO - 2022-05-10 13:56:16 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:56:16 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:56:16 --> Utf8 Class Initialized
INFO - 2022-05-10 13:56:16 --> URI Class Initialized
INFO - 2022-05-10 13:56:16 --> Router Class Initialized
INFO - 2022-05-10 13:56:16 --> Output Class Initialized
INFO - 2022-05-10 13:56:16 --> Security Class Initialized
DEBUG - 2022-05-10 13:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:56:16 --> Input Class Initialized
INFO - 2022-05-10 13:56:16 --> Language Class Initialized
INFO - 2022-05-10 13:56:16 --> Language Class Initialized
INFO - 2022-05-10 13:56:16 --> Config Class Initialized
INFO - 2022-05-10 13:56:16 --> Loader Class Initialized
INFO - 2022-05-10 13:56:16 --> Helper loaded: url_helper
INFO - 2022-05-10 13:56:16 --> Database Driver Class Initialized
INFO - 2022-05-10 13:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:56:16 --> Controller Class Initialized
DEBUG - 2022-05-10 13:56:16 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:56:16 --> Model Class Initialized
DEBUG - 2022-05-10 13:56:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:56:16 --> Model Class Initialized
DEBUG - 2022-05-10 13:56:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:56:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:56:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:56:16 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:56:16 --> Final output sent to browser
DEBUG - 2022-05-10 13:56:16 --> Total execution time: 0.0545
INFO - 2022-05-10 13:57:04 --> Config Class Initialized
INFO - 2022-05-10 13:57:04 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:57:04 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:04 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:04 --> URI Class Initialized
INFO - 2022-05-10 13:57:04 --> Router Class Initialized
INFO - 2022-05-10 13:57:04 --> Output Class Initialized
INFO - 2022-05-10 13:57:04 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:04 --> Input Class Initialized
INFO - 2022-05-10 13:57:04 --> Language Class Initialized
INFO - 2022-05-10 13:57:04 --> Language Class Initialized
INFO - 2022-05-10 13:57:04 --> Config Class Initialized
INFO - 2022-05-10 13:57:04 --> Loader Class Initialized
INFO - 2022-05-10 13:57:04 --> Helper loaded: url_helper
INFO - 2022-05-10 13:57:04 --> Database Driver Class Initialized
INFO - 2022-05-10 13:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:57:04 --> Controller Class Initialized
DEBUG - 2022-05-10 13:57:04 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:57:04 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:57:04 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:57:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:57:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:57:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:57:04 --> Final output sent to browser
DEBUG - 2022-05-10 13:57:04 --> Total execution time: 0.0471
INFO - 2022-05-10 13:57:05 --> Config Class Initialized
INFO - 2022-05-10 13:57:05 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:57:05 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:05 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:05 --> URI Class Initialized
INFO - 2022-05-10 13:57:05 --> Router Class Initialized
INFO - 2022-05-10 13:57:05 --> Output Class Initialized
INFO - 2022-05-10 13:57:05 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:05 --> Input Class Initialized
INFO - 2022-05-10 13:57:05 --> Language Class Initialized
INFO - 2022-05-10 13:57:05 --> Language Class Initialized
INFO - 2022-05-10 13:57:05 --> Config Class Initialized
INFO - 2022-05-10 13:57:05 --> Loader Class Initialized
INFO - 2022-05-10 13:57:05 --> Helper loaded: url_helper
INFO - 2022-05-10 13:57:05 --> Database Driver Class Initialized
INFO - 2022-05-10 13:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:57:05 --> Controller Class Initialized
DEBUG - 2022-05-10 13:57:05 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:57:05 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:57:05 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:57:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:57:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:57:05 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:57:05 --> Final output sent to browser
DEBUG - 2022-05-10 13:57:05 --> Total execution time: 0.0337
INFO - 2022-05-10 13:57:17 --> Config Class Initialized
INFO - 2022-05-10 13:57:17 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:57:17 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:17 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:17 --> URI Class Initialized
INFO - 2022-05-10 13:57:17 --> Router Class Initialized
INFO - 2022-05-10 13:57:17 --> Output Class Initialized
INFO - 2022-05-10 13:57:17 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:17 --> Input Class Initialized
INFO - 2022-05-10 13:57:17 --> Language Class Initialized
INFO - 2022-05-10 13:57:17 --> Language Class Initialized
INFO - 2022-05-10 13:57:17 --> Config Class Initialized
INFO - 2022-05-10 13:57:17 --> Loader Class Initialized
INFO - 2022-05-10 13:57:17 --> Helper loaded: url_helper
INFO - 2022-05-10 13:57:17 --> Database Driver Class Initialized
INFO - 2022-05-10 13:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:57:17 --> Controller Class Initialized
DEBUG - 2022-05-10 13:57:17 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:57:17 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:57:17 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:57:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:57:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:57:17 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:57:17 --> Final output sent to browser
DEBUG - 2022-05-10 13:57:17 --> Total execution time: 0.0325
INFO - 2022-05-10 13:57:54 --> Config Class Initialized
INFO - 2022-05-10 13:57:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:57:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:54 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:54 --> URI Class Initialized
INFO - 2022-05-10 13:57:54 --> Router Class Initialized
INFO - 2022-05-10 13:57:54 --> Output Class Initialized
INFO - 2022-05-10 13:57:54 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:54 --> Input Class Initialized
INFO - 2022-05-10 13:57:54 --> Language Class Initialized
INFO - 2022-05-10 13:57:54 --> Language Class Initialized
INFO - 2022-05-10 13:57:54 --> Config Class Initialized
INFO - 2022-05-10 13:57:54 --> Loader Class Initialized
INFO - 2022-05-10 13:57:54 --> Helper loaded: url_helper
INFO - 2022-05-10 13:57:54 --> Database Driver Class Initialized
INFO - 2022-05-10 13:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:57:54 --> Controller Class Initialized
DEBUG - 2022-05-10 13:57:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:57:54 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:57:54 --> Model Class Initialized
DEBUG - 2022-05-10 13:57:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:57:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:57:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:57:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:57:54 --> Final output sent to browser
DEBUG - 2022-05-10 13:57:54 --> Total execution time: 0.0327
INFO - 2022-05-10 13:57:59 --> Config Class Initialized
INFO - 2022-05-10 13:57:59 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:59 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:59 --> URI Class Initialized
INFO - 2022-05-10 13:57:59 --> Config Class Initialized
INFO - 2022-05-10 13:57:59 --> Hooks Class Initialized
INFO - 2022-05-10 13:57:59 --> Router Class Initialized
INFO - 2022-05-10 13:57:59 --> Output Class Initialized
DEBUG - 2022-05-10 13:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:59 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:59 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:59 --> URI Class Initialized
INFO - 2022-05-10 13:57:59 --> Input Class Initialized
INFO - 2022-05-10 13:57:59 --> Language Class Initialized
ERROR - 2022-05-10 13:57:59 --> 404 Page Not Found: /index
INFO - 2022-05-10 13:57:59 --> Router Class Initialized
INFO - 2022-05-10 13:57:59 --> Output Class Initialized
INFO - 2022-05-10 13:57:59 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:59 --> Input Class Initialized
INFO - 2022-05-10 13:57:59 --> Language Class Initialized
ERROR - 2022-05-10 13:57:59 --> 404 Page Not Found: /index
INFO - 2022-05-10 13:57:59 --> Config Class Initialized
INFO - 2022-05-10 13:57:59 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:57:59 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:57:59 --> Utf8 Class Initialized
INFO - 2022-05-10 13:57:59 --> URI Class Initialized
INFO - 2022-05-10 13:57:59 --> Router Class Initialized
INFO - 2022-05-10 13:57:59 --> Output Class Initialized
INFO - 2022-05-10 13:57:59 --> Security Class Initialized
DEBUG - 2022-05-10 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:57:59 --> Input Class Initialized
INFO - 2022-05-10 13:57:59 --> Language Class Initialized
ERROR - 2022-05-10 13:57:59 --> 404 Page Not Found: /index
INFO - 2022-05-10 13:58:20 --> Config Class Initialized
INFO - 2022-05-10 13:58:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:58:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:58:20 --> Utf8 Class Initialized
INFO - 2022-05-10 13:58:20 --> URI Class Initialized
INFO - 2022-05-10 13:58:20 --> Router Class Initialized
INFO - 2022-05-10 13:58:20 --> Output Class Initialized
INFO - 2022-05-10 13:58:20 --> Security Class Initialized
DEBUG - 2022-05-10 13:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:58:20 --> Input Class Initialized
INFO - 2022-05-10 13:58:20 --> Language Class Initialized
INFO - 2022-05-10 13:58:20 --> Language Class Initialized
INFO - 2022-05-10 13:58:20 --> Config Class Initialized
INFO - 2022-05-10 13:58:20 --> Loader Class Initialized
INFO - 2022-05-10 13:58:20 --> Helper loaded: url_helper
INFO - 2022-05-10 13:58:20 --> Database Driver Class Initialized
INFO - 2022-05-10 13:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:58:20 --> Controller Class Initialized
DEBUG - 2022-05-10 13:58:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:58:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:58:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:58:20 --> Model Class Initialized
DEBUG - 2022-05-10 13:58:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:58:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:58:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:58:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:58:20 --> Final output sent to browser
DEBUG - 2022-05-10 13:58:20 --> Total execution time: 0.0565
INFO - 2022-05-10 13:58:39 --> Config Class Initialized
INFO - 2022-05-10 13:58:39 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:58:39 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:58:39 --> Utf8 Class Initialized
INFO - 2022-05-10 13:58:39 --> URI Class Initialized
INFO - 2022-05-10 13:58:39 --> Router Class Initialized
INFO - 2022-05-10 13:58:39 --> Output Class Initialized
INFO - 2022-05-10 13:58:39 --> Security Class Initialized
DEBUG - 2022-05-10 13:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:58:39 --> Input Class Initialized
INFO - 2022-05-10 13:58:39 --> Language Class Initialized
INFO - 2022-05-10 13:58:39 --> Language Class Initialized
INFO - 2022-05-10 13:58:39 --> Config Class Initialized
INFO - 2022-05-10 13:58:39 --> Loader Class Initialized
INFO - 2022-05-10 13:58:39 --> Helper loaded: url_helper
INFO - 2022-05-10 13:58:39 --> Database Driver Class Initialized
INFO - 2022-05-10 13:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:58:39 --> Controller Class Initialized
DEBUG - 2022-05-10 13:58:39 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:58:39 --> Model Class Initialized
DEBUG - 2022-05-10 13:58:39 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:58:39 --> Model Class Initialized
DEBUG - 2022-05-10 13:58:39 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:58:39 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:58:39 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:58:39 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:58:39 --> Final output sent to browser
DEBUG - 2022-05-10 13:58:39 --> Total execution time: 0.0472
INFO - 2022-05-10 13:58:52 --> Config Class Initialized
INFO - 2022-05-10 13:58:52 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:58:52 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:58:52 --> Utf8 Class Initialized
INFO - 2022-05-10 13:58:52 --> URI Class Initialized
INFO - 2022-05-10 13:58:52 --> Router Class Initialized
INFO - 2022-05-10 13:58:52 --> Output Class Initialized
INFO - 2022-05-10 13:58:52 --> Security Class Initialized
DEBUG - 2022-05-10 13:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:58:52 --> Input Class Initialized
INFO - 2022-05-10 13:58:52 --> Language Class Initialized
INFO - 2022-05-10 13:58:52 --> Language Class Initialized
INFO - 2022-05-10 13:58:52 --> Config Class Initialized
INFO - 2022-05-10 13:58:52 --> Loader Class Initialized
INFO - 2022-05-10 13:58:52 --> Helper loaded: url_helper
INFO - 2022-05-10 13:58:52 --> Database Driver Class Initialized
INFO - 2022-05-10 13:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:58:53 --> Controller Class Initialized
DEBUG - 2022-05-10 13:58:53 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:58:53 --> Model Class Initialized
DEBUG - 2022-05-10 13:58:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:58:53 --> Model Class Initialized
DEBUG - 2022-05-10 13:58:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:58:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:58:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:58:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:58:53 --> Final output sent to browser
DEBUG - 2022-05-10 13:58:53 --> Total execution time: 0.0495
INFO - 2022-05-10 13:59:32 --> Config Class Initialized
INFO - 2022-05-10 13:59:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:59:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:59:32 --> Utf8 Class Initialized
INFO - 2022-05-10 13:59:32 --> URI Class Initialized
INFO - 2022-05-10 13:59:32 --> Router Class Initialized
INFO - 2022-05-10 13:59:32 --> Output Class Initialized
INFO - 2022-05-10 13:59:32 --> Security Class Initialized
DEBUG - 2022-05-10 13:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:59:32 --> Input Class Initialized
INFO - 2022-05-10 13:59:32 --> Language Class Initialized
INFO - 2022-05-10 13:59:32 --> Language Class Initialized
INFO - 2022-05-10 13:59:32 --> Config Class Initialized
INFO - 2022-05-10 13:59:32 --> Loader Class Initialized
INFO - 2022-05-10 13:59:32 --> Helper loaded: url_helper
INFO - 2022-05-10 13:59:32 --> Database Driver Class Initialized
INFO - 2022-05-10 13:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:59:32 --> Controller Class Initialized
DEBUG - 2022-05-10 13:59:32 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:59:32 --> Model Class Initialized
DEBUG - 2022-05-10 13:59:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:59:32 --> Model Class Initialized
DEBUG - 2022-05-10 13:59:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:59:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:59:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:59:32 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:59:32 --> Final output sent to browser
DEBUG - 2022-05-10 13:59:32 --> Total execution time: 0.0483
INFO - 2022-05-10 13:59:33 --> Config Class Initialized
INFO - 2022-05-10 13:59:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:59:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:59:33 --> Utf8 Class Initialized
INFO - 2022-05-10 13:59:33 --> URI Class Initialized
INFO - 2022-05-10 13:59:33 --> Router Class Initialized
INFO - 2022-05-10 13:59:33 --> Output Class Initialized
INFO - 2022-05-10 13:59:33 --> Security Class Initialized
DEBUG - 2022-05-10 13:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:59:33 --> Input Class Initialized
INFO - 2022-05-10 13:59:33 --> Language Class Initialized
INFO - 2022-05-10 13:59:33 --> Language Class Initialized
INFO - 2022-05-10 13:59:33 --> Config Class Initialized
INFO - 2022-05-10 13:59:33 --> Loader Class Initialized
INFO - 2022-05-10 13:59:33 --> Helper loaded: url_helper
INFO - 2022-05-10 13:59:33 --> Database Driver Class Initialized
INFO - 2022-05-10 13:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:59:33 --> Controller Class Initialized
DEBUG - 2022-05-10 13:59:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:59:33 --> Model Class Initialized
DEBUG - 2022-05-10 13:59:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:59:33 --> Model Class Initialized
DEBUG - 2022-05-10 13:59:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:59:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:59:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:59:33 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:59:33 --> Final output sent to browser
DEBUG - 2022-05-10 13:59:33 --> Total execution time: 0.0429
INFO - 2022-05-10 13:59:54 --> Config Class Initialized
INFO - 2022-05-10 13:59:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 13:59:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 13:59:54 --> Utf8 Class Initialized
INFO - 2022-05-10 13:59:54 --> URI Class Initialized
INFO - 2022-05-10 13:59:54 --> Router Class Initialized
INFO - 2022-05-10 13:59:54 --> Output Class Initialized
INFO - 2022-05-10 13:59:54 --> Security Class Initialized
DEBUG - 2022-05-10 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 13:59:54 --> Input Class Initialized
INFO - 2022-05-10 13:59:54 --> Language Class Initialized
INFO - 2022-05-10 13:59:54 --> Language Class Initialized
INFO - 2022-05-10 13:59:54 --> Config Class Initialized
INFO - 2022-05-10 13:59:54 --> Loader Class Initialized
INFO - 2022-05-10 13:59:54 --> Helper loaded: url_helper
INFO - 2022-05-10 13:59:54 --> Database Driver Class Initialized
INFO - 2022-05-10 13:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 13:59:54 --> Controller Class Initialized
DEBUG - 2022-05-10 13:59:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 13:59:54 --> Model Class Initialized
DEBUG - 2022-05-10 13:59:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 13:59:54 --> Model Class Initialized
DEBUG - 2022-05-10 13:59:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 13:59:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 13:59:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 13:59:54 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 13:59:54 --> Final output sent to browser
DEBUG - 2022-05-10 13:59:54 --> Total execution time: 0.0502
INFO - 2022-05-10 14:00:20 --> Config Class Initialized
INFO - 2022-05-10 14:00:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:00:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:00:20 --> Utf8 Class Initialized
INFO - 2022-05-10 14:00:20 --> URI Class Initialized
INFO - 2022-05-10 14:00:20 --> Router Class Initialized
INFO - 2022-05-10 14:00:20 --> Output Class Initialized
INFO - 2022-05-10 14:00:20 --> Security Class Initialized
DEBUG - 2022-05-10 14:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:00:20 --> Input Class Initialized
INFO - 2022-05-10 14:00:20 --> Language Class Initialized
INFO - 2022-05-10 14:00:20 --> Language Class Initialized
INFO - 2022-05-10 14:00:20 --> Config Class Initialized
INFO - 2022-05-10 14:00:20 --> Loader Class Initialized
INFO - 2022-05-10 14:00:20 --> Helper loaded: url_helper
INFO - 2022-05-10 14:00:20 --> Database Driver Class Initialized
INFO - 2022-05-10 14:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:00:20 --> Controller Class Initialized
DEBUG - 2022-05-10 14:00:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:00:20 --> Model Class Initialized
DEBUG - 2022-05-10 14:00:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:00:20 --> Model Class Initialized
DEBUG - 2022-05-10 14:00:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:00:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:00:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:00:20 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:00:20 --> Final output sent to browser
DEBUG - 2022-05-10 14:00:20 --> Total execution time: 0.0511
INFO - 2022-05-10 14:00:30 --> Config Class Initialized
INFO - 2022-05-10 14:00:30 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:00:30 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:00:30 --> Utf8 Class Initialized
INFO - 2022-05-10 14:00:30 --> URI Class Initialized
INFO - 2022-05-10 14:00:30 --> Router Class Initialized
INFO - 2022-05-10 14:00:30 --> Output Class Initialized
INFO - 2022-05-10 14:00:30 --> Security Class Initialized
DEBUG - 2022-05-10 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:00:30 --> Input Class Initialized
INFO - 2022-05-10 14:00:30 --> Language Class Initialized
INFO - 2022-05-10 14:00:30 --> Language Class Initialized
INFO - 2022-05-10 14:00:30 --> Config Class Initialized
INFO - 2022-05-10 14:00:30 --> Loader Class Initialized
INFO - 2022-05-10 14:00:30 --> Helper loaded: url_helper
INFO - 2022-05-10 14:00:30 --> Database Driver Class Initialized
INFO - 2022-05-10 14:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:00:30 --> Controller Class Initialized
DEBUG - 2022-05-10 14:00:30 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:00:30 --> Model Class Initialized
DEBUG - 2022-05-10 14:00:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:00:30 --> Model Class Initialized
DEBUG - 2022-05-10 14:00:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:00:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:00:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:00:30 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:00:30 --> Final output sent to browser
DEBUG - 2022-05-10 14:00:30 --> Total execution time: 0.0929
INFO - 2022-05-10 14:02:36 --> Config Class Initialized
INFO - 2022-05-10 14:02:36 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:02:36 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:02:36 --> Utf8 Class Initialized
INFO - 2022-05-10 14:02:36 --> URI Class Initialized
INFO - 2022-05-10 14:02:36 --> Router Class Initialized
INFO - 2022-05-10 14:02:36 --> Output Class Initialized
INFO - 2022-05-10 14:02:36 --> Security Class Initialized
DEBUG - 2022-05-10 14:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:02:36 --> Input Class Initialized
INFO - 2022-05-10 14:02:36 --> Language Class Initialized
INFO - 2022-05-10 14:02:36 --> Language Class Initialized
INFO - 2022-05-10 14:02:36 --> Config Class Initialized
INFO - 2022-05-10 14:02:36 --> Loader Class Initialized
INFO - 2022-05-10 14:02:36 --> Helper loaded: url_helper
INFO - 2022-05-10 14:02:36 --> Database Driver Class Initialized
INFO - 2022-05-10 14:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:02:36 --> Controller Class Initialized
DEBUG - 2022-05-10 14:02:36 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:02:36 --> Model Class Initialized
DEBUG - 2022-05-10 14:02:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:02:36 --> Model Class Initialized
DEBUG - 2022-05-10 14:02:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:02:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:02:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:02:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:02:36 --> Final output sent to browser
DEBUG - 2022-05-10 14:02:36 --> Total execution time: 0.0420
INFO - 2022-05-10 14:02:49 --> Config Class Initialized
INFO - 2022-05-10 14:02:49 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:02:49 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:02:49 --> Utf8 Class Initialized
INFO - 2022-05-10 14:02:49 --> URI Class Initialized
INFO - 2022-05-10 14:02:49 --> Router Class Initialized
INFO - 2022-05-10 14:02:49 --> Output Class Initialized
INFO - 2022-05-10 14:02:49 --> Security Class Initialized
DEBUG - 2022-05-10 14:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:02:49 --> Input Class Initialized
INFO - 2022-05-10 14:02:49 --> Language Class Initialized
INFO - 2022-05-10 14:02:49 --> Language Class Initialized
INFO - 2022-05-10 14:02:49 --> Config Class Initialized
INFO - 2022-05-10 14:02:49 --> Loader Class Initialized
INFO - 2022-05-10 14:02:49 --> Helper loaded: url_helper
INFO - 2022-05-10 14:02:49 --> Database Driver Class Initialized
INFO - 2022-05-10 14:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:02:49 --> Controller Class Initialized
DEBUG - 2022-05-10 14:02:49 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:02:49 --> Model Class Initialized
DEBUG - 2022-05-10 14:02:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:02:49 --> Model Class Initialized
DEBUG - 2022-05-10 14:02:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:02:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:02:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:02:49 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:02:49 --> Final output sent to browser
DEBUG - 2022-05-10 14:02:49 --> Total execution time: 0.0510
INFO - 2022-05-10 14:03:07 --> Config Class Initialized
INFO - 2022-05-10 14:03:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:03:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:03:07 --> Utf8 Class Initialized
INFO - 2022-05-10 14:03:07 --> URI Class Initialized
INFO - 2022-05-10 14:03:07 --> Router Class Initialized
INFO - 2022-05-10 14:03:07 --> Output Class Initialized
INFO - 2022-05-10 14:03:07 --> Security Class Initialized
DEBUG - 2022-05-10 14:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:03:07 --> Input Class Initialized
INFO - 2022-05-10 14:03:07 --> Language Class Initialized
INFO - 2022-05-10 14:03:07 --> Language Class Initialized
INFO - 2022-05-10 14:03:07 --> Config Class Initialized
INFO - 2022-05-10 14:03:07 --> Loader Class Initialized
INFO - 2022-05-10 14:03:07 --> Helper loaded: url_helper
INFO - 2022-05-10 14:03:07 --> Database Driver Class Initialized
INFO - 2022-05-10 14:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:03:07 --> Controller Class Initialized
DEBUG - 2022-05-10 14:03:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:03:07 --> Model Class Initialized
DEBUG - 2022-05-10 14:03:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:03:07 --> Model Class Initialized
DEBUG - 2022-05-10 14:03:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:03:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:03:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:03:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:03:07 --> Final output sent to browser
DEBUG - 2022-05-10 14:03:07 --> Total execution time: 0.0439
INFO - 2022-05-10 14:03:17 --> Config Class Initialized
INFO - 2022-05-10 14:03:17 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:03:17 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:03:17 --> Utf8 Class Initialized
INFO - 2022-05-10 14:03:18 --> URI Class Initialized
INFO - 2022-05-10 14:03:18 --> Router Class Initialized
INFO - 2022-05-10 14:03:18 --> Output Class Initialized
INFO - 2022-05-10 14:03:18 --> Security Class Initialized
DEBUG - 2022-05-10 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:03:18 --> Input Class Initialized
INFO - 2022-05-10 14:03:18 --> Language Class Initialized
INFO - 2022-05-10 14:03:18 --> Language Class Initialized
INFO - 2022-05-10 14:03:18 --> Config Class Initialized
INFO - 2022-05-10 14:03:18 --> Loader Class Initialized
INFO - 2022-05-10 14:03:18 --> Helper loaded: url_helper
INFO - 2022-05-10 14:03:18 --> Database Driver Class Initialized
INFO - 2022-05-10 14:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:03:18 --> Controller Class Initialized
DEBUG - 2022-05-10 14:03:18 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:03:18 --> Model Class Initialized
DEBUG - 2022-05-10 14:03:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:03:18 --> Model Class Initialized
DEBUG - 2022-05-10 14:03:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:03:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:03:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:03:18 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:03:18 --> Final output sent to browser
DEBUG - 2022-05-10 14:03:18 --> Total execution time: 0.0534
INFO - 2022-05-10 14:03:24 --> Config Class Initialized
INFO - 2022-05-10 14:03:24 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:03:24 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:03:24 --> Utf8 Class Initialized
INFO - 2022-05-10 14:03:24 --> URI Class Initialized
INFO - 2022-05-10 14:03:24 --> Router Class Initialized
INFO - 2022-05-10 14:03:24 --> Output Class Initialized
INFO - 2022-05-10 14:03:24 --> Security Class Initialized
DEBUG - 2022-05-10 14:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:03:24 --> Input Class Initialized
INFO - 2022-05-10 14:03:24 --> Language Class Initialized
INFO - 2022-05-10 14:03:24 --> Language Class Initialized
INFO - 2022-05-10 14:03:24 --> Config Class Initialized
INFO - 2022-05-10 14:03:24 --> Loader Class Initialized
INFO - 2022-05-10 14:03:24 --> Helper loaded: url_helper
INFO - 2022-05-10 14:03:24 --> Database Driver Class Initialized
INFO - 2022-05-10 14:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:03:24 --> Controller Class Initialized
DEBUG - 2022-05-10 14:03:24 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:03:24 --> Model Class Initialized
DEBUG - 2022-05-10 14:03:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:03:24 --> Model Class Initialized
DEBUG - 2022-05-10 14:03:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:03:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:03:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:03:24 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:03:24 --> Final output sent to browser
DEBUG - 2022-05-10 14:03:24 --> Total execution time: 0.0432
INFO - 2022-05-10 14:04:01 --> Config Class Initialized
INFO - 2022-05-10 14:04:01 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:04:01 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:01 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:01 --> URI Class Initialized
INFO - 2022-05-10 14:04:01 --> Router Class Initialized
INFO - 2022-05-10 14:04:01 --> Output Class Initialized
INFO - 2022-05-10 14:04:01 --> Security Class Initialized
DEBUG - 2022-05-10 14:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:01 --> Input Class Initialized
INFO - 2022-05-10 14:04:01 --> Language Class Initialized
INFO - 2022-05-10 14:04:01 --> Language Class Initialized
INFO - 2022-05-10 14:04:01 --> Config Class Initialized
INFO - 2022-05-10 14:04:01 --> Loader Class Initialized
INFO - 2022-05-10 14:04:01 --> Helper loaded: url_helper
INFO - 2022-05-10 14:04:01 --> Database Driver Class Initialized
INFO - 2022-05-10 14:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:04:01 --> Controller Class Initialized
DEBUG - 2022-05-10 14:04:01 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:04:01 --> Model Class Initialized
DEBUG - 2022-05-10 14:04:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:04:01 --> Model Class Initialized
DEBUG - 2022-05-10 14:04:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:04:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:04:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:04:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:04:01 --> Final output sent to browser
DEBUG - 2022-05-10 14:04:01 --> Total execution time: 0.0495
INFO - 2022-05-10 14:04:13 --> Config Class Initialized
INFO - 2022-05-10 14:04:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:04:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:13 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:13 --> URI Class Initialized
INFO - 2022-05-10 14:04:13 --> Config Class Initialized
INFO - 2022-05-10 14:04:13 --> Hooks Class Initialized
INFO - 2022-05-10 14:04:13 --> Router Class Initialized
DEBUG - 2022-05-10 14:04:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:13 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:13 --> Output Class Initialized
INFO - 2022-05-10 14:04:13 --> URI Class Initialized
INFO - 2022-05-10 14:04:13 --> Security Class Initialized
DEBUG - 2022-05-10 14:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:13 --> Input Class Initialized
INFO - 2022-05-10 14:04:13 --> Router Class Initialized
INFO - 2022-05-10 14:04:13 --> Language Class Initialized
INFO - 2022-05-10 14:04:13 --> Output Class Initialized
ERROR - 2022-05-10 14:04:13 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:04:13 --> Security Class Initialized
DEBUG - 2022-05-10 14:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:13 --> Input Class Initialized
INFO - 2022-05-10 14:04:13 --> Language Class Initialized
ERROR - 2022-05-10 14:04:13 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:04:13 --> Config Class Initialized
INFO - 2022-05-10 14:04:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:04:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:13 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:13 --> URI Class Initialized
INFO - 2022-05-10 14:04:13 --> Router Class Initialized
INFO - 2022-05-10 14:04:13 --> Output Class Initialized
INFO - 2022-05-10 14:04:13 --> Security Class Initialized
DEBUG - 2022-05-10 14:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:13 --> Input Class Initialized
INFO - 2022-05-10 14:04:13 --> Language Class Initialized
ERROR - 2022-05-10 14:04:13 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:04:40 --> Config Class Initialized
INFO - 2022-05-10 14:04:40 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:04:40 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:40 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:40 --> URI Class Initialized
INFO - 2022-05-10 14:04:40 --> Router Class Initialized
INFO - 2022-05-10 14:04:40 --> Output Class Initialized
INFO - 2022-05-10 14:04:40 --> Security Class Initialized
DEBUG - 2022-05-10 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:40 --> Input Class Initialized
INFO - 2022-05-10 14:04:40 --> Language Class Initialized
INFO - 2022-05-10 14:04:40 --> Language Class Initialized
INFO - 2022-05-10 14:04:40 --> Config Class Initialized
INFO - 2022-05-10 14:04:40 --> Loader Class Initialized
INFO - 2022-05-10 14:04:40 --> Helper loaded: url_helper
INFO - 2022-05-10 14:04:40 --> Database Driver Class Initialized
INFO - 2022-05-10 14:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:04:40 --> Controller Class Initialized
DEBUG - 2022-05-10 14:04:40 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:04:40 --> Model Class Initialized
DEBUG - 2022-05-10 14:04:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:04:40 --> Model Class Initialized
DEBUG - 2022-05-10 14:04:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:04:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:04:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:04:40 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:04:40 --> Final output sent to browser
DEBUG - 2022-05-10 14:04:40 --> Total execution time: 0.0327
INFO - 2022-05-10 14:04:40 --> Config Class Initialized
INFO - 2022-05-10 14:04:40 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:04:40 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:40 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:40 --> URI Class Initialized
INFO - 2022-05-10 14:04:40 --> Router Class Initialized
INFO - 2022-05-10 14:04:40 --> Output Class Initialized
INFO - 2022-05-10 14:04:40 --> Security Class Initialized
DEBUG - 2022-05-10 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:40 --> Input Class Initialized
INFO - 2022-05-10 14:04:40 --> Language Class Initialized
ERROR - 2022-05-10 14:04:40 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:04:40 --> Config Class Initialized
INFO - 2022-05-10 14:04:40 --> Hooks Class Initialized
INFO - 2022-05-10 14:04:40 --> Config Class Initialized
INFO - 2022-05-10 14:04:40 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:04:40 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:40 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:40 --> URI Class Initialized
DEBUG - 2022-05-10 14:04:40 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:04:40 --> Utf8 Class Initialized
INFO - 2022-05-10 14:04:40 --> URI Class Initialized
INFO - 2022-05-10 14:04:40 --> Router Class Initialized
INFO - 2022-05-10 14:04:40 --> Output Class Initialized
INFO - 2022-05-10 14:04:40 --> Router Class Initialized
INFO - 2022-05-10 14:04:40 --> Security Class Initialized
INFO - 2022-05-10 14:04:40 --> Output Class Initialized
DEBUG - 2022-05-10 14:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:04:40 --> Input Class Initialized
INFO - 2022-05-10 14:04:40 --> Security Class Initialized
INFO - 2022-05-10 14:04:40 --> Language Class Initialized
DEBUG - 2022-05-10 14:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 14:04:40 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:04:40 --> Input Class Initialized
INFO - 2022-05-10 14:04:40 --> Language Class Initialized
ERROR - 2022-05-10 14:04:40 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:05:26 --> Config Class Initialized
INFO - 2022-05-10 14:05:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:05:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:05:26 --> Utf8 Class Initialized
INFO - 2022-05-10 14:05:26 --> URI Class Initialized
INFO - 2022-05-10 14:05:26 --> Router Class Initialized
INFO - 2022-05-10 14:05:26 --> Output Class Initialized
INFO - 2022-05-10 14:05:26 --> Security Class Initialized
DEBUG - 2022-05-10 14:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:05:26 --> Input Class Initialized
INFO - 2022-05-10 14:05:26 --> Language Class Initialized
INFO - 2022-05-10 14:05:26 --> Language Class Initialized
INFO - 2022-05-10 14:05:26 --> Config Class Initialized
INFO - 2022-05-10 14:05:26 --> Loader Class Initialized
INFO - 2022-05-10 14:05:26 --> Helper loaded: url_helper
INFO - 2022-05-10 14:05:26 --> Database Driver Class Initialized
INFO - 2022-05-10 14:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:05:26 --> Controller Class Initialized
DEBUG - 2022-05-10 14:05:26 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:05:26 --> Model Class Initialized
DEBUG - 2022-05-10 14:05:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:05:26 --> Model Class Initialized
DEBUG - 2022-05-10 14:05:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:05:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:05:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:05:26 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:05:26 --> Final output sent to browser
DEBUG - 2022-05-10 14:05:26 --> Total execution time: 0.0549
INFO - 2022-05-10 14:05:26 --> Config Class Initialized
INFO - 2022-05-10 14:05:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:05:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:05:26 --> Utf8 Class Initialized
INFO - 2022-05-10 14:05:26 --> URI Class Initialized
INFO - 2022-05-10 14:05:26 --> Router Class Initialized
INFO - 2022-05-10 14:05:26 --> Output Class Initialized
INFO - 2022-05-10 14:05:26 --> Security Class Initialized
DEBUG - 2022-05-10 14:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:05:27 --> Input Class Initialized
INFO - 2022-05-10 14:05:27 --> Language Class Initialized
ERROR - 2022-05-10 14:05:27 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:05:27 --> Config Class Initialized
INFO - 2022-05-10 14:05:27 --> Hooks Class Initialized
INFO - 2022-05-10 14:05:27 --> Config Class Initialized
INFO - 2022-05-10 14:05:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:05:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:05:27 --> Utf8 Class Initialized
INFO - 2022-05-10 14:05:27 --> URI Class Initialized
DEBUG - 2022-05-10 14:05:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:05:27 --> Utf8 Class Initialized
INFO - 2022-05-10 14:05:27 --> URI Class Initialized
INFO - 2022-05-10 14:05:27 --> Router Class Initialized
INFO - 2022-05-10 14:05:27 --> Output Class Initialized
INFO - 2022-05-10 14:05:27 --> Router Class Initialized
INFO - 2022-05-10 14:05:27 --> Security Class Initialized
INFO - 2022-05-10 14:05:27 --> Output Class Initialized
DEBUG - 2022-05-10 14:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:05:27 --> Input Class Initialized
INFO - 2022-05-10 14:05:27 --> Security Class Initialized
INFO - 2022-05-10 14:05:27 --> Language Class Initialized
DEBUG - 2022-05-10 14:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 14:05:27 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:05:27 --> Input Class Initialized
INFO - 2022-05-10 14:05:27 --> Language Class Initialized
ERROR - 2022-05-10 14:05:27 --> 404 Page Not Found: /index
INFO - 2022-05-10 14:06:08 --> Config Class Initialized
INFO - 2022-05-10 14:06:08 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:06:08 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:06:08 --> Utf8 Class Initialized
INFO - 2022-05-10 14:06:08 --> URI Class Initialized
INFO - 2022-05-10 14:06:08 --> Router Class Initialized
INFO - 2022-05-10 14:06:08 --> Output Class Initialized
INFO - 2022-05-10 14:06:08 --> Security Class Initialized
DEBUG - 2022-05-10 14:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:06:08 --> Input Class Initialized
INFO - 2022-05-10 14:06:08 --> Language Class Initialized
INFO - 2022-05-10 14:06:08 --> Language Class Initialized
INFO - 2022-05-10 14:06:08 --> Config Class Initialized
INFO - 2022-05-10 14:06:08 --> Loader Class Initialized
INFO - 2022-05-10 14:06:08 --> Helper loaded: url_helper
INFO - 2022-05-10 14:06:08 --> Database Driver Class Initialized
INFO - 2022-05-10 14:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:06:08 --> Controller Class Initialized
DEBUG - 2022-05-10 14:06:08 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:06:08 --> Model Class Initialized
DEBUG - 2022-05-10 14:06:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:06:08 --> Model Class Initialized
DEBUG - 2022-05-10 14:06:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:06:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:06:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:06:08 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:06:08 --> Final output sent to browser
DEBUG - 2022-05-10 14:06:08 --> Total execution time: 0.0414
INFO - 2022-05-10 14:07:34 --> Config Class Initialized
INFO - 2022-05-10 14:07:34 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:07:34 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:07:34 --> Utf8 Class Initialized
INFO - 2022-05-10 14:07:34 --> URI Class Initialized
INFO - 2022-05-10 14:07:34 --> Router Class Initialized
INFO - 2022-05-10 14:07:34 --> Output Class Initialized
INFO - 2022-05-10 14:07:34 --> Security Class Initialized
DEBUG - 2022-05-10 14:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:07:34 --> Input Class Initialized
INFO - 2022-05-10 14:07:34 --> Language Class Initialized
INFO - 2022-05-10 14:07:34 --> Language Class Initialized
INFO - 2022-05-10 14:07:34 --> Config Class Initialized
INFO - 2022-05-10 14:07:34 --> Loader Class Initialized
INFO - 2022-05-10 14:07:34 --> Helper loaded: url_helper
INFO - 2022-05-10 14:07:34 --> Database Driver Class Initialized
INFO - 2022-05-10 14:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:07:34 --> Controller Class Initialized
DEBUG - 2022-05-10 14:07:34 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:07:34 --> Model Class Initialized
DEBUG - 2022-05-10 14:07:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:07:34 --> Model Class Initialized
DEBUG - 2022-05-10 14:07:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:07:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:07:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:07:34 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:07:34 --> Final output sent to browser
DEBUG - 2022-05-10 14:07:34 --> Total execution time: 0.0514
INFO - 2022-05-10 14:07:53 --> Config Class Initialized
INFO - 2022-05-10 14:07:53 --> Hooks Class Initialized
DEBUG - 2022-05-10 14:07:53 --> UTF-8 Support Enabled
INFO - 2022-05-10 14:07:53 --> Utf8 Class Initialized
INFO - 2022-05-10 14:07:53 --> URI Class Initialized
INFO - 2022-05-10 14:07:53 --> Router Class Initialized
INFO - 2022-05-10 14:07:53 --> Output Class Initialized
INFO - 2022-05-10 14:07:53 --> Security Class Initialized
DEBUG - 2022-05-10 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 14:07:53 --> Input Class Initialized
INFO - 2022-05-10 14:07:53 --> Language Class Initialized
INFO - 2022-05-10 14:07:53 --> Language Class Initialized
INFO - 2022-05-10 14:07:53 --> Config Class Initialized
INFO - 2022-05-10 14:07:53 --> Loader Class Initialized
INFO - 2022-05-10 14:07:53 --> Helper loaded: url_helper
INFO - 2022-05-10 14:07:53 --> Database Driver Class Initialized
INFO - 2022-05-10 14:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 14:07:53 --> Controller Class Initialized
DEBUG - 2022-05-10 14:07:53 --> Admin MX_Controller Initialized
INFO - 2022-05-10 14:07:53 --> Model Class Initialized
DEBUG - 2022-05-10 14:07:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 14:07:53 --> Model Class Initialized
DEBUG - 2022-05-10 14:07:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 14:07:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 14:07:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 14:07:53 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 14:07:53 --> Final output sent to browser
DEBUG - 2022-05-10 14:07:53 --> Total execution time: 0.0502
INFO - 2022-05-10 15:18:06 --> Config Class Initialized
INFO - 2022-05-10 15:18:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:18:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:18:06 --> Utf8 Class Initialized
INFO - 2022-05-10 15:18:06 --> URI Class Initialized
INFO - 2022-05-10 15:18:06 --> Router Class Initialized
INFO - 2022-05-10 15:18:06 --> Output Class Initialized
INFO - 2022-05-10 15:18:06 --> Security Class Initialized
DEBUG - 2022-05-10 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:18:06 --> Input Class Initialized
INFO - 2022-05-10 15:18:06 --> Language Class Initialized
INFO - 2022-05-10 15:18:06 --> Language Class Initialized
INFO - 2022-05-10 15:18:06 --> Config Class Initialized
INFO - 2022-05-10 15:18:06 --> Loader Class Initialized
INFO - 2022-05-10 15:18:06 --> Helper loaded: url_helper
INFO - 2022-05-10 15:18:06 --> Database Driver Class Initialized
INFO - 2022-05-10 15:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:18:06 --> Controller Class Initialized
DEBUG - 2022-05-10 15:18:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:18:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:18:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:18:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:18:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:18:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:18:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 15:18:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:18:06 --> Final output sent to browser
DEBUG - 2022-05-10 15:18:06 --> Total execution time: 0.0470
INFO - 2022-05-10 15:19:01 --> Config Class Initialized
INFO - 2022-05-10 15:19:01 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:19:01 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:19:01 --> Utf8 Class Initialized
INFO - 2022-05-10 15:19:01 --> URI Class Initialized
INFO - 2022-05-10 15:19:01 --> Router Class Initialized
INFO - 2022-05-10 15:19:01 --> Output Class Initialized
INFO - 2022-05-10 15:19:01 --> Security Class Initialized
DEBUG - 2022-05-10 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:19:01 --> Input Class Initialized
INFO - 2022-05-10 15:19:01 --> Language Class Initialized
INFO - 2022-05-10 15:19:01 --> Language Class Initialized
INFO - 2022-05-10 15:19:01 --> Config Class Initialized
INFO - 2022-05-10 15:19:01 --> Loader Class Initialized
INFO - 2022-05-10 15:19:01 --> Helper loaded: url_helper
INFO - 2022-05-10 15:19:01 --> Database Driver Class Initialized
INFO - 2022-05-10 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:19:01 --> Controller Class Initialized
DEBUG - 2022-05-10 15:19:01 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:19:01 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:19:01 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:19:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:19:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 15:19:01 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:19:01 --> Final output sent to browser
DEBUG - 2022-05-10 15:19:01 --> Total execution time: 0.0420
INFO - 2022-05-10 15:19:04 --> Config Class Initialized
INFO - 2022-05-10 15:19:04 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:19:04 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:19:04 --> Utf8 Class Initialized
INFO - 2022-05-10 15:19:04 --> URI Class Initialized
INFO - 2022-05-10 15:19:04 --> Router Class Initialized
INFO - 2022-05-10 15:19:04 --> Output Class Initialized
INFO - 2022-05-10 15:19:04 --> Security Class Initialized
DEBUG - 2022-05-10 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:19:04 --> Input Class Initialized
INFO - 2022-05-10 15:19:04 --> Language Class Initialized
INFO - 2022-05-10 15:19:04 --> Language Class Initialized
INFO - 2022-05-10 15:19:04 --> Config Class Initialized
INFO - 2022-05-10 15:19:04 --> Loader Class Initialized
INFO - 2022-05-10 15:19:04 --> Helper loaded: url_helper
INFO - 2022-05-10 15:19:04 --> Database Driver Class Initialized
INFO - 2022-05-10 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:19:04 --> Controller Class Initialized
DEBUG - 2022-05-10 15:19:04 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:19:04 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:19:04 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:19:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:19:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 15:19:04 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:19:04 --> Final output sent to browser
DEBUG - 2022-05-10 15:19:04 --> Total execution time: 0.0458
INFO - 2022-05-10 15:19:06 --> Config Class Initialized
INFO - 2022-05-10 15:19:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:19:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:19:06 --> Utf8 Class Initialized
INFO - 2022-05-10 15:19:06 --> URI Class Initialized
INFO - 2022-05-10 15:19:06 --> Router Class Initialized
INFO - 2022-05-10 15:19:06 --> Output Class Initialized
INFO - 2022-05-10 15:19:06 --> Security Class Initialized
DEBUG - 2022-05-10 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:19:06 --> Input Class Initialized
INFO - 2022-05-10 15:19:06 --> Language Class Initialized
INFO - 2022-05-10 15:19:06 --> Language Class Initialized
INFO - 2022-05-10 15:19:06 --> Config Class Initialized
INFO - 2022-05-10 15:19:06 --> Loader Class Initialized
INFO - 2022-05-10 15:19:06 --> Helper loaded: url_helper
INFO - 2022-05-10 15:19:06 --> Database Driver Class Initialized
INFO - 2022-05-10 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:19:06 --> Controller Class Initialized
DEBUG - 2022-05-10 15:19:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:19:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:19:06 --> Model Class Initialized
INFO - 2022-05-10 15:19:06 --> Config Class Initialized
INFO - 2022-05-10 15:19:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:19:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:19:06 --> Utf8 Class Initialized
INFO - 2022-05-10 15:19:06 --> URI Class Initialized
INFO - 2022-05-10 15:19:06 --> Router Class Initialized
INFO - 2022-05-10 15:19:06 --> Output Class Initialized
INFO - 2022-05-10 15:19:06 --> Security Class Initialized
DEBUG - 2022-05-10 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:19:06 --> Input Class Initialized
INFO - 2022-05-10 15:19:06 --> Language Class Initialized
INFO - 2022-05-10 15:19:06 --> Language Class Initialized
INFO - 2022-05-10 15:19:06 --> Config Class Initialized
INFO - 2022-05-10 15:19:06 --> Loader Class Initialized
INFO - 2022-05-10 15:19:06 --> Helper loaded: url_helper
INFO - 2022-05-10 15:19:06 --> Database Driver Class Initialized
INFO - 2022-05-10 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:19:06 --> Controller Class Initialized
DEBUG - 2022-05-10 15:19:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:19:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:19:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 15:19:06 --> Final output sent to browser
DEBUG - 2022-05-10 15:19:06 --> Total execution time: 0.0563
INFO - 2022-05-10 15:19:13 --> Config Class Initialized
INFO - 2022-05-10 15:19:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:19:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:19:13 --> Utf8 Class Initialized
INFO - 2022-05-10 15:19:13 --> URI Class Initialized
INFO - 2022-05-10 15:19:13 --> Router Class Initialized
INFO - 2022-05-10 15:19:13 --> Output Class Initialized
INFO - 2022-05-10 15:19:13 --> Security Class Initialized
DEBUG - 2022-05-10 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:19:13 --> Input Class Initialized
INFO - 2022-05-10 15:19:13 --> Language Class Initialized
INFO - 2022-05-10 15:19:13 --> Language Class Initialized
INFO - 2022-05-10 15:19:13 --> Config Class Initialized
INFO - 2022-05-10 15:19:13 --> Loader Class Initialized
INFO - 2022-05-10 15:19:13 --> Helper loaded: url_helper
INFO - 2022-05-10 15:19:13 --> Database Driver Class Initialized
INFO - 2022-05-10 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:19:13 --> Controller Class Initialized
DEBUG - 2022-05-10 15:19:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:19:13 --> Model Class Initialized
DEBUG - 2022-05-10 15:19:13 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:19:13 --> Model Class Initialized
ERROR - 2022-05-10 15:19:13 --> Query error: Unknown column 'r_mail' in 'where clause' - Invalid query: SELECT *
FROM `register`
WHERE `r_mail` = 'admin@gmail.com'
AND `r_pass` = 'admin'
INFO - 2022-05-10 15:19:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 15:20:19 --> Config Class Initialized
INFO - 2022-05-10 15:20:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:20:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:20:19 --> Utf8 Class Initialized
INFO - 2022-05-10 15:20:19 --> URI Class Initialized
INFO - 2022-05-10 15:20:19 --> Router Class Initialized
INFO - 2022-05-10 15:20:19 --> Output Class Initialized
INFO - 2022-05-10 15:20:19 --> Security Class Initialized
DEBUG - 2022-05-10 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:20:19 --> Input Class Initialized
INFO - 2022-05-10 15:20:19 --> Language Class Initialized
INFO - 2022-05-10 15:20:19 --> Language Class Initialized
INFO - 2022-05-10 15:20:19 --> Config Class Initialized
INFO - 2022-05-10 15:20:19 --> Loader Class Initialized
INFO - 2022-05-10 15:20:19 --> Helper loaded: url_helper
INFO - 2022-05-10 15:20:19 --> Database Driver Class Initialized
INFO - 2022-05-10 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:20:19 --> Controller Class Initialized
DEBUG - 2022-05-10 15:20:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:20:19 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:20:19 --> Model Class Initialized
INFO - 2022-05-10 15:20:19 --> Config Class Initialized
INFO - 2022-05-10 15:20:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:20:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:20:19 --> Utf8 Class Initialized
INFO - 2022-05-10 15:20:19 --> URI Class Initialized
INFO - 2022-05-10 15:20:19 --> Router Class Initialized
INFO - 2022-05-10 15:20:19 --> Output Class Initialized
INFO - 2022-05-10 15:20:19 --> Security Class Initialized
DEBUG - 2022-05-10 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:20:19 --> Input Class Initialized
INFO - 2022-05-10 15:20:19 --> Language Class Initialized
INFO - 2022-05-10 15:20:19 --> Language Class Initialized
INFO - 2022-05-10 15:20:19 --> Config Class Initialized
INFO - 2022-05-10 15:20:19 --> Loader Class Initialized
INFO - 2022-05-10 15:20:19 --> Helper loaded: url_helper
INFO - 2022-05-10 15:20:19 --> Database Driver Class Initialized
INFO - 2022-05-10 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:20:19 --> Controller Class Initialized
DEBUG - 2022-05-10 15:20:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:20:19 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:20:19 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 15:20:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:20:19 --> Final output sent to browser
DEBUG - 2022-05-10 15:20:19 --> Total execution time: 0.0413
INFO - 2022-05-10 15:20:21 --> Config Class Initialized
INFO - 2022-05-10 15:20:21 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:20:22 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:20:22 --> Utf8 Class Initialized
INFO - 2022-05-10 15:20:22 --> URI Class Initialized
INFO - 2022-05-10 15:20:22 --> Router Class Initialized
INFO - 2022-05-10 15:20:22 --> Output Class Initialized
INFO - 2022-05-10 15:20:22 --> Security Class Initialized
DEBUG - 2022-05-10 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:20:22 --> Input Class Initialized
INFO - 2022-05-10 15:20:22 --> Language Class Initialized
INFO - 2022-05-10 15:20:22 --> Language Class Initialized
INFO - 2022-05-10 15:20:22 --> Config Class Initialized
INFO - 2022-05-10 15:20:22 --> Loader Class Initialized
INFO - 2022-05-10 15:20:22 --> Helper loaded: url_helper
INFO - 2022-05-10 15:20:22 --> Database Driver Class Initialized
INFO - 2022-05-10 15:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:20:22 --> Controller Class Initialized
DEBUG - 2022-05-10 15:20:22 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:20:22 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:22 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:20:22 --> Model Class Initialized
INFO - 2022-05-10 15:20:22 --> Config Class Initialized
INFO - 2022-05-10 15:20:22 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:20:22 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:20:22 --> Utf8 Class Initialized
INFO - 2022-05-10 15:20:22 --> URI Class Initialized
INFO - 2022-05-10 15:20:22 --> Router Class Initialized
INFO - 2022-05-10 15:20:22 --> Output Class Initialized
INFO - 2022-05-10 15:20:22 --> Security Class Initialized
DEBUG - 2022-05-10 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:20:22 --> Input Class Initialized
INFO - 2022-05-10 15:20:22 --> Language Class Initialized
INFO - 2022-05-10 15:20:22 --> Language Class Initialized
INFO - 2022-05-10 15:20:22 --> Config Class Initialized
INFO - 2022-05-10 15:20:22 --> Loader Class Initialized
INFO - 2022-05-10 15:20:22 --> Helper loaded: url_helper
INFO - 2022-05-10 15:20:22 --> Database Driver Class Initialized
INFO - 2022-05-10 15:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:20:22 --> Controller Class Initialized
DEBUG - 2022-05-10 15:20:22 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:20:22 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:22 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:20:22 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:22 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 15:20:22 --> Final output sent to browser
DEBUG - 2022-05-10 15:20:22 --> Total execution time: 0.0287
INFO - 2022-05-10 15:20:27 --> Config Class Initialized
INFO - 2022-05-10 15:20:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:20:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:20:27 --> Utf8 Class Initialized
INFO - 2022-05-10 15:20:27 --> URI Class Initialized
INFO - 2022-05-10 15:20:27 --> Router Class Initialized
INFO - 2022-05-10 15:20:27 --> Output Class Initialized
INFO - 2022-05-10 15:20:27 --> Security Class Initialized
DEBUG - 2022-05-10 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:20:27 --> Input Class Initialized
INFO - 2022-05-10 15:20:27 --> Language Class Initialized
INFO - 2022-05-10 15:20:27 --> Language Class Initialized
INFO - 2022-05-10 15:20:27 --> Config Class Initialized
INFO - 2022-05-10 15:20:27 --> Loader Class Initialized
INFO - 2022-05-10 15:20:27 --> Helper loaded: url_helper
INFO - 2022-05-10 15:20:27 --> Database Driver Class Initialized
INFO - 2022-05-10 15:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:20:27 --> Controller Class Initialized
DEBUG - 2022-05-10 15:20:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:20:27 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:20:27 --> Model Class Initialized
INFO - 2022-05-10 15:20:27 --> Config Class Initialized
INFO - 2022-05-10 15:20:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:20:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:20:27 --> Utf8 Class Initialized
INFO - 2022-05-10 15:20:27 --> URI Class Initialized
INFO - 2022-05-10 15:20:27 --> Router Class Initialized
INFO - 2022-05-10 15:20:27 --> Output Class Initialized
INFO - 2022-05-10 15:20:27 --> Security Class Initialized
DEBUG - 2022-05-10 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:20:27 --> Input Class Initialized
INFO - 2022-05-10 15:20:27 --> Language Class Initialized
INFO - 2022-05-10 15:20:27 --> Language Class Initialized
INFO - 2022-05-10 15:20:27 --> Config Class Initialized
INFO - 2022-05-10 15:20:27 --> Loader Class Initialized
INFO - 2022-05-10 15:20:27 --> Helper loaded: url_helper
INFO - 2022-05-10 15:20:27 --> Database Driver Class Initialized
INFO - 2022-05-10 15:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:20:27 --> Controller Class Initialized
DEBUG - 2022-05-10 15:20:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:20:27 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:20:27 --> Model Class Initialized
DEBUG - 2022-05-10 15:20:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:20:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:20:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 15:20:27 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:20:27 --> Final output sent to browser
DEBUG - 2022-05-10 15:20:27 --> Total execution time: 0.0400
INFO - 2022-05-10 15:21:06 --> Config Class Initialized
INFO - 2022-05-10 15:21:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:06 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:06 --> URI Class Initialized
INFO - 2022-05-10 15:21:06 --> Router Class Initialized
INFO - 2022-05-10 15:21:06 --> Output Class Initialized
INFO - 2022-05-10 15:21:06 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:06 --> Input Class Initialized
INFO - 2022-05-10 15:21:06 --> Language Class Initialized
INFO - 2022-05-10 15:21:06 --> Language Class Initialized
INFO - 2022-05-10 15:21:06 --> Config Class Initialized
INFO - 2022-05-10 15:21:06 --> Loader Class Initialized
INFO - 2022-05-10 15:21:06 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:06 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:06 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:06 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:21:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:21:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 15:21:06 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:21:06 --> Final output sent to browser
DEBUG - 2022-05-10 15:21:06 --> Total execution time: 0.0407
INFO - 2022-05-10 15:21:11 --> Config Class Initialized
INFO - 2022-05-10 15:21:11 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:11 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:11 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:11 --> URI Class Initialized
INFO - 2022-05-10 15:21:11 --> Router Class Initialized
INFO - 2022-05-10 15:21:11 --> Output Class Initialized
INFO - 2022-05-10 15:21:11 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:11 --> Input Class Initialized
INFO - 2022-05-10 15:21:11 --> Language Class Initialized
INFO - 2022-05-10 15:21:11 --> Language Class Initialized
INFO - 2022-05-10 15:21:11 --> Config Class Initialized
INFO - 2022-05-10 15:21:11 --> Loader Class Initialized
INFO - 2022-05-10 15:21:11 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:11 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:11 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:11 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:11 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:11 --> Model Class Initialized
INFO - 2022-05-10 15:21:11 --> Config Class Initialized
INFO - 2022-05-10 15:21:11 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:11 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:11 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:11 --> URI Class Initialized
INFO - 2022-05-10 15:21:11 --> Router Class Initialized
INFO - 2022-05-10 15:21:11 --> Output Class Initialized
INFO - 2022-05-10 15:21:11 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:11 --> Input Class Initialized
INFO - 2022-05-10 15:21:11 --> Language Class Initialized
INFO - 2022-05-10 15:21:11 --> Language Class Initialized
INFO - 2022-05-10 15:21:11 --> Config Class Initialized
INFO - 2022-05-10 15:21:11 --> Loader Class Initialized
INFO - 2022-05-10 15:21:11 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:11 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:11 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:11 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:11 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:11 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:11 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 15:21:11 --> Final output sent to browser
DEBUG - 2022-05-10 15:21:11 --> Total execution time: 0.0493
INFO - 2022-05-10 15:21:14 --> Config Class Initialized
INFO - 2022-05-10 15:21:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:14 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:14 --> URI Class Initialized
INFO - 2022-05-10 15:21:14 --> Router Class Initialized
INFO - 2022-05-10 15:21:14 --> Output Class Initialized
INFO - 2022-05-10 15:21:14 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:14 --> Input Class Initialized
INFO - 2022-05-10 15:21:14 --> Language Class Initialized
INFO - 2022-05-10 15:21:14 --> Language Class Initialized
INFO - 2022-05-10 15:21:14 --> Config Class Initialized
INFO - 2022-05-10 15:21:14 --> Loader Class Initialized
INFO - 2022-05-10 15:21:14 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:14 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:14 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:14 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:14 --> Model Class Initialized
INFO - 2022-05-10 15:21:14 --> Config Class Initialized
INFO - 2022-05-10 15:21:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:14 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:14 --> URI Class Initialized
INFO - 2022-05-10 15:21:14 --> Router Class Initialized
INFO - 2022-05-10 15:21:14 --> Output Class Initialized
INFO - 2022-05-10 15:21:14 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:14 --> Input Class Initialized
INFO - 2022-05-10 15:21:14 --> Language Class Initialized
INFO - 2022-05-10 15:21:14 --> Language Class Initialized
INFO - 2022-05-10 15:21:14 --> Config Class Initialized
INFO - 2022-05-10 15:21:14 --> Loader Class Initialized
INFO - 2022-05-10 15:21:14 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:14 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:14 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:14 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:14 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:14 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 15:21:14 --> Final output sent to browser
DEBUG - 2022-05-10 15:21:14 --> Total execution time: 0.0617
INFO - 2022-05-10 15:21:19 --> Config Class Initialized
INFO - 2022-05-10 15:21:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:19 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:19 --> URI Class Initialized
INFO - 2022-05-10 15:21:19 --> Router Class Initialized
INFO - 2022-05-10 15:21:19 --> Output Class Initialized
INFO - 2022-05-10 15:21:19 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:19 --> Input Class Initialized
INFO - 2022-05-10 15:21:19 --> Language Class Initialized
INFO - 2022-05-10 15:21:19 --> Language Class Initialized
INFO - 2022-05-10 15:21:19 --> Config Class Initialized
INFO - 2022-05-10 15:21:19 --> Loader Class Initialized
INFO - 2022-05-10 15:21:19 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:19 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:19 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:19 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:19 --> Model Class Initialized
INFO - 2022-05-10 15:21:19 --> Config Class Initialized
INFO - 2022-05-10 15:21:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:19 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:19 --> URI Class Initialized
INFO - 2022-05-10 15:21:19 --> Router Class Initialized
INFO - 2022-05-10 15:21:19 --> Output Class Initialized
INFO - 2022-05-10 15:21:19 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:19 --> Input Class Initialized
INFO - 2022-05-10 15:21:19 --> Language Class Initialized
INFO - 2022-05-10 15:21:19 --> Language Class Initialized
INFO - 2022-05-10 15:21:19 --> Config Class Initialized
INFO - 2022-05-10 15:21:19 --> Loader Class Initialized
INFO - 2022-05-10 15:21:19 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:19 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:19 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:19 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:19 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:21:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:21:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 15:21:19 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:21:19 --> Final output sent to browser
DEBUG - 2022-05-10 15:21:19 --> Total execution time: 0.0283
INFO - 2022-05-10 15:21:23 --> Config Class Initialized
INFO - 2022-05-10 15:21:23 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:21:23 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:21:23 --> Utf8 Class Initialized
INFO - 2022-05-10 15:21:23 --> URI Class Initialized
INFO - 2022-05-10 15:21:23 --> Router Class Initialized
INFO - 2022-05-10 15:21:23 --> Output Class Initialized
INFO - 2022-05-10 15:21:23 --> Security Class Initialized
DEBUG - 2022-05-10 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:21:23 --> Input Class Initialized
INFO - 2022-05-10 15:21:23 --> Language Class Initialized
INFO - 2022-05-10 15:21:23 --> Language Class Initialized
INFO - 2022-05-10 15:21:23 --> Config Class Initialized
INFO - 2022-05-10 15:21:23 --> Loader Class Initialized
INFO - 2022-05-10 15:21:23 --> Helper loaded: url_helper
INFO - 2022-05-10 15:21:23 --> Database Driver Class Initialized
INFO - 2022-05-10 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:21:23 --> Controller Class Initialized
DEBUG - 2022-05-10 15:21:23 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:21:23 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:21:23 --> Model Class Initialized
DEBUG - 2022-05-10 15:21:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:21:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:21:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 15:21:23 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:21:23 --> Final output sent to browser
DEBUG - 2022-05-10 15:21:23 --> Total execution time: 0.0422
INFO - 2022-05-10 15:23:07 --> Config Class Initialized
INFO - 2022-05-10 15:23:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:23:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:23:07 --> Utf8 Class Initialized
INFO - 2022-05-10 15:23:07 --> URI Class Initialized
INFO - 2022-05-10 15:23:07 --> Router Class Initialized
INFO - 2022-05-10 15:23:07 --> Output Class Initialized
INFO - 2022-05-10 15:23:07 --> Security Class Initialized
DEBUG - 2022-05-10 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:23:07 --> Input Class Initialized
INFO - 2022-05-10 15:23:07 --> Language Class Initialized
INFO - 2022-05-10 15:23:07 --> Language Class Initialized
INFO - 2022-05-10 15:23:07 --> Config Class Initialized
INFO - 2022-05-10 15:23:07 --> Loader Class Initialized
INFO - 2022-05-10 15:23:07 --> Helper loaded: url_helper
INFO - 2022-05-10 15:23:07 --> Database Driver Class Initialized
INFO - 2022-05-10 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:23:07 --> Controller Class Initialized
DEBUG - 2022-05-10 15:23:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:23:07 --> Model Class Initialized
DEBUG - 2022-05-10 15:23:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:23:07 --> Model Class Initialized
DEBUG - 2022-05-10 15:23:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 15:23:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 15:23:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/add_car.php
DEBUG - 2022-05-10 15:23:07 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 15:23:07 --> Final output sent to browser
DEBUG - 2022-05-10 15:23:07 --> Total execution time: 0.0489
INFO - 2022-05-10 15:23:09 --> Config Class Initialized
INFO - 2022-05-10 15:23:09 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:23:09 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:23:09 --> Utf8 Class Initialized
INFO - 2022-05-10 15:23:09 --> URI Class Initialized
INFO - 2022-05-10 15:23:09 --> Router Class Initialized
INFO - 2022-05-10 15:23:09 --> Output Class Initialized
INFO - 2022-05-10 15:23:09 --> Security Class Initialized
DEBUG - 2022-05-10 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:23:09 --> Input Class Initialized
INFO - 2022-05-10 15:23:09 --> Language Class Initialized
ERROR - 2022-05-10 15:23:09 --> 404 Page Not Found: /index
INFO - 2022-05-10 15:23:09 --> Config Class Initialized
INFO - 2022-05-10 15:23:09 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:23:09 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:23:09 --> Utf8 Class Initialized
INFO - 2022-05-10 15:23:09 --> URI Class Initialized
INFO - 2022-05-10 15:23:09 --> Router Class Initialized
INFO - 2022-05-10 15:23:09 --> Output Class Initialized
INFO - 2022-05-10 15:23:09 --> Security Class Initialized
DEBUG - 2022-05-10 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:23:09 --> Input Class Initialized
INFO - 2022-05-10 15:23:09 --> Language Class Initialized
ERROR - 2022-05-10 15:23:09 --> 404 Page Not Found: /index
INFO - 2022-05-10 15:23:10 --> Config Class Initialized
INFO - 2022-05-10 15:23:10 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:23:10 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:23:10 --> Utf8 Class Initialized
INFO - 2022-05-10 15:23:10 --> URI Class Initialized
INFO - 2022-05-10 15:23:10 --> Router Class Initialized
INFO - 2022-05-10 15:23:10 --> Output Class Initialized
INFO - 2022-05-10 15:23:10 --> Security Class Initialized
DEBUG - 2022-05-10 15:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:23:10 --> Input Class Initialized
INFO - 2022-05-10 15:23:10 --> Language Class Initialized
ERROR - 2022-05-10 15:23:10 --> 404 Page Not Found: /index
INFO - 2022-05-10 15:23:35 --> Config Class Initialized
INFO - 2022-05-10 15:23:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:23:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:23:35 --> Utf8 Class Initialized
INFO - 2022-05-10 15:23:35 --> URI Class Initialized
INFO - 2022-05-10 15:23:35 --> Router Class Initialized
INFO - 2022-05-10 15:23:35 --> Output Class Initialized
INFO - 2022-05-10 15:23:35 --> Security Class Initialized
DEBUG - 2022-05-10 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:23:35 --> Input Class Initialized
INFO - 2022-05-10 15:23:35 --> Language Class Initialized
INFO - 2022-05-10 15:23:35 --> Language Class Initialized
INFO - 2022-05-10 15:23:35 --> Config Class Initialized
INFO - 2022-05-10 15:23:35 --> Loader Class Initialized
INFO - 2022-05-10 15:23:35 --> Helper loaded: url_helper
INFO - 2022-05-10 15:23:35 --> Database Driver Class Initialized
INFO - 2022-05-10 15:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:23:35 --> Controller Class Initialized
DEBUG - 2022-05-10 15:23:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:23:35 --> Model Class Initialized
DEBUG - 2022-05-10 15:23:35 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:23:35 --> Model Class Initialized
INFO - 2022-05-10 15:23:35 --> Config Class Initialized
INFO - 2022-05-10 15:23:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 15:23:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 15:23:35 --> Utf8 Class Initialized
INFO - 2022-05-10 15:23:35 --> URI Class Initialized
INFO - 2022-05-10 15:23:35 --> Router Class Initialized
INFO - 2022-05-10 15:23:35 --> Output Class Initialized
INFO - 2022-05-10 15:23:35 --> Security Class Initialized
DEBUG - 2022-05-10 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 15:23:35 --> Input Class Initialized
INFO - 2022-05-10 15:23:35 --> Language Class Initialized
INFO - 2022-05-10 15:23:35 --> Language Class Initialized
INFO - 2022-05-10 15:23:35 --> Config Class Initialized
INFO - 2022-05-10 15:23:35 --> Loader Class Initialized
INFO - 2022-05-10 15:23:35 --> Helper loaded: url_helper
INFO - 2022-05-10 15:23:36 --> Database Driver Class Initialized
INFO - 2022-05-10 15:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 15:23:36 --> Controller Class Initialized
DEBUG - 2022-05-10 15:23:36 --> Admin MX_Controller Initialized
INFO - 2022-05-10 15:23:36 --> Model Class Initialized
DEBUG - 2022-05-10 15:23:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 15:23:36 --> Model Class Initialized
DEBUG - 2022-05-10 15:23:36 --> File loaded: C:\xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 15:23:36 --> Final output sent to browser
DEBUG - 2022-05-10 15:23:36 --> Total execution time: 0.0591
INFO - 2022-05-10 19:04:33 --> Config Class Initialized
INFO - 2022-05-10 19:04:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:04:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:04:33 --> Utf8 Class Initialized
INFO - 2022-05-10 19:04:33 --> URI Class Initialized
DEBUG - 2022-05-10 19:04:33 --> No URI present. Default controller set.
INFO - 2022-05-10 19:04:33 --> Router Class Initialized
INFO - 2022-05-10 19:04:33 --> Output Class Initialized
INFO - 2022-05-10 19:04:33 --> Security Class Initialized
DEBUG - 2022-05-10 19:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:04:33 --> Input Class Initialized
INFO - 2022-05-10 19:04:33 --> Language Class Initialized
INFO - 2022-05-10 19:04:33 --> Language Class Initialized
INFO - 2022-05-10 19:04:33 --> Config Class Initialized
INFO - 2022-05-10 19:04:33 --> Loader Class Initialized
INFO - 2022-05-10 19:04:33 --> Helper loaded: url_helper
INFO - 2022-05-10 19:04:33 --> Database Driver Class Initialized
INFO - 2022-05-10 19:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:04:33 --> Controller Class Initialized
DEBUG - 2022-05-10 19:04:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:04:33 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:04:33 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 19:04:33 --> Final output sent to browser
DEBUG - 2022-05-10 19:04:33 --> Total execution time: 0.0623
INFO - 2022-05-10 19:04:43 --> Config Class Initialized
INFO - 2022-05-10 19:04:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:04:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:04:43 --> Utf8 Class Initialized
INFO - 2022-05-10 19:04:43 --> URI Class Initialized
INFO - 2022-05-10 19:04:43 --> Router Class Initialized
INFO - 2022-05-10 19:04:43 --> Output Class Initialized
INFO - 2022-05-10 19:04:43 --> Security Class Initialized
DEBUG - 2022-05-10 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:04:43 --> Input Class Initialized
INFO - 2022-05-10 19:04:43 --> Language Class Initialized
INFO - 2022-05-10 19:04:43 --> Language Class Initialized
INFO - 2022-05-10 19:04:43 --> Config Class Initialized
INFO - 2022-05-10 19:04:43 --> Loader Class Initialized
INFO - 2022-05-10 19:04:43 --> Helper loaded: url_helper
INFO - 2022-05-10 19:04:43 --> Database Driver Class Initialized
INFO - 2022-05-10 19:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:04:43 --> Controller Class Initialized
DEBUG - 2022-05-10 19:04:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:04:43 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:04:43 --> Model Class Initialized
INFO - 2022-05-10 19:04:43 --> Config Class Initialized
INFO - 2022-05-10 19:04:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:04:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:04:43 --> Utf8 Class Initialized
INFO - 2022-05-10 19:04:43 --> URI Class Initialized
INFO - 2022-05-10 19:04:43 --> Router Class Initialized
INFO - 2022-05-10 19:04:43 --> Output Class Initialized
INFO - 2022-05-10 19:04:43 --> Security Class Initialized
DEBUG - 2022-05-10 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:04:43 --> Input Class Initialized
INFO - 2022-05-10 19:04:43 --> Language Class Initialized
INFO - 2022-05-10 19:04:43 --> Language Class Initialized
INFO - 2022-05-10 19:04:43 --> Config Class Initialized
INFO - 2022-05-10 19:04:43 --> Loader Class Initialized
INFO - 2022-05-10 19:04:43 --> Helper loaded: url_helper
INFO - 2022-05-10 19:04:43 --> Database Driver Class Initialized
INFO - 2022-05-10 19:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:04:43 --> Controller Class Initialized
DEBUG - 2022-05-10 19:04:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:04:43 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:04:43 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-10 19:04:43 --> Final output sent to browser
DEBUG - 2022-05-10 19:04:43 --> Total execution time: 0.0734
INFO - 2022-05-10 19:04:56 --> Config Class Initialized
INFO - 2022-05-10 19:04:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:04:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:04:56 --> Utf8 Class Initialized
INFO - 2022-05-10 19:04:56 --> URI Class Initialized
INFO - 2022-05-10 19:04:56 --> Router Class Initialized
INFO - 2022-05-10 19:04:56 --> Output Class Initialized
INFO - 2022-05-10 19:04:56 --> Security Class Initialized
DEBUG - 2022-05-10 19:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:04:56 --> Input Class Initialized
INFO - 2022-05-10 19:04:56 --> Language Class Initialized
INFO - 2022-05-10 19:04:56 --> Language Class Initialized
INFO - 2022-05-10 19:04:56 --> Config Class Initialized
INFO - 2022-05-10 19:04:56 --> Loader Class Initialized
INFO - 2022-05-10 19:04:56 --> Helper loaded: url_helper
INFO - 2022-05-10 19:04:56 --> Database Driver Class Initialized
INFO - 2022-05-10 19:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:04:56 --> Controller Class Initialized
DEBUG - 2022-05-10 19:04:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:04:56 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:04:56 --> Model Class Initialized
INFO - 2022-05-10 19:04:56 --> Config Class Initialized
INFO - 2022-05-10 19:04:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:04:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:04:56 --> Utf8 Class Initialized
INFO - 2022-05-10 19:04:56 --> URI Class Initialized
INFO - 2022-05-10 19:04:56 --> Router Class Initialized
INFO - 2022-05-10 19:04:56 --> Output Class Initialized
INFO - 2022-05-10 19:04:56 --> Security Class Initialized
DEBUG - 2022-05-10 19:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:04:56 --> Input Class Initialized
INFO - 2022-05-10 19:04:56 --> Language Class Initialized
INFO - 2022-05-10 19:04:56 --> Language Class Initialized
INFO - 2022-05-10 19:04:56 --> Config Class Initialized
INFO - 2022-05-10 19:04:56 --> Loader Class Initialized
INFO - 2022-05-10 19:04:56 --> Helper loaded: url_helper
INFO - 2022-05-10 19:04:56 --> Database Driver Class Initialized
INFO - 2022-05-10 19:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:04:56 --> Controller Class Initialized
DEBUG - 2022-05-10 19:04:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:04:56 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:04:56 --> Model Class Initialized
DEBUG - 2022-05-10 19:04:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:04:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:04:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 19:04:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:04:56 --> Final output sent to browser
DEBUG - 2022-05-10 19:04:56 --> Total execution time: 0.0649
INFO - 2022-05-10 19:06:33 --> Config Class Initialized
INFO - 2022-05-10 19:06:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:06:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:06:33 --> Utf8 Class Initialized
INFO - 2022-05-10 19:06:33 --> URI Class Initialized
INFO - 2022-05-10 19:06:33 --> Router Class Initialized
INFO - 2022-05-10 19:06:33 --> Output Class Initialized
INFO - 2022-05-10 19:06:33 --> Security Class Initialized
DEBUG - 2022-05-10 19:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:06:33 --> Input Class Initialized
INFO - 2022-05-10 19:06:33 --> Language Class Initialized
INFO - 2022-05-10 19:06:33 --> Language Class Initialized
INFO - 2022-05-10 19:06:33 --> Config Class Initialized
INFO - 2022-05-10 19:06:33 --> Loader Class Initialized
INFO - 2022-05-10 19:06:33 --> Helper loaded: url_helper
INFO - 2022-05-10 19:06:33 --> Database Driver Class Initialized
INFO - 2022-05-10 19:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:06:33 --> Controller Class Initialized
DEBUG - 2022-05-10 19:06:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:06:33 --> Model Class Initialized
DEBUG - 2022-05-10 19:06:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:06:33 --> Model Class Initialized
DEBUG - 2022-05-10 19:06:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:06:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:06:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-10 19:06:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:06:33 --> Final output sent to browser
DEBUG - 2022-05-10 19:06:33 --> Total execution time: 0.0589
INFO - 2022-05-10 19:06:35 --> Config Class Initialized
INFO - 2022-05-10 19:06:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:06:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:06:35 --> Utf8 Class Initialized
INFO - 2022-05-10 19:06:35 --> URI Class Initialized
INFO - 2022-05-10 19:06:35 --> Router Class Initialized
INFO - 2022-05-10 19:06:35 --> Output Class Initialized
INFO - 2022-05-10 19:06:35 --> Security Class Initialized
DEBUG - 2022-05-10 19:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:06:35 --> Input Class Initialized
INFO - 2022-05-10 19:06:35 --> Language Class Initialized
INFO - 2022-05-10 19:06:35 --> Language Class Initialized
INFO - 2022-05-10 19:06:35 --> Config Class Initialized
INFO - 2022-05-10 19:06:35 --> Loader Class Initialized
INFO - 2022-05-10 19:06:35 --> Helper loaded: url_helper
INFO - 2022-05-10 19:06:35 --> Database Driver Class Initialized
INFO - 2022-05-10 19:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:06:35 --> Controller Class Initialized
DEBUG - 2022-05-10 19:06:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:06:35 --> Model Class Initialized
DEBUG - 2022-05-10 19:06:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:06:35 --> Model Class Initialized
DEBUG - 2022-05-10 19:06:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:06:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-10 19:06:42 --> Config Class Initialized
INFO - 2022-05-10 19:06:42 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:06:42 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:06:42 --> Utf8 Class Initialized
INFO - 2022-05-10 19:06:42 --> URI Class Initialized
INFO - 2022-05-10 19:06:42 --> Router Class Initialized
INFO - 2022-05-10 19:06:42 --> Output Class Initialized
INFO - 2022-05-10 19:06:42 --> Security Class Initialized
DEBUG - 2022-05-10 19:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:06:42 --> Input Class Initialized
INFO - 2022-05-10 19:06:42 --> Language Class Initialized
INFO - 2022-05-10 19:06:42 --> Language Class Initialized
INFO - 2022-05-10 19:06:42 --> Config Class Initialized
INFO - 2022-05-10 19:06:42 --> Loader Class Initialized
INFO - 2022-05-10 19:06:42 --> Helper loaded: url_helper
INFO - 2022-05-10 19:06:42 --> Database Driver Class Initialized
INFO - 2022-05-10 19:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:06:42 --> Controller Class Initialized
DEBUG - 2022-05-10 19:06:42 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:06:42 --> Model Class Initialized
DEBUG - 2022-05-10 19:06:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:06:42 --> Model Class Initialized
DEBUG - 2022-05-10 19:06:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:06:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:06:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:06:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:06:42 --> Final output sent to browser
DEBUG - 2022-05-10 19:06:42 --> Total execution time: 0.0503
INFO - 2022-05-10 19:07:22 --> Config Class Initialized
INFO - 2022-05-10 19:07:22 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:07:22 --> Utf8 Class Initialized
INFO - 2022-05-10 19:07:22 --> URI Class Initialized
INFO - 2022-05-10 19:07:22 --> Router Class Initialized
INFO - 2022-05-10 19:07:22 --> Output Class Initialized
INFO - 2022-05-10 19:07:22 --> Security Class Initialized
DEBUG - 2022-05-10 19:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:07:22 --> Input Class Initialized
INFO - 2022-05-10 19:07:22 --> Language Class Initialized
INFO - 2022-05-10 19:07:22 --> Language Class Initialized
INFO - 2022-05-10 19:07:22 --> Config Class Initialized
INFO - 2022-05-10 19:07:22 --> Loader Class Initialized
INFO - 2022-05-10 19:07:22 --> Helper loaded: url_helper
INFO - 2022-05-10 19:07:22 --> Database Driver Class Initialized
INFO - 2022-05-10 19:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:07:22 --> Controller Class Initialized
ERROR - 2022-05-10 19:07:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 19:08:13 --> Config Class Initialized
INFO - 2022-05-10 19:08:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:08:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:08:13 --> Utf8 Class Initialized
INFO - 2022-05-10 19:08:13 --> URI Class Initialized
INFO - 2022-05-10 19:08:13 --> Router Class Initialized
INFO - 2022-05-10 19:08:13 --> Output Class Initialized
INFO - 2022-05-10 19:08:13 --> Security Class Initialized
DEBUG - 2022-05-10 19:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:08:13 --> Input Class Initialized
INFO - 2022-05-10 19:08:13 --> Language Class Initialized
INFO - 2022-05-10 19:08:13 --> Language Class Initialized
INFO - 2022-05-10 19:08:13 --> Config Class Initialized
INFO - 2022-05-10 19:08:13 --> Loader Class Initialized
INFO - 2022-05-10 19:08:13 --> Helper loaded: url_helper
INFO - 2022-05-10 19:08:13 --> Database Driver Class Initialized
INFO - 2022-05-10 19:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:08:13 --> Controller Class Initialized
DEBUG - 2022-05-10 19:08:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:08:13 --> Model Class Initialized
DEBUG - 2022-05-10 19:08:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:08:13 --> Model Class Initialized
DEBUG - 2022-05-10 19:08:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:08:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:08:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:08:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:08:13 --> Final output sent to browser
DEBUG - 2022-05-10 19:08:13 --> Total execution time: 0.0630
INFO - 2022-05-10 19:13:13 --> Config Class Initialized
INFO - 2022-05-10 19:13:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:13:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:13:13 --> Utf8 Class Initialized
INFO - 2022-05-10 19:13:13 --> URI Class Initialized
INFO - 2022-05-10 19:13:13 --> Router Class Initialized
INFO - 2022-05-10 19:13:13 --> Output Class Initialized
INFO - 2022-05-10 19:13:13 --> Security Class Initialized
DEBUG - 2022-05-10 19:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:13:13 --> Input Class Initialized
INFO - 2022-05-10 19:13:13 --> Language Class Initialized
INFO - 2022-05-10 19:13:13 --> Language Class Initialized
INFO - 2022-05-10 19:13:13 --> Config Class Initialized
INFO - 2022-05-10 19:13:13 --> Loader Class Initialized
INFO - 2022-05-10 19:13:13 --> Helper loaded: url_helper
INFO - 2022-05-10 19:13:13 --> Database Driver Class Initialized
INFO - 2022-05-10 19:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:13:13 --> Controller Class Initialized
DEBUG - 2022-05-10 19:13:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:13:13 --> Model Class Initialized
DEBUG - 2022-05-10 19:13:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:13:13 --> Model Class Initialized
DEBUG - 2022-05-10 19:13:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:13:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:13:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:13:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:13:13 --> Final output sent to browser
DEBUG - 2022-05-10 19:13:13 --> Total execution time: 0.0509
INFO - 2022-05-10 19:13:18 --> Config Class Initialized
INFO - 2022-05-10 19:13:18 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:13:18 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:13:18 --> Utf8 Class Initialized
INFO - 2022-05-10 19:13:18 --> URI Class Initialized
INFO - 2022-05-10 19:13:18 --> Router Class Initialized
INFO - 2022-05-10 19:13:18 --> Output Class Initialized
INFO - 2022-05-10 19:13:18 --> Security Class Initialized
DEBUG - 2022-05-10 19:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:13:18 --> Input Class Initialized
INFO - 2022-05-10 19:13:18 --> Language Class Initialized
INFO - 2022-05-10 19:13:18 --> Language Class Initialized
INFO - 2022-05-10 19:13:18 --> Config Class Initialized
INFO - 2022-05-10 19:13:18 --> Loader Class Initialized
INFO - 2022-05-10 19:13:18 --> Helper loaded: url_helper
INFO - 2022-05-10 19:13:18 --> Database Driver Class Initialized
INFO - 2022-05-10 19:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:13:18 --> Controller Class Initialized
ERROR - 2022-05-10 19:13:18 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 19:14:30 --> Config Class Initialized
INFO - 2022-05-10 19:14:30 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:14:30 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:14:30 --> Utf8 Class Initialized
INFO - 2022-05-10 19:14:30 --> URI Class Initialized
INFO - 2022-05-10 19:14:30 --> Router Class Initialized
INFO - 2022-05-10 19:14:30 --> Output Class Initialized
INFO - 2022-05-10 19:14:30 --> Security Class Initialized
DEBUG - 2022-05-10 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:14:30 --> Input Class Initialized
INFO - 2022-05-10 19:14:30 --> Language Class Initialized
INFO - 2022-05-10 19:14:30 --> Language Class Initialized
INFO - 2022-05-10 19:14:30 --> Config Class Initialized
INFO - 2022-05-10 19:14:30 --> Loader Class Initialized
INFO - 2022-05-10 19:14:30 --> Helper loaded: url_helper
INFO - 2022-05-10 19:14:30 --> Database Driver Class Initialized
INFO - 2022-05-10 19:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:14:30 --> Controller Class Initialized
DEBUG - 2022-05-10 19:14:30 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:14:30 --> Model Class Initialized
DEBUG - 2022-05-10 19:14:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:14:30 --> Model Class Initialized
DEBUG - 2022-05-10 19:14:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:14:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:14:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:14:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:14:30 --> Final output sent to browser
DEBUG - 2022-05-10 19:14:30 --> Total execution time: 0.0559
INFO - 2022-05-10 19:14:32 --> Config Class Initialized
INFO - 2022-05-10 19:14:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:14:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:14:32 --> Utf8 Class Initialized
INFO - 2022-05-10 19:14:32 --> URI Class Initialized
INFO - 2022-05-10 19:14:32 --> Router Class Initialized
INFO - 2022-05-10 19:14:32 --> Output Class Initialized
INFO - 2022-05-10 19:14:32 --> Security Class Initialized
DEBUG - 2022-05-10 19:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:14:32 --> Input Class Initialized
INFO - 2022-05-10 19:14:32 --> Language Class Initialized
INFO - 2022-05-10 19:14:32 --> Language Class Initialized
INFO - 2022-05-10 19:14:32 --> Config Class Initialized
INFO - 2022-05-10 19:14:32 --> Loader Class Initialized
INFO - 2022-05-10 19:14:32 --> Helper loaded: url_helper
INFO - 2022-05-10 19:14:32 --> Database Driver Class Initialized
INFO - 2022-05-10 19:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:14:32 --> Controller Class Initialized
ERROR - 2022-05-10 19:14:32 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 19:15:12 --> Config Class Initialized
INFO - 2022-05-10 19:15:12 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:15:12 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:15:12 --> Utf8 Class Initialized
INFO - 2022-05-10 19:15:12 --> URI Class Initialized
INFO - 2022-05-10 19:15:12 --> Router Class Initialized
INFO - 2022-05-10 19:15:12 --> Output Class Initialized
INFO - 2022-05-10 19:15:12 --> Security Class Initialized
DEBUG - 2022-05-10 19:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:15:12 --> Input Class Initialized
INFO - 2022-05-10 19:15:12 --> Language Class Initialized
INFO - 2022-05-10 19:15:12 --> Language Class Initialized
INFO - 2022-05-10 19:15:12 --> Config Class Initialized
INFO - 2022-05-10 19:15:12 --> Loader Class Initialized
INFO - 2022-05-10 19:15:12 --> Helper loaded: url_helper
INFO - 2022-05-10 19:15:12 --> Database Driver Class Initialized
INFO - 2022-05-10 19:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:15:12 --> Controller Class Initialized
DEBUG - 2022-05-10 19:15:12 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:15:12 --> Model Class Initialized
DEBUG - 2022-05-10 19:15:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:15:12 --> Model Class Initialized
DEBUG - 2022-05-10 19:15:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:15:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:15:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:15:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:15:12 --> Final output sent to browser
DEBUG - 2022-05-10 19:15:12 --> Total execution time: 0.0595
INFO - 2022-05-10 19:15:14 --> Config Class Initialized
INFO - 2022-05-10 19:15:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:15:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:15:14 --> Utf8 Class Initialized
INFO - 2022-05-10 19:15:14 --> URI Class Initialized
INFO - 2022-05-10 19:15:14 --> Router Class Initialized
INFO - 2022-05-10 19:15:14 --> Output Class Initialized
INFO - 2022-05-10 19:15:14 --> Security Class Initialized
DEBUG - 2022-05-10 19:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:15:14 --> Input Class Initialized
INFO - 2022-05-10 19:15:14 --> Language Class Initialized
INFO - 2022-05-10 19:15:14 --> Language Class Initialized
INFO - 2022-05-10 19:15:14 --> Config Class Initialized
INFO - 2022-05-10 19:15:14 --> Loader Class Initialized
INFO - 2022-05-10 19:15:14 --> Helper loaded: url_helper
INFO - 2022-05-10 19:15:14 --> Database Driver Class Initialized
INFO - 2022-05-10 19:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:15:14 --> Controller Class Initialized
ERROR - 2022-05-10 19:15:14 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 19:15:17 --> Config Class Initialized
INFO - 2022-05-10 19:15:17 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:15:17 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:15:17 --> Utf8 Class Initialized
INFO - 2022-05-10 19:15:17 --> URI Class Initialized
INFO - 2022-05-10 19:15:17 --> Router Class Initialized
INFO - 2022-05-10 19:15:17 --> Output Class Initialized
INFO - 2022-05-10 19:15:17 --> Security Class Initialized
DEBUG - 2022-05-10 19:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:15:17 --> Input Class Initialized
INFO - 2022-05-10 19:15:17 --> Language Class Initialized
INFO - 2022-05-10 19:15:17 --> Language Class Initialized
INFO - 2022-05-10 19:15:17 --> Config Class Initialized
INFO - 2022-05-10 19:15:17 --> Loader Class Initialized
INFO - 2022-05-10 19:15:17 --> Helper loaded: url_helper
INFO - 2022-05-10 19:15:17 --> Database Driver Class Initialized
INFO - 2022-05-10 19:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:15:17 --> Controller Class Initialized
ERROR - 2022-05-10 19:15:17 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fetch_model
INFO - 2022-05-10 19:15:36 --> Config Class Initialized
INFO - 2022-05-10 19:15:36 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:15:36 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:15:36 --> Utf8 Class Initialized
INFO - 2022-05-10 19:15:36 --> URI Class Initialized
INFO - 2022-05-10 19:15:36 --> Router Class Initialized
INFO - 2022-05-10 19:15:36 --> Output Class Initialized
INFO - 2022-05-10 19:15:36 --> Security Class Initialized
DEBUG - 2022-05-10 19:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:15:36 --> Input Class Initialized
INFO - 2022-05-10 19:15:36 --> Language Class Initialized
INFO - 2022-05-10 19:15:36 --> Language Class Initialized
INFO - 2022-05-10 19:15:36 --> Config Class Initialized
INFO - 2022-05-10 19:15:36 --> Loader Class Initialized
INFO - 2022-05-10 19:15:36 --> Helper loaded: url_helper
INFO - 2022-05-10 19:15:36 --> Database Driver Class Initialized
INFO - 2022-05-10 19:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:15:36 --> Controller Class Initialized
DEBUG - 2022-05-10 19:15:36 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:15:36 --> Model Class Initialized
DEBUG - 2022-05-10 19:15:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:15:36 --> Model Class Initialized
DEBUG - 2022-05-10 19:15:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:15:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:15:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:15:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:15:36 --> Final output sent to browser
DEBUG - 2022-05-10 19:15:36 --> Total execution time: 0.0384
INFO - 2022-05-10 19:15:38 --> Config Class Initialized
INFO - 2022-05-10 19:15:38 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:15:38 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:15:38 --> Utf8 Class Initialized
INFO - 2022-05-10 19:15:38 --> URI Class Initialized
INFO - 2022-05-10 19:15:38 --> Router Class Initialized
INFO - 2022-05-10 19:15:38 --> Output Class Initialized
INFO - 2022-05-10 19:15:38 --> Security Class Initialized
DEBUG - 2022-05-10 19:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:15:38 --> Input Class Initialized
INFO - 2022-05-10 19:15:38 --> Language Class Initialized
INFO - 2022-05-10 19:15:38 --> Language Class Initialized
INFO - 2022-05-10 19:15:38 --> Config Class Initialized
INFO - 2022-05-10 19:15:38 --> Loader Class Initialized
INFO - 2022-05-10 19:15:38 --> Helper loaded: url_helper
INFO - 2022-05-10 19:15:38 --> Database Driver Class Initialized
INFO - 2022-05-10 19:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:15:38 --> Controller Class Initialized
DEBUG - 2022-05-10 19:15:38 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:15:38 --> Model Class Initialized
DEBUG - 2022-05-10 19:15:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:15:38 --> Model Class Initialized
ERROR - 2022-05-10 19:15:38 --> Severity: Notice --> Array to string conversion N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 164
INFO - 2022-05-10 19:15:38 --> Final output sent to browser
DEBUG - 2022-05-10 19:15:38 --> Total execution time: 0.0627
INFO - 2022-05-10 19:16:30 --> Config Class Initialized
INFO - 2022-05-10 19:16:30 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:16:30 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:16:30 --> Utf8 Class Initialized
INFO - 2022-05-10 19:16:30 --> URI Class Initialized
INFO - 2022-05-10 19:16:30 --> Router Class Initialized
INFO - 2022-05-10 19:16:30 --> Output Class Initialized
INFO - 2022-05-10 19:16:30 --> Security Class Initialized
DEBUG - 2022-05-10 19:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:16:30 --> Input Class Initialized
INFO - 2022-05-10 19:16:30 --> Language Class Initialized
INFO - 2022-05-10 19:16:30 --> Language Class Initialized
INFO - 2022-05-10 19:16:30 --> Config Class Initialized
INFO - 2022-05-10 19:16:30 --> Loader Class Initialized
INFO - 2022-05-10 19:16:30 --> Helper loaded: url_helper
INFO - 2022-05-10 19:16:30 --> Database Driver Class Initialized
INFO - 2022-05-10 19:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:16:30 --> Controller Class Initialized
DEBUG - 2022-05-10 19:16:30 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:16:30 --> Model Class Initialized
DEBUG - 2022-05-10 19:16:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:16:30 --> Model Class Initialized
DEBUG - 2022-05-10 19:16:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:16:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:16:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:16:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:16:30 --> Final output sent to browser
DEBUG - 2022-05-10 19:16:30 --> Total execution time: 0.0610
INFO - 2022-05-10 19:16:32 --> Config Class Initialized
INFO - 2022-05-10 19:16:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:16:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:16:32 --> Utf8 Class Initialized
INFO - 2022-05-10 19:16:32 --> URI Class Initialized
INFO - 2022-05-10 19:16:32 --> Router Class Initialized
INFO - 2022-05-10 19:16:32 --> Output Class Initialized
INFO - 2022-05-10 19:16:32 --> Security Class Initialized
DEBUG - 2022-05-10 19:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:16:32 --> Input Class Initialized
INFO - 2022-05-10 19:16:32 --> Language Class Initialized
INFO - 2022-05-10 19:16:32 --> Language Class Initialized
INFO - 2022-05-10 19:16:32 --> Config Class Initialized
INFO - 2022-05-10 19:16:32 --> Loader Class Initialized
INFO - 2022-05-10 19:16:32 --> Helper loaded: url_helper
INFO - 2022-05-10 19:16:32 --> Database Driver Class Initialized
INFO - 2022-05-10 19:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:16:32 --> Controller Class Initialized
DEBUG - 2022-05-10 19:16:32 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:16:32 --> Model Class Initialized
DEBUG - 2022-05-10 19:16:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:16:32 --> Model Class Initialized
ERROR - 2022-05-10 19:16:32 --> Severity: Notice --> Undefined index: m_id N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 167
ERROR - 2022-05-10 19:16:32 --> Severity: Notice --> Undefined index: m_name N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 167
INFO - 2022-05-10 19:16:32 --> Final output sent to browser
DEBUG - 2022-05-10 19:16:32 --> Total execution time: 0.0571
INFO - 2022-05-10 19:16:46 --> Config Class Initialized
INFO - 2022-05-10 19:16:46 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:16:46 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:16:46 --> Utf8 Class Initialized
INFO - 2022-05-10 19:16:46 --> URI Class Initialized
INFO - 2022-05-10 19:16:46 --> Router Class Initialized
INFO - 2022-05-10 19:16:46 --> Output Class Initialized
INFO - 2022-05-10 19:16:46 --> Security Class Initialized
DEBUG - 2022-05-10 19:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:16:46 --> Input Class Initialized
INFO - 2022-05-10 19:16:46 --> Language Class Initialized
INFO - 2022-05-10 19:16:46 --> Language Class Initialized
INFO - 2022-05-10 19:16:46 --> Config Class Initialized
INFO - 2022-05-10 19:16:46 --> Loader Class Initialized
INFO - 2022-05-10 19:16:46 --> Helper loaded: url_helper
INFO - 2022-05-10 19:16:46 --> Database Driver Class Initialized
INFO - 2022-05-10 19:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:16:46 --> Controller Class Initialized
DEBUG - 2022-05-10 19:16:46 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:16:46 --> Model Class Initialized
DEBUG - 2022-05-10 19:16:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:16:46 --> Model Class Initialized
DEBUG - 2022-05-10 19:16:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:16:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:16:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:16:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:16:46 --> Final output sent to browser
DEBUG - 2022-05-10 19:16:46 --> Total execution time: 0.0529
INFO - 2022-05-10 19:16:48 --> Config Class Initialized
INFO - 2022-05-10 19:16:48 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:16:48 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:16:48 --> Utf8 Class Initialized
INFO - 2022-05-10 19:16:48 --> URI Class Initialized
INFO - 2022-05-10 19:16:48 --> Router Class Initialized
INFO - 2022-05-10 19:16:48 --> Output Class Initialized
INFO - 2022-05-10 19:16:48 --> Security Class Initialized
DEBUG - 2022-05-10 19:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:16:48 --> Input Class Initialized
INFO - 2022-05-10 19:16:48 --> Language Class Initialized
INFO - 2022-05-10 19:16:48 --> Language Class Initialized
INFO - 2022-05-10 19:16:48 --> Config Class Initialized
INFO - 2022-05-10 19:16:48 --> Loader Class Initialized
INFO - 2022-05-10 19:16:48 --> Helper loaded: url_helper
INFO - 2022-05-10 19:16:48 --> Database Driver Class Initialized
INFO - 2022-05-10 19:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:16:48 --> Controller Class Initialized
DEBUG - 2022-05-10 19:16:48 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:16:48 --> Model Class Initialized
DEBUG - 2022-05-10 19:16:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:16:48 --> Model Class Initialized
ERROR - 2022-05-10 19:16:48 --> Severity: Notice --> Array to string conversion N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 164
ERROR - 2022-05-10 19:16:48 --> Severity: Notice --> Undefined index: m_id N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 167
ERROR - 2022-05-10 19:16:48 --> Severity: Notice --> Undefined index: m_name N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 167
INFO - 2022-05-10 19:16:48 --> Final output sent to browser
DEBUG - 2022-05-10 19:16:48 --> Total execution time: 0.0569
INFO - 2022-05-10 19:17:08 --> Config Class Initialized
INFO - 2022-05-10 19:17:08 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:17:08 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:17:08 --> Utf8 Class Initialized
INFO - 2022-05-10 19:17:08 --> URI Class Initialized
INFO - 2022-05-10 19:17:08 --> Router Class Initialized
INFO - 2022-05-10 19:17:08 --> Output Class Initialized
INFO - 2022-05-10 19:17:08 --> Security Class Initialized
DEBUG - 2022-05-10 19:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:17:08 --> Input Class Initialized
INFO - 2022-05-10 19:17:08 --> Language Class Initialized
INFO - 2022-05-10 19:17:08 --> Language Class Initialized
INFO - 2022-05-10 19:17:08 --> Config Class Initialized
INFO - 2022-05-10 19:17:08 --> Loader Class Initialized
INFO - 2022-05-10 19:17:08 --> Helper loaded: url_helper
INFO - 2022-05-10 19:17:08 --> Database Driver Class Initialized
INFO - 2022-05-10 19:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:17:08 --> Controller Class Initialized
DEBUG - 2022-05-10 19:17:08 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:17:08 --> Model Class Initialized
DEBUG - 2022-05-10 19:17:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:17:08 --> Model Class Initialized
DEBUG - 2022-05-10 19:17:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:17:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:17:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:17:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:17:08 --> Final output sent to browser
DEBUG - 2022-05-10 19:17:08 --> Total execution time: 0.0562
INFO - 2022-05-10 19:17:10 --> Config Class Initialized
INFO - 2022-05-10 19:17:10 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:17:10 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:17:10 --> Utf8 Class Initialized
INFO - 2022-05-10 19:17:10 --> URI Class Initialized
INFO - 2022-05-10 19:17:10 --> Router Class Initialized
INFO - 2022-05-10 19:17:10 --> Output Class Initialized
INFO - 2022-05-10 19:17:10 --> Security Class Initialized
DEBUG - 2022-05-10 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:17:10 --> Input Class Initialized
INFO - 2022-05-10 19:17:10 --> Language Class Initialized
INFO - 2022-05-10 19:17:10 --> Language Class Initialized
INFO - 2022-05-10 19:17:10 --> Config Class Initialized
INFO - 2022-05-10 19:17:10 --> Loader Class Initialized
INFO - 2022-05-10 19:17:10 --> Helper loaded: url_helper
INFO - 2022-05-10 19:17:10 --> Database Driver Class Initialized
INFO - 2022-05-10 19:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:17:10 --> Controller Class Initialized
DEBUG - 2022-05-10 19:17:10 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:17:10 --> Model Class Initialized
DEBUG - 2022-05-10 19:17:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:17:10 --> Model Class Initialized
INFO - 2022-05-10 19:17:10 --> Final output sent to browser
DEBUG - 2022-05-10 19:17:10 --> Total execution time: 0.0438
INFO - 2022-05-10 19:17:13 --> Config Class Initialized
INFO - 2022-05-10 19:17:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:17:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:17:13 --> Utf8 Class Initialized
INFO - 2022-05-10 19:17:13 --> URI Class Initialized
INFO - 2022-05-10 19:17:13 --> Router Class Initialized
INFO - 2022-05-10 19:17:13 --> Output Class Initialized
INFO - 2022-05-10 19:17:13 --> Security Class Initialized
DEBUG - 2022-05-10 19:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:17:13 --> Input Class Initialized
INFO - 2022-05-10 19:17:13 --> Language Class Initialized
INFO - 2022-05-10 19:17:13 --> Language Class Initialized
INFO - 2022-05-10 19:17:13 --> Config Class Initialized
INFO - 2022-05-10 19:17:13 --> Loader Class Initialized
INFO - 2022-05-10 19:17:13 --> Helper loaded: url_helper
INFO - 2022-05-10 19:17:13 --> Database Driver Class Initialized
INFO - 2022-05-10 19:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:17:13 --> Controller Class Initialized
DEBUG - 2022-05-10 19:17:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:17:13 --> Model Class Initialized
DEBUG - 2022-05-10 19:17:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:17:13 --> Model Class Initialized
INFO - 2022-05-10 19:17:13 --> Final output sent to browser
DEBUG - 2022-05-10 19:17:13 --> Total execution time: 0.0785
INFO - 2022-05-10 19:18:04 --> Config Class Initialized
INFO - 2022-05-10 19:18:04 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:18:04 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:18:04 --> Utf8 Class Initialized
INFO - 2022-05-10 19:18:04 --> URI Class Initialized
INFO - 2022-05-10 19:18:04 --> Router Class Initialized
INFO - 2022-05-10 19:18:04 --> Output Class Initialized
INFO - 2022-05-10 19:18:04 --> Security Class Initialized
DEBUG - 2022-05-10 19:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:18:04 --> Input Class Initialized
INFO - 2022-05-10 19:18:04 --> Language Class Initialized
INFO - 2022-05-10 19:18:04 --> Language Class Initialized
INFO - 2022-05-10 19:18:04 --> Config Class Initialized
INFO - 2022-05-10 19:18:04 --> Loader Class Initialized
INFO - 2022-05-10 19:18:04 --> Helper loaded: url_helper
INFO - 2022-05-10 19:18:04 --> Database Driver Class Initialized
INFO - 2022-05-10 19:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:18:04 --> Controller Class Initialized
DEBUG - 2022-05-10 19:18:04 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:18:04 --> Model Class Initialized
DEBUG - 2022-05-10 19:18:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:18:04 --> Model Class Initialized
DEBUG - 2022-05-10 19:18:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:18:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:18:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:18:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:18:04 --> Final output sent to browser
DEBUG - 2022-05-10 19:18:04 --> Total execution time: 0.0554
INFO - 2022-05-10 19:18:06 --> Config Class Initialized
INFO - 2022-05-10 19:18:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:18:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:18:06 --> Utf8 Class Initialized
INFO - 2022-05-10 19:18:06 --> URI Class Initialized
INFO - 2022-05-10 19:18:06 --> Router Class Initialized
INFO - 2022-05-10 19:18:06 --> Output Class Initialized
INFO - 2022-05-10 19:18:06 --> Security Class Initialized
DEBUG - 2022-05-10 19:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:18:06 --> Input Class Initialized
INFO - 2022-05-10 19:18:06 --> Language Class Initialized
INFO - 2022-05-10 19:18:06 --> Language Class Initialized
INFO - 2022-05-10 19:18:06 --> Config Class Initialized
INFO - 2022-05-10 19:18:06 --> Loader Class Initialized
INFO - 2022-05-10 19:18:06 --> Helper loaded: url_helper
INFO - 2022-05-10 19:18:06 --> Database Driver Class Initialized
INFO - 2022-05-10 19:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:18:06 --> Controller Class Initialized
DEBUG - 2022-05-10 19:18:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:18:06 --> Model Class Initialized
DEBUG - 2022-05-10 19:18:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:18:06 --> Model Class Initialized
ERROR - 2022-05-10 19:18:06 --> Query error: Column 'b_id' in where clause is ambiguous - Invalid query: SELECT `m`.`m_id`, `m`.`m_name`
FROM `model` as `m`
JOIN `brand` as `b` ON `b`.`b_id` =  `m`.`b_id` 
WHERE `b_id` = '1'
GROUP BY `b`.`b_id`
INFO - 2022-05-10 19:18:06 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 19:19:07 --> Config Class Initialized
INFO - 2022-05-10 19:19:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:19:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:19:07 --> Utf8 Class Initialized
INFO - 2022-05-10 19:19:07 --> URI Class Initialized
INFO - 2022-05-10 19:19:07 --> Router Class Initialized
INFO - 2022-05-10 19:19:07 --> Output Class Initialized
INFO - 2022-05-10 19:19:07 --> Security Class Initialized
DEBUG - 2022-05-10 19:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:19:07 --> Input Class Initialized
INFO - 2022-05-10 19:19:07 --> Language Class Initialized
INFO - 2022-05-10 19:19:07 --> Language Class Initialized
INFO - 2022-05-10 19:19:07 --> Config Class Initialized
INFO - 2022-05-10 19:19:07 --> Loader Class Initialized
INFO - 2022-05-10 19:19:07 --> Helper loaded: url_helper
INFO - 2022-05-10 19:19:07 --> Database Driver Class Initialized
INFO - 2022-05-10 19:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:19:07 --> Controller Class Initialized
DEBUG - 2022-05-10 19:19:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:19:07 --> Model Class Initialized
DEBUG - 2022-05-10 19:19:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:19:07 --> Model Class Initialized
DEBUG - 2022-05-10 19:19:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:19:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:19:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:19:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:19:07 --> Final output sent to browser
DEBUG - 2022-05-10 19:19:07 --> Total execution time: 0.0591
INFO - 2022-05-10 19:19:09 --> Config Class Initialized
INFO - 2022-05-10 19:19:09 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:19:09 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:19:09 --> Utf8 Class Initialized
INFO - 2022-05-10 19:19:09 --> URI Class Initialized
INFO - 2022-05-10 19:19:09 --> Router Class Initialized
INFO - 2022-05-10 19:19:09 --> Output Class Initialized
INFO - 2022-05-10 19:19:09 --> Security Class Initialized
DEBUG - 2022-05-10 19:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:19:09 --> Input Class Initialized
INFO - 2022-05-10 19:19:09 --> Language Class Initialized
INFO - 2022-05-10 19:19:09 --> Language Class Initialized
INFO - 2022-05-10 19:19:09 --> Config Class Initialized
INFO - 2022-05-10 19:19:09 --> Loader Class Initialized
INFO - 2022-05-10 19:19:09 --> Helper loaded: url_helper
INFO - 2022-05-10 19:19:09 --> Database Driver Class Initialized
INFO - 2022-05-10 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:19:09 --> Controller Class Initialized
DEBUG - 2022-05-10 19:19:09 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:19:09 --> Model Class Initialized
DEBUG - 2022-05-10 19:19:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:19:09 --> Model Class Initialized
ERROR - 2022-05-10 19:19:09 --> Query error: Column 'b_id' in where clause is ambiguous - Invalid query: SELECT `m`.`m_id`, `m`.`m_name`
FROM `model` as `m`
JOIN `brand` as `b` ON `b`.`b_id` =  `m`.`b_id` 
WHERE `b_id` = '1'
GROUP BY `b`.`b_id`
INFO - 2022-05-10 19:19:09 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 19:20:08 --> Config Class Initialized
INFO - 2022-05-10 19:20:08 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:20:08 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:20:08 --> Utf8 Class Initialized
INFO - 2022-05-10 19:20:08 --> URI Class Initialized
INFO - 2022-05-10 19:20:08 --> Router Class Initialized
INFO - 2022-05-10 19:20:08 --> Output Class Initialized
INFO - 2022-05-10 19:20:08 --> Security Class Initialized
DEBUG - 2022-05-10 19:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:20:08 --> Input Class Initialized
INFO - 2022-05-10 19:20:08 --> Language Class Initialized
INFO - 2022-05-10 19:20:08 --> Language Class Initialized
INFO - 2022-05-10 19:20:08 --> Config Class Initialized
INFO - 2022-05-10 19:20:08 --> Loader Class Initialized
INFO - 2022-05-10 19:20:08 --> Helper loaded: url_helper
INFO - 2022-05-10 19:20:08 --> Database Driver Class Initialized
INFO - 2022-05-10 19:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:20:08 --> Controller Class Initialized
DEBUG - 2022-05-10 19:20:08 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:20:08 --> Model Class Initialized
DEBUG - 2022-05-10 19:20:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:20:08 --> Model Class Initialized
DEBUG - 2022-05-10 19:20:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:20:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:20:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:20:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:20:08 --> Final output sent to browser
DEBUG - 2022-05-10 19:20:08 --> Total execution time: 0.0395
INFO - 2022-05-10 19:20:10 --> Config Class Initialized
INFO - 2022-05-10 19:20:10 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:20:10 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:20:10 --> Utf8 Class Initialized
INFO - 2022-05-10 19:20:10 --> URI Class Initialized
INFO - 2022-05-10 19:20:10 --> Router Class Initialized
INFO - 2022-05-10 19:20:10 --> Output Class Initialized
INFO - 2022-05-10 19:20:10 --> Security Class Initialized
DEBUG - 2022-05-10 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:20:10 --> Input Class Initialized
INFO - 2022-05-10 19:20:10 --> Language Class Initialized
INFO - 2022-05-10 19:20:10 --> Language Class Initialized
INFO - 2022-05-10 19:20:10 --> Config Class Initialized
INFO - 2022-05-10 19:20:10 --> Loader Class Initialized
INFO - 2022-05-10 19:20:10 --> Helper loaded: url_helper
INFO - 2022-05-10 19:20:10 --> Database Driver Class Initialized
INFO - 2022-05-10 19:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:20:10 --> Controller Class Initialized
DEBUG - 2022-05-10 19:20:10 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:20:10 --> Model Class Initialized
DEBUG - 2022-05-10 19:20:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:20:10 --> Model Class Initialized
ERROR - 2022-05-10 19:20:10 --> Query error: Column 'b_id' in where clause is ambiguous - Invalid query: SELECT `m`.`m_id`, `m`.`m_name`
FROM `model` as `m`
JOIN `brand` as `b` ON `b`.`b_id` =  `m`.`b_id` 
WHERE `b_id` = '1'
GROUP BY `b`.`b_id`
INFO - 2022-05-10 19:20:10 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 19:20:58 --> Config Class Initialized
INFO - 2022-05-10 19:20:58 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:20:58 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:20:58 --> Utf8 Class Initialized
INFO - 2022-05-10 19:20:58 --> URI Class Initialized
INFO - 2022-05-10 19:20:58 --> Router Class Initialized
INFO - 2022-05-10 19:20:58 --> Output Class Initialized
INFO - 2022-05-10 19:20:58 --> Security Class Initialized
DEBUG - 2022-05-10 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:20:58 --> Input Class Initialized
INFO - 2022-05-10 19:20:58 --> Language Class Initialized
INFO - 2022-05-10 19:20:58 --> Language Class Initialized
INFO - 2022-05-10 19:20:58 --> Config Class Initialized
INFO - 2022-05-10 19:20:58 --> Loader Class Initialized
INFO - 2022-05-10 19:20:58 --> Helper loaded: url_helper
INFO - 2022-05-10 19:20:58 --> Database Driver Class Initialized
INFO - 2022-05-10 19:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:20:58 --> Controller Class Initialized
DEBUG - 2022-05-10 19:20:58 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:20:58 --> Model Class Initialized
DEBUG - 2022-05-10 19:20:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:20:58 --> Model Class Initialized
DEBUG - 2022-05-10 19:20:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:20:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:20:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:20:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:20:58 --> Final output sent to browser
DEBUG - 2022-05-10 19:20:58 --> Total execution time: 0.0541
INFO - 2022-05-10 19:21:00 --> Config Class Initialized
INFO - 2022-05-10 19:21:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:21:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:21:00 --> Utf8 Class Initialized
INFO - 2022-05-10 19:21:00 --> URI Class Initialized
INFO - 2022-05-10 19:21:00 --> Router Class Initialized
INFO - 2022-05-10 19:21:00 --> Output Class Initialized
INFO - 2022-05-10 19:21:00 --> Security Class Initialized
DEBUG - 2022-05-10 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:21:00 --> Input Class Initialized
INFO - 2022-05-10 19:21:00 --> Language Class Initialized
INFO - 2022-05-10 19:21:00 --> Language Class Initialized
INFO - 2022-05-10 19:21:00 --> Config Class Initialized
INFO - 2022-05-10 19:21:00 --> Loader Class Initialized
INFO - 2022-05-10 19:21:00 --> Helper loaded: url_helper
INFO - 2022-05-10 19:21:00 --> Database Driver Class Initialized
INFO - 2022-05-10 19:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:21:00 --> Controller Class Initialized
DEBUG - 2022-05-10 19:21:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:21:00 --> Model Class Initialized
DEBUG - 2022-05-10 19:21:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:21:00 --> Model Class Initialized
INFO - 2022-05-10 19:24:26 --> Config Class Initialized
INFO - 2022-05-10 19:24:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:24:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:24:26 --> Utf8 Class Initialized
INFO - 2022-05-10 19:24:26 --> URI Class Initialized
INFO - 2022-05-10 19:24:26 --> Router Class Initialized
INFO - 2022-05-10 19:24:26 --> Output Class Initialized
INFO - 2022-05-10 19:24:26 --> Security Class Initialized
DEBUG - 2022-05-10 19:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:24:26 --> Input Class Initialized
INFO - 2022-05-10 19:24:26 --> Language Class Initialized
INFO - 2022-05-10 19:24:26 --> Language Class Initialized
INFO - 2022-05-10 19:24:26 --> Config Class Initialized
INFO - 2022-05-10 19:24:26 --> Loader Class Initialized
INFO - 2022-05-10 19:24:26 --> Helper loaded: url_helper
INFO - 2022-05-10 19:24:26 --> Database Driver Class Initialized
INFO - 2022-05-10 19:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:24:26 --> Controller Class Initialized
DEBUG - 2022-05-10 19:24:26 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:24:26 --> Model Class Initialized
DEBUG - 2022-05-10 19:24:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:24:26 --> Model Class Initialized
DEBUG - 2022-05-10 19:24:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:24:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:24:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:24:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:24:26 --> Final output sent to browser
DEBUG - 2022-05-10 19:24:26 --> Total execution time: 0.0418
INFO - 2022-05-10 19:24:28 --> Config Class Initialized
INFO - 2022-05-10 19:24:28 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:24:28 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:24:28 --> Utf8 Class Initialized
INFO - 2022-05-10 19:24:28 --> URI Class Initialized
INFO - 2022-05-10 19:24:28 --> Router Class Initialized
INFO - 2022-05-10 19:24:28 --> Output Class Initialized
INFO - 2022-05-10 19:24:28 --> Security Class Initialized
DEBUG - 2022-05-10 19:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:24:28 --> Input Class Initialized
INFO - 2022-05-10 19:24:28 --> Language Class Initialized
INFO - 2022-05-10 19:24:28 --> Language Class Initialized
INFO - 2022-05-10 19:24:28 --> Config Class Initialized
INFO - 2022-05-10 19:24:28 --> Loader Class Initialized
INFO - 2022-05-10 19:24:28 --> Helper loaded: url_helper
INFO - 2022-05-10 19:24:28 --> Database Driver Class Initialized
INFO - 2022-05-10 19:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:24:28 --> Controller Class Initialized
DEBUG - 2022-05-10 19:24:28 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:24:28 --> Model Class Initialized
DEBUG - 2022-05-10 19:24:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:24:28 --> Model Class Initialized
ERROR - 2022-05-10 19:24:28 --> Severity: Notice --> Undefined index: m_id N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 165
ERROR - 2022-05-10 19:24:28 --> Severity: Notice --> Undefined index: m_name N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 165
INFO - 2022-05-10 19:24:28 --> Final output sent to browser
DEBUG - 2022-05-10 19:24:28 --> Total execution time: 0.0465
INFO - 2022-05-10 19:25:50 --> Config Class Initialized
INFO - 2022-05-10 19:25:50 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:25:50 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:25:50 --> Utf8 Class Initialized
INFO - 2022-05-10 19:25:50 --> URI Class Initialized
INFO - 2022-05-10 19:25:50 --> Router Class Initialized
INFO - 2022-05-10 19:25:50 --> Output Class Initialized
INFO - 2022-05-10 19:25:50 --> Security Class Initialized
DEBUG - 2022-05-10 19:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:25:50 --> Input Class Initialized
INFO - 2022-05-10 19:25:50 --> Language Class Initialized
INFO - 2022-05-10 19:25:50 --> Language Class Initialized
INFO - 2022-05-10 19:25:50 --> Config Class Initialized
INFO - 2022-05-10 19:25:50 --> Loader Class Initialized
INFO - 2022-05-10 19:25:50 --> Helper loaded: url_helper
INFO - 2022-05-10 19:25:50 --> Database Driver Class Initialized
INFO - 2022-05-10 19:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:25:50 --> Controller Class Initialized
DEBUG - 2022-05-10 19:25:50 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:25:50 --> Model Class Initialized
DEBUG - 2022-05-10 19:25:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:25:50 --> Model Class Initialized
DEBUG - 2022-05-10 19:25:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:25:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:25:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:25:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:25:50 --> Final output sent to browser
DEBUG - 2022-05-10 19:25:50 --> Total execution time: 0.0536
INFO - 2022-05-10 19:25:52 --> Config Class Initialized
INFO - 2022-05-10 19:25:52 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:25:52 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:25:52 --> Utf8 Class Initialized
INFO - 2022-05-10 19:25:52 --> URI Class Initialized
INFO - 2022-05-10 19:25:52 --> Router Class Initialized
INFO - 2022-05-10 19:25:52 --> Output Class Initialized
INFO - 2022-05-10 19:25:52 --> Security Class Initialized
DEBUG - 2022-05-10 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:25:52 --> Input Class Initialized
INFO - 2022-05-10 19:25:52 --> Language Class Initialized
INFO - 2022-05-10 19:25:52 --> Language Class Initialized
INFO - 2022-05-10 19:25:52 --> Config Class Initialized
INFO - 2022-05-10 19:25:52 --> Loader Class Initialized
INFO - 2022-05-10 19:25:52 --> Helper loaded: url_helper
INFO - 2022-05-10 19:25:52 --> Database Driver Class Initialized
INFO - 2022-05-10 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:25:52 --> Controller Class Initialized
DEBUG - 2022-05-10 19:25:52 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:25:52 --> Model Class Initialized
DEBUG - 2022-05-10 19:25:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:25:52 --> Model Class Initialized
INFO - 2022-05-10 19:25:52 --> Final output sent to browser
DEBUG - 2022-05-10 19:25:52 --> Total execution time: 0.0549
INFO - 2022-05-10 19:26:15 --> Config Class Initialized
INFO - 2022-05-10 19:26:15 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:26:15 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:26:15 --> Utf8 Class Initialized
INFO - 2022-05-10 19:26:15 --> URI Class Initialized
INFO - 2022-05-10 19:26:15 --> Router Class Initialized
INFO - 2022-05-10 19:26:15 --> Output Class Initialized
INFO - 2022-05-10 19:26:15 --> Security Class Initialized
DEBUG - 2022-05-10 19:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:26:15 --> Input Class Initialized
INFO - 2022-05-10 19:26:15 --> Language Class Initialized
INFO - 2022-05-10 19:26:15 --> Language Class Initialized
INFO - 2022-05-10 19:26:15 --> Config Class Initialized
INFO - 2022-05-10 19:26:15 --> Loader Class Initialized
INFO - 2022-05-10 19:26:15 --> Helper loaded: url_helper
INFO - 2022-05-10 19:26:15 --> Database Driver Class Initialized
INFO - 2022-05-10 19:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:26:15 --> Controller Class Initialized
DEBUG - 2022-05-10 19:26:15 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:26:15 --> Model Class Initialized
DEBUG - 2022-05-10 19:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:26:15 --> Model Class Initialized
DEBUG - 2022-05-10 19:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:26:15 --> Final output sent to browser
DEBUG - 2022-05-10 19:26:15 --> Total execution time: 0.0541
INFO - 2022-05-10 19:26:17 --> Config Class Initialized
INFO - 2022-05-10 19:26:17 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:26:17 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:26:17 --> Utf8 Class Initialized
INFO - 2022-05-10 19:26:17 --> URI Class Initialized
INFO - 2022-05-10 19:26:17 --> Router Class Initialized
INFO - 2022-05-10 19:26:17 --> Output Class Initialized
INFO - 2022-05-10 19:26:17 --> Security Class Initialized
DEBUG - 2022-05-10 19:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:26:17 --> Input Class Initialized
INFO - 2022-05-10 19:26:17 --> Language Class Initialized
INFO - 2022-05-10 19:26:17 --> Language Class Initialized
INFO - 2022-05-10 19:26:17 --> Config Class Initialized
INFO - 2022-05-10 19:26:17 --> Loader Class Initialized
INFO - 2022-05-10 19:26:17 --> Helper loaded: url_helper
INFO - 2022-05-10 19:26:17 --> Database Driver Class Initialized
INFO - 2022-05-10 19:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:26:17 --> Controller Class Initialized
DEBUG - 2022-05-10 19:26:17 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:26:17 --> Model Class Initialized
DEBUG - 2022-05-10 19:26:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:26:17 --> Model Class Initialized
INFO - 2022-05-10 19:26:17 --> Final output sent to browser
DEBUG - 2022-05-10 19:26:17 --> Total execution time: 0.0521
INFO - 2022-05-10 19:27:05 --> Config Class Initialized
INFO - 2022-05-10 19:27:05 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:27:05 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:27:05 --> Utf8 Class Initialized
INFO - 2022-05-10 19:27:05 --> URI Class Initialized
INFO - 2022-05-10 19:27:05 --> Router Class Initialized
INFO - 2022-05-10 19:27:05 --> Output Class Initialized
INFO - 2022-05-10 19:27:05 --> Security Class Initialized
DEBUG - 2022-05-10 19:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:27:05 --> Input Class Initialized
INFO - 2022-05-10 19:27:05 --> Language Class Initialized
INFO - 2022-05-10 19:27:05 --> Language Class Initialized
INFO - 2022-05-10 19:27:05 --> Config Class Initialized
INFO - 2022-05-10 19:27:05 --> Loader Class Initialized
INFO - 2022-05-10 19:27:05 --> Helper loaded: url_helper
INFO - 2022-05-10 19:27:05 --> Database Driver Class Initialized
INFO - 2022-05-10 19:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:27:05 --> Controller Class Initialized
DEBUG - 2022-05-10 19:27:05 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:27:05 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:27:05 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:27:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:27:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:27:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:27:05 --> Final output sent to browser
DEBUG - 2022-05-10 19:27:05 --> Total execution time: 0.0569
INFO - 2022-05-10 19:27:07 --> Config Class Initialized
INFO - 2022-05-10 19:27:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:27:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:27:07 --> Utf8 Class Initialized
INFO - 2022-05-10 19:27:07 --> URI Class Initialized
INFO - 2022-05-10 19:27:07 --> Router Class Initialized
INFO - 2022-05-10 19:27:07 --> Output Class Initialized
INFO - 2022-05-10 19:27:07 --> Security Class Initialized
DEBUG - 2022-05-10 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:27:07 --> Input Class Initialized
INFO - 2022-05-10 19:27:07 --> Language Class Initialized
INFO - 2022-05-10 19:27:07 --> Language Class Initialized
INFO - 2022-05-10 19:27:07 --> Config Class Initialized
INFO - 2022-05-10 19:27:07 --> Loader Class Initialized
INFO - 2022-05-10 19:27:07 --> Helper loaded: url_helper
INFO - 2022-05-10 19:27:07 --> Database Driver Class Initialized
INFO - 2022-05-10 19:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:27:07 --> Controller Class Initialized
DEBUG - 2022-05-10 19:27:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:27:07 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:27:07 --> Model Class Initialized
INFO - 2022-05-10 19:27:07 --> Final output sent to browser
DEBUG - 2022-05-10 19:27:07 --> Total execution time: 0.0470
INFO - 2022-05-10 19:27:22 --> Config Class Initialized
INFO - 2022-05-10 19:27:22 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:27:22 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:27:22 --> Utf8 Class Initialized
INFO - 2022-05-10 19:27:22 --> URI Class Initialized
INFO - 2022-05-10 19:27:22 --> Router Class Initialized
INFO - 2022-05-10 19:27:22 --> Output Class Initialized
INFO - 2022-05-10 19:27:22 --> Security Class Initialized
DEBUG - 2022-05-10 19:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:27:22 --> Input Class Initialized
INFO - 2022-05-10 19:27:22 --> Language Class Initialized
INFO - 2022-05-10 19:27:22 --> Language Class Initialized
INFO - 2022-05-10 19:27:22 --> Config Class Initialized
INFO - 2022-05-10 19:27:22 --> Loader Class Initialized
INFO - 2022-05-10 19:27:22 --> Helper loaded: url_helper
INFO - 2022-05-10 19:27:22 --> Database Driver Class Initialized
INFO - 2022-05-10 19:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:27:22 --> Controller Class Initialized
DEBUG - 2022-05-10 19:27:22 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:27:22 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:27:22 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:27:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:27:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:27:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:27:22 --> Final output sent to browser
DEBUG - 2022-05-10 19:27:22 --> Total execution time: 0.0546
INFO - 2022-05-10 19:27:25 --> Config Class Initialized
INFO - 2022-05-10 19:27:25 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:27:25 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:27:25 --> Utf8 Class Initialized
INFO - 2022-05-10 19:27:25 --> URI Class Initialized
INFO - 2022-05-10 19:27:25 --> Router Class Initialized
INFO - 2022-05-10 19:27:25 --> Output Class Initialized
INFO - 2022-05-10 19:27:25 --> Security Class Initialized
DEBUG - 2022-05-10 19:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:27:25 --> Input Class Initialized
INFO - 2022-05-10 19:27:25 --> Language Class Initialized
INFO - 2022-05-10 19:27:25 --> Language Class Initialized
INFO - 2022-05-10 19:27:25 --> Config Class Initialized
INFO - 2022-05-10 19:27:25 --> Loader Class Initialized
INFO - 2022-05-10 19:27:25 --> Helper loaded: url_helper
INFO - 2022-05-10 19:27:25 --> Database Driver Class Initialized
INFO - 2022-05-10 19:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:27:25 --> Controller Class Initialized
DEBUG - 2022-05-10 19:27:25 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:27:25 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:27:25 --> Model Class Initialized
INFO - 2022-05-10 19:27:25 --> Final output sent to browser
DEBUG - 2022-05-10 19:27:25 --> Total execution time: 0.0447
INFO - 2022-05-10 19:27:55 --> Config Class Initialized
INFO - 2022-05-10 19:27:55 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:27:55 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:27:55 --> Utf8 Class Initialized
INFO - 2022-05-10 19:27:55 --> URI Class Initialized
INFO - 2022-05-10 19:27:55 --> Router Class Initialized
INFO - 2022-05-10 19:27:55 --> Output Class Initialized
INFO - 2022-05-10 19:27:55 --> Security Class Initialized
DEBUG - 2022-05-10 19:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:27:55 --> Input Class Initialized
INFO - 2022-05-10 19:27:55 --> Language Class Initialized
INFO - 2022-05-10 19:27:55 --> Language Class Initialized
INFO - 2022-05-10 19:27:55 --> Config Class Initialized
INFO - 2022-05-10 19:27:55 --> Loader Class Initialized
INFO - 2022-05-10 19:27:55 --> Helper loaded: url_helper
INFO - 2022-05-10 19:27:55 --> Database Driver Class Initialized
INFO - 2022-05-10 19:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:27:55 --> Controller Class Initialized
DEBUG - 2022-05-10 19:27:55 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:27:55 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:27:55 --> Model Class Initialized
DEBUG - 2022-05-10 19:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:27:55 --> Final output sent to browser
DEBUG - 2022-05-10 19:27:55 --> Total execution time: 0.0543
INFO - 2022-05-10 19:28:19 --> Config Class Initialized
INFO - 2022-05-10 19:28:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:28:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:28:19 --> Utf8 Class Initialized
INFO - 2022-05-10 19:28:19 --> URI Class Initialized
INFO - 2022-05-10 19:28:19 --> Router Class Initialized
INFO - 2022-05-10 19:28:19 --> Output Class Initialized
INFO - 2022-05-10 19:28:19 --> Security Class Initialized
DEBUG - 2022-05-10 19:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:28:19 --> Input Class Initialized
INFO - 2022-05-10 19:28:19 --> Language Class Initialized
INFO - 2022-05-10 19:28:19 --> Language Class Initialized
INFO - 2022-05-10 19:28:19 --> Config Class Initialized
INFO - 2022-05-10 19:28:20 --> Loader Class Initialized
INFO - 2022-05-10 19:28:20 --> Helper loaded: url_helper
INFO - 2022-05-10 19:28:20 --> Database Driver Class Initialized
INFO - 2022-05-10 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:28:20 --> Controller Class Initialized
DEBUG - 2022-05-10 19:28:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:28:20 --> Model Class Initialized
DEBUG - 2022-05-10 19:28:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:28:20 --> Model Class Initialized
DEBUG - 2022-05-10 19:28:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:28:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:28:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:28:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:28:20 --> Final output sent to browser
DEBUG - 2022-05-10 19:28:20 --> Total execution time: 0.0520
INFO - 2022-05-10 19:28:52 --> Config Class Initialized
INFO - 2022-05-10 19:28:52 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:28:52 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:28:52 --> Utf8 Class Initialized
INFO - 2022-05-10 19:28:52 --> URI Class Initialized
INFO - 2022-05-10 19:28:52 --> Router Class Initialized
INFO - 2022-05-10 19:28:52 --> Output Class Initialized
INFO - 2022-05-10 19:28:52 --> Security Class Initialized
DEBUG - 2022-05-10 19:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:28:52 --> Input Class Initialized
INFO - 2022-05-10 19:28:52 --> Language Class Initialized
INFO - 2022-05-10 19:28:52 --> Language Class Initialized
INFO - 2022-05-10 19:28:52 --> Config Class Initialized
INFO - 2022-05-10 19:28:52 --> Loader Class Initialized
INFO - 2022-05-10 19:28:52 --> Helper loaded: url_helper
INFO - 2022-05-10 19:28:52 --> Database Driver Class Initialized
INFO - 2022-05-10 19:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:28:52 --> Controller Class Initialized
DEBUG - 2022-05-10 19:28:52 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:28:52 --> Model Class Initialized
DEBUG - 2022-05-10 19:28:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:28:52 --> Model Class Initialized
DEBUG - 2022-05-10 19:28:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:28:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:28:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:28:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:28:52 --> Final output sent to browser
DEBUG - 2022-05-10 19:28:52 --> Total execution time: 0.0533
INFO - 2022-05-10 19:32:49 --> Config Class Initialized
INFO - 2022-05-10 19:32:49 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:32:49 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:32:49 --> Utf8 Class Initialized
INFO - 2022-05-10 19:32:49 --> URI Class Initialized
INFO - 2022-05-10 19:32:49 --> Router Class Initialized
INFO - 2022-05-10 19:32:49 --> Output Class Initialized
INFO - 2022-05-10 19:32:49 --> Security Class Initialized
DEBUG - 2022-05-10 19:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:32:49 --> Input Class Initialized
INFO - 2022-05-10 19:32:49 --> Language Class Initialized
INFO - 2022-05-10 19:32:49 --> Language Class Initialized
INFO - 2022-05-10 19:32:49 --> Config Class Initialized
INFO - 2022-05-10 19:32:49 --> Loader Class Initialized
INFO - 2022-05-10 19:32:49 --> Helper loaded: url_helper
INFO - 2022-05-10 19:32:49 --> Database Driver Class Initialized
INFO - 2022-05-10 19:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:32:49 --> Controller Class Initialized
DEBUG - 2022-05-10 19:32:49 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:32:49 --> Model Class Initialized
DEBUG - 2022-05-10 19:32:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:32:49 --> Model Class Initialized
INFO - 2022-05-10 19:32:49 --> Final output sent to browser
DEBUG - 2022-05-10 19:32:49 --> Total execution time: 0.0357
INFO - 2022-05-10 19:42:30 --> Config Class Initialized
INFO - 2022-05-10 19:42:30 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:42:30 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:42:30 --> Utf8 Class Initialized
INFO - 2022-05-10 19:42:30 --> URI Class Initialized
INFO - 2022-05-10 19:42:30 --> Router Class Initialized
INFO - 2022-05-10 19:42:30 --> Output Class Initialized
INFO - 2022-05-10 19:42:30 --> Security Class Initialized
DEBUG - 2022-05-10 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:42:30 --> Input Class Initialized
INFO - 2022-05-10 19:42:30 --> Language Class Initialized
INFO - 2022-05-10 19:42:30 --> Language Class Initialized
INFO - 2022-05-10 19:42:30 --> Config Class Initialized
INFO - 2022-05-10 19:42:30 --> Loader Class Initialized
INFO - 2022-05-10 19:42:30 --> Helper loaded: url_helper
INFO - 2022-05-10 19:42:30 --> Database Driver Class Initialized
INFO - 2022-05-10 19:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:42:30 --> Controller Class Initialized
DEBUG - 2022-05-10 19:42:30 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:42:30 --> Model Class Initialized
DEBUG - 2022-05-10 19:42:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:42:30 --> Model Class Initialized
DEBUG - 2022-05-10 19:42:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:42:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:42:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:42:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:42:30 --> Final output sent to browser
DEBUG - 2022-05-10 19:42:30 --> Total execution time: 0.0301
INFO - 2022-05-10 19:42:41 --> Config Class Initialized
INFO - 2022-05-10 19:42:41 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:42:41 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:42:41 --> Utf8 Class Initialized
INFO - 2022-05-10 19:42:41 --> URI Class Initialized
INFO - 2022-05-10 19:42:41 --> Router Class Initialized
INFO - 2022-05-10 19:42:41 --> Output Class Initialized
INFO - 2022-05-10 19:42:41 --> Security Class Initialized
DEBUG - 2022-05-10 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:42:41 --> Input Class Initialized
INFO - 2022-05-10 19:42:41 --> Language Class Initialized
INFO - 2022-05-10 19:42:41 --> Language Class Initialized
INFO - 2022-05-10 19:42:41 --> Config Class Initialized
INFO - 2022-05-10 19:42:41 --> Loader Class Initialized
INFO - 2022-05-10 19:42:41 --> Helper loaded: url_helper
INFO - 2022-05-10 19:42:41 --> Database Driver Class Initialized
INFO - 2022-05-10 19:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:42:41 --> Controller Class Initialized
DEBUG - 2022-05-10 19:42:41 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:42:41 --> Model Class Initialized
DEBUG - 2022-05-10 19:42:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:42:41 --> Model Class Initialized
DEBUG - 2022-05-10 19:42:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:42:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:42:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:42:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:42:41 --> Final output sent to browser
DEBUG - 2022-05-10 19:42:41 --> Total execution time: 0.0307
INFO - 2022-05-10 19:42:45 --> Config Class Initialized
INFO - 2022-05-10 19:42:45 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:42:45 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:42:45 --> Utf8 Class Initialized
INFO - 2022-05-10 19:42:45 --> URI Class Initialized
INFO - 2022-05-10 19:42:45 --> Router Class Initialized
INFO - 2022-05-10 19:42:45 --> Output Class Initialized
INFO - 2022-05-10 19:42:45 --> Security Class Initialized
DEBUG - 2022-05-10 19:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:42:45 --> Input Class Initialized
INFO - 2022-05-10 19:42:45 --> Language Class Initialized
INFO - 2022-05-10 19:42:45 --> Language Class Initialized
INFO - 2022-05-10 19:42:45 --> Config Class Initialized
INFO - 2022-05-10 19:42:45 --> Loader Class Initialized
INFO - 2022-05-10 19:42:45 --> Helper loaded: url_helper
INFO - 2022-05-10 19:42:45 --> Database Driver Class Initialized
INFO - 2022-05-10 19:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:42:45 --> Controller Class Initialized
DEBUG - 2022-05-10 19:42:45 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:42:45 --> Model Class Initialized
DEBUG - 2022-05-10 19:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:42:45 --> Model Class Initialized
DEBUG - 2022-05-10 19:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:42:45 --> Final output sent to browser
DEBUG - 2022-05-10 19:42:45 --> Total execution time: 0.0551
INFO - 2022-05-10 19:44:27 --> Config Class Initialized
INFO - 2022-05-10 19:44:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:44:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:44:27 --> Utf8 Class Initialized
INFO - 2022-05-10 19:44:27 --> URI Class Initialized
INFO - 2022-05-10 19:44:27 --> Router Class Initialized
INFO - 2022-05-10 19:44:27 --> Output Class Initialized
INFO - 2022-05-10 19:44:27 --> Security Class Initialized
DEBUG - 2022-05-10 19:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:44:27 --> Input Class Initialized
INFO - 2022-05-10 19:44:27 --> Language Class Initialized
INFO - 2022-05-10 19:44:27 --> Language Class Initialized
INFO - 2022-05-10 19:44:27 --> Config Class Initialized
INFO - 2022-05-10 19:44:27 --> Loader Class Initialized
INFO - 2022-05-10 19:44:27 --> Helper loaded: url_helper
INFO - 2022-05-10 19:44:27 --> Database Driver Class Initialized
INFO - 2022-05-10 19:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:44:27 --> Controller Class Initialized
DEBUG - 2022-05-10 19:44:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:44:27 --> Model Class Initialized
DEBUG - 2022-05-10 19:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:44:27 --> Model Class Initialized
DEBUG - 2022-05-10 19:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:44:27 --> Final output sent to browser
DEBUG - 2022-05-10 19:44:27 --> Total execution time: 0.0377
INFO - 2022-05-10 19:44:44 --> Config Class Initialized
INFO - 2022-05-10 19:44:44 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:44:44 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:44:44 --> Utf8 Class Initialized
INFO - 2022-05-10 19:44:44 --> URI Class Initialized
INFO - 2022-05-10 19:44:44 --> Router Class Initialized
INFO - 2022-05-10 19:44:44 --> Output Class Initialized
INFO - 2022-05-10 19:44:44 --> Security Class Initialized
DEBUG - 2022-05-10 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:44:44 --> Input Class Initialized
INFO - 2022-05-10 19:44:44 --> Language Class Initialized
INFO - 2022-05-10 19:44:44 --> Language Class Initialized
INFO - 2022-05-10 19:44:44 --> Config Class Initialized
INFO - 2022-05-10 19:44:44 --> Loader Class Initialized
INFO - 2022-05-10 19:44:44 --> Helper loaded: url_helper
INFO - 2022-05-10 19:44:44 --> Database Driver Class Initialized
INFO - 2022-05-10 19:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:44:44 --> Controller Class Initialized
DEBUG - 2022-05-10 19:44:44 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:44:44 --> Model Class Initialized
DEBUG - 2022-05-10 19:44:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:44:44 --> Model Class Initialized
INFO - 2022-05-10 19:44:44 --> Final output sent to browser
DEBUG - 2022-05-10 19:44:44 --> Total execution time: 0.0348
INFO - 2022-05-10 19:45:02 --> Config Class Initialized
INFO - 2022-05-10 19:45:02 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:45:02 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:45:02 --> Utf8 Class Initialized
INFO - 2022-05-10 19:45:02 --> URI Class Initialized
INFO - 2022-05-10 19:45:02 --> Router Class Initialized
INFO - 2022-05-10 19:45:02 --> Output Class Initialized
INFO - 2022-05-10 19:45:02 --> Security Class Initialized
DEBUG - 2022-05-10 19:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:45:02 --> Input Class Initialized
INFO - 2022-05-10 19:45:02 --> Language Class Initialized
INFO - 2022-05-10 19:45:02 --> Language Class Initialized
INFO - 2022-05-10 19:45:02 --> Config Class Initialized
INFO - 2022-05-10 19:45:02 --> Loader Class Initialized
INFO - 2022-05-10 19:45:02 --> Helper loaded: url_helper
INFO - 2022-05-10 19:45:02 --> Database Driver Class Initialized
INFO - 2022-05-10 19:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:45:02 --> Controller Class Initialized
DEBUG - 2022-05-10 19:45:02 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:45:02 --> Model Class Initialized
DEBUG - 2022-05-10 19:45:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:45:02 --> Model Class Initialized
DEBUG - 2022-05-10 19:45:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:45:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:45:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:45:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:45:02 --> Final output sent to browser
DEBUG - 2022-05-10 19:45:02 --> Total execution time: 0.0391
INFO - 2022-05-10 19:45:06 --> Config Class Initialized
INFO - 2022-05-10 19:45:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:45:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:45:06 --> Utf8 Class Initialized
INFO - 2022-05-10 19:45:06 --> URI Class Initialized
INFO - 2022-05-10 19:45:06 --> Router Class Initialized
INFO - 2022-05-10 19:45:06 --> Output Class Initialized
INFO - 2022-05-10 19:45:06 --> Security Class Initialized
DEBUG - 2022-05-10 19:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:45:06 --> Input Class Initialized
INFO - 2022-05-10 19:45:06 --> Language Class Initialized
INFO - 2022-05-10 19:45:06 --> Language Class Initialized
INFO - 2022-05-10 19:45:06 --> Config Class Initialized
INFO - 2022-05-10 19:45:06 --> Loader Class Initialized
INFO - 2022-05-10 19:45:06 --> Helper loaded: url_helper
INFO - 2022-05-10 19:45:06 --> Database Driver Class Initialized
INFO - 2022-05-10 19:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:45:06 --> Controller Class Initialized
DEBUG - 2022-05-10 19:45:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:45:06 --> Model Class Initialized
DEBUG - 2022-05-10 19:45:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:45:06 --> Model Class Initialized
INFO - 2022-05-10 19:45:06 --> Final output sent to browser
DEBUG - 2022-05-10 19:45:06 --> Total execution time: 0.0368
INFO - 2022-05-10 19:45:27 --> Config Class Initialized
INFO - 2022-05-10 19:45:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:45:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:45:27 --> Utf8 Class Initialized
INFO - 2022-05-10 19:45:27 --> URI Class Initialized
INFO - 2022-05-10 19:45:27 --> Router Class Initialized
INFO - 2022-05-10 19:45:27 --> Output Class Initialized
INFO - 2022-05-10 19:45:27 --> Security Class Initialized
DEBUG - 2022-05-10 19:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:45:27 --> Input Class Initialized
INFO - 2022-05-10 19:45:27 --> Language Class Initialized
INFO - 2022-05-10 19:45:27 --> Language Class Initialized
INFO - 2022-05-10 19:45:27 --> Config Class Initialized
INFO - 2022-05-10 19:45:27 --> Loader Class Initialized
INFO - 2022-05-10 19:45:27 --> Helper loaded: url_helper
INFO - 2022-05-10 19:45:27 --> Database Driver Class Initialized
INFO - 2022-05-10 19:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:45:27 --> Controller Class Initialized
DEBUG - 2022-05-10 19:45:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:45:27 --> Model Class Initialized
DEBUG - 2022-05-10 19:45:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:45:27 --> Model Class Initialized
DEBUG - 2022-05-10 19:45:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:45:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:45:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:45:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:45:27 --> Final output sent to browser
DEBUG - 2022-05-10 19:45:27 --> Total execution time: 0.0386
INFO - 2022-05-10 19:56:01 --> Config Class Initialized
INFO - 2022-05-10 19:56:01 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:56:01 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:56:01 --> Utf8 Class Initialized
INFO - 2022-05-10 19:56:01 --> URI Class Initialized
INFO - 2022-05-10 19:56:01 --> Router Class Initialized
INFO - 2022-05-10 19:56:01 --> Output Class Initialized
INFO - 2022-05-10 19:56:01 --> Security Class Initialized
DEBUG - 2022-05-10 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:56:01 --> Input Class Initialized
INFO - 2022-05-10 19:56:01 --> Language Class Initialized
INFO - 2022-05-10 19:56:01 --> Language Class Initialized
INFO - 2022-05-10 19:56:01 --> Config Class Initialized
INFO - 2022-05-10 19:56:01 --> Loader Class Initialized
INFO - 2022-05-10 19:56:01 --> Helper loaded: url_helper
INFO - 2022-05-10 19:56:01 --> Database Driver Class Initialized
INFO - 2022-05-10 19:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:56:01 --> Controller Class Initialized
DEBUG - 2022-05-10 19:56:01 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:56:01 --> Model Class Initialized
DEBUG - 2022-05-10 19:56:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:56:01 --> Model Class Initialized
DEBUG - 2022-05-10 19:56:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 19:56:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 19:56:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 19:56:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 19:56:01 --> Final output sent to browser
DEBUG - 2022-05-10 19:56:01 --> Total execution time: 0.0439
INFO - 2022-05-10 19:59:58 --> Config Class Initialized
INFO - 2022-05-10 19:59:58 --> Hooks Class Initialized
DEBUG - 2022-05-10 19:59:58 --> UTF-8 Support Enabled
INFO - 2022-05-10 19:59:58 --> Utf8 Class Initialized
INFO - 2022-05-10 19:59:58 --> URI Class Initialized
INFO - 2022-05-10 19:59:58 --> Router Class Initialized
INFO - 2022-05-10 19:59:58 --> Output Class Initialized
INFO - 2022-05-10 19:59:58 --> Security Class Initialized
DEBUG - 2022-05-10 19:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 19:59:58 --> Input Class Initialized
INFO - 2022-05-10 19:59:58 --> Language Class Initialized
INFO - 2022-05-10 19:59:58 --> Language Class Initialized
INFO - 2022-05-10 19:59:58 --> Config Class Initialized
INFO - 2022-05-10 19:59:58 --> Loader Class Initialized
INFO - 2022-05-10 19:59:58 --> Helper loaded: url_helper
INFO - 2022-05-10 19:59:58 --> Database Driver Class Initialized
INFO - 2022-05-10 19:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 19:59:58 --> Controller Class Initialized
DEBUG - 2022-05-10 19:59:58 --> Admin MX_Controller Initialized
INFO - 2022-05-10 19:59:58 --> Model Class Initialized
DEBUG - 2022-05-10 19:59:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 19:59:58 --> Model Class Initialized
ERROR - 2022-05-10 19:59:58 --> Query error: Table 'motodeal.bodycolor' doesn't exist - Invalid query: SELECT *
FROM `bodycolor`
INFO - 2022-05-10 19:59:58 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 20:00:23 --> Config Class Initialized
INFO - 2022-05-10 20:00:23 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:00:23 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:00:23 --> Utf8 Class Initialized
INFO - 2022-05-10 20:00:23 --> URI Class Initialized
INFO - 2022-05-10 20:00:23 --> Router Class Initialized
INFO - 2022-05-10 20:00:23 --> Output Class Initialized
INFO - 2022-05-10 20:00:23 --> Security Class Initialized
DEBUG - 2022-05-10 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:00:23 --> Input Class Initialized
INFO - 2022-05-10 20:00:23 --> Language Class Initialized
INFO - 2022-05-10 20:00:23 --> Language Class Initialized
INFO - 2022-05-10 20:00:23 --> Config Class Initialized
INFO - 2022-05-10 20:00:23 --> Loader Class Initialized
INFO - 2022-05-10 20:00:23 --> Helper loaded: url_helper
INFO - 2022-05-10 20:00:23 --> Database Driver Class Initialized
INFO - 2022-05-10 20:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:00:23 --> Controller Class Initialized
DEBUG - 2022-05-10 20:00:23 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:00:23 --> Model Class Initialized
DEBUG - 2022-05-10 20:00:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:00:23 --> Model Class Initialized
DEBUG - 2022-05-10 20:00:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:00:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:00:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:00:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:00:23 --> Final output sent to browser
DEBUG - 2022-05-10 20:00:23 --> Total execution time: 0.0423
INFO - 2022-05-10 20:05:17 --> Config Class Initialized
INFO - 2022-05-10 20:05:17 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:05:17 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:05:17 --> Utf8 Class Initialized
INFO - 2022-05-10 20:05:17 --> URI Class Initialized
INFO - 2022-05-10 20:05:17 --> Router Class Initialized
INFO - 2022-05-10 20:05:17 --> Output Class Initialized
INFO - 2022-05-10 20:05:17 --> Security Class Initialized
DEBUG - 2022-05-10 20:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:05:17 --> Input Class Initialized
INFO - 2022-05-10 20:05:17 --> Language Class Initialized
INFO - 2022-05-10 20:05:17 --> Language Class Initialized
INFO - 2022-05-10 20:05:17 --> Config Class Initialized
INFO - 2022-05-10 20:05:17 --> Loader Class Initialized
INFO - 2022-05-10 20:05:17 --> Helper loaded: url_helper
INFO - 2022-05-10 20:05:17 --> Database Driver Class Initialized
INFO - 2022-05-10 20:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:05:17 --> Controller Class Initialized
DEBUG - 2022-05-10 20:05:17 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:05:17 --> Model Class Initialized
DEBUG - 2022-05-10 20:05:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:05:17 --> Model Class Initialized
DEBUG - 2022-05-10 20:05:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:05:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:05:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:05:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:05:17 --> Final output sent to browser
DEBUG - 2022-05-10 20:05:17 --> Total execution time: 0.0915
INFO - 2022-05-10 20:05:30 --> Config Class Initialized
INFO - 2022-05-10 20:05:30 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:05:30 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:05:30 --> Utf8 Class Initialized
INFO - 2022-05-10 20:05:30 --> URI Class Initialized
INFO - 2022-05-10 20:05:30 --> Router Class Initialized
INFO - 2022-05-10 20:05:31 --> Output Class Initialized
INFO - 2022-05-10 20:05:31 --> Security Class Initialized
DEBUG - 2022-05-10 20:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:05:31 --> Input Class Initialized
INFO - 2022-05-10 20:05:31 --> Language Class Initialized
INFO - 2022-05-10 20:05:31 --> Language Class Initialized
INFO - 2022-05-10 20:05:31 --> Config Class Initialized
INFO - 2022-05-10 20:05:31 --> Loader Class Initialized
INFO - 2022-05-10 20:05:31 --> Helper loaded: url_helper
INFO - 2022-05-10 20:05:31 --> Database Driver Class Initialized
INFO - 2022-05-10 20:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:05:31 --> Controller Class Initialized
DEBUG - 2022-05-10 20:05:31 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:05:31 --> Model Class Initialized
DEBUG - 2022-05-10 20:05:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:05:31 --> Model Class Initialized
INFO - 2022-05-10 20:05:31 --> Final output sent to browser
DEBUG - 2022-05-10 20:05:31 --> Total execution time: 0.0373
INFO - 2022-05-10 20:11:35 --> Config Class Initialized
INFO - 2022-05-10 20:11:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:11:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:11:35 --> Utf8 Class Initialized
INFO - 2022-05-10 20:11:35 --> URI Class Initialized
INFO - 2022-05-10 20:11:35 --> Router Class Initialized
INFO - 2022-05-10 20:11:35 --> Output Class Initialized
INFO - 2022-05-10 20:11:35 --> Security Class Initialized
DEBUG - 2022-05-10 20:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:11:35 --> Input Class Initialized
INFO - 2022-05-10 20:11:35 --> Language Class Initialized
INFO - 2022-05-10 20:11:35 --> Language Class Initialized
INFO - 2022-05-10 20:11:35 --> Config Class Initialized
INFO - 2022-05-10 20:11:35 --> Loader Class Initialized
INFO - 2022-05-10 20:11:35 --> Helper loaded: url_helper
INFO - 2022-05-10 20:11:35 --> Database Driver Class Initialized
INFO - 2022-05-10 20:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:11:35 --> Controller Class Initialized
DEBUG - 2022-05-10 20:11:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:11:35 --> Model Class Initialized
DEBUG - 2022-05-10 20:11:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:11:35 --> Model Class Initialized
INFO - 2022-05-10 20:12:01 --> Config Class Initialized
INFO - 2022-05-10 20:12:01 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:12:01 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:12:01 --> Utf8 Class Initialized
INFO - 2022-05-10 20:12:01 --> URI Class Initialized
INFO - 2022-05-10 20:12:01 --> Router Class Initialized
INFO - 2022-05-10 20:12:01 --> Output Class Initialized
INFO - 2022-05-10 20:12:01 --> Security Class Initialized
DEBUG - 2022-05-10 20:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:12:01 --> Input Class Initialized
INFO - 2022-05-10 20:12:01 --> Language Class Initialized
INFO - 2022-05-10 20:12:01 --> Language Class Initialized
INFO - 2022-05-10 20:12:01 --> Config Class Initialized
INFO - 2022-05-10 20:12:01 --> Loader Class Initialized
INFO - 2022-05-10 20:12:01 --> Helper loaded: url_helper
INFO - 2022-05-10 20:12:01 --> Database Driver Class Initialized
INFO - 2022-05-10 20:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:12:01 --> Controller Class Initialized
DEBUG - 2022-05-10 20:12:01 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:12:01 --> Model Class Initialized
DEBUG - 2022-05-10 20:12:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:12:01 --> Model Class Initialized
DEBUG - 2022-05-10 20:12:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:12:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:12:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:12:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:12:01 --> Final output sent to browser
DEBUG - 2022-05-10 20:12:01 --> Total execution time: 0.0399
INFO - 2022-05-10 20:13:04 --> Config Class Initialized
INFO - 2022-05-10 20:13:04 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:13:04 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:13:04 --> Utf8 Class Initialized
INFO - 2022-05-10 20:13:04 --> URI Class Initialized
INFO - 2022-05-10 20:13:04 --> Router Class Initialized
INFO - 2022-05-10 20:13:04 --> Output Class Initialized
INFO - 2022-05-10 20:13:04 --> Security Class Initialized
DEBUG - 2022-05-10 20:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:13:04 --> Input Class Initialized
INFO - 2022-05-10 20:13:04 --> Language Class Initialized
INFO - 2022-05-10 20:13:04 --> Language Class Initialized
INFO - 2022-05-10 20:13:04 --> Config Class Initialized
INFO - 2022-05-10 20:13:04 --> Loader Class Initialized
INFO - 2022-05-10 20:13:04 --> Helper loaded: url_helper
INFO - 2022-05-10 20:13:04 --> Database Driver Class Initialized
INFO - 2022-05-10 20:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:13:04 --> Controller Class Initialized
DEBUG - 2022-05-10 20:13:04 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:13:04 --> Model Class Initialized
DEBUG - 2022-05-10 20:13:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:13:04 --> Model Class Initialized
DEBUG - 2022-05-10 20:13:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:13:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:13:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:13:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:13:04 --> Final output sent to browser
DEBUG - 2022-05-10 20:13:04 --> Total execution time: 0.0387
INFO - 2022-05-10 20:13:21 --> Config Class Initialized
INFO - 2022-05-10 20:13:21 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:13:21 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:13:21 --> Utf8 Class Initialized
INFO - 2022-05-10 20:13:21 --> URI Class Initialized
INFO - 2022-05-10 20:13:21 --> Router Class Initialized
INFO - 2022-05-10 20:13:21 --> Output Class Initialized
INFO - 2022-05-10 20:13:21 --> Security Class Initialized
DEBUG - 2022-05-10 20:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:13:21 --> Input Class Initialized
INFO - 2022-05-10 20:13:21 --> Language Class Initialized
INFO - 2022-05-10 20:13:21 --> Language Class Initialized
INFO - 2022-05-10 20:13:21 --> Config Class Initialized
INFO - 2022-05-10 20:13:21 --> Loader Class Initialized
INFO - 2022-05-10 20:13:21 --> Helper loaded: url_helper
INFO - 2022-05-10 20:13:21 --> Database Driver Class Initialized
INFO - 2022-05-10 20:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:13:21 --> Controller Class Initialized
DEBUG - 2022-05-10 20:13:21 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:13:21 --> Model Class Initialized
DEBUG - 2022-05-10 20:13:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:13:21 --> Model Class Initialized
INFO - 2022-05-10 20:13:21 --> Final output sent to browser
DEBUG - 2022-05-10 20:13:21 --> Total execution time: 0.0382
INFO - 2022-05-10 20:14:29 --> Config Class Initialized
INFO - 2022-05-10 20:14:29 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:14:29 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:14:29 --> Utf8 Class Initialized
INFO - 2022-05-10 20:14:29 --> URI Class Initialized
INFO - 2022-05-10 20:14:29 --> Router Class Initialized
INFO - 2022-05-10 20:14:29 --> Output Class Initialized
INFO - 2022-05-10 20:14:29 --> Security Class Initialized
DEBUG - 2022-05-10 20:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:14:29 --> Input Class Initialized
INFO - 2022-05-10 20:14:29 --> Language Class Initialized
INFO - 2022-05-10 20:14:29 --> Language Class Initialized
INFO - 2022-05-10 20:14:29 --> Config Class Initialized
INFO - 2022-05-10 20:14:29 --> Loader Class Initialized
INFO - 2022-05-10 20:14:29 --> Helper loaded: url_helper
INFO - 2022-05-10 20:14:29 --> Database Driver Class Initialized
INFO - 2022-05-10 20:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:14:29 --> Controller Class Initialized
DEBUG - 2022-05-10 20:14:29 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:14:29 --> Model Class Initialized
DEBUG - 2022-05-10 20:14:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:14:29 --> Model Class Initialized
INFO - 2022-05-10 20:27:56 --> Config Class Initialized
INFO - 2022-05-10 20:27:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:27:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:27:56 --> Utf8 Class Initialized
INFO - 2022-05-10 20:27:56 --> URI Class Initialized
INFO - 2022-05-10 20:27:56 --> Router Class Initialized
INFO - 2022-05-10 20:27:56 --> Output Class Initialized
INFO - 2022-05-10 20:27:56 --> Security Class Initialized
DEBUG - 2022-05-10 20:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:27:56 --> Input Class Initialized
INFO - 2022-05-10 20:27:56 --> Language Class Initialized
INFO - 2022-05-10 20:27:56 --> Language Class Initialized
INFO - 2022-05-10 20:27:56 --> Config Class Initialized
INFO - 2022-05-10 20:27:56 --> Loader Class Initialized
INFO - 2022-05-10 20:27:56 --> Helper loaded: url_helper
INFO - 2022-05-10 20:27:56 --> Database Driver Class Initialized
INFO - 2022-05-10 20:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:27:56 --> Controller Class Initialized
DEBUG - 2022-05-10 20:27:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:27:56 --> Model Class Initialized
DEBUG - 2022-05-10 20:27:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:27:56 --> Model Class Initialized
ERROR - 2022-05-10 20:27:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::inser_id() N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 93
INFO - 2022-05-10 20:28:07 --> Config Class Initialized
INFO - 2022-05-10 20:28:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:28:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:28:07 --> Utf8 Class Initialized
INFO - 2022-05-10 20:28:07 --> URI Class Initialized
INFO - 2022-05-10 20:28:07 --> Router Class Initialized
INFO - 2022-05-10 20:28:07 --> Output Class Initialized
INFO - 2022-05-10 20:28:07 --> Security Class Initialized
DEBUG - 2022-05-10 20:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:28:07 --> Input Class Initialized
INFO - 2022-05-10 20:28:07 --> Language Class Initialized
INFO - 2022-05-10 20:28:07 --> Language Class Initialized
INFO - 2022-05-10 20:28:07 --> Config Class Initialized
INFO - 2022-05-10 20:28:07 --> Loader Class Initialized
INFO - 2022-05-10 20:28:07 --> Helper loaded: url_helper
INFO - 2022-05-10 20:28:07 --> Database Driver Class Initialized
INFO - 2022-05-10 20:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:28:07 --> Controller Class Initialized
DEBUG - 2022-05-10 20:28:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:28:07 --> Model Class Initialized
DEBUG - 2022-05-10 20:28:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:28:07 --> Model Class Initialized
INFO - 2022-05-10 20:29:16 --> Config Class Initialized
INFO - 2022-05-10 20:29:16 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:29:16 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:29:16 --> Utf8 Class Initialized
INFO - 2022-05-10 20:29:16 --> URI Class Initialized
INFO - 2022-05-10 20:29:16 --> Router Class Initialized
INFO - 2022-05-10 20:29:16 --> Output Class Initialized
INFO - 2022-05-10 20:29:16 --> Security Class Initialized
DEBUG - 2022-05-10 20:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:29:16 --> Input Class Initialized
INFO - 2022-05-10 20:29:16 --> Language Class Initialized
INFO - 2022-05-10 20:29:16 --> Language Class Initialized
INFO - 2022-05-10 20:29:16 --> Config Class Initialized
INFO - 2022-05-10 20:29:16 --> Loader Class Initialized
INFO - 2022-05-10 20:29:16 --> Helper loaded: url_helper
INFO - 2022-05-10 20:29:16 --> Database Driver Class Initialized
INFO - 2022-05-10 20:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:29:16 --> Controller Class Initialized
DEBUG - 2022-05-10 20:29:16 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:29:16 --> Model Class Initialized
DEBUG - 2022-05-10 20:29:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:29:16 --> Model Class Initialized
DEBUG - 2022-05-10 20:29:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:29:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:29:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:29:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:29:16 --> Final output sent to browser
DEBUG - 2022-05-10 20:29:16 --> Total execution time: 0.0390
INFO - 2022-05-10 20:29:19 --> Config Class Initialized
INFO - 2022-05-10 20:29:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:29:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:29:19 --> Utf8 Class Initialized
INFO - 2022-05-10 20:29:19 --> URI Class Initialized
INFO - 2022-05-10 20:29:19 --> Router Class Initialized
INFO - 2022-05-10 20:29:19 --> Output Class Initialized
INFO - 2022-05-10 20:29:19 --> Security Class Initialized
DEBUG - 2022-05-10 20:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:29:19 --> Input Class Initialized
INFO - 2022-05-10 20:29:19 --> Language Class Initialized
INFO - 2022-05-10 20:29:19 --> Language Class Initialized
INFO - 2022-05-10 20:29:19 --> Config Class Initialized
INFO - 2022-05-10 20:29:19 --> Loader Class Initialized
INFO - 2022-05-10 20:29:19 --> Helper loaded: url_helper
INFO - 2022-05-10 20:29:19 --> Database Driver Class Initialized
INFO - 2022-05-10 20:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:29:19 --> Controller Class Initialized
DEBUG - 2022-05-10 20:29:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:29:19 --> Model Class Initialized
DEBUG - 2022-05-10 20:29:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:29:19 --> Model Class Initialized
DEBUG - 2022-05-10 20:29:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:29:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:29:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:29:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:29:19 --> Final output sent to browser
DEBUG - 2022-05-10 20:29:19 --> Total execution time: 0.0409
INFO - 2022-05-10 20:29:35 --> Config Class Initialized
INFO - 2022-05-10 20:29:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:29:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:29:35 --> Utf8 Class Initialized
INFO - 2022-05-10 20:29:35 --> URI Class Initialized
INFO - 2022-05-10 20:29:35 --> Router Class Initialized
INFO - 2022-05-10 20:29:35 --> Output Class Initialized
INFO - 2022-05-10 20:29:35 --> Security Class Initialized
DEBUG - 2022-05-10 20:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:29:35 --> Input Class Initialized
INFO - 2022-05-10 20:29:35 --> Language Class Initialized
INFO - 2022-05-10 20:29:35 --> Language Class Initialized
INFO - 2022-05-10 20:29:35 --> Config Class Initialized
INFO - 2022-05-10 20:29:35 --> Loader Class Initialized
INFO - 2022-05-10 20:29:35 --> Helper loaded: url_helper
INFO - 2022-05-10 20:29:35 --> Database Driver Class Initialized
INFO - 2022-05-10 20:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:29:35 --> Controller Class Initialized
DEBUG - 2022-05-10 20:29:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:29:35 --> Model Class Initialized
DEBUG - 2022-05-10 20:29:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:29:35 --> Model Class Initialized
INFO - 2022-05-10 20:29:35 --> Final output sent to browser
DEBUG - 2022-05-10 20:29:35 --> Total execution time: 0.0271
INFO - 2022-05-10 20:30:33 --> Config Class Initialized
INFO - 2022-05-10 20:30:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:30:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:30:33 --> Utf8 Class Initialized
INFO - 2022-05-10 20:30:33 --> URI Class Initialized
INFO - 2022-05-10 20:30:33 --> Router Class Initialized
INFO - 2022-05-10 20:30:33 --> Output Class Initialized
INFO - 2022-05-10 20:30:33 --> Security Class Initialized
DEBUG - 2022-05-10 20:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:30:33 --> Input Class Initialized
INFO - 2022-05-10 20:30:33 --> Language Class Initialized
INFO - 2022-05-10 20:30:33 --> Language Class Initialized
INFO - 2022-05-10 20:30:33 --> Config Class Initialized
INFO - 2022-05-10 20:30:33 --> Loader Class Initialized
INFO - 2022-05-10 20:30:33 --> Helper loaded: url_helper
INFO - 2022-05-10 20:30:33 --> Database Driver Class Initialized
INFO - 2022-05-10 20:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:30:33 --> Controller Class Initialized
DEBUG - 2022-05-10 20:30:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:30:33 --> Model Class Initialized
DEBUG - 2022-05-10 20:30:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:30:33 --> Model Class Initialized
INFO - 2022-05-10 20:32:13 --> Config Class Initialized
INFO - 2022-05-10 20:32:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:32:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:32:13 --> Utf8 Class Initialized
INFO - 2022-05-10 20:32:13 --> URI Class Initialized
INFO - 2022-05-10 20:32:13 --> Router Class Initialized
INFO - 2022-05-10 20:32:13 --> Output Class Initialized
INFO - 2022-05-10 20:32:13 --> Security Class Initialized
DEBUG - 2022-05-10 20:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:32:13 --> Input Class Initialized
INFO - 2022-05-10 20:32:13 --> Language Class Initialized
INFO - 2022-05-10 20:32:13 --> Language Class Initialized
INFO - 2022-05-10 20:32:13 --> Config Class Initialized
INFO - 2022-05-10 20:32:13 --> Loader Class Initialized
INFO - 2022-05-10 20:32:13 --> Helper loaded: url_helper
INFO - 2022-05-10 20:32:13 --> Database Driver Class Initialized
INFO - 2022-05-10 20:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:32:13 --> Controller Class Initialized
DEBUG - 2022-05-10 20:32:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:32:13 --> Model Class Initialized
DEBUG - 2022-05-10 20:32:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:32:13 --> Model Class Initialized
INFO - 2022-05-10 20:33:31 --> Config Class Initialized
INFO - 2022-05-10 20:33:31 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:33:31 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:33:31 --> Utf8 Class Initialized
INFO - 2022-05-10 20:33:31 --> URI Class Initialized
INFO - 2022-05-10 20:33:31 --> Router Class Initialized
INFO - 2022-05-10 20:33:31 --> Output Class Initialized
INFO - 2022-05-10 20:33:31 --> Security Class Initialized
DEBUG - 2022-05-10 20:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:33:31 --> Input Class Initialized
INFO - 2022-05-10 20:33:31 --> Language Class Initialized
INFO - 2022-05-10 20:33:31 --> Language Class Initialized
INFO - 2022-05-10 20:33:31 --> Config Class Initialized
INFO - 2022-05-10 20:33:31 --> Loader Class Initialized
INFO - 2022-05-10 20:33:31 --> Helper loaded: url_helper
INFO - 2022-05-10 20:33:31 --> Database Driver Class Initialized
INFO - 2022-05-10 20:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:33:31 --> Controller Class Initialized
DEBUG - 2022-05-10 20:33:31 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:33:31 --> Model Class Initialized
DEBUG - 2022-05-10 20:33:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:33:31 --> Model Class Initialized
INFO - 2022-05-10 20:33:34 --> Config Class Initialized
INFO - 2022-05-10 20:33:34 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:33:34 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:33:34 --> Utf8 Class Initialized
INFO - 2022-05-10 20:33:34 --> URI Class Initialized
INFO - 2022-05-10 20:33:34 --> Router Class Initialized
INFO - 2022-05-10 20:33:34 --> Output Class Initialized
INFO - 2022-05-10 20:33:34 --> Security Class Initialized
DEBUG - 2022-05-10 20:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:33:34 --> Input Class Initialized
INFO - 2022-05-10 20:33:34 --> Language Class Initialized
INFO - 2022-05-10 20:33:34 --> Language Class Initialized
INFO - 2022-05-10 20:33:34 --> Config Class Initialized
INFO - 2022-05-10 20:33:34 --> Loader Class Initialized
INFO - 2022-05-10 20:33:34 --> Helper loaded: url_helper
INFO - 2022-05-10 20:33:34 --> Database Driver Class Initialized
INFO - 2022-05-10 20:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:33:34 --> Controller Class Initialized
DEBUG - 2022-05-10 20:33:34 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:33:34 --> Model Class Initialized
DEBUG - 2022-05-10 20:33:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:33:34 --> Model Class Initialized
DEBUG - 2022-05-10 20:33:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:33:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:33:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:33:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:33:34 --> Final output sent to browser
DEBUG - 2022-05-10 20:33:34 --> Total execution time: 0.0396
INFO - 2022-05-10 20:33:40 --> Config Class Initialized
INFO - 2022-05-10 20:33:40 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:33:40 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:33:40 --> Utf8 Class Initialized
INFO - 2022-05-10 20:33:40 --> URI Class Initialized
INFO - 2022-05-10 20:33:40 --> Router Class Initialized
INFO - 2022-05-10 20:33:40 --> Output Class Initialized
INFO - 2022-05-10 20:33:40 --> Security Class Initialized
DEBUG - 2022-05-10 20:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:33:40 --> Input Class Initialized
INFO - 2022-05-10 20:33:40 --> Language Class Initialized
INFO - 2022-05-10 20:33:40 --> Language Class Initialized
INFO - 2022-05-10 20:33:40 --> Config Class Initialized
INFO - 2022-05-10 20:33:40 --> Loader Class Initialized
INFO - 2022-05-10 20:33:40 --> Helper loaded: url_helper
INFO - 2022-05-10 20:33:40 --> Database Driver Class Initialized
INFO - 2022-05-10 20:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:33:40 --> Controller Class Initialized
DEBUG - 2022-05-10 20:33:40 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:33:40 --> Model Class Initialized
DEBUG - 2022-05-10 20:33:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:33:40 --> Model Class Initialized
DEBUG - 2022-05-10 20:33:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:33:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:33:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:33:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:33:40 --> Final output sent to browser
DEBUG - 2022-05-10 20:33:40 --> Total execution time: 0.0424
INFO - 2022-05-10 20:33:53 --> Config Class Initialized
INFO - 2022-05-10 20:33:53 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:33:53 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:33:53 --> Utf8 Class Initialized
INFO - 2022-05-10 20:33:53 --> URI Class Initialized
INFO - 2022-05-10 20:33:53 --> Router Class Initialized
INFO - 2022-05-10 20:33:53 --> Output Class Initialized
INFO - 2022-05-10 20:33:53 --> Security Class Initialized
DEBUG - 2022-05-10 20:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:33:53 --> Input Class Initialized
INFO - 2022-05-10 20:33:53 --> Language Class Initialized
INFO - 2022-05-10 20:33:53 --> Language Class Initialized
INFO - 2022-05-10 20:33:53 --> Config Class Initialized
INFO - 2022-05-10 20:33:53 --> Loader Class Initialized
INFO - 2022-05-10 20:33:53 --> Helper loaded: url_helper
INFO - 2022-05-10 20:33:53 --> Database Driver Class Initialized
INFO - 2022-05-10 20:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:33:53 --> Controller Class Initialized
DEBUG - 2022-05-10 20:33:53 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:33:53 --> Model Class Initialized
DEBUG - 2022-05-10 20:33:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:33:53 --> Model Class Initialized
INFO - 2022-05-10 20:33:53 --> Final output sent to browser
DEBUG - 2022-05-10 20:33:53 --> Total execution time: 0.0354
INFO - 2022-05-10 20:34:50 --> Config Class Initialized
INFO - 2022-05-10 20:34:50 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:34:50 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:34:50 --> Utf8 Class Initialized
INFO - 2022-05-10 20:34:50 --> URI Class Initialized
INFO - 2022-05-10 20:34:50 --> Router Class Initialized
INFO - 2022-05-10 20:34:50 --> Output Class Initialized
INFO - 2022-05-10 20:34:50 --> Security Class Initialized
DEBUG - 2022-05-10 20:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:34:50 --> Input Class Initialized
INFO - 2022-05-10 20:34:50 --> Language Class Initialized
INFO - 2022-05-10 20:34:50 --> Language Class Initialized
INFO - 2022-05-10 20:34:50 --> Config Class Initialized
INFO - 2022-05-10 20:34:50 --> Loader Class Initialized
INFO - 2022-05-10 20:34:50 --> Helper loaded: url_helper
INFO - 2022-05-10 20:34:50 --> Database Driver Class Initialized
INFO - 2022-05-10 20:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:34:50 --> Controller Class Initialized
DEBUG - 2022-05-10 20:34:50 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:34:50 --> Model Class Initialized
DEBUG - 2022-05-10 20:34:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:34:50 --> Model Class Initialized
INFO - 2022-05-10 20:35:30 --> Config Class Initialized
INFO - 2022-05-10 20:35:30 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:35:30 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:35:30 --> Utf8 Class Initialized
INFO - 2022-05-10 20:35:30 --> URI Class Initialized
INFO - 2022-05-10 20:35:30 --> Router Class Initialized
INFO - 2022-05-10 20:35:30 --> Output Class Initialized
INFO - 2022-05-10 20:35:30 --> Security Class Initialized
DEBUG - 2022-05-10 20:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:35:30 --> Input Class Initialized
INFO - 2022-05-10 20:35:30 --> Language Class Initialized
INFO - 2022-05-10 20:35:30 --> Language Class Initialized
INFO - 2022-05-10 20:35:30 --> Config Class Initialized
INFO - 2022-05-10 20:35:30 --> Loader Class Initialized
INFO - 2022-05-10 20:35:30 --> Helper loaded: url_helper
INFO - 2022-05-10 20:35:30 --> Database Driver Class Initialized
INFO - 2022-05-10 20:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:35:30 --> Controller Class Initialized
DEBUG - 2022-05-10 20:35:30 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:35:30 --> Model Class Initialized
DEBUG - 2022-05-10 20:35:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:35:30 --> Model Class Initialized
INFO - 2022-05-10 20:36:15 --> Config Class Initialized
INFO - 2022-05-10 20:36:15 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:36:15 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:36:15 --> Utf8 Class Initialized
INFO - 2022-05-10 20:36:15 --> URI Class Initialized
INFO - 2022-05-10 20:36:15 --> Router Class Initialized
INFO - 2022-05-10 20:36:15 --> Output Class Initialized
INFO - 2022-05-10 20:36:15 --> Security Class Initialized
DEBUG - 2022-05-10 20:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:36:15 --> Input Class Initialized
INFO - 2022-05-10 20:36:15 --> Language Class Initialized
INFO - 2022-05-10 20:36:15 --> Language Class Initialized
INFO - 2022-05-10 20:36:15 --> Config Class Initialized
INFO - 2022-05-10 20:36:15 --> Loader Class Initialized
INFO - 2022-05-10 20:36:15 --> Helper loaded: url_helper
INFO - 2022-05-10 20:36:15 --> Database Driver Class Initialized
INFO - 2022-05-10 20:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:36:15 --> Controller Class Initialized
DEBUG - 2022-05-10 20:36:15 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:36:15 --> Model Class Initialized
DEBUG - 2022-05-10 20:36:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:36:15 --> Model Class Initialized
INFO - 2022-05-10 20:37:53 --> Config Class Initialized
INFO - 2022-05-10 20:37:53 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:37:53 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:37:53 --> Utf8 Class Initialized
INFO - 2022-05-10 20:37:53 --> URI Class Initialized
INFO - 2022-05-10 20:37:53 --> Router Class Initialized
INFO - 2022-05-10 20:37:53 --> Output Class Initialized
INFO - 2022-05-10 20:37:53 --> Security Class Initialized
DEBUG - 2022-05-10 20:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:37:53 --> Input Class Initialized
INFO - 2022-05-10 20:37:53 --> Language Class Initialized
INFO - 2022-05-10 20:37:53 --> Language Class Initialized
INFO - 2022-05-10 20:37:53 --> Config Class Initialized
INFO - 2022-05-10 20:37:53 --> Loader Class Initialized
INFO - 2022-05-10 20:37:53 --> Helper loaded: url_helper
INFO - 2022-05-10 20:37:53 --> Database Driver Class Initialized
INFO - 2022-05-10 20:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:37:53 --> Controller Class Initialized
DEBUG - 2022-05-10 20:37:53 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:37:53 --> Model Class Initialized
DEBUG - 2022-05-10 20:37:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:37:53 --> Model Class Initialized
DEBUG - 2022-05-10 20:37:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:37:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:37:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:37:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:37:53 --> Final output sent to browser
DEBUG - 2022-05-10 20:37:53 --> Total execution time: 0.0408
INFO - 2022-05-10 20:37:56 --> Config Class Initialized
INFO - 2022-05-10 20:37:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:37:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:37:56 --> Utf8 Class Initialized
INFO - 2022-05-10 20:37:56 --> URI Class Initialized
INFO - 2022-05-10 20:37:56 --> Router Class Initialized
INFO - 2022-05-10 20:37:56 --> Output Class Initialized
INFO - 2022-05-10 20:37:56 --> Security Class Initialized
DEBUG - 2022-05-10 20:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:37:56 --> Input Class Initialized
INFO - 2022-05-10 20:37:56 --> Language Class Initialized
INFO - 2022-05-10 20:37:56 --> Language Class Initialized
INFO - 2022-05-10 20:37:56 --> Config Class Initialized
INFO - 2022-05-10 20:37:56 --> Loader Class Initialized
INFO - 2022-05-10 20:37:56 --> Helper loaded: url_helper
INFO - 2022-05-10 20:37:56 --> Database Driver Class Initialized
INFO - 2022-05-10 20:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:37:56 --> Controller Class Initialized
DEBUG - 2022-05-10 20:37:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:37:56 --> Model Class Initialized
DEBUG - 2022-05-10 20:37:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:37:56 --> Model Class Initialized
DEBUG - 2022-05-10 20:37:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:37:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:37:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:37:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:37:56 --> Final output sent to browser
DEBUG - 2022-05-10 20:37:56 --> Total execution time: 0.0537
INFO - 2022-05-10 20:38:02 --> Config Class Initialized
INFO - 2022-05-10 20:38:02 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:38:02 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:38:02 --> Utf8 Class Initialized
INFO - 2022-05-10 20:38:02 --> URI Class Initialized
INFO - 2022-05-10 20:38:02 --> Router Class Initialized
INFO - 2022-05-10 20:38:02 --> Output Class Initialized
INFO - 2022-05-10 20:38:02 --> Security Class Initialized
DEBUG - 2022-05-10 20:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:38:02 --> Input Class Initialized
INFO - 2022-05-10 20:38:02 --> Language Class Initialized
INFO - 2022-05-10 20:38:02 --> Language Class Initialized
INFO - 2022-05-10 20:38:02 --> Config Class Initialized
INFO - 2022-05-10 20:38:02 --> Loader Class Initialized
INFO - 2022-05-10 20:38:02 --> Helper loaded: url_helper
INFO - 2022-05-10 20:38:02 --> Database Driver Class Initialized
INFO - 2022-05-10 20:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:38:02 --> Controller Class Initialized
DEBUG - 2022-05-10 20:38:02 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:38:02 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:38:02 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:38:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:38:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:38:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:38:02 --> Final output sent to browser
DEBUG - 2022-05-10 20:38:02 --> Total execution time: 0.0402
INFO - 2022-05-10 20:38:20 --> Config Class Initialized
INFO - 2022-05-10 20:38:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:38:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:38:20 --> Utf8 Class Initialized
INFO - 2022-05-10 20:38:20 --> URI Class Initialized
INFO - 2022-05-10 20:38:20 --> Router Class Initialized
INFO - 2022-05-10 20:38:20 --> Output Class Initialized
INFO - 2022-05-10 20:38:20 --> Security Class Initialized
DEBUG - 2022-05-10 20:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:38:20 --> Input Class Initialized
INFO - 2022-05-10 20:38:20 --> Language Class Initialized
INFO - 2022-05-10 20:38:20 --> Language Class Initialized
INFO - 2022-05-10 20:38:20 --> Config Class Initialized
INFO - 2022-05-10 20:38:20 --> Loader Class Initialized
INFO - 2022-05-10 20:38:20 --> Helper loaded: url_helper
INFO - 2022-05-10 20:38:20 --> Database Driver Class Initialized
INFO - 2022-05-10 20:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:38:20 --> Controller Class Initialized
DEBUG - 2022-05-10 20:38:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:38:20 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:38:20 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:38:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:38:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-10 20:38:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:38:20 --> Final output sent to browser
DEBUG - 2022-05-10 20:38:20 --> Total execution time: 0.0394
INFO - 2022-05-10 20:38:29 --> Config Class Initialized
INFO - 2022-05-10 20:38:29 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:38:29 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:38:29 --> Utf8 Class Initialized
INFO - 2022-05-10 20:38:29 --> URI Class Initialized
INFO - 2022-05-10 20:38:29 --> Router Class Initialized
INFO - 2022-05-10 20:38:29 --> Output Class Initialized
INFO - 2022-05-10 20:38:29 --> Security Class Initialized
DEBUG - 2022-05-10 20:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:38:29 --> Input Class Initialized
INFO - 2022-05-10 20:38:29 --> Language Class Initialized
INFO - 2022-05-10 20:38:29 --> Language Class Initialized
INFO - 2022-05-10 20:38:29 --> Config Class Initialized
INFO - 2022-05-10 20:38:29 --> Loader Class Initialized
INFO - 2022-05-10 20:38:29 --> Helper loaded: url_helper
INFO - 2022-05-10 20:38:29 --> Database Driver Class Initialized
INFO - 2022-05-10 20:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:38:29 --> Controller Class Initialized
DEBUG - 2022-05-10 20:38:29 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:38:29 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:38:29 --> Model Class Initialized
INFO - 2022-05-10 20:38:29 --> Upload Class Initialized
INFO - 2022-05-10 20:38:29 --> Config Class Initialized
INFO - 2022-05-10 20:38:29 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:38:29 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:38:29 --> Utf8 Class Initialized
INFO - 2022-05-10 20:38:29 --> URI Class Initialized
INFO - 2022-05-10 20:38:29 --> Router Class Initialized
INFO - 2022-05-10 20:38:29 --> Output Class Initialized
INFO - 2022-05-10 20:38:29 --> Security Class Initialized
DEBUG - 2022-05-10 20:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:38:29 --> Input Class Initialized
INFO - 2022-05-10 20:38:29 --> Language Class Initialized
INFO - 2022-05-10 20:38:29 --> Language Class Initialized
INFO - 2022-05-10 20:38:29 --> Config Class Initialized
INFO - 2022-05-10 20:38:29 --> Loader Class Initialized
INFO - 2022-05-10 20:38:29 --> Helper loaded: url_helper
INFO - 2022-05-10 20:38:29 --> Database Driver Class Initialized
INFO - 2022-05-10 20:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:38:29 --> Controller Class Initialized
DEBUG - 2022-05-10 20:38:29 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:38:29 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:38:29 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:38:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:38:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-10 20:38:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:38:29 --> Final output sent to browser
DEBUG - 2022-05-10 20:38:29 --> Total execution time: 0.0308
INFO - 2022-05-10 20:38:35 --> Config Class Initialized
INFO - 2022-05-10 20:38:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:38:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:38:35 --> Utf8 Class Initialized
INFO - 2022-05-10 20:38:35 --> URI Class Initialized
INFO - 2022-05-10 20:38:35 --> Router Class Initialized
INFO - 2022-05-10 20:38:35 --> Output Class Initialized
INFO - 2022-05-10 20:38:35 --> Security Class Initialized
DEBUG - 2022-05-10 20:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:38:35 --> Input Class Initialized
INFO - 2022-05-10 20:38:35 --> Language Class Initialized
INFO - 2022-05-10 20:38:35 --> Language Class Initialized
INFO - 2022-05-10 20:38:35 --> Config Class Initialized
INFO - 2022-05-10 20:38:35 --> Loader Class Initialized
INFO - 2022-05-10 20:38:35 --> Helper loaded: url_helper
INFO - 2022-05-10 20:38:35 --> Database Driver Class Initialized
INFO - 2022-05-10 20:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:38:35 --> Controller Class Initialized
DEBUG - 2022-05-10 20:38:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:38:35 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:38:35 --> Model Class Initialized
DEBUG - 2022-05-10 20:38:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:38:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:38:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:38:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:38:35 --> Final output sent to browser
DEBUG - 2022-05-10 20:38:35 --> Total execution time: 0.0372
INFO - 2022-05-10 20:39:02 --> Config Class Initialized
INFO - 2022-05-10 20:39:02 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:39:02 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:39:02 --> Utf8 Class Initialized
INFO - 2022-05-10 20:39:02 --> URI Class Initialized
INFO - 2022-05-10 20:39:02 --> Router Class Initialized
INFO - 2022-05-10 20:39:02 --> Output Class Initialized
INFO - 2022-05-10 20:39:02 --> Security Class Initialized
DEBUG - 2022-05-10 20:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:39:02 --> Input Class Initialized
INFO - 2022-05-10 20:39:02 --> Language Class Initialized
INFO - 2022-05-10 20:39:02 --> Language Class Initialized
INFO - 2022-05-10 20:39:02 --> Config Class Initialized
INFO - 2022-05-10 20:39:02 --> Loader Class Initialized
INFO - 2022-05-10 20:39:02 --> Helper loaded: url_helper
INFO - 2022-05-10 20:39:02 --> Database Driver Class Initialized
INFO - 2022-05-10 20:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:39:02 --> Controller Class Initialized
DEBUG - 2022-05-10 20:39:02 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:39:02 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:39:02 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:39:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:39:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-10 20:39:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:39:02 --> Final output sent to browser
DEBUG - 2022-05-10 20:39:02 --> Total execution time: 0.0375
INFO - 2022-05-10 20:39:13 --> Config Class Initialized
INFO - 2022-05-10 20:39:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:39:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:39:13 --> Utf8 Class Initialized
INFO - 2022-05-10 20:39:13 --> URI Class Initialized
INFO - 2022-05-10 20:39:13 --> Router Class Initialized
INFO - 2022-05-10 20:39:13 --> Output Class Initialized
INFO - 2022-05-10 20:39:13 --> Security Class Initialized
DEBUG - 2022-05-10 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:39:13 --> Input Class Initialized
INFO - 2022-05-10 20:39:13 --> Language Class Initialized
INFO - 2022-05-10 20:39:13 --> Language Class Initialized
INFO - 2022-05-10 20:39:13 --> Config Class Initialized
INFO - 2022-05-10 20:39:13 --> Loader Class Initialized
INFO - 2022-05-10 20:39:13 --> Helper loaded: url_helper
INFO - 2022-05-10 20:39:13 --> Database Driver Class Initialized
INFO - 2022-05-10 20:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:39:13 --> Controller Class Initialized
DEBUG - 2022-05-10 20:39:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:39:13 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:39:13 --> Model Class Initialized
INFO - 2022-05-10 20:39:13 --> Upload Class Initialized
INFO - 2022-05-10 20:39:14 --> Config Class Initialized
INFO - 2022-05-10 20:39:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:39:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:39:14 --> Utf8 Class Initialized
INFO - 2022-05-10 20:39:14 --> URI Class Initialized
INFO - 2022-05-10 20:39:14 --> Router Class Initialized
INFO - 2022-05-10 20:39:14 --> Output Class Initialized
INFO - 2022-05-10 20:39:14 --> Security Class Initialized
DEBUG - 2022-05-10 20:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:39:14 --> Input Class Initialized
INFO - 2022-05-10 20:39:14 --> Language Class Initialized
INFO - 2022-05-10 20:39:14 --> Language Class Initialized
INFO - 2022-05-10 20:39:14 --> Config Class Initialized
INFO - 2022-05-10 20:39:14 --> Loader Class Initialized
INFO - 2022-05-10 20:39:14 --> Helper loaded: url_helper
INFO - 2022-05-10 20:39:14 --> Database Driver Class Initialized
INFO - 2022-05-10 20:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:39:14 --> Controller Class Initialized
DEBUG - 2022-05-10 20:39:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:39:14 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:39:14 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:39:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:39:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-10 20:39:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:39:14 --> Final output sent to browser
DEBUG - 2022-05-10 20:39:14 --> Total execution time: 0.0373
INFO - 2022-05-10 20:39:21 --> Config Class Initialized
INFO - 2022-05-10 20:39:21 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:39:21 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:39:21 --> Utf8 Class Initialized
INFO - 2022-05-10 20:39:21 --> URI Class Initialized
INFO - 2022-05-10 20:39:21 --> Router Class Initialized
INFO - 2022-05-10 20:39:21 --> Output Class Initialized
INFO - 2022-05-10 20:39:21 --> Security Class Initialized
DEBUG - 2022-05-10 20:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:39:21 --> Input Class Initialized
INFO - 2022-05-10 20:39:21 --> Language Class Initialized
INFO - 2022-05-10 20:39:21 --> Language Class Initialized
INFO - 2022-05-10 20:39:21 --> Config Class Initialized
INFO - 2022-05-10 20:39:21 --> Loader Class Initialized
INFO - 2022-05-10 20:39:21 --> Helper loaded: url_helper
INFO - 2022-05-10 20:39:21 --> Database Driver Class Initialized
INFO - 2022-05-10 20:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:39:21 --> Controller Class Initialized
DEBUG - 2022-05-10 20:39:21 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:39:21 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:39:21 --> Model Class Initialized
DEBUG - 2022-05-10 20:39:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:39:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:39:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:39:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:39:21 --> Final output sent to browser
DEBUG - 2022-05-10 20:39:21 --> Total execution time: 0.0383
INFO - 2022-05-10 20:40:11 --> Config Class Initialized
INFO - 2022-05-10 20:40:11 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:40:11 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:40:11 --> Utf8 Class Initialized
INFO - 2022-05-10 20:40:11 --> URI Class Initialized
INFO - 2022-05-10 20:40:11 --> Router Class Initialized
INFO - 2022-05-10 20:40:11 --> Output Class Initialized
INFO - 2022-05-10 20:40:11 --> Security Class Initialized
DEBUG - 2022-05-10 20:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:40:11 --> Input Class Initialized
INFO - 2022-05-10 20:40:11 --> Language Class Initialized
INFO - 2022-05-10 20:40:11 --> Language Class Initialized
INFO - 2022-05-10 20:40:11 --> Config Class Initialized
INFO - 2022-05-10 20:40:11 --> Loader Class Initialized
INFO - 2022-05-10 20:40:11 --> Helper loaded: url_helper
INFO - 2022-05-10 20:40:11 --> Database Driver Class Initialized
INFO - 2022-05-10 20:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:40:11 --> Controller Class Initialized
DEBUG - 2022-05-10 20:40:11 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:40:11 --> Model Class Initialized
DEBUG - 2022-05-10 20:40:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:40:11 --> Model Class Initialized
DEBUG - 2022-05-10 20:40:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:40:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:40:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:40:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:40:11 --> Final output sent to browser
DEBUG - 2022-05-10 20:40:11 --> Total execution time: 0.0431
INFO - 2022-05-10 20:40:56 --> Config Class Initialized
INFO - 2022-05-10 20:40:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:40:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:40:56 --> Utf8 Class Initialized
INFO - 2022-05-10 20:40:56 --> URI Class Initialized
INFO - 2022-05-10 20:40:56 --> Router Class Initialized
INFO - 2022-05-10 20:40:56 --> Output Class Initialized
INFO - 2022-05-10 20:40:56 --> Security Class Initialized
DEBUG - 2022-05-10 20:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:40:56 --> Input Class Initialized
INFO - 2022-05-10 20:40:56 --> Language Class Initialized
INFO - 2022-05-10 20:40:56 --> Language Class Initialized
INFO - 2022-05-10 20:40:56 --> Config Class Initialized
INFO - 2022-05-10 20:40:56 --> Loader Class Initialized
INFO - 2022-05-10 20:40:56 --> Helper loaded: url_helper
INFO - 2022-05-10 20:40:56 --> Database Driver Class Initialized
INFO - 2022-05-10 20:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:40:56 --> Controller Class Initialized
DEBUG - 2022-05-10 20:40:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:40:56 --> Model Class Initialized
DEBUG - 2022-05-10 20:40:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:40:56 --> Model Class Initialized
DEBUG - 2022-05-10 20:40:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:40:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:40:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:40:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:40:56 --> Final output sent to browser
DEBUG - 2022-05-10 20:40:56 --> Total execution time: 0.0385
INFO - 2022-05-10 20:43:02 --> Config Class Initialized
INFO - 2022-05-10 20:43:02 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:43:02 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:43:02 --> Utf8 Class Initialized
INFO - 2022-05-10 20:43:02 --> URI Class Initialized
INFO - 2022-05-10 20:43:02 --> Router Class Initialized
INFO - 2022-05-10 20:43:02 --> Output Class Initialized
INFO - 2022-05-10 20:43:02 --> Security Class Initialized
DEBUG - 2022-05-10 20:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:43:02 --> Input Class Initialized
INFO - 2022-05-10 20:43:02 --> Language Class Initialized
INFO - 2022-05-10 20:43:02 --> Language Class Initialized
INFO - 2022-05-10 20:43:02 --> Config Class Initialized
INFO - 2022-05-10 20:43:02 --> Loader Class Initialized
INFO - 2022-05-10 20:43:02 --> Helper loaded: url_helper
INFO - 2022-05-10 20:43:02 --> Database Driver Class Initialized
INFO - 2022-05-10 20:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:43:02 --> Controller Class Initialized
DEBUG - 2022-05-10 20:43:02 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:43:02 --> Model Class Initialized
DEBUG - 2022-05-10 20:43:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:43:02 --> Model Class Initialized
DEBUG - 2022-05-10 20:43:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:43:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:43:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:43:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:43:03 --> Final output sent to browser
DEBUG - 2022-05-10 20:43:03 --> Total execution time: 0.0307
INFO - 2022-05-10 20:43:18 --> Config Class Initialized
INFO - 2022-05-10 20:43:18 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:43:18 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:43:18 --> Utf8 Class Initialized
INFO - 2022-05-10 20:43:18 --> URI Class Initialized
INFO - 2022-05-10 20:43:18 --> Router Class Initialized
INFO - 2022-05-10 20:43:18 --> Output Class Initialized
INFO - 2022-05-10 20:43:18 --> Security Class Initialized
DEBUG - 2022-05-10 20:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:43:18 --> Input Class Initialized
INFO - 2022-05-10 20:43:18 --> Language Class Initialized
INFO - 2022-05-10 20:43:18 --> Language Class Initialized
INFO - 2022-05-10 20:43:18 --> Config Class Initialized
INFO - 2022-05-10 20:43:18 --> Loader Class Initialized
INFO - 2022-05-10 20:43:18 --> Helper loaded: url_helper
INFO - 2022-05-10 20:43:18 --> Database Driver Class Initialized
INFO - 2022-05-10 20:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:43:18 --> Controller Class Initialized
DEBUG - 2022-05-10 20:43:18 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:43:18 --> Model Class Initialized
DEBUG - 2022-05-10 20:43:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:43:18 --> Model Class Initialized
INFO - 2022-05-10 20:43:18 --> Final output sent to browser
DEBUG - 2022-05-10 20:43:18 --> Total execution time: 0.0364
INFO - 2022-05-10 20:44:22 --> Config Class Initialized
INFO - 2022-05-10 20:44:22 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:44:22 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:44:22 --> Utf8 Class Initialized
INFO - 2022-05-10 20:44:22 --> URI Class Initialized
INFO - 2022-05-10 20:44:22 --> Router Class Initialized
INFO - 2022-05-10 20:44:22 --> Output Class Initialized
INFO - 2022-05-10 20:44:22 --> Security Class Initialized
DEBUG - 2022-05-10 20:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:44:22 --> Input Class Initialized
INFO - 2022-05-10 20:44:22 --> Language Class Initialized
INFO - 2022-05-10 20:44:22 --> Language Class Initialized
INFO - 2022-05-10 20:44:22 --> Config Class Initialized
INFO - 2022-05-10 20:44:22 --> Loader Class Initialized
INFO - 2022-05-10 20:44:22 --> Helper loaded: url_helper
INFO - 2022-05-10 20:44:22 --> Database Driver Class Initialized
INFO - 2022-05-10 20:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:44:22 --> Controller Class Initialized
DEBUG - 2022-05-10 20:44:22 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:44:22 --> Model Class Initialized
DEBUG - 2022-05-10 20:44:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:44:22 --> Model Class Initialized
INFO - 2022-05-10 20:45:03 --> Config Class Initialized
INFO - 2022-05-10 20:45:03 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:45:03 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:45:03 --> Utf8 Class Initialized
INFO - 2022-05-10 20:45:03 --> URI Class Initialized
INFO - 2022-05-10 20:45:03 --> Router Class Initialized
INFO - 2022-05-10 20:45:03 --> Output Class Initialized
INFO - 2022-05-10 20:45:03 --> Security Class Initialized
DEBUG - 2022-05-10 20:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:45:03 --> Input Class Initialized
INFO - 2022-05-10 20:45:03 --> Language Class Initialized
INFO - 2022-05-10 20:45:03 --> Language Class Initialized
INFO - 2022-05-10 20:45:03 --> Config Class Initialized
INFO - 2022-05-10 20:45:03 --> Loader Class Initialized
INFO - 2022-05-10 20:45:03 --> Helper loaded: url_helper
INFO - 2022-05-10 20:45:03 --> Database Driver Class Initialized
INFO - 2022-05-10 20:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:45:03 --> Controller Class Initialized
DEBUG - 2022-05-10 20:45:03 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:45:03 --> Model Class Initialized
DEBUG - 2022-05-10 20:45:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:45:03 --> Model Class Initialized
INFO - 2022-05-10 20:46:01 --> Config Class Initialized
INFO - 2022-05-10 20:46:01 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:46:01 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:46:01 --> Utf8 Class Initialized
INFO - 2022-05-10 20:46:01 --> URI Class Initialized
INFO - 2022-05-10 20:46:01 --> Router Class Initialized
INFO - 2022-05-10 20:46:01 --> Output Class Initialized
INFO - 2022-05-10 20:46:01 --> Security Class Initialized
DEBUG - 2022-05-10 20:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:46:01 --> Input Class Initialized
INFO - 2022-05-10 20:46:01 --> Language Class Initialized
INFO - 2022-05-10 20:46:01 --> Language Class Initialized
INFO - 2022-05-10 20:46:01 --> Config Class Initialized
INFO - 2022-05-10 20:46:01 --> Loader Class Initialized
INFO - 2022-05-10 20:46:01 --> Helper loaded: url_helper
INFO - 2022-05-10 20:46:01 --> Database Driver Class Initialized
INFO - 2022-05-10 20:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:46:01 --> Controller Class Initialized
DEBUG - 2022-05-10 20:46:01 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:46:01 --> Model Class Initialized
DEBUG - 2022-05-10 20:46:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:46:01 --> Model Class Initialized
DEBUG - 2022-05-10 20:46:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:46:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:46:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:46:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:46:01 --> Final output sent to browser
DEBUG - 2022-05-10 20:46:01 --> Total execution time: 0.0433
INFO - 2022-05-10 20:46:07 --> Config Class Initialized
INFO - 2022-05-10 20:46:07 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:46:07 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:46:07 --> Utf8 Class Initialized
INFO - 2022-05-10 20:46:07 --> URI Class Initialized
INFO - 2022-05-10 20:46:07 --> Router Class Initialized
INFO - 2022-05-10 20:46:07 --> Output Class Initialized
INFO - 2022-05-10 20:46:07 --> Security Class Initialized
DEBUG - 2022-05-10 20:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:46:07 --> Input Class Initialized
INFO - 2022-05-10 20:46:07 --> Language Class Initialized
INFO - 2022-05-10 20:46:07 --> Language Class Initialized
INFO - 2022-05-10 20:46:07 --> Config Class Initialized
INFO - 2022-05-10 20:46:07 --> Loader Class Initialized
INFO - 2022-05-10 20:46:07 --> Helper loaded: url_helper
INFO - 2022-05-10 20:46:07 --> Database Driver Class Initialized
INFO - 2022-05-10 20:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:46:07 --> Controller Class Initialized
DEBUG - 2022-05-10 20:46:07 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:46:07 --> Model Class Initialized
DEBUG - 2022-05-10 20:46:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:46:07 --> Model Class Initialized
DEBUG - 2022-05-10 20:46:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:46:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:46:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:46:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:46:07 --> Final output sent to browser
DEBUG - 2022-05-10 20:46:07 --> Total execution time: 0.0386
INFO - 2022-05-10 20:46:23 --> Config Class Initialized
INFO - 2022-05-10 20:46:23 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:46:23 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:46:23 --> Utf8 Class Initialized
INFO - 2022-05-10 20:46:23 --> URI Class Initialized
INFO - 2022-05-10 20:46:23 --> Router Class Initialized
INFO - 2022-05-10 20:46:23 --> Output Class Initialized
INFO - 2022-05-10 20:46:23 --> Security Class Initialized
DEBUG - 2022-05-10 20:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:46:23 --> Input Class Initialized
INFO - 2022-05-10 20:46:23 --> Language Class Initialized
INFO - 2022-05-10 20:46:23 --> Language Class Initialized
INFO - 2022-05-10 20:46:23 --> Config Class Initialized
INFO - 2022-05-10 20:46:23 --> Loader Class Initialized
INFO - 2022-05-10 20:46:23 --> Helper loaded: url_helper
INFO - 2022-05-10 20:46:23 --> Database Driver Class Initialized
INFO - 2022-05-10 20:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:46:23 --> Controller Class Initialized
DEBUG - 2022-05-10 20:46:23 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:46:23 --> Model Class Initialized
DEBUG - 2022-05-10 20:46:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:46:23 --> Model Class Initialized
INFO - 2022-05-10 20:46:23 --> Final output sent to browser
DEBUG - 2022-05-10 20:46:23 --> Total execution time: 0.0587
INFO - 2022-05-10 20:47:43 --> Config Class Initialized
INFO - 2022-05-10 20:47:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:47:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:47:43 --> Utf8 Class Initialized
INFO - 2022-05-10 20:47:43 --> URI Class Initialized
INFO - 2022-05-10 20:47:43 --> Router Class Initialized
INFO - 2022-05-10 20:47:43 --> Output Class Initialized
INFO - 2022-05-10 20:47:43 --> Security Class Initialized
DEBUG - 2022-05-10 20:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:47:43 --> Input Class Initialized
INFO - 2022-05-10 20:47:43 --> Language Class Initialized
INFO - 2022-05-10 20:47:43 --> Language Class Initialized
INFO - 2022-05-10 20:47:43 --> Config Class Initialized
INFO - 2022-05-10 20:47:43 --> Loader Class Initialized
INFO - 2022-05-10 20:47:43 --> Helper loaded: url_helper
INFO - 2022-05-10 20:47:43 --> Database Driver Class Initialized
INFO - 2022-05-10 20:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:47:43 --> Controller Class Initialized
DEBUG - 2022-05-10 20:47:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:47:43 --> Model Class Initialized
DEBUG - 2022-05-10 20:47:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:47:43 --> Model Class Initialized
INFO - 2022-05-10 20:48:51 --> Config Class Initialized
INFO - 2022-05-10 20:48:51 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:48:51 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:48:51 --> Utf8 Class Initialized
INFO - 2022-05-10 20:48:51 --> URI Class Initialized
INFO - 2022-05-10 20:48:51 --> Router Class Initialized
INFO - 2022-05-10 20:48:51 --> Output Class Initialized
INFO - 2022-05-10 20:48:51 --> Security Class Initialized
DEBUG - 2022-05-10 20:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:48:51 --> Input Class Initialized
INFO - 2022-05-10 20:48:51 --> Language Class Initialized
INFO - 2022-05-10 20:48:51 --> Language Class Initialized
INFO - 2022-05-10 20:48:51 --> Config Class Initialized
INFO - 2022-05-10 20:48:51 --> Loader Class Initialized
INFO - 2022-05-10 20:48:51 --> Helper loaded: url_helper
INFO - 2022-05-10 20:48:51 --> Database Driver Class Initialized
INFO - 2022-05-10 20:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:48:51 --> Controller Class Initialized
DEBUG - 2022-05-10 20:48:51 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:48:51 --> Model Class Initialized
DEBUG - 2022-05-10 20:48:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:48:51 --> Model Class Initialized
INFO - 2022-05-10 20:49:13 --> Config Class Initialized
INFO - 2022-05-10 20:49:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:49:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:49:13 --> Utf8 Class Initialized
INFO - 2022-05-10 20:49:13 --> URI Class Initialized
INFO - 2022-05-10 20:49:13 --> Router Class Initialized
INFO - 2022-05-10 20:49:13 --> Output Class Initialized
INFO - 2022-05-10 20:49:13 --> Security Class Initialized
DEBUG - 2022-05-10 20:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:49:13 --> Input Class Initialized
INFO - 2022-05-10 20:49:13 --> Language Class Initialized
INFO - 2022-05-10 20:49:13 --> Language Class Initialized
INFO - 2022-05-10 20:49:13 --> Config Class Initialized
INFO - 2022-05-10 20:49:13 --> Loader Class Initialized
INFO - 2022-05-10 20:49:13 --> Helper loaded: url_helper
INFO - 2022-05-10 20:49:13 --> Database Driver Class Initialized
INFO - 2022-05-10 20:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:49:13 --> Controller Class Initialized
DEBUG - 2022-05-10 20:49:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:49:13 --> Model Class Initialized
DEBUG - 2022-05-10 20:49:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:49:13 --> Model Class Initialized
INFO - 2022-05-10 20:50:18 --> Config Class Initialized
INFO - 2022-05-10 20:50:18 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:50:18 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:50:18 --> Utf8 Class Initialized
INFO - 2022-05-10 20:50:18 --> URI Class Initialized
INFO - 2022-05-10 20:50:18 --> Router Class Initialized
INFO - 2022-05-10 20:50:18 --> Output Class Initialized
INFO - 2022-05-10 20:50:18 --> Security Class Initialized
DEBUG - 2022-05-10 20:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:50:18 --> Input Class Initialized
INFO - 2022-05-10 20:50:18 --> Language Class Initialized
INFO - 2022-05-10 20:50:18 --> Language Class Initialized
INFO - 2022-05-10 20:50:18 --> Config Class Initialized
INFO - 2022-05-10 20:50:18 --> Loader Class Initialized
INFO - 2022-05-10 20:50:18 --> Helper loaded: url_helper
INFO - 2022-05-10 20:50:18 --> Database Driver Class Initialized
INFO - 2022-05-10 20:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:50:18 --> Controller Class Initialized
DEBUG - 2022-05-10 20:50:18 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:50:18 --> Model Class Initialized
DEBUG - 2022-05-10 20:50:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:50:18 --> Model Class Initialized
INFO - 2022-05-10 20:50:20 --> Config Class Initialized
INFO - 2022-05-10 20:50:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:50:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:50:20 --> Utf8 Class Initialized
INFO - 2022-05-10 20:50:20 --> URI Class Initialized
INFO - 2022-05-10 20:50:20 --> Router Class Initialized
INFO - 2022-05-10 20:50:20 --> Output Class Initialized
INFO - 2022-05-10 20:50:20 --> Security Class Initialized
DEBUG - 2022-05-10 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:50:20 --> Input Class Initialized
INFO - 2022-05-10 20:50:20 --> Language Class Initialized
INFO - 2022-05-10 20:50:20 --> Language Class Initialized
INFO - 2022-05-10 20:50:20 --> Config Class Initialized
INFO - 2022-05-10 20:50:20 --> Loader Class Initialized
INFO - 2022-05-10 20:50:20 --> Helper loaded: url_helper
INFO - 2022-05-10 20:50:20 --> Database Driver Class Initialized
INFO - 2022-05-10 20:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:50:20 --> Controller Class Initialized
DEBUG - 2022-05-10 20:50:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:50:20 --> Model Class Initialized
DEBUG - 2022-05-10 20:50:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:50:20 --> Model Class Initialized
DEBUG - 2022-05-10 20:50:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:50:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:50:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:50:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:50:20 --> Final output sent to browser
DEBUG - 2022-05-10 20:50:20 --> Total execution time: 0.0403
INFO - 2022-05-10 20:50:24 --> Config Class Initialized
INFO - 2022-05-10 20:50:24 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:50:24 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:50:24 --> Utf8 Class Initialized
INFO - 2022-05-10 20:50:24 --> URI Class Initialized
INFO - 2022-05-10 20:50:24 --> Router Class Initialized
INFO - 2022-05-10 20:50:24 --> Output Class Initialized
INFO - 2022-05-10 20:50:24 --> Security Class Initialized
DEBUG - 2022-05-10 20:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:50:24 --> Input Class Initialized
INFO - 2022-05-10 20:50:24 --> Language Class Initialized
INFO - 2022-05-10 20:50:24 --> Language Class Initialized
INFO - 2022-05-10 20:50:24 --> Config Class Initialized
INFO - 2022-05-10 20:50:24 --> Loader Class Initialized
INFO - 2022-05-10 20:50:24 --> Helper loaded: url_helper
INFO - 2022-05-10 20:50:24 --> Database Driver Class Initialized
INFO - 2022-05-10 20:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:50:24 --> Controller Class Initialized
DEBUG - 2022-05-10 20:50:24 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:50:24 --> Model Class Initialized
DEBUG - 2022-05-10 20:50:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:50:24 --> Model Class Initialized
DEBUG - 2022-05-10 20:50:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:50:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:50:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:50:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:50:24 --> Final output sent to browser
DEBUG - 2022-05-10 20:50:24 --> Total execution time: 0.0387
INFO - 2022-05-10 20:50:39 --> Config Class Initialized
INFO - 2022-05-10 20:50:39 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:50:39 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:50:39 --> Utf8 Class Initialized
INFO - 2022-05-10 20:50:39 --> URI Class Initialized
INFO - 2022-05-10 20:50:39 --> Router Class Initialized
INFO - 2022-05-10 20:50:39 --> Output Class Initialized
INFO - 2022-05-10 20:50:39 --> Security Class Initialized
DEBUG - 2022-05-10 20:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:50:39 --> Input Class Initialized
INFO - 2022-05-10 20:50:39 --> Language Class Initialized
INFO - 2022-05-10 20:50:39 --> Language Class Initialized
INFO - 2022-05-10 20:50:39 --> Config Class Initialized
INFO - 2022-05-10 20:50:39 --> Loader Class Initialized
INFO - 2022-05-10 20:50:39 --> Helper loaded: url_helper
INFO - 2022-05-10 20:50:39 --> Database Driver Class Initialized
INFO - 2022-05-10 20:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:50:39 --> Controller Class Initialized
DEBUG - 2022-05-10 20:50:39 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:50:39 --> Model Class Initialized
DEBUG - 2022-05-10 20:50:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:50:39 --> Model Class Initialized
INFO - 2022-05-10 20:50:39 --> Final output sent to browser
DEBUG - 2022-05-10 20:50:39 --> Total execution time: 0.0367
INFO - 2022-05-10 20:51:54 --> Config Class Initialized
INFO - 2022-05-10 20:51:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:51:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:51:54 --> Utf8 Class Initialized
INFO - 2022-05-10 20:51:54 --> URI Class Initialized
INFO - 2022-05-10 20:51:54 --> Router Class Initialized
INFO - 2022-05-10 20:51:54 --> Output Class Initialized
INFO - 2022-05-10 20:51:54 --> Security Class Initialized
DEBUG - 2022-05-10 20:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:51:54 --> Input Class Initialized
INFO - 2022-05-10 20:51:54 --> Language Class Initialized
INFO - 2022-05-10 20:51:54 --> Language Class Initialized
INFO - 2022-05-10 20:51:54 --> Config Class Initialized
INFO - 2022-05-10 20:51:54 --> Loader Class Initialized
INFO - 2022-05-10 20:51:54 --> Helper loaded: url_helper
INFO - 2022-05-10 20:51:54 --> Database Driver Class Initialized
INFO - 2022-05-10 20:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:51:54 --> Controller Class Initialized
DEBUG - 2022-05-10 20:51:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:51:54 --> Model Class Initialized
DEBUG - 2022-05-10 20:51:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:51:54 --> Model Class Initialized
INFO - 2022-05-10 20:52:06 --> Config Class Initialized
INFO - 2022-05-10 20:52:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:52:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:52:06 --> Utf8 Class Initialized
INFO - 2022-05-10 20:52:06 --> URI Class Initialized
INFO - 2022-05-10 20:52:06 --> Router Class Initialized
INFO - 2022-05-10 20:52:06 --> Output Class Initialized
INFO - 2022-05-10 20:52:06 --> Security Class Initialized
DEBUG - 2022-05-10 20:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:52:06 --> Input Class Initialized
INFO - 2022-05-10 20:52:06 --> Language Class Initialized
INFO - 2022-05-10 20:52:06 --> Language Class Initialized
INFO - 2022-05-10 20:52:06 --> Config Class Initialized
INFO - 2022-05-10 20:52:06 --> Loader Class Initialized
INFO - 2022-05-10 20:52:06 --> Helper loaded: url_helper
INFO - 2022-05-10 20:52:06 --> Database Driver Class Initialized
INFO - 2022-05-10 20:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:52:06 --> Controller Class Initialized
DEBUG - 2022-05-10 20:52:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:52:06 --> Model Class Initialized
DEBUG - 2022-05-10 20:52:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:52:06 --> Model Class Initialized
INFO - 2022-05-10 20:57:31 --> Config Class Initialized
INFO - 2022-05-10 20:57:31 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:57:31 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:57:31 --> Utf8 Class Initialized
INFO - 2022-05-10 20:57:31 --> URI Class Initialized
INFO - 2022-05-10 20:57:31 --> Router Class Initialized
INFO - 2022-05-10 20:57:31 --> Output Class Initialized
INFO - 2022-05-10 20:57:31 --> Security Class Initialized
DEBUG - 2022-05-10 20:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:57:31 --> Input Class Initialized
INFO - 2022-05-10 20:57:31 --> Language Class Initialized
INFO - 2022-05-10 20:57:31 --> Language Class Initialized
INFO - 2022-05-10 20:57:31 --> Config Class Initialized
INFO - 2022-05-10 20:57:31 --> Loader Class Initialized
INFO - 2022-05-10 20:57:31 --> Helper loaded: url_helper
INFO - 2022-05-10 20:57:31 --> Database Driver Class Initialized
INFO - 2022-05-10 20:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:57:31 --> Controller Class Initialized
DEBUG - 2022-05-10 20:57:31 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:57:31 --> Model Class Initialized
DEBUG - 2022-05-10 20:57:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:57:31 --> Model Class Initialized
ERROR - 2022-05-10 20:57:32 --> Query error: Unknown column 's_title' in 'field list' - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `s_title`, `s_description`, `s_keywords`, `s_schema`) VALUES (9, 'st', 'sd', 'sk', 'ss')
INFO - 2022-05-10 20:57:32 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 20:57:53 --> Config Class Initialized
INFO - 2022-05-10 20:57:53 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:57:53 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:57:53 --> Utf8 Class Initialized
INFO - 2022-05-10 20:57:53 --> URI Class Initialized
INFO - 2022-05-10 20:57:53 --> Router Class Initialized
INFO - 2022-05-10 20:57:53 --> Output Class Initialized
INFO - 2022-05-10 20:57:53 --> Security Class Initialized
DEBUG - 2022-05-10 20:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:57:53 --> Input Class Initialized
INFO - 2022-05-10 20:57:53 --> Language Class Initialized
INFO - 2022-05-10 20:57:53 --> Language Class Initialized
INFO - 2022-05-10 20:57:53 --> Config Class Initialized
INFO - 2022-05-10 20:57:53 --> Loader Class Initialized
INFO - 2022-05-10 20:57:53 --> Helper loaded: url_helper
INFO - 2022-05-10 20:57:53 --> Database Driver Class Initialized
INFO - 2022-05-10 20:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:57:53 --> Controller Class Initialized
DEBUG - 2022-05-10 20:57:53 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:57:53 --> Model Class Initialized
DEBUG - 2022-05-10 20:57:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:57:53 --> Model Class Initialized
ERROR - 2022-05-10 20:57:53 --> Query error: Unknown column 'v_id' in 'field list' - Invalid query: INSERT INTO `seo` (`v_id`, `s_title`, `s_description`, `s_keywords`, `s_schema`) VALUES (10, 'st', 'sd', 'sk', 'ss')
INFO - 2022-05-10 20:57:53 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 20:58:16 --> Config Class Initialized
INFO - 2022-05-10 20:58:16 --> Hooks Class Initialized
DEBUG - 2022-05-10 20:58:16 --> UTF-8 Support Enabled
INFO - 2022-05-10 20:58:16 --> Utf8 Class Initialized
INFO - 2022-05-10 20:58:16 --> URI Class Initialized
INFO - 2022-05-10 20:58:16 --> Router Class Initialized
INFO - 2022-05-10 20:58:16 --> Output Class Initialized
INFO - 2022-05-10 20:58:16 --> Security Class Initialized
DEBUG - 2022-05-10 20:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 20:58:16 --> Input Class Initialized
INFO - 2022-05-10 20:58:16 --> Language Class Initialized
INFO - 2022-05-10 20:58:16 --> Language Class Initialized
INFO - 2022-05-10 20:58:16 --> Config Class Initialized
INFO - 2022-05-10 20:58:16 --> Loader Class Initialized
INFO - 2022-05-10 20:58:16 --> Helper loaded: url_helper
INFO - 2022-05-10 20:58:16 --> Database Driver Class Initialized
INFO - 2022-05-10 20:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 20:58:16 --> Controller Class Initialized
DEBUG - 2022-05-10 20:58:16 --> Admin MX_Controller Initialized
INFO - 2022-05-10 20:58:16 --> Model Class Initialized
DEBUG - 2022-05-10 20:58:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 20:58:16 --> Model Class Initialized
DEBUG - 2022-05-10 20:58:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 20:58:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 20:58:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 20:58:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 20:58:16 --> Final output sent to browser
DEBUG - 2022-05-10 20:58:16 --> Total execution time: 0.0732
INFO - 2022-05-10 21:04:27 --> Config Class Initialized
INFO - 2022-05-10 21:04:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:04:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:04:27 --> Utf8 Class Initialized
INFO - 2022-05-10 21:04:27 --> URI Class Initialized
INFO - 2022-05-10 21:04:27 --> Router Class Initialized
INFO - 2022-05-10 21:04:27 --> Output Class Initialized
INFO - 2022-05-10 21:04:27 --> Security Class Initialized
DEBUG - 2022-05-10 21:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:04:27 --> Input Class Initialized
INFO - 2022-05-10 21:04:27 --> Language Class Initialized
INFO - 2022-05-10 21:04:27 --> Language Class Initialized
INFO - 2022-05-10 21:04:27 --> Config Class Initialized
INFO - 2022-05-10 21:04:27 --> Loader Class Initialized
INFO - 2022-05-10 21:04:27 --> Helper loaded: url_helper
INFO - 2022-05-10 21:04:27 --> Database Driver Class Initialized
INFO - 2022-05-10 21:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:04:27 --> Controller Class Initialized
DEBUG - 2022-05-10 21:04:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:04:27 --> Model Class Initialized
DEBUG - 2022-05-10 21:04:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:04:27 --> Model Class Initialized
DEBUG - 2022-05-10 21:04:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:04:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:04:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:04:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:04:27 --> Final output sent to browser
DEBUG - 2022-05-10 21:04:27 --> Total execution time: 0.0430
INFO - 2022-05-10 21:04:31 --> Config Class Initialized
INFO - 2022-05-10 21:04:31 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:04:31 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:04:31 --> Utf8 Class Initialized
INFO - 2022-05-10 21:04:31 --> URI Class Initialized
INFO - 2022-05-10 21:04:31 --> Router Class Initialized
INFO - 2022-05-10 21:04:31 --> Output Class Initialized
INFO - 2022-05-10 21:04:31 --> Security Class Initialized
DEBUG - 2022-05-10 21:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:04:31 --> Input Class Initialized
INFO - 2022-05-10 21:04:31 --> Language Class Initialized
INFO - 2022-05-10 21:04:31 --> Language Class Initialized
INFO - 2022-05-10 21:04:31 --> Config Class Initialized
INFO - 2022-05-10 21:04:31 --> Loader Class Initialized
INFO - 2022-05-10 21:04:31 --> Helper loaded: url_helper
INFO - 2022-05-10 21:04:31 --> Database Driver Class Initialized
INFO - 2022-05-10 21:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:04:31 --> Controller Class Initialized
DEBUG - 2022-05-10 21:04:31 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:04:31 --> Model Class Initialized
DEBUG - 2022-05-10 21:04:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:04:31 --> Model Class Initialized
DEBUG - 2022-05-10 21:04:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:04:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:04:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:04:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:04:31 --> Final output sent to browser
DEBUG - 2022-05-10 21:04:31 --> Total execution time: 0.0431
INFO - 2022-05-10 21:04:46 --> Config Class Initialized
INFO - 2022-05-10 21:04:46 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:04:46 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:04:46 --> Utf8 Class Initialized
INFO - 2022-05-10 21:04:46 --> URI Class Initialized
INFO - 2022-05-10 21:04:46 --> Router Class Initialized
INFO - 2022-05-10 21:04:46 --> Output Class Initialized
INFO - 2022-05-10 21:04:46 --> Security Class Initialized
DEBUG - 2022-05-10 21:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:04:46 --> Input Class Initialized
INFO - 2022-05-10 21:04:46 --> Language Class Initialized
INFO - 2022-05-10 21:04:46 --> Language Class Initialized
INFO - 2022-05-10 21:04:46 --> Config Class Initialized
INFO - 2022-05-10 21:04:46 --> Loader Class Initialized
INFO - 2022-05-10 21:04:46 --> Helper loaded: url_helper
INFO - 2022-05-10 21:04:46 --> Database Driver Class Initialized
INFO - 2022-05-10 21:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:04:46 --> Controller Class Initialized
DEBUG - 2022-05-10 21:04:46 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:04:46 --> Model Class Initialized
DEBUG - 2022-05-10 21:04:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:04:46 --> Model Class Initialized
INFO - 2022-05-10 21:04:46 --> Final output sent to browser
DEBUG - 2022-05-10 21:04:46 --> Total execution time: 0.0302
INFO - 2022-05-10 21:05:36 --> Config Class Initialized
INFO - 2022-05-10 21:05:36 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:05:36 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:05:36 --> Utf8 Class Initialized
INFO - 2022-05-10 21:05:36 --> URI Class Initialized
INFO - 2022-05-10 21:05:36 --> Router Class Initialized
INFO - 2022-05-10 21:05:36 --> Output Class Initialized
INFO - 2022-05-10 21:05:36 --> Security Class Initialized
DEBUG - 2022-05-10 21:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:05:36 --> Input Class Initialized
INFO - 2022-05-10 21:05:36 --> Language Class Initialized
INFO - 2022-05-10 21:05:36 --> Language Class Initialized
INFO - 2022-05-10 21:05:36 --> Config Class Initialized
INFO - 2022-05-10 21:05:36 --> Loader Class Initialized
INFO - 2022-05-10 21:05:36 --> Helper loaded: url_helper
INFO - 2022-05-10 21:05:36 --> Database Driver Class Initialized
INFO - 2022-05-10 21:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:05:36 --> Controller Class Initialized
DEBUG - 2022-05-10 21:05:36 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:05:36 --> Model Class Initialized
DEBUG - 2022-05-10 21:05:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:05:36 --> Model Class Initialized
ERROR - 2022-05-10 21:05:36 --> Severity: Notice --> Undefined index: color N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 113
ERROR - 2022-05-10 21:05:36 --> Severity: Notice --> Undefined index: transmission N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-10 21:05:36 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:05:36 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:05:36 --> Query error: Column 'color' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (12, 'Deisel', NULL, NULL, NULL, NULL)
INFO - 2022-05-10 21:05:36 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:06:32 --> Config Class Initialized
INFO - 2022-05-10 21:06:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:06:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:06:32 --> Utf8 Class Initialized
INFO - 2022-05-10 21:06:32 --> URI Class Initialized
INFO - 2022-05-10 21:06:32 --> Router Class Initialized
INFO - 2022-05-10 21:06:32 --> Output Class Initialized
INFO - 2022-05-10 21:06:32 --> Security Class Initialized
DEBUG - 2022-05-10 21:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:06:32 --> Input Class Initialized
INFO - 2022-05-10 21:06:32 --> Language Class Initialized
INFO - 2022-05-10 21:06:32 --> Language Class Initialized
INFO - 2022-05-10 21:06:32 --> Config Class Initialized
INFO - 2022-05-10 21:06:32 --> Loader Class Initialized
INFO - 2022-05-10 21:06:32 --> Helper loaded: url_helper
INFO - 2022-05-10 21:06:32 --> Database Driver Class Initialized
INFO - 2022-05-10 21:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:06:32 --> Controller Class Initialized
DEBUG - 2022-05-10 21:06:32 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:06:32 --> Model Class Initialized
DEBUG - 2022-05-10 21:06:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:06:32 --> Model Class Initialized
ERROR - 2022-05-10 21:06:32 --> Severity: Notice --> Undefined index: color N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 113
ERROR - 2022-05-10 21:06:32 --> Severity: Notice --> Undefined index: transmission N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-10 21:06:32 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:06:32 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:06:32 --> Query error: Unknown column 'vc_name' in 'field list' - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `vc_name`, `transmission_type`, `seater`, `body_type`) VALUES (13, 'Deisel', NULL, NULL, NULL, NULL)
INFO - 2022-05-10 21:06:32 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:06:57 --> Config Class Initialized
INFO - 2022-05-10 21:06:57 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:06:57 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:06:57 --> Utf8 Class Initialized
INFO - 2022-05-10 21:06:57 --> URI Class Initialized
INFO - 2022-05-10 21:06:57 --> Router Class Initialized
INFO - 2022-05-10 21:06:57 --> Output Class Initialized
INFO - 2022-05-10 21:06:57 --> Security Class Initialized
DEBUG - 2022-05-10 21:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:06:57 --> Input Class Initialized
INFO - 2022-05-10 21:06:57 --> Language Class Initialized
INFO - 2022-05-10 21:06:57 --> Language Class Initialized
INFO - 2022-05-10 21:06:57 --> Config Class Initialized
INFO - 2022-05-10 21:06:57 --> Loader Class Initialized
INFO - 2022-05-10 21:06:57 --> Helper loaded: url_helper
INFO - 2022-05-10 21:06:57 --> Database Driver Class Initialized
INFO - 2022-05-10 21:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:06:57 --> Controller Class Initialized
DEBUG - 2022-05-10 21:06:57 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:06:57 --> Model Class Initialized
DEBUG - 2022-05-10 21:06:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:06:57 --> Model Class Initialized
ERROR - 2022-05-10 21:06:57 --> Severity: Notice --> Undefined index: transmission N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-10 21:06:57 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:06:57 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:06:57 --> Query error: Column 'transmission_type' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (14, 'Deisel', 'white', NULL, NULL, NULL)
INFO - 2022-05-10 21:06:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:07:20 --> Config Class Initialized
INFO - 2022-05-10 21:07:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:07:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:07:20 --> Utf8 Class Initialized
INFO - 2022-05-10 21:07:20 --> URI Class Initialized
INFO - 2022-05-10 21:07:20 --> Router Class Initialized
INFO - 2022-05-10 21:07:20 --> Output Class Initialized
INFO - 2022-05-10 21:07:20 --> Security Class Initialized
DEBUG - 2022-05-10 21:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:07:20 --> Input Class Initialized
INFO - 2022-05-10 21:07:20 --> Language Class Initialized
INFO - 2022-05-10 21:07:20 --> Language Class Initialized
INFO - 2022-05-10 21:07:20 --> Config Class Initialized
INFO - 2022-05-10 21:07:20 --> Loader Class Initialized
INFO - 2022-05-10 21:07:20 --> Helper loaded: url_helper
INFO - 2022-05-10 21:07:20 --> Database Driver Class Initialized
INFO - 2022-05-10 21:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:07:20 --> Controller Class Initialized
DEBUG - 2022-05-10 21:07:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:07:20 --> Model Class Initialized
DEBUG - 2022-05-10 21:07:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:07:20 --> Model Class Initialized
ERROR - 2022-05-10 21:07:21 --> Severity: Notice --> Undefined index: transmission N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-10 21:07:21 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:07:21 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:07:21 --> Query error: Column 'transmission_type' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (15, 'Deisel', 'white', NULL, NULL, NULL)
INFO - 2022-05-10 21:07:21 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:07:47 --> Config Class Initialized
INFO - 2022-05-10 21:07:47 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:07:47 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:07:47 --> Utf8 Class Initialized
INFO - 2022-05-10 21:07:47 --> URI Class Initialized
INFO - 2022-05-10 21:07:47 --> Router Class Initialized
INFO - 2022-05-10 21:07:47 --> Output Class Initialized
INFO - 2022-05-10 21:07:47 --> Security Class Initialized
DEBUG - 2022-05-10 21:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:07:47 --> Input Class Initialized
INFO - 2022-05-10 21:07:47 --> Language Class Initialized
INFO - 2022-05-10 21:07:47 --> Language Class Initialized
INFO - 2022-05-10 21:07:47 --> Config Class Initialized
INFO - 2022-05-10 21:07:47 --> Loader Class Initialized
INFO - 2022-05-10 21:07:47 --> Helper loaded: url_helper
INFO - 2022-05-10 21:07:47 --> Database Driver Class Initialized
INFO - 2022-05-10 21:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:07:47 --> Controller Class Initialized
DEBUG - 2022-05-10 21:07:47 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:07:47 --> Model Class Initialized
DEBUG - 2022-05-10 21:07:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:07:47 --> Model Class Initialized
ERROR - 2022-05-10 21:07:48 --> Severity: Notice --> Undefined index: transmission N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-10 21:07:48 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:07:48 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:07:48 --> Query error: Column 'transmission_type' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (16, 'Deisel', 'white', NULL, NULL, NULL)
INFO - 2022-05-10 21:07:48 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:08:46 --> Config Class Initialized
INFO - 2022-05-10 21:08:46 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:08:46 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:08:46 --> Utf8 Class Initialized
INFO - 2022-05-10 21:08:46 --> URI Class Initialized
INFO - 2022-05-10 21:08:46 --> Router Class Initialized
INFO - 2022-05-10 21:08:46 --> Output Class Initialized
INFO - 2022-05-10 21:08:46 --> Security Class Initialized
DEBUG - 2022-05-10 21:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:08:46 --> Input Class Initialized
INFO - 2022-05-10 21:08:46 --> Language Class Initialized
INFO - 2022-05-10 21:08:46 --> Language Class Initialized
INFO - 2022-05-10 21:08:46 --> Config Class Initialized
INFO - 2022-05-10 21:08:46 --> Loader Class Initialized
INFO - 2022-05-10 21:08:46 --> Helper loaded: url_helper
INFO - 2022-05-10 21:08:46 --> Database Driver Class Initialized
INFO - 2022-05-10 21:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:08:46 --> Controller Class Initialized
DEBUG - 2022-05-10 21:08:46 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:08:46 --> Model Class Initialized
DEBUG - 2022-05-10 21:08:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:08:46 --> Model Class Initialized
ERROR - 2022-05-10 21:08:46 --> Severity: Notice --> Undefined index: transmission N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 114
ERROR - 2022-05-10 21:08:46 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:08:46 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:08:46 --> Query error: Column 'transmission_type' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (17, 'Deisel', 'white', NULL, NULL, NULL)
INFO - 2022-05-10 21:08:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:09:03 --> Config Class Initialized
INFO - 2022-05-10 21:09:03 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:09:03 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:09:03 --> Utf8 Class Initialized
INFO - 2022-05-10 21:09:03 --> URI Class Initialized
INFO - 2022-05-10 21:09:03 --> Router Class Initialized
INFO - 2022-05-10 21:09:03 --> Output Class Initialized
INFO - 2022-05-10 21:09:03 --> Security Class Initialized
DEBUG - 2022-05-10 21:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:09:03 --> Input Class Initialized
INFO - 2022-05-10 21:09:03 --> Language Class Initialized
INFO - 2022-05-10 21:09:03 --> Language Class Initialized
INFO - 2022-05-10 21:09:03 --> Config Class Initialized
INFO - 2022-05-10 21:09:03 --> Loader Class Initialized
INFO - 2022-05-10 21:09:03 --> Helper loaded: url_helper
INFO - 2022-05-10 21:09:03 --> Database Driver Class Initialized
INFO - 2022-05-10 21:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:09:03 --> Controller Class Initialized
DEBUG - 2022-05-10 21:09:03 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:09:03 --> Model Class Initialized
DEBUG - 2022-05-10 21:09:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:09:03 --> Model Class Initialized
DEBUG - 2022-05-10 21:09:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:09:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:09:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:09:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:09:03 --> Final output sent to browser
DEBUG - 2022-05-10 21:09:03 --> Total execution time: 0.0409
INFO - 2022-05-10 21:09:15 --> Config Class Initialized
INFO - 2022-05-10 21:09:15 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:09:15 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:09:15 --> Utf8 Class Initialized
INFO - 2022-05-10 21:09:15 --> URI Class Initialized
INFO - 2022-05-10 21:09:15 --> Router Class Initialized
INFO - 2022-05-10 21:09:15 --> Output Class Initialized
INFO - 2022-05-10 21:09:15 --> Security Class Initialized
DEBUG - 2022-05-10 21:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:09:15 --> Input Class Initialized
INFO - 2022-05-10 21:09:15 --> Language Class Initialized
INFO - 2022-05-10 21:09:15 --> Language Class Initialized
INFO - 2022-05-10 21:09:15 --> Config Class Initialized
INFO - 2022-05-10 21:09:15 --> Loader Class Initialized
INFO - 2022-05-10 21:09:15 --> Helper loaded: url_helper
INFO - 2022-05-10 21:09:15 --> Database Driver Class Initialized
INFO - 2022-05-10 21:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:09:15 --> Controller Class Initialized
DEBUG - 2022-05-10 21:09:15 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:09:15 --> Model Class Initialized
DEBUG - 2022-05-10 21:09:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:09:15 --> Model Class Initialized
INFO - 2022-05-10 21:09:15 --> Final output sent to browser
DEBUG - 2022-05-10 21:09:15 --> Total execution time: 0.0400
INFO - 2022-05-10 21:09:48 --> Config Class Initialized
INFO - 2022-05-10 21:09:48 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:09:48 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:09:48 --> Utf8 Class Initialized
INFO - 2022-05-10 21:09:48 --> URI Class Initialized
INFO - 2022-05-10 21:09:48 --> Router Class Initialized
INFO - 2022-05-10 21:09:48 --> Output Class Initialized
INFO - 2022-05-10 21:09:48 --> Security Class Initialized
DEBUG - 2022-05-10 21:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:09:48 --> Input Class Initialized
INFO - 2022-05-10 21:09:48 --> Language Class Initialized
INFO - 2022-05-10 21:09:48 --> Language Class Initialized
INFO - 2022-05-10 21:09:48 --> Config Class Initialized
INFO - 2022-05-10 21:09:48 --> Loader Class Initialized
INFO - 2022-05-10 21:09:48 --> Helper loaded: url_helper
INFO - 2022-05-10 21:09:48 --> Database Driver Class Initialized
INFO - 2022-05-10 21:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:09:48 --> Controller Class Initialized
DEBUG - 2022-05-10 21:09:48 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:09:48 --> Model Class Initialized
DEBUG - 2022-05-10 21:09:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:09:48 --> Model Class Initialized
ERROR - 2022-05-10 21:09:50 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:09:50 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:09:50 --> Query error: Column 'seater' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (18, 'Deisel', 'white', 'Manual', NULL, NULL)
INFO - 2022-05-10 21:09:50 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:10:16 --> Config Class Initialized
INFO - 2022-05-10 21:10:16 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:10:16 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:10:16 --> Utf8 Class Initialized
INFO - 2022-05-10 21:10:16 --> URI Class Initialized
INFO - 2022-05-10 21:10:16 --> Router Class Initialized
INFO - 2022-05-10 21:10:16 --> Output Class Initialized
INFO - 2022-05-10 21:10:16 --> Security Class Initialized
DEBUG - 2022-05-10 21:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:10:16 --> Input Class Initialized
INFO - 2022-05-10 21:10:16 --> Language Class Initialized
INFO - 2022-05-10 21:10:16 --> Language Class Initialized
INFO - 2022-05-10 21:10:16 --> Config Class Initialized
INFO - 2022-05-10 21:10:16 --> Loader Class Initialized
INFO - 2022-05-10 21:10:16 --> Helper loaded: url_helper
INFO - 2022-05-10 21:10:16 --> Database Driver Class Initialized
INFO - 2022-05-10 21:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:10:16 --> Controller Class Initialized
DEBUG - 2022-05-10 21:10:16 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:10:16 --> Model Class Initialized
DEBUG - 2022-05-10 21:10:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:10:16 --> Model Class Initialized
ERROR - 2022-05-10 21:10:17 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:10:17 --> Severity: Notice --> Undefined index: body_type N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 116
ERROR - 2022-05-10 21:10:17 --> Query error: Column 'seater' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (19, 'Deisel', 'white', 'Manual', NULL, NULL)
INFO - 2022-05-10 21:10:17 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:10:47 --> Config Class Initialized
INFO - 2022-05-10 21:10:47 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:10:47 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:10:47 --> Utf8 Class Initialized
INFO - 2022-05-10 21:10:47 --> URI Class Initialized
INFO - 2022-05-10 21:10:47 --> Router Class Initialized
INFO - 2022-05-10 21:10:47 --> Output Class Initialized
INFO - 2022-05-10 21:10:47 --> Security Class Initialized
DEBUG - 2022-05-10 21:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:10:47 --> Input Class Initialized
INFO - 2022-05-10 21:10:47 --> Language Class Initialized
INFO - 2022-05-10 21:10:47 --> Language Class Initialized
INFO - 2022-05-10 21:10:47 --> Config Class Initialized
INFO - 2022-05-10 21:10:47 --> Loader Class Initialized
INFO - 2022-05-10 21:10:47 --> Helper loaded: url_helper
INFO - 2022-05-10 21:10:47 --> Database Driver Class Initialized
INFO - 2022-05-10 21:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:10:47 --> Controller Class Initialized
DEBUG - 2022-05-10 21:10:47 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:10:47 --> Model Class Initialized
DEBUG - 2022-05-10 21:10:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:10:47 --> Model Class Initialized
ERROR - 2022-05-10 21:10:47 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:10:47 --> Query error: Column 'seater' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (20, 'Deisel', 'white', 'Manual', NULL, 'bt 1')
INFO - 2022-05-10 21:10:47 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:10:51 --> Config Class Initialized
INFO - 2022-05-10 21:10:51 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:10:51 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:10:51 --> Utf8 Class Initialized
INFO - 2022-05-10 21:10:51 --> URI Class Initialized
INFO - 2022-05-10 21:10:51 --> Router Class Initialized
INFO - 2022-05-10 21:10:51 --> Output Class Initialized
INFO - 2022-05-10 21:10:51 --> Security Class Initialized
DEBUG - 2022-05-10 21:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:10:51 --> Input Class Initialized
INFO - 2022-05-10 21:10:51 --> Language Class Initialized
INFO - 2022-05-10 21:10:51 --> Language Class Initialized
INFO - 2022-05-10 21:10:51 --> Config Class Initialized
INFO - 2022-05-10 21:10:51 --> Loader Class Initialized
INFO - 2022-05-10 21:10:51 --> Helper loaded: url_helper
INFO - 2022-05-10 21:10:51 --> Database Driver Class Initialized
INFO - 2022-05-10 21:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:10:51 --> Controller Class Initialized
DEBUG - 2022-05-10 21:10:51 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:10:51 --> Model Class Initialized
DEBUG - 2022-05-10 21:10:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:10:51 --> Model Class Initialized
DEBUG - 2022-05-10 21:10:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:10:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:10:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:10:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:10:51 --> Final output sent to browser
DEBUG - 2022-05-10 21:10:51 --> Total execution time: 0.0456
INFO - 2022-05-10 21:11:03 --> Config Class Initialized
INFO - 2022-05-10 21:11:03 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:11:03 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:11:03 --> Utf8 Class Initialized
INFO - 2022-05-10 21:11:03 --> URI Class Initialized
INFO - 2022-05-10 21:11:03 --> Router Class Initialized
INFO - 2022-05-10 21:11:03 --> Output Class Initialized
INFO - 2022-05-10 21:11:03 --> Security Class Initialized
DEBUG - 2022-05-10 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:11:03 --> Input Class Initialized
INFO - 2022-05-10 21:11:03 --> Language Class Initialized
INFO - 2022-05-10 21:11:03 --> Language Class Initialized
INFO - 2022-05-10 21:11:03 --> Config Class Initialized
INFO - 2022-05-10 21:11:03 --> Loader Class Initialized
INFO - 2022-05-10 21:11:03 --> Helper loaded: url_helper
INFO - 2022-05-10 21:11:03 --> Database Driver Class Initialized
INFO - 2022-05-10 21:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:11:03 --> Controller Class Initialized
DEBUG - 2022-05-10 21:11:03 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:11:03 --> Model Class Initialized
DEBUG - 2022-05-10 21:11:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:11:03 --> Model Class Initialized
INFO - 2022-05-10 21:11:03 --> Final output sent to browser
DEBUG - 2022-05-10 21:11:03 --> Total execution time: 0.0355
INFO - 2022-05-10 21:11:43 --> Config Class Initialized
INFO - 2022-05-10 21:11:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:11:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:11:43 --> Utf8 Class Initialized
INFO - 2022-05-10 21:11:43 --> URI Class Initialized
INFO - 2022-05-10 21:11:43 --> Router Class Initialized
INFO - 2022-05-10 21:11:43 --> Output Class Initialized
INFO - 2022-05-10 21:11:43 --> Security Class Initialized
DEBUG - 2022-05-10 21:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:11:43 --> Input Class Initialized
INFO - 2022-05-10 21:11:43 --> Language Class Initialized
INFO - 2022-05-10 21:11:43 --> Language Class Initialized
INFO - 2022-05-10 21:11:43 --> Config Class Initialized
INFO - 2022-05-10 21:11:43 --> Loader Class Initialized
INFO - 2022-05-10 21:11:43 --> Helper loaded: url_helper
INFO - 2022-05-10 21:11:43 --> Database Driver Class Initialized
INFO - 2022-05-10 21:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:11:43 --> Controller Class Initialized
DEBUG - 2022-05-10 21:11:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:11:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:11:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:11:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:11:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:11:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:11:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:11:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:11:43 --> Final output sent to browser
DEBUG - 2022-05-10 21:11:43 --> Total execution time: 0.0620
INFO - 2022-05-10 21:13:24 --> Config Class Initialized
INFO - 2022-05-10 21:13:24 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:13:24 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:13:24 --> Utf8 Class Initialized
INFO - 2022-05-10 21:13:24 --> URI Class Initialized
INFO - 2022-05-10 21:13:24 --> Router Class Initialized
INFO - 2022-05-10 21:13:24 --> Output Class Initialized
INFO - 2022-05-10 21:13:24 --> Security Class Initialized
DEBUG - 2022-05-10 21:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:13:24 --> Input Class Initialized
INFO - 2022-05-10 21:13:24 --> Language Class Initialized
INFO - 2022-05-10 21:13:24 --> Language Class Initialized
INFO - 2022-05-10 21:13:24 --> Config Class Initialized
INFO - 2022-05-10 21:13:24 --> Loader Class Initialized
INFO - 2022-05-10 21:13:24 --> Helper loaded: url_helper
INFO - 2022-05-10 21:13:24 --> Database Driver Class Initialized
INFO - 2022-05-10 21:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:13:24 --> Controller Class Initialized
DEBUG - 2022-05-10 21:13:24 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:13:24 --> Model Class Initialized
DEBUG - 2022-05-10 21:13:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:13:24 --> Model Class Initialized
DEBUG - 2022-05-10 21:13:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:13:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:13:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:13:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:13:25 --> Final output sent to browser
DEBUG - 2022-05-10 21:13:25 --> Total execution time: 0.3429
INFO - 2022-05-10 21:13:38 --> Config Class Initialized
INFO - 2022-05-10 21:13:38 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:13:38 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:13:38 --> Utf8 Class Initialized
INFO - 2022-05-10 21:13:38 --> URI Class Initialized
INFO - 2022-05-10 21:13:38 --> Router Class Initialized
INFO - 2022-05-10 21:13:38 --> Output Class Initialized
INFO - 2022-05-10 21:13:38 --> Security Class Initialized
DEBUG - 2022-05-10 21:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:13:38 --> Input Class Initialized
INFO - 2022-05-10 21:13:38 --> Language Class Initialized
INFO - 2022-05-10 21:13:38 --> Language Class Initialized
INFO - 2022-05-10 21:13:38 --> Config Class Initialized
INFO - 2022-05-10 21:13:38 --> Loader Class Initialized
INFO - 2022-05-10 21:13:38 --> Helper loaded: url_helper
INFO - 2022-05-10 21:13:38 --> Database Driver Class Initialized
INFO - 2022-05-10 21:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:13:38 --> Controller Class Initialized
DEBUG - 2022-05-10 21:13:38 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:13:38 --> Model Class Initialized
DEBUG - 2022-05-10 21:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:13:38 --> Model Class Initialized
DEBUG - 2022-05-10 21:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:13:38 --> Final output sent to browser
DEBUG - 2022-05-10 21:13:38 --> Total execution time: 0.0795
INFO - 2022-05-10 21:15:02 --> Config Class Initialized
INFO - 2022-05-10 21:15:02 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:15:02 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:15:02 --> Utf8 Class Initialized
INFO - 2022-05-10 21:15:02 --> URI Class Initialized
INFO - 2022-05-10 21:15:02 --> Router Class Initialized
INFO - 2022-05-10 21:15:02 --> Output Class Initialized
INFO - 2022-05-10 21:15:02 --> Security Class Initialized
DEBUG - 2022-05-10 21:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:15:02 --> Input Class Initialized
INFO - 2022-05-10 21:15:02 --> Language Class Initialized
INFO - 2022-05-10 21:15:02 --> Language Class Initialized
INFO - 2022-05-10 21:15:02 --> Config Class Initialized
INFO - 2022-05-10 21:15:02 --> Loader Class Initialized
INFO - 2022-05-10 21:15:02 --> Helper loaded: url_helper
INFO - 2022-05-10 21:15:02 --> Database Driver Class Initialized
INFO - 2022-05-10 21:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:15:02 --> Controller Class Initialized
DEBUG - 2022-05-10 21:15:02 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:15:02 --> Model Class Initialized
DEBUG - 2022-05-10 21:15:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:15:02 --> Model Class Initialized
DEBUG - 2022-05-10 21:15:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:15:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:15:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:15:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:15:02 --> Final output sent to browser
DEBUG - 2022-05-10 21:15:02 --> Total execution time: 0.0700
INFO - 2022-05-10 21:21:37 --> Config Class Initialized
INFO - 2022-05-10 21:21:37 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:21:37 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:21:37 --> Utf8 Class Initialized
INFO - 2022-05-10 21:21:37 --> URI Class Initialized
INFO - 2022-05-10 21:21:37 --> Router Class Initialized
INFO - 2022-05-10 21:21:37 --> Output Class Initialized
INFO - 2022-05-10 21:21:37 --> Security Class Initialized
DEBUG - 2022-05-10 21:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:21:37 --> Input Class Initialized
INFO - 2022-05-10 21:21:37 --> Language Class Initialized
INFO - 2022-05-10 21:21:37 --> Language Class Initialized
INFO - 2022-05-10 21:21:37 --> Config Class Initialized
INFO - 2022-05-10 21:21:37 --> Loader Class Initialized
INFO - 2022-05-10 21:21:37 --> Helper loaded: url_helper
INFO - 2022-05-10 21:21:37 --> Database Driver Class Initialized
INFO - 2022-05-10 21:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:21:37 --> Controller Class Initialized
DEBUG - 2022-05-10 21:21:37 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:21:37 --> Model Class Initialized
DEBUG - 2022-05-10 21:21:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:21:37 --> Model Class Initialized
ERROR - 2022-05-10 21:21:37 --> Severity: Error --> Call to undefined method Admin_model::add_verview() N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 166
INFO - 2022-05-10 21:21:54 --> Config Class Initialized
INFO - 2022-05-10 21:21:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:21:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:21:54 --> Utf8 Class Initialized
INFO - 2022-05-10 21:21:54 --> URI Class Initialized
INFO - 2022-05-10 21:21:54 --> Router Class Initialized
INFO - 2022-05-10 21:21:54 --> Output Class Initialized
INFO - 2022-05-10 21:21:54 --> Security Class Initialized
DEBUG - 2022-05-10 21:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:21:54 --> Input Class Initialized
INFO - 2022-05-10 21:21:54 --> Language Class Initialized
INFO - 2022-05-10 21:21:54 --> Language Class Initialized
INFO - 2022-05-10 21:21:54 --> Config Class Initialized
INFO - 2022-05-10 21:21:54 --> Loader Class Initialized
INFO - 2022-05-10 21:21:54 --> Helper loaded: url_helper
INFO - 2022-05-10 21:21:54 --> Database Driver Class Initialized
INFO - 2022-05-10 21:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:21:54 --> Controller Class Initialized
DEBUG - 2022-05-10 21:21:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:21:54 --> Model Class Initialized
DEBUG - 2022-05-10 21:21:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:21:54 --> Model Class Initialized
ERROR - 2022-05-10 21:21:54 --> Severity: Notice --> Undefined index: rc_number N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 128
ERROR - 2022-05-10 21:21:54 --> Severity: Notice --> Undefined index: insurances N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 130
ERROR - 2022-05-10 21:21:54 --> Query error: Unknown column 'reg_state' in 'field list' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurances`) VALUES (26, '2020', 'Dadar and Nagar Haveli', NULL, '2', NULL)
INFO - 2022-05-10 21:21:54 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:22:21 --> Config Class Initialized
INFO - 2022-05-10 21:22:21 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:22:21 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:22:21 --> Utf8 Class Initialized
INFO - 2022-05-10 21:22:21 --> URI Class Initialized
INFO - 2022-05-10 21:22:21 --> Router Class Initialized
INFO - 2022-05-10 21:22:21 --> Output Class Initialized
INFO - 2022-05-10 21:22:21 --> Security Class Initialized
DEBUG - 2022-05-10 21:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:22:21 --> Input Class Initialized
INFO - 2022-05-10 21:22:21 --> Language Class Initialized
INFO - 2022-05-10 21:22:21 --> Language Class Initialized
INFO - 2022-05-10 21:22:21 --> Config Class Initialized
INFO - 2022-05-10 21:22:21 --> Loader Class Initialized
INFO - 2022-05-10 21:22:21 --> Helper loaded: url_helper
INFO - 2022-05-10 21:22:21 --> Database Driver Class Initialized
INFO - 2022-05-10 21:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:22:21 --> Controller Class Initialized
DEBUG - 2022-05-10 21:22:21 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:22:21 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:22:21 --> Model Class Initialized
ERROR - 2022-05-10 21:22:21 --> Severity: Notice --> Undefined index: rc N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 128
ERROR - 2022-05-10 21:22:21 --> Severity: Notice --> Undefined index: insurances N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 130
ERROR - 2022-05-10 21:22:21 --> Query error: Unknown column 'reg_state' in 'field list' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurances`) VALUES (27, '2020', 'Dadar and Nagar Haveli', NULL, '2', NULL)
INFO - 2022-05-10 21:22:21 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:22:26 --> Config Class Initialized
INFO - 2022-05-10 21:22:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:22:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:22:26 --> Utf8 Class Initialized
INFO - 2022-05-10 21:22:26 --> URI Class Initialized
INFO - 2022-05-10 21:22:26 --> Router Class Initialized
INFO - 2022-05-10 21:22:26 --> Output Class Initialized
INFO - 2022-05-10 21:22:26 --> Security Class Initialized
DEBUG - 2022-05-10 21:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:22:26 --> Input Class Initialized
INFO - 2022-05-10 21:22:26 --> Language Class Initialized
INFO - 2022-05-10 21:22:26 --> Language Class Initialized
INFO - 2022-05-10 21:22:26 --> Config Class Initialized
INFO - 2022-05-10 21:22:26 --> Loader Class Initialized
INFO - 2022-05-10 21:22:26 --> Helper loaded: url_helper
INFO - 2022-05-10 21:22:26 --> Database Driver Class Initialized
INFO - 2022-05-10 21:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:22:26 --> Controller Class Initialized
DEBUG - 2022-05-10 21:22:26 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:22:26 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:22:26 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:22:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:22:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:22:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:22:26 --> Final output sent to browser
DEBUG - 2022-05-10 21:22:26 --> Total execution time: 0.0372
INFO - 2022-05-10 21:22:27 --> Config Class Initialized
INFO - 2022-05-10 21:22:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:22:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:22:27 --> Utf8 Class Initialized
INFO - 2022-05-10 21:22:27 --> URI Class Initialized
INFO - 2022-05-10 21:22:27 --> Router Class Initialized
INFO - 2022-05-10 21:22:27 --> Output Class Initialized
INFO - 2022-05-10 21:22:27 --> Security Class Initialized
DEBUG - 2022-05-10 21:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:22:27 --> Input Class Initialized
INFO - 2022-05-10 21:22:27 --> Language Class Initialized
INFO - 2022-05-10 21:22:27 --> Language Class Initialized
INFO - 2022-05-10 21:22:27 --> Config Class Initialized
INFO - 2022-05-10 21:22:27 --> Loader Class Initialized
INFO - 2022-05-10 21:22:27 --> Helper loaded: url_helper
INFO - 2022-05-10 21:22:27 --> Database Driver Class Initialized
INFO - 2022-05-10 21:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:22:27 --> Controller Class Initialized
DEBUG - 2022-05-10 21:22:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:22:27 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:22:27 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:22:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:22:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:22:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:22:27 --> Final output sent to browser
DEBUG - 2022-05-10 21:22:27 --> Total execution time: 0.0459
INFO - 2022-05-10 21:22:40 --> Config Class Initialized
INFO - 2022-05-10 21:22:40 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:22:40 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:22:40 --> Utf8 Class Initialized
INFO - 2022-05-10 21:22:40 --> URI Class Initialized
INFO - 2022-05-10 21:22:40 --> Router Class Initialized
INFO - 2022-05-10 21:22:40 --> Output Class Initialized
INFO - 2022-05-10 21:22:40 --> Security Class Initialized
DEBUG - 2022-05-10 21:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:22:40 --> Input Class Initialized
INFO - 2022-05-10 21:22:40 --> Language Class Initialized
INFO - 2022-05-10 21:22:40 --> Language Class Initialized
INFO - 2022-05-10 21:22:40 --> Config Class Initialized
INFO - 2022-05-10 21:22:40 --> Loader Class Initialized
INFO - 2022-05-10 21:22:40 --> Helper loaded: url_helper
INFO - 2022-05-10 21:22:40 --> Database Driver Class Initialized
INFO - 2022-05-10 21:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:22:40 --> Controller Class Initialized
DEBUG - 2022-05-10 21:22:40 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:22:40 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:22:40 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:22:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:22:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:22:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:22:40 --> Final output sent to browser
DEBUG - 2022-05-10 21:22:40 --> Total execution time: 0.0501
INFO - 2022-05-10 21:22:57 --> Config Class Initialized
INFO - 2022-05-10 21:22:57 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:22:57 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:22:57 --> Utf8 Class Initialized
INFO - 2022-05-10 21:22:57 --> URI Class Initialized
INFO - 2022-05-10 21:22:57 --> Router Class Initialized
INFO - 2022-05-10 21:22:57 --> Output Class Initialized
INFO - 2022-05-10 21:22:57 --> Security Class Initialized
DEBUG - 2022-05-10 21:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:22:57 --> Input Class Initialized
INFO - 2022-05-10 21:22:57 --> Language Class Initialized
INFO - 2022-05-10 21:22:57 --> Language Class Initialized
INFO - 2022-05-10 21:22:57 --> Config Class Initialized
INFO - 2022-05-10 21:22:57 --> Loader Class Initialized
INFO - 2022-05-10 21:22:57 --> Helper loaded: url_helper
INFO - 2022-05-10 21:22:57 --> Database Driver Class Initialized
INFO - 2022-05-10 21:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:22:57 --> Controller Class Initialized
DEBUG - 2022-05-10 21:22:57 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:22:57 --> Model Class Initialized
DEBUG - 2022-05-10 21:22:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:22:57 --> Model Class Initialized
INFO - 2022-05-10 21:22:57 --> Final output sent to browser
DEBUG - 2022-05-10 21:22:57 --> Total execution time: 0.0436
INFO - 2022-05-10 21:23:27 --> Config Class Initialized
INFO - 2022-05-10 21:23:27 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:23:27 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:23:27 --> Utf8 Class Initialized
INFO - 2022-05-10 21:23:27 --> URI Class Initialized
INFO - 2022-05-10 21:23:27 --> Router Class Initialized
INFO - 2022-05-10 21:23:27 --> Output Class Initialized
INFO - 2022-05-10 21:23:27 --> Security Class Initialized
DEBUG - 2022-05-10 21:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:23:27 --> Input Class Initialized
INFO - 2022-05-10 21:23:27 --> Language Class Initialized
INFO - 2022-05-10 21:23:27 --> Language Class Initialized
INFO - 2022-05-10 21:23:27 --> Config Class Initialized
INFO - 2022-05-10 21:23:27 --> Loader Class Initialized
INFO - 2022-05-10 21:23:27 --> Helper loaded: url_helper
INFO - 2022-05-10 21:23:27 --> Database Driver Class Initialized
INFO - 2022-05-10 21:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:23:27 --> Controller Class Initialized
DEBUG - 2022-05-10 21:23:27 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:23:27 --> Model Class Initialized
DEBUG - 2022-05-10 21:23:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:23:27 --> Model Class Initialized
DEBUG - 2022-05-10 21:23:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:23:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:23:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:23:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:23:27 --> Final output sent to browser
DEBUG - 2022-05-10 21:23:27 --> Total execution time: 0.0403
INFO - 2022-05-10 21:23:39 --> Config Class Initialized
INFO - 2022-05-10 21:23:39 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:23:39 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:23:39 --> Utf8 Class Initialized
INFO - 2022-05-10 21:23:39 --> URI Class Initialized
INFO - 2022-05-10 21:23:39 --> Router Class Initialized
INFO - 2022-05-10 21:23:39 --> Output Class Initialized
INFO - 2022-05-10 21:23:39 --> Security Class Initialized
DEBUG - 2022-05-10 21:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:23:39 --> Input Class Initialized
INFO - 2022-05-10 21:23:39 --> Language Class Initialized
INFO - 2022-05-10 21:23:39 --> Language Class Initialized
INFO - 2022-05-10 21:23:39 --> Config Class Initialized
INFO - 2022-05-10 21:23:39 --> Loader Class Initialized
INFO - 2022-05-10 21:23:39 --> Helper loaded: url_helper
INFO - 2022-05-10 21:23:39 --> Database Driver Class Initialized
INFO - 2022-05-10 21:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:23:39 --> Controller Class Initialized
DEBUG - 2022-05-10 21:23:39 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:23:39 --> Model Class Initialized
DEBUG - 2022-05-10 21:23:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:23:39 --> Model Class Initialized
INFO - 2022-05-10 21:23:39 --> Final output sent to browser
DEBUG - 2022-05-10 21:23:39 --> Total execution time: 0.0371
INFO - 2022-05-10 21:26:15 --> Config Class Initialized
INFO - 2022-05-10 21:26:15 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:26:15 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:26:15 --> Utf8 Class Initialized
INFO - 2022-05-10 21:26:15 --> URI Class Initialized
INFO - 2022-05-10 21:26:15 --> Router Class Initialized
INFO - 2022-05-10 21:26:15 --> Output Class Initialized
INFO - 2022-05-10 21:26:15 --> Security Class Initialized
DEBUG - 2022-05-10 21:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:26:15 --> Input Class Initialized
INFO - 2022-05-10 21:26:15 --> Language Class Initialized
INFO - 2022-05-10 21:26:15 --> Language Class Initialized
INFO - 2022-05-10 21:26:15 --> Config Class Initialized
INFO - 2022-05-10 21:26:15 --> Loader Class Initialized
INFO - 2022-05-10 21:26:15 --> Helper loaded: url_helper
INFO - 2022-05-10 21:26:15 --> Database Driver Class Initialized
INFO - 2022-05-10 21:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:26:15 --> Controller Class Initialized
DEBUG - 2022-05-10 21:26:15 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:26:15 --> Model Class Initialized
DEBUG - 2022-05-10 21:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:26:15 --> Model Class Initialized
DEBUG - 2022-05-10 21:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:26:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:26:15 --> Final output sent to browser
DEBUG - 2022-05-10 21:26:15 --> Total execution time: 0.0406
INFO - 2022-05-10 21:26:43 --> Config Class Initialized
INFO - 2022-05-10 21:26:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:26:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:26:43 --> Utf8 Class Initialized
INFO - 2022-05-10 21:26:43 --> URI Class Initialized
INFO - 2022-05-10 21:26:43 --> Router Class Initialized
INFO - 2022-05-10 21:26:43 --> Output Class Initialized
INFO - 2022-05-10 21:26:43 --> Security Class Initialized
DEBUG - 2022-05-10 21:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:26:43 --> Input Class Initialized
INFO - 2022-05-10 21:26:43 --> Language Class Initialized
INFO - 2022-05-10 21:26:43 --> Language Class Initialized
INFO - 2022-05-10 21:26:43 --> Config Class Initialized
INFO - 2022-05-10 21:26:43 --> Loader Class Initialized
INFO - 2022-05-10 21:26:43 --> Helper loaded: url_helper
INFO - 2022-05-10 21:26:43 --> Database Driver Class Initialized
INFO - 2022-05-10 21:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:26:43 --> Controller Class Initialized
DEBUG - 2022-05-10 21:26:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:26:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:26:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:26:43 --> Model Class Initialized
INFO - 2022-05-10 21:26:43 --> Final output sent to browser
DEBUG - 2022-05-10 21:26:43 --> Total execution time: 0.0304
INFO - 2022-05-10 21:27:23 --> Config Class Initialized
INFO - 2022-05-10 21:27:23 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:27:23 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:27:23 --> Utf8 Class Initialized
INFO - 2022-05-10 21:27:23 --> URI Class Initialized
INFO - 2022-05-10 21:27:23 --> Router Class Initialized
INFO - 2022-05-10 21:27:23 --> Output Class Initialized
INFO - 2022-05-10 21:27:23 --> Security Class Initialized
DEBUG - 2022-05-10 21:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:27:23 --> Input Class Initialized
INFO - 2022-05-10 21:27:23 --> Language Class Initialized
INFO - 2022-05-10 21:27:23 --> Language Class Initialized
INFO - 2022-05-10 21:27:23 --> Config Class Initialized
INFO - 2022-05-10 21:27:23 --> Loader Class Initialized
INFO - 2022-05-10 21:27:23 --> Helper loaded: url_helper
INFO - 2022-05-10 21:27:23 --> Database Driver Class Initialized
INFO - 2022-05-10 21:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:27:23 --> Controller Class Initialized
DEBUG - 2022-05-10 21:27:23 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:27:23 --> Model Class Initialized
DEBUG - 2022-05-10 21:27:23 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:27:23 --> Model Class Initialized
ERROR - 2022-05-10 21:27:23 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:27:23 --> Query error: Column 'seater' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (28, 'Deisel', 'red', 'Automatic', NULL, 'bt 1')
INFO - 2022-05-10 21:27:23 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:28:43 --> Config Class Initialized
INFO - 2022-05-10 21:28:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:28:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:28:43 --> Utf8 Class Initialized
INFO - 2022-05-10 21:28:43 --> URI Class Initialized
INFO - 2022-05-10 21:28:43 --> Router Class Initialized
INFO - 2022-05-10 21:28:43 --> Output Class Initialized
INFO - 2022-05-10 21:28:43 --> Security Class Initialized
DEBUG - 2022-05-10 21:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:28:43 --> Input Class Initialized
INFO - 2022-05-10 21:28:43 --> Language Class Initialized
INFO - 2022-05-10 21:28:43 --> Language Class Initialized
INFO - 2022-05-10 21:28:43 --> Config Class Initialized
INFO - 2022-05-10 21:28:43 --> Loader Class Initialized
INFO - 2022-05-10 21:28:43 --> Helper loaded: url_helper
INFO - 2022-05-10 21:28:43 --> Database Driver Class Initialized
INFO - 2022-05-10 21:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:28:43 --> Controller Class Initialized
DEBUG - 2022-05-10 21:28:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:28:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:28:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:28:43 --> Model Class Initialized
ERROR - 2022-05-10 21:28:43 --> Severity: Notice --> Undefined index: seater N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 115
ERROR - 2022-05-10 21:28:43 --> Query error: Column 'seater' cannot be null - Invalid query: INSERT INTO `vehicle_specification` (`v_id`, `fuel_type`, `color`, `transmission_type`, `seater`, `body_type`) VALUES (29, 'Deisel', 'red', 'Automatic', NULL, 'bt 1')
INFO - 2022-05-10 21:28:43 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:28:47 --> Config Class Initialized
INFO - 2022-05-10 21:28:47 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:28:47 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:28:47 --> Utf8 Class Initialized
INFO - 2022-05-10 21:28:47 --> URI Class Initialized
INFO - 2022-05-10 21:28:47 --> Router Class Initialized
INFO - 2022-05-10 21:28:47 --> Output Class Initialized
INFO - 2022-05-10 21:28:47 --> Security Class Initialized
DEBUG - 2022-05-10 21:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:28:47 --> Input Class Initialized
INFO - 2022-05-10 21:28:47 --> Language Class Initialized
INFO - 2022-05-10 21:28:47 --> Language Class Initialized
INFO - 2022-05-10 21:28:47 --> Config Class Initialized
INFO - 2022-05-10 21:28:47 --> Loader Class Initialized
INFO - 2022-05-10 21:28:47 --> Helper loaded: url_helper
INFO - 2022-05-10 21:28:47 --> Database Driver Class Initialized
INFO - 2022-05-10 21:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:28:47 --> Controller Class Initialized
DEBUG - 2022-05-10 21:28:47 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:28:47 --> Model Class Initialized
DEBUG - 2022-05-10 21:28:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:28:47 --> Model Class Initialized
DEBUG - 2022-05-10 21:28:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:28:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:28:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:28:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:28:47 --> Final output sent to browser
DEBUG - 2022-05-10 21:28:47 --> Total execution time: 0.0387
INFO - 2022-05-10 21:29:54 --> Config Class Initialized
INFO - 2022-05-10 21:29:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:29:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:29:54 --> Utf8 Class Initialized
INFO - 2022-05-10 21:29:54 --> URI Class Initialized
INFO - 2022-05-10 21:29:54 --> Router Class Initialized
INFO - 2022-05-10 21:29:54 --> Output Class Initialized
INFO - 2022-05-10 21:29:54 --> Security Class Initialized
DEBUG - 2022-05-10 21:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:29:54 --> Input Class Initialized
INFO - 2022-05-10 21:29:54 --> Language Class Initialized
INFO - 2022-05-10 21:29:54 --> Language Class Initialized
INFO - 2022-05-10 21:29:54 --> Config Class Initialized
INFO - 2022-05-10 21:29:54 --> Loader Class Initialized
INFO - 2022-05-10 21:29:54 --> Helper loaded: url_helper
INFO - 2022-05-10 21:29:54 --> Database Driver Class Initialized
INFO - 2022-05-10 21:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:29:54 --> Controller Class Initialized
DEBUG - 2022-05-10 21:29:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:29:54 --> Model Class Initialized
DEBUG - 2022-05-10 21:29:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:29:54 --> Model Class Initialized
ERROR - 2022-05-10 21:29:54 --> Severity: Notice --> Undefined index: insurances N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 130
ERROR - 2022-05-10 21:29:54 --> Query error: Unknown column 'reg_state' in 'field list' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurances`) VALUES (30, '2020', 'Delhi', '5465', '2', NULL)
INFO - 2022-05-10 21:29:54 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:30:45 --> Config Class Initialized
INFO - 2022-05-10 21:30:45 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:30:45 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:30:45 --> Utf8 Class Initialized
INFO - 2022-05-10 21:30:45 --> URI Class Initialized
INFO - 2022-05-10 21:30:45 --> Router Class Initialized
INFO - 2022-05-10 21:30:45 --> Output Class Initialized
INFO - 2022-05-10 21:30:45 --> Security Class Initialized
DEBUG - 2022-05-10 21:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:30:45 --> Input Class Initialized
INFO - 2022-05-10 21:30:45 --> Language Class Initialized
INFO - 2022-05-10 21:30:45 --> Language Class Initialized
INFO - 2022-05-10 21:30:45 --> Config Class Initialized
INFO - 2022-05-10 21:30:45 --> Loader Class Initialized
INFO - 2022-05-10 21:30:45 --> Helper loaded: url_helper
INFO - 2022-05-10 21:30:45 --> Database Driver Class Initialized
INFO - 2022-05-10 21:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:30:45 --> Controller Class Initialized
DEBUG - 2022-05-10 21:30:45 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:30:45 --> Model Class Initialized
DEBUG - 2022-05-10 21:30:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:30:45 --> Model Class Initialized
ERROR - 2022-05-10 21:30:46 --> Severity: Notice --> Undefined index: insurances N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 130
ERROR - 2022-05-10 21:30:46 --> Query error: Unknown column 'reg_state' in 'field list' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurances`) VALUES (31, '2020', 'Delhi', '5465', '2', NULL)
INFO - 2022-05-10 21:30:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:32:13 --> Config Class Initialized
INFO - 2022-05-10 21:32:13 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:32:13 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:32:13 --> Utf8 Class Initialized
INFO - 2022-05-10 21:32:13 --> URI Class Initialized
INFO - 2022-05-10 21:32:13 --> Router Class Initialized
INFO - 2022-05-10 21:32:13 --> Output Class Initialized
INFO - 2022-05-10 21:32:13 --> Security Class Initialized
DEBUG - 2022-05-10 21:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:32:13 --> Input Class Initialized
INFO - 2022-05-10 21:32:13 --> Language Class Initialized
INFO - 2022-05-10 21:32:13 --> Language Class Initialized
INFO - 2022-05-10 21:32:13 --> Config Class Initialized
INFO - 2022-05-10 21:32:13 --> Loader Class Initialized
INFO - 2022-05-10 21:32:13 --> Helper loaded: url_helper
INFO - 2022-05-10 21:32:13 --> Database Driver Class Initialized
INFO - 2022-05-10 21:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:32:13 --> Controller Class Initialized
DEBUG - 2022-05-10 21:32:13 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:32:13 --> Model Class Initialized
DEBUG - 2022-05-10 21:32:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:32:13 --> Model Class Initialized
ERROR - 2022-05-10 21:32:13 --> Severity: Notice --> Undefined index: insurances N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 130
ERROR - 2022-05-10 21:32:13 --> Query error: Unknown column 'insurances' in 'field list' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurances`) VALUES (32, '2020', 'Delhi', '5465', '2', NULL)
INFO - 2022-05-10 21:32:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:32:24 --> Config Class Initialized
INFO - 2022-05-10 21:32:24 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:32:24 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:32:24 --> Utf8 Class Initialized
INFO - 2022-05-10 21:32:24 --> URI Class Initialized
INFO - 2022-05-10 21:32:24 --> Router Class Initialized
INFO - 2022-05-10 21:32:24 --> Output Class Initialized
INFO - 2022-05-10 21:32:24 --> Security Class Initialized
DEBUG - 2022-05-10 21:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:32:24 --> Input Class Initialized
INFO - 2022-05-10 21:32:24 --> Language Class Initialized
INFO - 2022-05-10 21:32:24 --> Language Class Initialized
INFO - 2022-05-10 21:32:24 --> Config Class Initialized
INFO - 2022-05-10 21:32:24 --> Loader Class Initialized
INFO - 2022-05-10 21:32:24 --> Helper loaded: url_helper
INFO - 2022-05-10 21:32:24 --> Database Driver Class Initialized
INFO - 2022-05-10 21:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:32:24 --> Controller Class Initialized
DEBUG - 2022-05-10 21:32:24 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:32:24 --> Model Class Initialized
DEBUG - 2022-05-10 21:32:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:32:24 --> Model Class Initialized
ERROR - 2022-05-10 21:32:25 --> Severity: Notice --> Undefined index: insurances N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 130
ERROR - 2022-05-10 21:32:25 --> Query error: Column 'insurance' cannot be null - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`) VALUES (33, '2020', 'Delhi', '5465', '2', NULL)
INFO - 2022-05-10 21:32:25 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:32:32 --> Config Class Initialized
INFO - 2022-05-10 21:32:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:32:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:32:32 --> Utf8 Class Initialized
INFO - 2022-05-10 21:32:32 --> URI Class Initialized
INFO - 2022-05-10 21:32:32 --> Router Class Initialized
INFO - 2022-05-10 21:32:32 --> Output Class Initialized
INFO - 2022-05-10 21:32:32 --> Security Class Initialized
DEBUG - 2022-05-10 21:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:32:32 --> Input Class Initialized
INFO - 2022-05-10 21:32:32 --> Language Class Initialized
INFO - 2022-05-10 21:32:32 --> Language Class Initialized
INFO - 2022-05-10 21:32:32 --> Config Class Initialized
INFO - 2022-05-10 21:32:32 --> Loader Class Initialized
INFO - 2022-05-10 21:32:32 --> Helper loaded: url_helper
INFO - 2022-05-10 21:32:32 --> Database Driver Class Initialized
INFO - 2022-05-10 21:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:32:32 --> Controller Class Initialized
DEBUG - 2022-05-10 21:32:32 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:32:32 --> Model Class Initialized
DEBUG - 2022-05-10 21:32:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:32:32 --> Model Class Initialized
DEBUG - 2022-05-10 21:32:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:32:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:32:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:32:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:32:32 --> Final output sent to browser
DEBUG - 2022-05-10 21:32:32 --> Total execution time: 0.0630
INFO - 2022-05-10 21:35:09 --> Config Class Initialized
INFO - 2022-05-10 21:35:09 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:35:09 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:35:09 --> Utf8 Class Initialized
INFO - 2022-05-10 21:35:09 --> URI Class Initialized
INFO - 2022-05-10 21:35:09 --> Router Class Initialized
INFO - 2022-05-10 21:35:09 --> Output Class Initialized
INFO - 2022-05-10 21:35:09 --> Security Class Initialized
DEBUG - 2022-05-10 21:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:35:09 --> Input Class Initialized
INFO - 2022-05-10 21:35:09 --> Language Class Initialized
INFO - 2022-05-10 21:35:09 --> Language Class Initialized
INFO - 2022-05-10 21:35:09 --> Config Class Initialized
INFO - 2022-05-10 21:35:09 --> Loader Class Initialized
INFO - 2022-05-10 21:35:09 --> Helper loaded: url_helper
INFO - 2022-05-10 21:35:09 --> Database Driver Class Initialized
INFO - 2022-05-10 21:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:35:09 --> Controller Class Initialized
DEBUG - 2022-05-10 21:35:09 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:35:09 --> Model Class Initialized
DEBUG - 2022-05-10 21:35:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:35:09 --> Model Class Initialized
DEBUG - 2022-05-10 21:35:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:35:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:35:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:35:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:35:09 --> Final output sent to browser
DEBUG - 2022-05-10 21:35:09 --> Total execution time: 0.6639
INFO - 2022-05-10 21:35:44 --> Config Class Initialized
INFO - 2022-05-10 21:35:44 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:35:44 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:35:44 --> Utf8 Class Initialized
INFO - 2022-05-10 21:35:44 --> URI Class Initialized
INFO - 2022-05-10 21:35:44 --> Router Class Initialized
INFO - 2022-05-10 21:35:44 --> Output Class Initialized
INFO - 2022-05-10 21:35:44 --> Security Class Initialized
DEBUG - 2022-05-10 21:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:35:44 --> Input Class Initialized
INFO - 2022-05-10 21:35:44 --> Language Class Initialized
INFO - 2022-05-10 21:35:44 --> Language Class Initialized
INFO - 2022-05-10 21:35:44 --> Config Class Initialized
INFO - 2022-05-10 21:35:44 --> Loader Class Initialized
INFO - 2022-05-10 21:35:44 --> Helper loaded: url_helper
INFO - 2022-05-10 21:35:44 --> Database Driver Class Initialized
INFO - 2022-05-10 21:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:35:44 --> Controller Class Initialized
DEBUG - 2022-05-10 21:35:44 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:35:44 --> Model Class Initialized
DEBUG - 2022-05-10 21:35:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:35:44 --> Model Class Initialized
INFO - 2022-05-10 21:36:22 --> Config Class Initialized
INFO - 2022-05-10 21:36:22 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:36:22 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:36:22 --> Utf8 Class Initialized
INFO - 2022-05-10 21:36:22 --> URI Class Initialized
INFO - 2022-05-10 21:36:22 --> Router Class Initialized
INFO - 2022-05-10 21:36:22 --> Output Class Initialized
INFO - 2022-05-10 21:36:22 --> Security Class Initialized
DEBUG - 2022-05-10 21:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:36:22 --> Input Class Initialized
INFO - 2022-05-10 21:36:22 --> Language Class Initialized
INFO - 2022-05-10 21:36:22 --> Language Class Initialized
INFO - 2022-05-10 21:36:22 --> Config Class Initialized
INFO - 2022-05-10 21:36:22 --> Loader Class Initialized
INFO - 2022-05-10 21:36:22 --> Helper loaded: url_helper
INFO - 2022-05-10 21:36:22 --> Database Driver Class Initialized
INFO - 2022-05-10 21:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:36:22 --> Controller Class Initialized
DEBUG - 2022-05-10 21:36:22 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:36:22 --> Model Class Initialized
DEBUG - 2022-05-10 21:36:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:36:22 --> Model Class Initialized
ERROR - 2022-05-10 21:36:22 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`) VALUES (36, '2020', 'Delhi', '5465', '2', 'yes')
INFO - 2022-05-10 21:36:22 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:36:29 --> Config Class Initialized
INFO - 2022-05-10 21:36:29 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:36:29 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:36:29 --> Utf8 Class Initialized
INFO - 2022-05-10 21:36:29 --> URI Class Initialized
INFO - 2022-05-10 21:36:29 --> Router Class Initialized
INFO - 2022-05-10 21:36:29 --> Output Class Initialized
INFO - 2022-05-10 21:36:29 --> Security Class Initialized
DEBUG - 2022-05-10 21:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:36:29 --> Input Class Initialized
INFO - 2022-05-10 21:36:29 --> Language Class Initialized
INFO - 2022-05-10 21:36:29 --> Language Class Initialized
INFO - 2022-05-10 21:36:29 --> Config Class Initialized
INFO - 2022-05-10 21:36:29 --> Loader Class Initialized
INFO - 2022-05-10 21:36:29 --> Helper loaded: url_helper
INFO - 2022-05-10 21:36:29 --> Database Driver Class Initialized
INFO - 2022-05-10 21:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:36:29 --> Controller Class Initialized
DEBUG - 2022-05-10 21:36:29 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:36:29 --> Model Class Initialized
DEBUG - 2022-05-10 21:36:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:36:29 --> Model Class Initialized
DEBUG - 2022-05-10 21:36:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:36:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:36:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:36:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:36:29 --> Final output sent to browser
DEBUG - 2022-05-10 21:36:29 --> Total execution time: 0.0395
INFO - 2022-05-10 21:41:58 --> Config Class Initialized
INFO - 2022-05-10 21:41:58 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:41:58 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:41:58 --> Utf8 Class Initialized
INFO - 2022-05-10 21:41:58 --> URI Class Initialized
INFO - 2022-05-10 21:41:58 --> Router Class Initialized
INFO - 2022-05-10 21:41:58 --> Output Class Initialized
INFO - 2022-05-10 21:41:58 --> Security Class Initialized
DEBUG - 2022-05-10 21:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:41:58 --> Input Class Initialized
INFO - 2022-05-10 21:41:58 --> Language Class Initialized
INFO - 2022-05-10 21:41:58 --> Language Class Initialized
INFO - 2022-05-10 21:41:58 --> Config Class Initialized
INFO - 2022-05-10 21:41:58 --> Loader Class Initialized
INFO - 2022-05-10 21:41:58 --> Helper loaded: url_helper
INFO - 2022-05-10 21:41:58 --> Database Driver Class Initialized
INFO - 2022-05-10 21:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:41:58 --> Controller Class Initialized
DEBUG - 2022-05-10 21:41:58 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:41:58 --> Model Class Initialized
DEBUG - 2022-05-10 21:41:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:41:58 --> Model Class Initialized
INFO - 2022-05-10 21:41:58 --> Final output sent to browser
DEBUG - 2022-05-10 21:41:58 --> Total execution time: 0.0266
INFO - 2022-05-10 21:43:00 --> Config Class Initialized
INFO - 2022-05-10 21:43:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:43:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:43:00 --> Utf8 Class Initialized
INFO - 2022-05-10 21:43:00 --> URI Class Initialized
INFO - 2022-05-10 21:43:00 --> Router Class Initialized
INFO - 2022-05-10 21:43:00 --> Output Class Initialized
INFO - 2022-05-10 21:43:00 --> Security Class Initialized
DEBUG - 2022-05-10 21:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:43:00 --> Input Class Initialized
INFO - 2022-05-10 21:43:00 --> Language Class Initialized
INFO - 2022-05-10 21:43:00 --> Language Class Initialized
INFO - 2022-05-10 21:43:00 --> Config Class Initialized
INFO - 2022-05-10 21:43:00 --> Loader Class Initialized
INFO - 2022-05-10 21:43:00 --> Helper loaded: url_helper
INFO - 2022-05-10 21:43:00 --> Database Driver Class Initialized
INFO - 2022-05-10 21:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:43:00 --> Controller Class Initialized
DEBUG - 2022-05-10 21:43:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:43:00 --> Model Class Initialized
DEBUG - 2022-05-10 21:43:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:43:00 --> Model Class Initialized
ERROR - 2022-05-10 21:43:00 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`) VALUES (37, '2020', 'Dadar and Nagar Haveli', '51153', '2', 'No')
INFO - 2022-05-10 21:43:00 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:44:20 --> Config Class Initialized
INFO - 2022-05-10 21:44:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:44:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:44:20 --> Utf8 Class Initialized
INFO - 2022-05-10 21:44:20 --> URI Class Initialized
INFO - 2022-05-10 21:44:20 --> Router Class Initialized
INFO - 2022-05-10 21:44:20 --> Output Class Initialized
INFO - 2022-05-10 21:44:20 --> Security Class Initialized
DEBUG - 2022-05-10 21:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:44:20 --> Input Class Initialized
INFO - 2022-05-10 21:44:20 --> Language Class Initialized
INFO - 2022-05-10 21:44:20 --> Language Class Initialized
INFO - 2022-05-10 21:44:20 --> Config Class Initialized
INFO - 2022-05-10 21:44:20 --> Loader Class Initialized
INFO - 2022-05-10 21:44:20 --> Helper loaded: url_helper
INFO - 2022-05-10 21:44:20 --> Database Driver Class Initialized
INFO - 2022-05-10 21:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:44:20 --> Controller Class Initialized
DEBUG - 2022-05-10 21:44:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:44:20 --> Model Class Initialized
DEBUG - 2022-05-10 21:44:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:44:20 --> Model Class Initialized
DEBUG - 2022-05-10 21:44:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:44:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:44:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:44:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:44:20 --> Final output sent to browser
DEBUG - 2022-05-10 21:44:20 --> Total execution time: 0.1749
INFO - 2022-05-10 21:52:43 --> Config Class Initialized
INFO - 2022-05-10 21:52:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:52:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:52:43 --> Utf8 Class Initialized
INFO - 2022-05-10 21:52:43 --> URI Class Initialized
INFO - 2022-05-10 21:52:43 --> Router Class Initialized
INFO - 2022-05-10 21:52:43 --> Output Class Initialized
INFO - 2022-05-10 21:52:43 --> Security Class Initialized
DEBUG - 2022-05-10 21:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:52:43 --> Input Class Initialized
INFO - 2022-05-10 21:52:43 --> Language Class Initialized
INFO - 2022-05-10 21:52:43 --> Language Class Initialized
INFO - 2022-05-10 21:52:43 --> Config Class Initialized
INFO - 2022-05-10 21:52:43 --> Loader Class Initialized
INFO - 2022-05-10 21:52:43 --> Helper loaded: url_helper
INFO - 2022-05-10 21:52:43 --> Database Driver Class Initialized
INFO - 2022-05-10 21:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:52:43 --> Controller Class Initialized
DEBUG - 2022-05-10 21:52:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:52:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:52:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:52:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:52:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:52:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:52:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:52:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:52:43 --> Final output sent to browser
DEBUG - 2022-05-10 21:52:43 --> Total execution time: 0.0836
INFO - 2022-05-10 21:54:01 --> Config Class Initialized
INFO - 2022-05-10 21:54:01 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:54:01 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:54:01 --> Utf8 Class Initialized
INFO - 2022-05-10 21:54:01 --> URI Class Initialized
INFO - 2022-05-10 21:54:01 --> Router Class Initialized
INFO - 2022-05-10 21:54:01 --> Output Class Initialized
INFO - 2022-05-10 21:54:01 --> Security Class Initialized
DEBUG - 2022-05-10 21:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:54:01 --> Input Class Initialized
INFO - 2022-05-10 21:54:01 --> Language Class Initialized
INFO - 2022-05-10 21:54:01 --> Language Class Initialized
INFO - 2022-05-10 21:54:01 --> Config Class Initialized
INFO - 2022-05-10 21:54:01 --> Loader Class Initialized
INFO - 2022-05-10 21:54:01 --> Helper loaded: url_helper
INFO - 2022-05-10 21:54:01 --> Database Driver Class Initialized
INFO - 2022-05-10 21:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:54:01 --> Controller Class Initialized
DEBUG - 2022-05-10 21:54:01 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:54:01 --> Model Class Initialized
DEBUG - 2022-05-10 21:54:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:54:01 --> Model Class Initialized
DEBUG - 2022-05-10 21:54:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:54:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:54:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:54:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:54:01 --> Final output sent to browser
DEBUG - 2022-05-10 21:54:01 --> Total execution time: 0.0388
INFO - 2022-05-10 21:54:09 --> Config Class Initialized
INFO - 2022-05-10 21:54:09 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:54:09 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:54:09 --> Utf8 Class Initialized
INFO - 2022-05-10 21:54:09 --> URI Class Initialized
INFO - 2022-05-10 21:54:09 --> Router Class Initialized
INFO - 2022-05-10 21:54:09 --> Output Class Initialized
INFO - 2022-05-10 21:54:09 --> Security Class Initialized
DEBUG - 2022-05-10 21:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:54:09 --> Input Class Initialized
INFO - 2022-05-10 21:54:09 --> Language Class Initialized
INFO - 2022-05-10 21:54:09 --> Language Class Initialized
INFO - 2022-05-10 21:54:09 --> Config Class Initialized
INFO - 2022-05-10 21:54:09 --> Loader Class Initialized
INFO - 2022-05-10 21:54:09 --> Helper loaded: url_helper
INFO - 2022-05-10 21:54:09 --> Database Driver Class Initialized
INFO - 2022-05-10 21:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:54:09 --> Controller Class Initialized
DEBUG - 2022-05-10 21:54:09 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:54:09 --> Model Class Initialized
DEBUG - 2022-05-10 21:54:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:54:09 --> Model Class Initialized
INFO - 2022-05-10 21:54:09 --> Final output sent to browser
DEBUG - 2022-05-10 21:54:09 --> Total execution time: 0.0385
INFO - 2022-05-10 21:54:56 --> Config Class Initialized
INFO - 2022-05-10 21:54:56 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:54:56 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:54:56 --> Utf8 Class Initialized
INFO - 2022-05-10 21:54:56 --> URI Class Initialized
INFO - 2022-05-10 21:54:56 --> Router Class Initialized
INFO - 2022-05-10 21:54:56 --> Output Class Initialized
INFO - 2022-05-10 21:54:56 --> Security Class Initialized
DEBUG - 2022-05-10 21:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:54:56 --> Input Class Initialized
INFO - 2022-05-10 21:54:56 --> Language Class Initialized
INFO - 2022-05-10 21:54:56 --> Language Class Initialized
INFO - 2022-05-10 21:54:56 --> Config Class Initialized
INFO - 2022-05-10 21:54:56 --> Loader Class Initialized
INFO - 2022-05-10 21:54:56 --> Helper loaded: url_helper
INFO - 2022-05-10 21:54:56 --> Database Driver Class Initialized
INFO - 2022-05-10 21:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:54:56 --> Controller Class Initialized
DEBUG - 2022-05-10 21:54:56 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:54:56 --> Model Class Initialized
DEBUG - 2022-05-10 21:54:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:54:56 --> Model Class Initialized
DEBUG - 2022-05-10 21:54:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:54:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:54:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:54:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:54:56 --> Final output sent to browser
DEBUG - 2022-05-10 21:54:56 --> Total execution time: 0.5145
INFO - 2022-05-10 21:55:50 --> Config Class Initialized
INFO - 2022-05-10 21:55:50 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:55:50 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:55:50 --> Utf8 Class Initialized
INFO - 2022-05-10 21:55:50 --> URI Class Initialized
INFO - 2022-05-10 21:55:50 --> Router Class Initialized
INFO - 2022-05-10 21:55:50 --> Output Class Initialized
INFO - 2022-05-10 21:55:50 --> Security Class Initialized
DEBUG - 2022-05-10 21:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:55:50 --> Input Class Initialized
INFO - 2022-05-10 21:55:50 --> Language Class Initialized
INFO - 2022-05-10 21:55:50 --> Language Class Initialized
INFO - 2022-05-10 21:55:50 --> Config Class Initialized
INFO - 2022-05-10 21:55:50 --> Loader Class Initialized
INFO - 2022-05-10 21:55:50 --> Helper loaded: url_helper
INFO - 2022-05-10 21:55:50 --> Database Driver Class Initialized
INFO - 2022-05-10 21:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:55:50 --> Controller Class Initialized
DEBUG - 2022-05-10 21:55:50 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:55:50 --> Model Class Initialized
DEBUG - 2022-05-10 21:55:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:55:50 --> Model Class Initialized
INFO - 2022-05-10 21:55:50 --> Upload Class Initialized
ERROR - 2022-05-10 21:55:50 --> Severity: Notice --> Undefined index: kilometer N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 126
ERROR - 2022-05-10 21:55:50 --> Query error: Column 'kilometer_driven' cannot be null - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `kilometer_driven`, `reg_number`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`) VALUES (41, '2020', NULL, 'rn555', 'Assam', '3546', '2', 'yes')
INFO - 2022-05-10 21:55:50 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:56:36 --> Config Class Initialized
INFO - 2022-05-10 21:56:36 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:56:36 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:56:36 --> Utf8 Class Initialized
INFO - 2022-05-10 21:56:36 --> URI Class Initialized
INFO - 2022-05-10 21:56:36 --> Router Class Initialized
INFO - 2022-05-10 21:56:36 --> Output Class Initialized
INFO - 2022-05-10 21:56:36 --> Security Class Initialized
DEBUG - 2022-05-10 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:56:36 --> Input Class Initialized
INFO - 2022-05-10 21:56:36 --> Language Class Initialized
INFO - 2022-05-10 21:56:36 --> Language Class Initialized
INFO - 2022-05-10 21:56:36 --> Config Class Initialized
INFO - 2022-05-10 21:56:36 --> Loader Class Initialized
INFO - 2022-05-10 21:56:36 --> Helper loaded: url_helper
INFO - 2022-05-10 21:56:36 --> Database Driver Class Initialized
INFO - 2022-05-10 21:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:56:36 --> Controller Class Initialized
DEBUG - 2022-05-10 21:56:36 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:56:36 --> Model Class Initialized
DEBUG - 2022-05-10 21:56:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:56:36 --> Model Class Initialized
DEBUG - 2022-05-10 21:56:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:56:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:56:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:56:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:56:36 --> Final output sent to browser
DEBUG - 2022-05-10 21:56:36 --> Total execution time: 0.0406
INFO - 2022-05-10 21:56:43 --> Config Class Initialized
INFO - 2022-05-10 21:56:43 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:56:43 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:56:43 --> Utf8 Class Initialized
INFO - 2022-05-10 21:56:43 --> URI Class Initialized
INFO - 2022-05-10 21:56:43 --> Router Class Initialized
INFO - 2022-05-10 21:56:43 --> Output Class Initialized
INFO - 2022-05-10 21:56:43 --> Security Class Initialized
DEBUG - 2022-05-10 21:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:56:43 --> Input Class Initialized
INFO - 2022-05-10 21:56:43 --> Language Class Initialized
INFO - 2022-05-10 21:56:43 --> Language Class Initialized
INFO - 2022-05-10 21:56:43 --> Config Class Initialized
INFO - 2022-05-10 21:56:43 --> Loader Class Initialized
INFO - 2022-05-10 21:56:43 --> Helper loaded: url_helper
INFO - 2022-05-10 21:56:43 --> Database Driver Class Initialized
INFO - 2022-05-10 21:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:56:43 --> Controller Class Initialized
DEBUG - 2022-05-10 21:56:43 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:56:43 --> Model Class Initialized
DEBUG - 2022-05-10 21:56:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:56:43 --> Model Class Initialized
INFO - 2022-05-10 21:56:43 --> Final output sent to browser
DEBUG - 2022-05-10 21:56:43 --> Total execution time: 0.0345
INFO - 2022-05-10 21:57:32 --> Config Class Initialized
INFO - 2022-05-10 21:57:32 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:57:32 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:57:32 --> Utf8 Class Initialized
INFO - 2022-05-10 21:57:32 --> URI Class Initialized
INFO - 2022-05-10 21:57:32 --> Router Class Initialized
INFO - 2022-05-10 21:57:32 --> Output Class Initialized
INFO - 2022-05-10 21:57:32 --> Security Class Initialized
DEBUG - 2022-05-10 21:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:57:32 --> Input Class Initialized
INFO - 2022-05-10 21:57:32 --> Language Class Initialized
INFO - 2022-05-10 21:57:32 --> Language Class Initialized
INFO - 2022-05-10 21:57:32 --> Config Class Initialized
INFO - 2022-05-10 21:57:32 --> Loader Class Initialized
INFO - 2022-05-10 21:57:32 --> Helper loaded: url_helper
INFO - 2022-05-10 21:57:32 --> Database Driver Class Initialized
INFO - 2022-05-10 21:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:57:32 --> Controller Class Initialized
DEBUG - 2022-05-10 21:57:32 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:57:32 --> Model Class Initialized
DEBUG - 2022-05-10 21:57:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:57:32 --> Model Class Initialized
INFO - 2022-05-10 21:57:32 --> Upload Class Initialized
ERROR - 2022-05-10 21:57:32 --> Severity: Notice --> Undefined index: kilometer N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 126
ERROR - 2022-05-10 21:57:32 --> Query error: Column 'kilometer_driven' cannot be null - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `kilometer_driven`, `reg_number`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`) VALUES (42, '2020', NULL, '53151sd', 'Arunachal Pradesh', '5165156', '2', 'No')
INFO - 2022-05-10 21:57:32 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:58:54 --> Config Class Initialized
INFO - 2022-05-10 21:58:54 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:58:54 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:58:54 --> Utf8 Class Initialized
INFO - 2022-05-10 21:58:54 --> URI Class Initialized
INFO - 2022-05-10 21:58:54 --> Router Class Initialized
INFO - 2022-05-10 21:58:54 --> Output Class Initialized
INFO - 2022-05-10 21:58:54 --> Security Class Initialized
DEBUG - 2022-05-10 21:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:58:54 --> Input Class Initialized
INFO - 2022-05-10 21:58:54 --> Language Class Initialized
INFO - 2022-05-10 21:58:54 --> Language Class Initialized
INFO - 2022-05-10 21:58:54 --> Config Class Initialized
INFO - 2022-05-10 21:58:54 --> Loader Class Initialized
INFO - 2022-05-10 21:58:54 --> Helper loaded: url_helper
INFO - 2022-05-10 21:58:54 --> Database Driver Class Initialized
INFO - 2022-05-10 21:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:58:54 --> Controller Class Initialized
DEBUG - 2022-05-10 21:58:54 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:58:54 --> Model Class Initialized
DEBUG - 2022-05-10 21:58:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:58:54 --> Model Class Initialized
INFO - 2022-05-10 21:59:14 --> Config Class Initialized
INFO - 2022-05-10 21:59:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:59:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:59:14 --> Utf8 Class Initialized
INFO - 2022-05-10 21:59:14 --> URI Class Initialized
INFO - 2022-05-10 21:59:14 --> Router Class Initialized
INFO - 2022-05-10 21:59:14 --> Output Class Initialized
INFO - 2022-05-10 21:59:14 --> Security Class Initialized
DEBUG - 2022-05-10 21:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:59:14 --> Input Class Initialized
INFO - 2022-05-10 21:59:14 --> Language Class Initialized
INFO - 2022-05-10 21:59:14 --> Language Class Initialized
INFO - 2022-05-10 21:59:14 --> Config Class Initialized
INFO - 2022-05-10 21:59:14 --> Loader Class Initialized
INFO - 2022-05-10 21:59:14 --> Helper loaded: url_helper
INFO - 2022-05-10 21:59:14 --> Database Driver Class Initialized
INFO - 2022-05-10 21:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:59:14 --> Controller Class Initialized
DEBUG - 2022-05-10 21:59:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:59:14 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:59:14 --> Model Class Initialized
INFO - 2022-05-10 21:59:28 --> Config Class Initialized
INFO - 2022-05-10 21:59:28 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:59:28 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:59:28 --> Utf8 Class Initialized
INFO - 2022-05-10 21:59:28 --> URI Class Initialized
INFO - 2022-05-10 21:59:28 --> Router Class Initialized
INFO - 2022-05-10 21:59:28 --> Output Class Initialized
INFO - 2022-05-10 21:59:28 --> Security Class Initialized
DEBUG - 2022-05-10 21:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:59:28 --> Input Class Initialized
INFO - 2022-05-10 21:59:28 --> Language Class Initialized
INFO - 2022-05-10 21:59:28 --> Language Class Initialized
INFO - 2022-05-10 21:59:28 --> Config Class Initialized
INFO - 2022-05-10 21:59:28 --> Loader Class Initialized
INFO - 2022-05-10 21:59:28 --> Helper loaded: url_helper
INFO - 2022-05-10 21:59:28 --> Database Driver Class Initialized
INFO - 2022-05-10 21:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:59:28 --> Controller Class Initialized
DEBUG - 2022-05-10 21:59:28 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:59:28 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:59:28 --> Model Class Initialized
INFO - 2022-05-10 21:59:28 --> Upload Class Initialized
ERROR - 2022-05-10 21:59:28 --> Severity: Notice --> Undefined index: kilometer N:\Xampp\htdocs\motodeal\application\modules\admin\models\Admin_model.php 126
ERROR - 2022-05-10 21:59:28 --> Query error: Column 'kilometer_driven' cannot be null - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `kilometer_driven`, `reg_number`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`) VALUES (43, '2020', NULL, '53151sd', 'Arunachal Pradesh', '5165156', '2', 'No')
INFO - 2022-05-10 21:59:28 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 21:59:33 --> Config Class Initialized
INFO - 2022-05-10 21:59:33 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:59:33 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:59:33 --> Utf8 Class Initialized
INFO - 2022-05-10 21:59:33 --> URI Class Initialized
INFO - 2022-05-10 21:59:33 --> Router Class Initialized
INFO - 2022-05-10 21:59:33 --> Output Class Initialized
INFO - 2022-05-10 21:59:33 --> Security Class Initialized
DEBUG - 2022-05-10 21:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:59:33 --> Input Class Initialized
INFO - 2022-05-10 21:59:33 --> Language Class Initialized
INFO - 2022-05-10 21:59:33 --> Language Class Initialized
INFO - 2022-05-10 21:59:33 --> Config Class Initialized
INFO - 2022-05-10 21:59:33 --> Loader Class Initialized
INFO - 2022-05-10 21:59:33 --> Helper loaded: url_helper
INFO - 2022-05-10 21:59:33 --> Database Driver Class Initialized
INFO - 2022-05-10 21:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:59:33 --> Controller Class Initialized
DEBUG - 2022-05-10 21:59:33 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:59:33 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:59:33 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:59:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:59:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:59:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:59:33 --> Final output sent to browser
DEBUG - 2022-05-10 21:59:33 --> Total execution time: 0.0386
INFO - 2022-05-10 21:59:36 --> Config Class Initialized
INFO - 2022-05-10 21:59:36 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:59:36 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:59:36 --> Utf8 Class Initialized
INFO - 2022-05-10 21:59:36 --> URI Class Initialized
INFO - 2022-05-10 21:59:36 --> Router Class Initialized
INFO - 2022-05-10 21:59:36 --> Output Class Initialized
INFO - 2022-05-10 21:59:36 --> Security Class Initialized
DEBUG - 2022-05-10 21:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:59:36 --> Input Class Initialized
INFO - 2022-05-10 21:59:36 --> Language Class Initialized
INFO - 2022-05-10 21:59:36 --> Language Class Initialized
INFO - 2022-05-10 21:59:36 --> Config Class Initialized
INFO - 2022-05-10 21:59:36 --> Loader Class Initialized
INFO - 2022-05-10 21:59:36 --> Helper loaded: url_helper
INFO - 2022-05-10 21:59:36 --> Database Driver Class Initialized
INFO - 2022-05-10 21:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:59:36 --> Controller Class Initialized
DEBUG - 2022-05-10 21:59:36 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:59:36 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:59:36 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 21:59:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 21:59:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 21:59:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 21:59:36 --> Final output sent to browser
DEBUG - 2022-05-10 21:59:36 --> Total execution time: 0.0383
INFO - 2022-05-10 21:59:42 --> Config Class Initialized
INFO - 2022-05-10 21:59:42 --> Hooks Class Initialized
DEBUG - 2022-05-10 21:59:42 --> UTF-8 Support Enabled
INFO - 2022-05-10 21:59:42 --> Utf8 Class Initialized
INFO - 2022-05-10 21:59:42 --> URI Class Initialized
INFO - 2022-05-10 21:59:42 --> Router Class Initialized
INFO - 2022-05-10 21:59:42 --> Output Class Initialized
INFO - 2022-05-10 21:59:42 --> Security Class Initialized
DEBUG - 2022-05-10 21:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 21:59:42 --> Input Class Initialized
INFO - 2022-05-10 21:59:42 --> Language Class Initialized
INFO - 2022-05-10 21:59:42 --> Language Class Initialized
INFO - 2022-05-10 21:59:42 --> Config Class Initialized
INFO - 2022-05-10 21:59:42 --> Loader Class Initialized
INFO - 2022-05-10 21:59:42 --> Helper loaded: url_helper
INFO - 2022-05-10 21:59:42 --> Database Driver Class Initialized
INFO - 2022-05-10 21:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 21:59:42 --> Controller Class Initialized
DEBUG - 2022-05-10 21:59:42 --> Admin MX_Controller Initialized
INFO - 2022-05-10 21:59:42 --> Model Class Initialized
DEBUG - 2022-05-10 21:59:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 21:59:42 --> Model Class Initialized
INFO - 2022-05-10 21:59:42 --> Final output sent to browser
DEBUG - 2022-05-10 21:59:42 --> Total execution time: 0.0360
INFO - 2022-05-10 22:00:26 --> Config Class Initialized
INFO - 2022-05-10 22:00:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:00:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:00:26 --> Utf8 Class Initialized
INFO - 2022-05-10 22:00:26 --> URI Class Initialized
INFO - 2022-05-10 22:00:26 --> Router Class Initialized
INFO - 2022-05-10 22:00:26 --> Output Class Initialized
INFO - 2022-05-10 22:00:26 --> Security Class Initialized
DEBUG - 2022-05-10 22:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:00:26 --> Input Class Initialized
INFO - 2022-05-10 22:00:26 --> Language Class Initialized
INFO - 2022-05-10 22:00:26 --> Language Class Initialized
INFO - 2022-05-10 22:00:26 --> Config Class Initialized
INFO - 2022-05-10 22:00:26 --> Loader Class Initialized
INFO - 2022-05-10 22:00:26 --> Helper loaded: url_helper
INFO - 2022-05-10 22:00:26 --> Database Driver Class Initialized
INFO - 2022-05-10 22:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:00:26 --> Controller Class Initialized
DEBUG - 2022-05-10 22:00:26 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:00:26 --> Model Class Initialized
DEBUG - 2022-05-10 22:00:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:00:26 --> Model Class Initialized
INFO - 2022-05-10 22:00:26 --> Upload Class Initialized
INFO - 2022-05-10 22:00:26 --> Config Class Initialized
INFO - 2022-05-10 22:00:26 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:00:26 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:00:26 --> Utf8 Class Initialized
INFO - 2022-05-10 22:00:26 --> URI Class Initialized
INFO - 2022-05-10 22:00:26 --> Router Class Initialized
INFO - 2022-05-10 22:00:26 --> Output Class Initialized
INFO - 2022-05-10 22:00:26 --> Security Class Initialized
DEBUG - 2022-05-10 22:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:00:26 --> Input Class Initialized
INFO - 2022-05-10 22:00:26 --> Language Class Initialized
INFO - 2022-05-10 22:00:26 --> Language Class Initialized
INFO - 2022-05-10 22:00:26 --> Config Class Initialized
INFO - 2022-05-10 22:00:26 --> Loader Class Initialized
INFO - 2022-05-10 22:00:26 --> Helper loaded: url_helper
INFO - 2022-05-10 22:00:26 --> Database Driver Class Initialized
INFO - 2022-05-10 22:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:00:26 --> Controller Class Initialized
DEBUG - 2022-05-10 22:00:26 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:00:26 --> Model Class Initialized
DEBUG - 2022-05-10 22:00:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:00:26 --> Model Class Initialized
DEBUG - 2022-05-10 22:00:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:00:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:00:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:00:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:00:26 --> Final output sent to browser
DEBUG - 2022-05-10 22:00:26 --> Total execution time: 0.0415
INFO - 2022-05-10 22:01:52 --> Config Class Initialized
INFO - 2022-05-10 22:01:52 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:01:52 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:01:52 --> Utf8 Class Initialized
INFO - 2022-05-10 22:01:52 --> URI Class Initialized
INFO - 2022-05-10 22:01:52 --> Router Class Initialized
INFO - 2022-05-10 22:01:52 --> Output Class Initialized
INFO - 2022-05-10 22:01:52 --> Security Class Initialized
DEBUG - 2022-05-10 22:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:01:52 --> Input Class Initialized
INFO - 2022-05-10 22:01:52 --> Language Class Initialized
INFO - 2022-05-10 22:01:52 --> Language Class Initialized
INFO - 2022-05-10 22:01:52 --> Config Class Initialized
INFO - 2022-05-10 22:01:52 --> Loader Class Initialized
INFO - 2022-05-10 22:01:52 --> Helper loaded: url_helper
INFO - 2022-05-10 22:01:52 --> Database Driver Class Initialized
INFO - 2022-05-10 22:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:01:52 --> Controller Class Initialized
DEBUG - 2022-05-10 22:01:52 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:01:52 --> Model Class Initialized
DEBUG - 2022-05-10 22:01:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:01:52 --> Model Class Initialized
DEBUG - 2022-05-10 22:01:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:01:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:01:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:01:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:01:52 --> Final output sent to browser
DEBUG - 2022-05-10 22:01:52 --> Total execution time: 0.0391
INFO - 2022-05-10 22:02:00 --> Config Class Initialized
INFO - 2022-05-10 22:02:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:02:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:02:00 --> Utf8 Class Initialized
INFO - 2022-05-10 22:02:00 --> URI Class Initialized
INFO - 2022-05-10 22:02:00 --> Router Class Initialized
INFO - 2022-05-10 22:02:00 --> Output Class Initialized
INFO - 2022-05-10 22:02:00 --> Security Class Initialized
DEBUG - 2022-05-10 22:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:02:00 --> Input Class Initialized
INFO - 2022-05-10 22:02:00 --> Language Class Initialized
INFO - 2022-05-10 22:02:00 --> Language Class Initialized
INFO - 2022-05-10 22:02:00 --> Config Class Initialized
INFO - 2022-05-10 22:02:00 --> Loader Class Initialized
INFO - 2022-05-10 22:02:00 --> Helper loaded: url_helper
INFO - 2022-05-10 22:02:00 --> Database Driver Class Initialized
INFO - 2022-05-10 22:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:02:00 --> Controller Class Initialized
DEBUG - 2022-05-10 22:02:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:02:00 --> Model Class Initialized
DEBUG - 2022-05-10 22:02:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:02:00 --> Model Class Initialized
INFO - 2022-05-10 22:02:00 --> Upload Class Initialized
INFO - 2022-05-10 22:02:00 --> Config Class Initialized
INFO - 2022-05-10 22:02:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:02:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:02:00 --> Utf8 Class Initialized
INFO - 2022-05-10 22:02:00 --> URI Class Initialized
INFO - 2022-05-10 22:02:00 --> Router Class Initialized
INFO - 2022-05-10 22:02:00 --> Output Class Initialized
INFO - 2022-05-10 22:02:00 --> Security Class Initialized
DEBUG - 2022-05-10 22:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:02:00 --> Input Class Initialized
INFO - 2022-05-10 22:02:00 --> Language Class Initialized
INFO - 2022-05-10 22:02:00 --> Language Class Initialized
INFO - 2022-05-10 22:02:00 --> Config Class Initialized
INFO - 2022-05-10 22:02:00 --> Loader Class Initialized
INFO - 2022-05-10 22:02:00 --> Helper loaded: url_helper
INFO - 2022-05-10 22:02:00 --> Database Driver Class Initialized
INFO - 2022-05-10 22:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:02:00 --> Controller Class Initialized
DEBUG - 2022-05-10 22:02:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:02:00 --> Model Class Initialized
DEBUG - 2022-05-10 22:02:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:02:00 --> Model Class Initialized
DEBUG - 2022-05-10 22:02:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:02:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:02:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:02:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:02:00 --> Final output sent to browser
DEBUG - 2022-05-10 22:02:00 --> Total execution time: 0.0403
INFO - 2022-05-10 22:02:11 --> Config Class Initialized
INFO - 2022-05-10 22:02:11 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:02:11 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:02:11 --> Utf8 Class Initialized
INFO - 2022-05-10 22:02:11 --> URI Class Initialized
INFO - 2022-05-10 22:02:11 --> Router Class Initialized
INFO - 2022-05-10 22:02:11 --> Output Class Initialized
INFO - 2022-05-10 22:02:11 --> Security Class Initialized
DEBUG - 2022-05-10 22:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:02:11 --> Input Class Initialized
INFO - 2022-05-10 22:02:11 --> Language Class Initialized
INFO - 2022-05-10 22:02:11 --> Language Class Initialized
INFO - 2022-05-10 22:02:11 --> Config Class Initialized
INFO - 2022-05-10 22:02:11 --> Loader Class Initialized
INFO - 2022-05-10 22:02:11 --> Helper loaded: url_helper
INFO - 2022-05-10 22:02:11 --> Database Driver Class Initialized
INFO - 2022-05-10 22:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:02:11 --> Controller Class Initialized
DEBUG - 2022-05-10 22:02:11 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:02:11 --> Model Class Initialized
DEBUG - 2022-05-10 22:02:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:02:11 --> Model Class Initialized
DEBUG - 2022-05-10 22:02:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:02:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:02:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:02:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:02:11 --> Final output sent to browser
DEBUG - 2022-05-10 22:02:11 --> Total execution time: 0.0403
INFO - 2022-05-10 22:02:19 --> Config Class Initialized
INFO - 2022-05-10 22:02:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:02:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:02:19 --> Utf8 Class Initialized
INFO - 2022-05-10 22:02:19 --> URI Class Initialized
INFO - 2022-05-10 22:02:19 --> Router Class Initialized
INFO - 2022-05-10 22:02:19 --> Output Class Initialized
INFO - 2022-05-10 22:02:19 --> Security Class Initialized
DEBUG - 2022-05-10 22:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:02:19 --> Input Class Initialized
INFO - 2022-05-10 22:02:19 --> Language Class Initialized
INFO - 2022-05-10 22:02:19 --> Language Class Initialized
INFO - 2022-05-10 22:02:19 --> Config Class Initialized
INFO - 2022-05-10 22:02:19 --> Loader Class Initialized
INFO - 2022-05-10 22:02:19 --> Helper loaded: url_helper
INFO - 2022-05-10 22:02:19 --> Database Driver Class Initialized
INFO - 2022-05-10 22:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:02:19 --> Controller Class Initialized
DEBUG - 2022-05-10 22:02:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:02:19 --> Model Class Initialized
DEBUG - 2022-05-10 22:02:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:02:19 --> Model Class Initialized
INFO - 2022-05-10 22:06:00 --> Config Class Initialized
INFO - 2022-05-10 22:06:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:06:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:06:00 --> Utf8 Class Initialized
INFO - 2022-05-10 22:06:00 --> URI Class Initialized
INFO - 2022-05-10 22:06:00 --> Router Class Initialized
INFO - 2022-05-10 22:06:00 --> Output Class Initialized
INFO - 2022-05-10 22:06:00 --> Security Class Initialized
DEBUG - 2022-05-10 22:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:06:00 --> Input Class Initialized
INFO - 2022-05-10 22:06:00 --> Language Class Initialized
INFO - 2022-05-10 22:06:00 --> Language Class Initialized
INFO - 2022-05-10 22:06:00 --> Config Class Initialized
INFO - 2022-05-10 22:06:00 --> Loader Class Initialized
INFO - 2022-05-10 22:06:00 --> Helper loaded: url_helper
INFO - 2022-05-10 22:06:00 --> Database Driver Class Initialized
INFO - 2022-05-10 22:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:06:00 --> Controller Class Initialized
DEBUG - 2022-05-10 22:06:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:06:00 --> Model Class Initialized
DEBUG - 2022-05-10 22:06:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:06:00 --> Model Class Initialized
INFO - 2022-05-10 22:06:12 --> Config Class Initialized
INFO - 2022-05-10 22:06:12 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:06:12 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:06:12 --> Utf8 Class Initialized
INFO - 2022-05-10 22:06:12 --> URI Class Initialized
INFO - 2022-05-10 22:06:12 --> Router Class Initialized
INFO - 2022-05-10 22:06:12 --> Output Class Initialized
INFO - 2022-05-10 22:06:12 --> Security Class Initialized
DEBUG - 2022-05-10 22:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:06:12 --> Input Class Initialized
INFO - 2022-05-10 22:06:12 --> Language Class Initialized
INFO - 2022-05-10 22:06:12 --> Language Class Initialized
INFO - 2022-05-10 22:06:12 --> Config Class Initialized
INFO - 2022-05-10 22:06:12 --> Loader Class Initialized
INFO - 2022-05-10 22:06:12 --> Helper loaded: url_helper
INFO - 2022-05-10 22:06:12 --> Database Driver Class Initialized
INFO - 2022-05-10 22:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:06:12 --> Controller Class Initialized
DEBUG - 2022-05-10 22:06:12 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:06:12 --> Model Class Initialized
DEBUG - 2022-05-10 22:06:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:06:12 --> Model Class Initialized
INFO - 2022-05-10 22:06:12 --> Upload Class Initialized
INFO - 2022-05-10 22:08:35 --> Config Class Initialized
INFO - 2022-05-10 22:08:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:08:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:08:35 --> Utf8 Class Initialized
INFO - 2022-05-10 22:08:35 --> URI Class Initialized
INFO - 2022-05-10 22:08:35 --> Router Class Initialized
INFO - 2022-05-10 22:08:35 --> Output Class Initialized
INFO - 2022-05-10 22:08:35 --> Security Class Initialized
DEBUG - 2022-05-10 22:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:08:35 --> Input Class Initialized
INFO - 2022-05-10 22:08:35 --> Language Class Initialized
INFO - 2022-05-10 22:08:35 --> Language Class Initialized
INFO - 2022-05-10 22:08:35 --> Config Class Initialized
INFO - 2022-05-10 22:08:35 --> Loader Class Initialized
INFO - 2022-05-10 22:08:35 --> Helper loaded: url_helper
INFO - 2022-05-10 22:08:35 --> Database Driver Class Initialized
INFO - 2022-05-10 22:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:08:35 --> Controller Class Initialized
DEBUG - 2022-05-10 22:08:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:08:35 --> Model Class Initialized
DEBUG - 2022-05-10 22:08:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:08:35 --> Model Class Initialized
INFO - 2022-05-10 22:08:35 --> Upload Class Initialized
ERROR - 2022-05-10 22:08:35 --> Severity: Notice --> Array to string conversion N:\Xampp\htdocs\motodeal\system\database\DB_driver.php 1392
ERROR - 2022-05-10 22:08:35 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `vehicle_overview` (`v_id`, `year_of_purchase`, `kilometer_driven`, `reg_number`, `reg_state`, `rc_number`, `no_of_owners`, `insurance`, `document`) VALUES (49, '', '', '', 'Choose...', '', '', 'Choose...', Array)
INFO - 2022-05-10 22:08:35 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-10 22:09:12 --> Config Class Initialized
INFO - 2022-05-10 22:09:12 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:09:12 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:09:12 --> Utf8 Class Initialized
INFO - 2022-05-10 22:09:12 --> URI Class Initialized
INFO - 2022-05-10 22:09:12 --> Router Class Initialized
INFO - 2022-05-10 22:09:12 --> Output Class Initialized
INFO - 2022-05-10 22:09:12 --> Security Class Initialized
DEBUG - 2022-05-10 22:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:09:12 --> Input Class Initialized
INFO - 2022-05-10 22:09:12 --> Language Class Initialized
INFO - 2022-05-10 22:09:12 --> Language Class Initialized
INFO - 2022-05-10 22:09:12 --> Config Class Initialized
INFO - 2022-05-10 22:09:12 --> Loader Class Initialized
INFO - 2022-05-10 22:09:12 --> Helper loaded: url_helper
INFO - 2022-05-10 22:09:12 --> Database Driver Class Initialized
INFO - 2022-05-10 22:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:09:12 --> Controller Class Initialized
DEBUG - 2022-05-10 22:09:12 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:09:12 --> Model Class Initialized
DEBUG - 2022-05-10 22:09:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:09:12 --> Model Class Initialized
INFO - 2022-05-10 22:09:12 --> Upload Class Initialized
INFO - 2022-05-10 22:09:12 --> Config Class Initialized
INFO - 2022-05-10 22:09:12 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:09:12 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:09:12 --> Utf8 Class Initialized
INFO - 2022-05-10 22:09:12 --> URI Class Initialized
INFO - 2022-05-10 22:09:12 --> Router Class Initialized
INFO - 2022-05-10 22:09:12 --> Output Class Initialized
INFO - 2022-05-10 22:09:12 --> Security Class Initialized
DEBUG - 2022-05-10 22:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:09:12 --> Input Class Initialized
INFO - 2022-05-10 22:09:12 --> Language Class Initialized
INFO - 2022-05-10 22:09:12 --> Language Class Initialized
INFO - 2022-05-10 22:09:12 --> Config Class Initialized
INFO - 2022-05-10 22:09:12 --> Loader Class Initialized
INFO - 2022-05-10 22:09:12 --> Helper loaded: url_helper
INFO - 2022-05-10 22:09:12 --> Database Driver Class Initialized
INFO - 2022-05-10 22:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:09:12 --> Controller Class Initialized
DEBUG - 2022-05-10 22:09:12 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:09:12 --> Model Class Initialized
DEBUG - 2022-05-10 22:09:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:09:12 --> Model Class Initialized
DEBUG - 2022-05-10 22:09:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:09:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:09:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:09:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:09:12 --> Final output sent to browser
DEBUG - 2022-05-10 22:09:12 --> Total execution time: 0.0348
INFO - 2022-05-10 22:11:38 --> Config Class Initialized
INFO - 2022-05-10 22:11:38 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:11:38 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:11:38 --> Utf8 Class Initialized
INFO - 2022-05-10 22:11:38 --> URI Class Initialized
INFO - 2022-05-10 22:11:38 --> Router Class Initialized
INFO - 2022-05-10 22:11:38 --> Output Class Initialized
INFO - 2022-05-10 22:11:38 --> Security Class Initialized
DEBUG - 2022-05-10 22:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:11:38 --> Input Class Initialized
INFO - 2022-05-10 22:11:38 --> Language Class Initialized
INFO - 2022-05-10 22:11:38 --> Language Class Initialized
INFO - 2022-05-10 22:11:38 --> Config Class Initialized
INFO - 2022-05-10 22:11:38 --> Loader Class Initialized
INFO - 2022-05-10 22:11:38 --> Helper loaded: url_helper
INFO - 2022-05-10 22:11:38 --> Database Driver Class Initialized
INFO - 2022-05-10 22:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:11:38 --> Controller Class Initialized
DEBUG - 2022-05-10 22:11:38 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:11:38 --> Model Class Initialized
DEBUG - 2022-05-10 22:11:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:11:38 --> Model Class Initialized
DEBUG - 2022-05-10 22:11:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:11:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:11:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:11:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:11:38 --> Final output sent to browser
DEBUG - 2022-05-10 22:11:38 --> Total execution time: 0.0397
INFO - 2022-05-10 22:12:00 --> Config Class Initialized
INFO - 2022-05-10 22:12:00 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:12:00 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:12:00 --> Utf8 Class Initialized
INFO - 2022-05-10 22:12:00 --> URI Class Initialized
INFO - 2022-05-10 22:12:00 --> Router Class Initialized
INFO - 2022-05-10 22:12:00 --> Output Class Initialized
INFO - 2022-05-10 22:12:00 --> Security Class Initialized
DEBUG - 2022-05-10 22:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:12:00 --> Input Class Initialized
INFO - 2022-05-10 22:12:00 --> Language Class Initialized
INFO - 2022-05-10 22:12:00 --> Language Class Initialized
INFO - 2022-05-10 22:12:00 --> Config Class Initialized
INFO - 2022-05-10 22:12:00 --> Loader Class Initialized
INFO - 2022-05-10 22:12:00 --> Helper loaded: url_helper
INFO - 2022-05-10 22:12:00 --> Database Driver Class Initialized
INFO - 2022-05-10 22:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:12:00 --> Controller Class Initialized
DEBUG - 2022-05-10 22:12:00 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:12:00 --> Model Class Initialized
DEBUG - 2022-05-10 22:12:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:12:00 --> Model Class Initialized
DEBUG - 2022-05-10 22:12:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:12:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:12:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:12:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:12:00 --> Final output sent to browser
DEBUG - 2022-05-10 22:12:00 --> Total execution time: 0.0418
INFO - 2022-05-10 22:12:06 --> Config Class Initialized
INFO - 2022-05-10 22:12:06 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:12:06 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:12:06 --> Utf8 Class Initialized
INFO - 2022-05-10 22:12:06 --> URI Class Initialized
INFO - 2022-05-10 22:12:06 --> Router Class Initialized
INFO - 2022-05-10 22:12:06 --> Output Class Initialized
INFO - 2022-05-10 22:12:06 --> Security Class Initialized
DEBUG - 2022-05-10 22:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:12:06 --> Input Class Initialized
INFO - 2022-05-10 22:12:06 --> Language Class Initialized
INFO - 2022-05-10 22:12:06 --> Language Class Initialized
INFO - 2022-05-10 22:12:06 --> Config Class Initialized
INFO - 2022-05-10 22:12:06 --> Loader Class Initialized
INFO - 2022-05-10 22:12:06 --> Helper loaded: url_helper
INFO - 2022-05-10 22:12:06 --> Database Driver Class Initialized
INFO - 2022-05-10 22:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:12:06 --> Controller Class Initialized
DEBUG - 2022-05-10 22:12:06 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:12:06 --> Model Class Initialized
DEBUG - 2022-05-10 22:12:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:12:06 --> Model Class Initialized
INFO - 2022-05-10 22:12:19 --> Config Class Initialized
INFO - 2022-05-10 22:12:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:12:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:12:19 --> Utf8 Class Initialized
INFO - 2022-05-10 22:12:19 --> URI Class Initialized
INFO - 2022-05-10 22:12:19 --> Router Class Initialized
INFO - 2022-05-10 22:12:19 --> Output Class Initialized
INFO - 2022-05-10 22:12:19 --> Security Class Initialized
DEBUG - 2022-05-10 22:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:12:19 --> Input Class Initialized
INFO - 2022-05-10 22:12:19 --> Language Class Initialized
INFO - 2022-05-10 22:12:19 --> Language Class Initialized
INFO - 2022-05-10 22:12:19 --> Config Class Initialized
INFO - 2022-05-10 22:12:19 --> Loader Class Initialized
INFO - 2022-05-10 22:12:19 --> Helper loaded: url_helper
INFO - 2022-05-10 22:12:19 --> Database Driver Class Initialized
INFO - 2022-05-10 22:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:12:19 --> Controller Class Initialized
DEBUG - 2022-05-10 22:12:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:12:19 --> Model Class Initialized
DEBUG - 2022-05-10 22:12:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:12:19 --> Model Class Initialized
INFO - 2022-05-10 22:12:19 --> Upload Class Initialized
INFO - 2022-05-10 22:12:19 --> Config Class Initialized
INFO - 2022-05-10 22:12:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:12:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:12:19 --> Utf8 Class Initialized
INFO - 2022-05-10 22:12:19 --> URI Class Initialized
INFO - 2022-05-10 22:12:19 --> Router Class Initialized
INFO - 2022-05-10 22:12:19 --> Output Class Initialized
INFO - 2022-05-10 22:12:19 --> Security Class Initialized
DEBUG - 2022-05-10 22:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:12:19 --> Input Class Initialized
INFO - 2022-05-10 22:12:19 --> Language Class Initialized
INFO - 2022-05-10 22:12:19 --> Language Class Initialized
INFO - 2022-05-10 22:12:19 --> Config Class Initialized
INFO - 2022-05-10 22:12:19 --> Loader Class Initialized
INFO - 2022-05-10 22:12:19 --> Helper loaded: url_helper
INFO - 2022-05-10 22:12:19 --> Database Driver Class Initialized
INFO - 2022-05-10 22:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:12:19 --> Controller Class Initialized
DEBUG - 2022-05-10 22:12:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:12:19 --> Model Class Initialized
DEBUG - 2022-05-10 22:12:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:12:19 --> Model Class Initialized
DEBUG - 2022-05-10 22:12:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:12:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:12:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:12:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:12:19 --> Final output sent to browser
DEBUG - 2022-05-10 22:12:19 --> Total execution time: 0.0417
INFO - 2022-05-10 22:21:28 --> Config Class Initialized
INFO - 2022-05-10 22:21:28 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:21:28 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:21:28 --> Utf8 Class Initialized
INFO - 2022-05-10 22:21:28 --> URI Class Initialized
INFO - 2022-05-10 22:21:29 --> Router Class Initialized
INFO - 2022-05-10 22:21:29 --> Output Class Initialized
INFO - 2022-05-10 22:21:29 --> Security Class Initialized
DEBUG - 2022-05-10 22:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:21:29 --> Input Class Initialized
INFO - 2022-05-10 22:21:29 --> Language Class Initialized
INFO - 2022-05-10 22:21:29 --> Language Class Initialized
INFO - 2022-05-10 22:21:29 --> Config Class Initialized
INFO - 2022-05-10 22:21:29 --> Loader Class Initialized
INFO - 2022-05-10 22:21:29 --> Helper loaded: url_helper
INFO - 2022-05-10 22:21:29 --> Database Driver Class Initialized
INFO - 2022-05-10 22:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:21:29 --> Controller Class Initialized
DEBUG - 2022-05-10 22:21:29 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:21:29 --> Model Class Initialized
DEBUG - 2022-05-10 22:21:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:21:29 --> Model Class Initialized
DEBUG - 2022-05-10 22:21:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:21:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:21:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:21:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:21:29 --> Final output sent to browser
DEBUG - 2022-05-10 22:21:29 --> Total execution time: 0.0755
INFO - 2022-05-10 22:21:37 --> Config Class Initialized
INFO - 2022-05-10 22:21:37 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:21:37 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:21:37 --> Utf8 Class Initialized
INFO - 2022-05-10 22:21:37 --> URI Class Initialized
INFO - 2022-05-10 22:21:37 --> Router Class Initialized
INFO - 2022-05-10 22:21:37 --> Output Class Initialized
INFO - 2022-05-10 22:21:37 --> Security Class Initialized
DEBUG - 2022-05-10 22:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:21:37 --> Input Class Initialized
INFO - 2022-05-10 22:21:37 --> Language Class Initialized
INFO - 2022-05-10 22:21:37 --> Language Class Initialized
INFO - 2022-05-10 22:21:37 --> Config Class Initialized
INFO - 2022-05-10 22:21:37 --> Loader Class Initialized
INFO - 2022-05-10 22:21:37 --> Helper loaded: url_helper
INFO - 2022-05-10 22:21:37 --> Database Driver Class Initialized
INFO - 2022-05-10 22:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:21:37 --> Controller Class Initialized
DEBUG - 2022-05-10 22:21:37 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:21:37 --> Model Class Initialized
DEBUG - 2022-05-10 22:21:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:21:37 --> Model Class Initialized
INFO - 2022-05-10 22:21:41 --> Upload Class Initialized
INFO - 2022-05-10 22:21:41 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-05-10 22:21:41 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-05-10 22:21:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:21:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:21:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:21:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:21:41 --> Final output sent to browser
DEBUG - 2022-05-10 22:21:41 --> Total execution time: 3.2547
INFO - 2022-05-10 22:22:20 --> Config Class Initialized
INFO - 2022-05-10 22:22:20 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:22:20 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:22:20 --> Utf8 Class Initialized
INFO - 2022-05-10 22:22:20 --> URI Class Initialized
INFO - 2022-05-10 22:22:20 --> Router Class Initialized
INFO - 2022-05-10 22:22:20 --> Output Class Initialized
INFO - 2022-05-10 22:22:20 --> Security Class Initialized
DEBUG - 2022-05-10 22:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:22:20 --> Input Class Initialized
INFO - 2022-05-10 22:22:20 --> Language Class Initialized
INFO - 2022-05-10 22:22:20 --> Language Class Initialized
INFO - 2022-05-10 22:22:20 --> Config Class Initialized
INFO - 2022-05-10 22:22:20 --> Loader Class Initialized
INFO - 2022-05-10 22:22:20 --> Helper loaded: url_helper
INFO - 2022-05-10 22:22:20 --> Database Driver Class Initialized
INFO - 2022-05-10 22:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:22:20 --> Controller Class Initialized
DEBUG - 2022-05-10 22:22:20 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:22:20 --> Model Class Initialized
DEBUG - 2022-05-10 22:22:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:22:20 --> Model Class Initialized
INFO - 2022-05-10 22:22:21 --> Upload Class Initialized
INFO - 2022-05-10 22:22:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-05-10 22:22:21 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-05-10 22:22:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:22:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:22:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:22:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:22:21 --> Final output sent to browser
DEBUG - 2022-05-10 22:22:21 --> Total execution time: 0.2858
INFO - 2022-05-10 22:24:19 --> Config Class Initialized
INFO - 2022-05-10 22:24:19 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:24:19 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:24:19 --> Utf8 Class Initialized
INFO - 2022-05-10 22:24:19 --> URI Class Initialized
INFO - 2022-05-10 22:24:19 --> Router Class Initialized
INFO - 2022-05-10 22:24:19 --> Output Class Initialized
INFO - 2022-05-10 22:24:19 --> Security Class Initialized
DEBUG - 2022-05-10 22:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:24:19 --> Input Class Initialized
INFO - 2022-05-10 22:24:19 --> Language Class Initialized
INFO - 2022-05-10 22:24:19 --> Language Class Initialized
INFO - 2022-05-10 22:24:19 --> Config Class Initialized
INFO - 2022-05-10 22:24:19 --> Loader Class Initialized
INFO - 2022-05-10 22:24:19 --> Helper loaded: url_helper
INFO - 2022-05-10 22:24:19 --> Database Driver Class Initialized
INFO - 2022-05-10 22:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:24:19 --> Controller Class Initialized
DEBUG - 2022-05-10 22:24:19 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:24:19 --> Model Class Initialized
DEBUG - 2022-05-10 22:24:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:24:19 --> Model Class Initialized
DEBUG - 2022-05-10 22:24:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:24:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:24:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:24:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:24:20 --> Final output sent to browser
DEBUG - 2022-05-10 22:24:20 --> Total execution time: 0.1327
INFO - 2022-05-10 22:24:35 --> Config Class Initialized
INFO - 2022-05-10 22:24:35 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:24:35 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:24:35 --> Utf8 Class Initialized
INFO - 2022-05-10 22:24:35 --> URI Class Initialized
INFO - 2022-05-10 22:24:35 --> Router Class Initialized
INFO - 2022-05-10 22:24:35 --> Output Class Initialized
INFO - 2022-05-10 22:24:35 --> Security Class Initialized
DEBUG - 2022-05-10 22:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:24:35 --> Input Class Initialized
INFO - 2022-05-10 22:24:35 --> Language Class Initialized
INFO - 2022-05-10 22:24:35 --> Language Class Initialized
INFO - 2022-05-10 22:24:35 --> Config Class Initialized
INFO - 2022-05-10 22:24:35 --> Loader Class Initialized
INFO - 2022-05-10 22:24:35 --> Helper loaded: url_helper
INFO - 2022-05-10 22:24:35 --> Database Driver Class Initialized
INFO - 2022-05-10 22:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:24:35 --> Controller Class Initialized
DEBUG - 2022-05-10 22:24:35 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:24:35 --> Model Class Initialized
DEBUG - 2022-05-10 22:24:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:24:35 --> Model Class Initialized
DEBUG - 2022-05-10 22:24:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:24:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:24:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:24:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:24:35 --> Final output sent to browser
DEBUG - 2022-05-10 22:24:35 --> Total execution time: 0.1681
INFO - 2022-05-10 22:25:05 --> Config Class Initialized
INFO - 2022-05-10 22:25:05 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:25:05 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:25:05 --> Utf8 Class Initialized
INFO - 2022-05-10 22:25:05 --> URI Class Initialized
INFO - 2022-05-10 22:25:05 --> Router Class Initialized
INFO - 2022-05-10 22:25:05 --> Output Class Initialized
INFO - 2022-05-10 22:25:05 --> Security Class Initialized
DEBUG - 2022-05-10 22:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:25:05 --> Input Class Initialized
INFO - 2022-05-10 22:25:05 --> Language Class Initialized
INFO - 2022-05-10 22:25:05 --> Language Class Initialized
INFO - 2022-05-10 22:25:05 --> Config Class Initialized
INFO - 2022-05-10 22:25:05 --> Loader Class Initialized
INFO - 2022-05-10 22:25:05 --> Helper loaded: url_helper
INFO - 2022-05-10 22:25:05 --> Database Driver Class Initialized
INFO - 2022-05-10 22:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:25:05 --> Controller Class Initialized
DEBUG - 2022-05-10 22:25:05 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:25:05 --> Model Class Initialized
DEBUG - 2022-05-10 22:25:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:25:05 --> Model Class Initialized
DEBUG - 2022-05-10 22:25:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:25:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:25:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:25:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:25:05 --> Final output sent to browser
DEBUG - 2022-05-10 22:25:05 --> Total execution time: 0.0395
INFO - 2022-05-10 22:25:14 --> Config Class Initialized
INFO - 2022-05-10 22:25:14 --> Hooks Class Initialized
DEBUG - 2022-05-10 22:25:14 --> UTF-8 Support Enabled
INFO - 2022-05-10 22:25:14 --> Utf8 Class Initialized
INFO - 2022-05-10 22:25:14 --> URI Class Initialized
INFO - 2022-05-10 22:25:14 --> Router Class Initialized
INFO - 2022-05-10 22:25:14 --> Output Class Initialized
INFO - 2022-05-10 22:25:14 --> Security Class Initialized
DEBUG - 2022-05-10 22:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-10 22:25:14 --> Input Class Initialized
INFO - 2022-05-10 22:25:14 --> Language Class Initialized
INFO - 2022-05-10 22:25:14 --> Language Class Initialized
INFO - 2022-05-10 22:25:14 --> Config Class Initialized
INFO - 2022-05-10 22:25:14 --> Loader Class Initialized
INFO - 2022-05-10 22:25:14 --> Helper loaded: url_helper
INFO - 2022-05-10 22:25:14 --> Database Driver Class Initialized
INFO - 2022-05-10 22:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-10 22:25:14 --> Controller Class Initialized
DEBUG - 2022-05-10 22:25:14 --> Admin MX_Controller Initialized
INFO - 2022-05-10 22:25:14 --> Model Class Initialized
DEBUG - 2022-05-10 22:25:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-10 22:25:14 --> Model Class Initialized
INFO - 2022-05-10 22:25:14 --> Upload Class Initialized
INFO - 2022-05-10 22:25:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-05-10 22:25:14 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-05-10 22:25:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-10 22:25:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-10 22:25:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehicle.php
DEBUG - 2022-05-10 22:25:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-10 22:25:14 --> Final output sent to browser
DEBUG - 2022-05-10 22:25:14 --> Total execution time: 0.1725
