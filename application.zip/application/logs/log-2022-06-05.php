<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-05 13:47:04 --> Config Class Initialized
INFO - 2022-06-05 13:47:04 --> Hooks Class Initialized
DEBUG - 2022-06-05 13:47:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 13:47:04 --> Utf8 Class Initialized
INFO - 2022-06-05 13:47:04 --> URI Class Initialized
DEBUG - 2022-06-05 13:47:04 --> No URI present. Default controller set.
INFO - 2022-06-05 13:47:04 --> Router Class Initialized
INFO - 2022-06-05 13:47:04 --> Output Class Initialized
INFO - 2022-06-05 13:47:04 --> Security Class Initialized
DEBUG - 2022-06-05 13:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 13:47:04 --> Input Class Initialized
INFO - 2022-06-05 13:47:04 --> Language Class Initialized
INFO - 2022-06-05 13:47:04 --> Language Class Initialized
INFO - 2022-06-05 13:47:04 --> Config Class Initialized
INFO - 2022-06-05 13:47:04 --> Loader Class Initialized
INFO - 2022-06-05 13:47:04 --> Helper loaded: url_helper
INFO - 2022-06-05 13:47:04 --> Database Driver Class Initialized
INFO - 2022-06-05 13:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 13:47:04 --> Controller Class Initialized
DEBUG - 2022-06-05 13:47:04 --> Welcome MX_Controller Initialized
DEBUG - 2022-06-05 13:47:04 --> File loaded: N:\Xampp\htdocs\hmvc\application\modules/welcome/views/welcome_message.php
INFO - 2022-06-05 13:47:04 --> Final output sent to browser
DEBUG - 2022-06-05 13:47:04 --> Total execution time: 0.1637
INFO - 2022-06-05 13:47:25 --> Config Class Initialized
INFO - 2022-06-05 13:47:25 --> Hooks Class Initialized
DEBUG - 2022-06-05 13:47:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 13:47:26 --> Utf8 Class Initialized
INFO - 2022-06-05 13:47:26 --> URI Class Initialized
DEBUG - 2022-06-05 13:47:26 --> No URI present. Default controller set.
INFO - 2022-06-05 13:47:26 --> Router Class Initialized
INFO - 2022-06-05 13:47:26 --> Output Class Initialized
INFO - 2022-06-05 13:47:26 --> Security Class Initialized
DEBUG - 2022-06-05 13:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 13:47:26 --> Input Class Initialized
INFO - 2022-06-05 13:47:26 --> Language Class Initialized
INFO - 2022-06-05 13:47:26 --> Language Class Initialized
INFO - 2022-06-05 13:47:26 --> Config Class Initialized
INFO - 2022-06-05 13:47:26 --> Loader Class Initialized
INFO - 2022-06-05 13:47:26 --> Helper loaded: url_helper
INFO - 2022-06-05 13:47:26 --> Database Driver Class Initialized
INFO - 2022-06-05 13:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 13:47:26 --> Controller Class Initialized
DEBUG - 2022-06-05 13:47:26 --> Welcome MX_Controller Initialized
DEBUG - 2022-06-05 13:47:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/welcome/views/welcome_message.php
INFO - 2022-06-05 13:47:26 --> Final output sent to browser
DEBUG - 2022-06-05 13:47:26 --> Total execution time: 0.0358
INFO - 2022-06-05 15:47:10 --> Config Class Initialized
INFO - 2022-06-05 15:47:10 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:10 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:10 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:10 --> URI Class Initialized
DEBUG - 2022-06-05 15:47:10 --> No URI present. Default controller set.
INFO - 2022-06-05 15:47:10 --> Router Class Initialized
INFO - 2022-06-05 15:47:10 --> Output Class Initialized
INFO - 2022-06-05 15:47:10 --> Security Class Initialized
DEBUG - 2022-06-05 15:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:10 --> Input Class Initialized
INFO - 2022-06-05 15:47:10 --> Language Class Initialized
INFO - 2022-06-05 15:47:10 --> Language Class Initialized
INFO - 2022-06-05 15:47:10 --> Config Class Initialized
INFO - 2022-06-05 15:47:10 --> Loader Class Initialized
INFO - 2022-06-05 15:47:10 --> Helper loaded: url_helper
INFO - 2022-06-05 15:47:10 --> Database Driver Class Initialized
INFO - 2022-06-05 15:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:47:10 --> Controller Class Initialized
DEBUG - 2022-06-05 15:47:10 --> Admin MX_Controller Initialized
INFO - 2022-06-05 15:47:38 --> Config Class Initialized
INFO - 2022-06-05 15:47:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:38 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:38 --> URI Class Initialized
DEBUG - 2022-06-05 15:47:38 --> No URI present. Default controller set.
INFO - 2022-06-05 15:47:38 --> Router Class Initialized
INFO - 2022-06-05 15:47:38 --> Output Class Initialized
INFO - 2022-06-05 15:47:38 --> Security Class Initialized
DEBUG - 2022-06-05 15:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:38 --> Input Class Initialized
INFO - 2022-06-05 15:47:38 --> Language Class Initialized
INFO - 2022-06-05 15:47:38 --> Language Class Initialized
INFO - 2022-06-05 15:47:38 --> Config Class Initialized
INFO - 2022-06-05 15:47:38 --> Loader Class Initialized
INFO - 2022-06-05 15:47:38 --> Helper loaded: url_helper
INFO - 2022-06-05 15:47:38 --> Database Driver Class Initialized
INFO - 2022-06-05 15:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:47:38 --> Controller Class Initialized
DEBUG - 2022-06-05 15:47:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:47:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:47:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:47:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:47:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:47:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:47:38 --> Final output sent to browser
DEBUG - 2022-06-05 15:47:38 --> Total execution time: 0.0389
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:39 --> Config Class Initialized
INFO - 2022-06-05 15:47:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:47:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:39 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> URI Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Router Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Output Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
INFO - 2022-06-05 15:47:39 --> Security Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
DEBUG - 2022-06-05 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Input Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
INFO - 2022-06-05 15:47:39 --> Language Class Initialized
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:39 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:47:40 --> Config Class Initialized
INFO - 2022-06-05 15:47:40 --> Config Class Initialized
INFO - 2022-06-05 15:47:40 --> Config Class Initialized
INFO - 2022-06-05 15:47:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:47:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:47:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:47:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:47:40 --> URI Class Initialized
INFO - 2022-06-05 15:47:40 --> URI Class Initialized
INFO - 2022-06-05 15:47:40 --> URI Class Initialized
INFO - 2022-06-05 15:47:40 --> Router Class Initialized
INFO - 2022-06-05 15:47:40 --> Router Class Initialized
INFO - 2022-06-05 15:47:40 --> Router Class Initialized
INFO - 2022-06-05 15:47:40 --> Output Class Initialized
INFO - 2022-06-05 15:47:40 --> Output Class Initialized
INFO - 2022-06-05 15:47:40 --> Output Class Initialized
INFO - 2022-06-05 15:47:40 --> Security Class Initialized
INFO - 2022-06-05 15:47:40 --> Security Class Initialized
INFO - 2022-06-05 15:47:40 --> Security Class Initialized
DEBUG - 2022-06-05 15:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:40 --> Input Class Initialized
DEBUG - 2022-06-05 15:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:47:40 --> Input Class Initialized
INFO - 2022-06-05 15:47:40 --> Input Class Initialized
INFO - 2022-06-05 15:47:40 --> Language Class Initialized
INFO - 2022-06-05 15:47:40 --> Language Class Initialized
INFO - 2022-06-05 15:47:40 --> Language Class Initialized
ERROR - 2022-06-05 15:47:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:47:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
DEBUG - 2022-06-05 15:48:23 --> No URI present. Default controller set.
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Loader Class Initialized
INFO - 2022-06-05 15:48:23 --> Helper loaded: url_helper
INFO - 2022-06-05 15:48:23 --> Database Driver Class Initialized
INFO - 2022-06-05 15:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:48:23 --> Controller Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:48:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:48:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:48:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:48:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:48:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:48:23 --> Final output sent to browser
DEBUG - 2022-06-05 15:48:23 --> Total execution time: 0.0411
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> Config Class Initialized
INFO - 2022-06-05 15:48:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
DEBUG - 2022-06-05 15:48:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> URI Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
INFO - 2022-06-05 15:48:23 --> Router Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Output Class Initialized
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Security Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:23 --> Input Class Initialized
INFO - 2022-06-05 15:48:23 --> Language Class Initialized
ERROR - 2022-06-05 15:48:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:24 --> Config Class Initialized
INFO - 2022-06-05 15:48:24 --> Config Class Initialized
INFO - 2022-06-05 15:48:24 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:24 --> Config Class Initialized
INFO - 2022-06-05 15:48:24 --> Hooks Class Initialized
INFO - 2022-06-05 15:48:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:48:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:48:24 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:24 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:24 --> Utf8 Class Initialized
INFO - 2022-06-05 15:48:24 --> URI Class Initialized
INFO - 2022-06-05 15:48:24 --> URI Class Initialized
INFO - 2022-06-05 15:48:24 --> URI Class Initialized
INFO - 2022-06-05 15:48:24 --> Router Class Initialized
INFO - 2022-06-05 15:48:24 --> Router Class Initialized
INFO - 2022-06-05 15:48:24 --> Router Class Initialized
INFO - 2022-06-05 15:48:24 --> Output Class Initialized
INFO - 2022-06-05 15:48:24 --> Output Class Initialized
INFO - 2022-06-05 15:48:24 --> Output Class Initialized
INFO - 2022-06-05 15:48:24 --> Security Class Initialized
INFO - 2022-06-05 15:48:24 --> Security Class Initialized
INFO - 2022-06-05 15:48:24 --> Security Class Initialized
DEBUG - 2022-06-05 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:24 --> Input Class Initialized
INFO - 2022-06-05 15:48:24 --> Language Class Initialized
DEBUG - 2022-06-05 15:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:48:24 --> Input Class Initialized
INFO - 2022-06-05 15:48:24 --> Input Class Initialized
ERROR - 2022-06-05 15:48:24 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:48:24 --> Language Class Initialized
INFO - 2022-06-05 15:48:24 --> Language Class Initialized
ERROR - 2022-06-05 15:48:24 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:48:24 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:50:55 --> Config Class Initialized
INFO - 2022-06-05 15:50:55 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:50:55 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:55 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:55 --> URI Class Initialized
DEBUG - 2022-06-05 15:50:55 --> No URI present. Default controller set.
INFO - 2022-06-05 15:50:55 --> Router Class Initialized
INFO - 2022-06-05 15:50:55 --> Output Class Initialized
INFO - 2022-06-05 15:50:55 --> Security Class Initialized
DEBUG - 2022-06-05 15:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:55 --> Input Class Initialized
INFO - 2022-06-05 15:50:55 --> Language Class Initialized
INFO - 2022-06-05 15:50:55 --> Language Class Initialized
INFO - 2022-06-05 15:50:55 --> Config Class Initialized
INFO - 2022-06-05 15:50:55 --> Loader Class Initialized
INFO - 2022-06-05 15:50:55 --> Helper loaded: url_helper
INFO - 2022-06-05 15:50:55 --> Database Driver Class Initialized
INFO - 2022-06-05 15:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:50:55 --> Controller Class Initialized
DEBUG - 2022-06-05 15:50:55 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:50:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:50:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:50:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:50:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:50:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:50:55 --> Final output sent to browser
DEBUG - 2022-06-05 15:50:55 --> Total execution time: 0.0426
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> Config Class Initialized
INFO - 2022-06-05 15:50:56 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
DEBUG - 2022-06-05 15:50:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:56 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> URI Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
INFO - 2022-06-05 15:50:56 --> Router Class Initialized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Output Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
INFO - 2022-06-05 15:50:56 --> Security Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
DEBUG - 2022-06-05 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:56 --> Input Class Initialized
INFO - 2022-06-05 15:50:56 --> Language Class Initialized
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:50:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:50:57 --> Config Class Initialized
INFO - 2022-06-05 15:50:57 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:57 --> Config Class Initialized
INFO - 2022-06-05 15:50:57 --> Hooks Class Initialized
INFO - 2022-06-05 15:50:57 --> Config Class Initialized
INFO - 2022-06-05 15:50:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:50:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:57 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:50:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:57 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:50:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:50:57 --> URI Class Initialized
INFO - 2022-06-05 15:50:57 --> Utf8 Class Initialized
INFO - 2022-06-05 15:50:57 --> URI Class Initialized
INFO - 2022-06-05 15:50:57 --> URI Class Initialized
INFO - 2022-06-05 15:50:57 --> Router Class Initialized
INFO - 2022-06-05 15:50:57 --> Router Class Initialized
INFO - 2022-06-05 15:50:57 --> Router Class Initialized
INFO - 2022-06-05 15:50:57 --> Output Class Initialized
INFO - 2022-06-05 15:50:57 --> Output Class Initialized
INFO - 2022-06-05 15:50:57 --> Output Class Initialized
INFO - 2022-06-05 15:50:57 --> Security Class Initialized
INFO - 2022-06-05 15:50:57 --> Security Class Initialized
INFO - 2022-06-05 15:50:57 --> Security Class Initialized
DEBUG - 2022-06-05 15:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:57 --> Input Class Initialized
INFO - 2022-06-05 15:50:57 --> Input Class Initialized
INFO - 2022-06-05 15:50:57 --> Language Class Initialized
INFO - 2022-06-05 15:50:57 --> Language Class Initialized
DEBUG - 2022-06-05 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:50:57 --> Input Class Initialized
INFO - 2022-06-05 15:50:57 --> Language Class Initialized
ERROR - 2022-06-05 15:50:57 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:50:57 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:50:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
DEBUG - 2022-06-05 15:51:40 --> No URI present. Default controller set.
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Loader Class Initialized
INFO - 2022-06-05 15:51:40 --> Helper loaded: url_helper
INFO - 2022-06-05 15:51:40 --> Database Driver Class Initialized
INFO - 2022-06-05 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:51:40 --> Controller Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:51:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:51:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:51:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:51:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:51:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:51:40 --> Final output sent to browser
DEBUG - 2022-06-05 15:51:40 --> Total execution time: 0.0279
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:40 --> Config Class Initialized
INFO - 2022-06-05 15:51:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:40 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> URI Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Router Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Output Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
INFO - 2022-06-05 15:51:40 --> Security Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
DEBUG - 2022-06-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:40 --> Input Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
INFO - 2022-06-05 15:51:40 --> Language Class Initialized
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:51:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:51:42 --> Config Class Initialized
INFO - 2022-06-05 15:51:42 --> Config Class Initialized
INFO - 2022-06-05 15:51:42 --> Config Class Initialized
INFO - 2022-06-05 15:51:42 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:42 --> Hooks Class Initialized
INFO - 2022-06-05 15:51:42 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:51:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:42 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:51:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:51:42 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:42 --> Utf8 Class Initialized
INFO - 2022-06-05 15:51:42 --> URI Class Initialized
INFO - 2022-06-05 15:51:42 --> URI Class Initialized
INFO - 2022-06-05 15:51:42 --> URI Class Initialized
INFO - 2022-06-05 15:51:42 --> Router Class Initialized
INFO - 2022-06-05 15:51:42 --> Router Class Initialized
INFO - 2022-06-05 15:51:42 --> Router Class Initialized
INFO - 2022-06-05 15:51:42 --> Output Class Initialized
INFO - 2022-06-05 15:51:42 --> Output Class Initialized
INFO - 2022-06-05 15:51:42 --> Output Class Initialized
INFO - 2022-06-05 15:51:42 --> Security Class Initialized
INFO - 2022-06-05 15:51:42 --> Security Class Initialized
INFO - 2022-06-05 15:51:42 --> Security Class Initialized
DEBUG - 2022-06-05 15:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:51:42 --> Input Class Initialized
INFO - 2022-06-05 15:51:42 --> Input Class Initialized
INFO - 2022-06-05 15:51:42 --> Input Class Initialized
INFO - 2022-06-05 15:51:42 --> Language Class Initialized
INFO - 2022-06-05 15:51:42 --> Language Class Initialized
INFO - 2022-06-05 15:51:42 --> Language Class Initialized
ERROR - 2022-06-05 15:51:42 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:51:42 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:51:42 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:52:13 --> Config Class Initialized
INFO - 2022-06-05 15:52:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:52:13 --> Config Class Initialized
INFO - 2022-06-05 15:52:13 --> Config Class Initialized
INFO - 2022-06-05 15:52:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:52:13 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:52:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:52:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:52:13 --> URI Class Initialized
DEBUG - 2022-06-05 15:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:52:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:52:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:52:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:52:13 --> URI Class Initialized
INFO - 2022-06-05 15:52:13 --> URI Class Initialized
INFO - 2022-06-05 15:52:13 --> Router Class Initialized
INFO - 2022-06-05 15:52:13 --> Router Class Initialized
INFO - 2022-06-05 15:52:13 --> Output Class Initialized
INFO - 2022-06-05 15:52:13 --> Router Class Initialized
INFO - 2022-06-05 15:52:13 --> Security Class Initialized
INFO - 2022-06-05 15:52:13 --> Output Class Initialized
INFO - 2022-06-05 15:52:13 --> Output Class Initialized
DEBUG - 2022-06-05 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:52:13 --> Security Class Initialized
INFO - 2022-06-05 15:52:13 --> Input Class Initialized
INFO - 2022-06-05 15:52:13 --> Security Class Initialized
INFO - 2022-06-05 15:52:13 --> Language Class Initialized
DEBUG - 2022-06-05 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:52:13 --> Input Class Initialized
DEBUG - 2022-06-05 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:52:13 --> Language Class Initialized
ERROR - 2022-06-05 15:52:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:52:13 --> Input Class Initialized
INFO - 2022-06-05 15:52:13 --> Language Class Initialized
ERROR - 2022-06-05 15:52:13 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:52:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:52:29 --> Config Class Initialized
INFO - 2022-06-05 15:52:29 --> Hooks Class Initialized
INFO - 2022-06-05 15:52:29 --> Config Class Initialized
INFO - 2022-06-05 15:52:29 --> Config Class Initialized
INFO - 2022-06-05 15:52:29 --> Hooks Class Initialized
INFO - 2022-06-05 15:52:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:52:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:52:29 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:52:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:52:29 --> URI Class Initialized
INFO - 2022-06-05 15:52:29 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:52:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:52:29 --> Utf8 Class Initialized
INFO - 2022-06-05 15:52:29 --> URI Class Initialized
INFO - 2022-06-05 15:52:29 --> URI Class Initialized
INFO - 2022-06-05 15:52:29 --> Router Class Initialized
INFO - 2022-06-05 15:52:29 --> Router Class Initialized
INFO - 2022-06-05 15:52:29 --> Output Class Initialized
INFO - 2022-06-05 15:52:29 --> Router Class Initialized
INFO - 2022-06-05 15:52:29 --> Security Class Initialized
INFO - 2022-06-05 15:52:29 --> Output Class Initialized
INFO - 2022-06-05 15:52:29 --> Output Class Initialized
DEBUG - 2022-06-05 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:52:29 --> Security Class Initialized
INFO - 2022-06-05 15:52:29 --> Input Class Initialized
INFO - 2022-06-05 15:52:29 --> Security Class Initialized
DEBUG - 2022-06-05 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:52:29 --> Language Class Initialized
INFO - 2022-06-05 15:52:29 --> Input Class Initialized
INFO - 2022-06-05 15:52:29 --> Language Class Initialized
ERROR - 2022-06-05 15:52:29 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:52:29 --> Input Class Initialized
ERROR - 2022-06-05 15:52:29 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:52:29 --> Language Class Initialized
ERROR - 2022-06-05 15:52:29 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:08 --> No URI present. Default controller set.
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Loader Class Initialized
INFO - 2022-06-05 15:53:08 --> Helper loaded: url_helper
INFO - 2022-06-05 15:53:08 --> Database Driver Class Initialized
INFO - 2022-06-05 15:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:53:08 --> Controller Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:53:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:53:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:53:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:53:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:53:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:53:08 --> Final output sent to browser
DEBUG - 2022-06-05 15:53:08 --> Total execution time: 0.0350
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Config Class Initialized
INFO - 2022-06-05 15:53:08 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:08 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
INFO - 2022-06-05 15:53:08 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
INFO - 2022-06-05 15:53:08 --> Router Class Initialized
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Output Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
INFO - 2022-06-05 15:53:08 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:08 --> Input Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
INFO - 2022-06-05 15:53:08 --> Language Class Initialized
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:08 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:09 --> Config Class Initialized
INFO - 2022-06-05 15:53:09 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:09 --> Config Class Initialized
INFO - 2022-06-05 15:53:09 --> Config Class Initialized
INFO - 2022-06-05 15:53:09 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:09 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:09 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:09 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:09 --> URI Class Initialized
INFO - 2022-06-05 15:53:09 --> URI Class Initialized
INFO - 2022-06-05 15:53:09 --> URI Class Initialized
INFO - 2022-06-05 15:53:09 --> Router Class Initialized
INFO - 2022-06-05 15:53:09 --> Router Class Initialized
INFO - 2022-06-05 15:53:09 --> Output Class Initialized
INFO - 2022-06-05 15:53:09 --> Router Class Initialized
INFO - 2022-06-05 15:53:09 --> Output Class Initialized
INFO - 2022-06-05 15:53:09 --> Security Class Initialized
INFO - 2022-06-05 15:53:09 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:09 --> Output Class Initialized
INFO - 2022-06-05 15:53:09 --> Input Class Initialized
INFO - 2022-06-05 15:53:09 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:09 --> Input Class Initialized
INFO - 2022-06-05 15:53:09 --> Security Class Initialized
INFO - 2022-06-05 15:53:09 --> Language Class Initialized
ERROR - 2022-06-05 15:53:09 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:09 --> Input Class Initialized
ERROR - 2022-06-05 15:53:09 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:09 --> Language Class Initialized
ERROR - 2022-06-05 15:53:09 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:21 --> Config Class Initialized
INFO - 2022-06-05 15:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:21 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:21 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:21 --> No URI present. Default controller set.
INFO - 2022-06-05 15:53:21 --> Router Class Initialized
INFO - 2022-06-05 15:53:21 --> Output Class Initialized
INFO - 2022-06-05 15:53:21 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:21 --> Input Class Initialized
INFO - 2022-06-05 15:53:21 --> Language Class Initialized
INFO - 2022-06-05 15:53:21 --> Language Class Initialized
INFO - 2022-06-05 15:53:21 --> Config Class Initialized
INFO - 2022-06-05 15:53:21 --> Loader Class Initialized
INFO - 2022-06-05 15:53:21 --> Helper loaded: url_helper
INFO - 2022-06-05 15:53:21 --> Database Driver Class Initialized
INFO - 2022-06-05 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:53:22 --> Controller Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:53:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:53:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:53:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:53:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:53:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:53:22 --> Final output sent to browser
DEBUG - 2022-06-05 15:53:22 --> Total execution time: 0.0369
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:22 --> Config Class Initialized
INFO - 2022-06-05 15:53:22 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:22 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
INFO - 2022-06-05 15:53:22 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
INFO - 2022-06-05 15:53:22 --> Router Class Initialized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
INFO - 2022-06-05 15:53:22 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Security Class Initialized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:22 --> Input Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:22 --> Language Class Initialized
ERROR - 2022-06-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:23 --> Config Class Initialized
INFO - 2022-06-05 15:53:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:23 --> Config Class Initialized
INFO - 2022-06-05 15:53:23 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:23 --> Config Class Initialized
INFO - 2022-06-05 15:53:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:23 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:23 --> URI Class Initialized
INFO - 2022-06-05 15:53:23 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:23 --> URI Class Initialized
INFO - 2022-06-05 15:53:23 --> Router Class Initialized
INFO - 2022-06-05 15:53:23 --> Router Class Initialized
INFO - 2022-06-05 15:53:23 --> Output Class Initialized
INFO - 2022-06-05 15:53:23 --> Output Class Initialized
INFO - 2022-06-05 15:53:23 --> Security Class Initialized
INFO - 2022-06-05 15:53:23 --> Router Class Initialized
INFO - 2022-06-05 15:53:23 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:23 --> Input Class Initialized
INFO - 2022-06-05 15:53:23 --> Language Class Initialized
INFO - 2022-06-05 15:53:23 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:23 --> Input Class Initialized
ERROR - 2022-06-05 15:53:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:23 --> Language Class Initialized
INFO - 2022-06-05 15:53:23 --> Security Class Initialized
ERROR - 2022-06-05 15:53:23 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:23 --> Input Class Initialized
INFO - 2022-06-05 15:53:23 --> Language Class Initialized
ERROR - 2022-06-05 15:53:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:30 --> No URI present. Default controller set.
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Loader Class Initialized
INFO - 2022-06-05 15:53:30 --> Helper loaded: url_helper
INFO - 2022-06-05 15:53:30 --> Database Driver Class Initialized
INFO - 2022-06-05 15:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:53:30 --> Controller Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:53:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:53:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:53:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:53:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:53:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:53:30 --> Final output sent to browser
DEBUG - 2022-06-05 15:53:30 --> Total execution time: 0.0391
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> Config Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
DEBUG - 2022-06-05 15:53:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:30 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:30 --> URI Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
INFO - 2022-06-05 15:53:30 --> Router Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
INFO - 2022-06-05 15:53:30 --> Security Class Initialized
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:30 --> Input Class Initialized
INFO - 2022-06-05 15:53:30 --> Language Class Initialized
ERROR - 2022-06-05 15:53:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:31 --> Config Class Initialized
INFO - 2022-06-05 15:53:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:31 --> Config Class Initialized
INFO - 2022-06-05 15:53:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:31 --> Config Class Initialized
INFO - 2022-06-05 15:53:31 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:31 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:31 --> URI Class Initialized
INFO - 2022-06-05 15:53:31 --> URI Class Initialized
INFO - 2022-06-05 15:53:31 --> URI Class Initialized
INFO - 2022-06-05 15:53:31 --> Router Class Initialized
INFO - 2022-06-05 15:53:31 --> Router Class Initialized
INFO - 2022-06-05 15:53:31 --> Router Class Initialized
INFO - 2022-06-05 15:53:31 --> Output Class Initialized
INFO - 2022-06-05 15:53:31 --> Output Class Initialized
INFO - 2022-06-05 15:53:31 --> Security Class Initialized
INFO - 2022-06-05 15:53:31 --> Output Class Initialized
INFO - 2022-06-05 15:53:31 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:31 --> Input Class Initialized
INFO - 2022-06-05 15:53:31 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:31 --> Language Class Initialized
INFO - 2022-06-05 15:53:31 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:31 --> Input Class Initialized
INFO - 2022-06-05 15:53:31 --> Language Class Initialized
ERROR - 2022-06-05 15:53:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:31 --> Language Class Initialized
ERROR - 2022-06-05 15:53:31 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:36 --> No URI present. Default controller set.
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Loader Class Initialized
INFO - 2022-06-05 15:53:36 --> Helper loaded: url_helper
INFO - 2022-06-05 15:53:36 --> Database Driver Class Initialized
INFO - 2022-06-05 15:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:53:36 --> Controller Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:53:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:53:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:53:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:53:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:53:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:53:36 --> Final output sent to browser
DEBUG - 2022-06-05 15:53:36 --> Total execution time: 0.0373
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> Config Class Initialized
INFO - 2022-06-05 15:53:36 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:36 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> URI Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Router Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Output Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
INFO - 2022-06-05 15:53:36 --> Security Class Initialized
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:36 --> Input Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
INFO - 2022-06-05 15:53:36 --> Language Class Initialized
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:36 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:37 --> Config Class Initialized
INFO - 2022-06-05 15:53:37 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:37 --> Config Class Initialized
INFO - 2022-06-05 15:53:37 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:37 --> Config Class Initialized
INFO - 2022-06-05 15:53:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:37 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:37 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:37 --> URI Class Initialized
INFO - 2022-06-05 15:53:37 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:37 --> URI Class Initialized
INFO - 2022-06-05 15:53:37 --> URI Class Initialized
INFO - 2022-06-05 15:53:37 --> Router Class Initialized
INFO - 2022-06-05 15:53:37 --> Router Class Initialized
INFO - 2022-06-05 15:53:37 --> Router Class Initialized
INFO - 2022-06-05 15:53:37 --> Output Class Initialized
INFO - 2022-06-05 15:53:37 --> Output Class Initialized
INFO - 2022-06-05 15:53:37 --> Output Class Initialized
INFO - 2022-06-05 15:53:37 --> Security Class Initialized
INFO - 2022-06-05 15:53:37 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:37 --> Security Class Initialized
INFO - 2022-06-05 15:53:37 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:37 --> Input Class Initialized
INFO - 2022-06-05 15:53:37 --> Language Class Initialized
INFO - 2022-06-05 15:53:37 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:37 --> Input Class Initialized
ERROR - 2022-06-05 15:53:37 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:37 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:37 --> Language Class Initialized
ERROR - 2022-06-05 15:53:37 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:52 --> No URI present. Default controller set.
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Loader Class Initialized
INFO - 2022-06-05 15:53:52 --> Helper loaded: url_helper
INFO - 2022-06-05 15:53:52 --> Database Driver Class Initialized
INFO - 2022-06-05 15:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:53:52 --> Controller Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:53:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:53:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:53:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:53:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:53:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:53:52 --> Final output sent to browser
DEBUG - 2022-06-05 15:53:52 --> Total execution time: 0.0363
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
INFO - 2022-06-05 15:53:52 --> Config Class Initialized
INFO - 2022-06-05 15:53:52 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:52 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> URI Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:52 --> Router Class Initialized
INFO - 2022-06-05 15:53:52 --> Output Class Initialized
INFO - 2022-06-05 15:53:52 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:52 --> Input Class Initialized
INFO - 2022-06-05 15:53:52 --> Language Class Initialized
ERROR - 2022-06-05 15:53:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:53:53 --> Config Class Initialized
INFO - 2022-06-05 15:53:53 --> Config Class Initialized
INFO - 2022-06-05 15:53:53 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:53 --> Hooks Class Initialized
INFO - 2022-06-05 15:53:53 --> Config Class Initialized
INFO - 2022-06-05 15:53:53 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:53:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:53 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:53 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:53:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:53:53 --> Utf8 Class Initialized
INFO - 2022-06-05 15:53:53 --> URI Class Initialized
INFO - 2022-06-05 15:53:53 --> URI Class Initialized
INFO - 2022-06-05 15:53:53 --> URI Class Initialized
INFO - 2022-06-05 15:53:53 --> Router Class Initialized
INFO - 2022-06-05 15:53:53 --> Router Class Initialized
INFO - 2022-06-05 15:53:53 --> Router Class Initialized
INFO - 2022-06-05 15:53:53 --> Output Class Initialized
INFO - 2022-06-05 15:53:53 --> Output Class Initialized
INFO - 2022-06-05 15:53:53 --> Output Class Initialized
INFO - 2022-06-05 15:53:53 --> Security Class Initialized
INFO - 2022-06-05 15:53:53 --> Security Class Initialized
INFO - 2022-06-05 15:53:53 --> Security Class Initialized
DEBUG - 2022-06-05 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:53 --> Input Class Initialized
DEBUG - 2022-06-05 15:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:53:53 --> Language Class Initialized
INFO - 2022-06-05 15:53:53 --> Input Class Initialized
INFO - 2022-06-05 15:53:53 --> Input Class Initialized
INFO - 2022-06-05 15:53:53 --> Language Class Initialized
INFO - 2022-06-05 15:53:53 --> Language Class Initialized
ERROR - 2022-06-05 15:53:53 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:53 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:53:53 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:13 --> No URI present. Default controller set.
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Loader Class Initialized
INFO - 2022-06-05 15:54:13 --> Helper loaded: url_helper
INFO - 2022-06-05 15:54:13 --> Database Driver Class Initialized
INFO - 2022-06-05 15:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:54:13 --> Controller Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:54:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:54:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:54:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:54:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:54:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:54:13 --> Final output sent to browser
DEBUG - 2022-06-05 15:54:13 --> Total execution time: 0.0323
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Config Class Initialized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
INFO - 2022-06-05 15:54:13 --> URI Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Router Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Output Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
INFO - 2022-06-05 15:54:13 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:13 --> Input Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
INFO - 2022-06-05 15:54:13 --> Language Class Initialized
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:14 --> Config Class Initialized
INFO - 2022-06-05 15:54:14 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:14 --> Config Class Initialized
INFO - 2022-06-05 15:54:14 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:14 --> Config Class Initialized
INFO - 2022-06-05 15:54:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:14 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:14 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:14 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:14 --> URI Class Initialized
INFO - 2022-06-05 15:54:14 --> URI Class Initialized
INFO - 2022-06-05 15:54:14 --> URI Class Initialized
INFO - 2022-06-05 15:54:14 --> Router Class Initialized
INFO - 2022-06-05 15:54:14 --> Router Class Initialized
INFO - 2022-06-05 15:54:14 --> Router Class Initialized
INFO - 2022-06-05 15:54:14 --> Output Class Initialized
INFO - 2022-06-05 15:54:14 --> Output Class Initialized
INFO - 2022-06-05 15:54:14 --> Output Class Initialized
INFO - 2022-06-05 15:54:14 --> Security Class Initialized
INFO - 2022-06-05 15:54:14 --> Security Class Initialized
INFO - 2022-06-05 15:54:14 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:14 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:14 --> Input Class Initialized
INFO - 2022-06-05 15:54:14 --> Language Class Initialized
DEBUG - 2022-06-05 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:14 --> Input Class Initialized
INFO - 2022-06-05 15:54:14 --> Language Class Initialized
ERROR - 2022-06-05 15:54:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:14 --> Language Class Initialized
ERROR - 2022-06-05 15:54:14 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:27 --> No URI present. Default controller set.
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Loader Class Initialized
INFO - 2022-06-05 15:54:27 --> Helper loaded: url_helper
INFO - 2022-06-05 15:54:27 --> Database Driver Class Initialized
INFO - 2022-06-05 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:54:27 --> Controller Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:54:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:54:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:54:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:54:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:54:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:54:27 --> Final output sent to browser
DEBUG - 2022-06-05 15:54:27 --> Total execution time: 0.0272
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
INFO - 2022-06-05 15:54:27 --> Config Class Initialized
INFO - 2022-06-05 15:54:27 --> Hooks Class Initialized
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
DEBUG - 2022-06-05 15:54:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
INFO - 2022-06-05 15:54:27 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
INFO - 2022-06-05 15:54:27 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:27 --> Router Class Initialized
INFO - 2022-06-05 15:54:27 --> Output Class Initialized
INFO - 2022-06-05 15:54:27 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:27 --> Input Class Initialized
INFO - 2022-06-05 15:54:27 --> Language Class Initialized
ERROR - 2022-06-05 15:54:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:29 --> Config Class Initialized
INFO - 2022-06-05 15:54:29 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:29 --> Config Class Initialized
INFO - 2022-06-05 15:54:29 --> Config Class Initialized
INFO - 2022-06-05 15:54:29 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:29 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:29 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:29 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:29 --> URI Class Initialized
INFO - 2022-06-05 15:54:29 --> URI Class Initialized
INFO - 2022-06-05 15:54:29 --> URI Class Initialized
INFO - 2022-06-05 15:54:29 --> Router Class Initialized
INFO - 2022-06-05 15:54:29 --> Router Class Initialized
INFO - 2022-06-05 15:54:29 --> Router Class Initialized
INFO - 2022-06-05 15:54:29 --> Output Class Initialized
INFO - 2022-06-05 15:54:29 --> Output Class Initialized
INFO - 2022-06-05 15:54:29 --> Output Class Initialized
INFO - 2022-06-05 15:54:29 --> Security Class Initialized
INFO - 2022-06-05 15:54:29 --> Security Class Initialized
INFO - 2022-06-05 15:54:29 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:29 --> Input Class Initialized
INFO - 2022-06-05 15:54:29 --> Input Class Initialized
INFO - 2022-06-05 15:54:29 --> Input Class Initialized
INFO - 2022-06-05 15:54:29 --> Language Class Initialized
INFO - 2022-06-05 15:54:29 --> Language Class Initialized
INFO - 2022-06-05 15:54:29 --> Language Class Initialized
ERROR - 2022-06-05 15:54:29 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:29 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:29 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:48 --> No URI present. Default controller set.
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Loader Class Initialized
INFO - 2022-06-05 15:54:48 --> Helper loaded: url_helper
INFO - 2022-06-05 15:54:48 --> Database Driver Class Initialized
INFO - 2022-06-05 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:54:48 --> Controller Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:54:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:54:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:54:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:54:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:54:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:54:48 --> Final output sent to browser
DEBUG - 2022-06-05 15:54:48 --> Total execution time: 0.0355
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
INFO - 2022-06-05 15:54:48 --> Config Class Initialized
INFO - 2022-06-05 15:54:48 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
DEBUG - 2022-06-05 15:54:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:48 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
INFO - 2022-06-05 15:54:48 --> URI Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:48 --> Router Class Initialized
INFO - 2022-06-05 15:54:48 --> Output Class Initialized
INFO - 2022-06-05 15:54:48 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:48 --> Input Class Initialized
INFO - 2022-06-05 15:54:48 --> Language Class Initialized
ERROR - 2022-06-05 15:54:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:50 --> Config Class Initialized
INFO - 2022-06-05 15:54:50 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:50 --> Config Class Initialized
INFO - 2022-06-05 15:54:50 --> Hooks Class Initialized
INFO - 2022-06-05 15:54:50 --> Config Class Initialized
INFO - 2022-06-05 15:54:50 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:54:50 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:50 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:50 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:54:50 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:54:50 --> Utf8 Class Initialized
INFO - 2022-06-05 15:54:50 --> URI Class Initialized
INFO - 2022-06-05 15:54:50 --> URI Class Initialized
INFO - 2022-06-05 15:54:50 --> URI Class Initialized
INFO - 2022-06-05 15:54:50 --> Router Class Initialized
INFO - 2022-06-05 15:54:50 --> Router Class Initialized
INFO - 2022-06-05 15:54:50 --> Router Class Initialized
INFO - 2022-06-05 15:54:50 --> Output Class Initialized
INFO - 2022-06-05 15:54:50 --> Output Class Initialized
INFO - 2022-06-05 15:54:50 --> Output Class Initialized
INFO - 2022-06-05 15:54:50 --> Security Class Initialized
INFO - 2022-06-05 15:54:50 --> Security Class Initialized
INFO - 2022-06-05 15:54:50 --> Security Class Initialized
DEBUG - 2022-06-05 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:50 --> Input Class Initialized
DEBUG - 2022-06-05 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:50 --> Input Class Initialized
INFO - 2022-06-05 15:54:50 --> Language Class Initialized
DEBUG - 2022-06-05 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:54:50 --> Input Class Initialized
INFO - 2022-06-05 15:54:50 --> Language Class Initialized
ERROR - 2022-06-05 15:54:50 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:54:50 --> Language Class Initialized
ERROR - 2022-06-05 15:54:50 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:54:50 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
DEBUG - 2022-06-05 15:55:31 --> No URI present. Default controller set.
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Loader Class Initialized
INFO - 2022-06-05 15:55:31 --> Helper loaded: url_helper
INFO - 2022-06-05 15:55:31 --> Database Driver Class Initialized
INFO - 2022-06-05 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:55:31 --> Controller Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:55:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:55:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:55:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:55:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:55:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:55:31 --> Final output sent to browser
DEBUG - 2022-06-05 15:55:31 --> Total execution time: 0.0398
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Config Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
DEBUG - 2022-06-05 15:55:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:31 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
INFO - 2022-06-05 15:55:31 --> URI Class Initialized
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:31 --> Router Class Initialized
INFO - 2022-06-05 15:55:31 --> Output Class Initialized
INFO - 2022-06-05 15:55:31 --> Security Class Initialized
DEBUG - 2022-06-05 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:31 --> Input Class Initialized
INFO - 2022-06-05 15:55:31 --> Language Class Initialized
ERROR - 2022-06-05 15:55:31 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:55:33 --> Config Class Initialized
INFO - 2022-06-05 15:55:33 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:33 --> Config Class Initialized
INFO - 2022-06-05 15:55:33 --> Config Class Initialized
INFO - 2022-06-05 15:55:33 --> Hooks Class Initialized
INFO - 2022-06-05 15:55:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 15:55:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:33 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:33 --> Utf8 Class Initialized
DEBUG - 2022-06-05 15:55:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:55:33 --> Utf8 Class Initialized
INFO - 2022-06-05 15:55:33 --> URI Class Initialized
INFO - 2022-06-05 15:55:33 --> URI Class Initialized
INFO - 2022-06-05 15:55:33 --> URI Class Initialized
INFO - 2022-06-05 15:55:33 --> Router Class Initialized
INFO - 2022-06-05 15:55:33 --> Router Class Initialized
INFO - 2022-06-05 15:55:33 --> Router Class Initialized
INFO - 2022-06-05 15:55:33 --> Output Class Initialized
INFO - 2022-06-05 15:55:33 --> Output Class Initialized
INFO - 2022-06-05 15:55:33 --> Output Class Initialized
INFO - 2022-06-05 15:55:33 --> Security Class Initialized
INFO - 2022-06-05 15:55:33 --> Security Class Initialized
INFO - 2022-06-05 15:55:33 --> Security Class Initialized
DEBUG - 2022-06-05 15:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 15:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:55:33 --> Input Class Initialized
INFO - 2022-06-05 15:55:33 --> Input Class Initialized
INFO - 2022-06-05 15:55:33 --> Input Class Initialized
INFO - 2022-06-05 15:55:33 --> Language Class Initialized
INFO - 2022-06-05 15:55:33 --> Language Class Initialized
INFO - 2022-06-05 15:55:33 --> Language Class Initialized
ERROR - 2022-06-05 15:55:33 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:55:33 --> 404 Page Not Found: /index
ERROR - 2022-06-05 15:55:33 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:56:25 --> Config Class Initialized
INFO - 2022-06-05 15:56:25 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:56:25 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:56:25 --> Utf8 Class Initialized
INFO - 2022-06-05 15:56:25 --> URI Class Initialized
INFO - 2022-06-05 15:56:25 --> Router Class Initialized
INFO - 2022-06-05 15:56:25 --> Output Class Initialized
INFO - 2022-06-05 15:56:25 --> Security Class Initialized
DEBUG - 2022-06-05 15:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:56:25 --> Input Class Initialized
INFO - 2022-06-05 15:56:25 --> Language Class Initialized
ERROR - 2022-06-05 15:56:25 --> 404 Page Not Found: /index
INFO - 2022-06-05 15:56:26 --> Config Class Initialized
INFO - 2022-06-05 15:56:26 --> Hooks Class Initialized
DEBUG - 2022-06-05 15:56:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 15:56:26 --> Utf8 Class Initialized
INFO - 2022-06-05 15:56:26 --> URI Class Initialized
DEBUG - 2022-06-05 15:56:26 --> No URI present. Default controller set.
INFO - 2022-06-05 15:56:26 --> Router Class Initialized
INFO - 2022-06-05 15:56:26 --> Output Class Initialized
INFO - 2022-06-05 15:56:26 --> Security Class Initialized
DEBUG - 2022-06-05 15:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 15:56:26 --> Input Class Initialized
INFO - 2022-06-05 15:56:26 --> Language Class Initialized
INFO - 2022-06-05 15:56:26 --> Language Class Initialized
INFO - 2022-06-05 15:56:26 --> Config Class Initialized
INFO - 2022-06-05 15:56:26 --> Loader Class Initialized
INFO - 2022-06-05 15:56:26 --> Helper loaded: url_helper
INFO - 2022-06-05 15:56:26 --> Database Driver Class Initialized
INFO - 2022-06-05 15:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 15:56:26 --> Controller Class Initialized
DEBUG - 2022-06-05 15:56:26 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 15:56:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 15:56:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 15:56:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 15:56:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 15:56:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 15:56:26 --> Final output sent to browser
DEBUG - 2022-06-05 15:56:26 --> Total execution time: 0.0365
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:30 --> No URI present. Default controller set.
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Loader Class Initialized
INFO - 2022-06-05 16:00:30 --> Helper loaded: url_helper
INFO - 2022-06-05 16:00:30 --> Database Driver Class Initialized
INFO - 2022-06-05 16:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:00:30 --> Controller Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:00:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:00:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:00:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:00:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/test.php
DEBUG - 2022-06-05 16:00:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:00:30 --> Final output sent to browser
DEBUG - 2022-06-05 16:00:30 --> Total execution time: 0.0399
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Config Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:30 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> URI Class Initialized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Router Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Output Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
INFO - 2022-06-05 16:00:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Input Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
INFO - 2022-06-05 16:00:30 --> Language Class Initialized
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:30 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:32 --> Config Class Initialized
INFO - 2022-06-05 16:00:32 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:32 --> Config Class Initialized
INFO - 2022-06-05 16:00:32 --> Config Class Initialized
INFO - 2022-06-05 16:00:32 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:32 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:32 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:32 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:32 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:32 --> URI Class Initialized
INFO - 2022-06-05 16:00:32 --> URI Class Initialized
INFO - 2022-06-05 16:00:32 --> Router Class Initialized
INFO - 2022-06-05 16:00:32 --> Output Class Initialized
INFO - 2022-06-05 16:00:32 --> Router Class Initialized
INFO - 2022-06-05 16:00:32 --> Router Class Initialized
INFO - 2022-06-05 16:00:32 --> Security Class Initialized
INFO - 2022-06-05 16:00:32 --> Output Class Initialized
INFO - 2022-06-05 16:00:32 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:32 --> Input Class Initialized
INFO - 2022-06-05 16:00:32 --> Language Class Initialized
INFO - 2022-06-05 16:00:32 --> Security Class Initialized
INFO - 2022-06-05 16:00:32 --> Security Class Initialized
ERROR - 2022-06-05 16:00:32 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:32 --> Input Class Initialized
INFO - 2022-06-05 16:00:32 --> Input Class Initialized
INFO - 2022-06-05 16:00:32 --> Language Class Initialized
INFO - 2022-06-05 16:00:32 --> Language Class Initialized
ERROR - 2022-06-05 16:00:32 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:32 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:40 --> No URI present. Default controller set.
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Loader Class Initialized
INFO - 2022-06-05 16:00:40 --> Helper loaded: url_helper
INFO - 2022-06-05 16:00:40 --> Database Driver Class Initialized
INFO - 2022-06-05 16:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:00:40 --> Controller Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:00:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:00:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:00:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:00:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/test.php
DEBUG - 2022-06-05 16:00:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:00:40 --> Final output sent to browser
DEBUG - 2022-06-05 16:00:40 --> Total execution time: 0.0282
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Config Class Initialized
INFO - 2022-06-05 16:00:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:40 --> Utf8 Class Initialized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:40 --> URI Class Initialized
INFO - 2022-06-05 16:00:40 --> Router Class Initialized
INFO - 2022-06-05 16:00:40 --> Output Class Initialized
INFO - 2022-06-05 16:00:40 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:40 --> Input Class Initialized
INFO - 2022-06-05 16:00:40 --> Language Class Initialized
ERROR - 2022-06-05 16:00:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:42 --> Config Class Initialized
INFO - 2022-06-05 16:00:42 --> Config Class Initialized
INFO - 2022-06-05 16:00:42 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:42 --> Config Class Initialized
INFO - 2022-06-05 16:00:42 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:42 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:42 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:42 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:42 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:42 --> URI Class Initialized
INFO - 2022-06-05 16:00:42 --> URI Class Initialized
INFO - 2022-06-05 16:00:42 --> URI Class Initialized
INFO - 2022-06-05 16:00:42 --> Router Class Initialized
INFO - 2022-06-05 16:00:42 --> Router Class Initialized
INFO - 2022-06-05 16:00:42 --> Router Class Initialized
INFO - 2022-06-05 16:00:42 --> Output Class Initialized
INFO - 2022-06-05 16:00:42 --> Output Class Initialized
INFO - 2022-06-05 16:00:42 --> Output Class Initialized
INFO - 2022-06-05 16:00:42 --> Security Class Initialized
INFO - 2022-06-05 16:00:42 --> Security Class Initialized
INFO - 2022-06-05 16:00:42 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:42 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:42 --> Input Class Initialized
INFO - 2022-06-05 16:00:42 --> Input Class Initialized
INFO - 2022-06-05 16:00:42 --> Language Class Initialized
INFO - 2022-06-05 16:00:42 --> Language Class Initialized
INFO - 2022-06-05 16:00:42 --> Language Class Initialized
ERROR - 2022-06-05 16:00:42 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:42 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:42 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:48 --> No URI present. Default controller set.
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Loader Class Initialized
INFO - 2022-06-05 16:00:48 --> Helper loaded: url_helper
INFO - 2022-06-05 16:00:48 --> Database Driver Class Initialized
INFO - 2022-06-05 16:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:00:48 --> Controller Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:00:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:00:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:00:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:00:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/test.php
DEBUG - 2022-06-05 16:00:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:00:48 --> Final output sent to browser
DEBUG - 2022-06-05 16:00:48 --> Total execution time: 0.0375
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:48 --> Config Class Initialized
INFO - 2022-06-05 16:00:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:48 --> URI Class Initialized
INFO - 2022-06-05 16:00:48 --> Router Class Initialized
INFO - 2022-06-05 16:00:48 --> Output Class Initialized
INFO - 2022-06-05 16:00:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:48 --> Input Class Initialized
INFO - 2022-06-05 16:00:48 --> Language Class Initialized
ERROR - 2022-06-05 16:00:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:50 --> Config Class Initialized
INFO - 2022-06-05 16:00:50 --> Config Class Initialized
INFO - 2022-06-05 16:00:50 --> Config Class Initialized
INFO - 2022-06-05 16:00:50 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:50 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:50 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:50 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:50 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:50 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:50 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:50 --> URI Class Initialized
INFO - 2022-06-05 16:00:50 --> URI Class Initialized
INFO - 2022-06-05 16:00:50 --> URI Class Initialized
INFO - 2022-06-05 16:00:50 --> Router Class Initialized
INFO - 2022-06-05 16:00:50 --> Router Class Initialized
INFO - 2022-06-05 16:00:50 --> Router Class Initialized
INFO - 2022-06-05 16:00:50 --> Output Class Initialized
INFO - 2022-06-05 16:00:50 --> Output Class Initialized
INFO - 2022-06-05 16:00:50 --> Output Class Initialized
INFO - 2022-06-05 16:00:50 --> Security Class Initialized
INFO - 2022-06-05 16:00:50 --> Security Class Initialized
INFO - 2022-06-05 16:00:50 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:50 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:50 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:50 --> Input Class Initialized
INFO - 2022-06-05 16:00:50 --> Language Class Initialized
INFO - 2022-06-05 16:00:50 --> Language Class Initialized
INFO - 2022-06-05 16:00:50 --> Language Class Initialized
ERROR - 2022-06-05 16:00:50 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:50 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:50 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:56 --> No URI present. Default controller set.
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Loader Class Initialized
INFO - 2022-06-05 16:00:56 --> Helper loaded: url_helper
INFO - 2022-06-05 16:00:56 --> Database Driver Class Initialized
INFO - 2022-06-05 16:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:00:56 --> Controller Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:00:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:00:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:00:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:00:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:00:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:00:56 --> Final output sent to browser
DEBUG - 2022-06-05 16:00:56 --> Total execution time: 0.0348
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> Config Class Initialized
INFO - 2022-06-05 16:00:56 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:56 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
INFO - 2022-06-05 16:00:56 --> URI Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:56 --> Router Class Initialized
INFO - 2022-06-05 16:00:56 --> Output Class Initialized
INFO - 2022-06-05 16:00:56 --> Security Class Initialized
DEBUG - 2022-06-05 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:56 --> Input Class Initialized
INFO - 2022-06-05 16:00:56 --> Language Class Initialized
ERROR - 2022-06-05 16:00:56 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:57 --> Config Class Initialized
INFO - 2022-06-05 16:00:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:57 --> Config Class Initialized
INFO - 2022-06-05 16:00:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:00:57 --> Config Class Initialized
INFO - 2022-06-05 16:00:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:00:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:57 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:00:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:00:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:00:57 --> URI Class Initialized
INFO - 2022-06-05 16:00:57 --> URI Class Initialized
INFO - 2022-06-05 16:00:57 --> URI Class Initialized
INFO - 2022-06-05 16:00:57 --> Router Class Initialized
INFO - 2022-06-05 16:00:57 --> Router Class Initialized
INFO - 2022-06-05 16:00:57 --> Router Class Initialized
INFO - 2022-06-05 16:00:57 --> Output Class Initialized
INFO - 2022-06-05 16:00:57 --> Security Class Initialized
INFO - 2022-06-05 16:00:57 --> Output Class Initialized
INFO - 2022-06-05 16:00:57 --> Output Class Initialized
DEBUG - 2022-06-05 16:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:57 --> Input Class Initialized
INFO - 2022-06-05 16:00:57 --> Security Class Initialized
INFO - 2022-06-05 16:00:57 --> Security Class Initialized
INFO - 2022-06-05 16:00:57 --> Language Class Initialized
DEBUG - 2022-06-05 16:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:00:57 --> Input Class Initialized
DEBUG - 2022-06-05 16:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:00:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:00:57 --> Input Class Initialized
INFO - 2022-06-05 16:00:57 --> Language Class Initialized
INFO - 2022-06-05 16:00:57 --> Language Class Initialized
ERROR - 2022-06-05 16:00:57 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:00:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
DEBUG - 2022-06-05 16:04:46 --> No URI present. Default controller set.
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Loader Class Initialized
INFO - 2022-06-05 16:04:46 --> Helper loaded: url_helper
INFO - 2022-06-05 16:04:46 --> Database Driver Class Initialized
INFO - 2022-06-05 16:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:04:46 --> Controller Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:04:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:04:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:04:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:04:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:04:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:04:46 --> Final output sent to browser
DEBUG - 2022-06-05 16:04:46 --> Total execution time: 0.0368
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
INFO - 2022-06-05 16:04:46 --> Config Class Initialized
INFO - 2022-06-05 16:04:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
DEBUG - 2022-06-05 16:04:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:46 --> URI Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
INFO - 2022-06-05 16:04:46 --> Router Class Initialized
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:46 --> Output Class Initialized
INFO - 2022-06-05 16:04:46 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:46 --> Input Class Initialized
INFO - 2022-06-05 16:04:46 --> Language Class Initialized
ERROR - 2022-06-05 16:04:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Loader Class Initialized
INFO - 2022-06-05 16:04:48 --> Helper loaded: url_helper
INFO - 2022-06-05 16:04:48 --> Database Driver Class Initialized
INFO - 2022-06-05 16:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:04:48 --> Controller Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:04:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:04:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:04:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:04:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:04:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:04:48 --> Final output sent to browser
DEBUG - 2022-06-05 16:04:48 --> Total execution time: 0.0429
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Config Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
DEBUG - 2022-06-05 16:04:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:48 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:48 --> URI Class Initialized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
INFO - 2022-06-05 16:04:48 --> Router Class Initialized
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Output Class Initialized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
INFO - 2022-06-05 16:04:48 --> Security Class Initialized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:48 --> Input Class Initialized
INFO - 2022-06-05 16:04:48 --> Language Class Initialized
ERROR - 2022-06-05 16:04:48 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:04:51 --> Config Class Initialized
INFO - 2022-06-05 16:04:51 --> Config Class Initialized
INFO - 2022-06-05 16:04:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:04:51 --> Config Class Initialized
INFO - 2022-06-05 16:04:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:04:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:51 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:04:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:51 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:04:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:04:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:04:51 --> URI Class Initialized
INFO - 2022-06-05 16:04:51 --> URI Class Initialized
INFO - 2022-06-05 16:04:51 --> URI Class Initialized
INFO - 2022-06-05 16:04:51 --> Router Class Initialized
INFO - 2022-06-05 16:04:51 --> Router Class Initialized
INFO - 2022-06-05 16:04:51 --> Router Class Initialized
INFO - 2022-06-05 16:04:51 --> Output Class Initialized
INFO - 2022-06-05 16:04:51 --> Output Class Initialized
INFO - 2022-06-05 16:04:51 --> Output Class Initialized
INFO - 2022-06-05 16:04:51 --> Security Class Initialized
INFO - 2022-06-05 16:04:51 --> Security Class Initialized
INFO - 2022-06-05 16:04:51 --> Security Class Initialized
DEBUG - 2022-06-05 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:51 --> Input Class Initialized
DEBUG - 2022-06-05 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:51 --> Input Class Initialized
INFO - 2022-06-05 16:04:51 --> Language Class Initialized
DEBUG - 2022-06-05 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:04:51 --> Input Class Initialized
INFO - 2022-06-05 16:04:51 --> Language Class Initialized
INFO - 2022-06-05 16:04:51 --> Language Class Initialized
ERROR - 2022-06-05 16:04:51 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:04:51 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:04:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Loader Class Initialized
INFO - 2022-06-05 16:05:00 --> Helper loaded: url_helper
INFO - 2022-06-05 16:05:00 --> Database Driver Class Initialized
INFO - 2022-06-05 16:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:05:00 --> Controller Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:05:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:05:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:05:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:05:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:05:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:05:00 --> Final output sent to browser
DEBUG - 2022-06-05 16:05:00 --> Total execution time: 0.0356
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:00 --> Config Class Initialized
INFO - 2022-06-05 16:05:00 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:00 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:00 --> URI Class Initialized
INFO - 2022-06-05 16:05:00 --> Router Class Initialized
INFO - 2022-06-05 16:05:00 --> Output Class Initialized
INFO - 2022-06-05 16:05:00 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:00 --> Input Class Initialized
INFO - 2022-06-05 16:05:00 --> Language Class Initialized
ERROR - 2022-06-05 16:05:00 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Loader Class Initialized
INFO - 2022-06-05 16:05:01 --> Helper loaded: url_helper
INFO - 2022-06-05 16:05:01 --> Database Driver Class Initialized
INFO - 2022-06-05 16:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:05:01 --> Controller Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:05:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:05:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:05:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:05:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:05:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:05:01 --> Final output sent to browser
DEBUG - 2022-06-05 16:05:01 --> Total execution time: 0.0411
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:01 --> Config Class Initialized
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
INFO - 2022-06-05 16:05:01 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:01 --> URI Class Initialized
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:01 --> Router Class Initialized
INFO - 2022-06-05 16:05:01 --> Output Class Initialized
INFO - 2022-06-05 16:05:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:01 --> Input Class Initialized
INFO - 2022-06-05 16:05:01 --> Language Class Initialized
ERROR - 2022-06-05 16:05:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:02 --> Config Class Initialized
INFO - 2022-06-05 16:05:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:02 --> Config Class Initialized
INFO - 2022-06-05 16:05:02 --> Config Class Initialized
INFO - 2022-06-05 16:05:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:02 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:02 --> URI Class Initialized
INFO - 2022-06-05 16:05:02 --> URI Class Initialized
INFO - 2022-06-05 16:05:02 --> URI Class Initialized
INFO - 2022-06-05 16:05:02 --> Router Class Initialized
INFO - 2022-06-05 16:05:02 --> Router Class Initialized
INFO - 2022-06-05 16:05:02 --> Router Class Initialized
INFO - 2022-06-05 16:05:02 --> Output Class Initialized
INFO - 2022-06-05 16:05:02 --> Output Class Initialized
INFO - 2022-06-05 16:05:02 --> Output Class Initialized
INFO - 2022-06-05 16:05:02 --> Security Class Initialized
INFO - 2022-06-05 16:05:02 --> Security Class Initialized
INFO - 2022-06-05 16:05:02 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:02 --> Input Class Initialized
INFO - 2022-06-05 16:05:02 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:02 --> Input Class Initialized
ERROR - 2022-06-05 16:05:02 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:02 --> Input Class Initialized
INFO - 2022-06-05 16:05:02 --> Language Class Initialized
INFO - 2022-06-05 16:05:02 --> Language Class Initialized
ERROR - 2022-06-05 16:05:02 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:02 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Loader Class Initialized
INFO - 2022-06-05 16:05:05 --> Helper loaded: url_helper
INFO - 2022-06-05 16:05:05 --> Database Driver Class Initialized
INFO - 2022-06-05 16:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:05:05 --> Controller Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:05:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:05:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:05:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:05:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:05:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:05:05 --> Final output sent to browser
DEBUG - 2022-06-05 16:05:05 --> Total execution time: 0.0425
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:05 --> Config Class Initialized
INFO - 2022-06-05 16:05:05 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:05 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:05 --> URI Class Initialized
INFO - 2022-06-05 16:05:05 --> Router Class Initialized
INFO - 2022-06-05 16:05:05 --> Output Class Initialized
INFO - 2022-06-05 16:05:05 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:05 --> Input Class Initialized
INFO - 2022-06-05 16:05:05 --> Language Class Initialized
ERROR - 2022-06-05 16:05:05 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:08 --> Config Class Initialized
INFO - 2022-06-05 16:05:08 --> Config Class Initialized
INFO - 2022-06-05 16:05:08 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:08 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:08 --> Config Class Initialized
INFO - 2022-06-05 16:05:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:08 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:08 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:08 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:08 --> URI Class Initialized
INFO - 2022-06-05 16:05:08 --> URI Class Initialized
INFO - 2022-06-05 16:05:08 --> URI Class Initialized
INFO - 2022-06-05 16:05:08 --> Router Class Initialized
INFO - 2022-06-05 16:05:08 --> Router Class Initialized
INFO - 2022-06-05 16:05:08 --> Output Class Initialized
INFO - 2022-06-05 16:05:08 --> Router Class Initialized
INFO - 2022-06-05 16:05:08 --> Output Class Initialized
INFO - 2022-06-05 16:05:08 --> Security Class Initialized
INFO - 2022-06-05 16:05:08 --> Output Class Initialized
INFO - 2022-06-05 16:05:08 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:08 --> Input Class Initialized
INFO - 2022-06-05 16:05:08 --> Security Class Initialized
INFO - 2022-06-05 16:05:08 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:08 --> Input Class Initialized
DEBUG - 2022-06-05 16:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:08 --> Input Class Initialized
INFO - 2022-06-05 16:05:08 --> Language Class Initialized
ERROR - 2022-06-05 16:05:08 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:08 --> Language Class Initialized
ERROR - 2022-06-05 16:05:08 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:08 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Loader Class Initialized
INFO - 2022-06-05 16:05:45 --> Helper loaded: url_helper
INFO - 2022-06-05 16:05:45 --> Database Driver Class Initialized
INFO - 2022-06-05 16:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:05:45 --> Controller Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:05:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:05:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:05:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:05:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:05:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:05:45 --> Final output sent to browser
DEBUG - 2022-06-05 16:05:45 --> Total execution time: 0.0378
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
INFO - 2022-06-05 16:05:45 --> Config Class Initialized
INFO - 2022-06-05 16:05:45 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:45 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:45 --> URI Class Initialized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:45 --> Router Class Initialized
INFO - 2022-06-05 16:05:45 --> Output Class Initialized
INFO - 2022-06-05 16:05:45 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:45 --> Input Class Initialized
INFO - 2022-06-05 16:05:45 --> Language Class Initialized
ERROR - 2022-06-05 16:05:45 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Loader Class Initialized
INFO - 2022-06-05 16:05:46 --> Helper loaded: url_helper
INFO - 2022-06-05 16:05:46 --> Database Driver Class Initialized
INFO - 2022-06-05 16:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:05:46 --> Controller Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:05:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:05:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:05:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:05:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:05:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:05:46 --> Final output sent to browser
DEBUG - 2022-06-05 16:05:46 --> Total execution time: 0.0317
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:46 --> Config Class Initialized
INFO - 2022-06-05 16:05:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:46 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:46 --> URI Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Router Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
INFO - 2022-06-05 16:05:46 --> Security Class Initialized
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:46 --> Input Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:46 --> Language Class Initialized
ERROR - 2022-06-05 16:05:46 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:49 --> Config Class Initialized
INFO - 2022-06-05 16:05:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:49 --> Config Class Initialized
INFO - 2022-06-05 16:05:49 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:49 --> Config Class Initialized
INFO - 2022-06-05 16:05:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:49 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:49 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:49 --> URI Class Initialized
INFO - 2022-06-05 16:05:49 --> Router Class Initialized
INFO - 2022-06-05 16:05:49 --> URI Class Initialized
INFO - 2022-06-05 16:05:49 --> Output Class Initialized
INFO - 2022-06-05 16:05:49 --> Router Class Initialized
INFO - 2022-06-05 16:05:49 --> Security Class Initialized
INFO - 2022-06-05 16:05:49 --> Router Class Initialized
INFO - 2022-06-05 16:05:49 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:49 --> Input Class Initialized
INFO - 2022-06-05 16:05:49 --> Output Class Initialized
INFO - 2022-06-05 16:05:49 --> Language Class Initialized
INFO - 2022-06-05 16:05:49 --> Security Class Initialized
INFO - 2022-06-05 16:05:49 --> Security Class Initialized
ERROR - 2022-06-05 16:05:49 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:49 --> Input Class Initialized
DEBUG - 2022-06-05 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:49 --> Input Class Initialized
INFO - 2022-06-05 16:05:49 --> Language Class Initialized
INFO - 2022-06-05 16:05:49 --> Language Class Initialized
ERROR - 2022-06-05 16:05:49 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:49 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Loader Class Initialized
INFO - 2022-06-05 16:05:51 --> Helper loaded: url_helper
INFO - 2022-06-05 16:05:51 --> Database Driver Class Initialized
INFO - 2022-06-05 16:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:05:51 --> Controller Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:05:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:05:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:05:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:05:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:05:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:05:51 --> Final output sent to browser
DEBUG - 2022-06-05 16:05:51 --> Total execution time: 0.0361
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:51 --> Config Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
INFO - 2022-06-05 16:05:51 --> URI Class Initialized
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:51 --> Router Class Initialized
INFO - 2022-06-05 16:05:51 --> Output Class Initialized
INFO - 2022-06-05 16:05:51 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:51 --> Input Class Initialized
INFO - 2022-06-05 16:05:51 --> Language Class Initialized
ERROR - 2022-06-05 16:05:51 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:05:53 --> Config Class Initialized
INFO - 2022-06-05 16:05:53 --> Config Class Initialized
INFO - 2022-06-05 16:05:53 --> Config Class Initialized
INFO - 2022-06-05 16:05:53 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:53 --> Hooks Class Initialized
INFO - 2022-06-05 16:05:53 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:05:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:53 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:05:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:05:53 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:53 --> Utf8 Class Initialized
INFO - 2022-06-05 16:05:53 --> URI Class Initialized
INFO - 2022-06-05 16:05:53 --> URI Class Initialized
INFO - 2022-06-05 16:05:53 --> URI Class Initialized
INFO - 2022-06-05 16:05:53 --> Router Class Initialized
INFO - 2022-06-05 16:05:53 --> Router Class Initialized
INFO - 2022-06-05 16:05:53 --> Router Class Initialized
INFO - 2022-06-05 16:05:53 --> Output Class Initialized
INFO - 2022-06-05 16:05:53 --> Output Class Initialized
INFO - 2022-06-05 16:05:53 --> Output Class Initialized
INFO - 2022-06-05 16:05:53 --> Security Class Initialized
INFO - 2022-06-05 16:05:53 --> Security Class Initialized
INFO - 2022-06-05 16:05:53 --> Security Class Initialized
DEBUG - 2022-06-05 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:53 --> Input Class Initialized
INFO - 2022-06-05 16:05:53 --> Language Class Initialized
DEBUG - 2022-06-05 16:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:05:53 --> Input Class Initialized
INFO - 2022-06-05 16:05:53 --> Input Class Initialized
INFO - 2022-06-05 16:05:53 --> Language Class Initialized
INFO - 2022-06-05 16:05:53 --> Language Class Initialized
ERROR - 2022-06-05 16:05:53 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:53 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:05:53 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Loader Class Initialized
INFO - 2022-06-05 16:06:26 --> Helper loaded: url_helper
INFO - 2022-06-05 16:06:26 --> Database Driver Class Initialized
INFO - 2022-06-05 16:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:06:26 --> Controller Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:06:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:06:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:06:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:06:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:06:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:06:26 --> Final output sent to browser
DEBUG - 2022-06-05 16:06:26 --> Total execution time: 0.0397
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Config Class Initialized
INFO - 2022-06-05 16:06:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:06:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:26 --> URI Class Initialized
INFO - 2022-06-05 16:06:26 --> Router Class Initialized
INFO - 2022-06-05 16:06:26 --> Output Class Initialized
INFO - 2022-06-05 16:06:26 --> Security Class Initialized
DEBUG - 2022-06-05 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:26 --> Input Class Initialized
INFO - 2022-06-05 16:06:26 --> Language Class Initialized
ERROR - 2022-06-05 16:06:26 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:06:27 --> Config Class Initialized
INFO - 2022-06-05 16:06:27 --> Config Class Initialized
INFO - 2022-06-05 16:06:27 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:27 --> Config Class Initialized
INFO - 2022-06-05 16:06:27 --> Hooks Class Initialized
INFO - 2022-06-05 16:06:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:06:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:27 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:06:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:06:27 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:27 --> Utf8 Class Initialized
INFO - 2022-06-05 16:06:27 --> URI Class Initialized
INFO - 2022-06-05 16:06:27 --> URI Class Initialized
INFO - 2022-06-05 16:06:27 --> URI Class Initialized
INFO - 2022-06-05 16:06:27 --> Router Class Initialized
INFO - 2022-06-05 16:06:27 --> Router Class Initialized
INFO - 2022-06-05 16:06:27 --> Router Class Initialized
INFO - 2022-06-05 16:06:27 --> Output Class Initialized
INFO - 2022-06-05 16:06:27 --> Output Class Initialized
INFO - 2022-06-05 16:06:27 --> Output Class Initialized
INFO - 2022-06-05 16:06:27 --> Security Class Initialized
INFO - 2022-06-05 16:06:27 --> Security Class Initialized
INFO - 2022-06-05 16:06:27 --> Security Class Initialized
DEBUG - 2022-06-05 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:27 --> Input Class Initialized
DEBUG - 2022-06-05 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:27 --> Input Class Initialized
INFO - 2022-06-05 16:06:27 --> Language Class Initialized
INFO - 2022-06-05 16:06:27 --> Language Class Initialized
DEBUG - 2022-06-05 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:06:27 --> Input Class Initialized
ERROR - 2022-06-05 16:06:27 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:06:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:06:27 --> Language Class Initialized
ERROR - 2022-06-05 16:06:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
INFO - 2022-06-05 16:09:49 --> Loader Class Initialized
INFO - 2022-06-05 16:09:49 --> Helper loaded: url_helper
INFO - 2022-06-05 16:09:49 --> Database Driver Class Initialized
INFO - 2022-06-05 16:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:09:49 --> Controller Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:09:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:09:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:09:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:09:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:09:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:09:49 --> Final output sent to browser
DEBUG - 2022-06-05 16:09:49 --> Total execution time: 0.0951
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Config Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:49 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:49 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
INFO - 2022-06-05 16:09:49 --> URI Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
ERROR - 2022-06-05 16:09:49 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
ERROR - 2022-06-05 16:09:49 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:49 --> Router Class Initialized
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
ERROR - 2022-06-05 16:09:49 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
INFO - 2022-06-05 16:09:49 --> Output Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
INFO - 2022-06-05 16:09:49 --> Security Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
DEBUG - 2022-06-05 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:49 --> Input Class Initialized
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
ERROR - 2022-06-05 16:09:49 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:49 --> Language Class Initialized
ERROR - 2022-06-05 16:09:49 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:09:49 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:50 --> Config Class Initialized
INFO - 2022-06-05 16:09:50 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:09:50 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:50 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:50 --> URI Class Initialized
INFO - 2022-06-05 16:09:50 --> Router Class Initialized
INFO - 2022-06-05 16:09:50 --> Output Class Initialized
INFO - 2022-06-05 16:09:50 --> Security Class Initialized
DEBUG - 2022-06-05 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:50 --> Input Class Initialized
INFO - 2022-06-05 16:09:50 --> Language Class Initialized
ERROR - 2022-06-05 16:09:50 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:09:52 --> Config Class Initialized
INFO - 2022-06-05 16:09:52 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:52 --> Config Class Initialized
INFO - 2022-06-05 16:09:52 --> Hooks Class Initialized
INFO - 2022-06-05 16:09:52 --> Config Class Initialized
INFO - 2022-06-05 16:09:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:09:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:52 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:09:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:52 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:09:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:09:52 --> Utf8 Class Initialized
INFO - 2022-06-05 16:09:52 --> URI Class Initialized
INFO - 2022-06-05 16:09:52 --> URI Class Initialized
INFO - 2022-06-05 16:09:52 --> URI Class Initialized
INFO - 2022-06-05 16:09:52 --> Router Class Initialized
INFO - 2022-06-05 16:09:52 --> Router Class Initialized
INFO - 2022-06-05 16:09:52 --> Router Class Initialized
INFO - 2022-06-05 16:09:52 --> Output Class Initialized
INFO - 2022-06-05 16:09:52 --> Output Class Initialized
INFO - 2022-06-05 16:09:52 --> Output Class Initialized
INFO - 2022-06-05 16:09:52 --> Security Class Initialized
INFO - 2022-06-05 16:09:52 --> Security Class Initialized
INFO - 2022-06-05 16:09:52 --> Security Class Initialized
DEBUG - 2022-06-05 16:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:09:52 --> Input Class Initialized
INFO - 2022-06-05 16:09:52 --> Input Class Initialized
INFO - 2022-06-05 16:09:52 --> Input Class Initialized
INFO - 2022-06-05 16:09:52 --> Language Class Initialized
INFO - 2022-06-05 16:09:52 --> Language Class Initialized
INFO - 2022-06-05 16:09:52 --> Language Class Initialized
ERROR - 2022-06-05 16:09:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:09:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:09:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Loader Class Initialized
INFO - 2022-06-05 16:10:02 --> Helper loaded: url_helper
INFO - 2022-06-05 16:10:02 --> Database Driver Class Initialized
INFO - 2022-06-05 16:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:10:02 --> Controller Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:10:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:10:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:10:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:10:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:10:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:10:02 --> Final output sent to browser
DEBUG - 2022-06-05 16:10:02 --> Total execution time: 0.0372
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
INFO - 2022-06-05 16:10:02 --> Config Class Initialized
INFO - 2022-06-05 16:10:02 --> Hooks Class Initialized
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:02 --> URI Class Initialized
INFO - 2022-06-05 16:10:02 --> Router Class Initialized
INFO - 2022-06-05 16:10:02 --> Output Class Initialized
INFO - 2022-06-05 16:10:02 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:02 --> Input Class Initialized
INFO - 2022-06-05 16:10:02 --> Language Class Initialized
ERROR - 2022-06-05 16:10:02 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:04 --> Config Class Initialized
INFO - 2022-06-05 16:10:04 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:04 --> Config Class Initialized
INFO - 2022-06-05 16:10:04 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:04 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:10:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:04 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:04 --> Config Class Initialized
INFO - 2022-06-05 16:10:04 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:04 --> URI Class Initialized
INFO - 2022-06-05 16:10:04 --> URI Class Initialized
DEBUG - 2022-06-05 16:10:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:04 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:04 --> Router Class Initialized
INFO - 2022-06-05 16:10:04 --> Router Class Initialized
INFO - 2022-06-05 16:10:04 --> URI Class Initialized
INFO - 2022-06-05 16:10:04 --> Output Class Initialized
INFO - 2022-06-05 16:10:04 --> Output Class Initialized
INFO - 2022-06-05 16:10:04 --> Security Class Initialized
INFO - 2022-06-05 16:10:04 --> Security Class Initialized
INFO - 2022-06-05 16:10:04 --> Router Class Initialized
DEBUG - 2022-06-05 16:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:04 --> Input Class Initialized
DEBUG - 2022-06-05 16:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:04 --> Input Class Initialized
INFO - 2022-06-05 16:10:04 --> Language Class Initialized
INFO - 2022-06-05 16:10:04 --> Output Class Initialized
INFO - 2022-06-05 16:10:04 --> Language Class Initialized
ERROR - 2022-06-05 16:10:04 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:04 --> Security Class Initialized
ERROR - 2022-06-05 16:10:04 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:04 --> Input Class Initialized
INFO - 2022-06-05 16:10:04 --> Language Class Initialized
ERROR - 2022-06-05 16:10:04 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Loader Class Initialized
INFO - 2022-06-05 16:10:23 --> Helper loaded: url_helper
INFO - 2022-06-05 16:10:23 --> Database Driver Class Initialized
INFO - 2022-06-05 16:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:10:23 --> Controller Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:10:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:10:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:10:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:10:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:10:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:10:23 --> Final output sent to browser
DEBUG - 2022-06-05 16:10:23 --> Total execution time: 0.0521
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:23 --> Config Class Initialized
INFO - 2022-06-05 16:10:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:23 --> URI Class Initialized
INFO - 2022-06-05 16:10:23 --> Router Class Initialized
INFO - 2022-06-05 16:10:23 --> Output Class Initialized
INFO - 2022-06-05 16:10:23 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:23 --> Input Class Initialized
INFO - 2022-06-05 16:10:23 --> Language Class Initialized
ERROR - 2022-06-05 16:10:23 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:25 --> Config Class Initialized
INFO - 2022-06-05 16:10:25 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:25 --> Config Class Initialized
INFO - 2022-06-05 16:10:25 --> Hooks Class Initialized
INFO - 2022-06-05 16:10:25 --> Config Class Initialized
INFO - 2022-06-05 16:10:25 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:10:25 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:25 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:10:25 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:25 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:25 --> URI Class Initialized
DEBUG - 2022-06-05 16:10:25 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:10:25 --> URI Class Initialized
INFO - 2022-06-05 16:10:25 --> Utf8 Class Initialized
INFO - 2022-06-05 16:10:25 --> URI Class Initialized
INFO - 2022-06-05 16:10:25 --> Router Class Initialized
INFO - 2022-06-05 16:10:25 --> Router Class Initialized
INFO - 2022-06-05 16:10:25 --> Output Class Initialized
INFO - 2022-06-05 16:10:25 --> Router Class Initialized
INFO - 2022-06-05 16:10:25 --> Output Class Initialized
INFO - 2022-06-05 16:10:25 --> Security Class Initialized
INFO - 2022-06-05 16:10:25 --> Output Class Initialized
INFO - 2022-06-05 16:10:25 --> Security Class Initialized
DEBUG - 2022-06-05 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:25 --> Input Class Initialized
INFO - 2022-06-05 16:10:25 --> Security Class Initialized
INFO - 2022-06-05 16:10:25 --> Language Class Initialized
DEBUG - 2022-06-05 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:10:25 --> Input Class Initialized
DEBUG - 2022-06-05 16:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-05 16:10:25 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:10:25 --> Language Class Initialized
INFO - 2022-06-05 16:10:25 --> Input Class Initialized
INFO - 2022-06-05 16:10:25 --> Language Class Initialized
ERROR - 2022-06-05 16:10:25 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:10:25 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Loader Class Initialized
INFO - 2022-06-05 16:12:35 --> Helper loaded: url_helper
INFO - 2022-06-05 16:12:35 --> Database Driver Class Initialized
INFO - 2022-06-05 16:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:12:35 --> Controller Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:12:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:12:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:12:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:12:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:12:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:12:35 --> Final output sent to browser
DEBUG - 2022-06-05 16:12:35 --> Total execution time: 0.1413
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
INFO - 2022-06-05 16:12:35 --> Config Class Initialized
INFO - 2022-06-05 16:12:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
DEBUG - 2022-06-05 16:12:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
INFO - 2022-06-05 16:12:35 --> Utf8 Class Initialized
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:12:35 --> URI Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:12:35 --> Router Class Initialized
INFO - 2022-06-05 16:12:35 --> Output Class Initialized
INFO - 2022-06-05 16:12:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:35 --> Input Class Initialized
INFO - 2022-06-05 16:12:35 --> Language Class Initialized
ERROR - 2022-06-05 16:12:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:12:36 --> Config Class Initialized
INFO - 2022-06-05 16:12:36 --> Config Class Initialized
INFO - 2022-06-05 16:12:36 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:36 --> Hooks Class Initialized
INFO - 2022-06-05 16:12:36 --> Config Class Initialized
INFO - 2022-06-05 16:12:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:12:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:36 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:36 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:12:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:12:36 --> Utf8 Class Initialized
INFO - 2022-06-05 16:12:36 --> URI Class Initialized
INFO - 2022-06-05 16:12:36 --> URI Class Initialized
INFO - 2022-06-05 16:12:36 --> URI Class Initialized
INFO - 2022-06-05 16:12:36 --> Router Class Initialized
INFO - 2022-06-05 16:12:36 --> Router Class Initialized
INFO - 2022-06-05 16:12:36 --> Router Class Initialized
INFO - 2022-06-05 16:12:36 --> Output Class Initialized
INFO - 2022-06-05 16:12:36 --> Output Class Initialized
INFO - 2022-06-05 16:12:36 --> Output Class Initialized
INFO - 2022-06-05 16:12:36 --> Security Class Initialized
INFO - 2022-06-05 16:12:36 --> Security Class Initialized
INFO - 2022-06-05 16:12:36 --> Security Class Initialized
DEBUG - 2022-06-05 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:36 --> Input Class Initialized
DEBUG - 2022-06-05 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:36 --> Input Class Initialized
DEBUG - 2022-06-05 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:12:36 --> Language Class Initialized
INFO - 2022-06-05 16:12:36 --> Input Class Initialized
INFO - 2022-06-05 16:12:36 --> Language Class Initialized
INFO - 2022-06-05 16:12:36 --> Language Class Initialized
ERROR - 2022-06-05 16:12:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:12:36 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:12:36 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Loader Class Initialized
INFO - 2022-06-05 16:16:57 --> Helper loaded: url_helper
INFO - 2022-06-05 16:16:57 --> Database Driver Class Initialized
INFO - 2022-06-05 16:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:16:57 --> Controller Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:16:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:16:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:16:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:16:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:16:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:16:57 --> Final output sent to browser
DEBUG - 2022-06-05 16:16:57 --> Total execution time: 0.0546
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:57 --> Config Class Initialized
INFO - 2022-06-05 16:16:57 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
DEBUG - 2022-06-05 16:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:57 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
INFO - 2022-06-05 16:16:57 --> URI Class Initialized
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Router Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Output Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:57 --> Security Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:57 --> Input Class Initialized
INFO - 2022-06-05 16:16:57 --> Language Class Initialized
ERROR - 2022-06-05 16:16:57 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:59 --> Config Class Initialized
INFO - 2022-06-05 16:16:59 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:59 --> Config Class Initialized
INFO - 2022-06-05 16:16:59 --> Hooks Class Initialized
INFO - 2022-06-05 16:16:59 --> Config Class Initialized
INFO - 2022-06-05 16:16:59 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:16:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:59 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:16:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:59 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:16:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:16:59 --> URI Class Initialized
INFO - 2022-06-05 16:16:59 --> Utf8 Class Initialized
INFO - 2022-06-05 16:16:59 --> URI Class Initialized
INFO - 2022-06-05 16:16:59 --> URI Class Initialized
INFO - 2022-06-05 16:16:59 --> Router Class Initialized
INFO - 2022-06-05 16:16:59 --> Router Class Initialized
INFO - 2022-06-05 16:16:59 --> Router Class Initialized
INFO - 2022-06-05 16:16:59 --> Output Class Initialized
INFO - 2022-06-05 16:16:59 --> Output Class Initialized
INFO - 2022-06-05 16:16:59 --> Output Class Initialized
INFO - 2022-06-05 16:16:59 --> Security Class Initialized
INFO - 2022-06-05 16:16:59 --> Security Class Initialized
DEBUG - 2022-06-05 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:59 --> Security Class Initialized
INFO - 2022-06-05 16:16:59 --> Input Class Initialized
DEBUG - 2022-06-05 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:59 --> Input Class Initialized
INFO - 2022-06-05 16:16:59 --> Language Class Initialized
DEBUG - 2022-06-05 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:16:59 --> Language Class Initialized
INFO - 2022-06-05 16:16:59 --> Input Class Initialized
ERROR - 2022-06-05 16:16:59 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:16:59 --> Language Class Initialized
ERROR - 2022-06-05 16:16:59 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:16:59 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Loader Class Initialized
INFO - 2022-06-05 16:17:14 --> Helper loaded: url_helper
INFO - 2022-06-05 16:17:14 --> Database Driver Class Initialized
INFO - 2022-06-05 16:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:17:14 --> Controller Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:17:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:17:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:17:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:17:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:17:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:17:14 --> Final output sent to browser
DEBUG - 2022-06-05 16:17:14 --> Total execution time: 0.0512
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:14 --> Config Class Initialized
INFO - 2022-06-05 16:17:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:14 --> URI Class Initialized
INFO - 2022-06-05 16:17:14 --> Router Class Initialized
INFO - 2022-06-05 16:17:14 --> Output Class Initialized
INFO - 2022-06-05 16:17:14 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:14 --> Input Class Initialized
INFO - 2022-06-05 16:17:14 --> Language Class Initialized
ERROR - 2022-06-05 16:17:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:16 --> Config Class Initialized
INFO - 2022-06-05 16:17:16 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:16 --> Config Class Initialized
INFO - 2022-06-05 16:17:16 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:16 --> Config Class Initialized
INFO - 2022-06-05 16:17:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:16 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:16 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:16 --> URI Class Initialized
INFO - 2022-06-05 16:17:16 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:16 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:16 --> URI Class Initialized
INFO - 2022-06-05 16:17:16 --> Router Class Initialized
INFO - 2022-06-05 16:17:16 --> Router Class Initialized
INFO - 2022-06-05 16:17:16 --> Output Class Initialized
INFO - 2022-06-05 16:17:16 --> Output Class Initialized
INFO - 2022-06-05 16:17:16 --> Router Class Initialized
INFO - 2022-06-05 16:17:16 --> Security Class Initialized
INFO - 2022-06-05 16:17:16 --> Security Class Initialized
INFO - 2022-06-05 16:17:16 --> Output Class Initialized
DEBUG - 2022-06-05 16:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:16 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:16 --> Input Class Initialized
INFO - 2022-06-05 16:17:16 --> Language Class Initialized
INFO - 2022-06-05 16:17:16 --> Language Class Initialized
INFO - 2022-06-05 16:17:16 --> Security Class Initialized
ERROR - 2022-06-05 16:17:16 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:17:16 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:16 --> Input Class Initialized
INFO - 2022-06-05 16:17:16 --> Language Class Initialized
ERROR - 2022-06-05 16:17:16 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Loader Class Initialized
INFO - 2022-06-05 16:17:24 --> Helper loaded: url_helper
INFO - 2022-06-05 16:17:24 --> Database Driver Class Initialized
INFO - 2022-06-05 16:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:17:24 --> Controller Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:17:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:17:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:17:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:17:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:17:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:17:24 --> Final output sent to browser
DEBUG - 2022-06-05 16:17:24 --> Total execution time: 0.0490
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:24 --> Config Class Initialized
INFO - 2022-06-05 16:17:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:24 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:24 --> URI Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Router Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
INFO - 2022-06-05 16:17:24 --> Output Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
INFO - 2022-06-05 16:17:24 --> Security Class Initialized
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
DEBUG - 2022-06-05 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:24 --> Input Class Initialized
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:24 --> Language Class Initialized
ERROR - 2022-06-05 16:17:24 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:26 --> Config Class Initialized
INFO - 2022-06-05 16:17:26 --> Config Class Initialized
INFO - 2022-06-05 16:17:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:26 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:26 --> Config Class Initialized
INFO - 2022-06-05 16:17:26 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:26 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:17:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:26 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:26 --> URI Class Initialized
INFO - 2022-06-05 16:17:26 --> URI Class Initialized
INFO - 2022-06-05 16:17:26 --> URI Class Initialized
INFO - 2022-06-05 16:17:26 --> Router Class Initialized
INFO - 2022-06-05 16:17:26 --> Router Class Initialized
INFO - 2022-06-05 16:17:26 --> Router Class Initialized
INFO - 2022-06-05 16:17:26 --> Output Class Initialized
INFO - 2022-06-05 16:17:26 --> Output Class Initialized
INFO - 2022-06-05 16:17:26 --> Security Class Initialized
INFO - 2022-06-05 16:17:26 --> Security Class Initialized
INFO - 2022-06-05 16:17:26 --> Output Class Initialized
DEBUG - 2022-06-05 16:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:26 --> Security Class Initialized
INFO - 2022-06-05 16:17:26 --> Input Class Initialized
INFO - 2022-06-05 16:17:26 --> Input Class Initialized
INFO - 2022-06-05 16:17:26 --> Language Class Initialized
INFO - 2022-06-05 16:17:26 --> Language Class Initialized
DEBUG - 2022-06-05 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:26 --> Input Class Initialized
ERROR - 2022-06-05 16:17:26 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:17:26 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:26 --> Language Class Initialized
ERROR - 2022-06-05 16:17:26 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Loader Class Initialized
INFO - 2022-06-05 16:17:35 --> Helper loaded: url_helper
INFO - 2022-06-05 16:17:35 --> Database Driver Class Initialized
INFO - 2022-06-05 16:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:17:35 --> Controller Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:17:35 --> Final output sent to browser
DEBUG - 2022-06-05 16:17:35 --> Total execution time: 0.1155
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
ERROR - 2022-06-05 16:17:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
ERROR - 2022-06-05 16:17:35 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
ERROR - 2022-06-05 16:17:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> Config Class Initialized
INFO - 2022-06-05 16:17:35 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
ERROR - 2022-06-05 16:17:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:35 --> URI Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
ERROR - 2022-06-05 16:17:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:35 --> Router Class Initialized
DEBUG - 2022-06-05 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:35 --> Input Class Initialized
INFO - 2022-06-05 16:17:35 --> Language Class Initialized
INFO - 2022-06-05 16:17:35 --> Output Class Initialized
ERROR - 2022-06-05 16:17:35 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:36 --> Input Class Initialized
INFO - 2022-06-05 16:17:36 --> Language Class Initialized
ERROR - 2022-06-05 16:17:36 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:37 --> Config Class Initialized
INFO - 2022-06-05 16:17:37 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:37 --> Config Class Initialized
INFO - 2022-06-05 16:17:37 --> Config Class Initialized
INFO - 2022-06-05 16:17:37 --> Hooks Class Initialized
INFO - 2022-06-05 16:17:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:17:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:37 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:17:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:17:37 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:37 --> Utf8 Class Initialized
INFO - 2022-06-05 16:17:37 --> URI Class Initialized
INFO - 2022-06-05 16:17:37 --> URI Class Initialized
INFO - 2022-06-05 16:17:37 --> URI Class Initialized
INFO - 2022-06-05 16:17:37 --> Router Class Initialized
INFO - 2022-06-05 16:17:37 --> Router Class Initialized
INFO - 2022-06-05 16:17:37 --> Router Class Initialized
INFO - 2022-06-05 16:17:37 --> Output Class Initialized
INFO - 2022-06-05 16:17:37 --> Output Class Initialized
INFO - 2022-06-05 16:17:37 --> Output Class Initialized
INFO - 2022-06-05 16:17:37 --> Security Class Initialized
INFO - 2022-06-05 16:17:37 --> Security Class Initialized
INFO - 2022-06-05 16:17:37 --> Security Class Initialized
DEBUG - 2022-06-05 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:37 --> Input Class Initialized
INFO - 2022-06-05 16:17:37 --> Language Class Initialized
DEBUG - 2022-06-05 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:37 --> Input Class Initialized
DEBUG - 2022-06-05 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:17:37 --> Input Class Initialized
INFO - 2022-06-05 16:17:37 --> Language Class Initialized
ERROR - 2022-06-05 16:17:37 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:17:37 --> Language Class Initialized
ERROR - 2022-06-05 16:17:37 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:17:37 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Loader Class Initialized
INFO - 2022-06-05 16:18:12 --> Helper loaded: url_helper
INFO - 2022-06-05 16:18:12 --> Database Driver Class Initialized
INFO - 2022-06-05 16:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:18:12 --> Controller Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:18:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:18:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:18:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:18:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:18:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:18:12 --> Final output sent to browser
DEBUG - 2022-06-05 16:18:12 --> Total execution time: 0.0505
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:12 --> Config Class Initialized
INFO - 2022-06-05 16:18:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
INFO - 2022-06-05 16:18:12 --> URI Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> Router Class Initialized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Output Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
INFO - 2022-06-05 16:18:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:12 --> Input Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
INFO - 2022-06-05 16:18:12 --> Language Class Initialized
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:13 --> Config Class Initialized
INFO - 2022-06-05 16:18:13 --> Config Class Initialized
INFO - 2022-06-05 16:18:13 --> Config Class Initialized
INFO - 2022-06-05 16:18:13 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:13 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:13 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:18:13 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:13 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:13 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:13 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:13 --> URI Class Initialized
INFO - 2022-06-05 16:18:13 --> URI Class Initialized
INFO - 2022-06-05 16:18:13 --> URI Class Initialized
INFO - 2022-06-05 16:18:13 --> Router Class Initialized
INFO - 2022-06-05 16:18:13 --> Router Class Initialized
INFO - 2022-06-05 16:18:13 --> Router Class Initialized
INFO - 2022-06-05 16:18:13 --> Output Class Initialized
INFO - 2022-06-05 16:18:13 --> Output Class Initialized
INFO - 2022-06-05 16:18:13 --> Output Class Initialized
INFO - 2022-06-05 16:18:13 --> Security Class Initialized
INFO - 2022-06-05 16:18:13 --> Security Class Initialized
INFO - 2022-06-05 16:18:13 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:13 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:13 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:13 --> Input Class Initialized
INFO - 2022-06-05 16:18:13 --> Language Class Initialized
INFO - 2022-06-05 16:18:13 --> Language Class Initialized
INFO - 2022-06-05 16:18:13 --> Language Class Initialized
ERROR - 2022-06-05 16:18:13 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:13 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:13 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Loader Class Initialized
INFO - 2022-06-05 16:18:27 --> Helper loaded: url_helper
INFO - 2022-06-05 16:18:27 --> Database Driver Class Initialized
INFO - 2022-06-05 16:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:18:27 --> Controller Class Initialized
DEBUG - 2022-06-05 16:18:27 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:18:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:18:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:18:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:18:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:18:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:18:27 --> Final output sent to browser
DEBUG - 2022-06-05 16:18:27 --> Total execution time: 0.1160
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Config Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:27 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
INFO - 2022-06-05 16:18:27 --> URI Class Initialized
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Router Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Output Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
INFO - 2022-06-05 16:18:27 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Input Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
INFO - 2022-06-05 16:18:27 --> Language Class Initialized
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:27 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:29 --> Config Class Initialized
INFO - 2022-06-05 16:18:29 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:29 --> Config Class Initialized
INFO - 2022-06-05 16:18:29 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:29 --> Config Class Initialized
INFO - 2022-06-05 16:18:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:29 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:29 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:29 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:29 --> URI Class Initialized
INFO - 2022-06-05 16:18:29 --> URI Class Initialized
INFO - 2022-06-05 16:18:29 --> URI Class Initialized
INFO - 2022-06-05 16:18:29 --> Router Class Initialized
INFO - 2022-06-05 16:18:29 --> Router Class Initialized
INFO - 2022-06-05 16:18:29 --> Router Class Initialized
INFO - 2022-06-05 16:18:29 --> Output Class Initialized
INFO - 2022-06-05 16:18:29 --> Output Class Initialized
INFO - 2022-06-05 16:18:29 --> Output Class Initialized
INFO - 2022-06-05 16:18:29 --> Security Class Initialized
INFO - 2022-06-05 16:18:29 --> Security Class Initialized
INFO - 2022-06-05 16:18:29 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:29 --> Input Class Initialized
INFO - 2022-06-05 16:18:29 --> Language Class Initialized
DEBUG - 2022-06-05 16:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:29 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:29 --> Input Class Initialized
ERROR - 2022-06-05 16:18:29 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:29 --> Language Class Initialized
INFO - 2022-06-05 16:18:29 --> Language Class Initialized
ERROR - 2022-06-05 16:18:29 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:29 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Loader Class Initialized
INFO - 2022-06-05 16:18:38 --> Helper loaded: url_helper
INFO - 2022-06-05 16:18:38 --> Database Driver Class Initialized
INFO - 2022-06-05 16:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:18:38 --> Controller Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:18:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:18:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:18:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:18:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:18:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:18:38 --> Final output sent to browser
DEBUG - 2022-06-05 16:18:38 --> Total execution time: 0.1228
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> Config Class Initialized
INFO - 2022-06-05 16:18:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:38 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
INFO - 2022-06-05 16:18:38 --> URI Class Initialized
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
INFO - 2022-06-05 16:18:38 --> Router Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
INFO - 2022-06-05 16:18:38 --> Output Class Initialized
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:38 --> Input Class Initialized
INFO - 2022-06-05 16:18:38 --> Language Class Initialized
ERROR - 2022-06-05 16:18:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:18:40 --> Config Class Initialized
INFO - 2022-06-05 16:18:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:40 --> Config Class Initialized
INFO - 2022-06-05 16:18:40 --> Hooks Class Initialized
INFO - 2022-06-05 16:18:40 --> Config Class Initialized
INFO - 2022-06-05 16:18:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:18:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:40 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:18:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:18:40 --> URI Class Initialized
INFO - 2022-06-05 16:18:40 --> Utf8 Class Initialized
INFO - 2022-06-05 16:18:40 --> URI Class Initialized
INFO - 2022-06-05 16:18:40 --> URI Class Initialized
INFO - 2022-06-05 16:18:40 --> Router Class Initialized
INFO - 2022-06-05 16:18:40 --> Router Class Initialized
INFO - 2022-06-05 16:18:40 --> Router Class Initialized
INFO - 2022-06-05 16:18:40 --> Output Class Initialized
INFO - 2022-06-05 16:18:40 --> Output Class Initialized
INFO - 2022-06-05 16:18:40 --> Output Class Initialized
INFO - 2022-06-05 16:18:40 --> Security Class Initialized
INFO - 2022-06-05 16:18:40 --> Security Class Initialized
INFO - 2022-06-05 16:18:40 --> Security Class Initialized
DEBUG - 2022-06-05 16:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:40 --> Input Class Initialized
INFO - 2022-06-05 16:18:40 --> Input Class Initialized
DEBUG - 2022-06-05 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:18:40 --> Input Class Initialized
INFO - 2022-06-05 16:18:40 --> Language Class Initialized
INFO - 2022-06-05 16:18:40 --> Language Class Initialized
INFO - 2022-06-05 16:18:40 --> Language Class Initialized
ERROR - 2022-06-05 16:18:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:40 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:18:40 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Loader Class Initialized
INFO - 2022-06-05 16:19:12 --> Helper loaded: url_helper
INFO - 2022-06-05 16:19:12 --> Database Driver Class Initialized
INFO - 2022-06-05 16:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:19:12 --> Controller Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:19:12 --> Final output sent to browser
DEBUG - 2022-06-05 16:19:12 --> Total execution time: 0.0424
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Config Class Initialized
INFO - 2022-06-05 16:19:12 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
DEBUG - 2022-06-05 16:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
INFO - 2022-06-05 16:19:12 --> URI Class Initialized
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:12 --> Router Class Initialized
INFO - 2022-06-05 16:19:12 --> Output Class Initialized
INFO - 2022-06-05 16:19:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:12 --> Input Class Initialized
INFO - 2022-06-05 16:19:12 --> Language Class Initialized
ERROR - 2022-06-05 16:19:12 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:14 --> Config Class Initialized
INFO - 2022-06-05 16:19:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:14 --> Config Class Initialized
INFO - 2022-06-05 16:19:14 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:14 --> Config Class Initialized
INFO - 2022-06-05 16:19:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:14 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:14 --> URI Class Initialized
INFO - 2022-06-05 16:19:14 --> URI Class Initialized
DEBUG - 2022-06-05 16:19:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:14 --> URI Class Initialized
INFO - 2022-06-05 16:19:14 --> Router Class Initialized
INFO - 2022-06-05 16:19:14 --> Router Class Initialized
INFO - 2022-06-05 16:19:14 --> Output Class Initialized
INFO - 2022-06-05 16:19:14 --> Router Class Initialized
INFO - 2022-06-05 16:19:14 --> Security Class Initialized
INFO - 2022-06-05 16:19:14 --> Output Class Initialized
INFO - 2022-06-05 16:19:14 --> Output Class Initialized
DEBUG - 2022-06-05 16:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:14 --> Security Class Initialized
INFO - 2022-06-05 16:19:14 --> Input Class Initialized
INFO - 2022-06-05 16:19:14 --> Security Class Initialized
INFO - 2022-06-05 16:19:14 --> Language Class Initialized
DEBUG - 2022-06-05 16:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:14 --> Input Class Initialized
DEBUG - 2022-06-05 16:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:14 --> Input Class Initialized
INFO - 2022-06-05 16:19:14 --> Language Class Initialized
ERROR - 2022-06-05 16:19:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:14 --> Language Class Initialized
ERROR - 2022-06-05 16:19:14 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:14 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:33 --> Config Class Initialized
INFO - 2022-06-05 16:19:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:33 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:33 --> URI Class Initialized
INFO - 2022-06-05 16:19:33 --> Router Class Initialized
INFO - 2022-06-05 16:19:33 --> Output Class Initialized
INFO - 2022-06-05 16:19:33 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:33 --> Input Class Initialized
INFO - 2022-06-05 16:19:33 --> Language Class Initialized
INFO - 2022-06-05 16:19:33 --> Language Class Initialized
INFO - 2022-06-05 16:19:33 --> Config Class Initialized
INFO - 2022-06-05 16:19:33 --> Loader Class Initialized
INFO - 2022-06-05 16:19:33 --> Helper loaded: url_helper
INFO - 2022-06-05 16:19:33 --> Database Driver Class Initialized
INFO - 2022-06-05 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:19:33 --> Controller Class Initialized
DEBUG - 2022-06-05 16:19:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:19:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:19:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:19:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:19:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:19:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:19:33 --> Final output sent to browser
DEBUG - 2022-06-05 16:19:33 --> Total execution time: 0.0518
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Loader Class Initialized
INFO - 2022-06-05 16:19:38 --> Helper loaded: url_helper
INFO - 2022-06-05 16:19:38 --> Database Driver Class Initialized
INFO - 2022-06-05 16:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:19:38 --> Controller Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:19:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:19:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:19:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:19:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:19:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:19:38 --> Final output sent to browser
DEBUG - 2022-06-05 16:19:38 --> Total execution time: 0.0529
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:38 --> Config Class Initialized
INFO - 2022-06-05 16:19:38 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:19:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:38 --> URI Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:38 --> Router Class Initialized
INFO - 2022-06-05 16:19:38 --> Output Class Initialized
INFO - 2022-06-05 16:19:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:38 --> Input Class Initialized
INFO - 2022-06-05 16:19:38 --> Language Class Initialized
ERROR - 2022-06-05 16:19:38 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:39 --> Config Class Initialized
INFO - 2022-06-05 16:19:39 --> Config Class Initialized
INFO - 2022-06-05 16:19:39 --> Config Class Initialized
INFO - 2022-06-05 16:19:39 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:39 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-05 16:19:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:39 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:39 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:39 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:39 --> URI Class Initialized
INFO - 2022-06-05 16:19:39 --> URI Class Initialized
INFO - 2022-06-05 16:19:39 --> URI Class Initialized
INFO - 2022-06-05 16:19:39 --> Router Class Initialized
INFO - 2022-06-05 16:19:39 --> Router Class Initialized
INFO - 2022-06-05 16:19:39 --> Router Class Initialized
INFO - 2022-06-05 16:19:39 --> Output Class Initialized
INFO - 2022-06-05 16:19:39 --> Output Class Initialized
INFO - 2022-06-05 16:19:39 --> Output Class Initialized
INFO - 2022-06-05 16:19:39 --> Security Class Initialized
INFO - 2022-06-05 16:19:39 --> Security Class Initialized
INFO - 2022-06-05 16:19:39 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:39 --> Input Class Initialized
DEBUG - 2022-06-05 16:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:39 --> Input Class Initialized
INFO - 2022-06-05 16:19:39 --> Input Class Initialized
INFO - 2022-06-05 16:19:39 --> Language Class Initialized
INFO - 2022-06-05 16:19:39 --> Language Class Initialized
INFO - 2022-06-05 16:19:39 --> Language Class Initialized
ERROR - 2022-06-05 16:19:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:39 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:39 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:19:52 --> Config Class Initialized
INFO - 2022-06-05 16:19:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:52 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:52 --> URI Class Initialized
INFO - 2022-06-05 16:19:52 --> Router Class Initialized
INFO - 2022-06-05 16:19:52 --> Output Class Initialized
INFO - 2022-06-05 16:19:52 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:52 --> Input Class Initialized
INFO - 2022-06-05 16:19:52 --> Language Class Initialized
INFO - 2022-06-05 16:19:52 --> Language Class Initialized
INFO - 2022-06-05 16:19:52 --> Config Class Initialized
INFO - 2022-06-05 16:19:52 --> Loader Class Initialized
INFO - 2022-06-05 16:19:52 --> Helper loaded: url_helper
INFO - 2022-06-05 16:19:52 --> Database Driver Class Initialized
INFO - 2022-06-05 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:19:52 --> Controller Class Initialized
DEBUG - 2022-06-05 16:19:52 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:19:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:19:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:19:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:19:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:19:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:19:52 --> Final output sent to browser
DEBUG - 2022-06-05 16:19:52 --> Total execution time: 0.0525
INFO - 2022-06-05 16:19:52 --> Config Class Initialized
INFO - 2022-06-05 16:19:52 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:52 --> Config Class Initialized
INFO - 2022-06-05 16:19:52 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:52 --> Config Class Initialized
INFO - 2022-06-05 16:19:52 --> Hooks Class Initialized
INFO - 2022-06-05 16:19:52 --> Config Class Initialized
INFO - 2022-06-05 16:19:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:19:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:52 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:52 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:19:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:52 --> URI Class Initialized
INFO - 2022-06-05 16:19:52 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:52 --> URI Class Initialized
DEBUG - 2022-06-05 16:19:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:19:52 --> Utf8 Class Initialized
INFO - 2022-06-05 16:19:52 --> URI Class Initialized
INFO - 2022-06-05 16:19:52 --> URI Class Initialized
INFO - 2022-06-05 16:19:52 --> Router Class Initialized
INFO - 2022-06-05 16:19:52 --> Router Class Initialized
INFO - 2022-06-05 16:19:52 --> Router Class Initialized
INFO - 2022-06-05 16:19:52 --> Router Class Initialized
INFO - 2022-06-05 16:19:52 --> Output Class Initialized
INFO - 2022-06-05 16:19:52 --> Output Class Initialized
INFO - 2022-06-05 16:19:52 --> Output Class Initialized
INFO - 2022-06-05 16:19:52 --> Output Class Initialized
INFO - 2022-06-05 16:19:52 --> Security Class Initialized
INFO - 2022-06-05 16:19:52 --> Security Class Initialized
INFO - 2022-06-05 16:19:52 --> Security Class Initialized
INFO - 2022-06-05 16:19:52 --> Security Class Initialized
DEBUG - 2022-06-05 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:52 --> Input Class Initialized
DEBUG - 2022-06-05 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:52 --> Input Class Initialized
DEBUG - 2022-06-05 16:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:19:52 --> Language Class Initialized
INFO - 2022-06-05 16:19:52 --> Input Class Initialized
INFO - 2022-06-05 16:19:52 --> Input Class Initialized
INFO - 2022-06-05 16:19:52 --> Language Class Initialized
INFO - 2022-06-05 16:19:52 --> Language Class Initialized
INFO - 2022-06-05 16:19:52 --> Language Class Initialized
ERROR - 2022-06-05 16:19:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:52 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:19:52 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:20:01 --> Config Class Initialized
INFO - 2022-06-05 16:20:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:20:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:20:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:20:01 --> URI Class Initialized
INFO - 2022-06-05 16:20:01 --> Router Class Initialized
INFO - 2022-06-05 16:20:01 --> Output Class Initialized
INFO - 2022-06-05 16:20:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:20:01 --> Input Class Initialized
INFO - 2022-06-05 16:20:01 --> Language Class Initialized
INFO - 2022-06-05 16:20:01 --> Language Class Initialized
INFO - 2022-06-05 16:20:01 --> Config Class Initialized
INFO - 2022-06-05 16:20:01 --> Loader Class Initialized
INFO - 2022-06-05 16:20:01 --> Helper loaded: url_helper
INFO - 2022-06-05 16:20:01 --> Database Driver Class Initialized
INFO - 2022-06-05 16:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:20:01 --> Controller Class Initialized
DEBUG - 2022-06-05 16:20:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:20:01 --> Final output sent to browser
DEBUG - 2022-06-05 16:20:01 --> Total execution time: 0.0510
INFO - 2022-06-05 16:20:01 --> Config Class Initialized
INFO - 2022-06-05 16:20:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:20:01 --> Config Class Initialized
INFO - 2022-06-05 16:20:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:20:01 --> Config Class Initialized
INFO - 2022-06-05 16:20:01 --> Hooks Class Initialized
INFO - 2022-06-05 16:20:01 --> Config Class Initialized
INFO - 2022-06-05 16:20:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:20:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:20:01 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:20:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:20:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:20:01 --> URI Class Initialized
DEBUG - 2022-06-05 16:20:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:20:01 --> Utf8 Class Initialized
DEBUG - 2022-06-05 16:20:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:20:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:20:01 --> URI Class Initialized
INFO - 2022-06-05 16:20:01 --> URI Class Initialized
INFO - 2022-06-05 16:20:01 --> URI Class Initialized
INFO - 2022-06-05 16:20:01 --> Router Class Initialized
INFO - 2022-06-05 16:20:01 --> Router Class Initialized
INFO - 2022-06-05 16:20:01 --> Router Class Initialized
INFO - 2022-06-05 16:20:01 --> Output Class Initialized
INFO - 2022-06-05 16:20:01 --> Router Class Initialized
INFO - 2022-06-05 16:20:01 --> Output Class Initialized
INFO - 2022-06-05 16:20:01 --> Output Class Initialized
INFO - 2022-06-05 16:20:01 --> Security Class Initialized
INFO - 2022-06-05 16:20:01 --> Security Class Initialized
INFO - 2022-06-05 16:20:01 --> Output Class Initialized
INFO - 2022-06-05 16:20:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:20:01 --> Input Class Initialized
DEBUG - 2022-06-05 16:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-05 16:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:20:01 --> Input Class Initialized
INFO - 2022-06-05 16:20:01 --> Language Class Initialized
INFO - 2022-06-05 16:20:01 --> Security Class Initialized
INFO - 2022-06-05 16:20:01 --> Input Class Initialized
INFO - 2022-06-05 16:20:01 --> Language Class Initialized
INFO - 2022-06-05 16:20:01 --> Language Class Initialized
DEBUG - 2022-06-05 16:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:20:01 --> Input Class Initialized
ERROR - 2022-06-05 16:20:01 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:20:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:20:01 --> Language Class Initialized
ERROR - 2022-06-05 16:20:01 --> 404 Page Not Found: /index
ERROR - 2022-06-05 16:20:01 --> 404 Page Not Found: /index
INFO - 2022-06-05 16:20:18 --> Config Class Initialized
INFO - 2022-06-05 16:20:18 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:20:18 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:20:18 --> Utf8 Class Initialized
INFO - 2022-06-05 16:20:18 --> URI Class Initialized
INFO - 2022-06-05 16:20:18 --> Router Class Initialized
INFO - 2022-06-05 16:20:18 --> Output Class Initialized
INFO - 2022-06-05 16:20:18 --> Security Class Initialized
DEBUG - 2022-06-05 16:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:20:18 --> Input Class Initialized
INFO - 2022-06-05 16:20:18 --> Language Class Initialized
INFO - 2022-06-05 16:20:18 --> Language Class Initialized
INFO - 2022-06-05 16:20:18 --> Config Class Initialized
INFO - 2022-06-05 16:20:18 --> Loader Class Initialized
INFO - 2022-06-05 16:20:18 --> Helper loaded: url_helper
INFO - 2022-06-05 16:20:18 --> Database Driver Class Initialized
INFO - 2022-06-05 16:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:20:18 --> Controller Class Initialized
DEBUG - 2022-06-05 16:20:18 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:20:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:20:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:20:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:20:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:20:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:20:18 --> Final output sent to browser
DEBUG - 2022-06-05 16:20:18 --> Total execution time: 0.0568
INFO - 2022-06-05 16:21:12 --> Config Class Initialized
INFO - 2022-06-05 16:21:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:21:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:21:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:21:12 --> URI Class Initialized
INFO - 2022-06-05 16:21:12 --> Router Class Initialized
INFO - 2022-06-05 16:21:12 --> Output Class Initialized
INFO - 2022-06-05 16:21:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:21:12 --> Input Class Initialized
INFO - 2022-06-05 16:21:12 --> Language Class Initialized
INFO - 2022-06-05 16:21:12 --> Language Class Initialized
INFO - 2022-06-05 16:21:12 --> Config Class Initialized
INFO - 2022-06-05 16:21:12 --> Loader Class Initialized
INFO - 2022-06-05 16:21:12 --> Helper loaded: url_helper
INFO - 2022-06-05 16:21:12 --> Database Driver Class Initialized
INFO - 2022-06-05 16:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:21:12 --> Controller Class Initialized
DEBUG - 2022-06-05 16:21:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:21:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:21:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:21:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:21:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/dashboard.php
DEBUG - 2022-06-05 16:21:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:21:12 --> Final output sent to browser
DEBUG - 2022-06-05 16:21:12 --> Total execution time: 0.0812
INFO - 2022-06-05 16:21:15 --> Config Class Initialized
INFO - 2022-06-05 16:21:15 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:21:15 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:21:15 --> Utf8 Class Initialized
INFO - 2022-06-05 16:21:15 --> URI Class Initialized
INFO - 2022-06-05 16:21:15 --> Router Class Initialized
INFO - 2022-06-05 16:21:15 --> Output Class Initialized
INFO - 2022-06-05 16:21:15 --> Security Class Initialized
DEBUG - 2022-06-05 16:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:21:15 --> Input Class Initialized
INFO - 2022-06-05 16:21:15 --> Language Class Initialized
INFO - 2022-06-05 16:21:15 --> Language Class Initialized
INFO - 2022-06-05 16:21:15 --> Config Class Initialized
INFO - 2022-06-05 16:21:15 --> Loader Class Initialized
INFO - 2022-06-05 16:21:15 --> Helper loaded: url_helper
INFO - 2022-06-05 16:21:15 --> Database Driver Class Initialized
INFO - 2022-06-05 16:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:21:15 --> Controller Class Initialized
DEBUG - 2022-06-05 16:21:15 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:21:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:21:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:21:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:21:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:21:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:21:15 --> Final output sent to browser
DEBUG - 2022-06-05 16:21:15 --> Total execution time: 0.0622
INFO - 2022-06-05 16:24:32 --> Config Class Initialized
INFO - 2022-06-05 16:24:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:24:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:24:32 --> Utf8 Class Initialized
INFO - 2022-06-05 16:24:32 --> URI Class Initialized
INFO - 2022-06-05 16:24:32 --> Router Class Initialized
INFO - 2022-06-05 16:24:32 --> Output Class Initialized
INFO - 2022-06-05 16:24:32 --> Security Class Initialized
DEBUG - 2022-06-05 16:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:24:32 --> Input Class Initialized
INFO - 2022-06-05 16:24:32 --> Language Class Initialized
INFO - 2022-06-05 16:24:32 --> Language Class Initialized
INFO - 2022-06-05 16:24:32 --> Config Class Initialized
INFO - 2022-06-05 16:24:32 --> Loader Class Initialized
INFO - 2022-06-05 16:24:32 --> Helper loaded: url_helper
INFO - 2022-06-05 16:24:32 --> Database Driver Class Initialized
INFO - 2022-06-05 16:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:24:32 --> Controller Class Initialized
DEBUG - 2022-06-05 16:24:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:24:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:24:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:24:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:24:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:24:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:24:33 --> Final output sent to browser
DEBUG - 2022-06-05 16:24:33 --> Total execution time: 0.0522
INFO - 2022-06-05 16:25:55 --> Config Class Initialized
INFO - 2022-06-05 16:25:55 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:25:55 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:25:55 --> Utf8 Class Initialized
INFO - 2022-06-05 16:25:55 --> URI Class Initialized
INFO - 2022-06-05 16:25:55 --> Router Class Initialized
INFO - 2022-06-05 16:25:55 --> Output Class Initialized
INFO - 2022-06-05 16:25:55 --> Security Class Initialized
DEBUG - 2022-06-05 16:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:25:55 --> Input Class Initialized
INFO - 2022-06-05 16:25:55 --> Language Class Initialized
INFO - 2022-06-05 16:25:55 --> Language Class Initialized
INFO - 2022-06-05 16:25:55 --> Config Class Initialized
INFO - 2022-06-05 16:25:55 --> Loader Class Initialized
INFO - 2022-06-05 16:25:55 --> Helper loaded: url_helper
INFO - 2022-06-05 16:25:55 --> Database Driver Class Initialized
INFO - 2022-06-05 16:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:25:55 --> Controller Class Initialized
DEBUG - 2022-06-05 16:25:55 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:25:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:25:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:25:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:25:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:25:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:25:55 --> Final output sent to browser
DEBUG - 2022-06-05 16:25:55 --> Total execution time: 0.0557
INFO - 2022-06-05 16:27:03 --> Config Class Initialized
INFO - 2022-06-05 16:27:03 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:27:03 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:27:03 --> Utf8 Class Initialized
INFO - 2022-06-05 16:27:03 --> URI Class Initialized
INFO - 2022-06-05 16:27:03 --> Router Class Initialized
INFO - 2022-06-05 16:27:03 --> Output Class Initialized
INFO - 2022-06-05 16:27:03 --> Security Class Initialized
DEBUG - 2022-06-05 16:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:27:03 --> Input Class Initialized
INFO - 2022-06-05 16:27:03 --> Language Class Initialized
INFO - 2022-06-05 16:27:03 --> Language Class Initialized
INFO - 2022-06-05 16:27:03 --> Config Class Initialized
INFO - 2022-06-05 16:27:03 --> Loader Class Initialized
INFO - 2022-06-05 16:27:03 --> Helper loaded: url_helper
INFO - 2022-06-05 16:27:03 --> Database Driver Class Initialized
INFO - 2022-06-05 16:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:27:03 --> Controller Class Initialized
DEBUG - 2022-06-05 16:27:03 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:27:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:27:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:27:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:27:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:27:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:27:03 --> Final output sent to browser
DEBUG - 2022-06-05 16:27:03 --> Total execution time: 0.0534
INFO - 2022-06-05 16:27:14 --> Config Class Initialized
INFO - 2022-06-05 16:27:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:27:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:27:14 --> Utf8 Class Initialized
INFO - 2022-06-05 16:27:14 --> URI Class Initialized
INFO - 2022-06-05 16:27:14 --> Router Class Initialized
INFO - 2022-06-05 16:27:14 --> Output Class Initialized
INFO - 2022-06-05 16:27:14 --> Security Class Initialized
DEBUG - 2022-06-05 16:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:27:14 --> Input Class Initialized
INFO - 2022-06-05 16:27:14 --> Language Class Initialized
INFO - 2022-06-05 16:27:14 --> Language Class Initialized
INFO - 2022-06-05 16:27:14 --> Config Class Initialized
INFO - 2022-06-05 16:27:14 --> Loader Class Initialized
INFO - 2022-06-05 16:27:14 --> Helper loaded: url_helper
INFO - 2022-06-05 16:27:14 --> Database Driver Class Initialized
INFO - 2022-06-05 16:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:27:14 --> Controller Class Initialized
DEBUG - 2022-06-05 16:27:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:27:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:27:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:27:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:27:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:27:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:27:14 --> Final output sent to browser
DEBUG - 2022-06-05 16:27:14 --> Total execution time: 0.0479
INFO - 2022-06-05 16:27:35 --> Config Class Initialized
INFO - 2022-06-05 16:27:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:27:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:27:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:27:35 --> URI Class Initialized
INFO - 2022-06-05 16:27:35 --> Router Class Initialized
INFO - 2022-06-05 16:27:35 --> Output Class Initialized
INFO - 2022-06-05 16:27:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:27:35 --> Input Class Initialized
INFO - 2022-06-05 16:27:35 --> Language Class Initialized
INFO - 2022-06-05 16:27:35 --> Language Class Initialized
INFO - 2022-06-05 16:27:35 --> Config Class Initialized
INFO - 2022-06-05 16:27:35 --> Loader Class Initialized
INFO - 2022-06-05 16:27:35 --> Helper loaded: url_helper
INFO - 2022-06-05 16:27:35 --> Database Driver Class Initialized
INFO - 2022-06-05 16:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:27:35 --> Controller Class Initialized
DEBUG - 2022-06-05 16:27:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:27:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:27:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:27:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:27:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:27:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:27:35 --> Final output sent to browser
DEBUG - 2022-06-05 16:27:35 --> Total execution time: 0.0471
INFO - 2022-06-05 16:28:11 --> Config Class Initialized
INFO - 2022-06-05 16:28:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:28:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:28:11 --> Utf8 Class Initialized
INFO - 2022-06-05 16:28:11 --> URI Class Initialized
INFO - 2022-06-05 16:28:11 --> Router Class Initialized
INFO - 2022-06-05 16:28:11 --> Output Class Initialized
INFO - 2022-06-05 16:28:11 --> Security Class Initialized
DEBUG - 2022-06-05 16:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:28:11 --> Input Class Initialized
INFO - 2022-06-05 16:28:11 --> Language Class Initialized
INFO - 2022-06-05 16:28:11 --> Language Class Initialized
INFO - 2022-06-05 16:28:11 --> Config Class Initialized
INFO - 2022-06-05 16:28:11 --> Loader Class Initialized
INFO - 2022-06-05 16:28:11 --> Helper loaded: url_helper
INFO - 2022-06-05 16:28:11 --> Database Driver Class Initialized
INFO - 2022-06-05 16:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:28:11 --> Controller Class Initialized
DEBUG - 2022-06-05 16:28:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:28:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:28:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:28:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:28:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:28:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:28:11 --> Final output sent to browser
DEBUG - 2022-06-05 16:28:11 --> Total execution time: 0.0474
INFO - 2022-06-05 16:28:17 --> Config Class Initialized
INFO - 2022-06-05 16:28:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:28:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:28:17 --> Utf8 Class Initialized
INFO - 2022-06-05 16:28:17 --> URI Class Initialized
INFO - 2022-06-05 16:28:17 --> Router Class Initialized
INFO - 2022-06-05 16:28:17 --> Output Class Initialized
INFO - 2022-06-05 16:28:17 --> Security Class Initialized
DEBUG - 2022-06-05 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:28:17 --> Input Class Initialized
INFO - 2022-06-05 16:28:17 --> Language Class Initialized
INFO - 2022-06-05 16:28:17 --> Language Class Initialized
INFO - 2022-06-05 16:28:17 --> Config Class Initialized
INFO - 2022-06-05 16:28:17 --> Loader Class Initialized
INFO - 2022-06-05 16:28:17 --> Helper loaded: url_helper
INFO - 2022-06-05 16:28:17 --> Database Driver Class Initialized
INFO - 2022-06-05 16:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:28:17 --> Controller Class Initialized
DEBUG - 2022-06-05 16:28:17 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:28:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:28:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:28:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:28:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:28:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:28:17 --> Final output sent to browser
DEBUG - 2022-06-05 16:28:17 --> Total execution time: 0.0578
INFO - 2022-06-05 16:28:21 --> Config Class Initialized
INFO - 2022-06-05 16:28:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:28:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:28:21 --> Utf8 Class Initialized
INFO - 2022-06-05 16:28:21 --> URI Class Initialized
INFO - 2022-06-05 16:28:21 --> Router Class Initialized
INFO - 2022-06-05 16:28:21 --> Output Class Initialized
INFO - 2022-06-05 16:28:21 --> Security Class Initialized
DEBUG - 2022-06-05 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:28:21 --> Input Class Initialized
INFO - 2022-06-05 16:28:21 --> Language Class Initialized
INFO - 2022-06-05 16:28:21 --> Language Class Initialized
INFO - 2022-06-05 16:28:21 --> Config Class Initialized
INFO - 2022-06-05 16:28:21 --> Loader Class Initialized
INFO - 2022-06-05 16:28:21 --> Helper loaded: url_helper
INFO - 2022-06-05 16:28:22 --> Database Driver Class Initialized
INFO - 2022-06-05 16:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:28:22 --> Controller Class Initialized
DEBUG - 2022-06-05 16:28:22 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:28:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:28:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:28:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:28:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:28:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:28:22 --> Final output sent to browser
DEBUG - 2022-06-05 16:28:22 --> Total execution time: 0.0680
INFO - 2022-06-05 16:28:33 --> Config Class Initialized
INFO - 2022-06-05 16:28:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:28:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:28:33 --> Utf8 Class Initialized
INFO - 2022-06-05 16:28:33 --> URI Class Initialized
INFO - 2022-06-05 16:28:33 --> Router Class Initialized
INFO - 2022-06-05 16:28:33 --> Output Class Initialized
INFO - 2022-06-05 16:28:33 --> Security Class Initialized
DEBUG - 2022-06-05 16:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:28:33 --> Input Class Initialized
INFO - 2022-06-05 16:28:33 --> Language Class Initialized
INFO - 2022-06-05 16:28:33 --> Language Class Initialized
INFO - 2022-06-05 16:28:33 --> Config Class Initialized
INFO - 2022-06-05 16:28:33 --> Loader Class Initialized
INFO - 2022-06-05 16:28:33 --> Helper loaded: url_helper
INFO - 2022-06-05 16:28:33 --> Database Driver Class Initialized
INFO - 2022-06-05 16:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:28:33 --> Controller Class Initialized
DEBUG - 2022-06-05 16:28:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:28:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:28:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:28:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:28:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:28:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:28:33 --> Final output sent to browser
DEBUG - 2022-06-05 16:28:33 --> Total execution time: 0.0517
INFO - 2022-06-05 16:29:51 --> Config Class Initialized
INFO - 2022-06-05 16:29:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:29:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:29:51 --> Utf8 Class Initialized
INFO - 2022-06-05 16:29:51 --> URI Class Initialized
INFO - 2022-06-05 16:29:51 --> Router Class Initialized
INFO - 2022-06-05 16:29:51 --> Output Class Initialized
INFO - 2022-06-05 16:29:51 --> Security Class Initialized
DEBUG - 2022-06-05 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:29:51 --> Input Class Initialized
INFO - 2022-06-05 16:29:51 --> Language Class Initialized
INFO - 2022-06-05 16:29:51 --> Language Class Initialized
INFO - 2022-06-05 16:29:51 --> Config Class Initialized
INFO - 2022-06-05 16:29:51 --> Loader Class Initialized
INFO - 2022-06-05 16:29:51 --> Helper loaded: url_helper
INFO - 2022-06-05 16:29:51 --> Database Driver Class Initialized
INFO - 2022-06-05 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:29:51 --> Controller Class Initialized
DEBUG - 2022-06-05 16:29:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:29:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:29:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:29:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:29:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:29:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:29:51 --> Final output sent to browser
DEBUG - 2022-06-05 16:29:51 --> Total execution time: 0.0493
INFO - 2022-06-05 16:30:38 --> Config Class Initialized
INFO - 2022-06-05 16:30:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:30:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:30:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:30:38 --> URI Class Initialized
INFO - 2022-06-05 16:30:38 --> Router Class Initialized
INFO - 2022-06-05 16:30:38 --> Output Class Initialized
INFO - 2022-06-05 16:30:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:30:38 --> Input Class Initialized
INFO - 2022-06-05 16:30:38 --> Language Class Initialized
INFO - 2022-06-05 16:30:38 --> Language Class Initialized
INFO - 2022-06-05 16:30:38 --> Config Class Initialized
INFO - 2022-06-05 16:30:38 --> Loader Class Initialized
INFO - 2022-06-05 16:30:38 --> Helper loaded: url_helper
INFO - 2022-06-05 16:30:38 --> Database Driver Class Initialized
INFO - 2022-06-05 16:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:30:38 --> Controller Class Initialized
DEBUG - 2022-06-05 16:30:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:30:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:30:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:30:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:30:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:30:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:30:38 --> Final output sent to browser
DEBUG - 2022-06-05 16:30:38 --> Total execution time: 0.0479
INFO - 2022-06-05 16:31:02 --> Config Class Initialized
INFO - 2022-06-05 16:31:02 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:31:02 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:31:02 --> Utf8 Class Initialized
INFO - 2022-06-05 16:31:02 --> URI Class Initialized
INFO - 2022-06-05 16:31:02 --> Router Class Initialized
INFO - 2022-06-05 16:31:02 --> Output Class Initialized
INFO - 2022-06-05 16:31:02 --> Security Class Initialized
DEBUG - 2022-06-05 16:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:31:02 --> Input Class Initialized
INFO - 2022-06-05 16:31:02 --> Language Class Initialized
INFO - 2022-06-05 16:31:02 --> Language Class Initialized
INFO - 2022-06-05 16:31:02 --> Config Class Initialized
INFO - 2022-06-05 16:31:02 --> Loader Class Initialized
INFO - 2022-06-05 16:31:02 --> Helper loaded: url_helper
INFO - 2022-06-05 16:31:02 --> Database Driver Class Initialized
INFO - 2022-06-05 16:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:31:02 --> Controller Class Initialized
DEBUG - 2022-06-05 16:31:02 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:31:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:31:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:31:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:31:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:31:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:31:02 --> Final output sent to browser
DEBUG - 2022-06-05 16:31:02 --> Total execution time: 0.0493
INFO - 2022-06-05 16:31:11 --> Config Class Initialized
INFO - 2022-06-05 16:31:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:31:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:31:11 --> Utf8 Class Initialized
INFO - 2022-06-05 16:31:11 --> URI Class Initialized
INFO - 2022-06-05 16:31:11 --> Router Class Initialized
INFO - 2022-06-05 16:31:11 --> Output Class Initialized
INFO - 2022-06-05 16:31:11 --> Security Class Initialized
DEBUG - 2022-06-05 16:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:31:11 --> Input Class Initialized
INFO - 2022-06-05 16:31:11 --> Language Class Initialized
INFO - 2022-06-05 16:31:11 --> Language Class Initialized
INFO - 2022-06-05 16:31:11 --> Config Class Initialized
INFO - 2022-06-05 16:31:11 --> Loader Class Initialized
INFO - 2022-06-05 16:31:11 --> Helper loaded: url_helper
INFO - 2022-06-05 16:31:11 --> Database Driver Class Initialized
INFO - 2022-06-05 16:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:31:11 --> Controller Class Initialized
DEBUG - 2022-06-05 16:31:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:31:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:31:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:31:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:31:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:31:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:31:11 --> Final output sent to browser
DEBUG - 2022-06-05 16:31:11 --> Total execution time: 0.0487
INFO - 2022-06-05 16:31:28 --> Config Class Initialized
INFO - 2022-06-05 16:31:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:31:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:31:28 --> Utf8 Class Initialized
INFO - 2022-06-05 16:31:28 --> URI Class Initialized
INFO - 2022-06-05 16:31:28 --> Router Class Initialized
INFO - 2022-06-05 16:31:28 --> Output Class Initialized
INFO - 2022-06-05 16:31:28 --> Security Class Initialized
DEBUG - 2022-06-05 16:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:31:28 --> Input Class Initialized
INFO - 2022-06-05 16:31:28 --> Language Class Initialized
INFO - 2022-06-05 16:31:28 --> Language Class Initialized
INFO - 2022-06-05 16:31:28 --> Config Class Initialized
INFO - 2022-06-05 16:31:28 --> Loader Class Initialized
INFO - 2022-06-05 16:31:28 --> Helper loaded: url_helper
INFO - 2022-06-05 16:31:28 --> Database Driver Class Initialized
INFO - 2022-06-05 16:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:31:28 --> Controller Class Initialized
DEBUG - 2022-06-05 16:31:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:31:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:31:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:31:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:31:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:31:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:31:28 --> Final output sent to browser
DEBUG - 2022-06-05 16:31:28 --> Total execution time: 0.0534
INFO - 2022-06-05 16:31:33 --> Config Class Initialized
INFO - 2022-06-05 16:31:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:31:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:31:33 --> Utf8 Class Initialized
INFO - 2022-06-05 16:31:33 --> URI Class Initialized
INFO - 2022-06-05 16:31:33 --> Router Class Initialized
INFO - 2022-06-05 16:31:33 --> Output Class Initialized
INFO - 2022-06-05 16:31:33 --> Security Class Initialized
DEBUG - 2022-06-05 16:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:31:33 --> Input Class Initialized
INFO - 2022-06-05 16:31:33 --> Language Class Initialized
INFO - 2022-06-05 16:31:33 --> Language Class Initialized
INFO - 2022-06-05 16:31:33 --> Config Class Initialized
INFO - 2022-06-05 16:31:33 --> Loader Class Initialized
INFO - 2022-06-05 16:31:33 --> Helper loaded: url_helper
INFO - 2022-06-05 16:31:33 --> Database Driver Class Initialized
INFO - 2022-06-05 16:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:31:33 --> Controller Class Initialized
DEBUG - 2022-06-05 16:31:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:31:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:31:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:31:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:31:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:31:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:31:33 --> Final output sent to browser
DEBUG - 2022-06-05 16:31:33 --> Total execution time: 0.0512
INFO - 2022-06-05 16:31:35 --> Config Class Initialized
INFO - 2022-06-05 16:31:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:31:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:31:35 --> Utf8 Class Initialized
INFO - 2022-06-05 16:31:35 --> URI Class Initialized
INFO - 2022-06-05 16:31:35 --> Router Class Initialized
INFO - 2022-06-05 16:31:35 --> Output Class Initialized
INFO - 2022-06-05 16:31:35 --> Security Class Initialized
DEBUG - 2022-06-05 16:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:31:35 --> Input Class Initialized
INFO - 2022-06-05 16:31:35 --> Language Class Initialized
INFO - 2022-06-05 16:31:35 --> Language Class Initialized
INFO - 2022-06-05 16:31:35 --> Config Class Initialized
INFO - 2022-06-05 16:31:35 --> Loader Class Initialized
INFO - 2022-06-05 16:31:35 --> Helper loaded: url_helper
INFO - 2022-06-05 16:31:35 --> Database Driver Class Initialized
INFO - 2022-06-05 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:31:35 --> Controller Class Initialized
DEBUG - 2022-06-05 16:31:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:31:35 --> Final output sent to browser
DEBUG - 2022-06-05 16:31:35 --> Total execution time: 0.0868
INFO - 2022-06-05 16:31:59 --> Config Class Initialized
INFO - 2022-06-05 16:31:59 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:31:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:31:59 --> Utf8 Class Initialized
INFO - 2022-06-05 16:31:59 --> URI Class Initialized
INFO - 2022-06-05 16:31:59 --> Router Class Initialized
INFO - 2022-06-05 16:31:59 --> Output Class Initialized
INFO - 2022-06-05 16:31:59 --> Security Class Initialized
DEBUG - 2022-06-05 16:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:31:59 --> Input Class Initialized
INFO - 2022-06-05 16:31:59 --> Language Class Initialized
INFO - 2022-06-05 16:31:59 --> Language Class Initialized
INFO - 2022-06-05 16:31:59 --> Config Class Initialized
INFO - 2022-06-05 16:31:59 --> Loader Class Initialized
INFO - 2022-06-05 16:31:59 --> Helper loaded: url_helper
INFO - 2022-06-05 16:31:59 --> Database Driver Class Initialized
INFO - 2022-06-05 16:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:31:59 --> Controller Class Initialized
DEBUG - 2022-06-05 16:31:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:31:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:31:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:31:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:31:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:31:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:31:59 --> Final output sent to browser
DEBUG - 2022-06-05 16:31:59 --> Total execution time: 0.0500
INFO - 2022-06-05 16:32:23 --> Config Class Initialized
INFO - 2022-06-05 16:32:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:32:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:32:23 --> Utf8 Class Initialized
INFO - 2022-06-05 16:32:23 --> URI Class Initialized
INFO - 2022-06-05 16:32:23 --> Router Class Initialized
INFO - 2022-06-05 16:32:23 --> Output Class Initialized
INFO - 2022-06-05 16:32:23 --> Security Class Initialized
DEBUG - 2022-06-05 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:32:23 --> Input Class Initialized
INFO - 2022-06-05 16:32:23 --> Language Class Initialized
INFO - 2022-06-05 16:32:23 --> Language Class Initialized
INFO - 2022-06-05 16:32:23 --> Config Class Initialized
INFO - 2022-06-05 16:32:23 --> Loader Class Initialized
INFO - 2022-06-05 16:32:23 --> Helper loaded: url_helper
INFO - 2022-06-05 16:32:23 --> Database Driver Class Initialized
INFO - 2022-06-05 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:32:23 --> Controller Class Initialized
DEBUG - 2022-06-05 16:32:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:32:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:32:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:32:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:32:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:32:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:32:23 --> Final output sent to browser
DEBUG - 2022-06-05 16:32:23 --> Total execution time: 0.0464
INFO - 2022-06-05 16:32:30 --> Config Class Initialized
INFO - 2022-06-05 16:32:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:32:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:32:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:32:30 --> URI Class Initialized
INFO - 2022-06-05 16:32:30 --> Router Class Initialized
INFO - 2022-06-05 16:32:30 --> Output Class Initialized
INFO - 2022-06-05 16:32:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:32:30 --> Input Class Initialized
INFO - 2022-06-05 16:32:30 --> Language Class Initialized
INFO - 2022-06-05 16:32:30 --> Language Class Initialized
INFO - 2022-06-05 16:32:30 --> Config Class Initialized
INFO - 2022-06-05 16:32:30 --> Loader Class Initialized
INFO - 2022-06-05 16:32:30 --> Helper loaded: url_helper
INFO - 2022-06-05 16:32:30 --> Database Driver Class Initialized
INFO - 2022-06-05 16:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:32:30 --> Controller Class Initialized
DEBUG - 2022-06-05 16:32:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:32:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:32:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:32:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:32:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:32:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:32:30 --> Final output sent to browser
DEBUG - 2022-06-05 16:32:30 --> Total execution time: 0.0596
INFO - 2022-06-05 16:32:47 --> Config Class Initialized
INFO - 2022-06-05 16:32:47 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:32:47 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:32:47 --> Utf8 Class Initialized
INFO - 2022-06-05 16:32:47 --> URI Class Initialized
INFO - 2022-06-05 16:32:47 --> Router Class Initialized
INFO - 2022-06-05 16:32:47 --> Output Class Initialized
INFO - 2022-06-05 16:32:47 --> Security Class Initialized
DEBUG - 2022-06-05 16:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:32:47 --> Input Class Initialized
INFO - 2022-06-05 16:32:47 --> Language Class Initialized
INFO - 2022-06-05 16:32:47 --> Language Class Initialized
INFO - 2022-06-05 16:32:47 --> Config Class Initialized
INFO - 2022-06-05 16:32:47 --> Loader Class Initialized
INFO - 2022-06-05 16:32:47 --> Helper loaded: url_helper
INFO - 2022-06-05 16:32:47 --> Database Driver Class Initialized
INFO - 2022-06-05 16:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:32:47 --> Controller Class Initialized
DEBUG - 2022-06-05 16:32:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:32:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:32:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:32:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:32:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:32:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:32:47 --> Final output sent to browser
DEBUG - 2022-06-05 16:32:47 --> Total execution time: 0.0505
INFO - 2022-06-05 16:32:59 --> Config Class Initialized
INFO - 2022-06-05 16:32:59 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:32:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:32:59 --> Utf8 Class Initialized
INFO - 2022-06-05 16:32:59 --> URI Class Initialized
INFO - 2022-06-05 16:32:59 --> Router Class Initialized
INFO - 2022-06-05 16:32:59 --> Output Class Initialized
INFO - 2022-06-05 16:32:59 --> Security Class Initialized
DEBUG - 2022-06-05 16:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:32:59 --> Input Class Initialized
INFO - 2022-06-05 16:32:59 --> Language Class Initialized
INFO - 2022-06-05 16:32:59 --> Language Class Initialized
INFO - 2022-06-05 16:32:59 --> Config Class Initialized
INFO - 2022-06-05 16:32:59 --> Loader Class Initialized
INFO - 2022-06-05 16:32:59 --> Helper loaded: url_helper
INFO - 2022-06-05 16:32:59 --> Database Driver Class Initialized
INFO - 2022-06-05 16:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:32:59 --> Controller Class Initialized
DEBUG - 2022-06-05 16:32:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:32:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:32:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:32:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:32:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:32:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:32:59 --> Final output sent to browser
DEBUG - 2022-06-05 16:32:59 --> Total execution time: 0.0629
INFO - 2022-06-05 16:33:08 --> Config Class Initialized
INFO - 2022-06-05 16:33:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:33:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:33:08 --> Utf8 Class Initialized
INFO - 2022-06-05 16:33:08 --> URI Class Initialized
INFO - 2022-06-05 16:33:08 --> Router Class Initialized
INFO - 2022-06-05 16:33:08 --> Output Class Initialized
INFO - 2022-06-05 16:33:08 --> Security Class Initialized
DEBUG - 2022-06-05 16:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:33:08 --> Input Class Initialized
INFO - 2022-06-05 16:33:08 --> Language Class Initialized
INFO - 2022-06-05 16:33:08 --> Language Class Initialized
INFO - 2022-06-05 16:33:08 --> Config Class Initialized
INFO - 2022-06-05 16:33:08 --> Loader Class Initialized
INFO - 2022-06-05 16:33:08 --> Helper loaded: url_helper
INFO - 2022-06-05 16:33:08 --> Database Driver Class Initialized
INFO - 2022-06-05 16:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:33:08 --> Controller Class Initialized
DEBUG - 2022-06-05 16:33:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:33:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:33:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:33:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:33:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:33:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:33:08 --> Final output sent to browser
DEBUG - 2022-06-05 16:33:08 --> Total execution time: 0.0491
INFO - 2022-06-05 16:34:16 --> Config Class Initialized
INFO - 2022-06-05 16:34:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:34:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:34:16 --> Utf8 Class Initialized
INFO - 2022-06-05 16:34:16 --> URI Class Initialized
INFO - 2022-06-05 16:34:16 --> Router Class Initialized
INFO - 2022-06-05 16:34:16 --> Output Class Initialized
INFO - 2022-06-05 16:34:16 --> Security Class Initialized
DEBUG - 2022-06-05 16:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:34:16 --> Input Class Initialized
INFO - 2022-06-05 16:34:16 --> Language Class Initialized
INFO - 2022-06-05 16:34:16 --> Language Class Initialized
INFO - 2022-06-05 16:34:16 --> Config Class Initialized
INFO - 2022-06-05 16:34:16 --> Loader Class Initialized
INFO - 2022-06-05 16:34:16 --> Helper loaded: url_helper
INFO - 2022-06-05 16:34:16 --> Database Driver Class Initialized
INFO - 2022-06-05 16:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:34:16 --> Controller Class Initialized
DEBUG - 2022-06-05 16:34:16 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:34:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:34:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:34:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:34:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:34:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:34:16 --> Final output sent to browser
DEBUG - 2022-06-05 16:34:16 --> Total execution time: 0.0490
INFO - 2022-06-05 16:34:32 --> Config Class Initialized
INFO - 2022-06-05 16:34:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:34:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:34:32 --> Utf8 Class Initialized
INFO - 2022-06-05 16:34:32 --> URI Class Initialized
INFO - 2022-06-05 16:34:32 --> Router Class Initialized
INFO - 2022-06-05 16:34:32 --> Output Class Initialized
INFO - 2022-06-05 16:34:32 --> Security Class Initialized
DEBUG - 2022-06-05 16:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:34:32 --> Input Class Initialized
INFO - 2022-06-05 16:34:32 --> Language Class Initialized
INFO - 2022-06-05 16:34:32 --> Language Class Initialized
INFO - 2022-06-05 16:34:32 --> Config Class Initialized
INFO - 2022-06-05 16:34:32 --> Loader Class Initialized
INFO - 2022-06-05 16:34:32 --> Helper loaded: url_helper
INFO - 2022-06-05 16:34:32 --> Database Driver Class Initialized
INFO - 2022-06-05 16:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:34:32 --> Controller Class Initialized
DEBUG - 2022-06-05 16:34:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:34:32 --> Final output sent to browser
DEBUG - 2022-06-05 16:34:32 --> Total execution time: 0.0531
INFO - 2022-06-05 16:35:04 --> Config Class Initialized
INFO - 2022-06-05 16:35:04 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:35:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:35:04 --> Utf8 Class Initialized
INFO - 2022-06-05 16:35:04 --> URI Class Initialized
INFO - 2022-06-05 16:35:04 --> Router Class Initialized
INFO - 2022-06-05 16:35:04 --> Output Class Initialized
INFO - 2022-06-05 16:35:04 --> Security Class Initialized
DEBUG - 2022-06-05 16:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:35:04 --> Input Class Initialized
INFO - 2022-06-05 16:35:04 --> Language Class Initialized
INFO - 2022-06-05 16:35:04 --> Language Class Initialized
INFO - 2022-06-05 16:35:04 --> Config Class Initialized
INFO - 2022-06-05 16:35:04 --> Loader Class Initialized
INFO - 2022-06-05 16:35:04 --> Helper loaded: url_helper
INFO - 2022-06-05 16:35:04 --> Database Driver Class Initialized
INFO - 2022-06-05 16:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:35:04 --> Controller Class Initialized
DEBUG - 2022-06-05 16:35:04 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:35:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:35:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:35:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:35:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:35:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:35:04 --> Final output sent to browser
DEBUG - 2022-06-05 16:35:04 --> Total execution time: 0.0486
INFO - 2022-06-05 16:35:12 --> Config Class Initialized
INFO - 2022-06-05 16:35:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:35:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:35:12 --> Utf8 Class Initialized
INFO - 2022-06-05 16:35:12 --> URI Class Initialized
INFO - 2022-06-05 16:35:12 --> Router Class Initialized
INFO - 2022-06-05 16:35:12 --> Output Class Initialized
INFO - 2022-06-05 16:35:12 --> Security Class Initialized
DEBUG - 2022-06-05 16:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:35:12 --> Input Class Initialized
INFO - 2022-06-05 16:35:12 --> Language Class Initialized
INFO - 2022-06-05 16:35:12 --> Language Class Initialized
INFO - 2022-06-05 16:35:12 --> Config Class Initialized
INFO - 2022-06-05 16:35:12 --> Loader Class Initialized
INFO - 2022-06-05 16:35:12 --> Helper loaded: url_helper
INFO - 2022-06-05 16:35:12 --> Database Driver Class Initialized
INFO - 2022-06-05 16:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:35:12 --> Controller Class Initialized
DEBUG - 2022-06-05 16:35:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:35:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:35:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:35:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:35:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:35:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:35:12 --> Final output sent to browser
DEBUG - 2022-06-05 16:35:12 --> Total execution time: 0.0564
INFO - 2022-06-05 16:35:30 --> Config Class Initialized
INFO - 2022-06-05 16:35:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:35:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:35:30 --> Utf8 Class Initialized
INFO - 2022-06-05 16:35:30 --> URI Class Initialized
INFO - 2022-06-05 16:35:30 --> Router Class Initialized
INFO - 2022-06-05 16:35:30 --> Output Class Initialized
INFO - 2022-06-05 16:35:30 --> Security Class Initialized
DEBUG - 2022-06-05 16:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:35:30 --> Input Class Initialized
INFO - 2022-06-05 16:35:30 --> Language Class Initialized
INFO - 2022-06-05 16:35:30 --> Language Class Initialized
INFO - 2022-06-05 16:35:30 --> Config Class Initialized
INFO - 2022-06-05 16:35:30 --> Loader Class Initialized
INFO - 2022-06-05 16:35:30 --> Helper loaded: url_helper
INFO - 2022-06-05 16:35:30 --> Database Driver Class Initialized
INFO - 2022-06-05 16:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:35:30 --> Controller Class Initialized
DEBUG - 2022-06-05 16:35:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:35:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:35:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:35:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:35:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:35:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:35:30 --> Final output sent to browser
DEBUG - 2022-06-05 16:35:30 --> Total execution time: 0.0656
INFO - 2022-06-05 16:35:39 --> Config Class Initialized
INFO - 2022-06-05 16:35:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:35:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:35:39 --> Utf8 Class Initialized
INFO - 2022-06-05 16:35:39 --> URI Class Initialized
INFO - 2022-06-05 16:35:39 --> Router Class Initialized
INFO - 2022-06-05 16:35:39 --> Output Class Initialized
INFO - 2022-06-05 16:35:39 --> Security Class Initialized
DEBUG - 2022-06-05 16:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:35:39 --> Input Class Initialized
INFO - 2022-06-05 16:35:39 --> Language Class Initialized
INFO - 2022-06-05 16:35:39 --> Language Class Initialized
INFO - 2022-06-05 16:35:39 --> Config Class Initialized
INFO - 2022-06-05 16:35:39 --> Loader Class Initialized
INFO - 2022-06-05 16:35:39 --> Helper loaded: url_helper
INFO - 2022-06-05 16:35:39 --> Database Driver Class Initialized
INFO - 2022-06-05 16:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:35:39 --> Controller Class Initialized
DEBUG - 2022-06-05 16:35:39 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:35:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:35:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:35:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:35:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:35:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:35:39 --> Final output sent to browser
DEBUG - 2022-06-05 16:35:39 --> Total execution time: 0.0427
INFO - 2022-06-05 16:37:39 --> Config Class Initialized
INFO - 2022-06-05 16:37:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:37:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:37:39 --> Utf8 Class Initialized
INFO - 2022-06-05 16:37:39 --> URI Class Initialized
INFO - 2022-06-05 16:37:39 --> Router Class Initialized
INFO - 2022-06-05 16:37:39 --> Output Class Initialized
INFO - 2022-06-05 16:37:39 --> Security Class Initialized
DEBUG - 2022-06-05 16:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:37:39 --> Input Class Initialized
INFO - 2022-06-05 16:37:39 --> Language Class Initialized
INFO - 2022-06-05 16:37:39 --> Language Class Initialized
INFO - 2022-06-05 16:37:39 --> Config Class Initialized
INFO - 2022-06-05 16:37:39 --> Loader Class Initialized
INFO - 2022-06-05 16:37:39 --> Helper loaded: url_helper
INFO - 2022-06-05 16:37:39 --> Database Driver Class Initialized
INFO - 2022-06-05 16:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:37:39 --> Controller Class Initialized
DEBUG - 2022-06-05 16:37:39 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:37:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:37:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:37:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:37:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:37:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:37:39 --> Final output sent to browser
DEBUG - 2022-06-05 16:37:39 --> Total execution time: 0.0515
INFO - 2022-06-05 16:38:01 --> Config Class Initialized
INFO - 2022-06-05 16:38:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:38:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:38:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:38:01 --> URI Class Initialized
INFO - 2022-06-05 16:38:01 --> Router Class Initialized
INFO - 2022-06-05 16:38:01 --> Output Class Initialized
INFO - 2022-06-05 16:38:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:38:01 --> Input Class Initialized
INFO - 2022-06-05 16:38:01 --> Language Class Initialized
INFO - 2022-06-05 16:38:01 --> Language Class Initialized
INFO - 2022-06-05 16:38:01 --> Config Class Initialized
INFO - 2022-06-05 16:38:01 --> Loader Class Initialized
INFO - 2022-06-05 16:38:01 --> Helper loaded: url_helper
INFO - 2022-06-05 16:38:01 --> Database Driver Class Initialized
INFO - 2022-06-05 16:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:38:01 --> Controller Class Initialized
DEBUG - 2022-06-05 16:38:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:38:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:38:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:38:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:38:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:38:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:38:01 --> Final output sent to browser
DEBUG - 2022-06-05 16:38:01 --> Total execution time: 0.0464
INFO - 2022-06-05 16:38:59 --> Config Class Initialized
INFO - 2022-06-05 16:38:59 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:38:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:38:59 --> Utf8 Class Initialized
INFO - 2022-06-05 16:38:59 --> URI Class Initialized
INFO - 2022-06-05 16:38:59 --> Router Class Initialized
INFO - 2022-06-05 16:38:59 --> Output Class Initialized
INFO - 2022-06-05 16:38:59 --> Security Class Initialized
DEBUG - 2022-06-05 16:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:38:59 --> Input Class Initialized
INFO - 2022-06-05 16:38:59 --> Language Class Initialized
INFO - 2022-06-05 16:38:59 --> Language Class Initialized
INFO - 2022-06-05 16:38:59 --> Config Class Initialized
INFO - 2022-06-05 16:38:59 --> Loader Class Initialized
INFO - 2022-06-05 16:38:59 --> Helper loaded: url_helper
INFO - 2022-06-05 16:38:59 --> Database Driver Class Initialized
INFO - 2022-06-05 16:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:38:59 --> Controller Class Initialized
DEBUG - 2022-06-05 16:38:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:38:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:38:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:38:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:38:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:38:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:38:59 --> Final output sent to browser
DEBUG - 2022-06-05 16:38:59 --> Total execution time: 0.0498
INFO - 2022-06-05 16:39:28 --> Config Class Initialized
INFO - 2022-06-05 16:39:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:39:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:39:28 --> Utf8 Class Initialized
INFO - 2022-06-05 16:39:28 --> URI Class Initialized
INFO - 2022-06-05 16:39:28 --> Router Class Initialized
INFO - 2022-06-05 16:39:28 --> Output Class Initialized
INFO - 2022-06-05 16:39:28 --> Security Class Initialized
DEBUG - 2022-06-05 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:39:28 --> Input Class Initialized
INFO - 2022-06-05 16:39:28 --> Language Class Initialized
INFO - 2022-06-05 16:39:28 --> Language Class Initialized
INFO - 2022-06-05 16:39:28 --> Config Class Initialized
INFO - 2022-06-05 16:39:28 --> Loader Class Initialized
INFO - 2022-06-05 16:39:28 --> Helper loaded: url_helper
INFO - 2022-06-05 16:39:28 --> Database Driver Class Initialized
INFO - 2022-06-05 16:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:39:28 --> Controller Class Initialized
DEBUG - 2022-06-05 16:39:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:39:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:39:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:39:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:39:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:39:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:39:28 --> Final output sent to browser
DEBUG - 2022-06-05 16:39:28 --> Total execution time: 0.0518
INFO - 2022-06-05 16:39:42 --> Config Class Initialized
INFO - 2022-06-05 16:39:42 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:39:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:39:42 --> Utf8 Class Initialized
INFO - 2022-06-05 16:39:42 --> URI Class Initialized
INFO - 2022-06-05 16:39:42 --> Router Class Initialized
INFO - 2022-06-05 16:39:42 --> Output Class Initialized
INFO - 2022-06-05 16:39:42 --> Security Class Initialized
DEBUG - 2022-06-05 16:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:39:42 --> Input Class Initialized
INFO - 2022-06-05 16:39:42 --> Language Class Initialized
INFO - 2022-06-05 16:39:42 --> Language Class Initialized
INFO - 2022-06-05 16:39:42 --> Config Class Initialized
INFO - 2022-06-05 16:39:42 --> Loader Class Initialized
INFO - 2022-06-05 16:39:42 --> Helper loaded: url_helper
INFO - 2022-06-05 16:39:42 --> Database Driver Class Initialized
INFO - 2022-06-05 16:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:39:42 --> Controller Class Initialized
DEBUG - 2022-06-05 16:39:42 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:39:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:39:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:39:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:39:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:39:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:39:42 --> Final output sent to browser
DEBUG - 2022-06-05 16:39:42 --> Total execution time: 0.0556
INFO - 2022-06-05 16:39:55 --> Config Class Initialized
INFO - 2022-06-05 16:39:55 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:39:55 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:39:55 --> Utf8 Class Initialized
INFO - 2022-06-05 16:39:55 --> URI Class Initialized
INFO - 2022-06-05 16:39:55 --> Router Class Initialized
INFO - 2022-06-05 16:39:55 --> Output Class Initialized
INFO - 2022-06-05 16:39:55 --> Security Class Initialized
DEBUG - 2022-06-05 16:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:39:55 --> Input Class Initialized
INFO - 2022-06-05 16:39:55 --> Language Class Initialized
INFO - 2022-06-05 16:39:55 --> Language Class Initialized
INFO - 2022-06-05 16:39:55 --> Config Class Initialized
INFO - 2022-06-05 16:39:55 --> Loader Class Initialized
INFO - 2022-06-05 16:39:55 --> Helper loaded: url_helper
INFO - 2022-06-05 16:39:55 --> Database Driver Class Initialized
INFO - 2022-06-05 16:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:39:55 --> Controller Class Initialized
DEBUG - 2022-06-05 16:39:55 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:39:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:39:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:39:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:39:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:39:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:39:55 --> Final output sent to browser
DEBUG - 2022-06-05 16:39:55 --> Total execution time: 0.0519
INFO - 2022-06-05 16:40:09 --> Config Class Initialized
INFO - 2022-06-05 16:40:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:40:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:40:09 --> Utf8 Class Initialized
INFO - 2022-06-05 16:40:09 --> URI Class Initialized
INFO - 2022-06-05 16:40:09 --> Router Class Initialized
INFO - 2022-06-05 16:40:09 --> Output Class Initialized
INFO - 2022-06-05 16:40:09 --> Security Class Initialized
DEBUG - 2022-06-05 16:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:40:09 --> Input Class Initialized
INFO - 2022-06-05 16:40:09 --> Language Class Initialized
INFO - 2022-06-05 16:40:09 --> Language Class Initialized
INFO - 2022-06-05 16:40:09 --> Config Class Initialized
INFO - 2022-06-05 16:40:09 --> Loader Class Initialized
INFO - 2022-06-05 16:40:09 --> Helper loaded: url_helper
INFO - 2022-06-05 16:40:10 --> Database Driver Class Initialized
INFO - 2022-06-05 16:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:40:10 --> Controller Class Initialized
DEBUG - 2022-06-05 16:40:10 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:40:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:40:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:40:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:40:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:40:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:40:10 --> Final output sent to browser
DEBUG - 2022-06-05 16:40:10 --> Total execution time: 0.0511
INFO - 2022-06-05 16:40:38 --> Config Class Initialized
INFO - 2022-06-05 16:40:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:40:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:40:38 --> Utf8 Class Initialized
INFO - 2022-06-05 16:40:38 --> URI Class Initialized
INFO - 2022-06-05 16:40:38 --> Router Class Initialized
INFO - 2022-06-05 16:40:38 --> Output Class Initialized
INFO - 2022-06-05 16:40:38 --> Security Class Initialized
DEBUG - 2022-06-05 16:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:40:38 --> Input Class Initialized
INFO - 2022-06-05 16:40:38 --> Language Class Initialized
INFO - 2022-06-05 16:40:38 --> Language Class Initialized
INFO - 2022-06-05 16:40:38 --> Config Class Initialized
INFO - 2022-06-05 16:40:38 --> Loader Class Initialized
INFO - 2022-06-05 16:40:38 --> Helper loaded: url_helper
INFO - 2022-06-05 16:40:38 --> Database Driver Class Initialized
INFO - 2022-06-05 16:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:40:38 --> Controller Class Initialized
DEBUG - 2022-06-05 16:40:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:40:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:40:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:40:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:40:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:40:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:40:38 --> Final output sent to browser
DEBUG - 2022-06-05 16:40:38 --> Total execution time: 0.0322
INFO - 2022-06-05 16:41:01 --> Config Class Initialized
INFO - 2022-06-05 16:41:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:41:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:41:01 --> Utf8 Class Initialized
INFO - 2022-06-05 16:41:01 --> URI Class Initialized
INFO - 2022-06-05 16:41:01 --> Router Class Initialized
INFO - 2022-06-05 16:41:01 --> Output Class Initialized
INFO - 2022-06-05 16:41:01 --> Security Class Initialized
DEBUG - 2022-06-05 16:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:41:01 --> Input Class Initialized
INFO - 2022-06-05 16:41:01 --> Language Class Initialized
INFO - 2022-06-05 16:41:01 --> Language Class Initialized
INFO - 2022-06-05 16:41:01 --> Config Class Initialized
INFO - 2022-06-05 16:41:01 --> Loader Class Initialized
INFO - 2022-06-05 16:41:01 --> Helper loaded: url_helper
INFO - 2022-06-05 16:41:01 --> Database Driver Class Initialized
INFO - 2022-06-05 16:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:41:01 --> Controller Class Initialized
DEBUG - 2022-06-05 16:41:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:41:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:41:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:41:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:41:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:41:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:41:01 --> Final output sent to browser
DEBUG - 2022-06-05 16:41:01 --> Total execution time: 0.0522
INFO - 2022-06-05 16:41:07 --> Config Class Initialized
INFO - 2022-06-05 16:41:07 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:41:07 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:41:07 --> Utf8 Class Initialized
INFO - 2022-06-05 16:41:07 --> URI Class Initialized
INFO - 2022-06-05 16:41:07 --> Router Class Initialized
INFO - 2022-06-05 16:41:07 --> Output Class Initialized
INFO - 2022-06-05 16:41:07 --> Security Class Initialized
DEBUG - 2022-06-05 16:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:41:07 --> Input Class Initialized
INFO - 2022-06-05 16:41:07 --> Language Class Initialized
INFO - 2022-06-05 16:41:07 --> Language Class Initialized
INFO - 2022-06-05 16:41:07 --> Config Class Initialized
INFO - 2022-06-05 16:41:07 --> Loader Class Initialized
INFO - 2022-06-05 16:41:07 --> Helper loaded: url_helper
INFO - 2022-06-05 16:41:07 --> Database Driver Class Initialized
INFO - 2022-06-05 16:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:41:07 --> Controller Class Initialized
DEBUG - 2022-06-05 16:41:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:41:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:41:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:41:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:41:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:41:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:41:07 --> Final output sent to browser
DEBUG - 2022-06-05 16:41:07 --> Total execution time: 0.0955
INFO - 2022-06-05 16:41:17 --> Config Class Initialized
INFO - 2022-06-05 16:41:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:41:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:41:17 --> Utf8 Class Initialized
INFO - 2022-06-05 16:41:17 --> URI Class Initialized
INFO - 2022-06-05 16:41:17 --> Router Class Initialized
INFO - 2022-06-05 16:41:17 --> Output Class Initialized
INFO - 2022-06-05 16:41:17 --> Security Class Initialized
DEBUG - 2022-06-05 16:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:41:17 --> Input Class Initialized
INFO - 2022-06-05 16:41:17 --> Language Class Initialized
INFO - 2022-06-05 16:41:17 --> Language Class Initialized
INFO - 2022-06-05 16:41:17 --> Config Class Initialized
INFO - 2022-06-05 16:41:17 --> Loader Class Initialized
INFO - 2022-06-05 16:41:17 --> Helper loaded: url_helper
INFO - 2022-06-05 16:41:17 --> Database Driver Class Initialized
INFO - 2022-06-05 16:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:41:17 --> Controller Class Initialized
DEBUG - 2022-06-05 16:41:17 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:41:17 --> Final output sent to browser
DEBUG - 2022-06-05 16:41:17 --> Total execution time: 0.0477
INFO - 2022-06-05 16:42:11 --> Config Class Initialized
INFO - 2022-06-05 16:42:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:42:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:42:11 --> Utf8 Class Initialized
INFO - 2022-06-05 16:42:11 --> URI Class Initialized
INFO - 2022-06-05 16:42:11 --> Router Class Initialized
INFO - 2022-06-05 16:42:11 --> Output Class Initialized
INFO - 2022-06-05 16:42:11 --> Security Class Initialized
DEBUG - 2022-06-05 16:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:42:11 --> Input Class Initialized
INFO - 2022-06-05 16:42:11 --> Language Class Initialized
INFO - 2022-06-05 16:42:11 --> Language Class Initialized
INFO - 2022-06-05 16:42:11 --> Config Class Initialized
INFO - 2022-06-05 16:42:11 --> Loader Class Initialized
INFO - 2022-06-05 16:42:11 --> Helper loaded: url_helper
INFO - 2022-06-05 16:42:11 --> Database Driver Class Initialized
INFO - 2022-06-05 16:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:42:11 --> Controller Class Initialized
DEBUG - 2022-06-05 16:42:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:42:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:42:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:42:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:42:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:42:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:42:11 --> Final output sent to browser
DEBUG - 2022-06-05 16:42:11 --> Total execution time: 0.0508
INFO - 2022-06-05 16:42:29 --> Config Class Initialized
INFO - 2022-06-05 16:42:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:42:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:42:29 --> Utf8 Class Initialized
INFO - 2022-06-05 16:42:29 --> URI Class Initialized
INFO - 2022-06-05 16:42:29 --> Router Class Initialized
INFO - 2022-06-05 16:42:29 --> Output Class Initialized
INFO - 2022-06-05 16:42:29 --> Security Class Initialized
DEBUG - 2022-06-05 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:42:29 --> Input Class Initialized
INFO - 2022-06-05 16:42:29 --> Language Class Initialized
INFO - 2022-06-05 16:42:29 --> Language Class Initialized
INFO - 2022-06-05 16:42:29 --> Config Class Initialized
INFO - 2022-06-05 16:42:29 --> Loader Class Initialized
INFO - 2022-06-05 16:42:29 --> Helper loaded: url_helper
INFO - 2022-06-05 16:42:29 --> Database Driver Class Initialized
INFO - 2022-06-05 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:42:29 --> Controller Class Initialized
DEBUG - 2022-06-05 16:42:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:42:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:42:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:42:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:42:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:42:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:42:29 --> Final output sent to browser
DEBUG - 2022-06-05 16:42:29 --> Total execution time: 0.0531
INFO - 2022-06-05 16:43:07 --> Config Class Initialized
INFO - 2022-06-05 16:43:07 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:43:07 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:43:07 --> Utf8 Class Initialized
INFO - 2022-06-05 16:43:07 --> URI Class Initialized
INFO - 2022-06-05 16:43:07 --> Router Class Initialized
INFO - 2022-06-05 16:43:07 --> Output Class Initialized
INFO - 2022-06-05 16:43:07 --> Security Class Initialized
DEBUG - 2022-06-05 16:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:43:07 --> Input Class Initialized
INFO - 2022-06-05 16:43:07 --> Language Class Initialized
INFO - 2022-06-05 16:43:07 --> Language Class Initialized
INFO - 2022-06-05 16:43:07 --> Config Class Initialized
INFO - 2022-06-05 16:43:07 --> Loader Class Initialized
INFO - 2022-06-05 16:43:07 --> Helper loaded: url_helper
INFO - 2022-06-05 16:43:07 --> Database Driver Class Initialized
INFO - 2022-06-05 16:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:43:07 --> Controller Class Initialized
DEBUG - 2022-06-05 16:43:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:43:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:43:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:43:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:43:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:43:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:43:07 --> Final output sent to browser
DEBUG - 2022-06-05 16:43:07 --> Total execution time: 0.0436
INFO - 2022-06-05 16:49:45 --> Config Class Initialized
INFO - 2022-06-05 16:49:45 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:49:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:49:45 --> Utf8 Class Initialized
INFO - 2022-06-05 16:49:45 --> URI Class Initialized
INFO - 2022-06-05 16:49:45 --> Router Class Initialized
INFO - 2022-06-05 16:49:45 --> Output Class Initialized
INFO - 2022-06-05 16:49:45 --> Security Class Initialized
DEBUG - 2022-06-05 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:49:45 --> Input Class Initialized
INFO - 2022-06-05 16:49:45 --> Language Class Initialized
INFO - 2022-06-05 16:49:45 --> Language Class Initialized
INFO - 2022-06-05 16:49:45 --> Config Class Initialized
INFO - 2022-06-05 16:49:45 --> Loader Class Initialized
INFO - 2022-06-05 16:49:45 --> Helper loaded: url_helper
INFO - 2022-06-05 16:49:45 --> Database Driver Class Initialized
INFO - 2022-06-05 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:49:45 --> Model Class Initialized
DEBUG - 2022-06-05 16:49:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 16:49:45 --> Model Class Initialized
INFO - 2022-06-05 16:49:45 --> Controller Class Initialized
DEBUG - 2022-06-05 16:49:45 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:49:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:49:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:49:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:49:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:49:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:49:45 --> Final output sent to browser
DEBUG - 2022-06-05 16:49:45 --> Total execution time: 0.0347
INFO - 2022-06-05 16:56:37 --> Config Class Initialized
INFO - 2022-06-05 16:56:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 16:56:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 16:56:37 --> Utf8 Class Initialized
INFO - 2022-06-05 16:56:37 --> URI Class Initialized
INFO - 2022-06-05 16:56:37 --> Router Class Initialized
INFO - 2022-06-05 16:56:37 --> Output Class Initialized
INFO - 2022-06-05 16:56:37 --> Security Class Initialized
DEBUG - 2022-06-05 16:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 16:56:37 --> Input Class Initialized
INFO - 2022-06-05 16:56:37 --> Language Class Initialized
INFO - 2022-06-05 16:56:37 --> Language Class Initialized
INFO - 2022-06-05 16:56:37 --> Config Class Initialized
INFO - 2022-06-05 16:56:37 --> Loader Class Initialized
INFO - 2022-06-05 16:56:37 --> Helper loaded: url_helper
INFO - 2022-06-05 16:56:37 --> Database Driver Class Initialized
INFO - 2022-06-05 16:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 16:56:37 --> Model Class Initialized
DEBUG - 2022-06-05 16:56:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 16:56:37 --> Model Class Initialized
INFO - 2022-06-05 16:56:37 --> Controller Class Initialized
DEBUG - 2022-06-05 16:56:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 16:56:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 16:56:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 16:56:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 16:56:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 16:56:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 16:56:37 --> Final output sent to browser
DEBUG - 2022-06-05 16:56:37 --> Total execution time: 0.0391
INFO - 2022-06-05 17:00:36 --> Config Class Initialized
INFO - 2022-06-05 17:00:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:00:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:00:36 --> Utf8 Class Initialized
INFO - 2022-06-05 17:00:36 --> URI Class Initialized
INFO - 2022-06-05 17:00:36 --> Router Class Initialized
INFO - 2022-06-05 17:00:36 --> Output Class Initialized
INFO - 2022-06-05 17:00:36 --> Security Class Initialized
DEBUG - 2022-06-05 17:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:00:36 --> Input Class Initialized
INFO - 2022-06-05 17:00:36 --> Language Class Initialized
INFO - 2022-06-05 17:00:36 --> Language Class Initialized
INFO - 2022-06-05 17:00:36 --> Config Class Initialized
INFO - 2022-06-05 17:00:36 --> Loader Class Initialized
INFO - 2022-06-05 17:00:36 --> Helper loaded: url_helper
INFO - 2022-06-05 17:00:36 --> Database Driver Class Initialized
INFO - 2022-06-05 17:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:00:36 --> Model Class Initialized
DEBUG - 2022-06-05 17:00:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:00:36 --> Model Class Initialized
INFO - 2022-06-05 17:00:36 --> Controller Class Initialized
DEBUG - 2022-06-05 17:00:36 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:00:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:00:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:00:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:00:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:00:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:00:36 --> Final output sent to browser
DEBUG - 2022-06-05 17:00:36 --> Total execution time: 0.0370
INFO - 2022-06-05 17:00:42 --> Config Class Initialized
INFO - 2022-06-05 17:00:42 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:00:42 --> Utf8 Class Initialized
INFO - 2022-06-05 17:00:42 --> URI Class Initialized
INFO - 2022-06-05 17:00:42 --> Router Class Initialized
INFO - 2022-06-05 17:00:42 --> Output Class Initialized
INFO - 2022-06-05 17:00:42 --> Security Class Initialized
DEBUG - 2022-06-05 17:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:00:42 --> Input Class Initialized
INFO - 2022-06-05 17:00:42 --> Language Class Initialized
INFO - 2022-06-05 17:00:42 --> Language Class Initialized
INFO - 2022-06-05 17:00:42 --> Config Class Initialized
INFO - 2022-06-05 17:00:42 --> Loader Class Initialized
INFO - 2022-06-05 17:00:42 --> Helper loaded: url_helper
INFO - 2022-06-05 17:00:42 --> Database Driver Class Initialized
INFO - 2022-06-05 17:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:00:42 --> Model Class Initialized
DEBUG - 2022-06-05 17:00:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:00:42 --> Model Class Initialized
INFO - 2022-06-05 17:00:42 --> Controller Class Initialized
DEBUG - 2022-06-05 17:00:42 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 17:00:43 --> Severity: Error --> Call to a member function affected_rows() on a non-object N:\Xampp\htdocs\dhired\application\modules\admin\models\Admin_model.php 18
INFO - 2022-06-05 17:01:09 --> Config Class Initialized
INFO - 2022-06-05 17:01:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:01:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:01:09 --> Utf8 Class Initialized
INFO - 2022-06-05 17:01:09 --> URI Class Initialized
INFO - 2022-06-05 17:01:09 --> Router Class Initialized
INFO - 2022-06-05 17:01:09 --> Output Class Initialized
INFO - 2022-06-05 17:01:09 --> Security Class Initialized
DEBUG - 2022-06-05 17:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:01:09 --> Input Class Initialized
INFO - 2022-06-05 17:01:09 --> Language Class Initialized
INFO - 2022-06-05 17:01:09 --> Language Class Initialized
INFO - 2022-06-05 17:01:09 --> Config Class Initialized
INFO - 2022-06-05 17:01:09 --> Loader Class Initialized
INFO - 2022-06-05 17:01:09 --> Helper loaded: url_helper
INFO - 2022-06-05 17:01:09 --> Database Driver Class Initialized
INFO - 2022-06-05 17:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:01:09 --> Model Class Initialized
DEBUG - 2022-06-05 17:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:01:09 --> Model Class Initialized
INFO - 2022-06-05 17:01:09 --> Controller Class Initialized
DEBUG - 2022-06-05 17:01:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:01:09 --> Final output sent to browser
DEBUG - 2022-06-05 17:01:09 --> Total execution time: 0.0436
INFO - 2022-06-05 17:01:17 --> Config Class Initialized
INFO - 2022-06-05 17:01:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:01:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:01:17 --> Utf8 Class Initialized
INFO - 2022-06-05 17:01:17 --> URI Class Initialized
INFO - 2022-06-05 17:01:17 --> Router Class Initialized
INFO - 2022-06-05 17:01:17 --> Output Class Initialized
INFO - 2022-06-05 17:01:17 --> Security Class Initialized
DEBUG - 2022-06-05 17:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:01:17 --> Input Class Initialized
INFO - 2022-06-05 17:01:17 --> Language Class Initialized
INFO - 2022-06-05 17:01:17 --> Language Class Initialized
INFO - 2022-06-05 17:01:17 --> Config Class Initialized
INFO - 2022-06-05 17:01:17 --> Loader Class Initialized
INFO - 2022-06-05 17:01:17 --> Helper loaded: url_helper
INFO - 2022-06-05 17:01:17 --> Database Driver Class Initialized
INFO - 2022-06-05 17:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:01:17 --> Model Class Initialized
DEBUG - 2022-06-05 17:01:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:01:17 --> Model Class Initialized
INFO - 2022-06-05 17:01:17 --> Controller Class Initialized
DEBUG - 2022-06-05 17:01:17 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 17:01:17 --> Severity: Notice --> Trying to get property of non-object N:\Xampp\htdocs\dhired\application\modules\admin\models\Admin_model.php 18
ERROR - 2022-06-05 17:01:17 --> Severity: Error --> Call to a member function affected_rows() on a non-object N:\Xampp\htdocs\dhired\application\modules\admin\models\Admin_model.php 18
INFO - 2022-06-05 17:01:40 --> Config Class Initialized
INFO - 2022-06-05 17:01:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:01:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:01:40 --> Utf8 Class Initialized
INFO - 2022-06-05 17:01:40 --> URI Class Initialized
INFO - 2022-06-05 17:01:40 --> Router Class Initialized
INFO - 2022-06-05 17:01:40 --> Output Class Initialized
INFO - 2022-06-05 17:01:40 --> Security Class Initialized
DEBUG - 2022-06-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:01:40 --> Input Class Initialized
INFO - 2022-06-05 17:01:40 --> Language Class Initialized
INFO - 2022-06-05 17:01:40 --> Language Class Initialized
INFO - 2022-06-05 17:01:40 --> Config Class Initialized
INFO - 2022-06-05 17:01:40 --> Loader Class Initialized
INFO - 2022-06-05 17:01:40 --> Helper loaded: url_helper
INFO - 2022-06-05 17:01:40 --> Database Driver Class Initialized
INFO - 2022-06-05 17:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:01:40 --> Model Class Initialized
DEBUG - 2022-06-05 17:01:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:01:40 --> Model Class Initialized
INFO - 2022-06-05 17:01:40 --> Controller Class Initialized
DEBUG - 2022-06-05 17:01:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:01:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:01:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:01:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:01:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:01:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:01:40 --> Final output sent to browser
DEBUG - 2022-06-05 17:01:40 --> Total execution time: 0.0378
INFO - 2022-06-05 17:01:49 --> Config Class Initialized
INFO - 2022-06-05 17:01:49 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:01:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:01:49 --> Utf8 Class Initialized
INFO - 2022-06-05 17:01:49 --> URI Class Initialized
INFO - 2022-06-05 17:01:49 --> Router Class Initialized
INFO - 2022-06-05 17:01:49 --> Output Class Initialized
INFO - 2022-06-05 17:01:49 --> Security Class Initialized
DEBUG - 2022-06-05 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:01:49 --> Input Class Initialized
INFO - 2022-06-05 17:01:49 --> Language Class Initialized
INFO - 2022-06-05 17:01:49 --> Language Class Initialized
INFO - 2022-06-05 17:01:49 --> Config Class Initialized
INFO - 2022-06-05 17:01:49 --> Loader Class Initialized
INFO - 2022-06-05 17:01:49 --> Helper loaded: url_helper
INFO - 2022-06-05 17:01:49 --> Database Driver Class Initialized
INFO - 2022-06-05 17:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:01:49 --> Model Class Initialized
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:01:49 --> Model Class Initialized
INFO - 2022-06-05 17:01:49 --> Controller Class Initialized
DEBUG - 2022-06-05 17:01:49 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:01:49 --> Config Class Initialized
INFO - 2022-06-05 17:01:49 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:01:49 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:01:49 --> Utf8 Class Initialized
INFO - 2022-06-05 17:01:49 --> URI Class Initialized
INFO - 2022-06-05 17:01:49 --> Router Class Initialized
INFO - 2022-06-05 17:01:49 --> Output Class Initialized
INFO - 2022-06-05 17:01:49 --> Security Class Initialized
DEBUG - 2022-06-05 17:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:01:49 --> Input Class Initialized
INFO - 2022-06-05 17:01:49 --> Language Class Initialized
INFO - 2022-06-05 17:01:49 --> Language Class Initialized
INFO - 2022-06-05 17:01:49 --> Config Class Initialized
INFO - 2022-06-05 17:01:49 --> Loader Class Initialized
INFO - 2022-06-05 17:01:49 --> Helper loaded: url_helper
INFO - 2022-06-05 17:01:49 --> Database Driver Class Initialized
INFO - 2022-06-05 17:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:01:49 --> Model Class Initialized
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:01:49 --> Model Class Initialized
INFO - 2022-06-05 17:01:49 --> Controller Class Initialized
DEBUG - 2022-06-05 17:01:49 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:01:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:01:49 --> Final output sent to browser
DEBUG - 2022-06-05 17:01:49 --> Total execution time: 0.0369
INFO - 2022-06-05 17:03:57 --> Config Class Initialized
INFO - 2022-06-05 17:03:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:03:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:03:57 --> Utf8 Class Initialized
INFO - 2022-06-05 17:03:57 --> URI Class Initialized
INFO - 2022-06-05 17:03:57 --> Router Class Initialized
INFO - 2022-06-05 17:03:57 --> Output Class Initialized
INFO - 2022-06-05 17:03:57 --> Security Class Initialized
DEBUG - 2022-06-05 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:03:57 --> Input Class Initialized
INFO - 2022-06-05 17:03:57 --> Language Class Initialized
INFO - 2022-06-05 17:03:57 --> Language Class Initialized
INFO - 2022-06-05 17:03:57 --> Config Class Initialized
INFO - 2022-06-05 17:03:57 --> Loader Class Initialized
INFO - 2022-06-05 17:03:57 --> Helper loaded: url_helper
INFO - 2022-06-05 17:03:57 --> Database Driver Class Initialized
INFO - 2022-06-05 17:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:03:57 --> Model Class Initialized
DEBUG - 2022-06-05 17:03:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:03:57 --> Model Class Initialized
INFO - 2022-06-05 17:03:57 --> Controller Class Initialized
DEBUG - 2022-06-05 17:03:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:03:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:03:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:03:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:03:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:03:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:03:57 --> Final output sent to browser
DEBUG - 2022-06-05 17:03:57 --> Total execution time: 0.0350
INFO - 2022-06-05 17:04:04 --> Config Class Initialized
INFO - 2022-06-05 17:04:04 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:04:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:04:04 --> Utf8 Class Initialized
INFO - 2022-06-05 17:04:04 --> URI Class Initialized
INFO - 2022-06-05 17:04:04 --> Router Class Initialized
INFO - 2022-06-05 17:04:04 --> Output Class Initialized
INFO - 2022-06-05 17:04:04 --> Security Class Initialized
DEBUG - 2022-06-05 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:04:04 --> Input Class Initialized
INFO - 2022-06-05 17:04:04 --> Language Class Initialized
INFO - 2022-06-05 17:04:04 --> Language Class Initialized
INFO - 2022-06-05 17:04:04 --> Config Class Initialized
INFO - 2022-06-05 17:04:04 --> Loader Class Initialized
INFO - 2022-06-05 17:04:04 --> Helper loaded: url_helper
INFO - 2022-06-05 17:04:04 --> Database Driver Class Initialized
INFO - 2022-06-05 17:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:04:04 --> Model Class Initialized
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:04:04 --> Model Class Initialized
INFO - 2022-06-05 17:04:04 --> Controller Class Initialized
DEBUG - 2022-06-05 17:04:04 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:04:04 --> Config Class Initialized
INFO - 2022-06-05 17:04:04 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:04:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:04:04 --> Utf8 Class Initialized
INFO - 2022-06-05 17:04:04 --> URI Class Initialized
INFO - 2022-06-05 17:04:04 --> Router Class Initialized
INFO - 2022-06-05 17:04:04 --> Output Class Initialized
INFO - 2022-06-05 17:04:04 --> Security Class Initialized
DEBUG - 2022-06-05 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:04:04 --> Input Class Initialized
INFO - 2022-06-05 17:04:04 --> Language Class Initialized
INFO - 2022-06-05 17:04:04 --> Language Class Initialized
INFO - 2022-06-05 17:04:04 --> Config Class Initialized
INFO - 2022-06-05 17:04:04 --> Loader Class Initialized
INFO - 2022-06-05 17:04:04 --> Helper loaded: url_helper
INFO - 2022-06-05 17:04:04 --> Database Driver Class Initialized
INFO - 2022-06-05 17:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:04:04 --> Model Class Initialized
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:04:04 --> Model Class Initialized
INFO - 2022-06-05 17:04:04 --> Controller Class Initialized
DEBUG - 2022-06-05 17:04:04 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:04:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:04:04 --> Final output sent to browser
DEBUG - 2022-06-05 17:04:04 --> Total execution time: 0.0384
INFO - 2022-06-05 17:06:40 --> Config Class Initialized
INFO - 2022-06-05 17:06:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:06:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:06:40 --> Utf8 Class Initialized
INFO - 2022-06-05 17:06:40 --> URI Class Initialized
INFO - 2022-06-05 17:06:40 --> Router Class Initialized
INFO - 2022-06-05 17:06:40 --> Output Class Initialized
INFO - 2022-06-05 17:06:40 --> Security Class Initialized
DEBUG - 2022-06-05 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:06:40 --> Input Class Initialized
INFO - 2022-06-05 17:06:40 --> Language Class Initialized
INFO - 2022-06-05 17:06:40 --> Language Class Initialized
INFO - 2022-06-05 17:06:40 --> Config Class Initialized
INFO - 2022-06-05 17:06:40 --> Loader Class Initialized
INFO - 2022-06-05 17:06:40 --> Helper loaded: url_helper
INFO - 2022-06-05 17:06:40 --> Database Driver Class Initialized
INFO - 2022-06-05 17:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:06:40 --> Model Class Initialized
DEBUG - 2022-06-05 17:06:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:06:40 --> Model Class Initialized
INFO - 2022-06-05 17:06:40 --> Controller Class Initialized
DEBUG - 2022-06-05 17:06:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:06:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:06:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:06:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
INFO - 2022-06-05 17:08:07 --> Config Class Initialized
INFO - 2022-06-05 17:08:07 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:08:07 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:08:07 --> Utf8 Class Initialized
INFO - 2022-06-05 17:08:07 --> URI Class Initialized
INFO - 2022-06-05 17:08:07 --> Router Class Initialized
INFO - 2022-06-05 17:08:07 --> Output Class Initialized
INFO - 2022-06-05 17:08:07 --> Security Class Initialized
DEBUG - 2022-06-05 17:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:08:07 --> Input Class Initialized
INFO - 2022-06-05 17:08:07 --> Language Class Initialized
INFO - 2022-06-05 17:08:07 --> Language Class Initialized
INFO - 2022-06-05 17:08:07 --> Config Class Initialized
INFO - 2022-06-05 17:08:07 --> Loader Class Initialized
INFO - 2022-06-05 17:08:07 --> Helper loaded: url_helper
INFO - 2022-06-05 17:08:07 --> Database Driver Class Initialized
INFO - 2022-06-05 17:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:08:07 --> Model Class Initialized
DEBUG - 2022-06-05 17:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:08:07 --> Model Class Initialized
INFO - 2022-06-05 17:08:07 --> Controller Class Initialized
DEBUG - 2022-06-05 17:08:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:08:07 --> Final output sent to browser
DEBUG - 2022-06-05 17:08:07 --> Total execution time: 0.0382
INFO - 2022-06-05 17:11:58 --> Config Class Initialized
INFO - 2022-06-05 17:11:58 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:11:58 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:11:58 --> Utf8 Class Initialized
INFO - 2022-06-05 17:11:58 --> URI Class Initialized
INFO - 2022-06-05 17:11:58 --> Router Class Initialized
INFO - 2022-06-05 17:11:58 --> Output Class Initialized
INFO - 2022-06-05 17:11:58 --> Security Class Initialized
DEBUG - 2022-06-05 17:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:11:58 --> Input Class Initialized
INFO - 2022-06-05 17:11:58 --> Language Class Initialized
INFO - 2022-06-05 17:11:58 --> Language Class Initialized
INFO - 2022-06-05 17:11:58 --> Config Class Initialized
INFO - 2022-06-05 17:11:58 --> Loader Class Initialized
INFO - 2022-06-05 17:11:58 --> Helper loaded: url_helper
INFO - 2022-06-05 17:11:58 --> Database Driver Class Initialized
INFO - 2022-06-05 17:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:11:59 --> Model Class Initialized
DEBUG - 2022-06-05 17:11:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:11:59 --> Model Class Initialized
INFO - 2022-06-05 17:11:59 --> Controller Class Initialized
DEBUG - 2022-06-05 17:11:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:11:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:11:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:11:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:11:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:11:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:11:59 --> Final output sent to browser
DEBUG - 2022-06-05 17:11:59 --> Total execution time: 0.0426
INFO - 2022-06-05 17:12:01 --> Config Class Initialized
INFO - 2022-06-05 17:12:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:12:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:12:01 --> Utf8 Class Initialized
INFO - 2022-06-05 17:12:01 --> URI Class Initialized
INFO - 2022-06-05 17:12:01 --> Router Class Initialized
INFO - 2022-06-05 17:12:01 --> Output Class Initialized
INFO - 2022-06-05 17:12:01 --> Security Class Initialized
DEBUG - 2022-06-05 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:12:01 --> Input Class Initialized
INFO - 2022-06-05 17:12:01 --> Language Class Initialized
INFO - 2022-06-05 17:12:01 --> Language Class Initialized
INFO - 2022-06-05 17:12:01 --> Config Class Initialized
INFO - 2022-06-05 17:12:01 --> Loader Class Initialized
INFO - 2022-06-05 17:12:01 --> Helper loaded: url_helper
INFO - 2022-06-05 17:12:01 --> Database Driver Class Initialized
INFO - 2022-06-05 17:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:12:01 --> Model Class Initialized
DEBUG - 2022-06-05 17:12:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:12:01 --> Model Class Initialized
INFO - 2022-06-05 17:12:01 --> Controller Class Initialized
DEBUG - 2022-06-05 17:12:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:12:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:12:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:12:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:12:01 --> Severity: Notice --> Undefined variable: c N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 67
ERROR - 2022-06-05 17:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 67
DEBUG - 2022-06-05 17:12:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:12:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:12:01 --> Final output sent to browser
DEBUG - 2022-06-05 17:12:01 --> Total execution time: 0.0342
INFO - 2022-06-05 17:12:08 --> Config Class Initialized
INFO - 2022-06-05 17:12:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:12:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:12:08 --> Utf8 Class Initialized
INFO - 2022-06-05 17:12:08 --> URI Class Initialized
INFO - 2022-06-05 17:12:08 --> Router Class Initialized
INFO - 2022-06-05 17:12:08 --> Output Class Initialized
INFO - 2022-06-05 17:12:08 --> Security Class Initialized
DEBUG - 2022-06-05 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:12:08 --> Input Class Initialized
INFO - 2022-06-05 17:12:08 --> Language Class Initialized
INFO - 2022-06-05 17:12:08 --> Language Class Initialized
INFO - 2022-06-05 17:12:08 --> Config Class Initialized
INFO - 2022-06-05 17:12:08 --> Loader Class Initialized
INFO - 2022-06-05 17:12:08 --> Helper loaded: url_helper
INFO - 2022-06-05 17:12:08 --> Database Driver Class Initialized
INFO - 2022-06-05 17:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:12:08 --> Model Class Initialized
DEBUG - 2022-06-05 17:12:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:12:08 --> Model Class Initialized
INFO - 2022-06-05 17:12:08 --> Controller Class Initialized
DEBUG - 2022-06-05 17:12:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:12:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:12:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:12:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:12:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:12:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:12:08 --> Final output sent to browser
DEBUG - 2022-06-05 17:12:08 --> Total execution time: 0.0382
INFO - 2022-06-05 17:13:46 --> Config Class Initialized
INFO - 2022-06-05 17:13:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:13:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:13:46 --> Utf8 Class Initialized
INFO - 2022-06-05 17:13:46 --> URI Class Initialized
INFO - 2022-06-05 17:13:46 --> Router Class Initialized
INFO - 2022-06-05 17:13:46 --> Output Class Initialized
INFO - 2022-06-05 17:13:46 --> Security Class Initialized
DEBUG - 2022-06-05 17:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:13:46 --> Input Class Initialized
INFO - 2022-06-05 17:13:46 --> Language Class Initialized
INFO - 2022-06-05 17:13:46 --> Language Class Initialized
INFO - 2022-06-05 17:13:46 --> Config Class Initialized
INFO - 2022-06-05 17:13:46 --> Loader Class Initialized
INFO - 2022-06-05 17:13:46 --> Helper loaded: url_helper
INFO - 2022-06-05 17:13:46 --> Database Driver Class Initialized
INFO - 2022-06-05 17:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:13:46 --> Model Class Initialized
DEBUG - 2022-06-05 17:13:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:13:46 --> Model Class Initialized
INFO - 2022-06-05 17:13:46 --> Controller Class Initialized
DEBUG - 2022-06-05 17:13:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:13:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:13:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:13:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:13:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:13:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:13:46 --> Final output sent to browser
DEBUG - 2022-06-05 17:13:46 --> Total execution time: 0.0273
INFO - 2022-06-05 17:13:51 --> Config Class Initialized
INFO - 2022-06-05 17:13:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:13:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:13:51 --> Utf8 Class Initialized
INFO - 2022-06-05 17:13:51 --> URI Class Initialized
INFO - 2022-06-05 17:13:51 --> Router Class Initialized
INFO - 2022-06-05 17:13:51 --> Output Class Initialized
INFO - 2022-06-05 17:13:51 --> Security Class Initialized
DEBUG - 2022-06-05 17:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:13:51 --> Input Class Initialized
INFO - 2022-06-05 17:13:51 --> Language Class Initialized
INFO - 2022-06-05 17:13:51 --> Language Class Initialized
INFO - 2022-06-05 17:13:51 --> Config Class Initialized
INFO - 2022-06-05 17:13:51 --> Loader Class Initialized
INFO - 2022-06-05 17:13:51 --> Helper loaded: url_helper
INFO - 2022-06-05 17:13:51 --> Database Driver Class Initialized
INFO - 2022-06-05 17:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:13:51 --> Model Class Initialized
DEBUG - 2022-06-05 17:13:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:13:51 --> Model Class Initialized
INFO - 2022-06-05 17:13:51 --> Controller Class Initialized
DEBUG - 2022-06-05 17:13:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:13:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:13:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:13:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:13:51 --> Severity: Notice --> Undefined variable: c N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 67
ERROR - 2022-06-05 17:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 67
DEBUG - 2022-06-05 17:13:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:13:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:13:51 --> Final output sent to browser
DEBUG - 2022-06-05 17:13:51 --> Total execution time: 0.0417
INFO - 2022-06-05 17:16:11 --> Config Class Initialized
INFO - 2022-06-05 17:16:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:16:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:16:11 --> Utf8 Class Initialized
INFO - 2022-06-05 17:16:11 --> URI Class Initialized
INFO - 2022-06-05 17:16:11 --> Router Class Initialized
INFO - 2022-06-05 17:16:11 --> Output Class Initialized
INFO - 2022-06-05 17:16:11 --> Security Class Initialized
DEBUG - 2022-06-05 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:16:11 --> Input Class Initialized
INFO - 2022-06-05 17:16:11 --> Language Class Initialized
INFO - 2022-06-05 17:16:11 --> Language Class Initialized
INFO - 2022-06-05 17:16:11 --> Config Class Initialized
INFO - 2022-06-05 17:16:11 --> Loader Class Initialized
INFO - 2022-06-05 17:16:11 --> Helper loaded: url_helper
INFO - 2022-06-05 17:16:11 --> Database Driver Class Initialized
INFO - 2022-06-05 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:16:11 --> Model Class Initialized
DEBUG - 2022-06-05 17:16:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:16:11 --> Model Class Initialized
INFO - 2022-06-05 17:16:11 --> Controller Class Initialized
DEBUG - 2022-06-05 17:16:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:16:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:16:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:16:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:16:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:16:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:16:11 --> Final output sent to browser
DEBUG - 2022-06-05 17:16:11 --> Total execution time: 0.0355
INFO - 2022-06-05 17:17:22 --> Config Class Initialized
INFO - 2022-06-05 17:17:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:17:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:17:22 --> Utf8 Class Initialized
INFO - 2022-06-05 17:17:22 --> URI Class Initialized
INFO - 2022-06-05 17:17:22 --> Router Class Initialized
INFO - 2022-06-05 17:17:22 --> Output Class Initialized
INFO - 2022-06-05 17:17:22 --> Security Class Initialized
DEBUG - 2022-06-05 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:17:22 --> Input Class Initialized
INFO - 2022-06-05 17:17:22 --> Language Class Initialized
INFO - 2022-06-05 17:17:22 --> Language Class Initialized
INFO - 2022-06-05 17:17:22 --> Config Class Initialized
INFO - 2022-06-05 17:17:22 --> Loader Class Initialized
INFO - 2022-06-05 17:17:22 --> Helper loaded: url_helper
INFO - 2022-06-05 17:17:22 --> Database Driver Class Initialized
INFO - 2022-06-05 17:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:17:22 --> Model Class Initialized
DEBUG - 2022-06-05 17:17:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:17:22 --> Model Class Initialized
INFO - 2022-06-05 17:17:22 --> Controller Class Initialized
DEBUG - 2022-06-05 17:17:22 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:17:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:17:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:17:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:17:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:17:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:17:22 --> Final output sent to browser
DEBUG - 2022-06-05 17:17:22 --> Total execution time: 0.0392
INFO - 2022-06-05 17:18:06 --> Config Class Initialized
INFO - 2022-06-05 17:18:06 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:18:06 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:18:06 --> Utf8 Class Initialized
INFO - 2022-06-05 17:18:06 --> URI Class Initialized
INFO - 2022-06-05 17:18:06 --> Router Class Initialized
INFO - 2022-06-05 17:18:06 --> Output Class Initialized
INFO - 2022-06-05 17:18:06 --> Security Class Initialized
DEBUG - 2022-06-05 17:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:18:06 --> Input Class Initialized
INFO - 2022-06-05 17:18:06 --> Language Class Initialized
INFO - 2022-06-05 17:18:06 --> Language Class Initialized
INFO - 2022-06-05 17:18:06 --> Config Class Initialized
INFO - 2022-06-05 17:18:06 --> Loader Class Initialized
INFO - 2022-06-05 17:18:06 --> Helper loaded: url_helper
INFO - 2022-06-05 17:18:06 --> Database Driver Class Initialized
INFO - 2022-06-05 17:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:18:06 --> Model Class Initialized
DEBUG - 2022-06-05 17:18:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:18:06 --> Model Class Initialized
INFO - 2022-06-05 17:18:06 --> Controller Class Initialized
DEBUG - 2022-06-05 17:18:06 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:18:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:18:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:18:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:18:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:18:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:18:06 --> Final output sent to browser
DEBUG - 2022-06-05 17:18:06 --> Total execution time: 0.0364
INFO - 2022-06-05 17:18:15 --> Config Class Initialized
INFO - 2022-06-05 17:18:15 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:18:15 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:18:15 --> Utf8 Class Initialized
INFO - 2022-06-05 17:18:15 --> URI Class Initialized
INFO - 2022-06-05 17:18:15 --> Router Class Initialized
INFO - 2022-06-05 17:18:15 --> Output Class Initialized
INFO - 2022-06-05 17:18:15 --> Security Class Initialized
DEBUG - 2022-06-05 17:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:18:15 --> Input Class Initialized
INFO - 2022-06-05 17:18:15 --> Language Class Initialized
INFO - 2022-06-05 17:18:15 --> Language Class Initialized
INFO - 2022-06-05 17:18:15 --> Config Class Initialized
INFO - 2022-06-05 17:18:15 --> Loader Class Initialized
INFO - 2022-06-05 17:18:15 --> Helper loaded: url_helper
INFO - 2022-06-05 17:18:15 --> Database Driver Class Initialized
INFO - 2022-06-05 17:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:18:15 --> Model Class Initialized
DEBUG - 2022-06-05 17:18:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:18:15 --> Model Class Initialized
INFO - 2022-06-05 17:18:15 --> Controller Class Initialized
DEBUG - 2022-06-05 17:18:15 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:18:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:18:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:18:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:18:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:18:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:18:15 --> Final output sent to browser
DEBUG - 2022-06-05 17:18:15 --> Total execution time: 0.0433
INFO - 2022-06-05 17:18:29 --> Config Class Initialized
INFO - 2022-06-05 17:18:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:18:29 --> Utf8 Class Initialized
INFO - 2022-06-05 17:18:29 --> URI Class Initialized
INFO - 2022-06-05 17:18:29 --> Router Class Initialized
INFO - 2022-06-05 17:18:29 --> Output Class Initialized
INFO - 2022-06-05 17:18:29 --> Security Class Initialized
DEBUG - 2022-06-05 17:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:18:29 --> Input Class Initialized
INFO - 2022-06-05 17:18:29 --> Language Class Initialized
INFO - 2022-06-05 17:18:29 --> Language Class Initialized
INFO - 2022-06-05 17:18:29 --> Config Class Initialized
INFO - 2022-06-05 17:18:29 --> Loader Class Initialized
INFO - 2022-06-05 17:18:29 --> Helper loaded: url_helper
INFO - 2022-06-05 17:18:29 --> Database Driver Class Initialized
INFO - 2022-06-05 17:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:18:29 --> Model Class Initialized
DEBUG - 2022-06-05 17:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:18:29 --> Model Class Initialized
INFO - 2022-06-05 17:18:29 --> Controller Class Initialized
DEBUG - 2022-06-05 17:18:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:18:29 --> Final output sent to browser
DEBUG - 2022-06-05 17:18:29 --> Total execution time: 0.0278
INFO - 2022-06-05 17:18:35 --> Config Class Initialized
INFO - 2022-06-05 17:18:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:18:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:18:35 --> Utf8 Class Initialized
INFO - 2022-06-05 17:18:35 --> URI Class Initialized
INFO - 2022-06-05 17:18:35 --> Router Class Initialized
INFO - 2022-06-05 17:18:35 --> Output Class Initialized
INFO - 2022-06-05 17:18:35 --> Security Class Initialized
DEBUG - 2022-06-05 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:18:35 --> Input Class Initialized
INFO - 2022-06-05 17:18:35 --> Language Class Initialized
INFO - 2022-06-05 17:18:35 --> Language Class Initialized
INFO - 2022-06-05 17:18:35 --> Config Class Initialized
INFO - 2022-06-05 17:18:35 --> Loader Class Initialized
INFO - 2022-06-05 17:18:35 --> Helper loaded: url_helper
INFO - 2022-06-05 17:18:35 --> Database Driver Class Initialized
INFO - 2022-06-05 17:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:18:35 --> Model Class Initialized
DEBUG - 2022-06-05 17:18:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:18:35 --> Model Class Initialized
INFO - 2022-06-05 17:18:35 --> Controller Class Initialized
DEBUG - 2022-06-05 17:18:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:18:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:18:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:18:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:18:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:18:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:18:35 --> Final output sent to browser
DEBUG - 2022-06-05 17:18:35 --> Total execution time: 0.0296
INFO - 2022-06-05 17:19:36 --> Config Class Initialized
INFO - 2022-06-05 17:19:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:19:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:19:36 --> Utf8 Class Initialized
INFO - 2022-06-05 17:19:36 --> URI Class Initialized
INFO - 2022-06-05 17:19:36 --> Router Class Initialized
INFO - 2022-06-05 17:19:36 --> Output Class Initialized
INFO - 2022-06-05 17:19:36 --> Security Class Initialized
DEBUG - 2022-06-05 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:19:36 --> Input Class Initialized
INFO - 2022-06-05 17:19:36 --> Language Class Initialized
INFO - 2022-06-05 17:19:36 --> Language Class Initialized
INFO - 2022-06-05 17:19:36 --> Config Class Initialized
INFO - 2022-06-05 17:19:36 --> Loader Class Initialized
INFO - 2022-06-05 17:19:36 --> Helper loaded: url_helper
INFO - 2022-06-05 17:19:36 --> Database Driver Class Initialized
INFO - 2022-06-05 17:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:19:36 --> Model Class Initialized
DEBUG - 2022-06-05 17:19:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:19:36 --> Model Class Initialized
INFO - 2022-06-05 17:19:36 --> Controller Class Initialized
DEBUG - 2022-06-05 17:19:36 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:19:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:19:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:19:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:19:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:19:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:19:36 --> Final output sent to browser
DEBUG - 2022-06-05 17:19:36 --> Total execution time: 0.0387
INFO - 2022-06-05 17:20:01 --> Config Class Initialized
INFO - 2022-06-05 17:20:01 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:20:01 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:20:01 --> Utf8 Class Initialized
INFO - 2022-06-05 17:20:01 --> URI Class Initialized
INFO - 2022-06-05 17:20:01 --> Router Class Initialized
INFO - 2022-06-05 17:20:01 --> Output Class Initialized
INFO - 2022-06-05 17:20:01 --> Security Class Initialized
DEBUG - 2022-06-05 17:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:20:01 --> Input Class Initialized
INFO - 2022-06-05 17:20:01 --> Language Class Initialized
INFO - 2022-06-05 17:20:01 --> Language Class Initialized
INFO - 2022-06-05 17:20:01 --> Config Class Initialized
INFO - 2022-06-05 17:20:01 --> Loader Class Initialized
INFO - 2022-06-05 17:20:01 --> Helper loaded: url_helper
INFO - 2022-06-05 17:20:01 --> Database Driver Class Initialized
INFO - 2022-06-05 17:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:20:01 --> Model Class Initialized
DEBUG - 2022-06-05 17:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:20:01 --> Model Class Initialized
INFO - 2022-06-05 17:20:01 --> Controller Class Initialized
DEBUG - 2022-06-05 17:20:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:20:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:20:01 --> Final output sent to browser
DEBUG - 2022-06-05 17:20:01 --> Total execution time: 0.0605
INFO - 2022-06-05 17:21:14 --> Config Class Initialized
INFO - 2022-06-05 17:21:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:21:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:21:14 --> Utf8 Class Initialized
INFO - 2022-06-05 17:21:14 --> URI Class Initialized
INFO - 2022-06-05 17:21:14 --> Router Class Initialized
INFO - 2022-06-05 17:21:14 --> Output Class Initialized
INFO - 2022-06-05 17:21:14 --> Security Class Initialized
DEBUG - 2022-06-05 17:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:21:14 --> Input Class Initialized
INFO - 2022-06-05 17:21:14 --> Language Class Initialized
INFO - 2022-06-05 17:21:14 --> Language Class Initialized
INFO - 2022-06-05 17:21:14 --> Config Class Initialized
INFO - 2022-06-05 17:21:14 --> Loader Class Initialized
INFO - 2022-06-05 17:21:14 --> Helper loaded: url_helper
INFO - 2022-06-05 17:21:14 --> Database Driver Class Initialized
INFO - 2022-06-05 17:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:21:14 --> Model Class Initialized
DEBUG - 2022-06-05 17:21:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:21:14 --> Model Class Initialized
INFO - 2022-06-05 17:21:14 --> Controller Class Initialized
ERROR - 2022-06-05 17:21:14 --> 404 Page Not Found: ../modules/admin/controllers/Admin/index.html
INFO - 2022-06-05 17:21:16 --> Config Class Initialized
INFO - 2022-06-05 17:21:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:21:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:21:16 --> Utf8 Class Initialized
INFO - 2022-06-05 17:21:16 --> URI Class Initialized
INFO - 2022-06-05 17:21:16 --> Router Class Initialized
INFO - 2022-06-05 17:21:16 --> Output Class Initialized
INFO - 2022-06-05 17:21:16 --> Security Class Initialized
DEBUG - 2022-06-05 17:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:21:16 --> Input Class Initialized
INFO - 2022-06-05 17:21:16 --> Language Class Initialized
INFO - 2022-06-05 17:21:16 --> Language Class Initialized
INFO - 2022-06-05 17:21:16 --> Config Class Initialized
INFO - 2022-06-05 17:21:16 --> Loader Class Initialized
INFO - 2022-06-05 17:21:16 --> Helper loaded: url_helper
INFO - 2022-06-05 17:21:16 --> Database Driver Class Initialized
INFO - 2022-06-05 17:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:21:16 --> Model Class Initialized
DEBUG - 2022-06-05 17:21:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:21:16 --> Model Class Initialized
INFO - 2022-06-05 17:21:16 --> Controller Class Initialized
DEBUG - 2022-06-05 17:21:16 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:21:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:21:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:21:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:21:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:21:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:21:16 --> Final output sent to browser
DEBUG - 2022-06-05 17:21:16 --> Total execution time: 0.0375
INFO - 2022-06-05 17:21:18 --> Config Class Initialized
INFO - 2022-06-05 17:21:18 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:21:18 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:21:18 --> Utf8 Class Initialized
INFO - 2022-06-05 17:21:18 --> URI Class Initialized
INFO - 2022-06-05 17:21:18 --> Router Class Initialized
INFO - 2022-06-05 17:21:18 --> Output Class Initialized
INFO - 2022-06-05 17:21:18 --> Security Class Initialized
DEBUG - 2022-06-05 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:21:18 --> Input Class Initialized
INFO - 2022-06-05 17:21:18 --> Language Class Initialized
INFO - 2022-06-05 17:21:18 --> Language Class Initialized
INFO - 2022-06-05 17:21:18 --> Config Class Initialized
INFO - 2022-06-05 17:21:18 --> Loader Class Initialized
INFO - 2022-06-05 17:21:18 --> Helper loaded: url_helper
INFO - 2022-06-05 17:21:18 --> Database Driver Class Initialized
INFO - 2022-06-05 17:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:21:18 --> Model Class Initialized
DEBUG - 2022-06-05 17:21:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:21:18 --> Model Class Initialized
INFO - 2022-06-05 17:21:18 --> Controller Class Initialized
DEBUG - 2022-06-05 17:21:18 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:21:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:21:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:21:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:21:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:21:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:21:18 --> Final output sent to browser
DEBUG - 2022-06-05 17:21:18 --> Total execution time: 0.0375
INFO - 2022-06-05 17:21:35 --> Config Class Initialized
INFO - 2022-06-05 17:21:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:21:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:21:35 --> Utf8 Class Initialized
INFO - 2022-06-05 17:21:35 --> URI Class Initialized
INFO - 2022-06-05 17:21:35 --> Router Class Initialized
INFO - 2022-06-05 17:21:35 --> Output Class Initialized
INFO - 2022-06-05 17:21:35 --> Security Class Initialized
DEBUG - 2022-06-05 17:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:21:35 --> Input Class Initialized
INFO - 2022-06-05 17:21:35 --> Language Class Initialized
INFO - 2022-06-05 17:21:35 --> Language Class Initialized
INFO - 2022-06-05 17:21:35 --> Config Class Initialized
INFO - 2022-06-05 17:21:35 --> Loader Class Initialized
INFO - 2022-06-05 17:21:35 --> Helper loaded: url_helper
INFO - 2022-06-05 17:21:35 --> Database Driver Class Initialized
INFO - 2022-06-05 17:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:21:35 --> Model Class Initialized
DEBUG - 2022-06-05 17:21:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:21:35 --> Model Class Initialized
INFO - 2022-06-05 17:21:35 --> Controller Class Initialized
DEBUG - 2022-06-05 17:21:35 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 17:21:35 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `state` (`category_id`, `name`) VALUES ('2', 'Washington ')
INFO - 2022-06-05 17:21:35 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-05 17:22:09 --> Config Class Initialized
INFO - 2022-06-05 17:22:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:22:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:22:09 --> Utf8 Class Initialized
INFO - 2022-06-05 17:22:09 --> URI Class Initialized
INFO - 2022-06-05 17:22:09 --> Router Class Initialized
INFO - 2022-06-05 17:22:09 --> Output Class Initialized
INFO - 2022-06-05 17:22:09 --> Security Class Initialized
DEBUG - 2022-06-05 17:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:22:09 --> Input Class Initialized
INFO - 2022-06-05 17:22:09 --> Language Class Initialized
INFO - 2022-06-05 17:22:09 --> Language Class Initialized
INFO - 2022-06-05 17:22:09 --> Config Class Initialized
INFO - 2022-06-05 17:22:09 --> Loader Class Initialized
INFO - 2022-06-05 17:22:09 --> Helper loaded: url_helper
INFO - 2022-06-05 17:22:09 --> Database Driver Class Initialized
INFO - 2022-06-05 17:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:22:09 --> Model Class Initialized
DEBUG - 2022-06-05 17:22:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:22:09 --> Model Class Initialized
INFO - 2022-06-05 17:22:09 --> Controller Class Initialized
DEBUG - 2022-06-05 17:22:09 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 17:22:09 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `state` (`category_id`, `name`) VALUES ('2', 'Washington ')
INFO - 2022-06-05 17:22:09 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-05 17:22:16 --> Config Class Initialized
INFO - 2022-06-05 17:22:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:22:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:22:16 --> Utf8 Class Initialized
INFO - 2022-06-05 17:22:16 --> URI Class Initialized
INFO - 2022-06-05 17:22:16 --> Router Class Initialized
INFO - 2022-06-05 17:22:16 --> Output Class Initialized
INFO - 2022-06-05 17:22:16 --> Security Class Initialized
DEBUG - 2022-06-05 17:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:22:16 --> Input Class Initialized
INFO - 2022-06-05 17:22:16 --> Language Class Initialized
INFO - 2022-06-05 17:22:16 --> Language Class Initialized
INFO - 2022-06-05 17:22:16 --> Config Class Initialized
INFO - 2022-06-05 17:22:16 --> Loader Class Initialized
INFO - 2022-06-05 17:22:16 --> Helper loaded: url_helper
INFO - 2022-06-05 17:22:16 --> Database Driver Class Initialized
INFO - 2022-06-05 17:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:22:16 --> Model Class Initialized
DEBUG - 2022-06-05 17:22:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:22:16 --> Model Class Initialized
INFO - 2022-06-05 17:22:16 --> Controller Class Initialized
DEBUG - 2022-06-05 17:22:16 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 17:22:16 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `state` (`category_id`, `name`) VALUES ('2', 'Washington ')
INFO - 2022-06-05 17:22:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-05 17:22:25 --> Config Class Initialized
INFO - 2022-06-05 17:22:25 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:22:25 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:22:25 --> Utf8 Class Initialized
INFO - 2022-06-05 17:22:25 --> URI Class Initialized
INFO - 2022-06-05 17:22:25 --> Router Class Initialized
INFO - 2022-06-05 17:22:25 --> Output Class Initialized
INFO - 2022-06-05 17:22:25 --> Security Class Initialized
DEBUG - 2022-06-05 17:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:22:25 --> Input Class Initialized
INFO - 2022-06-05 17:22:25 --> Language Class Initialized
INFO - 2022-06-05 17:22:25 --> Language Class Initialized
INFO - 2022-06-05 17:22:25 --> Config Class Initialized
INFO - 2022-06-05 17:22:25 --> Loader Class Initialized
INFO - 2022-06-05 17:22:25 --> Helper loaded: url_helper
INFO - 2022-06-05 17:22:25 --> Database Driver Class Initialized
INFO - 2022-06-05 17:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:22:25 --> Model Class Initialized
DEBUG - 2022-06-05 17:22:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:22:25 --> Model Class Initialized
INFO - 2022-06-05 17:22:25 --> Controller Class Initialized
DEBUG - 2022-06-05 17:22:25 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:22:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:22:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:22:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:22:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:22:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:22:25 --> Final output sent to browser
DEBUG - 2022-06-05 17:22:25 --> Total execution time: 0.0386
INFO - 2022-06-05 17:22:32 --> Config Class Initialized
INFO - 2022-06-05 17:22:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:22:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:22:32 --> Utf8 Class Initialized
INFO - 2022-06-05 17:22:32 --> URI Class Initialized
INFO - 2022-06-05 17:22:32 --> Router Class Initialized
INFO - 2022-06-05 17:22:32 --> Output Class Initialized
INFO - 2022-06-05 17:22:32 --> Security Class Initialized
DEBUG - 2022-06-05 17:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:22:32 --> Input Class Initialized
INFO - 2022-06-05 17:22:32 --> Language Class Initialized
INFO - 2022-06-05 17:22:32 --> Language Class Initialized
INFO - 2022-06-05 17:22:32 --> Config Class Initialized
INFO - 2022-06-05 17:22:32 --> Loader Class Initialized
INFO - 2022-06-05 17:22:32 --> Helper loaded: url_helper
INFO - 2022-06-05 17:22:32 --> Database Driver Class Initialized
INFO - 2022-06-05 17:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:22:32 --> Model Class Initialized
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:22:32 --> Model Class Initialized
INFO - 2022-06-05 17:22:32 --> Controller Class Initialized
DEBUG - 2022-06-05 17:22:32 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:22:32 --> Config Class Initialized
INFO - 2022-06-05 17:22:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:22:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:22:32 --> Utf8 Class Initialized
INFO - 2022-06-05 17:22:32 --> URI Class Initialized
INFO - 2022-06-05 17:22:32 --> Router Class Initialized
INFO - 2022-06-05 17:22:32 --> Output Class Initialized
INFO - 2022-06-05 17:22:32 --> Security Class Initialized
DEBUG - 2022-06-05 17:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:22:32 --> Input Class Initialized
INFO - 2022-06-05 17:22:32 --> Language Class Initialized
INFO - 2022-06-05 17:22:32 --> Language Class Initialized
INFO - 2022-06-05 17:22:32 --> Config Class Initialized
INFO - 2022-06-05 17:22:32 --> Loader Class Initialized
INFO - 2022-06-05 17:22:32 --> Helper loaded: url_helper
INFO - 2022-06-05 17:22:32 --> Database Driver Class Initialized
INFO - 2022-06-05 17:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:22:32 --> Model Class Initialized
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:22:32 --> Model Class Initialized
INFO - 2022-06-05 17:22:32 --> Controller Class Initialized
DEBUG - 2022-06-05 17:22:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:22:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:22:32 --> Final output sent to browser
DEBUG - 2022-06-05 17:22:32 --> Total execution time: 0.0376
INFO - 2022-06-05 17:27:18 --> Config Class Initialized
INFO - 2022-06-05 17:27:18 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:27:18 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:27:18 --> Utf8 Class Initialized
INFO - 2022-06-05 17:27:18 --> URI Class Initialized
INFO - 2022-06-05 17:27:18 --> Router Class Initialized
INFO - 2022-06-05 17:27:18 --> Output Class Initialized
INFO - 2022-06-05 17:27:18 --> Security Class Initialized
DEBUG - 2022-06-05 17:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:27:18 --> Input Class Initialized
INFO - 2022-06-05 17:27:18 --> Language Class Initialized
INFO - 2022-06-05 17:27:18 --> Language Class Initialized
INFO - 2022-06-05 17:27:18 --> Config Class Initialized
INFO - 2022-06-05 17:27:18 --> Loader Class Initialized
INFO - 2022-06-05 17:27:18 --> Helper loaded: url_helper
INFO - 2022-06-05 17:27:18 --> Database Driver Class Initialized
INFO - 2022-06-05 17:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:27:18 --> Model Class Initialized
DEBUG - 2022-06-05 17:27:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:27:18 --> Model Class Initialized
INFO - 2022-06-05 17:27:18 --> Controller Class Initialized
DEBUG - 2022-06-05 17:27:18 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:27:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:27:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:27:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:27:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:27:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:27:18 --> Final output sent to browser
DEBUG - 2022-06-05 17:27:18 --> Total execution time: 0.0406
INFO - 2022-06-05 17:27:28 --> Config Class Initialized
INFO - 2022-06-05 17:27:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:27:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:27:28 --> Utf8 Class Initialized
INFO - 2022-06-05 17:27:28 --> URI Class Initialized
INFO - 2022-06-05 17:27:28 --> Router Class Initialized
INFO - 2022-06-05 17:27:28 --> Output Class Initialized
INFO - 2022-06-05 17:27:28 --> Security Class Initialized
DEBUG - 2022-06-05 17:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:27:28 --> Input Class Initialized
INFO - 2022-06-05 17:27:28 --> Language Class Initialized
INFO - 2022-06-05 17:27:28 --> Language Class Initialized
INFO - 2022-06-05 17:27:28 --> Config Class Initialized
INFO - 2022-06-05 17:27:28 --> Loader Class Initialized
INFO - 2022-06-05 17:27:28 --> Helper loaded: url_helper
INFO - 2022-06-05 17:27:28 --> Database Driver Class Initialized
INFO - 2022-06-05 17:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:27:28 --> Model Class Initialized
DEBUG - 2022-06-05 17:27:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:27:28 --> Model Class Initialized
INFO - 2022-06-05 17:27:28 --> Controller Class Initialized
DEBUG - 2022-06-05 17:27:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:27:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:27:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:27:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
INFO - 2022-06-05 17:28:00 --> Config Class Initialized
INFO - 2022-06-05 17:28:00 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:28:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:28:00 --> Utf8 Class Initialized
INFO - 2022-06-05 17:28:00 --> URI Class Initialized
INFO - 2022-06-05 17:28:00 --> Router Class Initialized
INFO - 2022-06-05 17:28:00 --> Output Class Initialized
INFO - 2022-06-05 17:28:00 --> Security Class Initialized
DEBUG - 2022-06-05 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:28:00 --> Input Class Initialized
INFO - 2022-06-05 17:28:00 --> Language Class Initialized
INFO - 2022-06-05 17:28:00 --> Language Class Initialized
INFO - 2022-06-05 17:28:00 --> Config Class Initialized
INFO - 2022-06-05 17:28:00 --> Loader Class Initialized
INFO - 2022-06-05 17:28:00 --> Helper loaded: url_helper
INFO - 2022-06-05 17:28:00 --> Database Driver Class Initialized
INFO - 2022-06-05 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:28:00 --> Model Class Initialized
DEBUG - 2022-06-05 17:28:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:28:00 --> Model Class Initialized
INFO - 2022-06-05 17:28:00 --> Controller Class Initialized
DEBUG - 2022-06-05 17:28:00 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:28:11 --> Config Class Initialized
INFO - 2022-06-05 17:28:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:28:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:28:11 --> Utf8 Class Initialized
INFO - 2022-06-05 17:28:11 --> URI Class Initialized
INFO - 2022-06-05 17:28:11 --> Router Class Initialized
INFO - 2022-06-05 17:28:11 --> Output Class Initialized
INFO - 2022-06-05 17:28:11 --> Security Class Initialized
DEBUG - 2022-06-05 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:28:11 --> Input Class Initialized
INFO - 2022-06-05 17:28:11 --> Language Class Initialized
INFO - 2022-06-05 17:28:11 --> Language Class Initialized
INFO - 2022-06-05 17:28:11 --> Config Class Initialized
INFO - 2022-06-05 17:28:11 --> Loader Class Initialized
INFO - 2022-06-05 17:28:11 --> Helper loaded: url_helper
INFO - 2022-06-05 17:28:11 --> Database Driver Class Initialized
INFO - 2022-06-05 17:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:28:11 --> Model Class Initialized
DEBUG - 2022-06-05 17:28:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:28:11 --> Model Class Initialized
INFO - 2022-06-05 17:28:11 --> Controller Class Initialized
DEBUG - 2022-06-05 17:28:11 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:28:50 --> Config Class Initialized
INFO - 2022-06-05 17:28:50 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:28:50 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:28:50 --> Utf8 Class Initialized
INFO - 2022-06-05 17:28:50 --> URI Class Initialized
INFO - 2022-06-05 17:28:50 --> Router Class Initialized
INFO - 2022-06-05 17:28:50 --> Output Class Initialized
INFO - 2022-06-05 17:28:50 --> Security Class Initialized
DEBUG - 2022-06-05 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:28:50 --> Input Class Initialized
INFO - 2022-06-05 17:28:50 --> Language Class Initialized
INFO - 2022-06-05 17:28:50 --> Language Class Initialized
INFO - 2022-06-05 17:28:50 --> Config Class Initialized
INFO - 2022-06-05 17:28:50 --> Loader Class Initialized
INFO - 2022-06-05 17:28:50 --> Helper loaded: url_helper
INFO - 2022-06-05 17:28:50 --> Database Driver Class Initialized
INFO - 2022-06-05 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:28:50 --> Model Class Initialized
DEBUG - 2022-06-05 17:28:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:28:50 --> Model Class Initialized
INFO - 2022-06-05 17:28:50 --> Controller Class Initialized
DEBUG - 2022-06-05 17:28:50 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:28:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:28:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:28:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
INFO - 2022-06-05 17:29:12 --> Config Class Initialized
INFO - 2022-06-05 17:29:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:12 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:12 --> URI Class Initialized
INFO - 2022-06-05 17:29:12 --> Router Class Initialized
INFO - 2022-06-05 17:29:12 --> Output Class Initialized
INFO - 2022-06-05 17:29:12 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:12 --> Input Class Initialized
INFO - 2022-06-05 17:29:12 --> Language Class Initialized
INFO - 2022-06-05 17:29:12 --> Language Class Initialized
INFO - 2022-06-05 17:29:12 --> Config Class Initialized
INFO - 2022-06-05 17:29:12 --> Loader Class Initialized
INFO - 2022-06-05 17:29:12 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:12 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:12 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:12 --> Model Class Initialized
INFO - 2022-06-05 17:29:12 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:29:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:29:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:29:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
INFO - 2022-06-05 17:29:18 --> Config Class Initialized
INFO - 2022-06-05 17:29:18 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:18 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:18 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:18 --> URI Class Initialized
INFO - 2022-06-05 17:29:18 --> Router Class Initialized
INFO - 2022-06-05 17:29:18 --> Output Class Initialized
INFO - 2022-06-05 17:29:18 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:18 --> Input Class Initialized
INFO - 2022-06-05 17:29:18 --> Language Class Initialized
INFO - 2022-06-05 17:29:18 --> Language Class Initialized
INFO - 2022-06-05 17:29:18 --> Config Class Initialized
INFO - 2022-06-05 17:29:18 --> Loader Class Initialized
INFO - 2022-06-05 17:29:18 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:18 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:18 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:18 --> Model Class Initialized
INFO - 2022-06-05 17:29:18 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:18 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:29:18 --> Final output sent to browser
DEBUG - 2022-06-05 17:29:18 --> Total execution time: 0.0273
INFO - 2022-06-05 17:29:29 --> Config Class Initialized
INFO - 2022-06-05 17:29:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:29 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:29 --> URI Class Initialized
INFO - 2022-06-05 17:29:29 --> Router Class Initialized
INFO - 2022-06-05 17:29:29 --> Output Class Initialized
INFO - 2022-06-05 17:29:29 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:29 --> Input Class Initialized
INFO - 2022-06-05 17:29:29 --> Language Class Initialized
INFO - 2022-06-05 17:29:29 --> Language Class Initialized
INFO - 2022-06-05 17:29:29 --> Config Class Initialized
INFO - 2022-06-05 17:29:29 --> Loader Class Initialized
INFO - 2022-06-05 17:29:29 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:29 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:29 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:29 --> Model Class Initialized
INFO - 2022-06-05 17:29:29 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:29 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:29:29 --> Config Class Initialized
INFO - 2022-06-05 17:29:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:29 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:29 --> URI Class Initialized
INFO - 2022-06-05 17:29:29 --> Router Class Initialized
INFO - 2022-06-05 17:29:29 --> Output Class Initialized
INFO - 2022-06-05 17:29:29 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:29 --> Input Class Initialized
INFO - 2022-06-05 17:29:29 --> Language Class Initialized
INFO - 2022-06-05 17:29:29 --> Language Class Initialized
INFO - 2022-06-05 17:29:29 --> Config Class Initialized
INFO - 2022-06-05 17:29:29 --> Loader Class Initialized
INFO - 2022-06-05 17:29:29 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:29 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:29 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:29 --> Model Class Initialized
INFO - 2022-06-05 17:29:29 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:29:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:29:29 --> Final output sent to browser
DEBUG - 2022-06-05 17:29:29 --> Total execution time: 0.0313
INFO - 2022-06-05 17:29:44 --> Config Class Initialized
INFO - 2022-06-05 17:29:44 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:44 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:44 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:44 --> URI Class Initialized
INFO - 2022-06-05 17:29:44 --> Router Class Initialized
INFO - 2022-06-05 17:29:44 --> Output Class Initialized
INFO - 2022-06-05 17:29:44 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:44 --> Input Class Initialized
INFO - 2022-06-05 17:29:44 --> Language Class Initialized
INFO - 2022-06-05 17:29:44 --> Language Class Initialized
INFO - 2022-06-05 17:29:44 --> Config Class Initialized
INFO - 2022-06-05 17:29:44 --> Loader Class Initialized
INFO - 2022-06-05 17:29:44 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:44 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:44 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:44 --> Model Class Initialized
INFO - 2022-06-05 17:29:44 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:44 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:29:44 --> Config Class Initialized
INFO - 2022-06-05 17:29:44 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:44 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:44 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:44 --> URI Class Initialized
INFO - 2022-06-05 17:29:44 --> Router Class Initialized
INFO - 2022-06-05 17:29:44 --> Output Class Initialized
INFO - 2022-06-05 17:29:44 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:44 --> Input Class Initialized
INFO - 2022-06-05 17:29:44 --> Language Class Initialized
INFO - 2022-06-05 17:29:44 --> Language Class Initialized
INFO - 2022-06-05 17:29:44 --> Config Class Initialized
INFO - 2022-06-05 17:29:44 --> Loader Class Initialized
INFO - 2022-06-05 17:29:44 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:44 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:44 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:44 --> Model Class Initialized
INFO - 2022-06-05 17:29:44 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:44 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:29:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:29:44 --> Final output sent to browser
DEBUG - 2022-06-05 17:29:44 --> Total execution time: 0.0416
INFO - 2022-06-05 17:29:54 --> Config Class Initialized
INFO - 2022-06-05 17:29:54 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:29:54 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:29:54 --> Utf8 Class Initialized
INFO - 2022-06-05 17:29:54 --> URI Class Initialized
INFO - 2022-06-05 17:29:54 --> Router Class Initialized
INFO - 2022-06-05 17:29:54 --> Output Class Initialized
INFO - 2022-06-05 17:29:54 --> Security Class Initialized
DEBUG - 2022-06-05 17:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:29:54 --> Input Class Initialized
INFO - 2022-06-05 17:29:54 --> Language Class Initialized
INFO - 2022-06-05 17:29:54 --> Language Class Initialized
INFO - 2022-06-05 17:29:54 --> Config Class Initialized
INFO - 2022-06-05 17:29:54 --> Loader Class Initialized
INFO - 2022-06-05 17:29:54 --> Helper loaded: url_helper
INFO - 2022-06-05 17:29:54 --> Database Driver Class Initialized
INFO - 2022-06-05 17:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:29:54 --> Model Class Initialized
DEBUG - 2022-06-05 17:29:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:29:54 --> Model Class Initialized
INFO - 2022-06-05 17:29:54 --> Controller Class Initialized
DEBUG - 2022-06-05 17:29:54 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:29:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:29:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:29:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:29:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:29:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:29:54 --> Final output sent to browser
DEBUG - 2022-06-05 17:29:54 --> Total execution time: 0.0408
INFO - 2022-06-05 17:30:09 --> Config Class Initialized
INFO - 2022-06-05 17:30:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:30:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:30:09 --> Utf8 Class Initialized
INFO - 2022-06-05 17:30:09 --> URI Class Initialized
INFO - 2022-06-05 17:30:09 --> Router Class Initialized
INFO - 2022-06-05 17:30:09 --> Output Class Initialized
INFO - 2022-06-05 17:30:09 --> Security Class Initialized
DEBUG - 2022-06-05 17:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:30:09 --> Input Class Initialized
INFO - 2022-06-05 17:30:09 --> Language Class Initialized
INFO - 2022-06-05 17:30:09 --> Language Class Initialized
INFO - 2022-06-05 17:30:09 --> Config Class Initialized
INFO - 2022-06-05 17:30:09 --> Loader Class Initialized
INFO - 2022-06-05 17:30:09 --> Helper loaded: url_helper
INFO - 2022-06-05 17:30:09 --> Database Driver Class Initialized
INFO - 2022-06-05 17:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:30:09 --> Model Class Initialized
DEBUG - 2022-06-05 17:30:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:30:09 --> Model Class Initialized
INFO - 2022-06-05 17:30:09 --> Controller Class Initialized
DEBUG - 2022-06-05 17:30:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:30:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:30:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:30:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
INFO - 2022-06-05 17:30:28 --> Config Class Initialized
INFO - 2022-06-05 17:30:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:30:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:30:28 --> Utf8 Class Initialized
INFO - 2022-06-05 17:30:28 --> URI Class Initialized
INFO - 2022-06-05 17:30:28 --> Router Class Initialized
INFO - 2022-06-05 17:30:28 --> Output Class Initialized
INFO - 2022-06-05 17:30:28 --> Security Class Initialized
DEBUG - 2022-06-05 17:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:30:28 --> Input Class Initialized
INFO - 2022-06-05 17:30:28 --> Language Class Initialized
INFO - 2022-06-05 17:30:28 --> Language Class Initialized
INFO - 2022-06-05 17:30:28 --> Config Class Initialized
INFO - 2022-06-05 17:30:28 --> Loader Class Initialized
INFO - 2022-06-05 17:30:28 --> Helper loaded: url_helper
INFO - 2022-06-05 17:30:28 --> Database Driver Class Initialized
INFO - 2022-06-05 17:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:30:28 --> Model Class Initialized
DEBUG - 2022-06-05 17:30:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:30:28 --> Model Class Initialized
INFO - 2022-06-05 17:30:28 --> Controller Class Initialized
DEBUG - 2022-06-05 17:30:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:30:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:30:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:30:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
INFO - 2022-06-05 17:30:41 --> Config Class Initialized
INFO - 2022-06-05 17:30:41 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:30:41 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:30:41 --> Utf8 Class Initialized
INFO - 2022-06-05 17:30:41 --> URI Class Initialized
INFO - 2022-06-05 17:30:41 --> Router Class Initialized
INFO - 2022-06-05 17:30:41 --> Output Class Initialized
INFO - 2022-06-05 17:30:41 --> Security Class Initialized
DEBUG - 2022-06-05 17:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:30:41 --> Input Class Initialized
INFO - 2022-06-05 17:30:41 --> Language Class Initialized
INFO - 2022-06-05 17:30:41 --> Language Class Initialized
INFO - 2022-06-05 17:30:41 --> Config Class Initialized
INFO - 2022-06-05 17:30:41 --> Loader Class Initialized
INFO - 2022-06-05 17:30:41 --> Helper loaded: url_helper
INFO - 2022-06-05 17:30:41 --> Database Driver Class Initialized
INFO - 2022-06-05 17:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:30:41 --> Model Class Initialized
DEBUG - 2022-06-05 17:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:30:41 --> Model Class Initialized
INFO - 2022-06-05 17:30:41 --> Controller Class Initialized
DEBUG - 2022-06-05 17:30:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:30:41 --> Final output sent to browser
DEBUG - 2022-06-05 17:30:41 --> Total execution time: 0.0370
INFO - 2022-06-05 17:31:32 --> Config Class Initialized
INFO - 2022-06-05 17:31:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:31:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:31:32 --> Utf8 Class Initialized
INFO - 2022-06-05 17:31:32 --> URI Class Initialized
INFO - 2022-06-05 17:31:32 --> Router Class Initialized
INFO - 2022-06-05 17:31:32 --> Output Class Initialized
INFO - 2022-06-05 17:31:32 --> Security Class Initialized
DEBUG - 2022-06-05 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:31:32 --> Input Class Initialized
INFO - 2022-06-05 17:31:32 --> Language Class Initialized
INFO - 2022-06-05 17:31:32 --> Language Class Initialized
INFO - 2022-06-05 17:31:32 --> Config Class Initialized
INFO - 2022-06-05 17:31:32 --> Loader Class Initialized
INFO - 2022-06-05 17:31:32 --> Helper loaded: url_helper
INFO - 2022-06-05 17:31:32 --> Database Driver Class Initialized
INFO - 2022-06-05 17:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:31:32 --> Model Class Initialized
DEBUG - 2022-06-05 17:31:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:31:32 --> Model Class Initialized
INFO - 2022-06-05 17:31:32 --> Controller Class Initialized
DEBUG - 2022-06-05 17:31:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:31:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:31:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:31:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:31:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:31:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:31:32 --> Final output sent to browser
DEBUG - 2022-06-05 17:31:32 --> Total execution time: 0.0443
INFO - 2022-06-05 17:31:47 --> Config Class Initialized
INFO - 2022-06-05 17:31:47 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:31:47 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:31:47 --> Utf8 Class Initialized
INFO - 2022-06-05 17:31:47 --> URI Class Initialized
INFO - 2022-06-05 17:31:47 --> Router Class Initialized
INFO - 2022-06-05 17:31:47 --> Output Class Initialized
INFO - 2022-06-05 17:31:47 --> Security Class Initialized
DEBUG - 2022-06-05 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:31:47 --> Input Class Initialized
INFO - 2022-06-05 17:31:47 --> Language Class Initialized
INFO - 2022-06-05 17:31:47 --> Language Class Initialized
INFO - 2022-06-05 17:31:47 --> Config Class Initialized
INFO - 2022-06-05 17:31:47 --> Loader Class Initialized
INFO - 2022-06-05 17:31:47 --> Helper loaded: url_helper
INFO - 2022-06-05 17:31:47 --> Database Driver Class Initialized
INFO - 2022-06-05 17:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:31:47 --> Model Class Initialized
DEBUG - 2022-06-05 17:31:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:31:47 --> Model Class Initialized
INFO - 2022-06-05 17:31:47 --> Controller Class Initialized
DEBUG - 2022-06-05 17:31:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:31:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:31:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:31:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:31:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:31:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:31:47 --> Final output sent to browser
DEBUG - 2022-06-05 17:31:47 --> Total execution time: 0.0300
INFO - 2022-06-05 17:32:11 --> Config Class Initialized
INFO - 2022-06-05 17:32:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:32:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:32:11 --> Utf8 Class Initialized
INFO - 2022-06-05 17:32:11 --> URI Class Initialized
INFO - 2022-06-05 17:32:11 --> Router Class Initialized
INFO - 2022-06-05 17:32:11 --> Output Class Initialized
INFO - 2022-06-05 17:32:11 --> Security Class Initialized
DEBUG - 2022-06-05 17:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:32:11 --> Input Class Initialized
INFO - 2022-06-05 17:32:11 --> Language Class Initialized
INFO - 2022-06-05 17:32:11 --> Language Class Initialized
INFO - 2022-06-05 17:32:11 --> Config Class Initialized
INFO - 2022-06-05 17:32:11 --> Loader Class Initialized
INFO - 2022-06-05 17:32:11 --> Helper loaded: url_helper
INFO - 2022-06-05 17:32:11 --> Database Driver Class Initialized
INFO - 2022-06-05 17:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:32:11 --> Model Class Initialized
DEBUG - 2022-06-05 17:32:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:32:11 --> Model Class Initialized
INFO - 2022-06-05 17:32:11 --> Controller Class Initialized
DEBUG - 2022-06-05 17:32:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:32:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:32:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:32:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:32:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:32:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:32:11 --> Final output sent to browser
DEBUG - 2022-06-05 17:32:11 --> Total execution time: 0.0445
INFO - 2022-06-05 17:32:12 --> Config Class Initialized
INFO - 2022-06-05 17:32:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:32:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:32:12 --> Utf8 Class Initialized
INFO - 2022-06-05 17:32:12 --> URI Class Initialized
INFO - 2022-06-05 17:32:12 --> Router Class Initialized
INFO - 2022-06-05 17:32:12 --> Output Class Initialized
INFO - 2022-06-05 17:32:12 --> Security Class Initialized
DEBUG - 2022-06-05 17:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:32:12 --> Input Class Initialized
INFO - 2022-06-05 17:32:12 --> Language Class Initialized
INFO - 2022-06-05 17:32:12 --> Language Class Initialized
INFO - 2022-06-05 17:32:12 --> Config Class Initialized
INFO - 2022-06-05 17:32:12 --> Loader Class Initialized
INFO - 2022-06-05 17:32:12 --> Helper loaded: url_helper
INFO - 2022-06-05 17:32:12 --> Database Driver Class Initialized
INFO - 2022-06-05 17:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:32:12 --> Model Class Initialized
DEBUG - 2022-06-05 17:32:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:32:12 --> Model Class Initialized
INFO - 2022-06-05 17:32:12 --> Controller Class Initialized
DEBUG - 2022-06-05 17:32:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:32:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:32:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:32:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:32:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:32:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:32:12 --> Final output sent to browser
DEBUG - 2022-06-05 17:32:12 --> Total execution time: 0.0359
INFO - 2022-06-05 17:32:14 --> Config Class Initialized
INFO - 2022-06-05 17:32:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:32:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:32:14 --> Utf8 Class Initialized
INFO - 2022-06-05 17:32:14 --> URI Class Initialized
INFO - 2022-06-05 17:32:14 --> Router Class Initialized
INFO - 2022-06-05 17:32:14 --> Output Class Initialized
INFO - 2022-06-05 17:32:14 --> Security Class Initialized
DEBUG - 2022-06-05 17:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:32:14 --> Input Class Initialized
INFO - 2022-06-05 17:32:14 --> Language Class Initialized
INFO - 2022-06-05 17:32:14 --> Language Class Initialized
INFO - 2022-06-05 17:32:14 --> Config Class Initialized
INFO - 2022-06-05 17:32:14 --> Loader Class Initialized
INFO - 2022-06-05 17:32:14 --> Helper loaded: url_helper
INFO - 2022-06-05 17:32:14 --> Database Driver Class Initialized
INFO - 2022-06-05 17:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:32:14 --> Model Class Initialized
DEBUG - 2022-06-05 17:32:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:32:14 --> Model Class Initialized
INFO - 2022-06-05 17:32:14 --> Controller Class Initialized
DEBUG - 2022-06-05 17:32:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:32:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:32:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:32:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:32:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:32:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:32:14 --> Final output sent to browser
DEBUG - 2022-06-05 17:32:14 --> Total execution time: 0.0394
INFO - 2022-06-05 17:33:37 --> Config Class Initialized
INFO - 2022-06-05 17:33:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:33:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:33:37 --> Utf8 Class Initialized
INFO - 2022-06-05 17:33:37 --> URI Class Initialized
INFO - 2022-06-05 17:33:37 --> Router Class Initialized
INFO - 2022-06-05 17:33:37 --> Output Class Initialized
INFO - 2022-06-05 17:33:37 --> Security Class Initialized
DEBUG - 2022-06-05 17:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:33:37 --> Input Class Initialized
INFO - 2022-06-05 17:33:37 --> Language Class Initialized
INFO - 2022-06-05 17:33:37 --> Language Class Initialized
INFO - 2022-06-05 17:33:37 --> Config Class Initialized
INFO - 2022-06-05 17:33:37 --> Loader Class Initialized
INFO - 2022-06-05 17:33:37 --> Helper loaded: url_helper
INFO - 2022-06-05 17:33:37 --> Database Driver Class Initialized
INFO - 2022-06-05 17:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:33:37 --> Model Class Initialized
DEBUG - 2022-06-05 17:33:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:33:37 --> Model Class Initialized
INFO - 2022-06-05 17:33:37 --> Controller Class Initialized
DEBUG - 2022-06-05 17:33:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:33:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:33:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:33:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:33:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:33:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:33:37 --> Final output sent to browser
DEBUG - 2022-06-05 17:33:37 --> Total execution time: 0.0403
INFO - 2022-06-05 17:33:45 --> Config Class Initialized
INFO - 2022-06-05 17:33:45 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:33:45 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:33:45 --> Utf8 Class Initialized
INFO - 2022-06-05 17:33:45 --> URI Class Initialized
INFO - 2022-06-05 17:33:45 --> Router Class Initialized
INFO - 2022-06-05 17:33:45 --> Output Class Initialized
INFO - 2022-06-05 17:33:45 --> Security Class Initialized
DEBUG - 2022-06-05 17:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:33:45 --> Input Class Initialized
INFO - 2022-06-05 17:33:45 --> Language Class Initialized
INFO - 2022-06-05 17:33:45 --> Language Class Initialized
INFO - 2022-06-05 17:33:45 --> Config Class Initialized
INFO - 2022-06-05 17:33:45 --> Loader Class Initialized
INFO - 2022-06-05 17:33:45 --> Helper loaded: url_helper
INFO - 2022-06-05 17:33:45 --> Database Driver Class Initialized
INFO - 2022-06-05 17:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:33:45 --> Model Class Initialized
DEBUG - 2022-06-05 17:33:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:33:45 --> Model Class Initialized
INFO - 2022-06-05 17:33:45 --> Controller Class Initialized
DEBUG - 2022-06-05 17:33:45 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:33:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:33:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:33:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:33:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:33:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:33:45 --> Final output sent to browser
DEBUG - 2022-06-05 17:33:45 --> Total execution time: 0.0401
INFO - 2022-06-05 17:34:11 --> Config Class Initialized
INFO - 2022-06-05 17:34:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:34:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:34:11 --> Utf8 Class Initialized
INFO - 2022-06-05 17:34:11 --> URI Class Initialized
INFO - 2022-06-05 17:34:11 --> Router Class Initialized
INFO - 2022-06-05 17:34:11 --> Output Class Initialized
INFO - 2022-06-05 17:34:11 --> Security Class Initialized
DEBUG - 2022-06-05 17:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:34:11 --> Input Class Initialized
INFO - 2022-06-05 17:34:11 --> Language Class Initialized
INFO - 2022-06-05 17:34:11 --> Language Class Initialized
INFO - 2022-06-05 17:34:11 --> Config Class Initialized
INFO - 2022-06-05 17:34:11 --> Loader Class Initialized
INFO - 2022-06-05 17:34:11 --> Helper loaded: url_helper
INFO - 2022-06-05 17:34:11 --> Database Driver Class Initialized
INFO - 2022-06-05 17:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:34:11 --> Model Class Initialized
DEBUG - 2022-06-05 17:34:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:34:11 --> Model Class Initialized
INFO - 2022-06-05 17:34:11 --> Controller Class Initialized
DEBUG - 2022-06-05 17:34:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:34:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:34:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:34:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:34:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:34:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:34:11 --> Final output sent to browser
DEBUG - 2022-06-05 17:34:11 --> Total execution time: 0.0441
INFO - 2022-06-05 17:34:32 --> Config Class Initialized
INFO - 2022-06-05 17:34:32 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:34:32 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:34:32 --> Utf8 Class Initialized
INFO - 2022-06-05 17:34:32 --> URI Class Initialized
INFO - 2022-06-05 17:34:32 --> Router Class Initialized
INFO - 2022-06-05 17:34:32 --> Output Class Initialized
INFO - 2022-06-05 17:34:32 --> Security Class Initialized
DEBUG - 2022-06-05 17:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:34:32 --> Input Class Initialized
INFO - 2022-06-05 17:34:32 --> Language Class Initialized
INFO - 2022-06-05 17:34:32 --> Language Class Initialized
INFO - 2022-06-05 17:34:32 --> Config Class Initialized
INFO - 2022-06-05 17:34:32 --> Loader Class Initialized
INFO - 2022-06-05 17:34:32 --> Helper loaded: url_helper
INFO - 2022-06-05 17:34:32 --> Database Driver Class Initialized
INFO - 2022-06-05 17:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:34:32 --> Model Class Initialized
DEBUG - 2022-06-05 17:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:34:32 --> Model Class Initialized
INFO - 2022-06-05 17:34:32 --> Controller Class Initialized
DEBUG - 2022-06-05 17:34:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:34:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:34:32 --> Final output sent to browser
DEBUG - 2022-06-05 17:34:32 --> Total execution time: 0.0388
INFO - 2022-06-05 17:34:37 --> Config Class Initialized
INFO - 2022-06-05 17:34:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:34:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:34:37 --> Utf8 Class Initialized
INFO - 2022-06-05 17:34:37 --> URI Class Initialized
INFO - 2022-06-05 17:34:37 --> Router Class Initialized
INFO - 2022-06-05 17:34:37 --> Output Class Initialized
INFO - 2022-06-05 17:34:37 --> Security Class Initialized
DEBUG - 2022-06-05 17:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:34:37 --> Input Class Initialized
INFO - 2022-06-05 17:34:37 --> Language Class Initialized
INFO - 2022-06-05 17:34:37 --> Language Class Initialized
INFO - 2022-06-05 17:34:37 --> Config Class Initialized
INFO - 2022-06-05 17:34:37 --> Loader Class Initialized
INFO - 2022-06-05 17:34:37 --> Helper loaded: url_helper
INFO - 2022-06-05 17:34:37 --> Database Driver Class Initialized
INFO - 2022-06-05 17:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:34:37 --> Model Class Initialized
DEBUG - 2022-06-05 17:34:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:34:37 --> Model Class Initialized
INFO - 2022-06-05 17:34:37 --> Controller Class Initialized
DEBUG - 2022-06-05 17:34:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:34:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:34:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:34:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:34:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:34:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:34:37 --> Final output sent to browser
DEBUG - 2022-06-05 17:34:37 --> Total execution time: 0.0287
INFO - 2022-06-05 17:34:41 --> Config Class Initialized
INFO - 2022-06-05 17:34:41 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:34:41 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:34:41 --> Utf8 Class Initialized
INFO - 2022-06-05 17:34:41 --> URI Class Initialized
INFO - 2022-06-05 17:34:41 --> Router Class Initialized
INFO - 2022-06-05 17:34:41 --> Output Class Initialized
INFO - 2022-06-05 17:34:41 --> Security Class Initialized
DEBUG - 2022-06-05 17:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:34:41 --> Input Class Initialized
INFO - 2022-06-05 17:34:41 --> Language Class Initialized
INFO - 2022-06-05 17:34:41 --> Language Class Initialized
INFO - 2022-06-05 17:34:41 --> Config Class Initialized
INFO - 2022-06-05 17:34:41 --> Loader Class Initialized
INFO - 2022-06-05 17:34:41 --> Helper loaded: url_helper
INFO - 2022-06-05 17:34:41 --> Database Driver Class Initialized
INFO - 2022-06-05 17:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:34:41 --> Model Class Initialized
DEBUG - 2022-06-05 17:34:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:34:41 --> Model Class Initialized
INFO - 2022-06-05 17:34:41 --> Controller Class Initialized
DEBUG - 2022-06-05 17:34:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:34:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:34:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:34:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:34:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:34:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:34:41 --> Final output sent to browser
DEBUG - 2022-06-05 17:34:41 --> Total execution time: 0.0452
INFO - 2022-06-05 17:34:42 --> Config Class Initialized
INFO - 2022-06-05 17:34:42 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:34:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:34:42 --> Utf8 Class Initialized
INFO - 2022-06-05 17:34:42 --> URI Class Initialized
INFO - 2022-06-05 17:34:42 --> Router Class Initialized
INFO - 2022-06-05 17:34:42 --> Output Class Initialized
INFO - 2022-06-05 17:34:42 --> Security Class Initialized
DEBUG - 2022-06-05 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:34:42 --> Input Class Initialized
INFO - 2022-06-05 17:34:42 --> Language Class Initialized
INFO - 2022-06-05 17:34:42 --> Language Class Initialized
INFO - 2022-06-05 17:34:42 --> Config Class Initialized
INFO - 2022-06-05 17:34:42 --> Loader Class Initialized
INFO - 2022-06-05 17:34:42 --> Helper loaded: url_helper
INFO - 2022-06-05 17:34:42 --> Database Driver Class Initialized
INFO - 2022-06-05 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:34:42 --> Model Class Initialized
DEBUG - 2022-06-05 17:34:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:34:42 --> Model Class Initialized
INFO - 2022-06-05 17:34:42 --> Controller Class Initialized
DEBUG - 2022-06-05 17:34:42 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:34:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:34:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:34:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:34:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:34:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:34:42 --> Final output sent to browser
DEBUG - 2022-06-05 17:34:42 --> Total execution time: 0.0366
INFO - 2022-06-05 17:35:58 --> Config Class Initialized
INFO - 2022-06-05 17:35:58 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:35:58 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:35:58 --> Utf8 Class Initialized
INFO - 2022-06-05 17:35:58 --> URI Class Initialized
INFO - 2022-06-05 17:35:58 --> Router Class Initialized
INFO - 2022-06-05 17:35:58 --> Output Class Initialized
INFO - 2022-06-05 17:35:58 --> Security Class Initialized
DEBUG - 2022-06-05 17:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:35:58 --> Input Class Initialized
INFO - 2022-06-05 17:35:58 --> Language Class Initialized
INFO - 2022-06-05 17:35:58 --> Language Class Initialized
INFO - 2022-06-05 17:35:58 --> Config Class Initialized
INFO - 2022-06-05 17:35:58 --> Loader Class Initialized
INFO - 2022-06-05 17:35:58 --> Helper loaded: url_helper
INFO - 2022-06-05 17:35:58 --> Database Driver Class Initialized
INFO - 2022-06-05 17:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:35:58 --> Model Class Initialized
DEBUG - 2022-06-05 17:35:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:35:58 --> Model Class Initialized
INFO - 2022-06-05 17:35:58 --> Controller Class Initialized
DEBUG - 2022-06-05 17:35:58 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:35:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:35:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:35:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:35:58 --> Severity: Notice --> Undefined variable: serial N:\Xampp\htdocs\dhired\application\modules\admin\views\add_country.php 70
DEBUG - 2022-06-05 17:35:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:35:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:35:58 --> Final output sent to browser
DEBUG - 2022-06-05 17:35:58 --> Total execution time: 0.0398
INFO - 2022-06-05 17:36:20 --> Config Class Initialized
INFO - 2022-06-05 17:36:20 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:36:20 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:36:20 --> Utf8 Class Initialized
INFO - 2022-06-05 17:36:20 --> URI Class Initialized
INFO - 2022-06-05 17:36:20 --> Router Class Initialized
INFO - 2022-06-05 17:36:20 --> Output Class Initialized
INFO - 2022-06-05 17:36:20 --> Security Class Initialized
DEBUG - 2022-06-05 17:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:36:20 --> Input Class Initialized
INFO - 2022-06-05 17:36:20 --> Language Class Initialized
INFO - 2022-06-05 17:36:20 --> Language Class Initialized
INFO - 2022-06-05 17:36:20 --> Config Class Initialized
INFO - 2022-06-05 17:36:20 --> Loader Class Initialized
INFO - 2022-06-05 17:36:20 --> Helper loaded: url_helper
INFO - 2022-06-05 17:36:20 --> Database Driver Class Initialized
INFO - 2022-06-05 17:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:36:20 --> Model Class Initialized
DEBUG - 2022-06-05 17:36:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:36:20 --> Model Class Initialized
INFO - 2022-06-05 17:36:20 --> Controller Class Initialized
DEBUG - 2022-06-05 17:36:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:36:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:36:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:36:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:36:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:36:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:36:20 --> Final output sent to browser
DEBUG - 2022-06-05 17:36:20 --> Total execution time: 0.0390
INFO - 2022-06-05 17:36:24 --> Config Class Initialized
INFO - 2022-06-05 17:36:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:36:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:36:24 --> Utf8 Class Initialized
INFO - 2022-06-05 17:36:24 --> URI Class Initialized
INFO - 2022-06-05 17:36:24 --> Router Class Initialized
INFO - 2022-06-05 17:36:24 --> Output Class Initialized
INFO - 2022-06-05 17:36:24 --> Security Class Initialized
DEBUG - 2022-06-05 17:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:36:24 --> Input Class Initialized
INFO - 2022-06-05 17:36:24 --> Language Class Initialized
INFO - 2022-06-05 17:36:24 --> Language Class Initialized
INFO - 2022-06-05 17:36:24 --> Config Class Initialized
INFO - 2022-06-05 17:36:24 --> Loader Class Initialized
INFO - 2022-06-05 17:36:24 --> Helper loaded: url_helper
INFO - 2022-06-05 17:36:24 --> Database Driver Class Initialized
INFO - 2022-06-05 17:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:36:24 --> Model Class Initialized
DEBUG - 2022-06-05 17:36:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:36:24 --> Model Class Initialized
INFO - 2022-06-05 17:36:24 --> Controller Class Initialized
DEBUG - 2022-06-05 17:36:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:36:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:36:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:36:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:36:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:36:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:36:24 --> Final output sent to browser
DEBUG - 2022-06-05 17:36:24 --> Total execution time: 0.0388
INFO - 2022-06-05 17:37:17 --> Config Class Initialized
INFO - 2022-06-05 17:37:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:37:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:37:17 --> Utf8 Class Initialized
INFO - 2022-06-05 17:37:17 --> URI Class Initialized
INFO - 2022-06-05 17:37:17 --> Router Class Initialized
INFO - 2022-06-05 17:37:17 --> Output Class Initialized
INFO - 2022-06-05 17:37:17 --> Security Class Initialized
DEBUG - 2022-06-05 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:37:17 --> Input Class Initialized
INFO - 2022-06-05 17:37:17 --> Language Class Initialized
INFO - 2022-06-05 17:37:17 --> Language Class Initialized
INFO - 2022-06-05 17:37:17 --> Config Class Initialized
INFO - 2022-06-05 17:37:17 --> Loader Class Initialized
INFO - 2022-06-05 17:37:17 --> Helper loaded: url_helper
INFO - 2022-06-05 17:37:17 --> Database Driver Class Initialized
INFO - 2022-06-05 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:37:17 --> Model Class Initialized
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:37:17 --> Model Class Initialized
INFO - 2022-06-05 17:37:17 --> Controller Class Initialized
DEBUG - 2022-06-05 17:37:17 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:37:17 --> Config Class Initialized
INFO - 2022-06-05 17:37:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:37:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:37:17 --> Utf8 Class Initialized
INFO - 2022-06-05 17:37:17 --> URI Class Initialized
INFO - 2022-06-05 17:37:17 --> Router Class Initialized
INFO - 2022-06-05 17:37:17 --> Output Class Initialized
INFO - 2022-06-05 17:37:17 --> Security Class Initialized
DEBUG - 2022-06-05 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:37:17 --> Input Class Initialized
INFO - 2022-06-05 17:37:17 --> Language Class Initialized
INFO - 2022-06-05 17:37:17 --> Language Class Initialized
INFO - 2022-06-05 17:37:17 --> Config Class Initialized
INFO - 2022-06-05 17:37:17 --> Loader Class Initialized
INFO - 2022-06-05 17:37:17 --> Helper loaded: url_helper
INFO - 2022-06-05 17:37:17 --> Database Driver Class Initialized
INFO - 2022-06-05 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:37:17 --> Model Class Initialized
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:37:17 --> Model Class Initialized
INFO - 2022-06-05 17:37:17 --> Controller Class Initialized
DEBUG - 2022-06-05 17:37:17 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:37:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:37:17 --> Final output sent to browser
DEBUG - 2022-06-05 17:37:17 --> Total execution time: 0.0400
INFO - 2022-06-05 17:37:31 --> Config Class Initialized
INFO - 2022-06-05 17:37:31 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:37:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:37:31 --> Utf8 Class Initialized
INFO - 2022-06-05 17:37:31 --> URI Class Initialized
INFO - 2022-06-05 17:37:31 --> Router Class Initialized
INFO - 2022-06-05 17:37:31 --> Output Class Initialized
INFO - 2022-06-05 17:37:31 --> Security Class Initialized
DEBUG - 2022-06-05 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:37:31 --> Input Class Initialized
INFO - 2022-06-05 17:37:31 --> Language Class Initialized
INFO - 2022-06-05 17:37:31 --> Language Class Initialized
INFO - 2022-06-05 17:37:31 --> Config Class Initialized
INFO - 2022-06-05 17:37:31 --> Loader Class Initialized
INFO - 2022-06-05 17:37:31 --> Helper loaded: url_helper
INFO - 2022-06-05 17:37:31 --> Database Driver Class Initialized
INFO - 2022-06-05 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:37:31 --> Model Class Initialized
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:37:31 --> Model Class Initialized
INFO - 2022-06-05 17:37:31 --> Controller Class Initialized
DEBUG - 2022-06-05 17:37:31 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:37:31 --> Config Class Initialized
INFO - 2022-06-05 17:37:31 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:37:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:37:31 --> Utf8 Class Initialized
INFO - 2022-06-05 17:37:31 --> URI Class Initialized
INFO - 2022-06-05 17:37:31 --> Router Class Initialized
INFO - 2022-06-05 17:37:31 --> Output Class Initialized
INFO - 2022-06-05 17:37:31 --> Security Class Initialized
DEBUG - 2022-06-05 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:37:31 --> Input Class Initialized
INFO - 2022-06-05 17:37:31 --> Language Class Initialized
INFO - 2022-06-05 17:37:31 --> Language Class Initialized
INFO - 2022-06-05 17:37:31 --> Config Class Initialized
INFO - 2022-06-05 17:37:31 --> Loader Class Initialized
INFO - 2022-06-05 17:37:31 --> Helper loaded: url_helper
INFO - 2022-06-05 17:37:31 --> Database Driver Class Initialized
INFO - 2022-06-05 17:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:37:31 --> Model Class Initialized
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:37:31 --> Model Class Initialized
INFO - 2022-06-05 17:37:31 --> Controller Class Initialized
DEBUG - 2022-06-05 17:37:31 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:37:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:37:31 --> Final output sent to browser
DEBUG - 2022-06-05 17:37:31 --> Total execution time: 0.0391
INFO - 2022-06-05 17:37:40 --> Config Class Initialized
INFO - 2022-06-05 17:37:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:37:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:37:40 --> Utf8 Class Initialized
INFO - 2022-06-05 17:37:40 --> URI Class Initialized
INFO - 2022-06-05 17:37:40 --> Router Class Initialized
INFO - 2022-06-05 17:37:40 --> Output Class Initialized
INFO - 2022-06-05 17:37:40 --> Security Class Initialized
DEBUG - 2022-06-05 17:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:37:40 --> Input Class Initialized
INFO - 2022-06-05 17:37:40 --> Language Class Initialized
INFO - 2022-06-05 17:37:40 --> Language Class Initialized
INFO - 2022-06-05 17:37:40 --> Config Class Initialized
INFO - 2022-06-05 17:37:40 --> Loader Class Initialized
INFO - 2022-06-05 17:37:40 --> Helper loaded: url_helper
INFO - 2022-06-05 17:37:40 --> Database Driver Class Initialized
INFO - 2022-06-05 17:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:37:40 --> Model Class Initialized
DEBUG - 2022-06-05 17:37:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:37:40 --> Model Class Initialized
INFO - 2022-06-05 17:37:40 --> Controller Class Initialized
DEBUG - 2022-06-05 17:37:40 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:38:23 --> Config Class Initialized
INFO - 2022-06-05 17:38:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:38:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:38:23 --> Utf8 Class Initialized
INFO - 2022-06-05 17:38:23 --> URI Class Initialized
INFO - 2022-06-05 17:38:23 --> Router Class Initialized
INFO - 2022-06-05 17:38:23 --> Output Class Initialized
INFO - 2022-06-05 17:38:23 --> Security Class Initialized
DEBUG - 2022-06-05 17:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:38:23 --> Input Class Initialized
INFO - 2022-06-05 17:38:23 --> Language Class Initialized
INFO - 2022-06-05 17:38:23 --> Language Class Initialized
INFO - 2022-06-05 17:38:23 --> Config Class Initialized
INFO - 2022-06-05 17:38:23 --> Loader Class Initialized
INFO - 2022-06-05 17:38:23 --> Helper loaded: url_helper
INFO - 2022-06-05 17:38:23 --> Database Driver Class Initialized
INFO - 2022-06-05 17:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:38:23 --> Model Class Initialized
DEBUG - 2022-06-05 17:38:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:38:23 --> Model Class Initialized
INFO - 2022-06-05 17:38:23 --> Controller Class Initialized
DEBUG - 2022-06-05 17:38:23 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:38:59 --> Config Class Initialized
INFO - 2022-06-05 17:38:59 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:38:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:38:59 --> Utf8 Class Initialized
INFO - 2022-06-05 17:38:59 --> URI Class Initialized
INFO - 2022-06-05 17:38:59 --> Router Class Initialized
INFO - 2022-06-05 17:38:59 --> Output Class Initialized
INFO - 2022-06-05 17:38:59 --> Security Class Initialized
DEBUG - 2022-06-05 17:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:38:59 --> Input Class Initialized
INFO - 2022-06-05 17:38:59 --> Language Class Initialized
INFO - 2022-06-05 17:38:59 --> Language Class Initialized
INFO - 2022-06-05 17:38:59 --> Config Class Initialized
INFO - 2022-06-05 17:38:59 --> Loader Class Initialized
INFO - 2022-06-05 17:38:59 --> Helper loaded: url_helper
INFO - 2022-06-05 17:38:59 --> Database Driver Class Initialized
INFO - 2022-06-05 17:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:38:59 --> Model Class Initialized
DEBUG - 2022-06-05 17:38:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:38:59 --> Model Class Initialized
INFO - 2022-06-05 17:38:59 --> Controller Class Initialized
DEBUG - 2022-06-05 17:38:59 --> Admin MX_Controller Initialized
INFO - 2022-06-05 17:39:21 --> Config Class Initialized
INFO - 2022-06-05 17:39:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:39:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:39:21 --> Utf8 Class Initialized
INFO - 2022-06-05 17:39:21 --> URI Class Initialized
INFO - 2022-06-05 17:39:21 --> Router Class Initialized
INFO - 2022-06-05 17:39:21 --> Output Class Initialized
INFO - 2022-06-05 17:39:21 --> Security Class Initialized
DEBUG - 2022-06-05 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:39:21 --> Input Class Initialized
INFO - 2022-06-05 17:39:21 --> Language Class Initialized
INFO - 2022-06-05 17:39:21 --> Language Class Initialized
INFO - 2022-06-05 17:39:21 --> Config Class Initialized
INFO - 2022-06-05 17:39:21 --> Loader Class Initialized
INFO - 2022-06-05 17:39:21 --> Helper loaded: url_helper
INFO - 2022-06-05 17:39:21 --> Database Driver Class Initialized
INFO - 2022-06-05 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:39:21 --> Model Class Initialized
DEBUG - 2022-06-05 17:39:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:39:21 --> Model Class Initialized
INFO - 2022-06-05 17:39:21 --> Controller Class Initialized
DEBUG - 2022-06-05 17:39:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:39:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:39:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:39:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:39:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:39:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:39:21 --> Final output sent to browser
DEBUG - 2022-06-05 17:39:21 --> Total execution time: 0.0385
INFO - 2022-06-05 17:39:40 --> Config Class Initialized
INFO - 2022-06-05 17:39:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:39:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:39:40 --> Utf8 Class Initialized
INFO - 2022-06-05 17:39:40 --> URI Class Initialized
INFO - 2022-06-05 17:39:40 --> Router Class Initialized
INFO - 2022-06-05 17:39:40 --> Output Class Initialized
INFO - 2022-06-05 17:39:40 --> Security Class Initialized
DEBUG - 2022-06-05 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:39:40 --> Input Class Initialized
INFO - 2022-06-05 17:39:40 --> Language Class Initialized
INFO - 2022-06-05 17:39:40 --> Language Class Initialized
INFO - 2022-06-05 17:39:40 --> Config Class Initialized
INFO - 2022-06-05 17:39:40 --> Loader Class Initialized
INFO - 2022-06-05 17:39:40 --> Helper loaded: url_helper
INFO - 2022-06-05 17:39:40 --> Database Driver Class Initialized
INFO - 2022-06-05 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:39:40 --> Model Class Initialized
DEBUG - 2022-06-05 17:39:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:39:40 --> Model Class Initialized
INFO - 2022-06-05 17:39:40 --> Controller Class Initialized
DEBUG - 2022-06-05 17:39:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:39:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:39:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:39:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:39:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:39:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:39:40 --> Final output sent to browser
DEBUG - 2022-06-05 17:39:40 --> Total execution time: 0.0439
INFO - 2022-06-05 17:40:47 --> Config Class Initialized
INFO - 2022-06-05 17:40:47 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:40:47 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:40:47 --> Utf8 Class Initialized
INFO - 2022-06-05 17:40:47 --> URI Class Initialized
INFO - 2022-06-05 17:40:47 --> Router Class Initialized
INFO - 2022-06-05 17:40:47 --> Output Class Initialized
INFO - 2022-06-05 17:40:47 --> Security Class Initialized
DEBUG - 2022-06-05 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:40:47 --> Input Class Initialized
INFO - 2022-06-05 17:40:47 --> Language Class Initialized
INFO - 2022-06-05 17:40:47 --> Language Class Initialized
INFO - 2022-06-05 17:40:47 --> Config Class Initialized
INFO - 2022-06-05 17:40:47 --> Loader Class Initialized
INFO - 2022-06-05 17:40:47 --> Helper loaded: url_helper
INFO - 2022-06-05 17:40:47 --> Database Driver Class Initialized
INFO - 2022-06-05 17:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:40:47 --> Model Class Initialized
DEBUG - 2022-06-05 17:40:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:40:47 --> Model Class Initialized
INFO - 2022-06-05 17:40:47 --> Controller Class Initialized
DEBUG - 2022-06-05 17:40:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:40:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:40:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:40:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:40:47 --> Severity: Notice --> Undefined variable: c N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 32
ERROR - 2022-06-05 17:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 32
ERROR - 2022-06-05 17:40:47 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 17:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 17:40:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 17:40:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:40:47 --> Final output sent to browser
DEBUG - 2022-06-05 17:40:47 --> Total execution time: 0.0389
INFO - 2022-06-05 17:40:56 --> Config Class Initialized
INFO - 2022-06-05 17:40:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:40:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:40:56 --> Utf8 Class Initialized
INFO - 2022-06-05 17:40:56 --> URI Class Initialized
INFO - 2022-06-05 17:40:56 --> Router Class Initialized
INFO - 2022-06-05 17:40:56 --> Output Class Initialized
INFO - 2022-06-05 17:40:56 --> Security Class Initialized
DEBUG - 2022-06-05 17:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:40:56 --> Input Class Initialized
INFO - 2022-06-05 17:40:56 --> Language Class Initialized
INFO - 2022-06-05 17:40:56 --> Language Class Initialized
INFO - 2022-06-05 17:40:56 --> Config Class Initialized
INFO - 2022-06-05 17:40:56 --> Loader Class Initialized
INFO - 2022-06-05 17:40:56 --> Helper loaded: url_helper
INFO - 2022-06-05 17:40:56 --> Database Driver Class Initialized
INFO - 2022-06-05 17:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:40:57 --> Model Class Initialized
DEBUG - 2022-06-05 17:40:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:40:57 --> Model Class Initialized
INFO - 2022-06-05 17:40:57 --> Controller Class Initialized
DEBUG - 2022-06-05 17:40:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:40:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:40:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:40:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:40:57 --> Severity: Notice --> Undefined variable: c N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 32
ERROR - 2022-06-05 17:40:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 32
ERROR - 2022-06-05 17:40:57 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 17:40:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 17:40:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 17:40:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:40:57 --> Final output sent to browser
DEBUG - 2022-06-05 17:40:57 --> Total execution time: 0.0390
INFO - 2022-06-05 17:41:00 --> Config Class Initialized
INFO - 2022-06-05 17:41:00 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:41:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:41:00 --> Utf8 Class Initialized
INFO - 2022-06-05 17:41:00 --> URI Class Initialized
INFO - 2022-06-05 17:41:00 --> Router Class Initialized
INFO - 2022-06-05 17:41:00 --> Output Class Initialized
INFO - 2022-06-05 17:41:00 --> Security Class Initialized
DEBUG - 2022-06-05 17:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:41:00 --> Input Class Initialized
INFO - 2022-06-05 17:41:00 --> Language Class Initialized
INFO - 2022-06-05 17:41:00 --> Language Class Initialized
INFO - 2022-06-05 17:41:00 --> Config Class Initialized
INFO - 2022-06-05 17:41:00 --> Loader Class Initialized
INFO - 2022-06-05 17:41:00 --> Helper loaded: url_helper
INFO - 2022-06-05 17:41:00 --> Database Driver Class Initialized
INFO - 2022-06-05 17:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:41:00 --> Model Class Initialized
DEBUG - 2022-06-05 17:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:41:00 --> Model Class Initialized
INFO - 2022-06-05 17:41:00 --> Controller Class Initialized
DEBUG - 2022-06-05 17:41:00 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:41:00 --> Final output sent to browser
DEBUG - 2022-06-05 17:41:00 --> Total execution time: 0.0441
INFO - 2022-06-05 17:41:04 --> Config Class Initialized
INFO - 2022-06-05 17:41:04 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:41:04 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:41:04 --> Utf8 Class Initialized
INFO - 2022-06-05 17:41:04 --> URI Class Initialized
INFO - 2022-06-05 17:41:04 --> Router Class Initialized
INFO - 2022-06-05 17:41:04 --> Output Class Initialized
INFO - 2022-06-05 17:41:04 --> Security Class Initialized
DEBUG - 2022-06-05 17:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:41:04 --> Input Class Initialized
INFO - 2022-06-05 17:41:04 --> Language Class Initialized
INFO - 2022-06-05 17:41:04 --> Language Class Initialized
INFO - 2022-06-05 17:41:04 --> Config Class Initialized
INFO - 2022-06-05 17:41:04 --> Loader Class Initialized
INFO - 2022-06-05 17:41:04 --> Helper loaded: url_helper
INFO - 2022-06-05 17:41:04 --> Database Driver Class Initialized
INFO - 2022-06-05 17:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:41:04 --> Model Class Initialized
DEBUG - 2022-06-05 17:41:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:41:04 --> Model Class Initialized
INFO - 2022-06-05 17:41:04 --> Controller Class Initialized
DEBUG - 2022-06-05 17:41:04 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:41:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:41:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:41:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:41:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:41:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:41:04 --> Final output sent to browser
DEBUG - 2022-06-05 17:41:04 --> Total execution time: 0.0302
INFO - 2022-06-05 17:41:06 --> Config Class Initialized
INFO - 2022-06-05 17:41:06 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:41:06 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:41:06 --> Utf8 Class Initialized
INFO - 2022-06-05 17:41:06 --> URI Class Initialized
INFO - 2022-06-05 17:41:06 --> Router Class Initialized
INFO - 2022-06-05 17:41:06 --> Output Class Initialized
INFO - 2022-06-05 17:41:06 --> Security Class Initialized
DEBUG - 2022-06-05 17:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:41:06 --> Input Class Initialized
INFO - 2022-06-05 17:41:06 --> Language Class Initialized
INFO - 2022-06-05 17:41:06 --> Language Class Initialized
INFO - 2022-06-05 17:41:06 --> Config Class Initialized
INFO - 2022-06-05 17:41:06 --> Loader Class Initialized
INFO - 2022-06-05 17:41:06 --> Helper loaded: url_helper
INFO - 2022-06-05 17:41:06 --> Database Driver Class Initialized
INFO - 2022-06-05 17:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:41:06 --> Model Class Initialized
DEBUG - 2022-06-05 17:41:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:41:06 --> Model Class Initialized
INFO - 2022-06-05 17:41:06 --> Controller Class Initialized
DEBUG - 2022-06-05 17:41:06 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:41:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:41:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:41:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:41:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:41:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:41:06 --> Final output sent to browser
DEBUG - 2022-06-05 17:41:06 --> Total execution time: 0.0368
INFO - 2022-06-05 17:41:17 --> Config Class Initialized
INFO - 2022-06-05 17:41:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:41:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:41:17 --> Utf8 Class Initialized
INFO - 2022-06-05 17:41:17 --> URI Class Initialized
INFO - 2022-06-05 17:41:17 --> Router Class Initialized
INFO - 2022-06-05 17:41:17 --> Output Class Initialized
INFO - 2022-06-05 17:41:17 --> Security Class Initialized
DEBUG - 2022-06-05 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:41:17 --> Input Class Initialized
INFO - 2022-06-05 17:41:17 --> Language Class Initialized
INFO - 2022-06-05 17:41:17 --> Language Class Initialized
INFO - 2022-06-05 17:41:17 --> Config Class Initialized
INFO - 2022-06-05 17:41:17 --> Loader Class Initialized
INFO - 2022-06-05 17:41:17 --> Helper loaded: url_helper
INFO - 2022-06-05 17:41:17 --> Database Driver Class Initialized
INFO - 2022-06-05 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:41:17 --> Model Class Initialized
DEBUG - 2022-06-05 17:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:41:17 --> Model Class Initialized
INFO - 2022-06-05 17:41:17 --> Controller Class Initialized
DEBUG - 2022-06-05 17:41:17 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:41:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:41:17 --> Final output sent to browser
DEBUG - 2022-06-05 17:41:17 --> Total execution time: 0.0464
INFO - 2022-06-05 17:41:19 --> Config Class Initialized
INFO - 2022-06-05 17:41:19 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:41:19 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:41:19 --> Utf8 Class Initialized
INFO - 2022-06-05 17:41:19 --> URI Class Initialized
INFO - 2022-06-05 17:41:19 --> Router Class Initialized
INFO - 2022-06-05 17:41:19 --> Output Class Initialized
INFO - 2022-06-05 17:41:19 --> Security Class Initialized
DEBUG - 2022-06-05 17:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:41:19 --> Input Class Initialized
INFO - 2022-06-05 17:41:19 --> Language Class Initialized
INFO - 2022-06-05 17:41:19 --> Language Class Initialized
INFO - 2022-06-05 17:41:19 --> Config Class Initialized
INFO - 2022-06-05 17:41:19 --> Loader Class Initialized
INFO - 2022-06-05 17:41:19 --> Helper loaded: url_helper
INFO - 2022-06-05 17:41:19 --> Database Driver Class Initialized
INFO - 2022-06-05 17:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:41:19 --> Model Class Initialized
DEBUG - 2022-06-05 17:41:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:41:19 --> Model Class Initialized
INFO - 2022-06-05 17:41:19 --> Controller Class Initialized
DEBUG - 2022-06-05 17:41:19 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:41:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:41:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:41:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:41:19 --> Severity: Notice --> Undefined variable: c N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 32
ERROR - 2022-06-05 17:41:19 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 32
ERROR - 2022-06-05 17:41:19 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 17:41:19 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 17:41:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 17:41:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:41:19 --> Final output sent to browser
DEBUG - 2022-06-05 17:41:19 --> Total execution time: 0.0377
INFO - 2022-06-05 17:42:08 --> Config Class Initialized
INFO - 2022-06-05 17:42:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:42:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:42:08 --> Utf8 Class Initialized
INFO - 2022-06-05 17:42:08 --> URI Class Initialized
INFO - 2022-06-05 17:42:08 --> Router Class Initialized
INFO - 2022-06-05 17:42:08 --> Output Class Initialized
INFO - 2022-06-05 17:42:08 --> Security Class Initialized
DEBUG - 2022-06-05 17:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:42:08 --> Input Class Initialized
INFO - 2022-06-05 17:42:08 --> Language Class Initialized
INFO - 2022-06-05 17:42:08 --> Language Class Initialized
INFO - 2022-06-05 17:42:08 --> Config Class Initialized
INFO - 2022-06-05 17:42:08 --> Loader Class Initialized
INFO - 2022-06-05 17:42:08 --> Helper loaded: url_helper
INFO - 2022-06-05 17:42:08 --> Database Driver Class Initialized
INFO - 2022-06-05 17:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:42:08 --> Model Class Initialized
DEBUG - 2022-06-05 17:42:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:42:08 --> Model Class Initialized
INFO - 2022-06-05 17:42:08 --> Controller Class Initialized
DEBUG - 2022-06-05 17:42:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:42:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:42:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:42:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:42:08 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 17:42:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 17:42:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:42:08 --> Final output sent to browser
DEBUG - 2022-06-05 17:42:08 --> Total execution time: 0.0433
INFO - 2022-06-05 17:42:22 --> Config Class Initialized
INFO - 2022-06-05 17:42:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:42:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:42:22 --> Utf8 Class Initialized
INFO - 2022-06-05 17:42:22 --> URI Class Initialized
INFO - 2022-06-05 17:42:22 --> Router Class Initialized
INFO - 2022-06-05 17:42:22 --> Output Class Initialized
INFO - 2022-06-05 17:42:22 --> Security Class Initialized
DEBUG - 2022-06-05 17:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:42:22 --> Input Class Initialized
INFO - 2022-06-05 17:42:22 --> Language Class Initialized
INFO - 2022-06-05 17:42:22 --> Language Class Initialized
INFO - 2022-06-05 17:42:22 --> Config Class Initialized
INFO - 2022-06-05 17:42:22 --> Loader Class Initialized
INFO - 2022-06-05 17:42:22 --> Helper loaded: url_helper
INFO - 2022-06-05 17:42:22 --> Database Driver Class Initialized
INFO - 2022-06-05 17:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:42:22 --> Model Class Initialized
DEBUG - 2022-06-05 17:42:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:42:22 --> Model Class Initialized
INFO - 2022-06-05 17:42:22 --> Controller Class Initialized
DEBUG - 2022-06-05 17:42:22 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:42:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:42:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:42:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:42:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:42:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:42:22 --> Final output sent to browser
DEBUG - 2022-06-05 17:42:22 --> Total execution time: 0.0377
INFO - 2022-06-05 17:43:26 --> Config Class Initialized
INFO - 2022-06-05 17:43:26 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:43:26 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:43:26 --> Utf8 Class Initialized
INFO - 2022-06-05 17:43:26 --> URI Class Initialized
INFO - 2022-06-05 17:43:26 --> Router Class Initialized
INFO - 2022-06-05 17:43:26 --> Output Class Initialized
INFO - 2022-06-05 17:43:26 --> Security Class Initialized
DEBUG - 2022-06-05 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:43:26 --> Input Class Initialized
INFO - 2022-06-05 17:43:26 --> Language Class Initialized
INFO - 2022-06-05 17:43:26 --> Language Class Initialized
INFO - 2022-06-05 17:43:26 --> Config Class Initialized
INFO - 2022-06-05 17:43:26 --> Loader Class Initialized
INFO - 2022-06-05 17:43:26 --> Helper loaded: url_helper
INFO - 2022-06-05 17:43:26 --> Database Driver Class Initialized
INFO - 2022-06-05 17:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:43:26 --> Model Class Initialized
DEBUG - 2022-06-05 17:43:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:43:26 --> Model Class Initialized
INFO - 2022-06-05 17:43:26 --> Controller Class Initialized
DEBUG - 2022-06-05 17:43:26 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:43:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:43:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:43:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:43:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-05 17:43:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:43:26 --> Final output sent to browser
DEBUG - 2022-06-05 17:43:26 --> Total execution time: 0.0288
INFO - 2022-06-05 17:43:28 --> Config Class Initialized
INFO - 2022-06-05 17:43:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:43:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:43:28 --> Utf8 Class Initialized
INFO - 2022-06-05 17:43:28 --> URI Class Initialized
INFO - 2022-06-05 17:43:28 --> Router Class Initialized
INFO - 2022-06-05 17:43:28 --> Output Class Initialized
INFO - 2022-06-05 17:43:28 --> Security Class Initialized
DEBUG - 2022-06-05 17:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:43:28 --> Input Class Initialized
INFO - 2022-06-05 17:43:28 --> Language Class Initialized
INFO - 2022-06-05 17:43:28 --> Language Class Initialized
INFO - 2022-06-05 17:43:28 --> Config Class Initialized
INFO - 2022-06-05 17:43:28 --> Loader Class Initialized
INFO - 2022-06-05 17:43:28 --> Helper loaded: url_helper
INFO - 2022-06-05 17:43:28 --> Database Driver Class Initialized
INFO - 2022-06-05 17:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:43:28 --> Model Class Initialized
DEBUG - 2022-06-05 17:43:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:43:28 --> Model Class Initialized
INFO - 2022-06-05 17:43:28 --> Controller Class Initialized
DEBUG - 2022-06-05 17:43:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:43:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:43:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:43:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 17:43:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:43:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:43:28 --> Final output sent to browser
DEBUG - 2022-06-05 17:43:28 --> Total execution time: 0.0375
INFO - 2022-06-05 17:58:21 --> Config Class Initialized
INFO - 2022-06-05 17:58:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:58:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:58:21 --> Utf8 Class Initialized
INFO - 2022-06-05 17:58:21 --> URI Class Initialized
INFO - 2022-06-05 17:58:21 --> Router Class Initialized
INFO - 2022-06-05 17:58:21 --> Output Class Initialized
INFO - 2022-06-05 17:58:21 --> Security Class Initialized
DEBUG - 2022-06-05 17:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:58:21 --> Input Class Initialized
INFO - 2022-06-05 17:58:21 --> Language Class Initialized
INFO - 2022-06-05 17:58:21 --> Language Class Initialized
INFO - 2022-06-05 17:58:21 --> Config Class Initialized
INFO - 2022-06-05 17:58:21 --> Loader Class Initialized
INFO - 2022-06-05 17:58:21 --> Helper loaded: url_helper
INFO - 2022-06-05 17:58:21 --> Database Driver Class Initialized
INFO - 2022-06-05 17:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:58:21 --> Model Class Initialized
DEBUG - 2022-06-05 17:58:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:58:21 --> Model Class Initialized
INFO - 2022-06-05 17:58:21 --> Controller Class Initialized
DEBUG - 2022-06-05 17:58:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:58:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:58:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:58:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:58:21 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 71
ERROR - 2022-06-05 17:58:21 --> Severity: Notice --> Undefined index: s_name N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 72
ERROR - 2022-06-05 17:58:21 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 71
ERROR - 2022-06-05 17:58:21 --> Severity: Notice --> Undefined index: s_name N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 72
ERROR - 2022-06-05 17:58:21 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 71
ERROR - 2022-06-05 17:58:21 --> Severity: Notice --> Undefined index: s_name N:\Xampp\htdocs\dhired\application\modules\admin\views\add_state.php 72
DEBUG - 2022-06-05 17:58:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-05 17:58:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:58:21 --> Final output sent to browser
DEBUG - 2022-06-05 17:58:21 --> Total execution time: 0.0310
INFO - 2022-06-05 17:58:27 --> Config Class Initialized
INFO - 2022-06-05 17:58:27 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:58:27 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:58:27 --> Utf8 Class Initialized
INFO - 2022-06-05 17:58:27 --> URI Class Initialized
INFO - 2022-06-05 17:58:27 --> Router Class Initialized
INFO - 2022-06-05 17:58:27 --> Output Class Initialized
INFO - 2022-06-05 17:58:27 --> Security Class Initialized
DEBUG - 2022-06-05 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:58:27 --> Input Class Initialized
INFO - 2022-06-05 17:58:27 --> Language Class Initialized
INFO - 2022-06-05 17:58:27 --> Language Class Initialized
INFO - 2022-06-05 17:58:27 --> Config Class Initialized
INFO - 2022-06-05 17:58:27 --> Loader Class Initialized
INFO - 2022-06-05 17:58:27 --> Helper loaded: url_helper
INFO - 2022-06-05 17:58:27 --> Database Driver Class Initialized
INFO - 2022-06-05 17:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:58:27 --> Model Class Initialized
DEBUG - 2022-06-05 17:58:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:58:27 --> Model Class Initialized
INFO - 2022-06-05 17:58:27 --> Controller Class Initialized
DEBUG - 2022-06-05 17:58:27 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:58:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:58:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:58:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:58:27 --> Severity: Notice --> Undefined variable: country N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 30
ERROR - 2022-06-05 17:58:27 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 17:58:27 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 17:58:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 17:58:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:58:27 --> Final output sent to browser
DEBUG - 2022-06-05 17:58:27 --> Total execution time: 0.0306
INFO - 2022-06-05 17:59:03 --> Config Class Initialized
INFO - 2022-06-05 17:59:03 --> Hooks Class Initialized
DEBUG - 2022-06-05 17:59:03 --> UTF-8 Support Enabled
INFO - 2022-06-05 17:59:03 --> Utf8 Class Initialized
INFO - 2022-06-05 17:59:03 --> URI Class Initialized
INFO - 2022-06-05 17:59:03 --> Router Class Initialized
INFO - 2022-06-05 17:59:03 --> Output Class Initialized
INFO - 2022-06-05 17:59:03 --> Security Class Initialized
DEBUG - 2022-06-05 17:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 17:59:03 --> Input Class Initialized
INFO - 2022-06-05 17:59:03 --> Language Class Initialized
INFO - 2022-06-05 17:59:03 --> Language Class Initialized
INFO - 2022-06-05 17:59:03 --> Config Class Initialized
INFO - 2022-06-05 17:59:03 --> Loader Class Initialized
INFO - 2022-06-05 17:59:03 --> Helper loaded: url_helper
INFO - 2022-06-05 17:59:03 --> Database Driver Class Initialized
INFO - 2022-06-05 17:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 17:59:03 --> Model Class Initialized
DEBUG - 2022-06-05 17:59:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 17:59:03 --> Model Class Initialized
INFO - 2022-06-05 17:59:03 --> Controller Class Initialized
DEBUG - 2022-06-05 17:59:03 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 17:59:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 17:59:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 17:59:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 17:59:03 --> Severity: Notice --> Undefined variable: country N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 30
ERROR - 2022-06-05 17:59:03 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 17:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 17:59:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 17:59:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 17:59:03 --> Final output sent to browser
DEBUG - 2022-06-05 17:59:03 --> Total execution time: 0.0409
INFO - 2022-06-05 18:00:47 --> Config Class Initialized
INFO - 2022-06-05 18:00:47 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:00:47 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:00:47 --> Utf8 Class Initialized
INFO - 2022-06-05 18:00:47 --> URI Class Initialized
INFO - 2022-06-05 18:00:47 --> Router Class Initialized
INFO - 2022-06-05 18:00:47 --> Output Class Initialized
INFO - 2022-06-05 18:00:47 --> Security Class Initialized
DEBUG - 2022-06-05 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:00:47 --> Input Class Initialized
INFO - 2022-06-05 18:00:47 --> Language Class Initialized
INFO - 2022-06-05 18:00:47 --> Language Class Initialized
INFO - 2022-06-05 18:00:47 --> Config Class Initialized
INFO - 2022-06-05 18:00:47 --> Loader Class Initialized
INFO - 2022-06-05 18:00:47 --> Helper loaded: url_helper
INFO - 2022-06-05 18:00:47 --> Database Driver Class Initialized
INFO - 2022-06-05 18:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:00:47 --> Model Class Initialized
DEBUG - 2022-06-05 18:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:00:47 --> Model Class Initialized
INFO - 2022-06-05 18:00:47 --> Controller Class Initialized
DEBUG - 2022-06-05 18:00:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:00:47 --> Severity: Notice --> Undefined variable: country N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 30
ERROR - 2022-06-05 18:00:47 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:00:47 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:00:47 --> Final output sent to browser
DEBUG - 2022-06-05 18:00:47 --> Total execution time: 0.0289
INFO - 2022-06-05 18:01:09 --> Config Class Initialized
INFO - 2022-06-05 18:01:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:01:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:01:09 --> Utf8 Class Initialized
INFO - 2022-06-05 18:01:09 --> URI Class Initialized
INFO - 2022-06-05 18:01:09 --> Router Class Initialized
INFO - 2022-06-05 18:01:09 --> Output Class Initialized
INFO - 2022-06-05 18:01:09 --> Security Class Initialized
DEBUG - 2022-06-05 18:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:01:09 --> Input Class Initialized
INFO - 2022-06-05 18:01:09 --> Language Class Initialized
INFO - 2022-06-05 18:01:09 --> Language Class Initialized
INFO - 2022-06-05 18:01:09 --> Config Class Initialized
INFO - 2022-06-05 18:01:09 --> Loader Class Initialized
INFO - 2022-06-05 18:01:09 --> Helper loaded: url_helper
INFO - 2022-06-05 18:01:09 --> Database Driver Class Initialized
INFO - 2022-06-05 18:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:01:09 --> Model Class Initialized
DEBUG - 2022-06-05 18:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:01:09 --> Model Class Initialized
INFO - 2022-06-05 18:01:09 --> Controller Class Initialized
DEBUG - 2022-06-05 18:01:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:01:09 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 71
ERROR - 2022-06-05 18:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 71
DEBUG - 2022-06-05 18:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:01:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:01:09 --> Final output sent to browser
DEBUG - 2022-06-05 18:01:09 --> Total execution time: 0.0458
INFO - 2022-06-05 18:02:57 --> Config Class Initialized
INFO - 2022-06-05 18:02:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:02:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:02:57 --> Utf8 Class Initialized
INFO - 2022-06-05 18:02:57 --> URI Class Initialized
INFO - 2022-06-05 18:02:57 --> Router Class Initialized
INFO - 2022-06-05 18:02:57 --> Output Class Initialized
INFO - 2022-06-05 18:02:57 --> Security Class Initialized
DEBUG - 2022-06-05 18:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:02:57 --> Input Class Initialized
INFO - 2022-06-05 18:02:57 --> Language Class Initialized
INFO - 2022-06-05 18:02:57 --> Language Class Initialized
INFO - 2022-06-05 18:02:57 --> Config Class Initialized
INFO - 2022-06-05 18:02:57 --> Loader Class Initialized
INFO - 2022-06-05 18:02:57 --> Helper loaded: url_helper
INFO - 2022-06-05 18:02:57 --> Database Driver Class Initialized
INFO - 2022-06-05 18:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:02:57 --> Model Class Initialized
DEBUG - 2022-06-05 18:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:02:57 --> Model Class Initialized
INFO - 2022-06-05 18:02:57 --> Controller Class Initialized
DEBUG - 2022-06-05 18:02:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:02:57 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:02:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:02:57 --> Final output sent to browser
DEBUG - 2022-06-05 18:02:57 --> Total execution time: 0.0385
INFO - 2022-06-05 18:03:23 --> Config Class Initialized
INFO - 2022-06-05 18:03:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:03:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:03:23 --> Utf8 Class Initialized
INFO - 2022-06-05 18:03:23 --> URI Class Initialized
INFO - 2022-06-05 18:03:23 --> Router Class Initialized
INFO - 2022-06-05 18:03:23 --> Output Class Initialized
INFO - 2022-06-05 18:03:23 --> Security Class Initialized
DEBUG - 2022-06-05 18:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:03:23 --> Input Class Initialized
INFO - 2022-06-05 18:03:23 --> Language Class Initialized
INFO - 2022-06-05 18:03:23 --> Language Class Initialized
INFO - 2022-06-05 18:03:23 --> Config Class Initialized
INFO - 2022-06-05 18:03:23 --> Loader Class Initialized
INFO - 2022-06-05 18:03:23 --> Helper loaded: url_helper
INFO - 2022-06-05 18:03:23 --> Database Driver Class Initialized
INFO - 2022-06-05 18:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:03:23 --> Model Class Initialized
DEBUG - 2022-06-05 18:03:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:03:23 --> Model Class Initialized
INFO - 2022-06-05 18:03:23 --> Controller Class Initialized
DEBUG - 2022-06-05 18:03:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:03:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:03:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:03:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:03:23 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:03:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:03:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:03:23 --> Final output sent to browser
DEBUG - 2022-06-05 18:03:23 --> Total execution time: 0.0336
INFO - 2022-06-05 18:03:24 --> Config Class Initialized
INFO - 2022-06-05 18:03:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:03:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:03:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:03:24 --> URI Class Initialized
INFO - 2022-06-05 18:03:24 --> Router Class Initialized
INFO - 2022-06-05 18:03:24 --> Output Class Initialized
INFO - 2022-06-05 18:03:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:03:24 --> Input Class Initialized
INFO - 2022-06-05 18:03:24 --> Language Class Initialized
INFO - 2022-06-05 18:03:24 --> Language Class Initialized
INFO - 2022-06-05 18:03:24 --> Config Class Initialized
INFO - 2022-06-05 18:03:24 --> Loader Class Initialized
INFO - 2022-06-05 18:03:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:03:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:03:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:03:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:03:24 --> Model Class Initialized
INFO - 2022-06-05 18:03:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:03:24 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:03:24 --> Severity: Notice --> Undefined index: category_id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 30
INFO - 2022-06-05 18:03:24 --> Final output sent to browser
DEBUG - 2022-06-05 18:03:24 --> Total execution time: 0.0426
INFO - 2022-06-05 18:03:52 --> Config Class Initialized
INFO - 2022-06-05 18:03:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:03:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:03:52 --> Utf8 Class Initialized
INFO - 2022-06-05 18:03:52 --> URI Class Initialized
INFO - 2022-06-05 18:03:52 --> Router Class Initialized
INFO - 2022-06-05 18:03:52 --> Output Class Initialized
INFO - 2022-06-05 18:03:52 --> Security Class Initialized
DEBUG - 2022-06-05 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:03:52 --> Input Class Initialized
INFO - 2022-06-05 18:03:52 --> Language Class Initialized
INFO - 2022-06-05 18:03:52 --> Language Class Initialized
INFO - 2022-06-05 18:03:52 --> Config Class Initialized
INFO - 2022-06-05 18:03:52 --> Loader Class Initialized
INFO - 2022-06-05 18:03:52 --> Helper loaded: url_helper
INFO - 2022-06-05 18:03:52 --> Database Driver Class Initialized
INFO - 2022-06-05 18:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:03:52 --> Model Class Initialized
DEBUG - 2022-06-05 18:03:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:03:52 --> Model Class Initialized
INFO - 2022-06-05 18:03:52 --> Controller Class Initialized
DEBUG - 2022-06-05 18:03:52 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:03:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:03:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:03:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:03:52 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:03:52 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:03:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:03:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:03:52 --> Final output sent to browser
DEBUG - 2022-06-05 18:03:52 --> Total execution time: 0.0312
INFO - 2022-06-05 18:03:55 --> Config Class Initialized
INFO - 2022-06-05 18:03:55 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:03:55 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:03:55 --> Utf8 Class Initialized
INFO - 2022-06-05 18:03:55 --> URI Class Initialized
INFO - 2022-06-05 18:03:55 --> Router Class Initialized
INFO - 2022-06-05 18:03:55 --> Output Class Initialized
INFO - 2022-06-05 18:03:55 --> Security Class Initialized
DEBUG - 2022-06-05 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:03:55 --> Input Class Initialized
INFO - 2022-06-05 18:03:55 --> Language Class Initialized
INFO - 2022-06-05 18:03:55 --> Language Class Initialized
INFO - 2022-06-05 18:03:55 --> Config Class Initialized
INFO - 2022-06-05 18:03:55 --> Loader Class Initialized
INFO - 2022-06-05 18:03:55 --> Helper loaded: url_helper
INFO - 2022-06-05 18:03:55 --> Database Driver Class Initialized
INFO - 2022-06-05 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:03:55 --> Model Class Initialized
DEBUG - 2022-06-05 18:03:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:03:55 --> Model Class Initialized
INFO - 2022-06-05 18:03:55 --> Controller Class Initialized
DEBUG - 2022-06-05 18:03:55 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:03:55 --> Severity: Notice --> Undefined index: category_id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 30
INFO - 2022-06-05 18:03:55 --> Final output sent to browser
DEBUG - 2022-06-05 18:03:55 --> Total execution time: 0.0299
INFO - 2022-06-05 18:03:58 --> Config Class Initialized
INFO - 2022-06-05 18:03:58 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:03:58 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:03:58 --> Utf8 Class Initialized
INFO - 2022-06-05 18:03:58 --> URI Class Initialized
INFO - 2022-06-05 18:03:58 --> Router Class Initialized
INFO - 2022-06-05 18:03:58 --> Output Class Initialized
INFO - 2022-06-05 18:03:58 --> Security Class Initialized
DEBUG - 2022-06-05 18:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:03:58 --> Input Class Initialized
INFO - 2022-06-05 18:03:58 --> Language Class Initialized
INFO - 2022-06-05 18:03:58 --> Language Class Initialized
INFO - 2022-06-05 18:03:58 --> Config Class Initialized
INFO - 2022-06-05 18:03:58 --> Loader Class Initialized
INFO - 2022-06-05 18:03:58 --> Helper loaded: url_helper
INFO - 2022-06-05 18:03:58 --> Database Driver Class Initialized
INFO - 2022-06-05 18:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:03:58 --> Model Class Initialized
DEBUG - 2022-06-05 18:03:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:03:58 --> Model Class Initialized
INFO - 2022-06-05 18:03:58 --> Controller Class Initialized
DEBUG - 2022-06-05 18:03:58 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:03:58 --> Severity: Notice --> Undefined index: category_id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 30
INFO - 2022-06-05 18:03:58 --> Final output sent to browser
DEBUG - 2022-06-05 18:03:58 --> Total execution time: 0.0404
INFO - 2022-06-05 18:04:24 --> Config Class Initialized
INFO - 2022-06-05 18:04:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:04:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:04:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:04:24 --> URI Class Initialized
INFO - 2022-06-05 18:04:24 --> Router Class Initialized
INFO - 2022-06-05 18:04:24 --> Output Class Initialized
INFO - 2022-06-05 18:04:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:04:24 --> Input Class Initialized
INFO - 2022-06-05 18:04:24 --> Language Class Initialized
INFO - 2022-06-05 18:04:24 --> Language Class Initialized
INFO - 2022-06-05 18:04:24 --> Config Class Initialized
INFO - 2022-06-05 18:04:24 --> Loader Class Initialized
INFO - 2022-06-05 18:04:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:04:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:04:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:04:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:04:24 --> Model Class Initialized
INFO - 2022-06-05 18:04:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:04:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:04:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:04:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:04:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:04:24 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:04:24 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:04:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:04:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:04:24 --> Final output sent to browser
DEBUG - 2022-06-05 18:04:24 --> Total execution time: 0.0374
INFO - 2022-06-05 18:04:25 --> Config Class Initialized
INFO - 2022-06-05 18:04:25 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:04:25 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:04:25 --> Utf8 Class Initialized
INFO - 2022-06-05 18:04:25 --> URI Class Initialized
INFO - 2022-06-05 18:04:25 --> Router Class Initialized
INFO - 2022-06-05 18:04:25 --> Output Class Initialized
INFO - 2022-06-05 18:04:25 --> Security Class Initialized
DEBUG - 2022-06-05 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:04:25 --> Input Class Initialized
INFO - 2022-06-05 18:04:25 --> Language Class Initialized
INFO - 2022-06-05 18:04:25 --> Language Class Initialized
INFO - 2022-06-05 18:04:25 --> Config Class Initialized
INFO - 2022-06-05 18:04:25 --> Loader Class Initialized
INFO - 2022-06-05 18:04:25 --> Helper loaded: url_helper
INFO - 2022-06-05 18:04:25 --> Database Driver Class Initialized
INFO - 2022-06-05 18:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:04:25 --> Model Class Initialized
DEBUG - 2022-06-05 18:04:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:04:25 --> Model Class Initialized
INFO - 2022-06-05 18:04:25 --> Controller Class Initialized
DEBUG - 2022-06-05 18:04:25 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:04:25 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
ERROR - 2022-06-05 18:04:25 --> Severity: Notice --> Undefined index: name N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
INFO - 2022-06-05 18:04:25 --> Final output sent to browser
DEBUG - 2022-06-05 18:04:25 --> Total execution time: 0.0301
INFO - 2022-06-05 18:04:28 --> Config Class Initialized
INFO - 2022-06-05 18:04:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:04:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:04:28 --> Utf8 Class Initialized
INFO - 2022-06-05 18:04:28 --> URI Class Initialized
INFO - 2022-06-05 18:04:28 --> Router Class Initialized
INFO - 2022-06-05 18:04:28 --> Output Class Initialized
INFO - 2022-06-05 18:04:28 --> Security Class Initialized
DEBUG - 2022-06-05 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:04:28 --> Input Class Initialized
INFO - 2022-06-05 18:04:28 --> Language Class Initialized
INFO - 2022-06-05 18:04:28 --> Language Class Initialized
INFO - 2022-06-05 18:04:28 --> Config Class Initialized
INFO - 2022-06-05 18:04:28 --> Loader Class Initialized
INFO - 2022-06-05 18:04:28 --> Helper loaded: url_helper
INFO - 2022-06-05 18:04:28 --> Database Driver Class Initialized
INFO - 2022-06-05 18:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:04:28 --> Model Class Initialized
DEBUG - 2022-06-05 18:04:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:04:28 --> Model Class Initialized
INFO - 2022-06-05 18:04:28 --> Controller Class Initialized
DEBUG - 2022-06-05 18:04:28 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:04:28 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
ERROR - 2022-06-05 18:04:28 --> Severity: Notice --> Undefined index: name N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
INFO - 2022-06-05 18:04:28 --> Final output sent to browser
DEBUG - 2022-06-05 18:04:28 --> Total execution time: 0.0344
INFO - 2022-06-05 18:04:33 --> Config Class Initialized
INFO - 2022-06-05 18:04:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:04:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:04:33 --> Utf8 Class Initialized
INFO - 2022-06-05 18:04:33 --> URI Class Initialized
INFO - 2022-06-05 18:04:33 --> Router Class Initialized
INFO - 2022-06-05 18:04:33 --> Output Class Initialized
INFO - 2022-06-05 18:04:33 --> Security Class Initialized
DEBUG - 2022-06-05 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:04:33 --> Input Class Initialized
INFO - 2022-06-05 18:04:33 --> Language Class Initialized
INFO - 2022-06-05 18:04:33 --> Language Class Initialized
INFO - 2022-06-05 18:04:33 --> Config Class Initialized
INFO - 2022-06-05 18:04:33 --> Loader Class Initialized
INFO - 2022-06-05 18:04:33 --> Helper loaded: url_helper
INFO - 2022-06-05 18:04:33 --> Database Driver Class Initialized
INFO - 2022-06-05 18:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:04:33 --> Model Class Initialized
DEBUG - 2022-06-05 18:04:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:04:33 --> Model Class Initialized
INFO - 2022-06-05 18:04:33 --> Controller Class Initialized
DEBUG - 2022-06-05 18:04:33 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:04:33 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
ERROR - 2022-06-05 18:04:33 --> Severity: Notice --> Undefined index: name N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
INFO - 2022-06-05 18:04:33 --> Final output sent to browser
DEBUG - 2022-06-05 18:04:33 --> Total execution time: 0.0353
INFO - 2022-06-05 18:05:20 --> Config Class Initialized
INFO - 2022-06-05 18:05:20 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:05:20 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:05:20 --> Utf8 Class Initialized
INFO - 2022-06-05 18:05:20 --> URI Class Initialized
INFO - 2022-06-05 18:05:20 --> Router Class Initialized
INFO - 2022-06-05 18:05:20 --> Output Class Initialized
INFO - 2022-06-05 18:05:20 --> Security Class Initialized
DEBUG - 2022-06-05 18:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:05:20 --> Input Class Initialized
INFO - 2022-06-05 18:05:20 --> Language Class Initialized
INFO - 2022-06-05 18:05:20 --> Language Class Initialized
INFO - 2022-06-05 18:05:20 --> Config Class Initialized
INFO - 2022-06-05 18:05:20 --> Loader Class Initialized
INFO - 2022-06-05 18:05:20 --> Helper loaded: url_helper
INFO - 2022-06-05 18:05:20 --> Database Driver Class Initialized
INFO - 2022-06-05 18:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:05:20 --> Model Class Initialized
DEBUG - 2022-06-05 18:05:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:05:20 --> Model Class Initialized
INFO - 2022-06-05 18:05:20 --> Controller Class Initialized
DEBUG - 2022-06-05 18:05:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:05:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:05:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:05:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:05:20 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:05:20 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:05:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:05:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:05:20 --> Final output sent to browser
DEBUG - 2022-06-05 18:05:20 --> Total execution time: 0.0454
INFO - 2022-06-05 18:05:21 --> Config Class Initialized
INFO - 2022-06-05 18:05:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:05:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:05:21 --> Utf8 Class Initialized
INFO - 2022-06-05 18:05:21 --> URI Class Initialized
INFO - 2022-06-05 18:05:21 --> Router Class Initialized
INFO - 2022-06-05 18:05:22 --> Output Class Initialized
INFO - 2022-06-05 18:05:22 --> Security Class Initialized
DEBUG - 2022-06-05 18:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:05:22 --> Input Class Initialized
INFO - 2022-06-05 18:05:22 --> Language Class Initialized
INFO - 2022-06-05 18:05:22 --> Language Class Initialized
INFO - 2022-06-05 18:05:22 --> Config Class Initialized
INFO - 2022-06-05 18:05:22 --> Loader Class Initialized
INFO - 2022-06-05 18:05:22 --> Helper loaded: url_helper
INFO - 2022-06-05 18:05:22 --> Database Driver Class Initialized
INFO - 2022-06-05 18:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:05:22 --> Model Class Initialized
DEBUG - 2022-06-05 18:05:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:05:22 --> Model Class Initialized
INFO - 2022-06-05 18:05:22 --> Controller Class Initialized
DEBUG - 2022-06-05 18:05:22 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:05:22 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 32
INFO - 2022-06-05 18:05:22 --> Final output sent to browser
DEBUG - 2022-06-05 18:05:22 --> Total execution time: 0.0399
INFO - 2022-06-05 18:05:56 --> Config Class Initialized
INFO - 2022-06-05 18:05:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:05:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:05:56 --> Utf8 Class Initialized
INFO - 2022-06-05 18:05:56 --> URI Class Initialized
INFO - 2022-06-05 18:05:56 --> Router Class Initialized
INFO - 2022-06-05 18:05:56 --> Output Class Initialized
INFO - 2022-06-05 18:05:56 --> Security Class Initialized
DEBUG - 2022-06-05 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:05:56 --> Input Class Initialized
INFO - 2022-06-05 18:05:56 --> Language Class Initialized
INFO - 2022-06-05 18:05:56 --> Language Class Initialized
INFO - 2022-06-05 18:05:56 --> Config Class Initialized
INFO - 2022-06-05 18:05:56 --> Loader Class Initialized
INFO - 2022-06-05 18:05:56 --> Helper loaded: url_helper
INFO - 2022-06-05 18:05:56 --> Database Driver Class Initialized
INFO - 2022-06-05 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:05:56 --> Model Class Initialized
DEBUG - 2022-06-05 18:05:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:05:56 --> Model Class Initialized
INFO - 2022-06-05 18:05:56 --> Controller Class Initialized
DEBUG - 2022-06-05 18:05:56 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:05:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:05:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:05:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:05:56 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:05:56 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:05:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:05:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:05:56 --> Final output sent to browser
DEBUG - 2022-06-05 18:05:56 --> Total execution time: 0.0422
INFO - 2022-06-05 18:05:58 --> Config Class Initialized
INFO - 2022-06-05 18:05:58 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:05:58 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:05:58 --> Utf8 Class Initialized
INFO - 2022-06-05 18:05:58 --> URI Class Initialized
INFO - 2022-06-05 18:05:58 --> Router Class Initialized
INFO - 2022-06-05 18:05:58 --> Output Class Initialized
INFO - 2022-06-05 18:05:58 --> Security Class Initialized
DEBUG - 2022-06-05 18:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:05:58 --> Input Class Initialized
INFO - 2022-06-05 18:05:58 --> Language Class Initialized
INFO - 2022-06-05 18:05:58 --> Language Class Initialized
INFO - 2022-06-05 18:05:58 --> Config Class Initialized
INFO - 2022-06-05 18:05:58 --> Loader Class Initialized
INFO - 2022-06-05 18:05:58 --> Helper loaded: url_helper
INFO - 2022-06-05 18:05:58 --> Database Driver Class Initialized
INFO - 2022-06-05 18:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:05:58 --> Model Class Initialized
DEBUG - 2022-06-05 18:05:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:05:58 --> Model Class Initialized
INFO - 2022-06-05 18:05:58 --> Controller Class Initialized
DEBUG - 2022-06-05 18:05:58 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:05:58 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 33
INFO - 2022-06-05 18:05:58 --> Final output sent to browser
DEBUG - 2022-06-05 18:05:58 --> Total execution time: 0.0348
INFO - 2022-06-05 18:06:33 --> Config Class Initialized
INFO - 2022-06-05 18:06:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:06:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:06:33 --> Utf8 Class Initialized
INFO - 2022-06-05 18:06:33 --> URI Class Initialized
INFO - 2022-06-05 18:06:33 --> Router Class Initialized
INFO - 2022-06-05 18:06:33 --> Output Class Initialized
INFO - 2022-06-05 18:06:33 --> Security Class Initialized
DEBUG - 2022-06-05 18:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:06:33 --> Input Class Initialized
INFO - 2022-06-05 18:06:33 --> Language Class Initialized
INFO - 2022-06-05 18:06:33 --> Language Class Initialized
INFO - 2022-06-05 18:06:33 --> Config Class Initialized
INFO - 2022-06-05 18:06:33 --> Loader Class Initialized
INFO - 2022-06-05 18:06:33 --> Helper loaded: url_helper
INFO - 2022-06-05 18:06:33 --> Database Driver Class Initialized
INFO - 2022-06-05 18:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:06:33 --> Model Class Initialized
DEBUG - 2022-06-05 18:06:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:06:33 --> Model Class Initialized
INFO - 2022-06-05 18:06:33 --> Controller Class Initialized
DEBUG - 2022-06-05 18:06:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:06:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:06:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:06:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:06:33 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:06:33 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:06:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:06:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:06:33 --> Final output sent to browser
DEBUG - 2022-06-05 18:06:33 --> Total execution time: 0.0444
INFO - 2022-06-05 18:06:34 --> Config Class Initialized
INFO - 2022-06-05 18:06:34 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:06:34 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:06:34 --> Utf8 Class Initialized
INFO - 2022-06-05 18:06:34 --> URI Class Initialized
INFO - 2022-06-05 18:06:34 --> Router Class Initialized
INFO - 2022-06-05 18:06:34 --> Output Class Initialized
INFO - 2022-06-05 18:06:34 --> Security Class Initialized
DEBUG - 2022-06-05 18:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:06:34 --> Input Class Initialized
INFO - 2022-06-05 18:06:34 --> Language Class Initialized
INFO - 2022-06-05 18:06:34 --> Language Class Initialized
INFO - 2022-06-05 18:06:34 --> Config Class Initialized
INFO - 2022-06-05 18:06:34 --> Loader Class Initialized
INFO - 2022-06-05 18:06:34 --> Helper loaded: url_helper
INFO - 2022-06-05 18:06:34 --> Database Driver Class Initialized
INFO - 2022-06-05 18:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:06:34 --> Model Class Initialized
DEBUG - 2022-06-05 18:06:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:06:34 --> Model Class Initialized
INFO - 2022-06-05 18:06:34 --> Controller Class Initialized
DEBUG - 2022-06-05 18:06:34 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:06:34 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 33
INFO - 2022-06-05 18:06:34 --> Final output sent to browser
DEBUG - 2022-06-05 18:06:34 --> Total execution time: 0.0353
INFO - 2022-06-05 18:06:55 --> Config Class Initialized
INFO - 2022-06-05 18:06:55 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:06:55 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:06:55 --> Utf8 Class Initialized
INFO - 2022-06-05 18:06:55 --> URI Class Initialized
INFO - 2022-06-05 18:06:55 --> Router Class Initialized
INFO - 2022-06-05 18:06:55 --> Output Class Initialized
INFO - 2022-06-05 18:06:55 --> Security Class Initialized
DEBUG - 2022-06-05 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:06:55 --> Input Class Initialized
INFO - 2022-06-05 18:06:55 --> Language Class Initialized
INFO - 2022-06-05 18:06:55 --> Language Class Initialized
INFO - 2022-06-05 18:06:55 --> Config Class Initialized
INFO - 2022-06-05 18:06:55 --> Loader Class Initialized
INFO - 2022-06-05 18:06:55 --> Helper loaded: url_helper
INFO - 2022-06-05 18:06:55 --> Database Driver Class Initialized
INFO - 2022-06-05 18:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:06:55 --> Model Class Initialized
DEBUG - 2022-06-05 18:06:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:06:55 --> Model Class Initialized
INFO - 2022-06-05 18:06:55 --> Controller Class Initialized
DEBUG - 2022-06-05 18:06:55 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:06:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:06:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:06:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:06:55 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:06:55 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:06:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:06:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:06:55 --> Final output sent to browser
DEBUG - 2022-06-05 18:06:55 --> Total execution time: 0.0342
INFO - 2022-06-05 18:06:57 --> Config Class Initialized
INFO - 2022-06-05 18:06:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:06:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:06:57 --> Utf8 Class Initialized
INFO - 2022-06-05 18:06:57 --> URI Class Initialized
INFO - 2022-06-05 18:06:57 --> Router Class Initialized
INFO - 2022-06-05 18:06:57 --> Output Class Initialized
INFO - 2022-06-05 18:06:57 --> Security Class Initialized
DEBUG - 2022-06-05 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:06:57 --> Input Class Initialized
INFO - 2022-06-05 18:06:57 --> Language Class Initialized
INFO - 2022-06-05 18:06:57 --> Language Class Initialized
INFO - 2022-06-05 18:06:57 --> Config Class Initialized
INFO - 2022-06-05 18:06:57 --> Loader Class Initialized
INFO - 2022-06-05 18:06:57 --> Helper loaded: url_helper
INFO - 2022-06-05 18:06:57 --> Database Driver Class Initialized
INFO - 2022-06-05 18:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:06:57 --> Model Class Initialized
DEBUG - 2022-06-05 18:06:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:06:57 --> Model Class Initialized
INFO - 2022-06-05 18:06:57 --> Controller Class Initialized
DEBUG - 2022-06-05 18:06:57 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:06:57 --> Severity: Notice --> Undefined index: s.id N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 33
INFO - 2022-06-05 18:06:57 --> Final output sent to browser
DEBUG - 2022-06-05 18:06:57 --> Total execution time: 0.0373
INFO - 2022-06-05 18:07:16 --> Config Class Initialized
INFO - 2022-06-05 18:07:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:07:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:07:16 --> Utf8 Class Initialized
INFO - 2022-06-05 18:07:16 --> URI Class Initialized
INFO - 2022-06-05 18:07:16 --> Router Class Initialized
INFO - 2022-06-05 18:07:16 --> Output Class Initialized
INFO - 2022-06-05 18:07:16 --> Security Class Initialized
DEBUG - 2022-06-05 18:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:07:16 --> Input Class Initialized
INFO - 2022-06-05 18:07:16 --> Language Class Initialized
INFO - 2022-06-05 18:07:16 --> Language Class Initialized
INFO - 2022-06-05 18:07:16 --> Config Class Initialized
INFO - 2022-06-05 18:07:16 --> Loader Class Initialized
INFO - 2022-06-05 18:07:16 --> Helper loaded: url_helper
INFO - 2022-06-05 18:07:16 --> Database Driver Class Initialized
INFO - 2022-06-05 18:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:07:16 --> Model Class Initialized
DEBUG - 2022-06-05 18:07:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:07:16 --> Model Class Initialized
INFO - 2022-06-05 18:07:16 --> Controller Class Initialized
DEBUG - 2022-06-05 18:07:16 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:07:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:07:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:07:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:07:16 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:07:16 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:07:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:07:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:07:16 --> Final output sent to browser
DEBUG - 2022-06-05 18:07:16 --> Total execution time: 0.0306
INFO - 2022-06-05 18:07:17 --> Config Class Initialized
INFO - 2022-06-05 18:07:17 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:07:17 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:07:17 --> Utf8 Class Initialized
INFO - 2022-06-05 18:07:17 --> URI Class Initialized
INFO - 2022-06-05 18:07:17 --> Router Class Initialized
INFO - 2022-06-05 18:07:17 --> Output Class Initialized
INFO - 2022-06-05 18:07:17 --> Security Class Initialized
DEBUG - 2022-06-05 18:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:07:17 --> Input Class Initialized
INFO - 2022-06-05 18:07:17 --> Language Class Initialized
INFO - 2022-06-05 18:07:17 --> Language Class Initialized
INFO - 2022-06-05 18:07:17 --> Config Class Initialized
INFO - 2022-06-05 18:07:17 --> Loader Class Initialized
INFO - 2022-06-05 18:07:17 --> Helper loaded: url_helper
INFO - 2022-06-05 18:07:17 --> Database Driver Class Initialized
INFO - 2022-06-05 18:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:07:17 --> Model Class Initialized
DEBUG - 2022-06-05 18:07:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:07:17 --> Model Class Initialized
INFO - 2022-06-05 18:07:17 --> Controller Class Initialized
DEBUG - 2022-06-05 18:07:17 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:07:17 --> Final output sent to browser
DEBUG - 2022-06-05 18:07:17 --> Total execution time: 0.0410
INFO - 2022-06-05 18:07:37 --> Config Class Initialized
INFO - 2022-06-05 18:07:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:07:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:07:37 --> Utf8 Class Initialized
INFO - 2022-06-05 18:07:37 --> URI Class Initialized
INFO - 2022-06-05 18:07:37 --> Router Class Initialized
INFO - 2022-06-05 18:07:37 --> Output Class Initialized
INFO - 2022-06-05 18:07:37 --> Security Class Initialized
DEBUG - 2022-06-05 18:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:07:37 --> Input Class Initialized
INFO - 2022-06-05 18:07:37 --> Language Class Initialized
INFO - 2022-06-05 18:07:37 --> Language Class Initialized
INFO - 2022-06-05 18:07:37 --> Config Class Initialized
INFO - 2022-06-05 18:07:37 --> Loader Class Initialized
INFO - 2022-06-05 18:07:37 --> Helper loaded: url_helper
INFO - 2022-06-05 18:07:37 --> Database Driver Class Initialized
INFO - 2022-06-05 18:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:07:37 --> Model Class Initialized
DEBUG - 2022-06-05 18:07:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:07:37 --> Model Class Initialized
INFO - 2022-06-05 18:07:37 --> Controller Class Initialized
DEBUG - 2022-06-05 18:07:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:07:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:07:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:07:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:07:37 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:07:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:07:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:07:37 --> Final output sent to browser
DEBUG - 2022-06-05 18:07:37 --> Total execution time: 0.0412
INFO - 2022-06-05 18:07:39 --> Config Class Initialized
INFO - 2022-06-05 18:07:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:07:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:07:39 --> Utf8 Class Initialized
INFO - 2022-06-05 18:07:39 --> URI Class Initialized
INFO - 2022-06-05 18:07:39 --> Router Class Initialized
INFO - 2022-06-05 18:07:39 --> Output Class Initialized
INFO - 2022-06-05 18:07:39 --> Security Class Initialized
DEBUG - 2022-06-05 18:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:07:39 --> Input Class Initialized
INFO - 2022-06-05 18:07:39 --> Language Class Initialized
INFO - 2022-06-05 18:07:39 --> Language Class Initialized
INFO - 2022-06-05 18:07:39 --> Config Class Initialized
INFO - 2022-06-05 18:07:39 --> Loader Class Initialized
INFO - 2022-06-05 18:07:39 --> Helper loaded: url_helper
INFO - 2022-06-05 18:07:39 --> Database Driver Class Initialized
INFO - 2022-06-05 18:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:07:39 --> Model Class Initialized
DEBUG - 2022-06-05 18:07:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:07:39 --> Model Class Initialized
INFO - 2022-06-05 18:07:39 --> Controller Class Initialized
DEBUG - 2022-06-05 18:07:39 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:07:39 --> Final output sent to browser
DEBUG - 2022-06-05 18:07:39 --> Total execution time: 0.0378
INFO - 2022-06-05 18:07:53 --> Config Class Initialized
INFO - 2022-06-05 18:07:53 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:07:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:07:53 --> Utf8 Class Initialized
INFO - 2022-06-05 18:07:53 --> URI Class Initialized
INFO - 2022-06-05 18:07:53 --> Router Class Initialized
INFO - 2022-06-05 18:07:53 --> Output Class Initialized
INFO - 2022-06-05 18:07:53 --> Security Class Initialized
DEBUG - 2022-06-05 18:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:07:53 --> Input Class Initialized
INFO - 2022-06-05 18:07:53 --> Language Class Initialized
INFO - 2022-06-05 18:07:53 --> Language Class Initialized
INFO - 2022-06-05 18:07:53 --> Config Class Initialized
INFO - 2022-06-05 18:07:53 --> Loader Class Initialized
INFO - 2022-06-05 18:07:53 --> Helper loaded: url_helper
INFO - 2022-06-05 18:07:53 --> Database Driver Class Initialized
INFO - 2022-06-05 18:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:07:53 --> Model Class Initialized
DEBUG - 2022-06-05 18:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:07:53 --> Model Class Initialized
INFO - 2022-06-05 18:07:53 --> Controller Class Initialized
DEBUG - 2022-06-05 18:07:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:07:53 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:07:53 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:07:53 --> Final output sent to browser
DEBUG - 2022-06-05 18:07:53 --> Total execution time: 0.0304
INFO - 2022-06-05 18:07:54 --> Config Class Initialized
INFO - 2022-06-05 18:07:54 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:07:54 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:07:54 --> Utf8 Class Initialized
INFO - 2022-06-05 18:07:54 --> URI Class Initialized
INFO - 2022-06-05 18:07:54 --> Router Class Initialized
INFO - 2022-06-05 18:07:54 --> Output Class Initialized
INFO - 2022-06-05 18:07:54 --> Security Class Initialized
DEBUG - 2022-06-05 18:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:07:54 --> Input Class Initialized
INFO - 2022-06-05 18:07:54 --> Language Class Initialized
INFO - 2022-06-05 18:07:54 --> Language Class Initialized
INFO - 2022-06-05 18:07:54 --> Config Class Initialized
INFO - 2022-06-05 18:07:54 --> Loader Class Initialized
INFO - 2022-06-05 18:07:54 --> Helper loaded: url_helper
INFO - 2022-06-05 18:07:54 --> Database Driver Class Initialized
INFO - 2022-06-05 18:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:07:54 --> Model Class Initialized
DEBUG - 2022-06-05 18:07:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:07:54 --> Model Class Initialized
INFO - 2022-06-05 18:07:54 --> Controller Class Initialized
DEBUG - 2022-06-05 18:07:54 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:07:54 --> Final output sent to browser
DEBUG - 2022-06-05 18:07:54 --> Total execution time: 0.0362
INFO - 2022-06-05 18:08:05 --> Config Class Initialized
INFO - 2022-06-05 18:08:05 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:08:05 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:08:05 --> Utf8 Class Initialized
INFO - 2022-06-05 18:08:05 --> URI Class Initialized
INFO - 2022-06-05 18:08:05 --> Router Class Initialized
INFO - 2022-06-05 18:08:05 --> Output Class Initialized
INFO - 2022-06-05 18:08:05 --> Security Class Initialized
DEBUG - 2022-06-05 18:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:08:05 --> Input Class Initialized
INFO - 2022-06-05 18:08:05 --> Language Class Initialized
INFO - 2022-06-05 18:08:05 --> Language Class Initialized
INFO - 2022-06-05 18:08:05 --> Config Class Initialized
INFO - 2022-06-05 18:08:05 --> Loader Class Initialized
INFO - 2022-06-05 18:08:05 --> Helper loaded: url_helper
INFO - 2022-06-05 18:08:05 --> Database Driver Class Initialized
INFO - 2022-06-05 18:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:08:05 --> Model Class Initialized
DEBUG - 2022-06-05 18:08:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:08:05 --> Model Class Initialized
INFO - 2022-06-05 18:08:05 --> Controller Class Initialized
DEBUG - 2022-06-05 18:08:05 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:08:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:08:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:08:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:08:05 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:08:05 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:08:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:08:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:08:05 --> Final output sent to browser
DEBUG - 2022-06-05 18:08:05 --> Total execution time: 0.0388
INFO - 2022-06-05 18:08:07 --> Config Class Initialized
INFO - 2022-06-05 18:08:07 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:08:07 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:08:07 --> Utf8 Class Initialized
INFO - 2022-06-05 18:08:07 --> URI Class Initialized
INFO - 2022-06-05 18:08:07 --> Router Class Initialized
INFO - 2022-06-05 18:08:07 --> Output Class Initialized
INFO - 2022-06-05 18:08:07 --> Security Class Initialized
DEBUG - 2022-06-05 18:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:08:07 --> Input Class Initialized
INFO - 2022-06-05 18:08:07 --> Language Class Initialized
INFO - 2022-06-05 18:08:07 --> Language Class Initialized
INFO - 2022-06-05 18:08:07 --> Config Class Initialized
INFO - 2022-06-05 18:08:07 --> Loader Class Initialized
INFO - 2022-06-05 18:08:07 --> Helper loaded: url_helper
INFO - 2022-06-05 18:08:07 --> Database Driver Class Initialized
INFO - 2022-06-05 18:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:08:07 --> Model Class Initialized
DEBUG - 2022-06-05 18:08:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:08:07 --> Model Class Initialized
INFO - 2022-06-05 18:08:07 --> Controller Class Initialized
DEBUG - 2022-06-05 18:08:07 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:08:07 --> Final output sent to browser
DEBUG - 2022-06-05 18:08:07 --> Total execution time: 0.0368
INFO - 2022-06-05 18:08:10 --> Config Class Initialized
INFO - 2022-06-05 18:08:10 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:08:10 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:08:10 --> Utf8 Class Initialized
INFO - 2022-06-05 18:08:10 --> URI Class Initialized
INFO - 2022-06-05 18:08:10 --> Router Class Initialized
INFO - 2022-06-05 18:08:10 --> Output Class Initialized
INFO - 2022-06-05 18:08:10 --> Security Class Initialized
DEBUG - 2022-06-05 18:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:08:10 --> Input Class Initialized
INFO - 2022-06-05 18:08:10 --> Language Class Initialized
INFO - 2022-06-05 18:08:10 --> Language Class Initialized
INFO - 2022-06-05 18:08:10 --> Config Class Initialized
INFO - 2022-06-05 18:08:10 --> Loader Class Initialized
INFO - 2022-06-05 18:08:10 --> Helper loaded: url_helper
INFO - 2022-06-05 18:08:10 --> Database Driver Class Initialized
INFO - 2022-06-05 18:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:08:10 --> Model Class Initialized
DEBUG - 2022-06-05 18:08:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:08:10 --> Model Class Initialized
INFO - 2022-06-05 18:08:10 --> Controller Class Initialized
DEBUG - 2022-06-05 18:08:10 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:08:10 --> Final output sent to browser
DEBUG - 2022-06-05 18:08:10 --> Total execution time: 0.0349
INFO - 2022-06-05 18:08:40 --> Config Class Initialized
INFO - 2022-06-05 18:08:40 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:08:40 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:08:40 --> Utf8 Class Initialized
INFO - 2022-06-05 18:08:40 --> URI Class Initialized
INFO - 2022-06-05 18:08:40 --> Router Class Initialized
INFO - 2022-06-05 18:08:40 --> Output Class Initialized
INFO - 2022-06-05 18:08:40 --> Security Class Initialized
DEBUG - 2022-06-05 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:08:40 --> Input Class Initialized
INFO - 2022-06-05 18:08:40 --> Language Class Initialized
INFO - 2022-06-05 18:08:40 --> Language Class Initialized
INFO - 2022-06-05 18:08:40 --> Config Class Initialized
INFO - 2022-06-05 18:08:40 --> Loader Class Initialized
INFO - 2022-06-05 18:08:40 --> Helper loaded: url_helper
INFO - 2022-06-05 18:08:40 --> Database Driver Class Initialized
INFO - 2022-06-05 18:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:08:40 --> Model Class Initialized
DEBUG - 2022-06-05 18:08:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:08:40 --> Model Class Initialized
INFO - 2022-06-05 18:08:40 --> Controller Class Initialized
DEBUG - 2022-06-05 18:08:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:08:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:08:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:08:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:08:40 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:08:40 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:08:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:08:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:08:40 --> Final output sent to browser
DEBUG - 2022-06-05 18:08:40 --> Total execution time: 0.0289
INFO - 2022-06-05 18:08:42 --> Config Class Initialized
INFO - 2022-06-05 18:08:42 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:08:42 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:08:42 --> Utf8 Class Initialized
INFO - 2022-06-05 18:08:42 --> URI Class Initialized
INFO - 2022-06-05 18:08:42 --> Router Class Initialized
INFO - 2022-06-05 18:08:42 --> Output Class Initialized
INFO - 2022-06-05 18:08:42 --> Security Class Initialized
DEBUG - 2022-06-05 18:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:08:42 --> Input Class Initialized
INFO - 2022-06-05 18:08:42 --> Language Class Initialized
INFO - 2022-06-05 18:08:42 --> Language Class Initialized
INFO - 2022-06-05 18:08:42 --> Config Class Initialized
INFO - 2022-06-05 18:08:42 --> Loader Class Initialized
INFO - 2022-06-05 18:08:42 --> Helper loaded: url_helper
INFO - 2022-06-05 18:08:42 --> Database Driver Class Initialized
INFO - 2022-06-05 18:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:08:42 --> Model Class Initialized
DEBUG - 2022-06-05 18:08:42 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:08:42 --> Model Class Initialized
INFO - 2022-06-05 18:08:42 --> Controller Class Initialized
DEBUG - 2022-06-05 18:08:42 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:08:42 --> Final output sent to browser
DEBUG - 2022-06-05 18:08:42 --> Total execution time: 0.0384
INFO - 2022-06-05 18:09:08 --> Config Class Initialized
INFO - 2022-06-05 18:09:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:09:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:09:08 --> Utf8 Class Initialized
INFO - 2022-06-05 18:09:08 --> URI Class Initialized
INFO - 2022-06-05 18:09:08 --> Router Class Initialized
INFO - 2022-06-05 18:09:08 --> Output Class Initialized
INFO - 2022-06-05 18:09:08 --> Security Class Initialized
DEBUG - 2022-06-05 18:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:09:08 --> Input Class Initialized
INFO - 2022-06-05 18:09:08 --> Language Class Initialized
INFO - 2022-06-05 18:09:08 --> Language Class Initialized
INFO - 2022-06-05 18:09:08 --> Config Class Initialized
INFO - 2022-06-05 18:09:08 --> Loader Class Initialized
INFO - 2022-06-05 18:09:08 --> Helper loaded: url_helper
INFO - 2022-06-05 18:09:08 --> Database Driver Class Initialized
INFO - 2022-06-05 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:09:08 --> Model Class Initialized
DEBUG - 2022-06-05 18:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:09:08 --> Model Class Initialized
INFO - 2022-06-05 18:09:08 --> Controller Class Initialized
DEBUG - 2022-06-05 18:09:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:09:08 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:09:08 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:09:08 --> Final output sent to browser
DEBUG - 2022-06-05 18:09:08 --> Total execution time: 0.0430
INFO - 2022-06-05 18:09:10 --> Config Class Initialized
INFO - 2022-06-05 18:09:10 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:09:10 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:09:10 --> Utf8 Class Initialized
INFO - 2022-06-05 18:09:10 --> URI Class Initialized
INFO - 2022-06-05 18:09:10 --> Router Class Initialized
INFO - 2022-06-05 18:09:10 --> Output Class Initialized
INFO - 2022-06-05 18:09:10 --> Security Class Initialized
DEBUG - 2022-06-05 18:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:09:10 --> Input Class Initialized
INFO - 2022-06-05 18:09:10 --> Language Class Initialized
INFO - 2022-06-05 18:09:10 --> Language Class Initialized
INFO - 2022-06-05 18:09:10 --> Config Class Initialized
INFO - 2022-06-05 18:09:10 --> Loader Class Initialized
INFO - 2022-06-05 18:09:10 --> Helper loaded: url_helper
INFO - 2022-06-05 18:09:10 --> Database Driver Class Initialized
INFO - 2022-06-05 18:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:09:10 --> Model Class Initialized
DEBUG - 2022-06-05 18:09:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:09:10 --> Model Class Initialized
INFO - 2022-06-05 18:09:10 --> Controller Class Initialized
DEBUG - 2022-06-05 18:09:10 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:09:10 --> Severity: Notice --> Array to string conversion N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 31
INFO - 2022-06-05 18:09:10 --> Final output sent to browser
DEBUG - 2022-06-05 18:09:10 --> Total execution time: 0.0276
INFO - 2022-06-05 18:09:29 --> Config Class Initialized
INFO - 2022-06-05 18:09:29 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:09:29 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:09:29 --> Utf8 Class Initialized
INFO - 2022-06-05 18:09:29 --> URI Class Initialized
INFO - 2022-06-05 18:09:29 --> Router Class Initialized
INFO - 2022-06-05 18:09:29 --> Output Class Initialized
INFO - 2022-06-05 18:09:29 --> Security Class Initialized
DEBUG - 2022-06-05 18:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:09:29 --> Input Class Initialized
INFO - 2022-06-05 18:09:29 --> Language Class Initialized
INFO - 2022-06-05 18:09:29 --> Language Class Initialized
INFO - 2022-06-05 18:09:29 --> Config Class Initialized
INFO - 2022-06-05 18:09:29 --> Loader Class Initialized
INFO - 2022-06-05 18:09:29 --> Helper loaded: url_helper
INFO - 2022-06-05 18:09:29 --> Database Driver Class Initialized
INFO - 2022-06-05 18:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:09:29 --> Model Class Initialized
DEBUG - 2022-06-05 18:09:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:09:29 --> Model Class Initialized
INFO - 2022-06-05 18:09:29 --> Controller Class Initialized
DEBUG - 2022-06-05 18:09:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:09:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:09:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:09:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:09:29 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:09:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:09:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:09:29 --> Final output sent to browser
DEBUG - 2022-06-05 18:09:29 --> Total execution time: 0.0306
INFO - 2022-06-05 18:09:31 --> Config Class Initialized
INFO - 2022-06-05 18:09:31 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:09:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:09:31 --> Utf8 Class Initialized
INFO - 2022-06-05 18:09:31 --> URI Class Initialized
INFO - 2022-06-05 18:09:31 --> Router Class Initialized
INFO - 2022-06-05 18:09:31 --> Output Class Initialized
INFO - 2022-06-05 18:09:31 --> Security Class Initialized
DEBUG - 2022-06-05 18:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:09:31 --> Input Class Initialized
INFO - 2022-06-05 18:09:31 --> Language Class Initialized
INFO - 2022-06-05 18:09:31 --> Language Class Initialized
INFO - 2022-06-05 18:09:31 --> Config Class Initialized
INFO - 2022-06-05 18:09:31 --> Loader Class Initialized
INFO - 2022-06-05 18:09:31 --> Helper loaded: url_helper
INFO - 2022-06-05 18:09:31 --> Database Driver Class Initialized
INFO - 2022-06-05 18:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:09:31 --> Model Class Initialized
DEBUG - 2022-06-05 18:09:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:09:31 --> Model Class Initialized
INFO - 2022-06-05 18:09:31 --> Controller Class Initialized
DEBUG - 2022-06-05 18:09:31 --> Admin MX_Controller Initialized
ERROR - 2022-06-05 18:09:31 --> Severity: Notice --> Array to string conversion N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 31
INFO - 2022-06-05 18:09:31 --> Final output sent to browser
DEBUG - 2022-06-05 18:09:31 --> Total execution time: 0.0402
INFO - 2022-06-05 18:09:51 --> Config Class Initialized
INFO - 2022-06-05 18:09:51 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:09:51 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:09:51 --> Utf8 Class Initialized
INFO - 2022-06-05 18:09:51 --> URI Class Initialized
INFO - 2022-06-05 18:09:51 --> Router Class Initialized
INFO - 2022-06-05 18:09:51 --> Output Class Initialized
INFO - 2022-06-05 18:09:51 --> Security Class Initialized
DEBUG - 2022-06-05 18:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:09:51 --> Input Class Initialized
INFO - 2022-06-05 18:09:51 --> Language Class Initialized
INFO - 2022-06-05 18:09:51 --> Language Class Initialized
INFO - 2022-06-05 18:09:51 --> Config Class Initialized
INFO - 2022-06-05 18:09:51 --> Loader Class Initialized
INFO - 2022-06-05 18:09:51 --> Helper loaded: url_helper
INFO - 2022-06-05 18:09:51 --> Database Driver Class Initialized
INFO - 2022-06-05 18:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:09:51 --> Model Class Initialized
DEBUG - 2022-06-05 18:09:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:09:51 --> Model Class Initialized
INFO - 2022-06-05 18:09:51 --> Controller Class Initialized
DEBUG - 2022-06-05 18:09:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:09:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:09:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:09:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:09:51 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:09:51 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:09:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:09:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:09:51 --> Final output sent to browser
DEBUG - 2022-06-05 18:09:51 --> Total execution time: 0.0387
INFO - 2022-06-05 18:09:53 --> Config Class Initialized
INFO - 2022-06-05 18:09:53 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:09:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:09:53 --> Utf8 Class Initialized
INFO - 2022-06-05 18:09:53 --> URI Class Initialized
INFO - 2022-06-05 18:09:53 --> Router Class Initialized
INFO - 2022-06-05 18:09:53 --> Output Class Initialized
INFO - 2022-06-05 18:09:53 --> Security Class Initialized
DEBUG - 2022-06-05 18:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:09:53 --> Input Class Initialized
INFO - 2022-06-05 18:09:53 --> Language Class Initialized
INFO - 2022-06-05 18:09:53 --> Language Class Initialized
INFO - 2022-06-05 18:09:53 --> Config Class Initialized
INFO - 2022-06-05 18:09:53 --> Loader Class Initialized
INFO - 2022-06-05 18:09:53 --> Helper loaded: url_helper
INFO - 2022-06-05 18:09:53 --> Database Driver Class Initialized
INFO - 2022-06-05 18:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:09:53 --> Model Class Initialized
DEBUG - 2022-06-05 18:09:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:09:53 --> Model Class Initialized
INFO - 2022-06-05 18:09:53 --> Controller Class Initialized
DEBUG - 2022-06-05 18:09:53 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:09:53 --> Final output sent to browser
DEBUG - 2022-06-05 18:09:53 --> Total execution time: 0.0356
INFO - 2022-06-05 18:11:12 --> Config Class Initialized
INFO - 2022-06-05 18:11:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:11:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:11:12 --> Utf8 Class Initialized
INFO - 2022-06-05 18:11:12 --> URI Class Initialized
INFO - 2022-06-05 18:11:12 --> Router Class Initialized
INFO - 2022-06-05 18:11:12 --> Output Class Initialized
INFO - 2022-06-05 18:11:12 --> Security Class Initialized
DEBUG - 2022-06-05 18:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:11:12 --> Input Class Initialized
INFO - 2022-06-05 18:11:12 --> Language Class Initialized
INFO - 2022-06-05 18:11:12 --> Language Class Initialized
INFO - 2022-06-05 18:11:12 --> Config Class Initialized
INFO - 2022-06-05 18:11:12 --> Loader Class Initialized
INFO - 2022-06-05 18:11:12 --> Helper loaded: url_helper
INFO - 2022-06-05 18:11:12 --> Database Driver Class Initialized
INFO - 2022-06-05 18:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:11:12 --> Model Class Initialized
DEBUG - 2022-06-05 18:11:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:11:12 --> Model Class Initialized
INFO - 2022-06-05 18:11:12 --> Controller Class Initialized
DEBUG - 2022-06-05 18:11:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:11:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:11:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:11:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:11:12 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:11:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:11:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:11:12 --> Final output sent to browser
DEBUG - 2022-06-05 18:11:12 --> Total execution time: 0.0370
INFO - 2022-06-05 18:11:14 --> Config Class Initialized
INFO - 2022-06-05 18:11:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:11:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:11:14 --> Utf8 Class Initialized
INFO - 2022-06-05 18:11:14 --> URI Class Initialized
INFO - 2022-06-05 18:11:14 --> Router Class Initialized
INFO - 2022-06-05 18:11:14 --> Output Class Initialized
INFO - 2022-06-05 18:11:14 --> Security Class Initialized
DEBUG - 2022-06-05 18:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:11:14 --> Input Class Initialized
INFO - 2022-06-05 18:11:14 --> Language Class Initialized
INFO - 2022-06-05 18:11:14 --> Language Class Initialized
INFO - 2022-06-05 18:11:14 --> Config Class Initialized
INFO - 2022-06-05 18:11:14 --> Loader Class Initialized
INFO - 2022-06-05 18:11:14 --> Helper loaded: url_helper
INFO - 2022-06-05 18:11:14 --> Database Driver Class Initialized
INFO - 2022-06-05 18:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:11:14 --> Model Class Initialized
DEBUG - 2022-06-05 18:11:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:11:14 --> Model Class Initialized
INFO - 2022-06-05 18:11:14 --> Controller Class Initialized
DEBUG - 2022-06-05 18:11:14 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:11:14 --> Final output sent to browser
DEBUG - 2022-06-05 18:11:14 --> Total execution time: 0.0366
INFO - 2022-06-05 18:11:53 --> Config Class Initialized
INFO - 2022-06-05 18:11:53 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:11:53 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:11:53 --> Utf8 Class Initialized
INFO - 2022-06-05 18:11:53 --> URI Class Initialized
INFO - 2022-06-05 18:11:53 --> Router Class Initialized
INFO - 2022-06-05 18:11:53 --> Output Class Initialized
INFO - 2022-06-05 18:11:53 --> Security Class Initialized
DEBUG - 2022-06-05 18:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:11:53 --> Input Class Initialized
INFO - 2022-06-05 18:11:53 --> Language Class Initialized
INFO - 2022-06-05 18:11:53 --> Language Class Initialized
INFO - 2022-06-05 18:11:53 --> Config Class Initialized
INFO - 2022-06-05 18:11:53 --> Loader Class Initialized
INFO - 2022-06-05 18:11:53 --> Helper loaded: url_helper
INFO - 2022-06-05 18:11:53 --> Database Driver Class Initialized
INFO - 2022-06-05 18:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:11:53 --> Model Class Initialized
DEBUG - 2022-06-05 18:11:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:11:53 --> Model Class Initialized
INFO - 2022-06-05 18:11:53 --> Controller Class Initialized
DEBUG - 2022-06-05 18:11:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:11:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:11:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:11:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:11:53 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:11:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:11:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:11:53 --> Final output sent to browser
DEBUG - 2022-06-05 18:11:53 --> Total execution time: 0.0376
INFO - 2022-06-05 18:11:55 --> Config Class Initialized
INFO - 2022-06-05 18:11:55 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:11:55 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:11:55 --> Utf8 Class Initialized
INFO - 2022-06-05 18:11:55 --> URI Class Initialized
INFO - 2022-06-05 18:11:55 --> Router Class Initialized
INFO - 2022-06-05 18:11:55 --> Output Class Initialized
INFO - 2022-06-05 18:11:55 --> Security Class Initialized
DEBUG - 2022-06-05 18:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:11:55 --> Input Class Initialized
INFO - 2022-06-05 18:11:55 --> Language Class Initialized
INFO - 2022-06-05 18:11:55 --> Language Class Initialized
INFO - 2022-06-05 18:11:55 --> Config Class Initialized
INFO - 2022-06-05 18:11:55 --> Loader Class Initialized
INFO - 2022-06-05 18:11:55 --> Helper loaded: url_helper
INFO - 2022-06-05 18:11:55 --> Database Driver Class Initialized
INFO - 2022-06-05 18:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:11:55 --> Model Class Initialized
DEBUG - 2022-06-05 18:11:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:11:55 --> Model Class Initialized
INFO - 2022-06-05 18:11:55 --> Controller Class Initialized
DEBUG - 2022-06-05 18:11:55 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:11:55 --> Final output sent to browser
DEBUG - 2022-06-05 18:11:55 --> Total execution time: 0.0267
INFO - 2022-06-05 18:12:16 --> Config Class Initialized
INFO - 2022-06-05 18:12:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:12:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:12:16 --> Utf8 Class Initialized
INFO - 2022-06-05 18:12:16 --> URI Class Initialized
INFO - 2022-06-05 18:12:16 --> Router Class Initialized
INFO - 2022-06-05 18:12:16 --> Output Class Initialized
INFO - 2022-06-05 18:12:16 --> Security Class Initialized
DEBUG - 2022-06-05 18:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:12:16 --> Input Class Initialized
INFO - 2022-06-05 18:12:16 --> Language Class Initialized
INFO - 2022-06-05 18:12:16 --> Language Class Initialized
INFO - 2022-06-05 18:12:16 --> Config Class Initialized
INFO - 2022-06-05 18:12:16 --> Loader Class Initialized
INFO - 2022-06-05 18:12:16 --> Helper loaded: url_helper
INFO - 2022-06-05 18:12:16 --> Database Driver Class Initialized
INFO - 2022-06-05 18:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:12:16 --> Model Class Initialized
DEBUG - 2022-06-05 18:12:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:12:16 --> Model Class Initialized
INFO - 2022-06-05 18:12:16 --> Controller Class Initialized
DEBUG - 2022-06-05 18:12:16 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:12:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:12:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:12:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:12:16 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:12:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:12:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:12:16 --> Final output sent to browser
DEBUG - 2022-06-05 18:12:16 --> Total execution time: 0.0381
INFO - 2022-06-05 18:12:18 --> Config Class Initialized
INFO - 2022-06-05 18:12:18 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:12:18 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:12:18 --> Utf8 Class Initialized
INFO - 2022-06-05 18:12:18 --> URI Class Initialized
INFO - 2022-06-05 18:12:18 --> Router Class Initialized
INFO - 2022-06-05 18:12:18 --> Output Class Initialized
INFO - 2022-06-05 18:12:18 --> Security Class Initialized
DEBUG - 2022-06-05 18:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:12:18 --> Input Class Initialized
INFO - 2022-06-05 18:12:18 --> Language Class Initialized
INFO - 2022-06-05 18:12:18 --> Language Class Initialized
INFO - 2022-06-05 18:12:18 --> Config Class Initialized
INFO - 2022-06-05 18:12:18 --> Loader Class Initialized
INFO - 2022-06-05 18:12:18 --> Helper loaded: url_helper
INFO - 2022-06-05 18:12:18 --> Database Driver Class Initialized
INFO - 2022-06-05 18:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:12:18 --> Model Class Initialized
DEBUG - 2022-06-05 18:12:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:12:18 --> Model Class Initialized
INFO - 2022-06-05 18:12:18 --> Controller Class Initialized
DEBUG - 2022-06-05 18:12:18 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:12:18 --> Final output sent to browser
DEBUG - 2022-06-05 18:12:18 --> Total execution time: 0.0365
INFO - 2022-06-05 18:13:21 --> Config Class Initialized
INFO - 2022-06-05 18:13:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:13:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:13:21 --> Utf8 Class Initialized
INFO - 2022-06-05 18:13:21 --> URI Class Initialized
INFO - 2022-06-05 18:13:21 --> Router Class Initialized
INFO - 2022-06-05 18:13:21 --> Output Class Initialized
INFO - 2022-06-05 18:13:21 --> Security Class Initialized
DEBUG - 2022-06-05 18:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:13:21 --> Input Class Initialized
INFO - 2022-06-05 18:13:21 --> Language Class Initialized
INFO - 2022-06-05 18:13:21 --> Language Class Initialized
INFO - 2022-06-05 18:13:21 --> Config Class Initialized
INFO - 2022-06-05 18:13:21 --> Loader Class Initialized
INFO - 2022-06-05 18:13:21 --> Helper loaded: url_helper
INFO - 2022-06-05 18:13:21 --> Database Driver Class Initialized
INFO - 2022-06-05 18:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:13:21 --> Model Class Initialized
DEBUG - 2022-06-05 18:13:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:13:21 --> Model Class Initialized
INFO - 2022-06-05 18:13:21 --> Controller Class Initialized
DEBUG - 2022-06-05 18:13:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:13:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:13:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:13:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:13:21 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:13:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:13:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:13:21 --> Final output sent to browser
DEBUG - 2022-06-05 18:13:21 --> Total execution time: 0.0395
INFO - 2022-06-05 18:13:23 --> Config Class Initialized
INFO - 2022-06-05 18:13:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:13:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:13:23 --> Utf8 Class Initialized
INFO - 2022-06-05 18:13:23 --> URI Class Initialized
INFO - 2022-06-05 18:13:23 --> Router Class Initialized
INFO - 2022-06-05 18:13:23 --> Output Class Initialized
INFO - 2022-06-05 18:13:23 --> Security Class Initialized
DEBUG - 2022-06-05 18:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:13:23 --> Input Class Initialized
INFO - 2022-06-05 18:13:23 --> Language Class Initialized
INFO - 2022-06-05 18:13:23 --> Language Class Initialized
INFO - 2022-06-05 18:13:23 --> Config Class Initialized
INFO - 2022-06-05 18:13:23 --> Loader Class Initialized
INFO - 2022-06-05 18:13:23 --> Helper loaded: url_helper
INFO - 2022-06-05 18:13:23 --> Database Driver Class Initialized
INFO - 2022-06-05 18:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:13:23 --> Model Class Initialized
DEBUG - 2022-06-05 18:13:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:13:23 --> Model Class Initialized
INFO - 2022-06-05 18:13:23 --> Controller Class Initialized
DEBUG - 2022-06-05 18:13:23 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:13:23 --> Final output sent to browser
DEBUG - 2022-06-05 18:13:23 --> Total execution time: 0.0443
INFO - 2022-06-05 18:13:39 --> Config Class Initialized
INFO - 2022-06-05 18:13:39 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:13:39 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:13:39 --> Utf8 Class Initialized
INFO - 2022-06-05 18:13:39 --> URI Class Initialized
INFO - 2022-06-05 18:13:39 --> Router Class Initialized
INFO - 2022-06-05 18:13:39 --> Output Class Initialized
INFO - 2022-06-05 18:13:39 --> Security Class Initialized
DEBUG - 2022-06-05 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:13:39 --> Input Class Initialized
INFO - 2022-06-05 18:13:39 --> Language Class Initialized
INFO - 2022-06-05 18:13:39 --> Language Class Initialized
INFO - 2022-06-05 18:13:39 --> Config Class Initialized
INFO - 2022-06-05 18:13:39 --> Loader Class Initialized
INFO - 2022-06-05 18:13:39 --> Helper loaded: url_helper
INFO - 2022-06-05 18:13:39 --> Database Driver Class Initialized
INFO - 2022-06-05 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:13:39 --> Model Class Initialized
DEBUG - 2022-06-05 18:13:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:13:39 --> Model Class Initialized
INFO - 2022-06-05 18:13:39 --> Controller Class Initialized
DEBUG - 2022-06-05 18:13:39 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:13:39 --> Final output sent to browser
DEBUG - 2022-06-05 18:13:39 --> Total execution time: 0.0348
INFO - 2022-06-05 18:14:33 --> Config Class Initialized
INFO - 2022-06-05 18:14:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:14:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:14:33 --> Utf8 Class Initialized
INFO - 2022-06-05 18:14:33 --> URI Class Initialized
INFO - 2022-06-05 18:14:33 --> Router Class Initialized
INFO - 2022-06-05 18:14:33 --> Output Class Initialized
INFO - 2022-06-05 18:14:33 --> Security Class Initialized
DEBUG - 2022-06-05 18:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:14:33 --> Input Class Initialized
INFO - 2022-06-05 18:14:33 --> Language Class Initialized
INFO - 2022-06-05 18:14:33 --> Language Class Initialized
INFO - 2022-06-05 18:14:33 --> Config Class Initialized
INFO - 2022-06-05 18:14:33 --> Loader Class Initialized
INFO - 2022-06-05 18:14:33 --> Helper loaded: url_helper
INFO - 2022-06-05 18:14:33 --> Database Driver Class Initialized
INFO - 2022-06-05 18:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:14:33 --> Model Class Initialized
DEBUG - 2022-06-05 18:14:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:14:33 --> Model Class Initialized
INFO - 2022-06-05 18:14:33 --> Controller Class Initialized
DEBUG - 2022-06-05 18:14:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:14:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:14:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:14:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:14:33 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:14:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:14:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:14:33 --> Final output sent to browser
DEBUG - 2022-06-05 18:14:33 --> Total execution time: 0.0395
INFO - 2022-06-05 18:14:35 --> Config Class Initialized
INFO - 2022-06-05 18:14:35 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:14:35 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:14:35 --> Utf8 Class Initialized
INFO - 2022-06-05 18:14:35 --> URI Class Initialized
INFO - 2022-06-05 18:14:35 --> Router Class Initialized
INFO - 2022-06-05 18:14:35 --> Output Class Initialized
INFO - 2022-06-05 18:14:35 --> Security Class Initialized
DEBUG - 2022-06-05 18:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:14:35 --> Input Class Initialized
INFO - 2022-06-05 18:14:35 --> Language Class Initialized
INFO - 2022-06-05 18:14:35 --> Language Class Initialized
INFO - 2022-06-05 18:14:35 --> Config Class Initialized
INFO - 2022-06-05 18:14:35 --> Loader Class Initialized
INFO - 2022-06-05 18:14:35 --> Helper loaded: url_helper
INFO - 2022-06-05 18:14:35 --> Database Driver Class Initialized
INFO - 2022-06-05 18:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:14:35 --> Model Class Initialized
DEBUG - 2022-06-05 18:14:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:14:35 --> Model Class Initialized
INFO - 2022-06-05 18:14:35 --> Controller Class Initialized
DEBUG - 2022-06-05 18:14:35 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:14:35 --> Final output sent to browser
DEBUG - 2022-06-05 18:14:35 --> Total execution time: 0.0362
INFO - 2022-06-05 18:14:59 --> Config Class Initialized
INFO - 2022-06-05 18:14:59 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:14:59 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:14:59 --> Utf8 Class Initialized
INFO - 2022-06-05 18:14:59 --> URI Class Initialized
INFO - 2022-06-05 18:14:59 --> Router Class Initialized
INFO - 2022-06-05 18:14:59 --> Output Class Initialized
INFO - 2022-06-05 18:14:59 --> Security Class Initialized
DEBUG - 2022-06-05 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:14:59 --> Input Class Initialized
INFO - 2022-06-05 18:14:59 --> Language Class Initialized
INFO - 2022-06-05 18:14:59 --> Language Class Initialized
INFO - 2022-06-05 18:14:59 --> Config Class Initialized
INFO - 2022-06-05 18:14:59 --> Loader Class Initialized
INFO - 2022-06-05 18:14:59 --> Helper loaded: url_helper
INFO - 2022-06-05 18:14:59 --> Database Driver Class Initialized
INFO - 2022-06-05 18:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:14:59 --> Model Class Initialized
DEBUG - 2022-06-05 18:14:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:14:59 --> Model Class Initialized
INFO - 2022-06-05 18:14:59 --> Controller Class Initialized
DEBUG - 2022-06-05 18:14:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:14:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:14:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:14:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:14:59 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:14:59 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:14:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:14:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:14:59 --> Final output sent to browser
DEBUG - 2022-06-05 18:14:59 --> Total execution time: 0.0411
INFO - 2022-06-05 18:15:00 --> Config Class Initialized
INFO - 2022-06-05 18:15:00 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:15:00 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:15:00 --> Utf8 Class Initialized
INFO - 2022-06-05 18:15:00 --> URI Class Initialized
INFO - 2022-06-05 18:15:00 --> Router Class Initialized
INFO - 2022-06-05 18:15:00 --> Output Class Initialized
INFO - 2022-06-05 18:15:00 --> Security Class Initialized
DEBUG - 2022-06-05 18:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:15:00 --> Input Class Initialized
INFO - 2022-06-05 18:15:00 --> Language Class Initialized
INFO - 2022-06-05 18:15:00 --> Language Class Initialized
INFO - 2022-06-05 18:15:00 --> Config Class Initialized
INFO - 2022-06-05 18:15:00 --> Loader Class Initialized
INFO - 2022-06-05 18:15:00 --> Helper loaded: url_helper
INFO - 2022-06-05 18:15:00 --> Database Driver Class Initialized
INFO - 2022-06-05 18:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:15:00 --> Model Class Initialized
DEBUG - 2022-06-05 18:15:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:15:00 --> Model Class Initialized
INFO - 2022-06-05 18:15:00 --> Controller Class Initialized
DEBUG - 2022-06-05 18:15:00 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:15:00 --> Final output sent to browser
DEBUG - 2022-06-05 18:15:00 --> Total execution time: 0.0363
INFO - 2022-06-05 18:15:22 --> Config Class Initialized
INFO - 2022-06-05 18:15:22 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:15:22 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:15:22 --> Utf8 Class Initialized
INFO - 2022-06-05 18:15:22 --> URI Class Initialized
INFO - 2022-06-05 18:15:22 --> Router Class Initialized
INFO - 2022-06-05 18:15:22 --> Output Class Initialized
INFO - 2022-06-05 18:15:22 --> Security Class Initialized
DEBUG - 2022-06-05 18:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:15:22 --> Input Class Initialized
INFO - 2022-06-05 18:15:22 --> Language Class Initialized
INFO - 2022-06-05 18:15:22 --> Language Class Initialized
INFO - 2022-06-05 18:15:22 --> Config Class Initialized
INFO - 2022-06-05 18:15:22 --> Loader Class Initialized
INFO - 2022-06-05 18:15:22 --> Helper loaded: url_helper
INFO - 2022-06-05 18:15:22 --> Database Driver Class Initialized
INFO - 2022-06-05 18:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:15:22 --> Model Class Initialized
DEBUG - 2022-06-05 18:15:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:15:22 --> Model Class Initialized
INFO - 2022-06-05 18:15:22 --> Controller Class Initialized
DEBUG - 2022-06-05 18:15:22 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:15:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:15:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:15:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:15:22 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:15:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:15:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:15:22 --> Final output sent to browser
DEBUG - 2022-06-05 18:15:22 --> Total execution time: 0.0336
INFO - 2022-06-05 18:15:24 --> Config Class Initialized
INFO - 2022-06-05 18:15:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:15:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:15:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:15:24 --> URI Class Initialized
INFO - 2022-06-05 18:15:24 --> Router Class Initialized
INFO - 2022-06-05 18:15:24 --> Output Class Initialized
INFO - 2022-06-05 18:15:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:15:24 --> Input Class Initialized
INFO - 2022-06-05 18:15:24 --> Language Class Initialized
INFO - 2022-06-05 18:15:24 --> Language Class Initialized
INFO - 2022-06-05 18:15:24 --> Config Class Initialized
INFO - 2022-06-05 18:15:24 --> Loader Class Initialized
INFO - 2022-06-05 18:15:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:15:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:15:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:15:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:15:24 --> Model Class Initialized
INFO - 2022-06-05 18:15:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:15:24 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:15:24 --> Final output sent to browser
DEBUG - 2022-06-05 18:15:24 --> Total execution time: 0.0311
INFO - 2022-06-05 18:16:46 --> Config Class Initialized
INFO - 2022-06-05 18:16:46 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:16:46 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:16:46 --> Utf8 Class Initialized
INFO - 2022-06-05 18:16:46 --> URI Class Initialized
INFO - 2022-06-05 18:16:46 --> Router Class Initialized
INFO - 2022-06-05 18:16:46 --> Output Class Initialized
INFO - 2022-06-05 18:16:46 --> Security Class Initialized
DEBUG - 2022-06-05 18:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:16:46 --> Input Class Initialized
INFO - 2022-06-05 18:16:46 --> Language Class Initialized
INFO - 2022-06-05 18:16:46 --> Language Class Initialized
INFO - 2022-06-05 18:16:46 --> Config Class Initialized
INFO - 2022-06-05 18:16:46 --> Loader Class Initialized
INFO - 2022-06-05 18:16:46 --> Helper loaded: url_helper
INFO - 2022-06-05 18:16:46 --> Database Driver Class Initialized
INFO - 2022-06-05 18:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:16:46 --> Model Class Initialized
DEBUG - 2022-06-05 18:16:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:16:46 --> Model Class Initialized
INFO - 2022-06-05 18:16:46 --> Controller Class Initialized
DEBUG - 2022-06-05 18:16:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:16:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:16:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:16:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:16:46 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:16:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:16:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:16:46 --> Final output sent to browser
DEBUG - 2022-06-05 18:16:46 --> Total execution time: 0.0397
INFO - 2022-06-05 18:16:48 --> Config Class Initialized
INFO - 2022-06-05 18:16:48 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:16:48 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:16:48 --> Utf8 Class Initialized
INFO - 2022-06-05 18:16:48 --> URI Class Initialized
INFO - 2022-06-05 18:16:48 --> Router Class Initialized
INFO - 2022-06-05 18:16:48 --> Output Class Initialized
INFO - 2022-06-05 18:16:48 --> Security Class Initialized
DEBUG - 2022-06-05 18:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:16:48 --> Input Class Initialized
INFO - 2022-06-05 18:16:48 --> Language Class Initialized
INFO - 2022-06-05 18:16:48 --> Language Class Initialized
INFO - 2022-06-05 18:16:48 --> Config Class Initialized
INFO - 2022-06-05 18:16:48 --> Loader Class Initialized
INFO - 2022-06-05 18:16:48 --> Helper loaded: url_helper
INFO - 2022-06-05 18:16:48 --> Database Driver Class Initialized
INFO - 2022-06-05 18:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:16:48 --> Model Class Initialized
DEBUG - 2022-06-05 18:16:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:16:48 --> Model Class Initialized
INFO - 2022-06-05 18:16:48 --> Controller Class Initialized
DEBUG - 2022-06-05 18:16:48 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:16:48 --> Final output sent to browser
DEBUG - 2022-06-05 18:16:48 --> Total execution time: 0.0360
INFO - 2022-06-05 18:17:07 --> Config Class Initialized
INFO - 2022-06-05 18:17:07 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:17:07 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:17:07 --> Utf8 Class Initialized
INFO - 2022-06-05 18:17:07 --> URI Class Initialized
INFO - 2022-06-05 18:17:07 --> Router Class Initialized
INFO - 2022-06-05 18:17:07 --> Output Class Initialized
INFO - 2022-06-05 18:17:07 --> Security Class Initialized
DEBUG - 2022-06-05 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:17:07 --> Input Class Initialized
INFO - 2022-06-05 18:17:07 --> Language Class Initialized
INFO - 2022-06-05 18:17:07 --> Language Class Initialized
INFO - 2022-06-05 18:17:07 --> Config Class Initialized
INFO - 2022-06-05 18:17:07 --> Loader Class Initialized
INFO - 2022-06-05 18:17:07 --> Helper loaded: url_helper
INFO - 2022-06-05 18:17:07 --> Database Driver Class Initialized
INFO - 2022-06-05 18:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:17:07 --> Model Class Initialized
DEBUG - 2022-06-05 18:17:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:17:07 --> Model Class Initialized
INFO - 2022-06-05 18:17:07 --> Controller Class Initialized
DEBUG - 2022-06-05 18:17:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:17:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:17:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:17:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:17:07 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:17:07 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:17:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:17:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:17:07 --> Final output sent to browser
DEBUG - 2022-06-05 18:17:07 --> Total execution time: 0.0283
INFO - 2022-06-05 18:17:12 --> Config Class Initialized
INFO - 2022-06-05 18:17:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:17:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:17:12 --> Utf8 Class Initialized
INFO - 2022-06-05 18:17:12 --> URI Class Initialized
INFO - 2022-06-05 18:17:12 --> Router Class Initialized
INFO - 2022-06-05 18:17:12 --> Output Class Initialized
INFO - 2022-06-05 18:17:12 --> Security Class Initialized
DEBUG - 2022-06-05 18:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:17:12 --> Input Class Initialized
INFO - 2022-06-05 18:17:12 --> Language Class Initialized
INFO - 2022-06-05 18:17:12 --> Language Class Initialized
INFO - 2022-06-05 18:17:12 --> Config Class Initialized
INFO - 2022-06-05 18:17:12 --> Loader Class Initialized
INFO - 2022-06-05 18:17:12 --> Helper loaded: url_helper
INFO - 2022-06-05 18:17:12 --> Database Driver Class Initialized
INFO - 2022-06-05 18:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:17:12 --> Model Class Initialized
DEBUG - 2022-06-05 18:17:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:17:12 --> Model Class Initialized
INFO - 2022-06-05 18:17:12 --> Controller Class Initialized
DEBUG - 2022-06-05 18:17:12 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:17:12 --> Final output sent to browser
DEBUG - 2022-06-05 18:17:12 --> Total execution time: 0.0282
INFO - 2022-06-05 18:17:52 --> Config Class Initialized
INFO - 2022-06-05 18:17:52 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:17:52 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:17:52 --> Utf8 Class Initialized
INFO - 2022-06-05 18:17:52 --> URI Class Initialized
INFO - 2022-06-05 18:17:52 --> Router Class Initialized
INFO - 2022-06-05 18:17:52 --> Output Class Initialized
INFO - 2022-06-05 18:17:52 --> Security Class Initialized
DEBUG - 2022-06-05 18:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:17:52 --> Input Class Initialized
INFO - 2022-06-05 18:17:52 --> Language Class Initialized
INFO - 2022-06-05 18:17:52 --> Language Class Initialized
INFO - 2022-06-05 18:17:52 --> Config Class Initialized
INFO - 2022-06-05 18:17:52 --> Loader Class Initialized
INFO - 2022-06-05 18:17:52 --> Helper loaded: url_helper
INFO - 2022-06-05 18:17:52 --> Database Driver Class Initialized
INFO - 2022-06-05 18:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:17:52 --> Model Class Initialized
DEBUG - 2022-06-05 18:17:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:17:52 --> Model Class Initialized
INFO - 2022-06-05 18:17:52 --> Controller Class Initialized
DEBUG - 2022-06-05 18:17:52 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:17:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:17:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:17:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:17:52 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:17:52 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:17:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:17:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:17:52 --> Final output sent to browser
DEBUG - 2022-06-05 18:17:52 --> Total execution time: 0.0404
INFO - 2022-06-05 18:17:54 --> Config Class Initialized
INFO - 2022-06-05 18:17:54 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:17:54 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:17:54 --> Utf8 Class Initialized
INFO - 2022-06-05 18:17:54 --> URI Class Initialized
INFO - 2022-06-05 18:17:54 --> Router Class Initialized
INFO - 2022-06-05 18:17:54 --> Output Class Initialized
INFO - 2022-06-05 18:17:54 --> Security Class Initialized
DEBUG - 2022-06-05 18:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:17:54 --> Input Class Initialized
INFO - 2022-06-05 18:17:54 --> Language Class Initialized
INFO - 2022-06-05 18:17:54 --> Language Class Initialized
INFO - 2022-06-05 18:17:54 --> Config Class Initialized
INFO - 2022-06-05 18:17:54 --> Loader Class Initialized
INFO - 2022-06-05 18:17:54 --> Helper loaded: url_helper
INFO - 2022-06-05 18:17:54 --> Database Driver Class Initialized
INFO - 2022-06-05 18:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:17:54 --> Model Class Initialized
DEBUG - 2022-06-05 18:17:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:17:54 --> Model Class Initialized
INFO - 2022-06-05 18:17:54 --> Controller Class Initialized
DEBUG - 2022-06-05 18:17:54 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:17:54 --> Final output sent to browser
DEBUG - 2022-06-05 18:17:54 --> Total execution time: 0.0355
INFO - 2022-06-05 18:18:33 --> Config Class Initialized
INFO - 2022-06-05 18:18:33 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:18:33 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:18:33 --> Utf8 Class Initialized
INFO - 2022-06-05 18:18:33 --> URI Class Initialized
INFO - 2022-06-05 18:18:33 --> Router Class Initialized
INFO - 2022-06-05 18:18:33 --> Output Class Initialized
INFO - 2022-06-05 18:18:33 --> Security Class Initialized
DEBUG - 2022-06-05 18:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:18:33 --> Input Class Initialized
INFO - 2022-06-05 18:18:33 --> Language Class Initialized
INFO - 2022-06-05 18:18:33 --> Language Class Initialized
INFO - 2022-06-05 18:18:33 --> Config Class Initialized
INFO - 2022-06-05 18:18:33 --> Loader Class Initialized
INFO - 2022-06-05 18:18:33 --> Helper loaded: url_helper
INFO - 2022-06-05 18:18:33 --> Database Driver Class Initialized
INFO - 2022-06-05 18:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:18:33 --> Model Class Initialized
DEBUG - 2022-06-05 18:18:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:18:33 --> Model Class Initialized
INFO - 2022-06-05 18:18:33 --> Controller Class Initialized
DEBUG - 2022-06-05 18:18:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:18:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:18:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:18:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:18:33 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:18:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:18:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:18:33 --> Final output sent to browser
DEBUG - 2022-06-05 18:18:33 --> Total execution time: 0.0397
INFO - 2022-06-05 18:18:36 --> Config Class Initialized
INFO - 2022-06-05 18:18:36 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:18:36 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:18:36 --> Utf8 Class Initialized
INFO - 2022-06-05 18:18:36 --> URI Class Initialized
INFO - 2022-06-05 18:18:36 --> Router Class Initialized
INFO - 2022-06-05 18:18:36 --> Output Class Initialized
INFO - 2022-06-05 18:18:36 --> Security Class Initialized
DEBUG - 2022-06-05 18:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:18:36 --> Input Class Initialized
INFO - 2022-06-05 18:18:36 --> Language Class Initialized
INFO - 2022-06-05 18:18:36 --> Language Class Initialized
INFO - 2022-06-05 18:18:36 --> Config Class Initialized
INFO - 2022-06-05 18:18:36 --> Loader Class Initialized
INFO - 2022-06-05 18:18:36 --> Helper loaded: url_helper
INFO - 2022-06-05 18:18:36 --> Database Driver Class Initialized
INFO - 2022-06-05 18:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:18:36 --> Model Class Initialized
DEBUG - 2022-06-05 18:18:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:18:36 --> Model Class Initialized
INFO - 2022-06-05 18:18:36 --> Controller Class Initialized
DEBUG - 2022-06-05 18:18:36 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:18:36 --> Final output sent to browser
DEBUG - 2022-06-05 18:18:36 --> Total execution time: 0.0394
INFO - 2022-06-05 18:19:09 --> Config Class Initialized
INFO - 2022-06-05 18:19:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:19:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:19:09 --> Utf8 Class Initialized
INFO - 2022-06-05 18:19:09 --> URI Class Initialized
INFO - 2022-06-05 18:19:09 --> Router Class Initialized
INFO - 2022-06-05 18:19:09 --> Output Class Initialized
INFO - 2022-06-05 18:19:09 --> Security Class Initialized
DEBUG - 2022-06-05 18:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:19:09 --> Input Class Initialized
INFO - 2022-06-05 18:19:09 --> Language Class Initialized
INFO - 2022-06-05 18:19:09 --> Language Class Initialized
INFO - 2022-06-05 18:19:09 --> Config Class Initialized
INFO - 2022-06-05 18:19:09 --> Loader Class Initialized
INFO - 2022-06-05 18:19:09 --> Helper loaded: url_helper
INFO - 2022-06-05 18:19:09 --> Database Driver Class Initialized
INFO - 2022-06-05 18:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:19:09 --> Model Class Initialized
DEBUG - 2022-06-05 18:19:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:19:09 --> Model Class Initialized
INFO - 2022-06-05 18:19:09 --> Controller Class Initialized
DEBUG - 2022-06-05 18:19:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:19:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:19:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:19:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:19:09 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:19:09 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:19:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:19:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:19:09 --> Final output sent to browser
DEBUG - 2022-06-05 18:19:09 --> Total execution time: 0.0384
INFO - 2022-06-05 18:19:11 --> Config Class Initialized
INFO - 2022-06-05 18:19:11 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:19:11 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:19:11 --> Utf8 Class Initialized
INFO - 2022-06-05 18:19:11 --> URI Class Initialized
INFO - 2022-06-05 18:19:11 --> Router Class Initialized
INFO - 2022-06-05 18:19:11 --> Output Class Initialized
INFO - 2022-06-05 18:19:11 --> Security Class Initialized
DEBUG - 2022-06-05 18:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:19:11 --> Input Class Initialized
INFO - 2022-06-05 18:19:11 --> Language Class Initialized
INFO - 2022-06-05 18:19:11 --> Language Class Initialized
INFO - 2022-06-05 18:19:11 --> Config Class Initialized
INFO - 2022-06-05 18:19:11 --> Loader Class Initialized
INFO - 2022-06-05 18:19:11 --> Helper loaded: url_helper
INFO - 2022-06-05 18:19:11 --> Database Driver Class Initialized
INFO - 2022-06-05 18:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:19:11 --> Model Class Initialized
DEBUG - 2022-06-05 18:19:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:19:11 --> Model Class Initialized
INFO - 2022-06-05 18:19:11 --> Controller Class Initialized
DEBUG - 2022-06-05 18:19:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:19:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:19:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:19:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:19:11 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:19:11 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:19:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:19:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:19:11 --> Final output sent to browser
DEBUG - 2022-06-05 18:19:11 --> Total execution time: 0.0380
INFO - 2022-06-05 18:19:12 --> Config Class Initialized
INFO - 2022-06-05 18:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:19:12 --> Utf8 Class Initialized
INFO - 2022-06-05 18:19:12 --> URI Class Initialized
INFO - 2022-06-05 18:19:12 --> Router Class Initialized
INFO - 2022-06-05 18:19:12 --> Output Class Initialized
INFO - 2022-06-05 18:19:12 --> Security Class Initialized
DEBUG - 2022-06-05 18:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:19:12 --> Input Class Initialized
INFO - 2022-06-05 18:19:12 --> Language Class Initialized
INFO - 2022-06-05 18:19:12 --> Language Class Initialized
INFO - 2022-06-05 18:19:12 --> Config Class Initialized
INFO - 2022-06-05 18:19:12 --> Loader Class Initialized
INFO - 2022-06-05 18:19:12 --> Helper loaded: url_helper
INFO - 2022-06-05 18:19:12 --> Database Driver Class Initialized
INFO - 2022-06-05 18:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:19:12 --> Model Class Initialized
DEBUG - 2022-06-05 18:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:19:12 --> Model Class Initialized
INFO - 2022-06-05 18:19:12 --> Controller Class Initialized
DEBUG - 2022-06-05 18:19:12 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:19:12 --> Final output sent to browser
DEBUG - 2022-06-05 18:19:12 --> Total execution time: 0.0447
INFO - 2022-06-05 18:19:21 --> Config Class Initialized
INFO - 2022-06-05 18:19:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:19:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:19:21 --> Utf8 Class Initialized
INFO - 2022-06-05 18:19:21 --> URI Class Initialized
INFO - 2022-06-05 18:19:21 --> Router Class Initialized
INFO - 2022-06-05 18:19:21 --> Output Class Initialized
INFO - 2022-06-05 18:19:21 --> Security Class Initialized
DEBUG - 2022-06-05 18:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:19:21 --> Input Class Initialized
INFO - 2022-06-05 18:19:21 --> Language Class Initialized
INFO - 2022-06-05 18:19:21 --> Language Class Initialized
INFO - 2022-06-05 18:19:21 --> Config Class Initialized
INFO - 2022-06-05 18:19:21 --> Loader Class Initialized
INFO - 2022-06-05 18:19:21 --> Helper loaded: url_helper
INFO - 2022-06-05 18:19:21 --> Database Driver Class Initialized
INFO - 2022-06-05 18:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:19:21 --> Model Class Initialized
DEBUG - 2022-06-05 18:19:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:19:21 --> Model Class Initialized
INFO - 2022-06-05 18:19:21 --> Controller Class Initialized
DEBUG - 2022-06-05 18:19:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:19:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:19:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:19:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:19:21 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:19:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:19:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:19:21 --> Final output sent to browser
DEBUG - 2022-06-05 18:19:21 --> Total execution time: 0.0429
INFO - 2022-06-05 18:19:30 --> Config Class Initialized
INFO - 2022-06-05 18:19:30 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:19:30 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:19:30 --> Utf8 Class Initialized
INFO - 2022-06-05 18:19:30 --> URI Class Initialized
INFO - 2022-06-05 18:19:30 --> Router Class Initialized
INFO - 2022-06-05 18:19:30 --> Output Class Initialized
INFO - 2022-06-05 18:19:30 --> Security Class Initialized
DEBUG - 2022-06-05 18:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:19:30 --> Input Class Initialized
INFO - 2022-06-05 18:19:30 --> Language Class Initialized
INFO - 2022-06-05 18:19:30 --> Language Class Initialized
INFO - 2022-06-05 18:19:30 --> Config Class Initialized
INFO - 2022-06-05 18:19:30 --> Loader Class Initialized
INFO - 2022-06-05 18:19:30 --> Helper loaded: url_helper
INFO - 2022-06-05 18:19:30 --> Database Driver Class Initialized
INFO - 2022-06-05 18:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:19:30 --> Model Class Initialized
DEBUG - 2022-06-05 18:19:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:19:30 --> Model Class Initialized
INFO - 2022-06-05 18:19:30 --> Controller Class Initialized
DEBUG - 2022-06-05 18:19:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:19:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:19:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:19:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:19:30 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:19:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:19:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:19:30 --> Final output sent to browser
DEBUG - 2022-06-05 18:19:30 --> Total execution time: 0.0419
INFO - 2022-06-05 18:19:50 --> Config Class Initialized
INFO - 2022-06-05 18:19:50 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:19:50 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:19:50 --> Utf8 Class Initialized
INFO - 2022-06-05 18:19:50 --> URI Class Initialized
INFO - 2022-06-05 18:19:50 --> Router Class Initialized
INFO - 2022-06-05 18:19:50 --> Output Class Initialized
INFO - 2022-06-05 18:19:50 --> Security Class Initialized
DEBUG - 2022-06-05 18:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:19:50 --> Input Class Initialized
INFO - 2022-06-05 18:19:50 --> Language Class Initialized
INFO - 2022-06-05 18:19:50 --> Language Class Initialized
INFO - 2022-06-05 18:19:50 --> Config Class Initialized
INFO - 2022-06-05 18:19:50 --> Loader Class Initialized
INFO - 2022-06-05 18:19:50 --> Helper loaded: url_helper
INFO - 2022-06-05 18:19:50 --> Database Driver Class Initialized
INFO - 2022-06-05 18:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:19:50 --> Model Class Initialized
DEBUG - 2022-06-05 18:19:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:19:50 --> Model Class Initialized
INFO - 2022-06-05 18:19:50 --> Controller Class Initialized
DEBUG - 2022-06-05 18:19:50 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:19:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:19:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:19:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:19:50 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:19:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:19:50 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:19:50 --> Final output sent to browser
DEBUG - 2022-06-05 18:19:50 --> Total execution time: 0.0392
INFO - 2022-06-05 18:20:10 --> Config Class Initialized
INFO - 2022-06-05 18:20:10 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:20:10 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:20:10 --> Utf8 Class Initialized
INFO - 2022-06-05 18:20:10 --> URI Class Initialized
INFO - 2022-06-05 18:20:10 --> Router Class Initialized
INFO - 2022-06-05 18:20:10 --> Output Class Initialized
INFO - 2022-06-05 18:20:10 --> Security Class Initialized
DEBUG - 2022-06-05 18:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:20:10 --> Input Class Initialized
INFO - 2022-06-05 18:20:10 --> Language Class Initialized
INFO - 2022-06-05 18:20:10 --> Language Class Initialized
INFO - 2022-06-05 18:20:10 --> Config Class Initialized
INFO - 2022-06-05 18:20:10 --> Loader Class Initialized
INFO - 2022-06-05 18:20:10 --> Helper loaded: url_helper
INFO - 2022-06-05 18:20:10 --> Database Driver Class Initialized
INFO - 2022-06-05 18:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:20:10 --> Model Class Initialized
DEBUG - 2022-06-05 18:20:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:20:10 --> Model Class Initialized
INFO - 2022-06-05 18:20:10 --> Controller Class Initialized
DEBUG - 2022-06-05 18:20:10 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:20:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:20:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:20:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:20:10 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:20:10 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:20:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:20:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:20:10 --> Final output sent to browser
DEBUG - 2022-06-05 18:20:10 --> Total execution time: 0.0470
INFO - 2022-06-05 18:20:28 --> Config Class Initialized
INFO - 2022-06-05 18:20:28 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:20:28 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:20:28 --> Utf8 Class Initialized
INFO - 2022-06-05 18:20:28 --> URI Class Initialized
INFO - 2022-06-05 18:20:28 --> Router Class Initialized
INFO - 2022-06-05 18:20:28 --> Output Class Initialized
INFO - 2022-06-05 18:20:28 --> Security Class Initialized
DEBUG - 2022-06-05 18:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:20:28 --> Input Class Initialized
INFO - 2022-06-05 18:20:28 --> Language Class Initialized
INFO - 2022-06-05 18:20:28 --> Language Class Initialized
INFO - 2022-06-05 18:20:28 --> Config Class Initialized
INFO - 2022-06-05 18:20:28 --> Loader Class Initialized
INFO - 2022-06-05 18:20:28 --> Helper loaded: url_helper
INFO - 2022-06-05 18:20:29 --> Database Driver Class Initialized
INFO - 2022-06-05 18:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:20:29 --> Model Class Initialized
DEBUG - 2022-06-05 18:20:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:20:29 --> Model Class Initialized
INFO - 2022-06-05 18:20:29 --> Controller Class Initialized
DEBUG - 2022-06-05 18:20:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:20:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:20:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:20:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:20:29 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:20:29 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:20:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:20:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:20:29 --> Final output sent to browser
DEBUG - 2022-06-05 18:20:29 --> Total execution time: 0.0284
INFO - 2022-06-05 18:20:41 --> Config Class Initialized
INFO - 2022-06-05 18:20:41 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:20:41 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:20:41 --> Utf8 Class Initialized
INFO - 2022-06-05 18:20:41 --> URI Class Initialized
INFO - 2022-06-05 18:20:41 --> Router Class Initialized
INFO - 2022-06-05 18:20:41 --> Output Class Initialized
INFO - 2022-06-05 18:20:41 --> Security Class Initialized
DEBUG - 2022-06-05 18:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:20:41 --> Input Class Initialized
INFO - 2022-06-05 18:20:41 --> Language Class Initialized
INFO - 2022-06-05 18:20:41 --> Language Class Initialized
INFO - 2022-06-05 18:20:41 --> Config Class Initialized
INFO - 2022-06-05 18:20:41 --> Loader Class Initialized
INFO - 2022-06-05 18:20:41 --> Helper loaded: url_helper
INFO - 2022-06-05 18:20:41 --> Database Driver Class Initialized
INFO - 2022-06-05 18:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:20:41 --> Model Class Initialized
DEBUG - 2022-06-05 18:20:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:20:41 --> Model Class Initialized
INFO - 2022-06-05 18:20:41 --> Controller Class Initialized
DEBUG - 2022-06-05 18:20:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:20:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:20:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:20:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:20:41 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
ERROR - 2022-06-05 18:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 74
DEBUG - 2022-06-05 18:20:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:20:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:20:41 --> Final output sent to browser
DEBUG - 2022-06-05 18:20:41 --> Total execution time: 0.0409
INFO - 2022-06-05 18:21:12 --> Config Class Initialized
INFO - 2022-06-05 18:21:12 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:21:12 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:21:12 --> Utf8 Class Initialized
INFO - 2022-06-05 18:21:12 --> URI Class Initialized
INFO - 2022-06-05 18:21:13 --> Router Class Initialized
INFO - 2022-06-05 18:21:13 --> Output Class Initialized
INFO - 2022-06-05 18:21:13 --> Security Class Initialized
DEBUG - 2022-06-05 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:21:13 --> Input Class Initialized
INFO - 2022-06-05 18:21:13 --> Language Class Initialized
INFO - 2022-06-05 18:21:13 --> Language Class Initialized
INFO - 2022-06-05 18:21:13 --> Config Class Initialized
INFO - 2022-06-05 18:21:13 --> Loader Class Initialized
INFO - 2022-06-05 18:21:13 --> Helper loaded: url_helper
INFO - 2022-06-05 18:21:13 --> Database Driver Class Initialized
INFO - 2022-06-05 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:21:13 --> Model Class Initialized
DEBUG - 2022-06-05 18:21:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:21:13 --> Model Class Initialized
INFO - 2022-06-05 18:21:13 --> Controller Class Initialized
DEBUG - 2022-06-05 18:21:13 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:21:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:21:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:21:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:21:13 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:21:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:21:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:21:13 --> Final output sent to browser
DEBUG - 2022-06-05 18:21:13 --> Total execution time: 0.0401
INFO - 2022-06-05 18:21:21 --> Config Class Initialized
INFO - 2022-06-05 18:21:21 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:21:21 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:21:21 --> Utf8 Class Initialized
INFO - 2022-06-05 18:21:21 --> URI Class Initialized
INFO - 2022-06-05 18:21:21 --> Router Class Initialized
INFO - 2022-06-05 18:21:21 --> Output Class Initialized
INFO - 2022-06-05 18:21:21 --> Security Class Initialized
DEBUG - 2022-06-05 18:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:21:21 --> Input Class Initialized
INFO - 2022-06-05 18:21:21 --> Language Class Initialized
INFO - 2022-06-05 18:21:21 --> Language Class Initialized
INFO - 2022-06-05 18:21:21 --> Config Class Initialized
INFO - 2022-06-05 18:21:21 --> Loader Class Initialized
INFO - 2022-06-05 18:21:21 --> Helper loaded: url_helper
INFO - 2022-06-05 18:21:21 --> Database Driver Class Initialized
INFO - 2022-06-05 18:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:21:21 --> Model Class Initialized
DEBUG - 2022-06-05 18:21:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:21:21 --> Model Class Initialized
INFO - 2022-06-05 18:21:21 --> Controller Class Initialized
DEBUG - 2022-06-05 18:21:21 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:21:21 --> Final output sent to browser
DEBUG - 2022-06-05 18:21:21 --> Total execution time: 0.0367
INFO - 2022-06-05 18:21:24 --> Config Class Initialized
INFO - 2022-06-05 18:21:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:21:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:21:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:21:24 --> URI Class Initialized
INFO - 2022-06-05 18:21:24 --> Router Class Initialized
INFO - 2022-06-05 18:21:24 --> Output Class Initialized
INFO - 2022-06-05 18:21:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:21:24 --> Input Class Initialized
INFO - 2022-06-05 18:21:24 --> Language Class Initialized
INFO - 2022-06-05 18:21:24 --> Language Class Initialized
INFO - 2022-06-05 18:21:24 --> Config Class Initialized
INFO - 2022-06-05 18:21:24 --> Loader Class Initialized
INFO - 2022-06-05 18:21:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:21:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:21:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:21:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:21:24 --> Model Class Initialized
INFO - 2022-06-05 18:21:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:21:24 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:21:24 --> Final output sent to browser
DEBUG - 2022-06-05 18:21:24 --> Total execution time: 0.0366
INFO - 2022-06-05 18:22:23 --> Config Class Initialized
INFO - 2022-06-05 18:22:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:22:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:22:23 --> Utf8 Class Initialized
INFO - 2022-06-05 18:22:23 --> URI Class Initialized
INFO - 2022-06-05 18:22:23 --> Router Class Initialized
INFO - 2022-06-05 18:22:23 --> Output Class Initialized
INFO - 2022-06-05 18:22:23 --> Security Class Initialized
DEBUG - 2022-06-05 18:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:22:23 --> Input Class Initialized
INFO - 2022-06-05 18:22:23 --> Language Class Initialized
INFO - 2022-06-05 18:22:23 --> Language Class Initialized
INFO - 2022-06-05 18:22:23 --> Config Class Initialized
INFO - 2022-06-05 18:22:23 --> Loader Class Initialized
INFO - 2022-06-05 18:22:23 --> Helper loaded: url_helper
INFO - 2022-06-05 18:22:23 --> Database Driver Class Initialized
INFO - 2022-06-05 18:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:22:23 --> Model Class Initialized
DEBUG - 2022-06-05 18:22:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:22:23 --> Model Class Initialized
INFO - 2022-06-05 18:22:23 --> Controller Class Initialized
DEBUG - 2022-06-05 18:22:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:22:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:22:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:22:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:22:23 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:22:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:22:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:22:23 --> Final output sent to browser
DEBUG - 2022-06-05 18:22:23 --> Total execution time: 0.0398
INFO - 2022-06-05 18:22:31 --> Config Class Initialized
INFO - 2022-06-05 18:22:31 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:22:31 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:22:31 --> Utf8 Class Initialized
INFO - 2022-06-05 18:22:31 --> URI Class Initialized
INFO - 2022-06-05 18:22:31 --> Router Class Initialized
INFO - 2022-06-05 18:22:31 --> Output Class Initialized
INFO - 2022-06-05 18:22:31 --> Security Class Initialized
DEBUG - 2022-06-05 18:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:22:31 --> Input Class Initialized
INFO - 2022-06-05 18:22:31 --> Language Class Initialized
INFO - 2022-06-05 18:22:31 --> Language Class Initialized
INFO - 2022-06-05 18:22:31 --> Config Class Initialized
INFO - 2022-06-05 18:22:31 --> Loader Class Initialized
INFO - 2022-06-05 18:22:31 --> Helper loaded: url_helper
INFO - 2022-06-05 18:22:31 --> Database Driver Class Initialized
INFO - 2022-06-05 18:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:22:31 --> Model Class Initialized
DEBUG - 2022-06-05 18:22:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:22:31 --> Model Class Initialized
INFO - 2022-06-05 18:22:31 --> Controller Class Initialized
DEBUG - 2022-06-05 18:22:31 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:22:31 --> Final output sent to browser
DEBUG - 2022-06-05 18:22:31 --> Total execution time: 0.0353
INFO - 2022-06-05 18:22:37 --> Config Class Initialized
INFO - 2022-06-05 18:22:37 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:22:37 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:22:37 --> Utf8 Class Initialized
INFO - 2022-06-05 18:22:37 --> URI Class Initialized
INFO - 2022-06-05 18:22:37 --> Router Class Initialized
INFO - 2022-06-05 18:22:37 --> Output Class Initialized
INFO - 2022-06-05 18:22:37 --> Security Class Initialized
DEBUG - 2022-06-05 18:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:22:37 --> Input Class Initialized
INFO - 2022-06-05 18:22:37 --> Language Class Initialized
INFO - 2022-06-05 18:22:37 --> Language Class Initialized
INFO - 2022-06-05 18:22:37 --> Config Class Initialized
INFO - 2022-06-05 18:22:37 --> Loader Class Initialized
INFO - 2022-06-05 18:22:37 --> Helper loaded: url_helper
INFO - 2022-06-05 18:22:37 --> Database Driver Class Initialized
INFO - 2022-06-05 18:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:22:37 --> Model Class Initialized
DEBUG - 2022-06-05 18:22:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:22:37 --> Model Class Initialized
INFO - 2022-06-05 18:22:37 --> Controller Class Initialized
DEBUG - 2022-06-05 18:22:37 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:22:38 --> Config Class Initialized
INFO - 2022-06-05 18:22:38 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:22:38 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:22:38 --> Utf8 Class Initialized
INFO - 2022-06-05 18:22:38 --> URI Class Initialized
INFO - 2022-06-05 18:22:38 --> Router Class Initialized
INFO - 2022-06-05 18:22:38 --> Output Class Initialized
INFO - 2022-06-05 18:22:38 --> Security Class Initialized
DEBUG - 2022-06-05 18:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:22:38 --> Input Class Initialized
INFO - 2022-06-05 18:22:38 --> Language Class Initialized
INFO - 2022-06-05 18:22:38 --> Language Class Initialized
INFO - 2022-06-05 18:22:38 --> Config Class Initialized
INFO - 2022-06-05 18:22:38 --> Loader Class Initialized
INFO - 2022-06-05 18:22:38 --> Helper loaded: url_helper
INFO - 2022-06-05 18:22:38 --> Database Driver Class Initialized
INFO - 2022-06-05 18:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:22:38 --> Model Class Initialized
DEBUG - 2022-06-05 18:22:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:22:38 --> Model Class Initialized
INFO - 2022-06-05 18:22:38 --> Controller Class Initialized
DEBUG - 2022-06-05 18:22:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:22:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:22:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:22:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:22:38 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:22:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:22:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:22:38 --> Final output sent to browser
DEBUG - 2022-06-05 18:22:38 --> Total execution time: 0.0375
INFO - 2022-06-05 18:24:14 --> Config Class Initialized
INFO - 2022-06-05 18:24:14 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:24:14 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:24:14 --> Utf8 Class Initialized
INFO - 2022-06-05 18:24:14 --> URI Class Initialized
INFO - 2022-06-05 18:24:14 --> Router Class Initialized
INFO - 2022-06-05 18:24:14 --> Output Class Initialized
INFO - 2022-06-05 18:24:14 --> Security Class Initialized
DEBUG - 2022-06-05 18:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:24:14 --> Input Class Initialized
INFO - 2022-06-05 18:24:14 --> Language Class Initialized
INFO - 2022-06-05 18:24:14 --> Language Class Initialized
INFO - 2022-06-05 18:24:14 --> Config Class Initialized
INFO - 2022-06-05 18:24:14 --> Loader Class Initialized
INFO - 2022-06-05 18:24:14 --> Helper loaded: url_helper
INFO - 2022-06-05 18:24:14 --> Database Driver Class Initialized
INFO - 2022-06-05 18:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:24:14 --> Model Class Initialized
DEBUG - 2022-06-05 18:24:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:24:14 --> Model Class Initialized
INFO - 2022-06-05 18:24:14 --> Controller Class Initialized
DEBUG - 2022-06-05 18:24:14 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:24:14 --> Final output sent to browser
DEBUG - 2022-06-05 18:24:14 --> Total execution time: 0.0411
INFO - 2022-06-05 18:24:24 --> Config Class Initialized
INFO - 2022-06-05 18:24:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:24:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:24:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:24:24 --> URI Class Initialized
INFO - 2022-06-05 18:24:24 --> Router Class Initialized
INFO - 2022-06-05 18:24:24 --> Output Class Initialized
INFO - 2022-06-05 18:24:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:24:24 --> Input Class Initialized
INFO - 2022-06-05 18:24:24 --> Language Class Initialized
INFO - 2022-06-05 18:24:24 --> Language Class Initialized
INFO - 2022-06-05 18:24:24 --> Config Class Initialized
INFO - 2022-06-05 18:24:24 --> Loader Class Initialized
INFO - 2022-06-05 18:24:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:24:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:24:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:24:24 --> Model Class Initialized
INFO - 2022-06-05 18:24:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:24:24 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:24:24 --> Config Class Initialized
INFO - 2022-06-05 18:24:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:24:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:24:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:24:24 --> URI Class Initialized
INFO - 2022-06-05 18:24:24 --> Router Class Initialized
INFO - 2022-06-05 18:24:24 --> Output Class Initialized
INFO - 2022-06-05 18:24:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:24:24 --> Input Class Initialized
INFO - 2022-06-05 18:24:24 --> Language Class Initialized
INFO - 2022-06-05 18:24:24 --> Language Class Initialized
INFO - 2022-06-05 18:24:24 --> Config Class Initialized
INFO - 2022-06-05 18:24:24 --> Loader Class Initialized
INFO - 2022-06-05 18:24:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:24:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:24:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:24:24 --> Model Class Initialized
INFO - 2022-06-05 18:24:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:24:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:24:24 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
ERROR - 2022-06-05 18:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 75
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:24:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:24:24 --> Final output sent to browser
DEBUG - 2022-06-05 18:24:24 --> Total execution time: 0.0407
INFO - 2022-06-05 18:28:20 --> Config Class Initialized
INFO - 2022-06-05 18:28:20 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:28:20 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:28:20 --> Utf8 Class Initialized
INFO - 2022-06-05 18:28:20 --> URI Class Initialized
INFO - 2022-06-05 18:28:20 --> Router Class Initialized
INFO - 2022-06-05 18:28:20 --> Output Class Initialized
INFO - 2022-06-05 18:28:20 --> Security Class Initialized
DEBUG - 2022-06-05 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:28:20 --> Input Class Initialized
INFO - 2022-06-05 18:28:20 --> Language Class Initialized
INFO - 2022-06-05 18:28:20 --> Language Class Initialized
INFO - 2022-06-05 18:28:20 --> Config Class Initialized
INFO - 2022-06-05 18:28:20 --> Loader Class Initialized
INFO - 2022-06-05 18:28:20 --> Helper loaded: url_helper
INFO - 2022-06-05 18:28:20 --> Database Driver Class Initialized
INFO - 2022-06-05 18:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:28:20 --> Model Class Initialized
DEBUG - 2022-06-05 18:28:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:28:20 --> Model Class Initialized
INFO - 2022-06-05 18:28:20 --> Controller Class Initialized
DEBUG - 2022-06-05 18:28:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:28:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:28:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:28:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-05 18:28:20 --> Severity: Notice --> Undefined variable: s N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 76
ERROR - 2022-06-05 18:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_city.php 76
DEBUG - 2022-06-05 18:28:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:28:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:28:20 --> Final output sent to browser
DEBUG - 2022-06-05 18:28:20 --> Total execution time: 0.0439
INFO - 2022-06-05 18:28:44 --> Config Class Initialized
INFO - 2022-06-05 18:28:44 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:28:44 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:28:44 --> Utf8 Class Initialized
INFO - 2022-06-05 18:28:44 --> URI Class Initialized
INFO - 2022-06-05 18:28:44 --> Router Class Initialized
INFO - 2022-06-05 18:28:44 --> Output Class Initialized
INFO - 2022-06-05 18:28:44 --> Security Class Initialized
DEBUG - 2022-06-05 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:28:44 --> Input Class Initialized
INFO - 2022-06-05 18:28:44 --> Language Class Initialized
INFO - 2022-06-05 18:28:44 --> Language Class Initialized
INFO - 2022-06-05 18:28:44 --> Config Class Initialized
INFO - 2022-06-05 18:28:44 --> Loader Class Initialized
INFO - 2022-06-05 18:28:44 --> Helper loaded: url_helper
INFO - 2022-06-05 18:28:44 --> Database Driver Class Initialized
INFO - 2022-06-05 18:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:28:44 --> Model Class Initialized
DEBUG - 2022-06-05 18:28:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:28:44 --> Model Class Initialized
INFO - 2022-06-05 18:28:44 --> Controller Class Initialized
DEBUG - 2022-06-05 18:28:44 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:28:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:28:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:28:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:28:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:28:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:28:44 --> Final output sent to browser
DEBUG - 2022-06-05 18:28:44 --> Total execution time: 0.0390
INFO - 2022-06-05 18:29:09 --> Config Class Initialized
INFO - 2022-06-05 18:29:09 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:29:09 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:29:09 --> Utf8 Class Initialized
INFO - 2022-06-05 18:29:09 --> URI Class Initialized
INFO - 2022-06-05 18:29:09 --> Router Class Initialized
INFO - 2022-06-05 18:29:09 --> Output Class Initialized
INFO - 2022-06-05 18:29:09 --> Security Class Initialized
DEBUG - 2022-06-05 18:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:29:09 --> Input Class Initialized
INFO - 2022-06-05 18:29:09 --> Language Class Initialized
INFO - 2022-06-05 18:29:09 --> Language Class Initialized
INFO - 2022-06-05 18:29:09 --> Config Class Initialized
INFO - 2022-06-05 18:29:09 --> Loader Class Initialized
INFO - 2022-06-05 18:29:09 --> Helper loaded: url_helper
INFO - 2022-06-05 18:29:09 --> Database Driver Class Initialized
INFO - 2022-06-05 18:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:29:09 --> Model Class Initialized
DEBUG - 2022-06-05 18:29:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:29:09 --> Model Class Initialized
INFO - 2022-06-05 18:29:09 --> Controller Class Initialized
DEBUG - 2022-06-05 18:29:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:29:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:29:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:29:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:29:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:29:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:29:09 --> Final output sent to browser
DEBUG - 2022-06-05 18:29:09 --> Total execution time: 0.0405
INFO - 2022-06-05 18:29:16 --> Config Class Initialized
INFO - 2022-06-05 18:29:16 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:29:16 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:29:16 --> Utf8 Class Initialized
INFO - 2022-06-05 18:29:16 --> URI Class Initialized
INFO - 2022-06-05 18:29:16 --> Router Class Initialized
INFO - 2022-06-05 18:29:16 --> Output Class Initialized
INFO - 2022-06-05 18:29:16 --> Security Class Initialized
DEBUG - 2022-06-05 18:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:29:16 --> Input Class Initialized
INFO - 2022-06-05 18:29:16 --> Language Class Initialized
INFO - 2022-06-05 18:29:16 --> Language Class Initialized
INFO - 2022-06-05 18:29:16 --> Config Class Initialized
INFO - 2022-06-05 18:29:16 --> Loader Class Initialized
INFO - 2022-06-05 18:29:16 --> Helper loaded: url_helper
INFO - 2022-06-05 18:29:16 --> Database Driver Class Initialized
INFO - 2022-06-05 18:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:29:16 --> Model Class Initialized
DEBUG - 2022-06-05 18:29:16 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:29:16 --> Model Class Initialized
INFO - 2022-06-05 18:29:16 --> Controller Class Initialized
DEBUG - 2022-06-05 18:29:16 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:29:16 --> Final output sent to browser
DEBUG - 2022-06-05 18:29:16 --> Total execution time: 0.0363
INFO - 2022-06-05 18:29:23 --> Config Class Initialized
INFO - 2022-06-05 18:29:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:29:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:29:23 --> Utf8 Class Initialized
INFO - 2022-06-05 18:29:23 --> URI Class Initialized
INFO - 2022-06-05 18:29:23 --> Router Class Initialized
INFO - 2022-06-05 18:29:23 --> Output Class Initialized
INFO - 2022-06-05 18:29:23 --> Security Class Initialized
DEBUG - 2022-06-05 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:29:23 --> Input Class Initialized
INFO - 2022-06-05 18:29:23 --> Language Class Initialized
INFO - 2022-06-05 18:29:23 --> Language Class Initialized
INFO - 2022-06-05 18:29:23 --> Config Class Initialized
INFO - 2022-06-05 18:29:23 --> Loader Class Initialized
INFO - 2022-06-05 18:29:23 --> Helper loaded: url_helper
INFO - 2022-06-05 18:29:23 --> Database Driver Class Initialized
INFO - 2022-06-05 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:29:23 --> Model Class Initialized
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:29:23 --> Model Class Initialized
INFO - 2022-06-05 18:29:23 --> Controller Class Initialized
DEBUG - 2022-06-05 18:29:23 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:29:23 --> Config Class Initialized
INFO - 2022-06-05 18:29:23 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:29:23 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:29:23 --> Utf8 Class Initialized
INFO - 2022-06-05 18:29:23 --> URI Class Initialized
INFO - 2022-06-05 18:29:23 --> Router Class Initialized
INFO - 2022-06-05 18:29:23 --> Output Class Initialized
INFO - 2022-06-05 18:29:23 --> Security Class Initialized
DEBUG - 2022-06-05 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:29:23 --> Input Class Initialized
INFO - 2022-06-05 18:29:23 --> Language Class Initialized
INFO - 2022-06-05 18:29:23 --> Language Class Initialized
INFO - 2022-06-05 18:29:23 --> Config Class Initialized
INFO - 2022-06-05 18:29:23 --> Loader Class Initialized
INFO - 2022-06-05 18:29:23 --> Helper loaded: url_helper
INFO - 2022-06-05 18:29:23 --> Database Driver Class Initialized
INFO - 2022-06-05 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:29:23 --> Model Class Initialized
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:29:23 --> Model Class Initialized
INFO - 2022-06-05 18:29:23 --> Controller Class Initialized
DEBUG - 2022-06-05 18:29:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:29:23 --> Final output sent to browser
DEBUG - 2022-06-05 18:29:23 --> Total execution time: 0.0432
INFO - 2022-06-05 18:29:57 --> Config Class Initialized
INFO - 2022-06-05 18:29:57 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:29:57 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:29:57 --> Utf8 Class Initialized
INFO - 2022-06-05 18:29:57 --> URI Class Initialized
INFO - 2022-06-05 18:29:57 --> Router Class Initialized
INFO - 2022-06-05 18:29:57 --> Output Class Initialized
INFO - 2022-06-05 18:29:57 --> Security Class Initialized
DEBUG - 2022-06-05 18:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:29:57 --> Input Class Initialized
INFO - 2022-06-05 18:29:57 --> Language Class Initialized
INFO - 2022-06-05 18:29:57 --> Language Class Initialized
INFO - 2022-06-05 18:29:57 --> Config Class Initialized
INFO - 2022-06-05 18:29:57 --> Loader Class Initialized
INFO - 2022-06-05 18:29:57 --> Helper loaded: url_helper
INFO - 2022-06-05 18:29:57 --> Database Driver Class Initialized
INFO - 2022-06-05 18:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:29:57 --> Model Class Initialized
DEBUG - 2022-06-05 18:29:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:29:57 --> Model Class Initialized
INFO - 2022-06-05 18:29:57 --> Controller Class Initialized
DEBUG - 2022-06-05 18:29:57 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:29:57 --> Final output sent to browser
DEBUG - 2022-06-05 18:29:57 --> Total execution time: 0.0358
INFO - 2022-06-05 18:30:08 --> Config Class Initialized
INFO - 2022-06-05 18:30:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:30:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:30:08 --> Utf8 Class Initialized
INFO - 2022-06-05 18:30:08 --> URI Class Initialized
INFO - 2022-06-05 18:30:08 --> Router Class Initialized
INFO - 2022-06-05 18:30:08 --> Output Class Initialized
INFO - 2022-06-05 18:30:08 --> Security Class Initialized
DEBUG - 2022-06-05 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:30:08 --> Input Class Initialized
INFO - 2022-06-05 18:30:08 --> Language Class Initialized
INFO - 2022-06-05 18:30:08 --> Language Class Initialized
INFO - 2022-06-05 18:30:08 --> Config Class Initialized
INFO - 2022-06-05 18:30:08 --> Loader Class Initialized
INFO - 2022-06-05 18:30:08 --> Helper loaded: url_helper
INFO - 2022-06-05 18:30:08 --> Database Driver Class Initialized
INFO - 2022-06-05 18:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:30:08 --> Model Class Initialized
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:30:08 --> Model Class Initialized
INFO - 2022-06-05 18:30:08 --> Controller Class Initialized
DEBUG - 2022-06-05 18:30:08 --> Admin MX_Controller Initialized
INFO - 2022-06-05 18:30:08 --> Config Class Initialized
INFO - 2022-06-05 18:30:08 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:30:08 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:30:08 --> Utf8 Class Initialized
INFO - 2022-06-05 18:30:08 --> URI Class Initialized
INFO - 2022-06-05 18:30:08 --> Router Class Initialized
INFO - 2022-06-05 18:30:08 --> Output Class Initialized
INFO - 2022-06-05 18:30:08 --> Security Class Initialized
DEBUG - 2022-06-05 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:30:08 --> Input Class Initialized
INFO - 2022-06-05 18:30:08 --> Language Class Initialized
INFO - 2022-06-05 18:30:08 --> Language Class Initialized
INFO - 2022-06-05 18:30:08 --> Config Class Initialized
INFO - 2022-06-05 18:30:08 --> Loader Class Initialized
INFO - 2022-06-05 18:30:08 --> Helper loaded: url_helper
INFO - 2022-06-05 18:30:08 --> Database Driver Class Initialized
INFO - 2022-06-05 18:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:30:08 --> Model Class Initialized
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:30:08 --> Model Class Initialized
INFO - 2022-06-05 18:30:08 --> Controller Class Initialized
DEBUG - 2022-06-05 18:30:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:30:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:30:08 --> Final output sent to browser
DEBUG - 2022-06-05 18:30:08 --> Total execution time: 0.0482
INFO - 2022-06-05 18:30:24 --> Config Class Initialized
INFO - 2022-06-05 18:30:24 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:30:24 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:30:24 --> Utf8 Class Initialized
INFO - 2022-06-05 18:30:24 --> URI Class Initialized
INFO - 2022-06-05 18:30:24 --> Router Class Initialized
INFO - 2022-06-05 18:30:24 --> Output Class Initialized
INFO - 2022-06-05 18:30:24 --> Security Class Initialized
DEBUG - 2022-06-05 18:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:30:24 --> Input Class Initialized
INFO - 2022-06-05 18:30:24 --> Language Class Initialized
INFO - 2022-06-05 18:30:24 --> Language Class Initialized
INFO - 2022-06-05 18:30:24 --> Config Class Initialized
INFO - 2022-06-05 18:30:24 --> Loader Class Initialized
INFO - 2022-06-05 18:30:24 --> Helper loaded: url_helper
INFO - 2022-06-05 18:30:24 --> Database Driver Class Initialized
INFO - 2022-06-05 18:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:30:24 --> Model Class Initialized
DEBUG - 2022-06-05 18:30:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:30:24 --> Model Class Initialized
INFO - 2022-06-05 18:30:24 --> Controller Class Initialized
DEBUG - 2022-06-05 18:30:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:30:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:30:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:30:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:30:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:30:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:30:24 --> Final output sent to browser
DEBUG - 2022-06-05 18:30:24 --> Total execution time: 0.0338
INFO - 2022-06-05 18:30:43 --> Config Class Initialized
INFO - 2022-06-05 18:30:43 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:30:43 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:30:43 --> Utf8 Class Initialized
INFO - 2022-06-05 18:30:43 --> URI Class Initialized
INFO - 2022-06-05 18:30:43 --> Router Class Initialized
INFO - 2022-06-05 18:30:43 --> Output Class Initialized
INFO - 2022-06-05 18:30:43 --> Security Class Initialized
DEBUG - 2022-06-05 18:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:30:43 --> Input Class Initialized
INFO - 2022-06-05 18:30:43 --> Language Class Initialized
INFO - 2022-06-05 18:30:43 --> Language Class Initialized
INFO - 2022-06-05 18:30:43 --> Config Class Initialized
INFO - 2022-06-05 18:30:43 --> Loader Class Initialized
INFO - 2022-06-05 18:30:43 --> Helper loaded: url_helper
INFO - 2022-06-05 18:30:43 --> Database Driver Class Initialized
INFO - 2022-06-05 18:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:30:43 --> Model Class Initialized
DEBUG - 2022-06-05 18:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:30:43 --> Model Class Initialized
INFO - 2022-06-05 18:30:43 --> Controller Class Initialized
DEBUG - 2022-06-05 18:30:43 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:30:43 --> Final output sent to browser
DEBUG - 2022-06-05 18:30:43 --> Total execution time: 0.0433
INFO - 2022-06-05 18:30:56 --> Config Class Initialized
INFO - 2022-06-05 18:30:56 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:30:56 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:30:56 --> Utf8 Class Initialized
INFO - 2022-06-05 18:30:56 --> URI Class Initialized
INFO - 2022-06-05 18:30:56 --> Router Class Initialized
INFO - 2022-06-05 18:30:56 --> Output Class Initialized
INFO - 2022-06-05 18:30:56 --> Security Class Initialized
DEBUG - 2022-06-05 18:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:30:56 --> Input Class Initialized
INFO - 2022-06-05 18:30:56 --> Language Class Initialized
INFO - 2022-06-05 18:30:56 --> Language Class Initialized
INFO - 2022-06-05 18:30:56 --> Config Class Initialized
INFO - 2022-06-05 18:30:56 --> Loader Class Initialized
INFO - 2022-06-05 18:30:56 --> Helper loaded: url_helper
INFO - 2022-06-05 18:30:56 --> Database Driver Class Initialized
INFO - 2022-06-05 18:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:30:56 --> Model Class Initialized
DEBUG - 2022-06-05 18:30:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:30:56 --> Model Class Initialized
INFO - 2022-06-05 18:30:56 --> Controller Class Initialized
DEBUG - 2022-06-05 18:30:56 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:30:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:30:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:30:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:30:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:30:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:30:56 --> Final output sent to browser
DEBUG - 2022-06-05 18:30:56 --> Total execution time: 0.0389
INFO - 2022-06-05 18:31:07 --> Config Class Initialized
INFO - 2022-06-05 18:31:07 --> Hooks Class Initialized
DEBUG - 2022-06-05 18:31:07 --> UTF-8 Support Enabled
INFO - 2022-06-05 18:31:07 --> Utf8 Class Initialized
INFO - 2022-06-05 18:31:07 --> URI Class Initialized
INFO - 2022-06-05 18:31:07 --> Router Class Initialized
INFO - 2022-06-05 18:31:07 --> Output Class Initialized
INFO - 2022-06-05 18:31:07 --> Security Class Initialized
DEBUG - 2022-06-05 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-05 18:31:07 --> Input Class Initialized
INFO - 2022-06-05 18:31:07 --> Language Class Initialized
INFO - 2022-06-05 18:31:07 --> Language Class Initialized
INFO - 2022-06-05 18:31:07 --> Config Class Initialized
INFO - 2022-06-05 18:31:07 --> Loader Class Initialized
INFO - 2022-06-05 18:31:07 --> Helper loaded: url_helper
INFO - 2022-06-05 18:31:07 --> Database Driver Class Initialized
INFO - 2022-06-05 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-05 18:31:07 --> Model Class Initialized
DEBUG - 2022-06-05 18:31:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-05 18:31:07 --> Model Class Initialized
INFO - 2022-06-05 18:31:07 --> Controller Class Initialized
DEBUG - 2022-06-05 18:31:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-05 18:31:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-05 18:31:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-05 18:31:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-05 18:31:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-05 18:31:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-05 18:31:07 --> Final output sent to browser
DEBUG - 2022-06-05 18:31:07 --> Total execution time: 0.0371
