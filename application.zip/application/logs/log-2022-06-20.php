<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-20 07:18:47 --> Config Class Initialized
INFO - 2022-06-20 07:18:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:18:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:18:47 --> Utf8 Class Initialized
INFO - 2022-06-20 07:18:47 --> URI Class Initialized
INFO - 2022-06-20 07:18:47 --> Router Class Initialized
INFO - 2022-06-20 07:18:47 --> Output Class Initialized
INFO - 2022-06-20 07:18:47 --> Security Class Initialized
DEBUG - 2022-06-20 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:18:47 --> Input Class Initialized
INFO - 2022-06-20 07:18:47 --> Language Class Initialized
INFO - 2022-06-20 07:18:48 --> Language Class Initialized
INFO - 2022-06-20 07:18:48 --> Config Class Initialized
INFO - 2022-06-20 07:18:48 --> Loader Class Initialized
INFO - 2022-06-20 07:18:48 --> Helper loaded: url_helper
INFO - 2022-06-20 07:18:49 --> Database Driver Class Initialized
INFO - 2022-06-20 07:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:18:49 --> Model Class Initialized
DEBUG - 2022-06-20 07:18:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:18:49 --> Model Class Initialized
INFO - 2022-06-20 07:18:49 --> Controller Class Initialized
DEBUG - 2022-06-20 07:18:49 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:18:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:18:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:18:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:18:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 07:18:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:18:53 --> Final output sent to browser
DEBUG - 2022-06-20 07:18:53 --> Total execution time: 6.1585
INFO - 2022-06-20 07:18:57 --> Config Class Initialized
INFO - 2022-06-20 07:18:57 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:18:57 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:18:57 --> Utf8 Class Initialized
INFO - 2022-06-20 07:18:57 --> URI Class Initialized
INFO - 2022-06-20 07:18:57 --> Router Class Initialized
INFO - 2022-06-20 07:18:57 --> Output Class Initialized
INFO - 2022-06-20 07:18:57 --> Security Class Initialized
DEBUG - 2022-06-20 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:18:57 --> Input Class Initialized
INFO - 2022-06-20 07:18:57 --> Language Class Initialized
INFO - 2022-06-20 07:18:57 --> Language Class Initialized
INFO - 2022-06-20 07:18:57 --> Config Class Initialized
INFO - 2022-06-20 07:18:57 --> Loader Class Initialized
INFO - 2022-06-20 07:18:57 --> Helper loaded: url_helper
INFO - 2022-06-20 07:18:57 --> Database Driver Class Initialized
INFO - 2022-06-20 07:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:18:57 --> Model Class Initialized
DEBUG - 2022-06-20 07:18:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:18:57 --> Model Class Initialized
INFO - 2022-06-20 07:18:57 --> Controller Class Initialized
DEBUG - 2022-06-20 07:18:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:18:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:18:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:18:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:18:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:18:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:18:57 --> Final output sent to browser
DEBUG - 2022-06-20 07:18:57 --> Total execution time: 0.0378
INFO - 2022-06-20 07:19:04 --> Config Class Initialized
INFO - 2022-06-20 07:19:04 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:19:04 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:19:04 --> Utf8 Class Initialized
INFO - 2022-06-20 07:19:04 --> URI Class Initialized
INFO - 2022-06-20 07:19:04 --> Router Class Initialized
INFO - 2022-06-20 07:19:04 --> Output Class Initialized
INFO - 2022-06-20 07:19:04 --> Security Class Initialized
DEBUG - 2022-06-20 07:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:19:04 --> Input Class Initialized
INFO - 2022-06-20 07:19:04 --> Language Class Initialized
INFO - 2022-06-20 07:19:04 --> Language Class Initialized
INFO - 2022-06-20 07:19:04 --> Config Class Initialized
INFO - 2022-06-20 07:19:04 --> Loader Class Initialized
INFO - 2022-06-20 07:19:04 --> Helper loaded: url_helper
INFO - 2022-06-20 07:19:04 --> Database Driver Class Initialized
INFO - 2022-06-20 07:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:19:04 --> Model Class Initialized
DEBUG - 2022-06-20 07:19:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:19:04 --> Model Class Initialized
INFO - 2022-06-20 07:19:04 --> Controller Class Initialized
DEBUG - 2022-06-20 07:19:04 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:19:07 --> Config Class Initialized
INFO - 2022-06-20 07:19:07 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:19:07 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:19:07 --> Utf8 Class Initialized
INFO - 2022-06-20 07:19:07 --> URI Class Initialized
INFO - 2022-06-20 07:19:07 --> Router Class Initialized
INFO - 2022-06-20 07:19:07 --> Output Class Initialized
INFO - 2022-06-20 07:19:07 --> Security Class Initialized
DEBUG - 2022-06-20 07:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:19:07 --> Input Class Initialized
INFO - 2022-06-20 07:19:07 --> Language Class Initialized
INFO - 2022-06-20 07:19:07 --> Language Class Initialized
INFO - 2022-06-20 07:19:07 --> Config Class Initialized
INFO - 2022-06-20 07:19:07 --> Loader Class Initialized
INFO - 2022-06-20 07:19:07 --> Helper loaded: url_helper
INFO - 2022-06-20 07:19:07 --> Database Driver Class Initialized
INFO - 2022-06-20 07:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:19:07 --> Model Class Initialized
DEBUG - 2022-06-20 07:19:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:19:07 --> Model Class Initialized
INFO - 2022-06-20 07:19:07 --> Controller Class Initialized
DEBUG - 2022-06-20 07:19:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:19:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:19:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:19:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:19:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:19:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:19:07 --> Final output sent to browser
DEBUG - 2022-06-20 07:19:07 --> Total execution time: 0.0370
INFO - 2022-06-20 07:19:10 --> Config Class Initialized
INFO - 2022-06-20 07:19:10 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:19:10 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:19:10 --> Utf8 Class Initialized
INFO - 2022-06-20 07:19:10 --> URI Class Initialized
INFO - 2022-06-20 07:19:10 --> Router Class Initialized
INFO - 2022-06-20 07:19:10 --> Output Class Initialized
INFO - 2022-06-20 07:19:10 --> Security Class Initialized
DEBUG - 2022-06-20 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:19:10 --> Input Class Initialized
INFO - 2022-06-20 07:19:10 --> Language Class Initialized
INFO - 2022-06-20 07:19:10 --> Language Class Initialized
INFO - 2022-06-20 07:19:10 --> Config Class Initialized
INFO - 2022-06-20 07:19:10 --> Loader Class Initialized
INFO - 2022-06-20 07:19:10 --> Helper loaded: url_helper
INFO - 2022-06-20 07:19:10 --> Database Driver Class Initialized
INFO - 2022-06-20 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:19:10 --> Model Class Initialized
DEBUG - 2022-06-20 07:19:10 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:19:10 --> Model Class Initialized
INFO - 2022-06-20 07:19:10 --> Controller Class Initialized
DEBUG - 2022-06-20 07:19:10 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:19:12 --> Config Class Initialized
INFO - 2022-06-20 07:19:12 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:19:12 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:19:12 --> Utf8 Class Initialized
INFO - 2022-06-20 07:19:12 --> URI Class Initialized
INFO - 2022-06-20 07:19:12 --> Router Class Initialized
INFO - 2022-06-20 07:19:12 --> Output Class Initialized
INFO - 2022-06-20 07:19:12 --> Security Class Initialized
DEBUG - 2022-06-20 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:19:12 --> Input Class Initialized
INFO - 2022-06-20 07:19:12 --> Language Class Initialized
INFO - 2022-06-20 07:19:12 --> Language Class Initialized
INFO - 2022-06-20 07:19:12 --> Config Class Initialized
INFO - 2022-06-20 07:19:12 --> Loader Class Initialized
INFO - 2022-06-20 07:19:12 --> Helper loaded: url_helper
INFO - 2022-06-20 07:19:12 --> Database Driver Class Initialized
INFO - 2022-06-20 07:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:19:12 --> Model Class Initialized
DEBUG - 2022-06-20 07:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:19:12 --> Model Class Initialized
INFO - 2022-06-20 07:19:12 --> Controller Class Initialized
DEBUG - 2022-06-20 07:19:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:19:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:19:12 --> Final output sent to browser
DEBUG - 2022-06-20 07:19:12 --> Total execution time: 0.0757
INFO - 2022-06-20 07:24:59 --> Config Class Initialized
INFO - 2022-06-20 07:24:59 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:24:59 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:24:59 --> Utf8 Class Initialized
INFO - 2022-06-20 07:24:59 --> URI Class Initialized
INFO - 2022-06-20 07:24:59 --> Router Class Initialized
INFO - 2022-06-20 07:24:59 --> Output Class Initialized
INFO - 2022-06-20 07:24:59 --> Security Class Initialized
DEBUG - 2022-06-20 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:24:59 --> Input Class Initialized
INFO - 2022-06-20 07:24:59 --> Language Class Initialized
INFO - 2022-06-20 07:24:59 --> Language Class Initialized
INFO - 2022-06-20 07:24:59 --> Config Class Initialized
INFO - 2022-06-20 07:24:59 --> Loader Class Initialized
INFO - 2022-06-20 07:24:59 --> Helper loaded: url_helper
INFO - 2022-06-20 07:24:59 --> Database Driver Class Initialized
INFO - 2022-06-20 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:24:59 --> Model Class Initialized
DEBUG - 2022-06-20 07:24:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:24:59 --> Model Class Initialized
INFO - 2022-06-20 07:24:59 --> Controller Class Initialized
DEBUG - 2022-06-20 07:24:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:24:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:24:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:24:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:24:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:24:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:24:59 --> Final output sent to browser
DEBUG - 2022-06-20 07:24:59 --> Total execution time: 0.0355
INFO - 2022-06-20 07:25:03 --> Config Class Initialized
INFO - 2022-06-20 07:25:03 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:25:03 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:25:03 --> Utf8 Class Initialized
INFO - 2022-06-20 07:25:03 --> URI Class Initialized
INFO - 2022-06-20 07:25:03 --> Router Class Initialized
INFO - 2022-06-20 07:25:03 --> Output Class Initialized
INFO - 2022-06-20 07:25:03 --> Security Class Initialized
DEBUG - 2022-06-20 07:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:25:03 --> Input Class Initialized
INFO - 2022-06-20 07:25:03 --> Language Class Initialized
INFO - 2022-06-20 07:25:03 --> Language Class Initialized
INFO - 2022-06-20 07:25:03 --> Config Class Initialized
INFO - 2022-06-20 07:25:03 --> Loader Class Initialized
INFO - 2022-06-20 07:25:03 --> Helper loaded: url_helper
INFO - 2022-06-20 07:25:03 --> Database Driver Class Initialized
INFO - 2022-06-20 07:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:25:03 --> Model Class Initialized
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:25:03 --> Model Class Initialized
INFO - 2022-06-20 07:25:03 --> Controller Class Initialized
DEBUG - 2022-06-20 07:25:03 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:25:03 --> Config Class Initialized
INFO - 2022-06-20 07:25:03 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:25:03 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:25:03 --> Utf8 Class Initialized
INFO - 2022-06-20 07:25:03 --> URI Class Initialized
INFO - 2022-06-20 07:25:03 --> Router Class Initialized
INFO - 2022-06-20 07:25:03 --> Output Class Initialized
INFO - 2022-06-20 07:25:03 --> Security Class Initialized
DEBUG - 2022-06-20 07:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:25:03 --> Input Class Initialized
INFO - 2022-06-20 07:25:03 --> Language Class Initialized
INFO - 2022-06-20 07:25:03 --> Language Class Initialized
INFO - 2022-06-20 07:25:03 --> Config Class Initialized
INFO - 2022-06-20 07:25:03 --> Loader Class Initialized
INFO - 2022-06-20 07:25:03 --> Helper loaded: url_helper
INFO - 2022-06-20 07:25:03 --> Database Driver Class Initialized
INFO - 2022-06-20 07:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:25:03 --> Model Class Initialized
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:25:03 --> Model Class Initialized
INFO - 2022-06-20 07:25:03 --> Controller Class Initialized
DEBUG - 2022-06-20 07:25:03 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:25:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:25:04 --> Final output sent to browser
DEBUG - 2022-06-20 07:25:04 --> Total execution time: 0.0444
INFO - 2022-06-20 07:25:23 --> Config Class Initialized
INFO - 2022-06-20 07:25:23 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:25:23 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:25:23 --> Utf8 Class Initialized
INFO - 2022-06-20 07:25:23 --> URI Class Initialized
INFO - 2022-06-20 07:25:23 --> Router Class Initialized
INFO - 2022-06-20 07:25:23 --> Output Class Initialized
INFO - 2022-06-20 07:25:23 --> Security Class Initialized
DEBUG - 2022-06-20 07:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:25:23 --> Input Class Initialized
INFO - 2022-06-20 07:25:23 --> Language Class Initialized
INFO - 2022-06-20 07:25:23 --> Language Class Initialized
INFO - 2022-06-20 07:25:23 --> Config Class Initialized
INFO - 2022-06-20 07:25:23 --> Loader Class Initialized
INFO - 2022-06-20 07:25:23 --> Helper loaded: url_helper
INFO - 2022-06-20 07:25:23 --> Database Driver Class Initialized
INFO - 2022-06-20 07:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:25:23 --> Model Class Initialized
DEBUG - 2022-06-20 07:25:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:25:23 --> Model Class Initialized
INFO - 2022-06-20 07:25:23 --> Controller Class Initialized
DEBUG - 2022-06-20 07:25:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:25:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:25:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:25:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:25:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:25:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:25:23 --> Final output sent to browser
DEBUG - 2022-06-20 07:25:23 --> Total execution time: 0.0388
INFO - 2022-06-20 07:25:27 --> Config Class Initialized
INFO - 2022-06-20 07:25:27 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:25:27 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:25:27 --> Utf8 Class Initialized
INFO - 2022-06-20 07:25:27 --> URI Class Initialized
INFO - 2022-06-20 07:25:27 --> Router Class Initialized
INFO - 2022-06-20 07:25:27 --> Output Class Initialized
INFO - 2022-06-20 07:25:27 --> Security Class Initialized
DEBUG - 2022-06-20 07:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:25:27 --> Input Class Initialized
INFO - 2022-06-20 07:25:27 --> Language Class Initialized
INFO - 2022-06-20 07:25:27 --> Language Class Initialized
INFO - 2022-06-20 07:25:27 --> Config Class Initialized
INFO - 2022-06-20 07:25:27 --> Loader Class Initialized
INFO - 2022-06-20 07:25:27 --> Helper loaded: url_helper
INFO - 2022-06-20 07:25:27 --> Database Driver Class Initialized
INFO - 2022-06-20 07:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:25:27 --> Model Class Initialized
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:25:27 --> Model Class Initialized
INFO - 2022-06-20 07:25:27 --> Controller Class Initialized
DEBUG - 2022-06-20 07:25:27 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:25:27 --> Config Class Initialized
INFO - 2022-06-20 07:25:27 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:25:27 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:25:27 --> Utf8 Class Initialized
INFO - 2022-06-20 07:25:27 --> URI Class Initialized
INFO - 2022-06-20 07:25:27 --> Router Class Initialized
INFO - 2022-06-20 07:25:27 --> Output Class Initialized
INFO - 2022-06-20 07:25:27 --> Security Class Initialized
DEBUG - 2022-06-20 07:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:25:27 --> Input Class Initialized
INFO - 2022-06-20 07:25:27 --> Language Class Initialized
INFO - 2022-06-20 07:25:27 --> Language Class Initialized
INFO - 2022-06-20 07:25:27 --> Config Class Initialized
INFO - 2022-06-20 07:25:27 --> Loader Class Initialized
INFO - 2022-06-20 07:25:27 --> Helper loaded: url_helper
INFO - 2022-06-20 07:25:27 --> Database Driver Class Initialized
INFO - 2022-06-20 07:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:25:27 --> Model Class Initialized
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:25:27 --> Model Class Initialized
INFO - 2022-06-20 07:25:27 --> Controller Class Initialized
DEBUG - 2022-06-20 07:25:27 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:25:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:25:27 --> Final output sent to browser
DEBUG - 2022-06-20 07:25:27 --> Total execution time: 0.0273
INFO - 2022-06-20 07:27:12 --> Config Class Initialized
INFO - 2022-06-20 07:27:12 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:27:12 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:27:12 --> Utf8 Class Initialized
INFO - 2022-06-20 07:27:12 --> URI Class Initialized
INFO - 2022-06-20 07:27:12 --> Router Class Initialized
INFO - 2022-06-20 07:27:12 --> Output Class Initialized
INFO - 2022-06-20 07:27:12 --> Security Class Initialized
DEBUG - 2022-06-20 07:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:27:12 --> Input Class Initialized
INFO - 2022-06-20 07:27:12 --> Language Class Initialized
INFO - 2022-06-20 07:27:12 --> Language Class Initialized
INFO - 2022-06-20 07:27:12 --> Config Class Initialized
INFO - 2022-06-20 07:27:12 --> Loader Class Initialized
INFO - 2022-06-20 07:27:12 --> Helper loaded: url_helper
INFO - 2022-06-20 07:27:12 --> Database Driver Class Initialized
INFO - 2022-06-20 07:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:27:12 --> Model Class Initialized
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:27:12 --> Model Class Initialized
INFO - 2022-06-20 07:27:12 --> Controller Class Initialized
DEBUG - 2022-06-20 07:27:12 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:27:12 --> Config Class Initialized
INFO - 2022-06-20 07:27:12 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:27:12 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:27:12 --> Utf8 Class Initialized
INFO - 2022-06-20 07:27:12 --> URI Class Initialized
INFO - 2022-06-20 07:27:12 --> Router Class Initialized
INFO - 2022-06-20 07:27:12 --> Output Class Initialized
INFO - 2022-06-20 07:27:12 --> Security Class Initialized
DEBUG - 2022-06-20 07:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:27:12 --> Input Class Initialized
INFO - 2022-06-20 07:27:12 --> Language Class Initialized
INFO - 2022-06-20 07:27:12 --> Language Class Initialized
INFO - 2022-06-20 07:27:12 --> Config Class Initialized
INFO - 2022-06-20 07:27:12 --> Loader Class Initialized
INFO - 2022-06-20 07:27:12 --> Helper loaded: url_helper
INFO - 2022-06-20 07:27:12 --> Database Driver Class Initialized
INFO - 2022-06-20 07:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:27:12 --> Model Class Initialized
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:27:12 --> Model Class Initialized
INFO - 2022-06-20 07:27:12 --> Controller Class Initialized
DEBUG - 2022-06-20 07:27:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:27:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:27:12 --> Final output sent to browser
DEBUG - 2022-06-20 07:27:12 --> Total execution time: 0.0360
INFO - 2022-06-20 07:27:32 --> Config Class Initialized
INFO - 2022-06-20 07:27:32 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:27:32 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:27:32 --> Utf8 Class Initialized
INFO - 2022-06-20 07:27:33 --> URI Class Initialized
INFO - 2022-06-20 07:27:33 --> Router Class Initialized
INFO - 2022-06-20 07:27:33 --> Output Class Initialized
INFO - 2022-06-20 07:27:33 --> Security Class Initialized
DEBUG - 2022-06-20 07:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:27:33 --> Input Class Initialized
INFO - 2022-06-20 07:27:33 --> Language Class Initialized
INFO - 2022-06-20 07:27:33 --> Language Class Initialized
INFO - 2022-06-20 07:27:33 --> Config Class Initialized
INFO - 2022-06-20 07:27:33 --> Loader Class Initialized
INFO - 2022-06-20 07:27:33 --> Helper loaded: url_helper
INFO - 2022-06-20 07:27:33 --> Database Driver Class Initialized
INFO - 2022-06-20 07:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:27:33 --> Model Class Initialized
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:27:33 --> Model Class Initialized
INFO - 2022-06-20 07:27:33 --> Controller Class Initialized
DEBUG - 2022-06-20 07:27:33 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:27:33 --> Config Class Initialized
INFO - 2022-06-20 07:27:33 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:27:33 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:27:33 --> Utf8 Class Initialized
INFO - 2022-06-20 07:27:33 --> URI Class Initialized
INFO - 2022-06-20 07:27:33 --> Router Class Initialized
INFO - 2022-06-20 07:27:33 --> Output Class Initialized
INFO - 2022-06-20 07:27:33 --> Security Class Initialized
DEBUG - 2022-06-20 07:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:27:33 --> Input Class Initialized
INFO - 2022-06-20 07:27:33 --> Language Class Initialized
INFO - 2022-06-20 07:27:33 --> Language Class Initialized
INFO - 2022-06-20 07:27:33 --> Config Class Initialized
INFO - 2022-06-20 07:27:33 --> Loader Class Initialized
INFO - 2022-06-20 07:27:33 --> Helper loaded: url_helper
INFO - 2022-06-20 07:27:33 --> Database Driver Class Initialized
INFO - 2022-06-20 07:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:27:33 --> Model Class Initialized
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:27:33 --> Model Class Initialized
INFO - 2022-06-20 07:27:33 --> Controller Class Initialized
DEBUG - 2022-06-20 07:27:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_country.php
DEBUG - 2022-06-20 07:27:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:27:33 --> Final output sent to browser
DEBUG - 2022-06-20 07:27:33 --> Total execution time: 0.0384
INFO - 2022-06-20 07:27:37 --> Config Class Initialized
INFO - 2022-06-20 07:27:37 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:27:37 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:27:37 --> Utf8 Class Initialized
INFO - 2022-06-20 07:27:37 --> URI Class Initialized
INFO - 2022-06-20 07:27:37 --> Router Class Initialized
INFO - 2022-06-20 07:27:37 --> Output Class Initialized
INFO - 2022-06-20 07:27:37 --> Security Class Initialized
DEBUG - 2022-06-20 07:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:27:37 --> Input Class Initialized
INFO - 2022-06-20 07:27:37 --> Language Class Initialized
INFO - 2022-06-20 07:27:37 --> Language Class Initialized
INFO - 2022-06-20 07:27:37 --> Config Class Initialized
INFO - 2022-06-20 07:27:37 --> Loader Class Initialized
INFO - 2022-06-20 07:27:37 --> Helper loaded: url_helper
INFO - 2022-06-20 07:27:37 --> Database Driver Class Initialized
INFO - 2022-06-20 07:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:27:37 --> Model Class Initialized
DEBUG - 2022-06-20 07:27:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:27:37 --> Model Class Initialized
INFO - 2022-06-20 07:27:37 --> Controller Class Initialized
DEBUG - 2022-06-20 07:27:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:27:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:27:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:27:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:27:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:27:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:27:37 --> Final output sent to browser
DEBUG - 2022-06-20 07:27:37 --> Total execution time: 0.0362
INFO - 2022-06-20 07:28:35 --> Config Class Initialized
INFO - 2022-06-20 07:28:35 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:28:35 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:28:35 --> Utf8 Class Initialized
INFO - 2022-06-20 07:28:35 --> URI Class Initialized
INFO - 2022-06-20 07:28:35 --> Router Class Initialized
INFO - 2022-06-20 07:28:35 --> Output Class Initialized
INFO - 2022-06-20 07:28:35 --> Security Class Initialized
DEBUG - 2022-06-20 07:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:28:35 --> Input Class Initialized
INFO - 2022-06-20 07:28:35 --> Language Class Initialized
INFO - 2022-06-20 07:28:35 --> Language Class Initialized
INFO - 2022-06-20 07:28:35 --> Config Class Initialized
INFO - 2022-06-20 07:28:35 --> Loader Class Initialized
INFO - 2022-06-20 07:28:35 --> Helper loaded: url_helper
INFO - 2022-06-20 07:28:35 --> Database Driver Class Initialized
INFO - 2022-06-20 07:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:28:35 --> Model Class Initialized
DEBUG - 2022-06-20 07:28:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:28:35 --> Model Class Initialized
INFO - 2022-06-20 07:28:35 --> Controller Class Initialized
DEBUG - 2022-06-20 07:28:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:28:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:28:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:28:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:28:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:28:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:28:35 --> Final output sent to browser
DEBUG - 2022-06-20 07:28:35 --> Total execution time: 0.0407
INFO - 2022-06-20 07:28:44 --> Config Class Initialized
INFO - 2022-06-20 07:28:44 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:28:45 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:28:45 --> Utf8 Class Initialized
INFO - 2022-06-20 07:28:45 --> URI Class Initialized
INFO - 2022-06-20 07:28:45 --> Router Class Initialized
INFO - 2022-06-20 07:28:45 --> Output Class Initialized
INFO - 2022-06-20 07:28:45 --> Security Class Initialized
DEBUG - 2022-06-20 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:28:45 --> Input Class Initialized
INFO - 2022-06-20 07:28:45 --> Language Class Initialized
INFO - 2022-06-20 07:28:45 --> Language Class Initialized
INFO - 2022-06-20 07:28:45 --> Config Class Initialized
INFO - 2022-06-20 07:28:45 --> Loader Class Initialized
INFO - 2022-06-20 07:28:45 --> Helper loaded: url_helper
INFO - 2022-06-20 07:28:45 --> Database Driver Class Initialized
INFO - 2022-06-20 07:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:28:45 --> Model Class Initialized
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:28:45 --> Model Class Initialized
INFO - 2022-06-20 07:28:45 --> Controller Class Initialized
DEBUG - 2022-06-20 07:28:45 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:28:45 --> Config Class Initialized
INFO - 2022-06-20 07:28:45 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:28:45 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:28:45 --> Utf8 Class Initialized
INFO - 2022-06-20 07:28:45 --> URI Class Initialized
INFO - 2022-06-20 07:28:45 --> Router Class Initialized
INFO - 2022-06-20 07:28:45 --> Output Class Initialized
INFO - 2022-06-20 07:28:45 --> Security Class Initialized
DEBUG - 2022-06-20 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:28:45 --> Input Class Initialized
INFO - 2022-06-20 07:28:45 --> Language Class Initialized
INFO - 2022-06-20 07:28:45 --> Language Class Initialized
INFO - 2022-06-20 07:28:45 --> Config Class Initialized
INFO - 2022-06-20 07:28:45 --> Loader Class Initialized
INFO - 2022-06-20 07:28:45 --> Helper loaded: url_helper
INFO - 2022-06-20 07:28:45 --> Database Driver Class Initialized
INFO - 2022-06-20 07:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:28:45 --> Model Class Initialized
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:28:45 --> Model Class Initialized
INFO - 2022-06-20 07:28:45 --> Controller Class Initialized
DEBUG - 2022-06-20 07:28:45 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:28:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:28:45 --> Final output sent to browser
DEBUG - 2022-06-20 07:28:45 --> Total execution time: 0.0344
INFO - 2022-06-20 07:28:53 --> Config Class Initialized
INFO - 2022-06-20 07:28:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:28:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:28:53 --> Utf8 Class Initialized
INFO - 2022-06-20 07:28:53 --> URI Class Initialized
INFO - 2022-06-20 07:28:53 --> Router Class Initialized
INFO - 2022-06-20 07:28:53 --> Output Class Initialized
INFO - 2022-06-20 07:28:53 --> Security Class Initialized
DEBUG - 2022-06-20 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:28:53 --> Input Class Initialized
INFO - 2022-06-20 07:28:53 --> Language Class Initialized
INFO - 2022-06-20 07:28:53 --> Language Class Initialized
INFO - 2022-06-20 07:28:53 --> Config Class Initialized
INFO - 2022-06-20 07:28:53 --> Loader Class Initialized
INFO - 2022-06-20 07:28:53 --> Helper loaded: url_helper
INFO - 2022-06-20 07:28:53 --> Database Driver Class Initialized
INFO - 2022-06-20 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:28:53 --> Model Class Initialized
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:28:53 --> Model Class Initialized
INFO - 2022-06-20 07:28:53 --> Controller Class Initialized
DEBUG - 2022-06-20 07:28:53 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:28:53 --> Config Class Initialized
INFO - 2022-06-20 07:28:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:28:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:28:53 --> Utf8 Class Initialized
INFO - 2022-06-20 07:28:53 --> URI Class Initialized
INFO - 2022-06-20 07:28:53 --> Router Class Initialized
INFO - 2022-06-20 07:28:53 --> Output Class Initialized
INFO - 2022-06-20 07:28:53 --> Security Class Initialized
DEBUG - 2022-06-20 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:28:53 --> Input Class Initialized
INFO - 2022-06-20 07:28:53 --> Language Class Initialized
INFO - 2022-06-20 07:28:53 --> Language Class Initialized
INFO - 2022-06-20 07:28:53 --> Config Class Initialized
INFO - 2022-06-20 07:28:53 --> Loader Class Initialized
INFO - 2022-06-20 07:28:53 --> Helper loaded: url_helper
INFO - 2022-06-20 07:28:53 --> Database Driver Class Initialized
INFO - 2022-06-20 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:28:53 --> Model Class Initialized
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:28:53 --> Model Class Initialized
INFO - 2022-06-20 07:28:53 --> Controller Class Initialized
DEBUG - 2022-06-20 07:28:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:28:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:28:53 --> Final output sent to browser
DEBUG - 2022-06-20 07:28:53 --> Total execution time: 0.0433
INFO - 2022-06-20 07:29:18 --> Config Class Initialized
INFO - 2022-06-20 07:29:18 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:29:18 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:29:18 --> Utf8 Class Initialized
INFO - 2022-06-20 07:29:18 --> URI Class Initialized
INFO - 2022-06-20 07:29:18 --> Router Class Initialized
INFO - 2022-06-20 07:29:18 --> Output Class Initialized
INFO - 2022-06-20 07:29:18 --> Security Class Initialized
DEBUG - 2022-06-20 07:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:29:18 --> Input Class Initialized
INFO - 2022-06-20 07:29:18 --> Language Class Initialized
INFO - 2022-06-20 07:29:18 --> Language Class Initialized
INFO - 2022-06-20 07:29:18 --> Config Class Initialized
INFO - 2022-06-20 07:29:18 --> Loader Class Initialized
INFO - 2022-06-20 07:29:18 --> Helper loaded: url_helper
INFO - 2022-06-20 07:29:18 --> Database Driver Class Initialized
INFO - 2022-06-20 07:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:29:18 --> Model Class Initialized
DEBUG - 2022-06-20 07:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:29:18 --> Model Class Initialized
INFO - 2022-06-20 07:29:18 --> Controller Class Initialized
DEBUG - 2022-06-20 07:29:18 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:29:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:29:18 --> Final output sent to browser
DEBUG - 2022-06-20 07:29:18 --> Total execution time: 0.0296
INFO - 2022-06-20 07:29:23 --> Config Class Initialized
INFO - 2022-06-20 07:29:23 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:29:23 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:29:23 --> Utf8 Class Initialized
INFO - 2022-06-20 07:29:23 --> URI Class Initialized
INFO - 2022-06-20 07:29:23 --> Router Class Initialized
INFO - 2022-06-20 07:29:23 --> Output Class Initialized
INFO - 2022-06-20 07:29:23 --> Security Class Initialized
DEBUG - 2022-06-20 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:29:23 --> Input Class Initialized
INFO - 2022-06-20 07:29:23 --> Language Class Initialized
INFO - 2022-06-20 07:29:23 --> Language Class Initialized
INFO - 2022-06-20 07:29:23 --> Config Class Initialized
INFO - 2022-06-20 07:29:23 --> Loader Class Initialized
INFO - 2022-06-20 07:29:23 --> Helper loaded: url_helper
INFO - 2022-06-20 07:29:23 --> Database Driver Class Initialized
INFO - 2022-06-20 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:29:23 --> Model Class Initialized
DEBUG - 2022-06-20 07:29:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:29:23 --> Model Class Initialized
INFO - 2022-06-20 07:29:23 --> Controller Class Initialized
DEBUG - 2022-06-20 07:29:23 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:30:31 --> Config Class Initialized
INFO - 2022-06-20 07:30:31 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:30:31 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:30:31 --> Utf8 Class Initialized
INFO - 2022-06-20 07:30:31 --> URI Class Initialized
INFO - 2022-06-20 07:30:31 --> Router Class Initialized
INFO - 2022-06-20 07:30:31 --> Output Class Initialized
INFO - 2022-06-20 07:30:31 --> Security Class Initialized
DEBUG - 2022-06-20 07:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:30:31 --> Input Class Initialized
INFO - 2022-06-20 07:30:31 --> Language Class Initialized
INFO - 2022-06-20 07:30:31 --> Language Class Initialized
INFO - 2022-06-20 07:30:31 --> Config Class Initialized
INFO - 2022-06-20 07:30:31 --> Loader Class Initialized
INFO - 2022-06-20 07:30:31 --> Helper loaded: url_helper
INFO - 2022-06-20 07:30:31 --> Database Driver Class Initialized
INFO - 2022-06-20 07:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:30:31 --> Model Class Initialized
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:30:31 --> Model Class Initialized
INFO - 2022-06-20 07:30:31 --> Controller Class Initialized
DEBUG - 2022-06-20 07:30:31 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:30:31 --> Config Class Initialized
INFO - 2022-06-20 07:30:31 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:30:31 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:30:31 --> Utf8 Class Initialized
INFO - 2022-06-20 07:30:31 --> URI Class Initialized
INFO - 2022-06-20 07:30:31 --> Router Class Initialized
INFO - 2022-06-20 07:30:31 --> Output Class Initialized
INFO - 2022-06-20 07:30:31 --> Security Class Initialized
DEBUG - 2022-06-20 07:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:30:31 --> Input Class Initialized
INFO - 2022-06-20 07:30:31 --> Language Class Initialized
INFO - 2022-06-20 07:30:31 --> Language Class Initialized
INFO - 2022-06-20 07:30:31 --> Config Class Initialized
INFO - 2022-06-20 07:30:31 --> Loader Class Initialized
INFO - 2022-06-20 07:30:31 --> Helper loaded: url_helper
INFO - 2022-06-20 07:30:31 --> Database Driver Class Initialized
INFO - 2022-06-20 07:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:30:31 --> Model Class Initialized
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:30:31 --> Model Class Initialized
INFO - 2022-06-20 07:30:31 --> Controller Class Initialized
DEBUG - 2022-06-20 07:30:31 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:30:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:30:31 --> Final output sent to browser
DEBUG - 2022-06-20 07:30:31 --> Total execution time: 0.0302
INFO - 2022-06-20 07:30:41 --> Config Class Initialized
INFO - 2022-06-20 07:30:41 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:30:41 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:30:41 --> Utf8 Class Initialized
INFO - 2022-06-20 07:30:41 --> URI Class Initialized
INFO - 2022-06-20 07:30:41 --> Router Class Initialized
INFO - 2022-06-20 07:30:41 --> Output Class Initialized
INFO - 2022-06-20 07:30:41 --> Security Class Initialized
DEBUG - 2022-06-20 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:30:41 --> Input Class Initialized
INFO - 2022-06-20 07:30:41 --> Language Class Initialized
INFO - 2022-06-20 07:30:41 --> Language Class Initialized
INFO - 2022-06-20 07:30:41 --> Config Class Initialized
INFO - 2022-06-20 07:30:41 --> Loader Class Initialized
INFO - 2022-06-20 07:30:41 --> Helper loaded: url_helper
INFO - 2022-06-20 07:30:41 --> Database Driver Class Initialized
INFO - 2022-06-20 07:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:30:41 --> Model Class Initialized
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:30:41 --> Model Class Initialized
INFO - 2022-06-20 07:30:41 --> Controller Class Initialized
DEBUG - 2022-06-20 07:30:41 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:30:41 --> Config Class Initialized
INFO - 2022-06-20 07:30:41 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:30:41 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:30:41 --> Utf8 Class Initialized
INFO - 2022-06-20 07:30:41 --> URI Class Initialized
INFO - 2022-06-20 07:30:41 --> Router Class Initialized
INFO - 2022-06-20 07:30:41 --> Output Class Initialized
INFO - 2022-06-20 07:30:41 --> Security Class Initialized
DEBUG - 2022-06-20 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:30:41 --> Input Class Initialized
INFO - 2022-06-20 07:30:41 --> Language Class Initialized
INFO - 2022-06-20 07:30:41 --> Language Class Initialized
INFO - 2022-06-20 07:30:41 --> Config Class Initialized
INFO - 2022-06-20 07:30:41 --> Loader Class Initialized
INFO - 2022-06-20 07:30:41 --> Helper loaded: url_helper
INFO - 2022-06-20 07:30:41 --> Database Driver Class Initialized
INFO - 2022-06-20 07:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:30:41 --> Model Class Initialized
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:30:41 --> Model Class Initialized
INFO - 2022-06-20 07:30:41 --> Controller Class Initialized
DEBUG - 2022-06-20 07:30:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_state.php
DEBUG - 2022-06-20 07:30:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:30:41 --> Final output sent to browser
DEBUG - 2022-06-20 07:30:41 --> Total execution time: 0.0299
INFO - 2022-06-20 07:30:43 --> Config Class Initialized
INFO - 2022-06-20 07:30:43 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:30:43 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:30:43 --> Utf8 Class Initialized
INFO - 2022-06-20 07:30:43 --> URI Class Initialized
INFO - 2022-06-20 07:30:43 --> Router Class Initialized
INFO - 2022-06-20 07:30:43 --> Output Class Initialized
INFO - 2022-06-20 07:30:43 --> Security Class Initialized
DEBUG - 2022-06-20 07:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:30:43 --> Input Class Initialized
INFO - 2022-06-20 07:30:43 --> Language Class Initialized
INFO - 2022-06-20 07:30:43 --> Language Class Initialized
INFO - 2022-06-20 07:30:43 --> Config Class Initialized
INFO - 2022-06-20 07:30:43 --> Loader Class Initialized
INFO - 2022-06-20 07:30:43 --> Helper loaded: url_helper
INFO - 2022-06-20 07:30:43 --> Database Driver Class Initialized
INFO - 2022-06-20 07:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:30:43 --> Model Class Initialized
DEBUG - 2022-06-20 07:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:30:43 --> Model Class Initialized
INFO - 2022-06-20 07:30:43 --> Controller Class Initialized
DEBUG - 2022-06-20 07:30:43 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-20 07:30:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:30:43 --> Final output sent to browser
DEBUG - 2022-06-20 07:30:43 --> Total execution time: 0.0363
INFO - 2022-06-20 07:30:53 --> Config Class Initialized
INFO - 2022-06-20 07:30:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:30:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:30:53 --> Utf8 Class Initialized
INFO - 2022-06-20 07:30:53 --> URI Class Initialized
INFO - 2022-06-20 07:30:53 --> Router Class Initialized
INFO - 2022-06-20 07:30:53 --> Output Class Initialized
INFO - 2022-06-20 07:30:53 --> Security Class Initialized
DEBUG - 2022-06-20 07:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:30:53 --> Input Class Initialized
INFO - 2022-06-20 07:30:53 --> Language Class Initialized
INFO - 2022-06-20 07:30:53 --> Language Class Initialized
INFO - 2022-06-20 07:30:53 --> Config Class Initialized
INFO - 2022-06-20 07:30:53 --> Loader Class Initialized
INFO - 2022-06-20 07:30:53 --> Helper loaded: url_helper
INFO - 2022-06-20 07:30:53 --> Database Driver Class Initialized
INFO - 2022-06-20 07:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:30:53 --> Model Class Initialized
DEBUG - 2022-06-20 07:30:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:30:53 --> Model Class Initialized
INFO - 2022-06-20 07:30:53 --> Controller Class Initialized
DEBUG - 2022-06-20 07:30:53 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:30:53 --> Final output sent to browser
DEBUG - 2022-06-20 07:30:53 --> Total execution time: 0.0385
INFO - 2022-06-20 07:31:04 --> Config Class Initialized
INFO - 2022-06-20 07:31:04 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:31:04 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:31:04 --> Utf8 Class Initialized
INFO - 2022-06-20 07:31:04 --> URI Class Initialized
INFO - 2022-06-20 07:31:04 --> Router Class Initialized
INFO - 2022-06-20 07:31:04 --> Output Class Initialized
INFO - 2022-06-20 07:31:04 --> Security Class Initialized
DEBUG - 2022-06-20 07:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:31:04 --> Input Class Initialized
INFO - 2022-06-20 07:31:04 --> Language Class Initialized
INFO - 2022-06-20 07:31:04 --> Language Class Initialized
INFO - 2022-06-20 07:31:04 --> Config Class Initialized
INFO - 2022-06-20 07:31:04 --> Loader Class Initialized
INFO - 2022-06-20 07:31:04 --> Helper loaded: url_helper
INFO - 2022-06-20 07:31:04 --> Database Driver Class Initialized
INFO - 2022-06-20 07:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:31:04 --> Model Class Initialized
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:31:04 --> Model Class Initialized
INFO - 2022-06-20 07:31:04 --> Controller Class Initialized
DEBUG - 2022-06-20 07:31:04 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:31:04 --> Config Class Initialized
INFO - 2022-06-20 07:31:04 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:31:04 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:31:04 --> Utf8 Class Initialized
INFO - 2022-06-20 07:31:04 --> URI Class Initialized
INFO - 2022-06-20 07:31:04 --> Router Class Initialized
INFO - 2022-06-20 07:31:04 --> Output Class Initialized
INFO - 2022-06-20 07:31:04 --> Security Class Initialized
DEBUG - 2022-06-20 07:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:31:04 --> Input Class Initialized
INFO - 2022-06-20 07:31:04 --> Language Class Initialized
INFO - 2022-06-20 07:31:04 --> Language Class Initialized
INFO - 2022-06-20 07:31:04 --> Config Class Initialized
INFO - 2022-06-20 07:31:04 --> Loader Class Initialized
INFO - 2022-06-20 07:31:04 --> Helper loaded: url_helper
INFO - 2022-06-20 07:31:04 --> Database Driver Class Initialized
INFO - 2022-06-20 07:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:31:04 --> Model Class Initialized
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:31:04 --> Model Class Initialized
INFO - 2022-06-20 07:31:04 --> Controller Class Initialized
DEBUG - 2022-06-20 07:31:04 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-20 07:31:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:31:04 --> Final output sent to browser
DEBUG - 2022-06-20 07:31:04 --> Total execution time: 0.0278
INFO - 2022-06-20 07:31:18 --> Config Class Initialized
INFO - 2022-06-20 07:31:18 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:31:18 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:31:18 --> Utf8 Class Initialized
INFO - 2022-06-20 07:31:18 --> URI Class Initialized
INFO - 2022-06-20 07:31:18 --> Router Class Initialized
INFO - 2022-06-20 07:31:18 --> Output Class Initialized
INFO - 2022-06-20 07:31:18 --> Security Class Initialized
DEBUG - 2022-06-20 07:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:31:18 --> Input Class Initialized
INFO - 2022-06-20 07:31:18 --> Language Class Initialized
INFO - 2022-06-20 07:31:18 --> Language Class Initialized
INFO - 2022-06-20 07:31:18 --> Config Class Initialized
INFO - 2022-06-20 07:31:18 --> Loader Class Initialized
INFO - 2022-06-20 07:31:18 --> Helper loaded: url_helper
INFO - 2022-06-20 07:31:18 --> Database Driver Class Initialized
INFO - 2022-06-20 07:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:31:18 --> Model Class Initialized
DEBUG - 2022-06-20 07:31:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:31:18 --> Model Class Initialized
INFO - 2022-06-20 07:31:18 --> Controller Class Initialized
DEBUG - 2022-06-20 07:31:18 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:31:18 --> Final output sent to browser
DEBUG - 2022-06-20 07:31:18 --> Total execution time: 0.0382
INFO - 2022-06-20 07:31:34 --> Config Class Initialized
INFO - 2022-06-20 07:31:34 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:31:34 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:31:34 --> Utf8 Class Initialized
INFO - 2022-06-20 07:31:34 --> URI Class Initialized
INFO - 2022-06-20 07:31:34 --> Router Class Initialized
INFO - 2022-06-20 07:31:34 --> Output Class Initialized
INFO - 2022-06-20 07:31:34 --> Security Class Initialized
DEBUG - 2022-06-20 07:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:31:34 --> Input Class Initialized
INFO - 2022-06-20 07:31:34 --> Language Class Initialized
INFO - 2022-06-20 07:31:34 --> Language Class Initialized
INFO - 2022-06-20 07:31:34 --> Config Class Initialized
INFO - 2022-06-20 07:31:34 --> Loader Class Initialized
INFO - 2022-06-20 07:31:34 --> Helper loaded: url_helper
INFO - 2022-06-20 07:31:34 --> Database Driver Class Initialized
INFO - 2022-06-20 07:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:31:34 --> Model Class Initialized
DEBUG - 2022-06-20 07:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:31:34 --> Model Class Initialized
INFO - 2022-06-20 07:31:34 --> Controller Class Initialized
DEBUG - 2022-06-20 07:31:34 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:31:35 --> Config Class Initialized
INFO - 2022-06-20 07:31:35 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:31:35 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:31:35 --> Utf8 Class Initialized
INFO - 2022-06-20 07:31:35 --> URI Class Initialized
INFO - 2022-06-20 07:31:35 --> Router Class Initialized
INFO - 2022-06-20 07:31:35 --> Output Class Initialized
INFO - 2022-06-20 07:31:35 --> Security Class Initialized
DEBUG - 2022-06-20 07:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:31:35 --> Input Class Initialized
INFO - 2022-06-20 07:31:35 --> Language Class Initialized
INFO - 2022-06-20 07:31:35 --> Language Class Initialized
INFO - 2022-06-20 07:31:35 --> Config Class Initialized
INFO - 2022-06-20 07:31:35 --> Loader Class Initialized
INFO - 2022-06-20 07:31:35 --> Helper loaded: url_helper
INFO - 2022-06-20 07:31:35 --> Database Driver Class Initialized
INFO - 2022-06-20 07:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:31:35 --> Model Class Initialized
DEBUG - 2022-06-20 07:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:31:35 --> Model Class Initialized
INFO - 2022-06-20 07:31:35 --> Controller Class Initialized
DEBUG - 2022-06-20 07:31:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-20 07:31:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:31:35 --> Final output sent to browser
DEBUG - 2022-06-20 07:31:35 --> Total execution time: 0.0288
INFO - 2022-06-20 07:31:39 --> Config Class Initialized
INFO - 2022-06-20 07:31:39 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:31:39 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:31:39 --> Utf8 Class Initialized
INFO - 2022-06-20 07:31:39 --> URI Class Initialized
INFO - 2022-06-20 07:31:39 --> Router Class Initialized
INFO - 2022-06-20 07:31:39 --> Output Class Initialized
INFO - 2022-06-20 07:31:39 --> Security Class Initialized
DEBUG - 2022-06-20 07:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:31:39 --> Input Class Initialized
INFO - 2022-06-20 07:31:39 --> Language Class Initialized
INFO - 2022-06-20 07:31:39 --> Language Class Initialized
INFO - 2022-06-20 07:31:39 --> Config Class Initialized
INFO - 2022-06-20 07:31:39 --> Loader Class Initialized
INFO - 2022-06-20 07:31:39 --> Helper loaded: url_helper
INFO - 2022-06-20 07:31:39 --> Database Driver Class Initialized
INFO - 2022-06-20 07:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:31:39 --> Model Class Initialized
DEBUG - 2022-06-20 07:31:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:31:39 --> Model Class Initialized
INFO - 2022-06-20 07:31:39 --> Controller Class Initialized
DEBUG - 2022-06-20 07:31:39 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:31:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:31:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:31:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:31:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:31:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:31:39 --> Final output sent to browser
DEBUG - 2022-06-20 07:31:39 --> Total execution time: 0.0293
INFO - 2022-06-20 07:33:41 --> Config Class Initialized
INFO - 2022-06-20 07:33:41 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:33:41 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:33:41 --> Utf8 Class Initialized
INFO - 2022-06-20 07:33:41 --> URI Class Initialized
INFO - 2022-06-20 07:33:41 --> Router Class Initialized
INFO - 2022-06-20 07:33:41 --> Output Class Initialized
INFO - 2022-06-20 07:33:41 --> Security Class Initialized
DEBUG - 2022-06-20 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:33:41 --> Input Class Initialized
INFO - 2022-06-20 07:33:41 --> Language Class Initialized
INFO - 2022-06-20 07:33:41 --> Language Class Initialized
INFO - 2022-06-20 07:33:41 --> Config Class Initialized
INFO - 2022-06-20 07:33:41 --> Loader Class Initialized
INFO - 2022-06-20 07:33:41 --> Helper loaded: url_helper
INFO - 2022-06-20 07:33:41 --> Database Driver Class Initialized
INFO - 2022-06-20 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:33:41 --> Model Class Initialized
DEBUG - 2022-06-20 07:33:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:33:41 --> Model Class Initialized
INFO - 2022-06-20 07:33:41 --> Controller Class Initialized
DEBUG - 2022-06-20 07:33:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:33:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:33:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:33:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:33:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:33:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:33:41 --> Final output sent to browser
DEBUG - 2022-06-20 07:33:41 --> Total execution time: 0.0398
INFO - 2022-06-20 07:34:02 --> Config Class Initialized
INFO - 2022-06-20 07:34:02 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:34:02 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:34:02 --> Utf8 Class Initialized
INFO - 2022-06-20 07:34:02 --> URI Class Initialized
INFO - 2022-06-20 07:34:02 --> Router Class Initialized
INFO - 2022-06-20 07:34:02 --> Output Class Initialized
INFO - 2022-06-20 07:34:02 --> Security Class Initialized
DEBUG - 2022-06-20 07:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:34:02 --> Input Class Initialized
INFO - 2022-06-20 07:34:02 --> Language Class Initialized
INFO - 2022-06-20 07:34:02 --> Language Class Initialized
INFO - 2022-06-20 07:34:02 --> Config Class Initialized
INFO - 2022-06-20 07:34:02 --> Loader Class Initialized
INFO - 2022-06-20 07:34:02 --> Helper loaded: url_helper
INFO - 2022-06-20 07:34:02 --> Database Driver Class Initialized
INFO - 2022-06-20 07:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:34:02 --> Model Class Initialized
DEBUG - 2022-06-20 07:34:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:34:02 --> Model Class Initialized
INFO - 2022-06-20 07:34:02 --> Controller Class Initialized
DEBUG - 2022-06-20 07:34:02 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 07:34:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Science' at line 3 - Invalid query: SELECT *
FROM `interest`
WHERE Data Science
INFO - 2022-06-20 07:34:03 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-20 07:34:46 --> Config Class Initialized
INFO - 2022-06-20 07:34:46 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:34:46 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:34:46 --> Utf8 Class Initialized
INFO - 2022-06-20 07:34:46 --> URI Class Initialized
INFO - 2022-06-20 07:34:46 --> Router Class Initialized
INFO - 2022-06-20 07:34:46 --> Output Class Initialized
INFO - 2022-06-20 07:34:46 --> Security Class Initialized
DEBUG - 2022-06-20 07:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:34:46 --> Input Class Initialized
INFO - 2022-06-20 07:34:46 --> Language Class Initialized
INFO - 2022-06-20 07:34:46 --> Language Class Initialized
INFO - 2022-06-20 07:34:46 --> Config Class Initialized
INFO - 2022-06-20 07:34:46 --> Loader Class Initialized
INFO - 2022-06-20 07:34:46 --> Helper loaded: url_helper
INFO - 2022-06-20 07:34:46 --> Database Driver Class Initialized
INFO - 2022-06-20 07:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:34:46 --> Model Class Initialized
DEBUG - 2022-06-20 07:34:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:34:46 --> Model Class Initialized
INFO - 2022-06-20 07:34:46 --> Controller Class Initialized
DEBUG - 2022-06-20 07:34:46 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:35:19 --> Config Class Initialized
INFO - 2022-06-20 07:35:19 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:35:19 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:35:19 --> Utf8 Class Initialized
INFO - 2022-06-20 07:35:19 --> URI Class Initialized
INFO - 2022-06-20 07:35:19 --> Router Class Initialized
INFO - 2022-06-20 07:35:19 --> Output Class Initialized
INFO - 2022-06-20 07:35:19 --> Security Class Initialized
DEBUG - 2022-06-20 07:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:35:19 --> Input Class Initialized
INFO - 2022-06-20 07:35:19 --> Language Class Initialized
INFO - 2022-06-20 07:35:19 --> Language Class Initialized
INFO - 2022-06-20 07:35:19 --> Config Class Initialized
INFO - 2022-06-20 07:35:19 --> Loader Class Initialized
INFO - 2022-06-20 07:35:19 --> Helper loaded: url_helper
INFO - 2022-06-20 07:35:19 --> Database Driver Class Initialized
INFO - 2022-06-20 07:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:35:19 --> Model Class Initialized
DEBUG - 2022-06-20 07:35:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:35:19 --> Model Class Initialized
INFO - 2022-06-20 07:35:19 --> Controller Class Initialized
DEBUG - 2022-06-20 07:35:19 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:35:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:35:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:35:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:35:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:35:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:35:19 --> Final output sent to browser
DEBUG - 2022-06-20 07:35:19 --> Total execution time: 0.0353
INFO - 2022-06-20 07:36:06 --> Config Class Initialized
INFO - 2022-06-20 07:36:06 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:36:06 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:36:06 --> Utf8 Class Initialized
INFO - 2022-06-20 07:36:06 --> URI Class Initialized
INFO - 2022-06-20 07:36:06 --> Router Class Initialized
INFO - 2022-06-20 07:36:06 --> Output Class Initialized
INFO - 2022-06-20 07:36:06 --> Security Class Initialized
DEBUG - 2022-06-20 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:36:06 --> Input Class Initialized
INFO - 2022-06-20 07:36:06 --> Language Class Initialized
INFO - 2022-06-20 07:36:06 --> Language Class Initialized
INFO - 2022-06-20 07:36:06 --> Config Class Initialized
INFO - 2022-06-20 07:36:06 --> Loader Class Initialized
INFO - 2022-06-20 07:36:06 --> Helper loaded: url_helper
INFO - 2022-06-20 07:36:06 --> Database Driver Class Initialized
INFO - 2022-06-20 07:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:36:06 --> Model Class Initialized
DEBUG - 2022-06-20 07:36:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:36:06 --> Model Class Initialized
INFO - 2022-06-20 07:36:06 --> Controller Class Initialized
DEBUG - 2022-06-20 07:36:06 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:36:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:36:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:36:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:36:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_city.php
DEBUG - 2022-06-20 07:36:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:36:06 --> Final output sent to browser
DEBUG - 2022-06-20 07:36:06 --> Total execution time: 0.0353
INFO - 2022-06-20 07:36:21 --> Config Class Initialized
INFO - 2022-06-20 07:36:21 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:36:21 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:36:21 --> Utf8 Class Initialized
INFO - 2022-06-20 07:36:21 --> URI Class Initialized
INFO - 2022-06-20 07:36:21 --> Router Class Initialized
INFO - 2022-06-20 07:36:21 --> Output Class Initialized
INFO - 2022-06-20 07:36:21 --> Security Class Initialized
DEBUG - 2022-06-20 07:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:36:21 --> Input Class Initialized
INFO - 2022-06-20 07:36:21 --> Language Class Initialized
INFO - 2022-06-20 07:36:21 --> Language Class Initialized
INFO - 2022-06-20 07:36:21 --> Config Class Initialized
INFO - 2022-06-20 07:36:21 --> Loader Class Initialized
INFO - 2022-06-20 07:36:21 --> Helper loaded: url_helper
INFO - 2022-06-20 07:36:21 --> Database Driver Class Initialized
INFO - 2022-06-20 07:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:36:21 --> Model Class Initialized
DEBUG - 2022-06-20 07:36:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:36:21 --> Model Class Initialized
INFO - 2022-06-20 07:36:21 --> Controller Class Initialized
DEBUG - 2022-06-20 07:36:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:36:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:36:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:36:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:36:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:36:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:36:21 --> Final output sent to browser
DEBUG - 2022-06-20 07:36:21 --> Total execution time: 0.0354
INFO - 2022-06-20 07:36:37 --> Config Class Initialized
INFO - 2022-06-20 07:36:37 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:36:37 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:36:37 --> Utf8 Class Initialized
INFO - 2022-06-20 07:36:37 --> URI Class Initialized
INFO - 2022-06-20 07:36:37 --> Router Class Initialized
INFO - 2022-06-20 07:36:37 --> Output Class Initialized
INFO - 2022-06-20 07:36:37 --> Security Class Initialized
DEBUG - 2022-06-20 07:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:36:37 --> Input Class Initialized
INFO - 2022-06-20 07:36:37 --> Language Class Initialized
INFO - 2022-06-20 07:36:37 --> Language Class Initialized
INFO - 2022-06-20 07:36:37 --> Config Class Initialized
INFO - 2022-06-20 07:36:37 --> Loader Class Initialized
INFO - 2022-06-20 07:36:37 --> Helper loaded: url_helper
INFO - 2022-06-20 07:36:37 --> Database Driver Class Initialized
INFO - 2022-06-20 07:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:36:37 --> Model Class Initialized
DEBUG - 2022-06-20 07:36:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:36:37 --> Model Class Initialized
INFO - 2022-06-20 07:36:37 --> Controller Class Initialized
DEBUG - 2022-06-20 07:36:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:36:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:36:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:36:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:36:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:36:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:36:37 --> Final output sent to browser
DEBUG - 2022-06-20 07:36:37 --> Total execution time: 0.0303
INFO - 2022-06-20 07:36:54 --> Config Class Initialized
INFO - 2022-06-20 07:36:54 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:36:54 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:36:54 --> Utf8 Class Initialized
INFO - 2022-06-20 07:36:54 --> URI Class Initialized
INFO - 2022-06-20 07:36:54 --> Router Class Initialized
INFO - 2022-06-20 07:36:54 --> Output Class Initialized
INFO - 2022-06-20 07:36:54 --> Security Class Initialized
DEBUG - 2022-06-20 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:36:54 --> Input Class Initialized
INFO - 2022-06-20 07:36:54 --> Language Class Initialized
INFO - 2022-06-20 07:36:54 --> Language Class Initialized
INFO - 2022-06-20 07:36:54 --> Config Class Initialized
INFO - 2022-06-20 07:36:54 --> Loader Class Initialized
INFO - 2022-06-20 07:36:54 --> Helper loaded: url_helper
INFO - 2022-06-20 07:36:54 --> Database Driver Class Initialized
INFO - 2022-06-20 07:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:36:54 --> Model Class Initialized
DEBUG - 2022-06-20 07:36:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:36:54 --> Model Class Initialized
INFO - 2022-06-20 07:36:54 --> Controller Class Initialized
DEBUG - 2022-06-20 07:36:54 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:36:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:36:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:36:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:36:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:36:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:36:54 --> Final output sent to browser
DEBUG - 2022-06-20 07:36:54 --> Total execution time: 0.0383
INFO - 2022-06-20 07:37:04 --> Config Class Initialized
INFO - 2022-06-20 07:37:04 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:37:04 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:37:04 --> Utf8 Class Initialized
INFO - 2022-06-20 07:37:04 --> URI Class Initialized
INFO - 2022-06-20 07:37:04 --> Router Class Initialized
INFO - 2022-06-20 07:37:04 --> Output Class Initialized
INFO - 2022-06-20 07:37:04 --> Security Class Initialized
DEBUG - 2022-06-20 07:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:37:04 --> Input Class Initialized
INFO - 2022-06-20 07:37:04 --> Language Class Initialized
INFO - 2022-06-20 07:37:04 --> Language Class Initialized
INFO - 2022-06-20 07:37:04 --> Config Class Initialized
INFO - 2022-06-20 07:37:04 --> Loader Class Initialized
INFO - 2022-06-20 07:37:04 --> Helper loaded: url_helper
INFO - 2022-06-20 07:37:04 --> Database Driver Class Initialized
INFO - 2022-06-20 07:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:37:04 --> Model Class Initialized
DEBUG - 2022-06-20 07:37:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:37:04 --> Model Class Initialized
INFO - 2022-06-20 07:37:04 --> Controller Class Initialized
DEBUG - 2022-06-20 07:37:04 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:37:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:37:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:37:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:37:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:37:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:37:04 --> Final output sent to browser
DEBUG - 2022-06-20 07:37:04 --> Total execution time: 0.0364
INFO - 2022-06-20 07:37:14 --> Config Class Initialized
INFO - 2022-06-20 07:37:14 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:37:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:37:14 --> Utf8 Class Initialized
INFO - 2022-06-20 07:37:14 --> URI Class Initialized
INFO - 2022-06-20 07:37:14 --> Router Class Initialized
INFO - 2022-06-20 07:37:14 --> Output Class Initialized
INFO - 2022-06-20 07:37:14 --> Security Class Initialized
DEBUG - 2022-06-20 07:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:37:14 --> Input Class Initialized
INFO - 2022-06-20 07:37:14 --> Language Class Initialized
INFO - 2022-06-20 07:37:14 --> Language Class Initialized
INFO - 2022-06-20 07:37:14 --> Config Class Initialized
INFO - 2022-06-20 07:37:14 --> Loader Class Initialized
INFO - 2022-06-20 07:37:14 --> Helper loaded: url_helper
INFO - 2022-06-20 07:37:14 --> Database Driver Class Initialized
INFO - 2022-06-20 07:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:37:14 --> Model Class Initialized
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:37:14 --> Model Class Initialized
INFO - 2022-06-20 07:37:14 --> Controller Class Initialized
DEBUG - 2022-06-20 07:37:14 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:37:14 --> Upload Class Initialized
INFO - 2022-06-20 07:37:14 --> Config Class Initialized
INFO - 2022-06-20 07:37:14 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:37:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:37:14 --> Utf8 Class Initialized
INFO - 2022-06-20 07:37:14 --> URI Class Initialized
INFO - 2022-06-20 07:37:14 --> Router Class Initialized
INFO - 2022-06-20 07:37:14 --> Output Class Initialized
INFO - 2022-06-20 07:37:14 --> Security Class Initialized
DEBUG - 2022-06-20 07:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:37:14 --> Input Class Initialized
INFO - 2022-06-20 07:37:14 --> Language Class Initialized
INFO - 2022-06-20 07:37:14 --> Language Class Initialized
INFO - 2022-06-20 07:37:14 --> Config Class Initialized
INFO - 2022-06-20 07:37:14 --> Loader Class Initialized
INFO - 2022-06-20 07:37:14 --> Helper loaded: url_helper
INFO - 2022-06-20 07:37:14 --> Database Driver Class Initialized
INFO - 2022-06-20 07:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:37:14 --> Model Class Initialized
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:37:14 --> Model Class Initialized
INFO - 2022-06-20 07:37:14 --> Controller Class Initialized
DEBUG - 2022-06-20 07:37:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:37:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:37:14 --> Final output sent to browser
DEBUG - 2022-06-20 07:37:14 --> Total execution time: 0.0297
INFO - 2022-06-20 07:37:53 --> Config Class Initialized
INFO - 2022-06-20 07:37:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:37:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:37:53 --> Utf8 Class Initialized
INFO - 2022-06-20 07:37:53 --> URI Class Initialized
INFO - 2022-06-20 07:37:53 --> Router Class Initialized
INFO - 2022-06-20 07:37:53 --> Output Class Initialized
INFO - 2022-06-20 07:37:53 --> Security Class Initialized
DEBUG - 2022-06-20 07:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:37:53 --> Input Class Initialized
INFO - 2022-06-20 07:37:53 --> Language Class Initialized
INFO - 2022-06-20 07:37:53 --> Language Class Initialized
INFO - 2022-06-20 07:37:53 --> Config Class Initialized
INFO - 2022-06-20 07:37:53 --> Loader Class Initialized
INFO - 2022-06-20 07:37:53 --> Helper loaded: url_helper
INFO - 2022-06-20 07:37:53 --> Database Driver Class Initialized
INFO - 2022-06-20 07:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:37:53 --> Model Class Initialized
DEBUG - 2022-06-20 07:37:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:37:53 --> Model Class Initialized
INFO - 2022-06-20 07:37:53 --> Controller Class Initialized
DEBUG - 2022-06-20 07:37:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:37:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:37:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:37:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:37:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 07:37:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:37:53 --> Final output sent to browser
DEBUG - 2022-06-20 07:37:53 --> Total execution time: 0.0365
INFO - 2022-06-20 07:37:55 --> Config Class Initialized
INFO - 2022-06-20 07:37:55 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:37:55 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:37:55 --> Utf8 Class Initialized
INFO - 2022-06-20 07:37:55 --> URI Class Initialized
INFO - 2022-06-20 07:37:55 --> Router Class Initialized
INFO - 2022-06-20 07:37:55 --> Output Class Initialized
INFO - 2022-06-20 07:37:55 --> Security Class Initialized
DEBUG - 2022-06-20 07:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:37:55 --> Input Class Initialized
INFO - 2022-06-20 07:37:55 --> Language Class Initialized
INFO - 2022-06-20 07:37:55 --> Language Class Initialized
INFO - 2022-06-20 07:37:55 --> Config Class Initialized
INFO - 2022-06-20 07:37:55 --> Loader Class Initialized
INFO - 2022-06-20 07:37:55 --> Helper loaded: url_helper
INFO - 2022-06-20 07:37:55 --> Database Driver Class Initialized
INFO - 2022-06-20 07:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:37:55 --> Model Class Initialized
DEBUG - 2022-06-20 07:37:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:37:55 --> Model Class Initialized
INFO - 2022-06-20 07:37:55 --> Controller Class Initialized
DEBUG - 2022-06-20 07:37:55 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:37:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:37:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:37:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:37:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_category.php
DEBUG - 2022-06-20 07:37:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:37:56 --> Final output sent to browser
DEBUG - 2022-06-20 07:37:56 --> Total execution time: 0.7507
INFO - 2022-06-20 07:40:15 --> Config Class Initialized
INFO - 2022-06-20 07:40:15 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:40:15 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:40:15 --> Utf8 Class Initialized
INFO - 2022-06-20 07:40:15 --> URI Class Initialized
INFO - 2022-06-20 07:40:15 --> Router Class Initialized
INFO - 2022-06-20 07:40:15 --> Output Class Initialized
INFO - 2022-06-20 07:40:15 --> Security Class Initialized
DEBUG - 2022-06-20 07:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:40:15 --> Input Class Initialized
INFO - 2022-06-20 07:40:15 --> Language Class Initialized
INFO - 2022-06-20 07:40:15 --> Language Class Initialized
INFO - 2022-06-20 07:40:15 --> Config Class Initialized
INFO - 2022-06-20 07:40:15 --> Loader Class Initialized
INFO - 2022-06-20 07:40:15 --> Helper loaded: url_helper
INFO - 2022-06-20 07:40:15 --> Database Driver Class Initialized
INFO - 2022-06-20 07:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:40:15 --> Model Class Initialized
DEBUG - 2022-06-20 07:40:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:40:15 --> Model Class Initialized
INFO - 2022-06-20 07:40:15 --> Controller Class Initialized
DEBUG - 2022-06-20 07:40:15 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:40:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:40:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:40:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:40:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_category.php
DEBUG - 2022-06-20 07:40:15 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:40:15 --> Final output sent to browser
DEBUG - 2022-06-20 07:40:15 --> Total execution time: 0.0402
INFO - 2022-06-20 07:40:38 --> Config Class Initialized
INFO - 2022-06-20 07:40:38 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:40:38 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:40:38 --> Utf8 Class Initialized
INFO - 2022-06-20 07:40:38 --> URI Class Initialized
INFO - 2022-06-20 07:40:38 --> Router Class Initialized
INFO - 2022-06-20 07:40:39 --> Output Class Initialized
INFO - 2022-06-20 07:40:39 --> Security Class Initialized
DEBUG - 2022-06-20 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:40:39 --> Input Class Initialized
INFO - 2022-06-20 07:40:39 --> Language Class Initialized
INFO - 2022-06-20 07:40:39 --> Language Class Initialized
INFO - 2022-06-20 07:40:39 --> Config Class Initialized
INFO - 2022-06-20 07:40:39 --> Loader Class Initialized
INFO - 2022-06-20 07:40:39 --> Helper loaded: url_helper
INFO - 2022-06-20 07:40:39 --> Database Driver Class Initialized
INFO - 2022-06-20 07:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:40:39 --> Model Class Initialized
DEBUG - 2022-06-20 07:40:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:40:39 --> Model Class Initialized
INFO - 2022-06-20 07:40:39 --> Controller Class Initialized
DEBUG - 2022-06-20 07:40:39 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:40:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:40:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:40:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:40:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_category.php
DEBUG - 2022-06-20 07:40:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:40:39 --> Final output sent to browser
DEBUG - 2022-06-20 07:40:39 --> Total execution time: 0.1123
INFO - 2022-06-20 07:41:00 --> Config Class Initialized
INFO - 2022-06-20 07:41:00 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:41:00 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:41:00 --> Utf8 Class Initialized
INFO - 2022-06-20 07:41:00 --> URI Class Initialized
INFO - 2022-06-20 07:41:00 --> Router Class Initialized
INFO - 2022-06-20 07:41:00 --> Output Class Initialized
INFO - 2022-06-20 07:41:00 --> Security Class Initialized
DEBUG - 2022-06-20 07:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:41:00 --> Input Class Initialized
INFO - 2022-06-20 07:41:00 --> Language Class Initialized
INFO - 2022-06-20 07:41:00 --> Language Class Initialized
INFO - 2022-06-20 07:41:00 --> Config Class Initialized
INFO - 2022-06-20 07:41:00 --> Loader Class Initialized
INFO - 2022-06-20 07:41:00 --> Helper loaded: url_helper
INFO - 2022-06-20 07:41:00 --> Database Driver Class Initialized
INFO - 2022-06-20 07:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:41:00 --> Model Class Initialized
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:41:00 --> Model Class Initialized
INFO - 2022-06-20 07:41:00 --> Controller Class Initialized
DEBUG - 2022-06-20 07:41:00 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:41:00 --> Upload Class Initialized
INFO - 2022-06-20 07:41:00 --> Config Class Initialized
INFO - 2022-06-20 07:41:00 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:41:00 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:41:00 --> Utf8 Class Initialized
INFO - 2022-06-20 07:41:00 --> URI Class Initialized
INFO - 2022-06-20 07:41:00 --> Router Class Initialized
INFO - 2022-06-20 07:41:00 --> Output Class Initialized
INFO - 2022-06-20 07:41:00 --> Security Class Initialized
DEBUG - 2022-06-20 07:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:41:00 --> Input Class Initialized
INFO - 2022-06-20 07:41:00 --> Language Class Initialized
INFO - 2022-06-20 07:41:00 --> Language Class Initialized
INFO - 2022-06-20 07:41:00 --> Config Class Initialized
INFO - 2022-06-20 07:41:00 --> Loader Class Initialized
INFO - 2022-06-20 07:41:00 --> Helper loaded: url_helper
INFO - 2022-06-20 07:41:00 --> Database Driver Class Initialized
INFO - 2022-06-20 07:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:41:00 --> Model Class Initialized
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:41:00 --> Model Class Initialized
INFO - 2022-06-20 07:41:00 --> Controller Class Initialized
DEBUG - 2022-06-20 07:41:00 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_category.php
DEBUG - 2022-06-20 07:41:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:41:00 --> Final output sent to browser
DEBUG - 2022-06-20 07:41:00 --> Total execution time: 0.0810
INFO - 2022-06-20 07:41:20 --> Config Class Initialized
INFO - 2022-06-20 07:41:20 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:41:20 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:41:20 --> Utf8 Class Initialized
INFO - 2022-06-20 07:41:20 --> URI Class Initialized
INFO - 2022-06-20 07:41:20 --> Router Class Initialized
INFO - 2022-06-20 07:41:20 --> Output Class Initialized
INFO - 2022-06-20 07:41:20 --> Security Class Initialized
DEBUG - 2022-06-20 07:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:41:20 --> Input Class Initialized
INFO - 2022-06-20 07:41:20 --> Language Class Initialized
INFO - 2022-06-20 07:41:20 --> Language Class Initialized
INFO - 2022-06-20 07:41:20 --> Config Class Initialized
INFO - 2022-06-20 07:41:20 --> Loader Class Initialized
INFO - 2022-06-20 07:41:20 --> Helper loaded: url_helper
INFO - 2022-06-20 07:41:20 --> Database Driver Class Initialized
INFO - 2022-06-20 07:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:41:20 --> Model Class Initialized
DEBUG - 2022-06-20 07:41:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:41:20 --> Model Class Initialized
INFO - 2022-06-20 07:41:20 --> Controller Class Initialized
DEBUG - 2022-06-20 07:41:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:41:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:41:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:41:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:41:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:41:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:41:20 --> Final output sent to browser
DEBUG - 2022-06-20 07:41:20 --> Total execution time: 0.0823
INFO - 2022-06-20 07:43:39 --> Config Class Initialized
INFO - 2022-06-20 07:43:39 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:43:39 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:43:39 --> Utf8 Class Initialized
INFO - 2022-06-20 07:43:39 --> URI Class Initialized
INFO - 2022-06-20 07:43:39 --> Router Class Initialized
INFO - 2022-06-20 07:43:39 --> Output Class Initialized
INFO - 2022-06-20 07:43:39 --> Security Class Initialized
DEBUG - 2022-06-20 07:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:43:39 --> Input Class Initialized
INFO - 2022-06-20 07:43:39 --> Language Class Initialized
INFO - 2022-06-20 07:43:39 --> Language Class Initialized
INFO - 2022-06-20 07:43:39 --> Config Class Initialized
INFO - 2022-06-20 07:43:39 --> Loader Class Initialized
INFO - 2022-06-20 07:43:39 --> Helper loaded: url_helper
INFO - 2022-06-20 07:43:39 --> Database Driver Class Initialized
INFO - 2022-06-20 07:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:43:39 --> Model Class Initialized
DEBUG - 2022-06-20 07:43:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:43:39 --> Model Class Initialized
INFO - 2022-06-20 07:43:39 --> Controller Class Initialized
DEBUG - 2022-06-20 07:43:39 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:43:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:43:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:43:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:43:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:43:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:43:39 --> Final output sent to browser
DEBUG - 2022-06-20 07:43:39 --> Total execution time: 0.1311
INFO - 2022-06-20 07:43:41 --> Config Class Initialized
INFO - 2022-06-20 07:43:41 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:43:41 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:43:41 --> Utf8 Class Initialized
INFO - 2022-06-20 07:43:41 --> URI Class Initialized
INFO - 2022-06-20 07:43:41 --> Router Class Initialized
INFO - 2022-06-20 07:43:41 --> Output Class Initialized
INFO - 2022-06-20 07:43:41 --> Security Class Initialized
DEBUG - 2022-06-20 07:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:43:41 --> Input Class Initialized
INFO - 2022-06-20 07:43:41 --> Language Class Initialized
INFO - 2022-06-20 07:43:41 --> Language Class Initialized
INFO - 2022-06-20 07:43:41 --> Config Class Initialized
INFO - 2022-06-20 07:43:41 --> Loader Class Initialized
INFO - 2022-06-20 07:43:41 --> Helper loaded: url_helper
INFO - 2022-06-20 07:43:41 --> Database Driver Class Initialized
INFO - 2022-06-20 07:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:43:41 --> Model Class Initialized
DEBUG - 2022-06-20 07:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:43:41 --> Model Class Initialized
INFO - 2022-06-20 07:43:41 --> Controller Class Initialized
DEBUG - 2022-06-20 07:43:41 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:43:41 --> Final output sent to browser
DEBUG - 2022-06-20 07:43:41 --> Total execution time: 0.0760
INFO - 2022-06-20 07:43:47 --> Config Class Initialized
INFO - 2022-06-20 07:43:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:43:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:43:47 --> Utf8 Class Initialized
INFO - 2022-06-20 07:43:47 --> URI Class Initialized
INFO - 2022-06-20 07:43:47 --> Router Class Initialized
INFO - 2022-06-20 07:43:47 --> Output Class Initialized
INFO - 2022-06-20 07:43:47 --> Security Class Initialized
DEBUG - 2022-06-20 07:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:43:47 --> Input Class Initialized
INFO - 2022-06-20 07:43:47 --> Language Class Initialized
INFO - 2022-06-20 07:43:48 --> Language Class Initialized
INFO - 2022-06-20 07:43:48 --> Config Class Initialized
INFO - 2022-06-20 07:43:48 --> Loader Class Initialized
INFO - 2022-06-20 07:43:48 --> Helper loaded: url_helper
INFO - 2022-06-20 07:43:48 --> Database Driver Class Initialized
INFO - 2022-06-20 07:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:43:48 --> Model Class Initialized
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:43:48 --> Model Class Initialized
INFO - 2022-06-20 07:43:48 --> Controller Class Initialized
DEBUG - 2022-06-20 07:43:48 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:43:48 --> Config Class Initialized
INFO - 2022-06-20 07:43:48 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:43:48 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:43:48 --> Utf8 Class Initialized
INFO - 2022-06-20 07:43:48 --> URI Class Initialized
INFO - 2022-06-20 07:43:48 --> Router Class Initialized
INFO - 2022-06-20 07:43:48 --> Output Class Initialized
INFO - 2022-06-20 07:43:48 --> Security Class Initialized
DEBUG - 2022-06-20 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:43:48 --> Input Class Initialized
INFO - 2022-06-20 07:43:48 --> Language Class Initialized
INFO - 2022-06-20 07:43:48 --> Language Class Initialized
INFO - 2022-06-20 07:43:48 --> Config Class Initialized
INFO - 2022-06-20 07:43:48 --> Loader Class Initialized
INFO - 2022-06-20 07:43:48 --> Helper loaded: url_helper
INFO - 2022-06-20 07:43:48 --> Database Driver Class Initialized
INFO - 2022-06-20 07:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:43:48 --> Model Class Initialized
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:43:48 --> Model Class Initialized
INFO - 2022-06-20 07:43:48 --> Controller Class Initialized
DEBUG - 2022-06-20 07:43:48 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:43:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:43:48 --> Final output sent to browser
DEBUG - 2022-06-20 07:43:48 --> Total execution time: 0.0825
INFO - 2022-06-20 07:44:17 --> Config Class Initialized
INFO - 2022-06-20 07:44:17 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:44:17 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:44:17 --> Utf8 Class Initialized
INFO - 2022-06-20 07:44:17 --> URI Class Initialized
INFO - 2022-06-20 07:44:17 --> Router Class Initialized
INFO - 2022-06-20 07:44:17 --> Output Class Initialized
INFO - 2022-06-20 07:44:17 --> Security Class Initialized
DEBUG - 2022-06-20 07:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:44:17 --> Input Class Initialized
INFO - 2022-06-20 07:44:17 --> Language Class Initialized
INFO - 2022-06-20 07:44:17 --> Language Class Initialized
INFO - 2022-06-20 07:44:17 --> Config Class Initialized
INFO - 2022-06-20 07:44:17 --> Loader Class Initialized
INFO - 2022-06-20 07:44:17 --> Helper loaded: url_helper
INFO - 2022-06-20 07:44:17 --> Database Driver Class Initialized
INFO - 2022-06-20 07:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:44:17 --> Model Class Initialized
DEBUG - 2022-06-20 07:44:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:44:17 --> Model Class Initialized
INFO - 2022-06-20 07:44:17 --> Controller Class Initialized
DEBUG - 2022-06-20 07:44:17 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:44:17 --> Final output sent to browser
DEBUG - 2022-06-20 07:44:17 --> Total execution time: 0.0707
INFO - 2022-06-20 07:44:22 --> Config Class Initialized
INFO - 2022-06-20 07:44:22 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:44:22 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:44:22 --> Utf8 Class Initialized
INFO - 2022-06-20 07:44:22 --> URI Class Initialized
INFO - 2022-06-20 07:44:22 --> Router Class Initialized
INFO - 2022-06-20 07:44:22 --> Output Class Initialized
INFO - 2022-06-20 07:44:22 --> Security Class Initialized
DEBUG - 2022-06-20 07:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:44:22 --> Input Class Initialized
INFO - 2022-06-20 07:44:22 --> Language Class Initialized
INFO - 2022-06-20 07:44:22 --> Language Class Initialized
INFO - 2022-06-20 07:44:22 --> Config Class Initialized
INFO - 2022-06-20 07:44:22 --> Loader Class Initialized
INFO - 2022-06-20 07:44:22 --> Helper loaded: url_helper
INFO - 2022-06-20 07:44:22 --> Database Driver Class Initialized
INFO - 2022-06-20 07:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:44:22 --> Model Class Initialized
DEBUG - 2022-06-20 07:44:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:44:22 --> Model Class Initialized
INFO - 2022-06-20 07:44:22 --> Controller Class Initialized
DEBUG - 2022-06-20 07:44:22 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:44:23 --> Config Class Initialized
INFO - 2022-06-20 07:44:23 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:44:23 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:44:23 --> Utf8 Class Initialized
INFO - 2022-06-20 07:44:23 --> URI Class Initialized
INFO - 2022-06-20 07:44:23 --> Router Class Initialized
INFO - 2022-06-20 07:44:23 --> Output Class Initialized
INFO - 2022-06-20 07:44:23 --> Security Class Initialized
DEBUG - 2022-06-20 07:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:44:23 --> Input Class Initialized
INFO - 2022-06-20 07:44:23 --> Language Class Initialized
INFO - 2022-06-20 07:44:23 --> Language Class Initialized
INFO - 2022-06-20 07:44:23 --> Config Class Initialized
INFO - 2022-06-20 07:44:23 --> Loader Class Initialized
INFO - 2022-06-20 07:44:23 --> Helper loaded: url_helper
INFO - 2022-06-20 07:44:23 --> Database Driver Class Initialized
INFO - 2022-06-20 07:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:44:23 --> Model Class Initialized
DEBUG - 2022-06-20 07:44:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:44:23 --> Model Class Initialized
INFO - 2022-06-20 07:44:23 --> Controller Class Initialized
DEBUG - 2022-06-20 07:44:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:44:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:44:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:44:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:44:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:44:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:44:23 --> Final output sent to browser
DEBUG - 2022-06-20 07:44:23 --> Total execution time: 0.0977
INFO - 2022-06-20 07:44:46 --> Config Class Initialized
INFO - 2022-06-20 07:44:46 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:44:46 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:44:46 --> Utf8 Class Initialized
INFO - 2022-06-20 07:44:46 --> URI Class Initialized
INFO - 2022-06-20 07:44:46 --> Router Class Initialized
INFO - 2022-06-20 07:44:46 --> Output Class Initialized
INFO - 2022-06-20 07:44:46 --> Security Class Initialized
DEBUG - 2022-06-20 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:44:46 --> Input Class Initialized
INFO - 2022-06-20 07:44:46 --> Language Class Initialized
INFO - 2022-06-20 07:44:46 --> Language Class Initialized
INFO - 2022-06-20 07:44:46 --> Config Class Initialized
INFO - 2022-06-20 07:44:46 --> Loader Class Initialized
INFO - 2022-06-20 07:44:46 --> Helper loaded: url_helper
INFO - 2022-06-20 07:44:46 --> Database Driver Class Initialized
INFO - 2022-06-20 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:44:46 --> Model Class Initialized
DEBUG - 2022-06-20 07:44:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:44:46 --> Model Class Initialized
INFO - 2022-06-20 07:44:46 --> Controller Class Initialized
DEBUG - 2022-06-20 07:44:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:44:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:44:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:44:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:44:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:44:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:44:46 --> Final output sent to browser
DEBUG - 2022-06-20 07:44:46 --> Total execution time: 0.0885
INFO - 2022-06-20 07:44:48 --> Config Class Initialized
INFO - 2022-06-20 07:44:48 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:44:48 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:44:48 --> Utf8 Class Initialized
INFO - 2022-06-20 07:44:48 --> URI Class Initialized
INFO - 2022-06-20 07:44:48 --> Router Class Initialized
INFO - 2022-06-20 07:44:48 --> Output Class Initialized
INFO - 2022-06-20 07:44:48 --> Security Class Initialized
DEBUG - 2022-06-20 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:44:48 --> Input Class Initialized
INFO - 2022-06-20 07:44:48 --> Language Class Initialized
INFO - 2022-06-20 07:44:48 --> Language Class Initialized
INFO - 2022-06-20 07:44:48 --> Config Class Initialized
INFO - 2022-06-20 07:44:48 --> Loader Class Initialized
INFO - 2022-06-20 07:44:48 --> Helper loaded: url_helper
INFO - 2022-06-20 07:44:48 --> Database Driver Class Initialized
INFO - 2022-06-20 07:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:44:48 --> Model Class Initialized
DEBUG - 2022-06-20 07:44:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:44:48 --> Model Class Initialized
INFO - 2022-06-20 07:44:48 --> Controller Class Initialized
DEBUG - 2022-06-20 07:44:48 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:44:48 --> Final output sent to browser
DEBUG - 2022-06-20 07:44:48 --> Total execution time: 0.0796
INFO - 2022-06-20 07:44:51 --> Config Class Initialized
INFO - 2022-06-20 07:44:51 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:44:51 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:44:51 --> Utf8 Class Initialized
INFO - 2022-06-20 07:44:51 --> URI Class Initialized
INFO - 2022-06-20 07:44:51 --> Router Class Initialized
INFO - 2022-06-20 07:44:51 --> Output Class Initialized
INFO - 2022-06-20 07:44:51 --> Security Class Initialized
DEBUG - 2022-06-20 07:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:44:51 --> Input Class Initialized
INFO - 2022-06-20 07:44:51 --> Language Class Initialized
INFO - 2022-06-20 07:44:51 --> Language Class Initialized
INFO - 2022-06-20 07:44:51 --> Config Class Initialized
INFO - 2022-06-20 07:44:51 --> Loader Class Initialized
INFO - 2022-06-20 07:44:51 --> Helper loaded: url_helper
INFO - 2022-06-20 07:44:51 --> Database Driver Class Initialized
INFO - 2022-06-20 07:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:44:51 --> Model Class Initialized
DEBUG - 2022-06-20 07:44:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:44:51 --> Model Class Initialized
INFO - 2022-06-20 07:44:51 --> Controller Class Initialized
DEBUG - 2022-06-20 07:44:51 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:45:29 --> Config Class Initialized
INFO - 2022-06-20 07:45:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:45:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:45:29 --> Utf8 Class Initialized
INFO - 2022-06-20 07:45:29 --> URI Class Initialized
INFO - 2022-06-20 07:45:29 --> Router Class Initialized
INFO - 2022-06-20 07:45:29 --> Output Class Initialized
INFO - 2022-06-20 07:45:29 --> Security Class Initialized
DEBUG - 2022-06-20 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:45:29 --> Input Class Initialized
INFO - 2022-06-20 07:45:29 --> Language Class Initialized
INFO - 2022-06-20 07:45:29 --> Language Class Initialized
INFO - 2022-06-20 07:45:29 --> Config Class Initialized
INFO - 2022-06-20 07:45:29 --> Loader Class Initialized
INFO - 2022-06-20 07:45:29 --> Helper loaded: url_helper
INFO - 2022-06-20 07:45:29 --> Database Driver Class Initialized
INFO - 2022-06-20 07:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:45:29 --> Model Class Initialized
DEBUG - 2022-06-20 07:45:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:45:29 --> Model Class Initialized
INFO - 2022-06-20 07:45:29 --> Controller Class Initialized
DEBUG - 2022-06-20 07:45:29 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:45:47 --> Config Class Initialized
INFO - 2022-06-20 07:45:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:45:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:45:47 --> Utf8 Class Initialized
INFO - 2022-06-20 07:45:47 --> URI Class Initialized
INFO - 2022-06-20 07:45:47 --> Router Class Initialized
INFO - 2022-06-20 07:45:47 --> Output Class Initialized
INFO - 2022-06-20 07:45:47 --> Security Class Initialized
DEBUG - 2022-06-20 07:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:45:47 --> Input Class Initialized
INFO - 2022-06-20 07:45:47 --> Language Class Initialized
INFO - 2022-06-20 07:45:47 --> Language Class Initialized
INFO - 2022-06-20 07:45:47 --> Config Class Initialized
INFO - 2022-06-20 07:45:47 --> Loader Class Initialized
INFO - 2022-06-20 07:45:47 --> Helper loaded: url_helper
INFO - 2022-06-20 07:45:47 --> Database Driver Class Initialized
INFO - 2022-06-20 07:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:45:47 --> Model Class Initialized
DEBUG - 2022-06-20 07:45:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:45:47 --> Model Class Initialized
INFO - 2022-06-20 07:45:47 --> Controller Class Initialized
DEBUG - 2022-06-20 07:45:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:45:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:45:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:45:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:45:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:45:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:45:47 --> Final output sent to browser
DEBUG - 2022-06-20 07:45:47 --> Total execution time: 0.0634
INFO - 2022-06-20 07:45:49 --> Config Class Initialized
INFO - 2022-06-20 07:45:49 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:45:49 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:45:49 --> Utf8 Class Initialized
INFO - 2022-06-20 07:45:49 --> URI Class Initialized
INFO - 2022-06-20 07:45:49 --> Router Class Initialized
INFO - 2022-06-20 07:45:49 --> Output Class Initialized
INFO - 2022-06-20 07:45:49 --> Security Class Initialized
DEBUG - 2022-06-20 07:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:45:49 --> Input Class Initialized
INFO - 2022-06-20 07:45:49 --> Language Class Initialized
INFO - 2022-06-20 07:45:49 --> Language Class Initialized
INFO - 2022-06-20 07:45:49 --> Config Class Initialized
INFO - 2022-06-20 07:45:49 --> Loader Class Initialized
INFO - 2022-06-20 07:45:49 --> Helper loaded: url_helper
INFO - 2022-06-20 07:45:49 --> Database Driver Class Initialized
INFO - 2022-06-20 07:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:45:49 --> Model Class Initialized
DEBUG - 2022-06-20 07:45:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:45:49 --> Model Class Initialized
INFO - 2022-06-20 07:45:49 --> Controller Class Initialized
DEBUG - 2022-06-20 07:45:49 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:45:49 --> Final output sent to browser
DEBUG - 2022-06-20 07:45:49 --> Total execution time: 0.0672
INFO - 2022-06-20 07:45:54 --> Config Class Initialized
INFO - 2022-06-20 07:45:54 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:45:54 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:45:54 --> Utf8 Class Initialized
INFO - 2022-06-20 07:45:54 --> URI Class Initialized
INFO - 2022-06-20 07:45:54 --> Router Class Initialized
INFO - 2022-06-20 07:45:54 --> Output Class Initialized
INFO - 2022-06-20 07:45:54 --> Security Class Initialized
DEBUG - 2022-06-20 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:45:54 --> Input Class Initialized
INFO - 2022-06-20 07:45:54 --> Language Class Initialized
INFO - 2022-06-20 07:45:54 --> Language Class Initialized
INFO - 2022-06-20 07:45:54 --> Config Class Initialized
INFO - 2022-06-20 07:45:54 --> Loader Class Initialized
INFO - 2022-06-20 07:45:54 --> Helper loaded: url_helper
INFO - 2022-06-20 07:45:54 --> Database Driver Class Initialized
INFO - 2022-06-20 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:45:54 --> Model Class Initialized
DEBUG - 2022-06-20 07:45:54 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:45:54 --> Model Class Initialized
INFO - 2022-06-20 07:45:54 --> Controller Class Initialized
DEBUG - 2022-06-20 07:45:54 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:46:26 --> Config Class Initialized
INFO - 2022-06-20 07:46:26 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:46:26 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:46:26 --> Utf8 Class Initialized
INFO - 2022-06-20 07:46:26 --> URI Class Initialized
INFO - 2022-06-20 07:46:26 --> Router Class Initialized
INFO - 2022-06-20 07:46:26 --> Output Class Initialized
INFO - 2022-06-20 07:46:26 --> Security Class Initialized
DEBUG - 2022-06-20 07:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:46:26 --> Input Class Initialized
INFO - 2022-06-20 07:46:26 --> Language Class Initialized
INFO - 2022-06-20 07:46:26 --> Language Class Initialized
INFO - 2022-06-20 07:46:26 --> Config Class Initialized
INFO - 2022-06-20 07:46:26 --> Loader Class Initialized
INFO - 2022-06-20 07:46:26 --> Helper loaded: url_helper
INFO - 2022-06-20 07:46:26 --> Database Driver Class Initialized
INFO - 2022-06-20 07:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:46:26 --> Model Class Initialized
DEBUG - 2022-06-20 07:46:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:46:26 --> Model Class Initialized
INFO - 2022-06-20 07:46:26 --> Controller Class Initialized
DEBUG - 2022-06-20 07:46:26 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:47:17 --> Config Class Initialized
INFO - 2022-06-20 07:47:17 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:47:17 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:47:17 --> Utf8 Class Initialized
INFO - 2022-06-20 07:47:17 --> URI Class Initialized
INFO - 2022-06-20 07:47:17 --> Router Class Initialized
INFO - 2022-06-20 07:47:17 --> Output Class Initialized
INFO - 2022-06-20 07:47:17 --> Security Class Initialized
DEBUG - 2022-06-20 07:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:47:17 --> Input Class Initialized
INFO - 2022-06-20 07:47:17 --> Language Class Initialized
INFO - 2022-06-20 07:47:17 --> Language Class Initialized
INFO - 2022-06-20 07:47:17 --> Config Class Initialized
INFO - 2022-06-20 07:47:17 --> Loader Class Initialized
INFO - 2022-06-20 07:47:17 --> Helper loaded: url_helper
INFO - 2022-06-20 07:47:17 --> Database Driver Class Initialized
INFO - 2022-06-20 07:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:47:17 --> Model Class Initialized
DEBUG - 2022-06-20 07:47:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:47:17 --> Model Class Initialized
INFO - 2022-06-20 07:47:17 --> Controller Class Initialized
DEBUG - 2022-06-20 07:47:17 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:47:28 --> Config Class Initialized
INFO - 2022-06-20 07:47:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:47:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:47:28 --> Utf8 Class Initialized
INFO - 2022-06-20 07:47:28 --> URI Class Initialized
INFO - 2022-06-20 07:47:28 --> Router Class Initialized
INFO - 2022-06-20 07:47:28 --> Output Class Initialized
INFO - 2022-06-20 07:47:28 --> Security Class Initialized
DEBUG - 2022-06-20 07:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:47:28 --> Input Class Initialized
INFO - 2022-06-20 07:47:28 --> Language Class Initialized
INFO - 2022-06-20 07:47:28 --> Language Class Initialized
INFO - 2022-06-20 07:47:28 --> Config Class Initialized
INFO - 2022-06-20 07:47:28 --> Loader Class Initialized
INFO - 2022-06-20 07:47:28 --> Helper loaded: url_helper
INFO - 2022-06-20 07:47:28 --> Database Driver Class Initialized
INFO - 2022-06-20 07:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:47:28 --> Model Class Initialized
DEBUG - 2022-06-20 07:47:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:47:28 --> Model Class Initialized
INFO - 2022-06-20 07:47:28 --> Controller Class Initialized
DEBUG - 2022-06-20 07:47:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:47:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:47:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:47:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:47:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:47:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:47:28 --> Final output sent to browser
DEBUG - 2022-06-20 07:47:28 --> Total execution time: 0.0871
INFO - 2022-06-20 07:47:31 --> Config Class Initialized
INFO - 2022-06-20 07:47:31 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:47:31 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:47:31 --> Utf8 Class Initialized
INFO - 2022-06-20 07:47:31 --> URI Class Initialized
INFO - 2022-06-20 07:47:31 --> Router Class Initialized
INFO - 2022-06-20 07:47:31 --> Output Class Initialized
INFO - 2022-06-20 07:47:31 --> Security Class Initialized
DEBUG - 2022-06-20 07:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:47:31 --> Input Class Initialized
INFO - 2022-06-20 07:47:31 --> Language Class Initialized
INFO - 2022-06-20 07:47:31 --> Language Class Initialized
INFO - 2022-06-20 07:47:31 --> Config Class Initialized
INFO - 2022-06-20 07:47:31 --> Loader Class Initialized
INFO - 2022-06-20 07:47:31 --> Helper loaded: url_helper
INFO - 2022-06-20 07:47:31 --> Database Driver Class Initialized
INFO - 2022-06-20 07:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:47:31 --> Model Class Initialized
DEBUG - 2022-06-20 07:47:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:47:31 --> Model Class Initialized
INFO - 2022-06-20 07:47:31 --> Controller Class Initialized
DEBUG - 2022-06-20 07:47:31 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:47:31 --> Final output sent to browser
DEBUG - 2022-06-20 07:47:31 --> Total execution time: 0.0642
INFO - 2022-06-20 07:47:38 --> Config Class Initialized
INFO - 2022-06-20 07:47:38 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:47:38 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:47:38 --> Utf8 Class Initialized
INFO - 2022-06-20 07:47:38 --> URI Class Initialized
INFO - 2022-06-20 07:47:38 --> Router Class Initialized
INFO - 2022-06-20 07:47:38 --> Output Class Initialized
INFO - 2022-06-20 07:47:38 --> Security Class Initialized
DEBUG - 2022-06-20 07:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:47:38 --> Input Class Initialized
INFO - 2022-06-20 07:47:38 --> Language Class Initialized
INFO - 2022-06-20 07:47:38 --> Language Class Initialized
INFO - 2022-06-20 07:47:38 --> Config Class Initialized
INFO - 2022-06-20 07:47:38 --> Loader Class Initialized
INFO - 2022-06-20 07:47:38 --> Helper loaded: url_helper
INFO - 2022-06-20 07:47:38 --> Database Driver Class Initialized
INFO - 2022-06-20 07:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:47:38 --> Model Class Initialized
DEBUG - 2022-06-20 07:47:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:47:38 --> Model Class Initialized
INFO - 2022-06-20 07:47:38 --> Controller Class Initialized
DEBUG - 2022-06-20 07:47:38 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:47:47 --> Config Class Initialized
INFO - 2022-06-20 07:47:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:47:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:47:47 --> Utf8 Class Initialized
INFO - 2022-06-20 07:47:47 --> URI Class Initialized
INFO - 2022-06-20 07:47:47 --> Router Class Initialized
INFO - 2022-06-20 07:47:47 --> Output Class Initialized
INFO - 2022-06-20 07:47:47 --> Security Class Initialized
DEBUG - 2022-06-20 07:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:47:47 --> Input Class Initialized
INFO - 2022-06-20 07:47:47 --> Language Class Initialized
INFO - 2022-06-20 07:47:47 --> Language Class Initialized
INFO - 2022-06-20 07:47:47 --> Config Class Initialized
INFO - 2022-06-20 07:47:47 --> Loader Class Initialized
INFO - 2022-06-20 07:47:47 --> Helper loaded: url_helper
INFO - 2022-06-20 07:47:47 --> Database Driver Class Initialized
INFO - 2022-06-20 07:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:47:47 --> Model Class Initialized
DEBUG - 2022-06-20 07:47:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:47:47 --> Model Class Initialized
INFO - 2022-06-20 07:47:47 --> Controller Class Initialized
DEBUG - 2022-06-20 07:47:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:47:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:47:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:47:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:47:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:47:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:47:47 --> Final output sent to browser
DEBUG - 2022-06-20 07:47:47 --> Total execution time: 0.0841
INFO - 2022-06-20 07:48:06 --> Config Class Initialized
INFO - 2022-06-20 07:48:06 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:48:06 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:48:06 --> Utf8 Class Initialized
INFO - 2022-06-20 07:48:06 --> URI Class Initialized
INFO - 2022-06-20 07:48:06 --> Router Class Initialized
INFO - 2022-06-20 07:48:06 --> Output Class Initialized
INFO - 2022-06-20 07:48:06 --> Security Class Initialized
DEBUG - 2022-06-20 07:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:48:06 --> Input Class Initialized
INFO - 2022-06-20 07:48:06 --> Language Class Initialized
INFO - 2022-06-20 07:48:06 --> Language Class Initialized
INFO - 2022-06-20 07:48:06 --> Config Class Initialized
INFO - 2022-06-20 07:48:06 --> Loader Class Initialized
INFO - 2022-06-20 07:48:06 --> Helper loaded: url_helper
INFO - 2022-06-20 07:48:06 --> Database Driver Class Initialized
INFO - 2022-06-20 07:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:48:06 --> Model Class Initialized
DEBUG - 2022-06-20 07:48:06 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:48:06 --> Model Class Initialized
INFO - 2022-06-20 07:48:06 --> Controller Class Initialized
DEBUG - 2022-06-20 07:48:06 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:48:06 --> Final output sent to browser
DEBUG - 2022-06-20 07:48:06 --> Total execution time: 0.0528
INFO - 2022-06-20 07:48:20 --> Config Class Initialized
INFO - 2022-06-20 07:48:20 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:48:20 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:48:20 --> Utf8 Class Initialized
INFO - 2022-06-20 07:48:20 --> URI Class Initialized
INFO - 2022-06-20 07:48:20 --> Router Class Initialized
INFO - 2022-06-20 07:48:20 --> Output Class Initialized
INFO - 2022-06-20 07:48:20 --> Security Class Initialized
DEBUG - 2022-06-20 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:48:20 --> Input Class Initialized
INFO - 2022-06-20 07:48:20 --> Language Class Initialized
INFO - 2022-06-20 07:48:20 --> Language Class Initialized
INFO - 2022-06-20 07:48:20 --> Config Class Initialized
INFO - 2022-06-20 07:48:20 --> Loader Class Initialized
INFO - 2022-06-20 07:48:20 --> Helper loaded: url_helper
INFO - 2022-06-20 07:48:20 --> Database Driver Class Initialized
INFO - 2022-06-20 07:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:48:20 --> Model Class Initialized
DEBUG - 2022-06-20 07:48:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:48:20 --> Model Class Initialized
INFO - 2022-06-20 07:48:20 --> Controller Class Initialized
DEBUG - 2022-06-20 07:48:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:48:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:48:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:48:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:48:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:48:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:48:20 --> Final output sent to browser
DEBUG - 2022-06-20 07:48:20 --> Total execution time: 0.0838
INFO - 2022-06-20 07:48:26 --> Config Class Initialized
INFO - 2022-06-20 07:48:26 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:48:26 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:48:26 --> Utf8 Class Initialized
INFO - 2022-06-20 07:48:26 --> URI Class Initialized
INFO - 2022-06-20 07:48:26 --> Router Class Initialized
INFO - 2022-06-20 07:48:26 --> Output Class Initialized
INFO - 2022-06-20 07:48:26 --> Security Class Initialized
DEBUG - 2022-06-20 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:48:26 --> Input Class Initialized
INFO - 2022-06-20 07:48:26 --> Language Class Initialized
INFO - 2022-06-20 07:48:26 --> Language Class Initialized
INFO - 2022-06-20 07:48:26 --> Config Class Initialized
INFO - 2022-06-20 07:48:26 --> Loader Class Initialized
INFO - 2022-06-20 07:48:26 --> Helper loaded: url_helper
INFO - 2022-06-20 07:48:26 --> Database Driver Class Initialized
INFO - 2022-06-20 07:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:48:26 --> Model Class Initialized
DEBUG - 2022-06-20 07:48:26 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:48:26 --> Model Class Initialized
INFO - 2022-06-20 07:48:26 --> Controller Class Initialized
DEBUG - 2022-06-20 07:48:26 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:48:26 --> Final output sent to browser
DEBUG - 2022-06-20 07:48:26 --> Total execution time: 0.0650
INFO - 2022-06-20 07:48:43 --> Config Class Initialized
INFO - 2022-06-20 07:48:43 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:48:43 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:48:43 --> Utf8 Class Initialized
INFO - 2022-06-20 07:48:43 --> URI Class Initialized
INFO - 2022-06-20 07:48:43 --> Router Class Initialized
INFO - 2022-06-20 07:48:43 --> Output Class Initialized
INFO - 2022-06-20 07:48:43 --> Security Class Initialized
DEBUG - 2022-06-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:48:44 --> Input Class Initialized
INFO - 2022-06-20 07:48:44 --> Language Class Initialized
INFO - 2022-06-20 07:48:44 --> Language Class Initialized
INFO - 2022-06-20 07:48:44 --> Config Class Initialized
INFO - 2022-06-20 07:48:44 --> Loader Class Initialized
INFO - 2022-06-20 07:48:44 --> Helper loaded: url_helper
INFO - 2022-06-20 07:48:44 --> Database Driver Class Initialized
INFO - 2022-06-20 07:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:48:44 --> Model Class Initialized
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:48:44 --> Model Class Initialized
INFO - 2022-06-20 07:48:44 --> Controller Class Initialized
DEBUG - 2022-06-20 07:48:44 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:48:44 --> Config Class Initialized
INFO - 2022-06-20 07:48:44 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:48:44 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:48:44 --> Utf8 Class Initialized
INFO - 2022-06-20 07:48:44 --> URI Class Initialized
INFO - 2022-06-20 07:48:44 --> Router Class Initialized
INFO - 2022-06-20 07:48:44 --> Output Class Initialized
INFO - 2022-06-20 07:48:44 --> Security Class Initialized
DEBUG - 2022-06-20 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:48:44 --> Input Class Initialized
INFO - 2022-06-20 07:48:44 --> Language Class Initialized
INFO - 2022-06-20 07:48:44 --> Language Class Initialized
INFO - 2022-06-20 07:48:44 --> Config Class Initialized
INFO - 2022-06-20 07:48:44 --> Loader Class Initialized
INFO - 2022-06-20 07:48:44 --> Helper loaded: url_helper
INFO - 2022-06-20 07:48:44 --> Database Driver Class Initialized
INFO - 2022-06-20 07:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:48:44 --> Model Class Initialized
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:48:44 --> Model Class Initialized
INFO - 2022-06-20 07:48:44 --> Controller Class Initialized
DEBUG - 2022-06-20 07:48:44 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 07:48:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:48:44 --> Final output sent to browser
DEBUG - 2022-06-20 07:48:44 --> Total execution time: 0.0857
INFO - 2022-06-20 07:48:59 --> Config Class Initialized
INFO - 2022-06-20 07:48:59 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:48:59 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:48:59 --> Utf8 Class Initialized
INFO - 2022-06-20 07:48:59 --> URI Class Initialized
INFO - 2022-06-20 07:48:59 --> Router Class Initialized
INFO - 2022-06-20 07:48:59 --> Output Class Initialized
INFO - 2022-06-20 07:48:59 --> Security Class Initialized
DEBUG - 2022-06-20 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:48:59 --> Input Class Initialized
INFO - 2022-06-20 07:48:59 --> Language Class Initialized
INFO - 2022-06-20 07:48:59 --> Language Class Initialized
INFO - 2022-06-20 07:48:59 --> Config Class Initialized
INFO - 2022-06-20 07:48:59 --> Loader Class Initialized
INFO - 2022-06-20 07:48:59 --> Helper loaded: url_helper
INFO - 2022-06-20 07:48:59 --> Database Driver Class Initialized
INFO - 2022-06-20 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:49:00 --> Model Class Initialized
DEBUG - 2022-06-20 07:49:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:49:00 --> Model Class Initialized
INFO - 2022-06-20 07:49:00 --> Controller Class Initialized
DEBUG - 2022-06-20 07:49:00 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:49:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:49:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:49:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:49:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:49:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:49:00 --> Final output sent to browser
DEBUG - 2022-06-20 07:49:00 --> Total execution time: 0.0749
INFO - 2022-06-20 07:50:36 --> Config Class Initialized
INFO - 2022-06-20 07:50:36 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:50:36 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:50:36 --> Utf8 Class Initialized
INFO - 2022-06-20 07:50:36 --> URI Class Initialized
INFO - 2022-06-20 07:50:36 --> Router Class Initialized
INFO - 2022-06-20 07:50:36 --> Output Class Initialized
INFO - 2022-06-20 07:50:36 --> Security Class Initialized
DEBUG - 2022-06-20 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:50:36 --> Input Class Initialized
INFO - 2022-06-20 07:50:36 --> Language Class Initialized
INFO - 2022-06-20 07:50:36 --> Language Class Initialized
INFO - 2022-06-20 07:50:36 --> Config Class Initialized
INFO - 2022-06-20 07:50:36 --> Loader Class Initialized
INFO - 2022-06-20 07:50:36 --> Helper loaded: url_helper
INFO - 2022-06-20 07:50:36 --> Database Driver Class Initialized
INFO - 2022-06-20 07:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:50:36 --> Model Class Initialized
DEBUG - 2022-06-20 07:50:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:50:36 --> Model Class Initialized
INFO - 2022-06-20 07:50:36 --> Controller Class Initialized
DEBUG - 2022-06-20 07:50:36 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:50:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:50:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:50:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:50:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:50:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:50:36 --> Final output sent to browser
DEBUG - 2022-06-20 07:50:36 --> Total execution time: 0.0657
INFO - 2022-06-20 07:51:07 --> Config Class Initialized
INFO - 2022-06-20 07:51:07 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:51:07 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:51:07 --> Utf8 Class Initialized
INFO - 2022-06-20 07:51:07 --> URI Class Initialized
INFO - 2022-06-20 07:51:07 --> Router Class Initialized
INFO - 2022-06-20 07:51:07 --> Output Class Initialized
INFO - 2022-06-20 07:51:07 --> Security Class Initialized
DEBUG - 2022-06-20 07:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:51:07 --> Input Class Initialized
INFO - 2022-06-20 07:51:07 --> Language Class Initialized
INFO - 2022-06-20 07:51:07 --> Language Class Initialized
INFO - 2022-06-20 07:51:07 --> Config Class Initialized
INFO - 2022-06-20 07:51:07 --> Loader Class Initialized
INFO - 2022-06-20 07:51:07 --> Helper loaded: url_helper
INFO - 2022-06-20 07:51:07 --> Database Driver Class Initialized
INFO - 2022-06-20 07:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:51:07 --> Model Class Initialized
DEBUG - 2022-06-20 07:51:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:51:07 --> Model Class Initialized
INFO - 2022-06-20 07:51:07 --> Controller Class Initialized
DEBUG - 2022-06-20 07:51:07 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 07:51:07 --> Query error: Table 'dhired.social' doesn't exist - Invalid query: SELECT *
FROM `social`
WHERE `name` = 'Linkdin'
INFO - 2022-06-20 07:51:07 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-20 07:51:22 --> Config Class Initialized
INFO - 2022-06-20 07:51:22 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:51:22 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:51:22 --> Utf8 Class Initialized
INFO - 2022-06-20 07:51:22 --> URI Class Initialized
INFO - 2022-06-20 07:51:22 --> Router Class Initialized
INFO - 2022-06-20 07:51:22 --> Output Class Initialized
INFO - 2022-06-20 07:51:22 --> Security Class Initialized
DEBUG - 2022-06-20 07:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:51:22 --> Input Class Initialized
INFO - 2022-06-20 07:51:22 --> Language Class Initialized
INFO - 2022-06-20 07:51:22 --> Language Class Initialized
INFO - 2022-06-20 07:51:22 --> Config Class Initialized
INFO - 2022-06-20 07:51:22 --> Loader Class Initialized
INFO - 2022-06-20 07:51:22 --> Helper loaded: url_helper
INFO - 2022-06-20 07:51:22 --> Database Driver Class Initialized
INFO - 2022-06-20 07:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:51:22 --> Model Class Initialized
DEBUG - 2022-06-20 07:51:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:51:22 --> Model Class Initialized
INFO - 2022-06-20 07:51:22 --> Controller Class Initialized
DEBUG - 2022-06-20 07:51:22 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:51:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:51:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:51:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 07:51:22 --> Severity: Notice --> Undefined variable: soc N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
ERROR - 2022-06-20 07:51:22 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
DEBUG - 2022-06-20 07:51:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:51:22 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:51:22 --> Final output sent to browser
DEBUG - 2022-06-20 07:51:22 --> Total execution time: 0.1052
INFO - 2022-06-20 07:52:21 --> Config Class Initialized
INFO - 2022-06-20 07:52:21 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:52:21 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:52:21 --> Utf8 Class Initialized
INFO - 2022-06-20 07:52:21 --> URI Class Initialized
INFO - 2022-06-20 07:52:21 --> Router Class Initialized
INFO - 2022-06-20 07:52:21 --> Output Class Initialized
INFO - 2022-06-20 07:52:21 --> Security Class Initialized
DEBUG - 2022-06-20 07:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:52:21 --> Input Class Initialized
INFO - 2022-06-20 07:52:21 --> Language Class Initialized
INFO - 2022-06-20 07:52:21 --> Language Class Initialized
INFO - 2022-06-20 07:52:21 --> Config Class Initialized
INFO - 2022-06-20 07:52:21 --> Loader Class Initialized
INFO - 2022-06-20 07:52:21 --> Helper loaded: url_helper
INFO - 2022-06-20 07:52:21 --> Database Driver Class Initialized
INFO - 2022-06-20 07:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:52:21 --> Model Class Initialized
DEBUG - 2022-06-20 07:52:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:52:21 --> Model Class Initialized
INFO - 2022-06-20 07:52:21 --> Controller Class Initialized
DEBUG - 2022-06-20 07:52:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:52:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:52:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:52:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:52:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:52:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:52:21 --> Final output sent to browser
DEBUG - 2022-06-20 07:52:21 --> Total execution time: 0.0775
INFO - 2022-06-20 07:52:32 --> Config Class Initialized
INFO - 2022-06-20 07:52:32 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:52:32 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:52:32 --> Utf8 Class Initialized
INFO - 2022-06-20 07:52:32 --> URI Class Initialized
INFO - 2022-06-20 07:52:32 --> Router Class Initialized
INFO - 2022-06-20 07:52:32 --> Output Class Initialized
INFO - 2022-06-20 07:52:32 --> Security Class Initialized
DEBUG - 2022-06-20 07:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:52:32 --> Input Class Initialized
INFO - 2022-06-20 07:52:32 --> Language Class Initialized
INFO - 2022-06-20 07:52:32 --> Language Class Initialized
INFO - 2022-06-20 07:52:32 --> Config Class Initialized
INFO - 2022-06-20 07:52:32 --> Loader Class Initialized
INFO - 2022-06-20 07:52:32 --> Helper loaded: url_helper
INFO - 2022-06-20 07:52:32 --> Database Driver Class Initialized
INFO - 2022-06-20 07:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:52:32 --> Model Class Initialized
DEBUG - 2022-06-20 07:52:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:52:32 --> Model Class Initialized
INFO - 2022-06-20 07:52:32 --> Controller Class Initialized
DEBUG - 2022-06-20 07:52:32 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:52:32 --> Upload Class Initialized
INFO - 2022-06-20 07:52:33 --> Config Class Initialized
INFO - 2022-06-20 07:52:33 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:52:33 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:52:33 --> Utf8 Class Initialized
INFO - 2022-06-20 07:52:33 --> URI Class Initialized
INFO - 2022-06-20 07:52:33 --> Router Class Initialized
INFO - 2022-06-20 07:52:33 --> Output Class Initialized
INFO - 2022-06-20 07:52:33 --> Security Class Initialized
DEBUG - 2022-06-20 07:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:52:33 --> Input Class Initialized
INFO - 2022-06-20 07:52:33 --> Language Class Initialized
INFO - 2022-06-20 07:52:33 --> Language Class Initialized
INFO - 2022-06-20 07:52:33 --> Config Class Initialized
INFO - 2022-06-20 07:52:33 --> Loader Class Initialized
INFO - 2022-06-20 07:52:33 --> Helper loaded: url_helper
INFO - 2022-06-20 07:52:33 --> Database Driver Class Initialized
INFO - 2022-06-20 07:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:52:33 --> Model Class Initialized
DEBUG - 2022-06-20 07:52:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:52:33 --> Model Class Initialized
INFO - 2022-06-20 07:52:33 --> Controller Class Initialized
DEBUG - 2022-06-20 07:52:33 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:52:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:52:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:52:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:52:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:52:33 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:52:33 --> Final output sent to browser
DEBUG - 2022-06-20 07:52:33 --> Total execution time: 0.0629
INFO - 2022-06-20 07:52:59 --> Config Class Initialized
INFO - 2022-06-20 07:52:59 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:52:59 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:52:59 --> Utf8 Class Initialized
INFO - 2022-06-20 07:52:59 --> URI Class Initialized
INFO - 2022-06-20 07:52:59 --> Router Class Initialized
INFO - 2022-06-20 07:52:59 --> Output Class Initialized
INFO - 2022-06-20 07:52:59 --> Security Class Initialized
DEBUG - 2022-06-20 07:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:52:59 --> Input Class Initialized
INFO - 2022-06-20 07:52:59 --> Language Class Initialized
INFO - 2022-06-20 07:52:59 --> Language Class Initialized
INFO - 2022-06-20 07:52:59 --> Config Class Initialized
INFO - 2022-06-20 07:52:59 --> Loader Class Initialized
INFO - 2022-06-20 07:52:59 --> Helper loaded: url_helper
INFO - 2022-06-20 07:52:59 --> Database Driver Class Initialized
INFO - 2022-06-20 07:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:53:00 --> Model Class Initialized
DEBUG - 2022-06-20 07:53:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:53:00 --> Model Class Initialized
INFO - 2022-06-20 07:53:00 --> Controller Class Initialized
DEBUG - 2022-06-20 07:53:00 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:53:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:53:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:53:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 07:53:00 --> Severity: Notice --> Undefined variable: soc N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
ERROR - 2022-06-20 07:53:00 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
DEBUG - 2022-06-20 07:53:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:53:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:53:00 --> Final output sent to browser
DEBUG - 2022-06-20 07:53:00 --> Total execution time: 0.0863
INFO - 2022-06-20 07:54:53 --> Config Class Initialized
INFO - 2022-06-20 07:54:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:54:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:54:53 --> Utf8 Class Initialized
INFO - 2022-06-20 07:54:53 --> URI Class Initialized
INFO - 2022-06-20 07:54:53 --> Router Class Initialized
INFO - 2022-06-20 07:54:53 --> Output Class Initialized
INFO - 2022-06-20 07:54:53 --> Security Class Initialized
DEBUG - 2022-06-20 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:54:53 --> Input Class Initialized
INFO - 2022-06-20 07:54:53 --> Language Class Initialized
INFO - 2022-06-20 07:54:53 --> Language Class Initialized
INFO - 2022-06-20 07:54:53 --> Config Class Initialized
INFO - 2022-06-20 07:54:53 --> Loader Class Initialized
INFO - 2022-06-20 07:54:53 --> Helper loaded: url_helper
INFO - 2022-06-20 07:54:53 --> Database Driver Class Initialized
INFO - 2022-06-20 07:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:54:53 --> Model Class Initialized
DEBUG - 2022-06-20 07:54:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:54:53 --> Model Class Initialized
INFO - 2022-06-20 07:54:53 --> Controller Class Initialized
DEBUG - 2022-06-20 07:54:53 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:55:28 --> Config Class Initialized
INFO - 2022-06-20 07:55:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:55:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:55:28 --> Utf8 Class Initialized
INFO - 2022-06-20 07:55:28 --> URI Class Initialized
INFO - 2022-06-20 07:55:28 --> Router Class Initialized
INFO - 2022-06-20 07:55:28 --> Output Class Initialized
INFO - 2022-06-20 07:55:28 --> Security Class Initialized
DEBUG - 2022-06-20 07:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:55:28 --> Input Class Initialized
INFO - 2022-06-20 07:55:28 --> Language Class Initialized
INFO - 2022-06-20 07:55:28 --> Language Class Initialized
INFO - 2022-06-20 07:55:28 --> Config Class Initialized
INFO - 2022-06-20 07:55:28 --> Loader Class Initialized
INFO - 2022-06-20 07:55:28 --> Helper loaded: url_helper
INFO - 2022-06-20 07:55:28 --> Database Driver Class Initialized
INFO - 2022-06-20 07:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:55:28 --> Model Class Initialized
DEBUG - 2022-06-20 07:55:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:55:28 --> Model Class Initialized
INFO - 2022-06-20 07:55:28 --> Controller Class Initialized
DEBUG - 2022-06-20 07:55:28 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:55:37 --> Config Class Initialized
INFO - 2022-06-20 07:55:37 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:55:37 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:55:37 --> Utf8 Class Initialized
INFO - 2022-06-20 07:55:37 --> URI Class Initialized
INFO - 2022-06-20 07:55:37 --> Router Class Initialized
INFO - 2022-06-20 07:55:37 --> Output Class Initialized
INFO - 2022-06-20 07:55:37 --> Security Class Initialized
DEBUG - 2022-06-20 07:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:55:37 --> Input Class Initialized
INFO - 2022-06-20 07:55:37 --> Language Class Initialized
INFO - 2022-06-20 07:55:37 --> Language Class Initialized
INFO - 2022-06-20 07:55:37 --> Config Class Initialized
INFO - 2022-06-20 07:55:37 --> Loader Class Initialized
INFO - 2022-06-20 07:55:37 --> Helper loaded: url_helper
INFO - 2022-06-20 07:55:37 --> Database Driver Class Initialized
INFO - 2022-06-20 07:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:55:37 --> Model Class Initialized
DEBUG - 2022-06-20 07:55:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:55:37 --> Model Class Initialized
INFO - 2022-06-20 07:55:37 --> Controller Class Initialized
DEBUG - 2022-06-20 07:55:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:55:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:55:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:55:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:55:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:55:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:55:37 --> Final output sent to browser
DEBUG - 2022-06-20 07:55:37 --> Total execution time: 0.0304
INFO - 2022-06-20 07:55:56 --> Config Class Initialized
INFO - 2022-06-20 07:55:56 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:55:56 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:55:56 --> Utf8 Class Initialized
INFO - 2022-06-20 07:55:56 --> URI Class Initialized
INFO - 2022-06-20 07:55:56 --> Router Class Initialized
INFO - 2022-06-20 07:55:56 --> Output Class Initialized
INFO - 2022-06-20 07:55:56 --> Security Class Initialized
DEBUG - 2022-06-20 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:55:56 --> Input Class Initialized
INFO - 2022-06-20 07:55:56 --> Language Class Initialized
INFO - 2022-06-20 07:55:56 --> Language Class Initialized
INFO - 2022-06-20 07:55:56 --> Config Class Initialized
INFO - 2022-06-20 07:55:56 --> Loader Class Initialized
INFO - 2022-06-20 07:55:56 --> Helper loaded: url_helper
INFO - 2022-06-20 07:55:56 --> Database Driver Class Initialized
INFO - 2022-06-20 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:55:56 --> Model Class Initialized
DEBUG - 2022-06-20 07:55:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:55:56 --> Model Class Initialized
INFO - 2022-06-20 07:55:56 --> Controller Class Initialized
DEBUG - 2022-06-20 07:55:56 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:55:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:55:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:55:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:55:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:55:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:55:56 --> Final output sent to browser
DEBUG - 2022-06-20 07:55:56 --> Total execution time: 0.0581
INFO - 2022-06-20 07:56:04 --> Config Class Initialized
INFO - 2022-06-20 07:56:04 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:56:04 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:56:04 --> Utf8 Class Initialized
INFO - 2022-06-20 07:56:04 --> URI Class Initialized
INFO - 2022-06-20 07:56:04 --> Router Class Initialized
INFO - 2022-06-20 07:56:04 --> Output Class Initialized
INFO - 2022-06-20 07:56:04 --> Security Class Initialized
DEBUG - 2022-06-20 07:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:56:04 --> Input Class Initialized
INFO - 2022-06-20 07:56:04 --> Language Class Initialized
INFO - 2022-06-20 07:56:04 --> Language Class Initialized
INFO - 2022-06-20 07:56:04 --> Config Class Initialized
INFO - 2022-06-20 07:56:04 --> Loader Class Initialized
INFO - 2022-06-20 07:56:04 --> Helper loaded: url_helper
INFO - 2022-06-20 07:56:04 --> Database Driver Class Initialized
INFO - 2022-06-20 07:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:56:04 --> Model Class Initialized
DEBUG - 2022-06-20 07:56:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:56:04 --> Model Class Initialized
INFO - 2022-06-20 07:56:04 --> Controller Class Initialized
DEBUG - 2022-06-20 07:56:04 --> Admin MX_Controller Initialized
INFO - 2022-06-20 07:59:17 --> Config Class Initialized
INFO - 2022-06-20 07:59:17 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:59:17 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:59:17 --> Utf8 Class Initialized
INFO - 2022-06-20 07:59:17 --> URI Class Initialized
INFO - 2022-06-20 07:59:17 --> Router Class Initialized
INFO - 2022-06-20 07:59:17 --> Output Class Initialized
INFO - 2022-06-20 07:59:17 --> Security Class Initialized
DEBUG - 2022-06-20 07:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:59:17 --> Input Class Initialized
INFO - 2022-06-20 07:59:17 --> Language Class Initialized
INFO - 2022-06-20 07:59:17 --> Language Class Initialized
INFO - 2022-06-20 07:59:17 --> Config Class Initialized
INFO - 2022-06-20 07:59:17 --> Loader Class Initialized
INFO - 2022-06-20 07:59:17 --> Helper loaded: url_helper
INFO - 2022-06-20 07:59:17 --> Database Driver Class Initialized
INFO - 2022-06-20 07:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:59:17 --> Model Class Initialized
DEBUG - 2022-06-20 07:59:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:59:17 --> Model Class Initialized
INFO - 2022-06-20 07:59:17 --> Controller Class Initialized
DEBUG - 2022-06-20 07:59:17 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:59:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:59:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:59:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 07:59:17 --> Severity: Notice --> Undefined variable: soc N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
ERROR - 2022-06-20 07:59:17 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
DEBUG - 2022-06-20 07:59:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:59:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:59:17 --> Final output sent to browser
DEBUG - 2022-06-20 07:59:17 --> Total execution time: 0.0402
INFO - 2022-06-20 07:59:23 --> Config Class Initialized
INFO - 2022-06-20 07:59:23 --> Hooks Class Initialized
DEBUG - 2022-06-20 07:59:23 --> UTF-8 Support Enabled
INFO - 2022-06-20 07:59:23 --> Utf8 Class Initialized
INFO - 2022-06-20 07:59:23 --> URI Class Initialized
INFO - 2022-06-20 07:59:23 --> Router Class Initialized
INFO - 2022-06-20 07:59:23 --> Output Class Initialized
INFO - 2022-06-20 07:59:23 --> Security Class Initialized
DEBUG - 2022-06-20 07:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 07:59:23 --> Input Class Initialized
INFO - 2022-06-20 07:59:23 --> Language Class Initialized
INFO - 2022-06-20 07:59:23 --> Language Class Initialized
INFO - 2022-06-20 07:59:23 --> Config Class Initialized
INFO - 2022-06-20 07:59:23 --> Loader Class Initialized
INFO - 2022-06-20 07:59:23 --> Helper loaded: url_helper
INFO - 2022-06-20 07:59:23 --> Database Driver Class Initialized
INFO - 2022-06-20 07:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 07:59:23 --> Model Class Initialized
DEBUG - 2022-06-20 07:59:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 07:59:23 --> Model Class Initialized
INFO - 2022-06-20 07:59:23 --> Controller Class Initialized
DEBUG - 2022-06-20 07:59:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 07:59:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 07:59:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 07:59:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 07:59:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 07:59:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 07:59:23 --> Final output sent to browser
DEBUG - 2022-06-20 07:59:23 --> Total execution time: 0.0387
INFO - 2022-06-20 08:00:47 --> Config Class Initialized
INFO - 2022-06-20 08:00:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:00:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:00:47 --> Utf8 Class Initialized
INFO - 2022-06-20 08:00:47 --> URI Class Initialized
INFO - 2022-06-20 08:00:47 --> Router Class Initialized
INFO - 2022-06-20 08:00:47 --> Output Class Initialized
INFO - 2022-06-20 08:00:47 --> Security Class Initialized
DEBUG - 2022-06-20 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:00:47 --> Input Class Initialized
INFO - 2022-06-20 08:00:47 --> Language Class Initialized
INFO - 2022-06-20 08:00:47 --> Language Class Initialized
INFO - 2022-06-20 08:00:47 --> Config Class Initialized
INFO - 2022-06-20 08:00:47 --> Loader Class Initialized
INFO - 2022-06-20 08:00:47 --> Helper loaded: url_helper
INFO - 2022-06-20 08:00:47 --> Database Driver Class Initialized
INFO - 2022-06-20 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:00:47 --> Model Class Initialized
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:00:47 --> Model Class Initialized
INFO - 2022-06-20 08:00:47 --> Controller Class Initialized
DEBUG - 2022-06-20 08:00:47 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:00:47 --> Upload Class Initialized
INFO - 2022-06-20 08:00:47 --> Config Class Initialized
INFO - 2022-06-20 08:00:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:00:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:00:47 --> Utf8 Class Initialized
INFO - 2022-06-20 08:00:47 --> URI Class Initialized
INFO - 2022-06-20 08:00:47 --> Router Class Initialized
INFO - 2022-06-20 08:00:47 --> Output Class Initialized
INFO - 2022-06-20 08:00:47 --> Security Class Initialized
DEBUG - 2022-06-20 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:00:47 --> Input Class Initialized
INFO - 2022-06-20 08:00:47 --> Language Class Initialized
INFO - 2022-06-20 08:00:47 --> Language Class Initialized
INFO - 2022-06-20 08:00:47 --> Config Class Initialized
INFO - 2022-06-20 08:00:47 --> Loader Class Initialized
INFO - 2022-06-20 08:00:47 --> Helper loaded: url_helper
INFO - 2022-06-20 08:00:47 --> Database Driver Class Initialized
INFO - 2022-06-20 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:00:47 --> Model Class Initialized
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:00:47 --> Model Class Initialized
INFO - 2022-06-20 08:00:47 --> Controller Class Initialized
DEBUG - 2022-06-20 08:00:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:00:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:00:47 --> Final output sent to browser
DEBUG - 2022-06-20 08:00:47 --> Total execution time: 0.0414
INFO - 2022-06-20 08:00:57 --> Config Class Initialized
INFO - 2022-06-20 08:00:57 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:00:57 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:00:57 --> Utf8 Class Initialized
INFO - 2022-06-20 08:00:57 --> URI Class Initialized
INFO - 2022-06-20 08:00:57 --> Router Class Initialized
INFO - 2022-06-20 08:00:57 --> Output Class Initialized
INFO - 2022-06-20 08:00:57 --> Security Class Initialized
DEBUG - 2022-06-20 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:00:57 --> Input Class Initialized
INFO - 2022-06-20 08:00:57 --> Language Class Initialized
INFO - 2022-06-20 08:00:57 --> Language Class Initialized
INFO - 2022-06-20 08:00:57 --> Config Class Initialized
INFO - 2022-06-20 08:00:57 --> Loader Class Initialized
INFO - 2022-06-20 08:00:57 --> Helper loaded: url_helper
INFO - 2022-06-20 08:00:57 --> Database Driver Class Initialized
INFO - 2022-06-20 08:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:00:57 --> Model Class Initialized
DEBUG - 2022-06-20 08:00:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:00:57 --> Model Class Initialized
INFO - 2022-06-20 08:00:57 --> Controller Class Initialized
DEBUG - 2022-06-20 08:00:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:00:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:00:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:00:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 08:00:57 --> Severity: Notice --> Undefined variable: soc N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
ERROR - 2022-06-20 08:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
DEBUG - 2022-06-20 08:00:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:00:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:00:57 --> Final output sent to browser
DEBUG - 2022-06-20 08:00:57 --> Total execution time: 0.0458
INFO - 2022-06-20 08:01:53 --> Config Class Initialized
INFO - 2022-06-20 08:01:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:01:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:01:53 --> Utf8 Class Initialized
INFO - 2022-06-20 08:01:53 --> URI Class Initialized
INFO - 2022-06-20 08:01:53 --> Router Class Initialized
INFO - 2022-06-20 08:01:53 --> Output Class Initialized
INFO - 2022-06-20 08:01:53 --> Security Class Initialized
DEBUG - 2022-06-20 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:01:53 --> Input Class Initialized
INFO - 2022-06-20 08:01:53 --> Language Class Initialized
INFO - 2022-06-20 08:01:53 --> Language Class Initialized
INFO - 2022-06-20 08:01:53 --> Config Class Initialized
INFO - 2022-06-20 08:01:53 --> Loader Class Initialized
INFO - 2022-06-20 08:01:53 --> Helper loaded: url_helper
INFO - 2022-06-20 08:01:53 --> Database Driver Class Initialized
INFO - 2022-06-20 08:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:01:53 --> Model Class Initialized
DEBUG - 2022-06-20 08:01:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:01:53 --> Model Class Initialized
INFO - 2022-06-20 08:01:53 --> Controller Class Initialized
DEBUG - 2022-06-20 08:01:53 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 08:01:53 --> Severity: Notice --> Trying to access array offset on value of type int N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 233
DEBUG - 2022-06-20 08:01:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:01:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:01:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 08:01:53 --> Severity: Notice --> Undefined variable: soc N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
ERROR - 2022-06-20 08:01:53 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
DEBUG - 2022-06-20 08:01:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:01:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:01:53 --> Final output sent to browser
DEBUG - 2022-06-20 08:01:53 --> Total execution time: 0.0334
INFO - 2022-06-20 08:02:05 --> Config Class Initialized
INFO - 2022-06-20 08:02:05 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:02:05 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:02:05 --> Utf8 Class Initialized
INFO - 2022-06-20 08:02:05 --> URI Class Initialized
INFO - 2022-06-20 08:02:05 --> Router Class Initialized
INFO - 2022-06-20 08:02:05 --> Output Class Initialized
INFO - 2022-06-20 08:02:05 --> Security Class Initialized
DEBUG - 2022-06-20 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:02:05 --> Input Class Initialized
INFO - 2022-06-20 08:02:05 --> Language Class Initialized
INFO - 2022-06-20 08:02:05 --> Language Class Initialized
INFO - 2022-06-20 08:02:05 --> Config Class Initialized
INFO - 2022-06-20 08:02:05 --> Loader Class Initialized
INFO - 2022-06-20 08:02:05 --> Helper loaded: url_helper
INFO - 2022-06-20 08:02:05 --> Database Driver Class Initialized
INFO - 2022-06-20 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:02:05 --> Model Class Initialized
DEBUG - 2022-06-20 08:02:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:02:05 --> Model Class Initialized
INFO - 2022-06-20 08:02:05 --> Controller Class Initialized
DEBUG - 2022-06-20 08:02:05 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:02:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:02:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:02:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 08:02:05 --> Severity: Notice --> Undefined variable: soc N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
ERROR - 2022-06-20 08:02:05 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_socialmedia.php 69
DEBUG - 2022-06-20 08:02:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:02:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:02:05 --> Final output sent to browser
DEBUG - 2022-06-20 08:02:05 --> Total execution time: 0.0388
INFO - 2022-06-20 08:02:14 --> Config Class Initialized
INFO - 2022-06-20 08:02:14 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:02:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:02:14 --> Utf8 Class Initialized
INFO - 2022-06-20 08:02:14 --> URI Class Initialized
INFO - 2022-06-20 08:02:14 --> Router Class Initialized
INFO - 2022-06-20 08:02:14 --> Output Class Initialized
INFO - 2022-06-20 08:02:14 --> Security Class Initialized
DEBUG - 2022-06-20 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:02:14 --> Input Class Initialized
INFO - 2022-06-20 08:02:14 --> Language Class Initialized
INFO - 2022-06-20 08:02:14 --> Language Class Initialized
INFO - 2022-06-20 08:02:14 --> Config Class Initialized
INFO - 2022-06-20 08:02:14 --> Loader Class Initialized
INFO - 2022-06-20 08:02:14 --> Helper loaded: url_helper
INFO - 2022-06-20 08:02:14 --> Database Driver Class Initialized
INFO - 2022-06-20 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:02:14 --> Model Class Initialized
DEBUG - 2022-06-20 08:02:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:02:14 --> Model Class Initialized
INFO - 2022-06-20 08:02:14 --> Controller Class Initialized
DEBUG - 2022-06-20 08:02:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:02:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:02:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:02:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:02:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:02:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:02:14 --> Final output sent to browser
DEBUG - 2022-06-20 08:02:14 --> Total execution time: 0.0355
INFO - 2022-06-20 08:03:19 --> Config Class Initialized
INFO - 2022-06-20 08:03:19 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:03:19 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:03:19 --> Utf8 Class Initialized
INFO - 2022-06-20 08:03:19 --> URI Class Initialized
INFO - 2022-06-20 08:03:19 --> Router Class Initialized
INFO - 2022-06-20 08:03:19 --> Output Class Initialized
INFO - 2022-06-20 08:03:19 --> Security Class Initialized
DEBUG - 2022-06-20 08:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:03:19 --> Input Class Initialized
INFO - 2022-06-20 08:03:19 --> Language Class Initialized
INFO - 2022-06-20 08:03:19 --> Language Class Initialized
INFO - 2022-06-20 08:03:19 --> Config Class Initialized
INFO - 2022-06-20 08:03:19 --> Loader Class Initialized
INFO - 2022-06-20 08:03:19 --> Helper loaded: url_helper
INFO - 2022-06-20 08:03:19 --> Database Driver Class Initialized
INFO - 2022-06-20 08:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:03:19 --> Model Class Initialized
DEBUG - 2022-06-20 08:03:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:03:19 --> Model Class Initialized
INFO - 2022-06-20 08:03:19 --> Controller Class Initialized
DEBUG - 2022-06-20 08:03:19 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:03:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:03:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:03:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:03:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:03:19 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:03:19 --> Final output sent to browser
DEBUG - 2022-06-20 08:03:19 --> Total execution time: 0.0434
INFO - 2022-06-20 08:03:29 --> Config Class Initialized
INFO - 2022-06-20 08:03:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:03:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:03:29 --> Utf8 Class Initialized
INFO - 2022-06-20 08:03:29 --> URI Class Initialized
INFO - 2022-06-20 08:03:29 --> Router Class Initialized
INFO - 2022-06-20 08:03:29 --> Output Class Initialized
INFO - 2022-06-20 08:03:29 --> Security Class Initialized
DEBUG - 2022-06-20 08:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:03:29 --> Input Class Initialized
INFO - 2022-06-20 08:03:29 --> Language Class Initialized
INFO - 2022-06-20 08:03:29 --> Language Class Initialized
INFO - 2022-06-20 08:03:29 --> Config Class Initialized
INFO - 2022-06-20 08:03:29 --> Loader Class Initialized
INFO - 2022-06-20 08:03:29 --> Helper loaded: url_helper
INFO - 2022-06-20 08:03:29 --> Database Driver Class Initialized
INFO - 2022-06-20 08:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:03:29 --> Model Class Initialized
DEBUG - 2022-06-20 08:03:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:03:29 --> Model Class Initialized
INFO - 2022-06-20 08:03:29 --> Controller Class Initialized
DEBUG - 2022-06-20 08:03:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:03:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:03:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:03:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:03:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:03:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:03:29 --> Final output sent to browser
DEBUG - 2022-06-20 08:03:29 --> Total execution time: 0.0404
INFO - 2022-06-20 08:04:14 --> Config Class Initialized
INFO - 2022-06-20 08:04:14 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:04:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:04:14 --> Utf8 Class Initialized
INFO - 2022-06-20 08:04:14 --> URI Class Initialized
INFO - 2022-06-20 08:04:14 --> Router Class Initialized
INFO - 2022-06-20 08:04:14 --> Output Class Initialized
INFO - 2022-06-20 08:04:14 --> Security Class Initialized
DEBUG - 2022-06-20 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:04:14 --> Input Class Initialized
INFO - 2022-06-20 08:04:14 --> Language Class Initialized
INFO - 2022-06-20 08:04:14 --> Language Class Initialized
INFO - 2022-06-20 08:04:14 --> Config Class Initialized
INFO - 2022-06-20 08:04:14 --> Loader Class Initialized
INFO - 2022-06-20 08:04:14 --> Helper loaded: url_helper
INFO - 2022-06-20 08:04:14 --> Database Driver Class Initialized
INFO - 2022-06-20 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:04:14 --> Model Class Initialized
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:04:14 --> Model Class Initialized
INFO - 2022-06-20 08:04:14 --> Controller Class Initialized
DEBUG - 2022-06-20 08:04:14 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:04:14 --> Upload Class Initialized
INFO - 2022-06-20 08:04:14 --> Config Class Initialized
INFO - 2022-06-20 08:04:14 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:04:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:04:14 --> Utf8 Class Initialized
INFO - 2022-06-20 08:04:14 --> URI Class Initialized
INFO - 2022-06-20 08:04:14 --> Router Class Initialized
INFO - 2022-06-20 08:04:14 --> Output Class Initialized
INFO - 2022-06-20 08:04:14 --> Security Class Initialized
DEBUG - 2022-06-20 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:04:14 --> Input Class Initialized
INFO - 2022-06-20 08:04:14 --> Language Class Initialized
INFO - 2022-06-20 08:04:14 --> Language Class Initialized
INFO - 2022-06-20 08:04:14 --> Config Class Initialized
INFO - 2022-06-20 08:04:14 --> Loader Class Initialized
INFO - 2022-06-20 08:04:14 --> Helper loaded: url_helper
INFO - 2022-06-20 08:04:14 --> Database Driver Class Initialized
INFO - 2022-06-20 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:04:14 --> Model Class Initialized
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:04:14 --> Model Class Initialized
INFO - 2022-06-20 08:04:14 --> Controller Class Initialized
DEBUG - 2022-06-20 08:04:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:04:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:04:14 --> Final output sent to browser
DEBUG - 2022-06-20 08:04:14 --> Total execution time: 0.0579
INFO - 2022-06-20 08:04:19 --> Config Class Initialized
INFO - 2022-06-20 08:04:19 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:04:19 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:04:19 --> Utf8 Class Initialized
INFO - 2022-06-20 08:04:19 --> URI Class Initialized
INFO - 2022-06-20 08:04:19 --> Router Class Initialized
INFO - 2022-06-20 08:04:19 --> Output Class Initialized
INFO - 2022-06-20 08:04:19 --> Security Class Initialized
DEBUG - 2022-06-20 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:04:20 --> Input Class Initialized
INFO - 2022-06-20 08:04:20 --> Language Class Initialized
INFO - 2022-06-20 08:04:20 --> Language Class Initialized
INFO - 2022-06-20 08:04:20 --> Config Class Initialized
INFO - 2022-06-20 08:04:20 --> Loader Class Initialized
INFO - 2022-06-20 08:04:20 --> Helper loaded: url_helper
INFO - 2022-06-20 08:04:20 --> Database Driver Class Initialized
INFO - 2022-06-20 08:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:04:20 --> Model Class Initialized
DEBUG - 2022-06-20 08:04:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:04:20 --> Model Class Initialized
INFO - 2022-06-20 08:04:20 --> Controller Class Initialized
DEBUG - 2022-06-20 08:04:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:04:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:04:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:04:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:04:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:04:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:04:20 --> Final output sent to browser
DEBUG - 2022-06-20 08:04:20 --> Total execution time: 0.0454
INFO - 2022-06-20 08:05:53 --> Config Class Initialized
INFO - 2022-06-20 08:05:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:05:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:05:53 --> Utf8 Class Initialized
INFO - 2022-06-20 08:05:53 --> URI Class Initialized
INFO - 2022-06-20 08:05:53 --> Router Class Initialized
INFO - 2022-06-20 08:05:53 --> Output Class Initialized
INFO - 2022-06-20 08:05:53 --> Security Class Initialized
DEBUG - 2022-06-20 08:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:05:53 --> Input Class Initialized
INFO - 2022-06-20 08:05:53 --> Language Class Initialized
INFO - 2022-06-20 08:05:53 --> Language Class Initialized
INFO - 2022-06-20 08:05:53 --> Config Class Initialized
INFO - 2022-06-20 08:05:53 --> Loader Class Initialized
INFO - 2022-06-20 08:05:53 --> Helper loaded: url_helper
INFO - 2022-06-20 08:05:53 --> Database Driver Class Initialized
INFO - 2022-06-20 08:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:05:53 --> Model Class Initialized
DEBUG - 2022-06-20 08:05:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:05:53 --> Model Class Initialized
INFO - 2022-06-20 08:05:53 --> Controller Class Initialized
DEBUG - 2022-06-20 08:05:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:05:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:05:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:05:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:05:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:05:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:05:53 --> Final output sent to browser
DEBUG - 2022-06-20 08:05:53 --> Total execution time: 0.0394
INFO - 2022-06-20 08:06:09 --> Config Class Initialized
INFO - 2022-06-20 08:06:09 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:09 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:09 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:09 --> URI Class Initialized
INFO - 2022-06-20 08:06:09 --> Router Class Initialized
INFO - 2022-06-20 08:06:09 --> Output Class Initialized
INFO - 2022-06-20 08:06:09 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:09 --> Input Class Initialized
INFO - 2022-06-20 08:06:09 --> Language Class Initialized
INFO - 2022-06-20 08:06:09 --> Language Class Initialized
INFO - 2022-06-20 08:06:09 --> Config Class Initialized
INFO - 2022-06-20 08:06:09 --> Loader Class Initialized
INFO - 2022-06-20 08:06:09 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:09 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:09 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:09 --> Model Class Initialized
INFO - 2022-06-20 08:06:09 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:09 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:09 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:09 --> Total execution time: 0.0329
INFO - 2022-06-20 08:06:09 --> Config Class Initialized
INFO - 2022-06-20 08:06:09 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:09 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:09 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:09 --> URI Class Initialized
INFO - 2022-06-20 08:06:09 --> Router Class Initialized
INFO - 2022-06-20 08:06:09 --> Output Class Initialized
INFO - 2022-06-20 08:06:09 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:09 --> Input Class Initialized
INFO - 2022-06-20 08:06:09 --> Language Class Initialized
INFO - 2022-06-20 08:06:09 --> Language Class Initialized
INFO - 2022-06-20 08:06:09 --> Config Class Initialized
INFO - 2022-06-20 08:06:09 --> Loader Class Initialized
INFO - 2022-06-20 08:06:09 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:09 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:09 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:09 --> Model Class Initialized
INFO - 2022-06-20 08:06:09 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:09 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:09 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:09 --> Total execution time: 0.0357
INFO - 2022-06-20 08:06:11 --> Config Class Initialized
INFO - 2022-06-20 08:06:11 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:11 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:11 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:11 --> URI Class Initialized
INFO - 2022-06-20 08:06:11 --> Router Class Initialized
INFO - 2022-06-20 08:06:11 --> Output Class Initialized
INFO - 2022-06-20 08:06:11 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:11 --> Input Class Initialized
INFO - 2022-06-20 08:06:11 --> Language Class Initialized
INFO - 2022-06-20 08:06:11 --> Language Class Initialized
INFO - 2022-06-20 08:06:11 --> Config Class Initialized
INFO - 2022-06-20 08:06:11 --> Loader Class Initialized
INFO - 2022-06-20 08:06:11 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:11 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:11 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:11 --> Model Class Initialized
INFO - 2022-06-20 08:06:11 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:11 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:11 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:11 --> Total execution time: 0.0365
INFO - 2022-06-20 08:06:11 --> Config Class Initialized
INFO - 2022-06-20 08:06:11 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:11 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:11 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:11 --> URI Class Initialized
INFO - 2022-06-20 08:06:11 --> Router Class Initialized
INFO - 2022-06-20 08:06:11 --> Output Class Initialized
INFO - 2022-06-20 08:06:11 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:11 --> Input Class Initialized
INFO - 2022-06-20 08:06:11 --> Language Class Initialized
INFO - 2022-06-20 08:06:11 --> Language Class Initialized
INFO - 2022-06-20 08:06:11 --> Config Class Initialized
INFO - 2022-06-20 08:06:11 --> Loader Class Initialized
INFO - 2022-06-20 08:06:11 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:11 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:11 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:11 --> Model Class Initialized
INFO - 2022-06-20 08:06:11 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:11 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:11 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:11 --> Total execution time: 0.0326
INFO - 2022-06-20 08:06:13 --> Config Class Initialized
INFO - 2022-06-20 08:06:13 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:13 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:13 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:13 --> URI Class Initialized
INFO - 2022-06-20 08:06:13 --> Router Class Initialized
INFO - 2022-06-20 08:06:13 --> Output Class Initialized
INFO - 2022-06-20 08:06:13 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:13 --> Input Class Initialized
INFO - 2022-06-20 08:06:13 --> Language Class Initialized
INFO - 2022-06-20 08:06:13 --> Language Class Initialized
INFO - 2022-06-20 08:06:13 --> Config Class Initialized
INFO - 2022-06-20 08:06:13 --> Loader Class Initialized
INFO - 2022-06-20 08:06:13 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:13 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:13 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:13 --> Model Class Initialized
INFO - 2022-06-20 08:06:13 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:13 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:06:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:06:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:06:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:06:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:06:13 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:06:13 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:13 --> Total execution time: 0.0411
INFO - 2022-06-20 08:06:25 --> Config Class Initialized
INFO - 2022-06-20 08:06:25 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:25 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:25 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:25 --> URI Class Initialized
INFO - 2022-06-20 08:06:25 --> Router Class Initialized
INFO - 2022-06-20 08:06:25 --> Output Class Initialized
INFO - 2022-06-20 08:06:25 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:25 --> Input Class Initialized
INFO - 2022-06-20 08:06:25 --> Language Class Initialized
INFO - 2022-06-20 08:06:25 --> Language Class Initialized
INFO - 2022-06-20 08:06:25 --> Config Class Initialized
INFO - 2022-06-20 08:06:25 --> Loader Class Initialized
INFO - 2022-06-20 08:06:25 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:25 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:25 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:25 --> Model Class Initialized
INFO - 2022-06-20 08:06:25 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:25 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:25 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:25 --> Total execution time: 0.0370
INFO - 2022-06-20 08:06:25 --> Config Class Initialized
INFO - 2022-06-20 08:06:25 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:25 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:25 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:25 --> URI Class Initialized
INFO - 2022-06-20 08:06:25 --> Router Class Initialized
INFO - 2022-06-20 08:06:25 --> Output Class Initialized
INFO - 2022-06-20 08:06:25 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:25 --> Input Class Initialized
INFO - 2022-06-20 08:06:25 --> Language Class Initialized
INFO - 2022-06-20 08:06:25 --> Language Class Initialized
INFO - 2022-06-20 08:06:25 --> Config Class Initialized
INFO - 2022-06-20 08:06:25 --> Loader Class Initialized
INFO - 2022-06-20 08:06:25 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:25 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:25 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:25 --> Model Class Initialized
INFO - 2022-06-20 08:06:25 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:25 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:25 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:25 --> Total execution time: 0.0336
INFO - 2022-06-20 08:06:28 --> Config Class Initialized
INFO - 2022-06-20 08:06:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:28 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:28 --> URI Class Initialized
INFO - 2022-06-20 08:06:28 --> Router Class Initialized
INFO - 2022-06-20 08:06:28 --> Output Class Initialized
INFO - 2022-06-20 08:06:28 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:28 --> Input Class Initialized
INFO - 2022-06-20 08:06:28 --> Language Class Initialized
INFO - 2022-06-20 08:06:28 --> Language Class Initialized
INFO - 2022-06-20 08:06:28 --> Config Class Initialized
INFO - 2022-06-20 08:06:28 --> Loader Class Initialized
INFO - 2022-06-20 08:06:28 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:28 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:28 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:28 --> Model Class Initialized
INFO - 2022-06-20 08:06:28 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:28 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:28 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:28 --> Total execution time: 0.0353
INFO - 2022-06-20 08:06:28 --> Config Class Initialized
INFO - 2022-06-20 08:06:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:28 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:28 --> URI Class Initialized
INFO - 2022-06-20 08:06:28 --> Router Class Initialized
INFO - 2022-06-20 08:06:28 --> Output Class Initialized
INFO - 2022-06-20 08:06:28 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:28 --> Input Class Initialized
INFO - 2022-06-20 08:06:28 --> Language Class Initialized
INFO - 2022-06-20 08:06:28 --> Language Class Initialized
INFO - 2022-06-20 08:06:28 --> Config Class Initialized
INFO - 2022-06-20 08:06:28 --> Loader Class Initialized
INFO - 2022-06-20 08:06:28 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:28 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:28 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:28 --> Model Class Initialized
INFO - 2022-06-20 08:06:28 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:28 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:28 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:28 --> Total execution time: 0.0335
INFO - 2022-06-20 08:06:29 --> Config Class Initialized
INFO - 2022-06-20 08:06:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:29 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:29 --> URI Class Initialized
INFO - 2022-06-20 08:06:29 --> Router Class Initialized
INFO - 2022-06-20 08:06:29 --> Output Class Initialized
INFO - 2022-06-20 08:06:29 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:29 --> Input Class Initialized
INFO - 2022-06-20 08:06:29 --> Language Class Initialized
INFO - 2022-06-20 08:06:29 --> Language Class Initialized
INFO - 2022-06-20 08:06:29 --> Config Class Initialized
INFO - 2022-06-20 08:06:29 --> Loader Class Initialized
INFO - 2022-06-20 08:06:29 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:29 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:29 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:29 --> Model Class Initialized
INFO - 2022-06-20 08:06:29 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:29 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:06:29 --> Config Class Initialized
INFO - 2022-06-20 08:06:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:29 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:29 --> URI Class Initialized
INFO - 2022-06-20 08:06:29 --> Router Class Initialized
INFO - 2022-06-20 08:06:29 --> Output Class Initialized
INFO - 2022-06-20 08:06:29 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:29 --> Input Class Initialized
INFO - 2022-06-20 08:06:29 --> Language Class Initialized
INFO - 2022-06-20 08:06:29 --> Language Class Initialized
INFO - 2022-06-20 08:06:29 --> Config Class Initialized
INFO - 2022-06-20 08:06:29 --> Loader Class Initialized
INFO - 2022-06-20 08:06:29 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:29 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:29 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:29 --> Model Class Initialized
INFO - 2022-06-20 08:06:29 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:06:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:06:29 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:29 --> Total execution time: 0.0455
INFO - 2022-06-20 08:06:51 --> Config Class Initialized
INFO - 2022-06-20 08:06:51 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:06:51 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:06:51 --> Utf8 Class Initialized
INFO - 2022-06-20 08:06:51 --> URI Class Initialized
INFO - 2022-06-20 08:06:51 --> Router Class Initialized
INFO - 2022-06-20 08:06:51 --> Output Class Initialized
INFO - 2022-06-20 08:06:51 --> Security Class Initialized
DEBUG - 2022-06-20 08:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:06:51 --> Input Class Initialized
INFO - 2022-06-20 08:06:51 --> Language Class Initialized
INFO - 2022-06-20 08:06:51 --> Language Class Initialized
INFO - 2022-06-20 08:06:51 --> Config Class Initialized
INFO - 2022-06-20 08:06:51 --> Loader Class Initialized
INFO - 2022-06-20 08:06:51 --> Helper loaded: url_helper
INFO - 2022-06-20 08:06:51 --> Database Driver Class Initialized
INFO - 2022-06-20 08:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:06:51 --> Model Class Initialized
DEBUG - 2022-06-20 08:06:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:06:51 --> Model Class Initialized
INFO - 2022-06-20 08:06:51 --> Controller Class Initialized
DEBUG - 2022-06-20 08:06:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:06:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:06:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:06:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:06:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:06:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:06:51 --> Final output sent to browser
DEBUG - 2022-06-20 08:06:51 --> Total execution time: 0.0394
INFO - 2022-06-20 08:07:36 --> Config Class Initialized
INFO - 2022-06-20 08:07:36 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:07:36 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:07:36 --> Utf8 Class Initialized
INFO - 2022-06-20 08:07:36 --> URI Class Initialized
INFO - 2022-06-20 08:07:36 --> Router Class Initialized
INFO - 2022-06-20 08:07:36 --> Output Class Initialized
INFO - 2022-06-20 08:07:36 --> Security Class Initialized
DEBUG - 2022-06-20 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:07:36 --> Input Class Initialized
INFO - 2022-06-20 08:07:36 --> Language Class Initialized
INFO - 2022-06-20 08:07:36 --> Language Class Initialized
INFO - 2022-06-20 08:07:36 --> Config Class Initialized
INFO - 2022-06-20 08:07:36 --> Loader Class Initialized
INFO - 2022-06-20 08:07:36 --> Helper loaded: url_helper
INFO - 2022-06-20 08:07:36 --> Database Driver Class Initialized
INFO - 2022-06-20 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:07:36 --> Model Class Initialized
DEBUG - 2022-06-20 08:07:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:07:36 --> Model Class Initialized
INFO - 2022-06-20 08:07:36 --> Controller Class Initialized
DEBUG - 2022-06-20 08:07:36 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:07:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:07:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:07:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:07:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:07:36 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:07:36 --> Final output sent to browser
DEBUG - 2022-06-20 08:07:36 --> Total execution time: 0.0393
INFO - 2022-06-20 08:07:49 --> Config Class Initialized
INFO - 2022-06-20 08:07:49 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:07:49 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:07:49 --> Utf8 Class Initialized
INFO - 2022-06-20 08:07:49 --> URI Class Initialized
INFO - 2022-06-20 08:07:49 --> Router Class Initialized
INFO - 2022-06-20 08:07:49 --> Output Class Initialized
INFO - 2022-06-20 08:07:49 --> Security Class Initialized
DEBUG - 2022-06-20 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:07:49 --> Input Class Initialized
INFO - 2022-06-20 08:07:49 --> Language Class Initialized
INFO - 2022-06-20 08:07:49 --> Language Class Initialized
INFO - 2022-06-20 08:07:49 --> Config Class Initialized
INFO - 2022-06-20 08:07:49 --> Loader Class Initialized
INFO - 2022-06-20 08:07:49 --> Helper loaded: url_helper
INFO - 2022-06-20 08:07:49 --> Database Driver Class Initialized
INFO - 2022-06-20 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:07:49 --> Model Class Initialized
DEBUG - 2022-06-20 08:07:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:07:49 --> Model Class Initialized
INFO - 2022-06-20 08:07:49 --> Controller Class Initialized
DEBUG - 2022-06-20 08:07:49 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:07:49 --> Final output sent to browser
DEBUG - 2022-06-20 08:07:49 --> Total execution time: 0.0351
INFO - 2022-06-20 08:07:49 --> Config Class Initialized
INFO - 2022-06-20 08:07:49 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:07:49 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:07:49 --> Utf8 Class Initialized
INFO - 2022-06-20 08:07:49 --> URI Class Initialized
INFO - 2022-06-20 08:07:49 --> Router Class Initialized
INFO - 2022-06-20 08:07:49 --> Output Class Initialized
INFO - 2022-06-20 08:07:49 --> Security Class Initialized
DEBUG - 2022-06-20 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:07:49 --> Input Class Initialized
INFO - 2022-06-20 08:07:49 --> Language Class Initialized
INFO - 2022-06-20 08:07:49 --> Language Class Initialized
INFO - 2022-06-20 08:07:49 --> Config Class Initialized
INFO - 2022-06-20 08:07:49 --> Loader Class Initialized
INFO - 2022-06-20 08:07:49 --> Helper loaded: url_helper
INFO - 2022-06-20 08:07:49 --> Database Driver Class Initialized
INFO - 2022-06-20 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:07:49 --> Model Class Initialized
DEBUG - 2022-06-20 08:07:49 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:07:49 --> Model Class Initialized
INFO - 2022-06-20 08:07:49 --> Controller Class Initialized
DEBUG - 2022-06-20 08:07:49 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:07:49 --> Final output sent to browser
DEBUG - 2022-06-20 08:07:49 --> Total execution time: 0.0338
INFO - 2022-06-20 08:07:53 --> Config Class Initialized
INFO - 2022-06-20 08:07:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:07:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:07:53 --> Utf8 Class Initialized
INFO - 2022-06-20 08:07:53 --> URI Class Initialized
INFO - 2022-06-20 08:07:53 --> Router Class Initialized
INFO - 2022-06-20 08:07:53 --> Output Class Initialized
INFO - 2022-06-20 08:07:53 --> Security Class Initialized
DEBUG - 2022-06-20 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:07:53 --> Input Class Initialized
INFO - 2022-06-20 08:07:53 --> Language Class Initialized
INFO - 2022-06-20 08:07:53 --> Language Class Initialized
INFO - 2022-06-20 08:07:53 --> Config Class Initialized
INFO - 2022-06-20 08:07:53 --> Loader Class Initialized
INFO - 2022-06-20 08:07:53 --> Helper loaded: url_helper
INFO - 2022-06-20 08:07:53 --> Database Driver Class Initialized
INFO - 2022-06-20 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:07:53 --> Model Class Initialized
DEBUG - 2022-06-20 08:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:07:53 --> Model Class Initialized
INFO - 2022-06-20 08:07:53 --> Controller Class Initialized
DEBUG - 2022-06-20 08:07:53 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:07:53 --> Final output sent to browser
DEBUG - 2022-06-20 08:07:53 --> Total execution time: 0.0337
INFO - 2022-06-20 08:07:53 --> Config Class Initialized
INFO - 2022-06-20 08:07:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:07:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:07:53 --> Utf8 Class Initialized
INFO - 2022-06-20 08:07:53 --> URI Class Initialized
INFO - 2022-06-20 08:07:53 --> Router Class Initialized
INFO - 2022-06-20 08:07:53 --> Output Class Initialized
INFO - 2022-06-20 08:07:53 --> Security Class Initialized
DEBUG - 2022-06-20 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:07:53 --> Input Class Initialized
INFO - 2022-06-20 08:07:53 --> Language Class Initialized
INFO - 2022-06-20 08:07:53 --> Language Class Initialized
INFO - 2022-06-20 08:07:53 --> Config Class Initialized
INFO - 2022-06-20 08:07:53 --> Loader Class Initialized
INFO - 2022-06-20 08:07:53 --> Helper loaded: url_helper
INFO - 2022-06-20 08:07:53 --> Database Driver Class Initialized
INFO - 2022-06-20 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:07:53 --> Model Class Initialized
DEBUG - 2022-06-20 08:07:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:07:53 --> Model Class Initialized
INFO - 2022-06-20 08:07:53 --> Controller Class Initialized
DEBUG - 2022-06-20 08:07:53 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:07:53 --> Final output sent to browser
DEBUG - 2022-06-20 08:07:53 --> Total execution time: 0.0327
INFO - 2022-06-20 08:08:11 --> Config Class Initialized
INFO - 2022-06-20 08:08:11 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:11 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:11 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:11 --> URI Class Initialized
INFO - 2022-06-20 08:08:11 --> Router Class Initialized
INFO - 2022-06-20 08:08:11 --> Output Class Initialized
INFO - 2022-06-20 08:08:11 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:11 --> Input Class Initialized
INFO - 2022-06-20 08:08:11 --> Language Class Initialized
INFO - 2022-06-20 08:08:11 --> Language Class Initialized
INFO - 2022-06-20 08:08:11 --> Config Class Initialized
INFO - 2022-06-20 08:08:11 --> Loader Class Initialized
INFO - 2022-06-20 08:08:11 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:11 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:11 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:11 --> Model Class Initialized
INFO - 2022-06-20 08:08:11 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:08:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:08:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:08:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:08:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 08:08:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:08:11 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:11 --> Total execution time: 0.0366
INFO - 2022-06-20 08:08:17 --> Config Class Initialized
INFO - 2022-06-20 08:08:17 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:17 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:17 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:17 --> URI Class Initialized
INFO - 2022-06-20 08:08:17 --> Router Class Initialized
INFO - 2022-06-20 08:08:17 --> Output Class Initialized
INFO - 2022-06-20 08:08:17 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:17 --> Input Class Initialized
INFO - 2022-06-20 08:08:17 --> Language Class Initialized
INFO - 2022-06-20 08:08:17 --> Language Class Initialized
INFO - 2022-06-20 08:08:17 --> Config Class Initialized
INFO - 2022-06-20 08:08:17 --> Loader Class Initialized
INFO - 2022-06-20 08:08:17 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:17 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:17 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:17 --> Model Class Initialized
INFO - 2022-06-20 08:08:17 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:17 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:08:17 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:17 --> Total execution time: 0.0382
INFO - 2022-06-20 08:08:17 --> Config Class Initialized
INFO - 2022-06-20 08:08:17 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:17 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:17 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:17 --> URI Class Initialized
INFO - 2022-06-20 08:08:17 --> Router Class Initialized
INFO - 2022-06-20 08:08:17 --> Output Class Initialized
INFO - 2022-06-20 08:08:17 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:17 --> Input Class Initialized
INFO - 2022-06-20 08:08:17 --> Language Class Initialized
INFO - 2022-06-20 08:08:17 --> Language Class Initialized
INFO - 2022-06-20 08:08:17 --> Config Class Initialized
INFO - 2022-06-20 08:08:17 --> Loader Class Initialized
INFO - 2022-06-20 08:08:17 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:17 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:17 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:17 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:17 --> Model Class Initialized
INFO - 2022-06-20 08:08:17 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:17 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:08:17 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:17 --> Total execution time: 0.0344
INFO - 2022-06-20 08:08:21 --> Config Class Initialized
INFO - 2022-06-20 08:08:21 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:21 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:21 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:21 --> URI Class Initialized
INFO - 2022-06-20 08:08:21 --> Router Class Initialized
INFO - 2022-06-20 08:08:21 --> Output Class Initialized
INFO - 2022-06-20 08:08:21 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:21 --> Input Class Initialized
INFO - 2022-06-20 08:08:21 --> Language Class Initialized
INFO - 2022-06-20 08:08:21 --> Language Class Initialized
INFO - 2022-06-20 08:08:21 --> Config Class Initialized
INFO - 2022-06-20 08:08:21 --> Loader Class Initialized
INFO - 2022-06-20 08:08:21 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:21 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:21 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:21 --> Model Class Initialized
INFO - 2022-06-20 08:08:21 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:21 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:08:21 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:21 --> Total execution time: 0.0407
INFO - 2022-06-20 08:08:21 --> Config Class Initialized
INFO - 2022-06-20 08:08:21 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:21 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:21 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:21 --> URI Class Initialized
INFO - 2022-06-20 08:08:21 --> Router Class Initialized
INFO - 2022-06-20 08:08:21 --> Output Class Initialized
INFO - 2022-06-20 08:08:21 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:21 --> Input Class Initialized
INFO - 2022-06-20 08:08:21 --> Language Class Initialized
INFO - 2022-06-20 08:08:21 --> Language Class Initialized
INFO - 2022-06-20 08:08:21 --> Config Class Initialized
INFO - 2022-06-20 08:08:21 --> Loader Class Initialized
INFO - 2022-06-20 08:08:21 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:21 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:21 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:21 --> Model Class Initialized
INFO - 2022-06-20 08:08:21 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:21 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:08:21 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:21 --> Total execution time: 0.0329
INFO - 2022-06-20 08:08:24 --> Config Class Initialized
INFO - 2022-06-20 08:08:24 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:24 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:24 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:24 --> URI Class Initialized
INFO - 2022-06-20 08:08:24 --> Router Class Initialized
INFO - 2022-06-20 08:08:24 --> Output Class Initialized
INFO - 2022-06-20 08:08:24 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:24 --> Input Class Initialized
INFO - 2022-06-20 08:08:24 --> Language Class Initialized
INFO - 2022-06-20 08:08:24 --> Language Class Initialized
INFO - 2022-06-20 08:08:24 --> Config Class Initialized
INFO - 2022-06-20 08:08:24 --> Loader Class Initialized
INFO - 2022-06-20 08:08:24 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:24 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:24 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:24 --> Model Class Initialized
INFO - 2022-06-20 08:08:24 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:08:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:08:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:08:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:08:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 08:08:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:08:24 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:24 --> Total execution time: 0.0417
INFO - 2022-06-20 08:08:28 --> Config Class Initialized
INFO - 2022-06-20 08:08:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:28 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:28 --> URI Class Initialized
INFO - 2022-06-20 08:08:28 --> Router Class Initialized
INFO - 2022-06-20 08:08:28 --> Output Class Initialized
INFO - 2022-06-20 08:08:28 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:28 --> Input Class Initialized
INFO - 2022-06-20 08:08:28 --> Language Class Initialized
INFO - 2022-06-20 08:08:28 --> Language Class Initialized
INFO - 2022-06-20 08:08:28 --> Config Class Initialized
INFO - 2022-06-20 08:08:28 --> Loader Class Initialized
INFO - 2022-06-20 08:08:28 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:28 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:28 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:28 --> Model Class Initialized
INFO - 2022-06-20 08:08:28 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:08:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:08:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:08:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:08:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 08:08:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:08:28 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:28 --> Total execution time: 0.0382
INFO - 2022-06-20 08:08:34 --> Config Class Initialized
INFO - 2022-06-20 08:08:34 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:34 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:34 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:34 --> URI Class Initialized
INFO - 2022-06-20 08:08:34 --> Router Class Initialized
INFO - 2022-06-20 08:08:34 --> Output Class Initialized
INFO - 2022-06-20 08:08:34 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:34 --> Input Class Initialized
INFO - 2022-06-20 08:08:34 --> Language Class Initialized
INFO - 2022-06-20 08:08:34 --> Language Class Initialized
INFO - 2022-06-20 08:08:34 --> Config Class Initialized
INFO - 2022-06-20 08:08:34 --> Loader Class Initialized
INFO - 2022-06-20 08:08:34 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:34 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:34 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:34 --> Model Class Initialized
INFO - 2022-06-20 08:08:34 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:34 --> Admin MX_Controller Initialized
INFO - 2022-06-20 08:08:34 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:34 --> Total execution time: 0.0392
INFO - 2022-06-20 08:08:53 --> Config Class Initialized
INFO - 2022-06-20 08:08:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:08:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:08:53 --> Utf8 Class Initialized
INFO - 2022-06-20 08:08:53 --> URI Class Initialized
INFO - 2022-06-20 08:08:53 --> Router Class Initialized
INFO - 2022-06-20 08:08:53 --> Output Class Initialized
INFO - 2022-06-20 08:08:53 --> Security Class Initialized
DEBUG - 2022-06-20 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:08:53 --> Input Class Initialized
INFO - 2022-06-20 08:08:53 --> Language Class Initialized
INFO - 2022-06-20 08:08:53 --> Language Class Initialized
INFO - 2022-06-20 08:08:53 --> Config Class Initialized
INFO - 2022-06-20 08:08:53 --> Loader Class Initialized
INFO - 2022-06-20 08:08:53 --> Helper loaded: url_helper
INFO - 2022-06-20 08:08:53 --> Database Driver Class Initialized
INFO - 2022-06-20 08:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:08:53 --> Model Class Initialized
DEBUG - 2022-06-20 08:08:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:08:53 --> Model Class Initialized
INFO - 2022-06-20 08:08:53 --> Controller Class Initialized
DEBUG - 2022-06-20 08:08:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:08:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:08:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:08:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:08:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 08:08:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:08:53 --> Final output sent to browser
DEBUG - 2022-06-20 08:08:53 --> Total execution time: 0.0422
INFO - 2022-06-20 08:09:01 --> Config Class Initialized
INFO - 2022-06-20 08:09:01 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:09:01 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:09:01 --> Utf8 Class Initialized
INFO - 2022-06-20 08:09:01 --> URI Class Initialized
INFO - 2022-06-20 08:09:01 --> Router Class Initialized
INFO - 2022-06-20 08:09:01 --> Output Class Initialized
INFO - 2022-06-20 08:09:01 --> Security Class Initialized
DEBUG - 2022-06-20 08:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:09:01 --> Input Class Initialized
INFO - 2022-06-20 08:09:01 --> Language Class Initialized
INFO - 2022-06-20 08:09:01 --> Language Class Initialized
INFO - 2022-06-20 08:09:01 --> Config Class Initialized
INFO - 2022-06-20 08:09:01 --> Loader Class Initialized
INFO - 2022-06-20 08:09:01 --> Helper loaded: url_helper
INFO - 2022-06-20 08:09:01 --> Database Driver Class Initialized
INFO - 2022-06-20 08:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:09:01 --> Model Class Initialized
DEBUG - 2022-06-20 08:09:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:09:01 --> Model Class Initialized
INFO - 2022-06-20 08:09:01 --> Controller Class Initialized
DEBUG - 2022-06-20 08:09:01 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:09:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:09:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:09:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:09:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_category.php
DEBUG - 2022-06-20 08:09:01 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:09:01 --> Final output sent to browser
DEBUG - 2022-06-20 08:09:01 --> Total execution time: 0.0316
INFO - 2022-06-20 08:09:08 --> Config Class Initialized
INFO - 2022-06-20 08:09:08 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:09:08 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:09:08 --> Utf8 Class Initialized
INFO - 2022-06-20 08:09:08 --> URI Class Initialized
INFO - 2022-06-20 08:09:08 --> Router Class Initialized
INFO - 2022-06-20 08:09:08 --> Output Class Initialized
INFO - 2022-06-20 08:09:08 --> Security Class Initialized
DEBUG - 2022-06-20 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:09:08 --> Input Class Initialized
INFO - 2022-06-20 08:09:08 --> Language Class Initialized
INFO - 2022-06-20 08:09:08 --> Language Class Initialized
INFO - 2022-06-20 08:09:08 --> Config Class Initialized
INFO - 2022-06-20 08:09:08 --> Loader Class Initialized
INFO - 2022-06-20 08:09:08 --> Helper loaded: url_helper
INFO - 2022-06-20 08:09:08 --> Database Driver Class Initialized
INFO - 2022-06-20 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:09:08 --> Model Class Initialized
DEBUG - 2022-06-20 08:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:09:08 --> Model Class Initialized
INFO - 2022-06-20 08:09:08 --> Controller Class Initialized
DEBUG - 2022-06-20 08:09:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 08:09:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:09:08 --> Final output sent to browser
DEBUG - 2022-06-20 08:09:08 --> Total execution time: 0.0360
INFO - 2022-06-20 08:09:28 --> Config Class Initialized
INFO - 2022-06-20 08:09:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 08:09:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 08:09:28 --> Utf8 Class Initialized
INFO - 2022-06-20 08:09:28 --> URI Class Initialized
INFO - 2022-06-20 08:09:28 --> Router Class Initialized
INFO - 2022-06-20 08:09:28 --> Output Class Initialized
INFO - 2022-06-20 08:09:28 --> Security Class Initialized
DEBUG - 2022-06-20 08:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 08:09:28 --> Input Class Initialized
INFO - 2022-06-20 08:09:28 --> Language Class Initialized
INFO - 2022-06-20 08:09:28 --> Language Class Initialized
INFO - 2022-06-20 08:09:28 --> Config Class Initialized
INFO - 2022-06-20 08:09:28 --> Loader Class Initialized
INFO - 2022-06-20 08:09:28 --> Helper loaded: url_helper
INFO - 2022-06-20 08:09:28 --> Database Driver Class Initialized
INFO - 2022-06-20 08:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 08:09:28 --> Model Class Initialized
DEBUG - 2022-06-20 08:09:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 08:09:28 --> Model Class Initialized
INFO - 2022-06-20 08:09:28 --> Controller Class Initialized
DEBUG - 2022-06-20 08:09:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 08:09:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 08:09:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 08:09:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 08:09:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 08:09:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 08:09:28 --> Final output sent to browser
DEBUG - 2022-06-20 08:09:28 --> Total execution time: 0.0466
INFO - 2022-06-20 09:15:11 --> Config Class Initialized
INFO - 2022-06-20 09:15:11 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:15:11 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:15:11 --> Utf8 Class Initialized
INFO - 2022-06-20 09:15:11 --> URI Class Initialized
INFO - 2022-06-20 09:15:11 --> Router Class Initialized
INFO - 2022-06-20 09:15:11 --> Output Class Initialized
INFO - 2022-06-20 09:15:11 --> Security Class Initialized
DEBUG - 2022-06-20 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:15:11 --> Input Class Initialized
INFO - 2022-06-20 09:15:11 --> Language Class Initialized
INFO - 2022-06-20 09:15:11 --> Language Class Initialized
INFO - 2022-06-20 09:15:11 --> Config Class Initialized
INFO - 2022-06-20 09:15:11 --> Loader Class Initialized
INFO - 2022-06-20 09:15:11 --> Helper loaded: url_helper
INFO - 2022-06-20 09:15:11 --> Database Driver Class Initialized
INFO - 2022-06-20 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:15:11 --> Model Class Initialized
DEBUG - 2022-06-20 09:15:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:15:11 --> Model Class Initialized
INFO - 2022-06-20 09:15:11 --> Controller Class Initialized
DEBUG - 2022-06-20 09:15:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:15:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:15:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:15:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:15:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 09:15:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:15:11 --> Final output sent to browser
DEBUG - 2022-06-20 09:15:11 --> Total execution time: 0.1220
INFO - 2022-06-20 09:15:44 --> Config Class Initialized
INFO - 2022-06-20 09:15:44 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:15:44 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:15:44 --> Utf8 Class Initialized
INFO - 2022-06-20 09:15:44 --> URI Class Initialized
INFO - 2022-06-20 09:15:44 --> Router Class Initialized
INFO - 2022-06-20 09:15:44 --> Output Class Initialized
INFO - 2022-06-20 09:15:44 --> Security Class Initialized
DEBUG - 2022-06-20 09:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:15:44 --> Input Class Initialized
INFO - 2022-06-20 09:15:44 --> Language Class Initialized
INFO - 2022-06-20 09:15:44 --> Language Class Initialized
INFO - 2022-06-20 09:15:44 --> Config Class Initialized
INFO - 2022-06-20 09:15:44 --> Loader Class Initialized
INFO - 2022-06-20 09:15:44 --> Helper loaded: url_helper
INFO - 2022-06-20 09:15:44 --> Database Driver Class Initialized
INFO - 2022-06-20 09:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:15:44 --> Model Class Initialized
DEBUG - 2022-06-20 09:15:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:15:44 --> Model Class Initialized
INFO - 2022-06-20 09:15:44 --> Controller Class Initialized
DEBUG - 2022-06-20 09:15:44 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:15:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:15:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:15:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:15:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 09:15:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:15:44 --> Final output sent to browser
DEBUG - 2022-06-20 09:15:44 --> Total execution time: 0.0357
INFO - 2022-06-20 09:16:03 --> Config Class Initialized
INFO - 2022-06-20 09:16:03 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:16:03 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:16:03 --> Utf8 Class Initialized
INFO - 2022-06-20 09:16:03 --> URI Class Initialized
INFO - 2022-06-20 09:16:03 --> Router Class Initialized
INFO - 2022-06-20 09:16:03 --> Output Class Initialized
INFO - 2022-06-20 09:16:03 --> Security Class Initialized
DEBUG - 2022-06-20 09:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:16:03 --> Input Class Initialized
INFO - 2022-06-20 09:16:03 --> Language Class Initialized
INFO - 2022-06-20 09:16:03 --> Language Class Initialized
INFO - 2022-06-20 09:16:03 --> Config Class Initialized
INFO - 2022-06-20 09:16:03 --> Loader Class Initialized
INFO - 2022-06-20 09:16:03 --> Helper loaded: url_helper
INFO - 2022-06-20 09:16:03 --> Database Driver Class Initialized
INFO - 2022-06-20 09:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:16:03 --> Model Class Initialized
DEBUG - 2022-06-20 09:16:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:16:03 --> Model Class Initialized
INFO - 2022-06-20 09:16:03 --> Controller Class Initialized
DEBUG - 2022-06-20 09:16:03 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:16:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:16:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:16:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:16:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 09:16:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:16:03 --> Final output sent to browser
DEBUG - 2022-06-20 09:16:03 --> Total execution time: 0.0390
INFO - 2022-06-20 09:16:32 --> Config Class Initialized
INFO - 2022-06-20 09:16:32 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:16:32 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:16:32 --> Utf8 Class Initialized
INFO - 2022-06-20 09:16:32 --> URI Class Initialized
INFO - 2022-06-20 09:16:32 --> Router Class Initialized
INFO - 2022-06-20 09:16:32 --> Output Class Initialized
INFO - 2022-06-20 09:16:32 --> Security Class Initialized
DEBUG - 2022-06-20 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:16:32 --> Input Class Initialized
INFO - 2022-06-20 09:16:32 --> Language Class Initialized
INFO - 2022-06-20 09:16:32 --> Language Class Initialized
INFO - 2022-06-20 09:16:32 --> Config Class Initialized
INFO - 2022-06-20 09:16:32 --> Loader Class Initialized
INFO - 2022-06-20 09:16:32 --> Helper loaded: url_helper
INFO - 2022-06-20 09:16:32 --> Database Driver Class Initialized
INFO - 2022-06-20 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:16:32 --> Model Class Initialized
DEBUG - 2022-06-20 09:16:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:16:32 --> Model Class Initialized
INFO - 2022-06-20 09:16:32 --> Controller Class Initialized
DEBUG - 2022-06-20 09:16:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:16:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:16:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:16:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:16:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 09:16:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:16:32 --> Final output sent to browser
DEBUG - 2022-06-20 09:16:32 --> Total execution time: 0.0341
INFO - 2022-06-20 09:16:39 --> Config Class Initialized
INFO - 2022-06-20 09:16:39 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:16:39 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:16:39 --> Utf8 Class Initialized
INFO - 2022-06-20 09:16:39 --> URI Class Initialized
INFO - 2022-06-20 09:16:39 --> Router Class Initialized
INFO - 2022-06-20 09:16:39 --> Output Class Initialized
INFO - 2022-06-20 09:16:39 --> Security Class Initialized
DEBUG - 2022-06-20 09:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:16:39 --> Input Class Initialized
INFO - 2022-06-20 09:16:39 --> Language Class Initialized
INFO - 2022-06-20 09:16:39 --> Language Class Initialized
INFO - 2022-06-20 09:16:39 --> Config Class Initialized
INFO - 2022-06-20 09:16:39 --> Loader Class Initialized
INFO - 2022-06-20 09:16:39 --> Helper loaded: url_helper
INFO - 2022-06-20 09:16:39 --> Database Driver Class Initialized
INFO - 2022-06-20 09:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:16:39 --> Model Class Initialized
DEBUG - 2022-06-20 09:16:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:16:39 --> Model Class Initialized
INFO - 2022-06-20 09:16:39 --> Controller Class Initialized
DEBUG - 2022-06-20 09:16:39 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:16:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:16:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:16:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:16:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_interest.php
DEBUG - 2022-06-20 09:16:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:16:39 --> Final output sent to browser
DEBUG - 2022-06-20 09:16:39 --> Total execution time: 0.0343
INFO - 2022-06-20 09:17:37 --> Config Class Initialized
INFO - 2022-06-20 09:17:37 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:17:37 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:17:37 --> Utf8 Class Initialized
INFO - 2022-06-20 09:17:37 --> URI Class Initialized
INFO - 2022-06-20 09:17:37 --> Router Class Initialized
INFO - 2022-06-20 09:17:37 --> Output Class Initialized
INFO - 2022-06-20 09:17:37 --> Security Class Initialized
DEBUG - 2022-06-20 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:17:37 --> Input Class Initialized
INFO - 2022-06-20 09:17:37 --> Language Class Initialized
INFO - 2022-06-20 09:17:37 --> Language Class Initialized
INFO - 2022-06-20 09:17:37 --> Config Class Initialized
INFO - 2022-06-20 09:17:37 --> Loader Class Initialized
INFO - 2022-06-20 09:17:37 --> Helper loaded: url_helper
INFO - 2022-06-20 09:17:37 --> Database Driver Class Initialized
INFO - 2022-06-20 09:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:17:37 --> Model Class Initialized
DEBUG - 2022-06-20 09:17:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:17:37 --> Model Class Initialized
INFO - 2022-06-20 09:17:37 --> Controller Class Initialized
DEBUG - 2022-06-20 09:17:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:17:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:17:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:17:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:17:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_subcategory.php
DEBUG - 2022-06-20 09:17:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:17:37 --> Final output sent to browser
DEBUG - 2022-06-20 09:17:37 --> Total execution time: 0.0620
INFO - 2022-06-20 09:17:56 --> Config Class Initialized
INFO - 2022-06-20 09:17:56 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:17:56 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:17:56 --> Utf8 Class Initialized
INFO - 2022-06-20 09:17:56 --> URI Class Initialized
INFO - 2022-06-20 09:17:56 --> Router Class Initialized
INFO - 2022-06-20 09:17:56 --> Output Class Initialized
INFO - 2022-06-20 09:17:56 --> Security Class Initialized
DEBUG - 2022-06-20 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:17:56 --> Input Class Initialized
INFO - 2022-06-20 09:17:56 --> Language Class Initialized
INFO - 2022-06-20 09:17:56 --> Language Class Initialized
INFO - 2022-06-20 09:17:56 --> Config Class Initialized
INFO - 2022-06-20 09:17:56 --> Loader Class Initialized
INFO - 2022-06-20 09:17:56 --> Helper loaded: url_helper
INFO - 2022-06-20 09:17:56 --> Database Driver Class Initialized
INFO - 2022-06-20 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:17:56 --> Model Class Initialized
DEBUG - 2022-06-20 09:17:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:17:56 --> Model Class Initialized
INFO - 2022-06-20 09:17:56 --> Controller Class Initialized
DEBUG - 2022-06-20 09:17:56 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:17:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:17:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:17:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:17:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 09:17:56 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:17:56 --> Final output sent to browser
DEBUG - 2022-06-20 09:17:56 --> Total execution time: 0.0520
INFO - 2022-06-20 09:25:24 --> Config Class Initialized
INFO - 2022-06-20 09:25:24 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:25:24 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:25:24 --> Utf8 Class Initialized
INFO - 2022-06-20 09:25:24 --> URI Class Initialized
INFO - 2022-06-20 09:25:24 --> Router Class Initialized
INFO - 2022-06-20 09:25:24 --> Output Class Initialized
INFO - 2022-06-20 09:25:24 --> Security Class Initialized
DEBUG - 2022-06-20 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:25:24 --> Input Class Initialized
INFO - 2022-06-20 09:25:24 --> Language Class Initialized
INFO - 2022-06-20 09:25:24 --> Language Class Initialized
INFO - 2022-06-20 09:25:24 --> Config Class Initialized
INFO - 2022-06-20 09:25:24 --> Loader Class Initialized
INFO - 2022-06-20 09:25:24 --> Helper loaded: url_helper
INFO - 2022-06-20 09:25:24 --> Database Driver Class Initialized
INFO - 2022-06-20 09:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:25:24 --> Model Class Initialized
DEBUG - 2022-06-20 09:25:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:25:24 --> Model Class Initialized
INFO - 2022-06-20 09:25:24 --> Controller Class Initialized
DEBUG - 2022-06-20 09:25:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:25:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:25:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:25:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:25:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 09:25:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:25:24 --> Final output sent to browser
DEBUG - 2022-06-20 09:25:24 --> Total execution time: 0.0269
INFO - 2022-06-20 09:25:25 --> Config Class Initialized
INFO - 2022-06-20 09:25:25 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:25:25 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:25:25 --> Utf8 Class Initialized
INFO - 2022-06-20 09:25:25 --> URI Class Initialized
INFO - 2022-06-20 09:25:25 --> Router Class Initialized
INFO - 2022-06-20 09:25:25 --> Output Class Initialized
INFO - 2022-06-20 09:25:25 --> Security Class Initialized
DEBUG - 2022-06-20 09:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:25:25 --> Input Class Initialized
INFO - 2022-06-20 09:25:25 --> Language Class Initialized
INFO - 2022-06-20 09:25:25 --> Language Class Initialized
INFO - 2022-06-20 09:25:25 --> Config Class Initialized
INFO - 2022-06-20 09:25:25 --> Loader Class Initialized
INFO - 2022-06-20 09:25:25 --> Helper loaded: url_helper
INFO - 2022-06-20 09:25:25 --> Database Driver Class Initialized
INFO - 2022-06-20 09:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:25:25 --> Model Class Initialized
DEBUG - 2022-06-20 09:25:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:25:25 --> Model Class Initialized
INFO - 2022-06-20 09:25:25 --> Controller Class Initialized
DEBUG - 2022-06-20 09:25:25 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:25:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:25:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:25:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:25:25 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 105
ERROR - 2022-06-20 09:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 105
DEBUG - 2022-06-20 09:25:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:25:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:25:25 --> Final output sent to browser
DEBUG - 2022-06-20 09:25:25 --> Total execution time: 0.0747
INFO - 2022-06-20 09:25:48 --> Config Class Initialized
INFO - 2022-06-20 09:25:48 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:25:48 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:25:48 --> Utf8 Class Initialized
INFO - 2022-06-20 09:25:48 --> URI Class Initialized
INFO - 2022-06-20 09:25:48 --> Router Class Initialized
INFO - 2022-06-20 09:25:48 --> Output Class Initialized
INFO - 2022-06-20 09:25:48 --> Security Class Initialized
DEBUG - 2022-06-20 09:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:25:48 --> Input Class Initialized
INFO - 2022-06-20 09:25:48 --> Language Class Initialized
INFO - 2022-06-20 09:25:48 --> Language Class Initialized
INFO - 2022-06-20 09:25:48 --> Config Class Initialized
INFO - 2022-06-20 09:25:48 --> Loader Class Initialized
INFO - 2022-06-20 09:25:48 --> Helper loaded: url_helper
INFO - 2022-06-20 09:25:48 --> Database Driver Class Initialized
INFO - 2022-06-20 09:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:25:48 --> Model Class Initialized
DEBUG - 2022-06-20 09:25:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:25:48 --> Model Class Initialized
INFO - 2022-06-20 09:25:48 --> Controller Class Initialized
DEBUG - 2022-06-20 09:25:48 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:25:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:25:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:25:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:25:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_community.php
DEBUG - 2022-06-20 09:25:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:25:48 --> Final output sent to browser
DEBUG - 2022-06-20 09:25:48 --> Total execution time: 0.0404
INFO - 2022-06-20 09:25:51 --> Config Class Initialized
INFO - 2022-06-20 09:25:51 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:25:51 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:25:51 --> Utf8 Class Initialized
INFO - 2022-06-20 09:25:51 --> URI Class Initialized
INFO - 2022-06-20 09:25:51 --> Router Class Initialized
INFO - 2022-06-20 09:25:51 --> Output Class Initialized
INFO - 2022-06-20 09:25:51 --> Security Class Initialized
DEBUG - 2022-06-20 09:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:25:51 --> Input Class Initialized
INFO - 2022-06-20 09:25:51 --> Language Class Initialized
INFO - 2022-06-20 09:25:51 --> Language Class Initialized
INFO - 2022-06-20 09:25:51 --> Config Class Initialized
INFO - 2022-06-20 09:25:51 --> Loader Class Initialized
INFO - 2022-06-20 09:25:51 --> Helper loaded: url_helper
INFO - 2022-06-20 09:25:51 --> Database Driver Class Initialized
INFO - 2022-06-20 09:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:25:51 --> Model Class Initialized
DEBUG - 2022-06-20 09:25:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:25:51 --> Model Class Initialized
INFO - 2022-06-20 09:25:51 --> Controller Class Initialized
DEBUG - 2022-06-20 09:25:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:25:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:25:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:25:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 09:25:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_socialmedia.php
DEBUG - 2022-06-20 09:25:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:25:51 --> Final output sent to browser
DEBUG - 2022-06-20 09:25:51 --> Total execution time: 0.0313
INFO - 2022-06-20 09:25:57 --> Config Class Initialized
INFO - 2022-06-20 09:25:57 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:25:57 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:25:57 --> Utf8 Class Initialized
INFO - 2022-06-20 09:25:57 --> URI Class Initialized
INFO - 2022-06-20 09:25:57 --> Router Class Initialized
INFO - 2022-06-20 09:25:57 --> Output Class Initialized
INFO - 2022-06-20 09:25:57 --> Security Class Initialized
DEBUG - 2022-06-20 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:25:57 --> Input Class Initialized
INFO - 2022-06-20 09:25:57 --> Language Class Initialized
INFO - 2022-06-20 09:25:57 --> Language Class Initialized
INFO - 2022-06-20 09:25:57 --> Config Class Initialized
INFO - 2022-06-20 09:25:57 --> Loader Class Initialized
INFO - 2022-06-20 09:25:57 --> Helper loaded: url_helper
INFO - 2022-06-20 09:25:57 --> Database Driver Class Initialized
INFO - 2022-06-20 09:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:25:57 --> Model Class Initialized
DEBUG - 2022-06-20 09:25:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:25:57 --> Model Class Initialized
INFO - 2022-06-20 09:25:57 --> Controller Class Initialized
DEBUG - 2022-06-20 09:25:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:25:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:25:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:25:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:25:57 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 105
ERROR - 2022-06-20 09:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 105
DEBUG - 2022-06-20 09:25:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:25:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:25:57 --> Final output sent to browser
DEBUG - 2022-06-20 09:25:57 --> Total execution time: 0.0312
INFO - 2022-06-20 09:28:59 --> Config Class Initialized
INFO - 2022-06-20 09:28:59 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:28:59 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:28:59 --> Utf8 Class Initialized
INFO - 2022-06-20 09:28:59 --> URI Class Initialized
INFO - 2022-06-20 09:28:59 --> Router Class Initialized
INFO - 2022-06-20 09:28:59 --> Output Class Initialized
INFO - 2022-06-20 09:28:59 --> Security Class Initialized
DEBUG - 2022-06-20 09:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:29:00 --> Input Class Initialized
INFO - 2022-06-20 09:29:00 --> Language Class Initialized
INFO - 2022-06-20 09:29:00 --> Language Class Initialized
INFO - 2022-06-20 09:29:00 --> Config Class Initialized
INFO - 2022-06-20 09:29:00 --> Loader Class Initialized
INFO - 2022-06-20 09:29:00 --> Helper loaded: url_helper
INFO - 2022-06-20 09:29:00 --> Database Driver Class Initialized
INFO - 2022-06-20 09:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:29:00 --> Model Class Initialized
DEBUG - 2022-06-20 09:29:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:29:00 --> Model Class Initialized
INFO - 2022-06-20 09:29:00 --> Controller Class Initialized
DEBUG - 2022-06-20 09:29:00 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:29:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:29:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:29:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:29:00 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 36
ERROR - 2022-06-20 09:29:00 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 36
ERROR - 2022-06-20 09:29:00 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
ERROR - 2022-06-20 09:29:00 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
DEBUG - 2022-06-20 09:29:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:29:00 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:29:00 --> Final output sent to browser
DEBUG - 2022-06-20 09:29:00 --> Total execution time: 0.2107
INFO - 2022-06-20 09:29:05 --> Config Class Initialized
INFO - 2022-06-20 09:29:05 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:29:05 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:29:05 --> Utf8 Class Initialized
INFO - 2022-06-20 09:29:05 --> URI Class Initialized
INFO - 2022-06-20 09:29:05 --> Router Class Initialized
INFO - 2022-06-20 09:29:05 --> Output Class Initialized
INFO - 2022-06-20 09:29:05 --> Security Class Initialized
DEBUG - 2022-06-20 09:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:29:05 --> Input Class Initialized
INFO - 2022-06-20 09:29:05 --> Language Class Initialized
INFO - 2022-06-20 09:29:05 --> Language Class Initialized
INFO - 2022-06-20 09:29:05 --> Config Class Initialized
INFO - 2022-06-20 09:29:05 --> Loader Class Initialized
INFO - 2022-06-20 09:29:05 --> Helper loaded: url_helper
INFO - 2022-06-20 09:29:05 --> Database Driver Class Initialized
INFO - 2022-06-20 09:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:29:05 --> Model Class Initialized
DEBUG - 2022-06-20 09:29:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:29:05 --> Model Class Initialized
INFO - 2022-06-20 09:29:05 --> Controller Class Initialized
DEBUG - 2022-06-20 09:29:05 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:29:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:29:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:29:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:29:05 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 36
ERROR - 2022-06-20 09:29:05 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 36
ERROR - 2022-06-20 09:29:05 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
ERROR - 2022-06-20 09:29:05 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
DEBUG - 2022-06-20 09:29:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:29:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:29:05 --> Final output sent to browser
DEBUG - 2022-06-20 09:29:05 --> Total execution time: 0.0366
INFO - 2022-06-20 09:29:21 --> Config Class Initialized
INFO - 2022-06-20 09:29:21 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:29:21 --> Utf8 Class Initialized
INFO - 2022-06-20 09:29:21 --> URI Class Initialized
INFO - 2022-06-20 09:29:21 --> Router Class Initialized
INFO - 2022-06-20 09:29:21 --> Output Class Initialized
INFO - 2022-06-20 09:29:21 --> Security Class Initialized
DEBUG - 2022-06-20 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:29:21 --> Input Class Initialized
INFO - 2022-06-20 09:29:21 --> Language Class Initialized
INFO - 2022-06-20 09:29:21 --> Language Class Initialized
INFO - 2022-06-20 09:29:21 --> Config Class Initialized
INFO - 2022-06-20 09:29:21 --> Loader Class Initialized
INFO - 2022-06-20 09:29:21 --> Helper loaded: url_helper
INFO - 2022-06-20 09:29:21 --> Database Driver Class Initialized
INFO - 2022-06-20 09:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:29:21 --> Model Class Initialized
DEBUG - 2022-06-20 09:29:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:29:21 --> Model Class Initialized
INFO - 2022-06-20 09:29:21 --> Controller Class Initialized
DEBUG - 2022-06-20 09:29:21 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:29:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:29:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:29:21 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:29:21 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 3
INFO - 2022-06-20 09:29:37 --> Config Class Initialized
INFO - 2022-06-20 09:29:37 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:29:37 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:29:37 --> Utf8 Class Initialized
INFO - 2022-06-20 09:29:37 --> URI Class Initialized
INFO - 2022-06-20 09:29:37 --> Router Class Initialized
INFO - 2022-06-20 09:29:37 --> Output Class Initialized
INFO - 2022-06-20 09:29:37 --> Security Class Initialized
DEBUG - 2022-06-20 09:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:29:37 --> Input Class Initialized
INFO - 2022-06-20 09:29:37 --> Language Class Initialized
INFO - 2022-06-20 09:29:37 --> Language Class Initialized
INFO - 2022-06-20 09:29:37 --> Config Class Initialized
INFO - 2022-06-20 09:29:37 --> Loader Class Initialized
INFO - 2022-06-20 09:29:37 --> Helper loaded: url_helper
INFO - 2022-06-20 09:29:37 --> Database Driver Class Initialized
INFO - 2022-06-20 09:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:29:37 --> Model Class Initialized
DEBUG - 2022-06-20 09:29:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:29:37 --> Model Class Initialized
INFO - 2022-06-20 09:29:37 --> Controller Class Initialized
DEBUG - 2022-06-20 09:29:37 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:29:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:29:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:29:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:29:37 --> Severity: Notice --> Undefined index: title N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 37
ERROR - 2022-06-20 09:29:37 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
ERROR - 2022-06-20 09:29:37 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
DEBUG - 2022-06-20 09:29:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:29:37 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:29:37 --> Final output sent to browser
DEBUG - 2022-06-20 09:29:37 --> Total execution time: 0.0464
INFO - 2022-06-20 09:31:12 --> Config Class Initialized
INFO - 2022-06-20 09:31:12 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:31:12 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:31:12 --> Utf8 Class Initialized
INFO - 2022-06-20 09:31:12 --> URI Class Initialized
INFO - 2022-06-20 09:31:12 --> Router Class Initialized
INFO - 2022-06-20 09:31:12 --> Output Class Initialized
INFO - 2022-06-20 09:31:12 --> Security Class Initialized
DEBUG - 2022-06-20 09:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:31:12 --> Input Class Initialized
INFO - 2022-06-20 09:31:12 --> Language Class Initialized
INFO - 2022-06-20 09:31:12 --> Language Class Initialized
INFO - 2022-06-20 09:31:12 --> Config Class Initialized
INFO - 2022-06-20 09:31:12 --> Loader Class Initialized
INFO - 2022-06-20 09:31:12 --> Helper loaded: url_helper
INFO - 2022-06-20 09:31:12 --> Database Driver Class Initialized
INFO - 2022-06-20 09:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:31:12 --> Model Class Initialized
DEBUG - 2022-06-20 09:31:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:31:12 --> Model Class Initialized
INFO - 2022-06-20 09:31:12 --> Controller Class Initialized
DEBUG - 2022-06-20 09:31:12 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:31:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:31:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:31:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:31:12 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
ERROR - 2022-06-20 09:31:12 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
DEBUG - 2022-06-20 09:31:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:31:12 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:31:12 --> Final output sent to browser
DEBUG - 2022-06-20 09:31:12 --> Total execution time: 0.0386
INFO - 2022-06-20 09:31:34 --> Config Class Initialized
INFO - 2022-06-20 09:31:34 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:31:34 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:31:34 --> Utf8 Class Initialized
INFO - 2022-06-20 09:31:34 --> URI Class Initialized
INFO - 2022-06-20 09:31:34 --> Router Class Initialized
INFO - 2022-06-20 09:31:34 --> Output Class Initialized
INFO - 2022-06-20 09:31:34 --> Security Class Initialized
DEBUG - 2022-06-20 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:31:34 --> Input Class Initialized
INFO - 2022-06-20 09:31:34 --> Language Class Initialized
INFO - 2022-06-20 09:31:34 --> Language Class Initialized
INFO - 2022-06-20 09:31:34 --> Config Class Initialized
INFO - 2022-06-20 09:31:34 --> Loader Class Initialized
INFO - 2022-06-20 09:31:34 --> Helper loaded: url_helper
INFO - 2022-06-20 09:31:34 --> Database Driver Class Initialized
INFO - 2022-06-20 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:31:34 --> Model Class Initialized
DEBUG - 2022-06-20 09:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:31:34 --> Model Class Initialized
INFO - 2022-06-20 09:31:34 --> Controller Class Initialized
DEBUG - 2022-06-20 09:31:34 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:31:34 --> Severity: Notice --> Undefined index: title N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 37
ERROR - 2022-06-20 09:31:34 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
ERROR - 2022-06-20 09:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
DEBUG - 2022-06-20 09:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:31:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:31:34 --> Final output sent to browser
DEBUG - 2022-06-20 09:31:34 --> Total execution time: 0.0390
INFO - 2022-06-20 09:32:52 --> Config Class Initialized
INFO - 2022-06-20 09:32:52 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:32:52 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:32:52 --> Utf8 Class Initialized
INFO - 2022-06-20 09:32:52 --> URI Class Initialized
INFO - 2022-06-20 09:32:52 --> Router Class Initialized
INFO - 2022-06-20 09:32:52 --> Output Class Initialized
INFO - 2022-06-20 09:32:52 --> Security Class Initialized
DEBUG - 2022-06-20 09:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:32:52 --> Input Class Initialized
INFO - 2022-06-20 09:32:52 --> Language Class Initialized
INFO - 2022-06-20 09:32:52 --> Language Class Initialized
INFO - 2022-06-20 09:32:52 --> Config Class Initialized
INFO - 2022-06-20 09:32:52 --> Loader Class Initialized
INFO - 2022-06-20 09:32:52 --> Helper loaded: url_helper
INFO - 2022-06-20 09:32:52 --> Database Driver Class Initialized
INFO - 2022-06-20 09:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:32:52 --> Model Class Initialized
DEBUG - 2022-06-20 09:32:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:32:52 --> Model Class Initialized
INFO - 2022-06-20 09:32:52 --> Controller Class Initialized
DEBUG - 2022-06-20 09:32:52 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:32:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:32:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:32:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:32:52 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
ERROR - 2022-06-20 09:32:52 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 107
DEBUG - 2022-06-20 09:32:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:32:52 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:32:52 --> Final output sent to browser
DEBUG - 2022-06-20 09:32:52 --> Total execution time: 0.0389
INFO - 2022-06-20 09:33:55 --> Config Class Initialized
INFO - 2022-06-20 09:33:55 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:33:55 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:33:55 --> Utf8 Class Initialized
INFO - 2022-06-20 09:33:55 --> URI Class Initialized
INFO - 2022-06-20 09:33:55 --> Router Class Initialized
INFO - 2022-06-20 09:33:55 --> Output Class Initialized
INFO - 2022-06-20 09:33:55 --> Security Class Initialized
DEBUG - 2022-06-20 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:33:55 --> Input Class Initialized
INFO - 2022-06-20 09:33:55 --> Language Class Initialized
INFO - 2022-06-20 09:33:55 --> Language Class Initialized
INFO - 2022-06-20 09:33:55 --> Config Class Initialized
INFO - 2022-06-20 09:33:55 --> Loader Class Initialized
INFO - 2022-06-20 09:33:55 --> Helper loaded: url_helper
INFO - 2022-06-20 09:33:55 --> Database Driver Class Initialized
INFO - 2022-06-20 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:33:55 --> Model Class Initialized
DEBUG - 2022-06-20 09:33:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:33:55 --> Model Class Initialized
INFO - 2022-06-20 09:33:55 --> Controller Class Initialized
DEBUG - 2022-06-20 09:33:55 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:33:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:33:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:33:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:33:55 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 106
ERROR - 2022-06-20 09:33:55 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 106
DEBUG - 2022-06-20 09:33:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:33:55 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:33:55 --> Final output sent to browser
DEBUG - 2022-06-20 09:33:55 --> Total execution time: 0.0439
INFO - 2022-06-20 09:34:34 --> Config Class Initialized
INFO - 2022-06-20 09:34:34 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:34:34 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:34:34 --> Utf8 Class Initialized
INFO - 2022-06-20 09:34:34 --> URI Class Initialized
INFO - 2022-06-20 09:34:34 --> Router Class Initialized
INFO - 2022-06-20 09:34:34 --> Output Class Initialized
INFO - 2022-06-20 09:34:34 --> Security Class Initialized
DEBUG - 2022-06-20 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:34:34 --> Input Class Initialized
INFO - 2022-06-20 09:34:34 --> Language Class Initialized
INFO - 2022-06-20 09:34:34 --> Language Class Initialized
INFO - 2022-06-20 09:34:34 --> Config Class Initialized
INFO - 2022-06-20 09:34:34 --> Loader Class Initialized
INFO - 2022-06-20 09:34:34 --> Helper loaded: url_helper
INFO - 2022-06-20 09:34:34 --> Database Driver Class Initialized
INFO - 2022-06-20 09:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:34:34 --> Model Class Initialized
DEBUG - 2022-06-20 09:34:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:34:34 --> Model Class Initialized
INFO - 2022-06-20 09:34:34 --> Controller Class Initialized
DEBUG - 2022-06-20 09:34:34 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:34:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:34:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:34:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:34:34 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:34:34 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:34:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:34:34 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:34:34 --> Final output sent to browser
DEBUG - 2022-06-20 09:34:34 --> Total execution time: 0.0357
INFO - 2022-06-20 09:38:25 --> Config Class Initialized
INFO - 2022-06-20 09:38:25 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:38:25 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:38:25 --> Utf8 Class Initialized
INFO - 2022-06-20 09:38:25 --> URI Class Initialized
INFO - 2022-06-20 09:38:25 --> Router Class Initialized
INFO - 2022-06-20 09:38:25 --> Output Class Initialized
INFO - 2022-06-20 09:38:25 --> Security Class Initialized
DEBUG - 2022-06-20 09:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:38:25 --> Input Class Initialized
INFO - 2022-06-20 09:38:25 --> Language Class Initialized
INFO - 2022-06-20 09:38:25 --> Language Class Initialized
INFO - 2022-06-20 09:38:25 --> Config Class Initialized
INFO - 2022-06-20 09:38:25 --> Loader Class Initialized
INFO - 2022-06-20 09:38:25 --> Helper loaded: url_helper
INFO - 2022-06-20 09:38:25 --> Database Driver Class Initialized
INFO - 2022-06-20 09:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:38:25 --> Model Class Initialized
DEBUG - 2022-06-20 09:38:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:38:25 --> Model Class Initialized
INFO - 2022-06-20 09:38:25 --> Controller Class Initialized
DEBUG - 2022-06-20 09:38:25 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:38:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:38:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:38:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:38:25 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:38:25 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:38:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:38:25 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:38:25 --> Final output sent to browser
DEBUG - 2022-06-20 09:38:25 --> Total execution time: 0.0414
INFO - 2022-06-20 09:38:51 --> Config Class Initialized
INFO - 2022-06-20 09:38:51 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:38:51 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:38:51 --> Utf8 Class Initialized
INFO - 2022-06-20 09:38:51 --> URI Class Initialized
INFO - 2022-06-20 09:38:51 --> Router Class Initialized
INFO - 2022-06-20 09:38:51 --> Output Class Initialized
INFO - 2022-06-20 09:38:51 --> Security Class Initialized
DEBUG - 2022-06-20 09:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:38:51 --> Input Class Initialized
INFO - 2022-06-20 09:38:51 --> Language Class Initialized
INFO - 2022-06-20 09:38:51 --> Language Class Initialized
INFO - 2022-06-20 09:38:51 --> Config Class Initialized
INFO - 2022-06-20 09:38:51 --> Loader Class Initialized
INFO - 2022-06-20 09:38:51 --> Helper loaded: url_helper
INFO - 2022-06-20 09:38:51 --> Database Driver Class Initialized
INFO - 2022-06-20 09:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:38:51 --> Model Class Initialized
DEBUG - 2022-06-20 09:38:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:38:51 --> Model Class Initialized
INFO - 2022-06-20 09:38:51 --> Controller Class Initialized
DEBUG - 2022-06-20 09:38:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:38:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:38:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:38:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:38:51 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:38:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:38:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:38:51 --> Final output sent to browser
DEBUG - 2022-06-20 09:38:51 --> Total execution time: 0.0379
INFO - 2022-06-20 09:39:30 --> Config Class Initialized
INFO - 2022-06-20 09:39:30 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:39:30 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:39:30 --> Utf8 Class Initialized
INFO - 2022-06-20 09:39:30 --> URI Class Initialized
INFO - 2022-06-20 09:39:30 --> Router Class Initialized
INFO - 2022-06-20 09:39:30 --> Output Class Initialized
INFO - 2022-06-20 09:39:30 --> Security Class Initialized
DEBUG - 2022-06-20 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:39:30 --> Input Class Initialized
INFO - 2022-06-20 09:39:30 --> Language Class Initialized
INFO - 2022-06-20 09:39:30 --> Language Class Initialized
INFO - 2022-06-20 09:39:30 --> Config Class Initialized
INFO - 2022-06-20 09:39:30 --> Loader Class Initialized
INFO - 2022-06-20 09:39:30 --> Helper loaded: url_helper
INFO - 2022-06-20 09:39:30 --> Database Driver Class Initialized
INFO - 2022-06-20 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:39:30 --> Model Class Initialized
DEBUG - 2022-06-20 09:39:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:39:30 --> Model Class Initialized
INFO - 2022-06-20 09:39:30 --> Controller Class Initialized
DEBUG - 2022-06-20 09:39:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:39:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:39:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:39:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:39:30 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:39:30 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:39:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:39:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:39:30 --> Final output sent to browser
DEBUG - 2022-06-20 09:39:30 --> Total execution time: 0.0312
INFO - 2022-06-20 09:39:41 --> Config Class Initialized
INFO - 2022-06-20 09:39:41 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:39:41 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:39:41 --> Utf8 Class Initialized
INFO - 2022-06-20 09:39:41 --> URI Class Initialized
INFO - 2022-06-20 09:39:41 --> Router Class Initialized
INFO - 2022-06-20 09:39:41 --> Output Class Initialized
INFO - 2022-06-20 09:39:41 --> Security Class Initialized
DEBUG - 2022-06-20 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:39:41 --> Input Class Initialized
INFO - 2022-06-20 09:39:41 --> Language Class Initialized
INFO - 2022-06-20 09:39:41 --> Language Class Initialized
INFO - 2022-06-20 09:39:41 --> Config Class Initialized
INFO - 2022-06-20 09:39:41 --> Loader Class Initialized
INFO - 2022-06-20 09:39:41 --> Helper loaded: url_helper
INFO - 2022-06-20 09:39:41 --> Database Driver Class Initialized
INFO - 2022-06-20 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:39:41 --> Model Class Initialized
DEBUG - 2022-06-20 09:39:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:39:41 --> Model Class Initialized
INFO - 2022-06-20 09:39:41 --> Controller Class Initialized
DEBUG - 2022-06-20 09:39:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:39:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:39:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:39:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:39:41 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:39:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:39:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:39:41 --> Final output sent to browser
DEBUG - 2022-06-20 09:39:41 --> Total execution time: 0.0407
INFO - 2022-06-20 09:40:30 --> Config Class Initialized
INFO - 2022-06-20 09:40:30 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:40:30 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:40:30 --> Utf8 Class Initialized
INFO - 2022-06-20 09:40:30 --> URI Class Initialized
INFO - 2022-06-20 09:40:30 --> Router Class Initialized
INFO - 2022-06-20 09:40:30 --> Output Class Initialized
INFO - 2022-06-20 09:40:30 --> Security Class Initialized
DEBUG - 2022-06-20 09:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:40:30 --> Input Class Initialized
INFO - 2022-06-20 09:40:30 --> Language Class Initialized
INFO - 2022-06-20 09:40:30 --> Language Class Initialized
INFO - 2022-06-20 09:40:30 --> Config Class Initialized
INFO - 2022-06-20 09:40:30 --> Loader Class Initialized
INFO - 2022-06-20 09:40:30 --> Helper loaded: url_helper
INFO - 2022-06-20 09:40:30 --> Database Driver Class Initialized
INFO - 2022-06-20 09:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:40:30 --> Model Class Initialized
DEBUG - 2022-06-20 09:40:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:40:30 --> Model Class Initialized
INFO - 2022-06-20 09:40:30 --> Controller Class Initialized
DEBUG - 2022-06-20 09:40:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:40:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:40:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:40:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:40:30 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:40:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:40:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:40:30 --> Final output sent to browser
DEBUG - 2022-06-20 09:40:30 --> Total execution time: 0.0377
INFO - 2022-06-20 09:43:41 --> Config Class Initialized
INFO - 2022-06-20 09:43:41 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:43:41 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:43:41 --> Utf8 Class Initialized
INFO - 2022-06-20 09:43:41 --> URI Class Initialized
INFO - 2022-06-20 09:43:41 --> Router Class Initialized
INFO - 2022-06-20 09:43:41 --> Output Class Initialized
INFO - 2022-06-20 09:43:41 --> Security Class Initialized
DEBUG - 2022-06-20 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:43:41 --> Input Class Initialized
INFO - 2022-06-20 09:43:41 --> Language Class Initialized
INFO - 2022-06-20 09:43:41 --> Language Class Initialized
INFO - 2022-06-20 09:43:41 --> Config Class Initialized
INFO - 2022-06-20 09:43:41 --> Loader Class Initialized
INFO - 2022-06-20 09:43:41 --> Helper loaded: url_helper
INFO - 2022-06-20 09:43:41 --> Database Driver Class Initialized
INFO - 2022-06-20 09:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:43:41 --> Model Class Initialized
DEBUG - 2022-06-20 09:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:43:41 --> Model Class Initialized
INFO - 2022-06-20 09:43:41 --> Controller Class Initialized
DEBUG - 2022-06-20 09:43:41 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:43:41 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:43:41 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:43:41 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:43:41 --> Final output sent to browser
DEBUG - 2022-06-20 09:43:41 --> Total execution time: 0.0314
INFO - 2022-06-20 09:44:53 --> Config Class Initialized
INFO - 2022-06-20 09:44:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:44:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:44:53 --> Utf8 Class Initialized
INFO - 2022-06-20 09:44:53 --> URI Class Initialized
INFO - 2022-06-20 09:44:53 --> Router Class Initialized
INFO - 2022-06-20 09:44:53 --> Output Class Initialized
INFO - 2022-06-20 09:44:53 --> Security Class Initialized
DEBUG - 2022-06-20 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:44:53 --> Input Class Initialized
INFO - 2022-06-20 09:44:53 --> Language Class Initialized
INFO - 2022-06-20 09:44:53 --> Language Class Initialized
INFO - 2022-06-20 09:44:53 --> Config Class Initialized
INFO - 2022-06-20 09:44:53 --> Loader Class Initialized
INFO - 2022-06-20 09:44:53 --> Helper loaded: url_helper
INFO - 2022-06-20 09:44:53 --> Database Driver Class Initialized
INFO - 2022-06-20 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:44:53 --> Model Class Initialized
DEBUG - 2022-06-20 09:44:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:44:53 --> Model Class Initialized
INFO - 2022-06-20 09:44:53 --> Controller Class Initialized
DEBUG - 2022-06-20 09:44:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:44:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:44:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:44:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:44:53 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:44:53 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:44:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:44:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:44:53 --> Final output sent to browser
DEBUG - 2022-06-20 09:44:53 --> Total execution time: 0.0399
INFO - 2022-06-20 09:45:18 --> Config Class Initialized
INFO - 2022-06-20 09:45:18 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:45:18 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:45:18 --> Utf8 Class Initialized
INFO - 2022-06-20 09:45:18 --> URI Class Initialized
INFO - 2022-06-20 09:45:18 --> Router Class Initialized
INFO - 2022-06-20 09:45:18 --> Output Class Initialized
INFO - 2022-06-20 09:45:18 --> Security Class Initialized
DEBUG - 2022-06-20 09:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:45:18 --> Input Class Initialized
INFO - 2022-06-20 09:45:18 --> Language Class Initialized
INFO - 2022-06-20 09:45:18 --> Language Class Initialized
INFO - 2022-06-20 09:45:18 --> Config Class Initialized
INFO - 2022-06-20 09:45:18 --> Loader Class Initialized
INFO - 2022-06-20 09:45:18 --> Helper loaded: url_helper
INFO - 2022-06-20 09:45:18 --> Database Driver Class Initialized
INFO - 2022-06-20 09:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:45:18 --> Model Class Initialized
DEBUG - 2022-06-20 09:45:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:45:18 --> Model Class Initialized
INFO - 2022-06-20 09:45:18 --> Controller Class Initialized
DEBUG - 2022-06-20 09:45:18 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:45:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:45:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:45:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:45:18 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:45:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:45:18 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:45:18 --> Final output sent to browser
DEBUG - 2022-06-20 09:45:18 --> Total execution time: 0.0448
INFO - 2022-06-20 09:45:30 --> Config Class Initialized
INFO - 2022-06-20 09:45:30 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:45:30 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:45:30 --> Utf8 Class Initialized
INFO - 2022-06-20 09:45:30 --> URI Class Initialized
INFO - 2022-06-20 09:45:30 --> Router Class Initialized
INFO - 2022-06-20 09:45:30 --> Output Class Initialized
INFO - 2022-06-20 09:45:30 --> Security Class Initialized
DEBUG - 2022-06-20 09:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:45:30 --> Input Class Initialized
INFO - 2022-06-20 09:45:30 --> Language Class Initialized
INFO - 2022-06-20 09:45:30 --> Language Class Initialized
INFO - 2022-06-20 09:45:30 --> Config Class Initialized
INFO - 2022-06-20 09:45:30 --> Loader Class Initialized
INFO - 2022-06-20 09:45:30 --> Helper loaded: url_helper
INFO - 2022-06-20 09:45:30 --> Database Driver Class Initialized
INFO - 2022-06-20 09:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:45:30 --> Model Class Initialized
DEBUG - 2022-06-20 09:45:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:45:30 --> Model Class Initialized
INFO - 2022-06-20 09:45:30 --> Controller Class Initialized
DEBUG - 2022-06-20 09:45:30 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:45:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:45:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:45:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:45:30 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:45:30 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:45:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:45:30 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:45:30 --> Final output sent to browser
DEBUG - 2022-06-20 09:45:30 --> Total execution time: 0.0401
INFO - 2022-06-20 09:45:46 --> Config Class Initialized
INFO - 2022-06-20 09:45:46 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:45:46 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:45:46 --> Utf8 Class Initialized
INFO - 2022-06-20 09:45:46 --> URI Class Initialized
INFO - 2022-06-20 09:45:46 --> Router Class Initialized
INFO - 2022-06-20 09:45:46 --> Output Class Initialized
INFO - 2022-06-20 09:45:46 --> Security Class Initialized
DEBUG - 2022-06-20 09:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:45:46 --> Input Class Initialized
INFO - 2022-06-20 09:45:46 --> Language Class Initialized
INFO - 2022-06-20 09:45:46 --> Language Class Initialized
INFO - 2022-06-20 09:45:46 --> Config Class Initialized
INFO - 2022-06-20 09:45:46 --> Loader Class Initialized
INFO - 2022-06-20 09:45:46 --> Helper loaded: url_helper
INFO - 2022-06-20 09:45:46 --> Database Driver Class Initialized
INFO - 2022-06-20 09:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:45:46 --> Model Class Initialized
DEBUG - 2022-06-20 09:45:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:45:46 --> Model Class Initialized
INFO - 2022-06-20 09:45:46 --> Controller Class Initialized
DEBUG - 2022-06-20 09:45:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:45:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:45:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:45:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:45:46 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:45:46 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:45:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:45:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:45:46 --> Final output sent to browser
DEBUG - 2022-06-20 09:45:46 --> Total execution time: 0.0297
INFO - 2022-06-20 09:46:45 --> Config Class Initialized
INFO - 2022-06-20 09:46:45 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:46:45 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:46:45 --> Utf8 Class Initialized
INFO - 2022-06-20 09:46:45 --> URI Class Initialized
INFO - 2022-06-20 09:46:45 --> Router Class Initialized
INFO - 2022-06-20 09:46:45 --> Output Class Initialized
INFO - 2022-06-20 09:46:45 --> Security Class Initialized
DEBUG - 2022-06-20 09:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:46:45 --> Input Class Initialized
INFO - 2022-06-20 09:46:45 --> Language Class Initialized
INFO - 2022-06-20 09:46:45 --> Language Class Initialized
INFO - 2022-06-20 09:46:45 --> Config Class Initialized
INFO - 2022-06-20 09:46:45 --> Loader Class Initialized
INFO - 2022-06-20 09:46:45 --> Helper loaded: url_helper
INFO - 2022-06-20 09:46:45 --> Database Driver Class Initialized
INFO - 2022-06-20 09:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:46:45 --> Model Class Initialized
DEBUG - 2022-06-20 09:46:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:46:45 --> Model Class Initialized
INFO - 2022-06-20 09:46:45 --> Controller Class Initialized
DEBUG - 2022-06-20 09:46:45 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:46:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:46:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:46:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:46:45 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:46:45 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:46:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:46:45 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:46:45 --> Final output sent to browser
DEBUG - 2022-06-20 09:46:45 --> Total execution time: 0.0382
INFO - 2022-06-20 09:46:53 --> Config Class Initialized
INFO - 2022-06-20 09:46:53 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:46:53 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:46:53 --> Utf8 Class Initialized
INFO - 2022-06-20 09:46:53 --> URI Class Initialized
INFO - 2022-06-20 09:46:53 --> Router Class Initialized
INFO - 2022-06-20 09:46:53 --> Output Class Initialized
INFO - 2022-06-20 09:46:53 --> Security Class Initialized
DEBUG - 2022-06-20 09:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:46:53 --> Input Class Initialized
INFO - 2022-06-20 09:46:53 --> Language Class Initialized
INFO - 2022-06-20 09:46:53 --> Language Class Initialized
INFO - 2022-06-20 09:46:53 --> Config Class Initialized
INFO - 2022-06-20 09:46:53 --> Loader Class Initialized
INFO - 2022-06-20 09:46:53 --> Helper loaded: url_helper
INFO - 2022-06-20 09:46:53 --> Database Driver Class Initialized
INFO - 2022-06-20 09:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:46:53 --> Model Class Initialized
DEBUG - 2022-06-20 09:46:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:46:53 --> Model Class Initialized
INFO - 2022-06-20 09:46:53 --> Controller Class Initialized
DEBUG - 2022-06-20 09:46:53 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:46:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:46:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:46:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:46:53 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:46:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:46:53 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:46:53 --> Final output sent to browser
DEBUG - 2022-06-20 09:46:53 --> Total execution time: 0.0449
INFO - 2022-06-20 09:47:23 --> Config Class Initialized
INFO - 2022-06-20 09:47:23 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:47:23 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:47:23 --> Utf8 Class Initialized
INFO - 2022-06-20 09:47:23 --> URI Class Initialized
INFO - 2022-06-20 09:47:23 --> Router Class Initialized
INFO - 2022-06-20 09:47:23 --> Output Class Initialized
INFO - 2022-06-20 09:47:23 --> Security Class Initialized
DEBUG - 2022-06-20 09:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:47:23 --> Input Class Initialized
INFO - 2022-06-20 09:47:23 --> Language Class Initialized
INFO - 2022-06-20 09:47:23 --> Language Class Initialized
INFO - 2022-06-20 09:47:23 --> Config Class Initialized
INFO - 2022-06-20 09:47:23 --> Loader Class Initialized
INFO - 2022-06-20 09:47:23 --> Helper loaded: url_helper
INFO - 2022-06-20 09:47:23 --> Database Driver Class Initialized
INFO - 2022-06-20 09:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:47:23 --> Model Class Initialized
DEBUG - 2022-06-20 09:47:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:47:23 --> Model Class Initialized
INFO - 2022-06-20 09:47:23 --> Controller Class Initialized
DEBUG - 2022-06-20 09:47:23 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:47:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:47:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:47:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:47:23 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:47:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:47:23 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:47:23 --> Final output sent to browser
DEBUG - 2022-06-20 09:47:23 --> Total execution time: 0.0368
INFO - 2022-06-20 09:49:09 --> Config Class Initialized
INFO - 2022-06-20 09:49:09 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:49:09 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:49:09 --> Utf8 Class Initialized
INFO - 2022-06-20 09:49:09 --> URI Class Initialized
INFO - 2022-06-20 09:49:09 --> Router Class Initialized
INFO - 2022-06-20 09:49:09 --> Output Class Initialized
INFO - 2022-06-20 09:49:09 --> Security Class Initialized
DEBUG - 2022-06-20 09:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:49:09 --> Input Class Initialized
INFO - 2022-06-20 09:49:09 --> Language Class Initialized
INFO - 2022-06-20 09:49:09 --> Language Class Initialized
INFO - 2022-06-20 09:49:09 --> Config Class Initialized
INFO - 2022-06-20 09:49:09 --> Loader Class Initialized
INFO - 2022-06-20 09:49:09 --> Helper loaded: url_helper
INFO - 2022-06-20 09:49:09 --> Database Driver Class Initialized
INFO - 2022-06-20 09:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:49:09 --> Model Class Initialized
DEBUG - 2022-06-20 09:49:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:49:09 --> Model Class Initialized
INFO - 2022-06-20 09:49:09 --> Controller Class Initialized
DEBUG - 2022-06-20 09:49:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:49:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:49:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:49:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:49:09 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:49:09 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:49:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:49:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:49:09 --> Final output sent to browser
DEBUG - 2022-06-20 09:49:09 --> Total execution time: 0.0267
INFO - 2022-06-20 09:49:57 --> Config Class Initialized
INFO - 2022-06-20 09:49:57 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:49:57 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:49:57 --> Utf8 Class Initialized
INFO - 2022-06-20 09:49:57 --> URI Class Initialized
INFO - 2022-06-20 09:49:57 --> Router Class Initialized
INFO - 2022-06-20 09:49:57 --> Output Class Initialized
INFO - 2022-06-20 09:49:57 --> Security Class Initialized
DEBUG - 2022-06-20 09:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:49:57 --> Input Class Initialized
INFO - 2022-06-20 09:49:57 --> Language Class Initialized
INFO - 2022-06-20 09:49:57 --> Language Class Initialized
INFO - 2022-06-20 09:49:57 --> Config Class Initialized
INFO - 2022-06-20 09:49:57 --> Loader Class Initialized
INFO - 2022-06-20 09:49:57 --> Helper loaded: url_helper
INFO - 2022-06-20 09:49:57 --> Database Driver Class Initialized
INFO - 2022-06-20 09:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:49:57 --> Model Class Initialized
DEBUG - 2022-06-20 09:49:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:49:57 --> Model Class Initialized
INFO - 2022-06-20 09:49:57 --> Controller Class Initialized
DEBUG - 2022-06-20 09:49:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:49:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:49:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:49:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:49:57 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:49:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:49:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:49:57 --> Final output sent to browser
DEBUG - 2022-06-20 09:49:57 --> Total execution time: 0.0386
INFO - 2022-06-20 09:50:27 --> Config Class Initialized
INFO - 2022-06-20 09:50:27 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:50:27 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:50:27 --> Utf8 Class Initialized
INFO - 2022-06-20 09:50:27 --> URI Class Initialized
INFO - 2022-06-20 09:50:27 --> Router Class Initialized
INFO - 2022-06-20 09:50:27 --> Output Class Initialized
INFO - 2022-06-20 09:50:27 --> Security Class Initialized
DEBUG - 2022-06-20 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:50:27 --> Input Class Initialized
INFO - 2022-06-20 09:50:27 --> Language Class Initialized
INFO - 2022-06-20 09:50:27 --> Language Class Initialized
INFO - 2022-06-20 09:50:27 --> Config Class Initialized
INFO - 2022-06-20 09:50:27 --> Loader Class Initialized
INFO - 2022-06-20 09:50:27 --> Helper loaded: url_helper
INFO - 2022-06-20 09:50:27 --> Database Driver Class Initialized
INFO - 2022-06-20 09:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:50:27 --> Model Class Initialized
DEBUG - 2022-06-20 09:50:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:50:27 --> Model Class Initialized
INFO - 2022-06-20 09:50:27 --> Controller Class Initialized
DEBUG - 2022-06-20 09:50:27 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:50:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:50:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:50:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:50:27 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:50:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:50:27 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:50:27 --> Final output sent to browser
DEBUG - 2022-06-20 09:50:27 --> Total execution time: 0.6133
INFO - 2022-06-20 09:51:29 --> Config Class Initialized
INFO - 2022-06-20 09:51:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:51:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:51:29 --> Utf8 Class Initialized
INFO - 2022-06-20 09:51:29 --> URI Class Initialized
INFO - 2022-06-20 09:51:29 --> Router Class Initialized
INFO - 2022-06-20 09:51:29 --> Output Class Initialized
INFO - 2022-06-20 09:51:29 --> Security Class Initialized
DEBUG - 2022-06-20 09:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:51:29 --> Input Class Initialized
INFO - 2022-06-20 09:51:29 --> Language Class Initialized
INFO - 2022-06-20 09:51:29 --> Language Class Initialized
INFO - 2022-06-20 09:51:29 --> Config Class Initialized
INFO - 2022-06-20 09:51:29 --> Loader Class Initialized
INFO - 2022-06-20 09:51:29 --> Helper loaded: url_helper
INFO - 2022-06-20 09:51:29 --> Database Driver Class Initialized
INFO - 2022-06-20 09:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:51:29 --> Model Class Initialized
DEBUG - 2022-06-20 09:51:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:51:29 --> Model Class Initialized
INFO - 2022-06-20 09:51:29 --> Controller Class Initialized
DEBUG - 2022-06-20 09:51:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:51:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:51:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:51:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:51:29 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:51:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:51:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:51:29 --> Final output sent to browser
DEBUG - 2022-06-20 09:51:29 --> Total execution time: 0.0385
INFO - 2022-06-20 09:51:58 --> Config Class Initialized
INFO - 2022-06-20 09:51:58 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:51:58 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:51:58 --> Utf8 Class Initialized
INFO - 2022-06-20 09:51:58 --> URI Class Initialized
INFO - 2022-06-20 09:51:58 --> Router Class Initialized
INFO - 2022-06-20 09:51:58 --> Output Class Initialized
INFO - 2022-06-20 09:51:58 --> Security Class Initialized
DEBUG - 2022-06-20 09:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:51:58 --> Input Class Initialized
INFO - 2022-06-20 09:51:58 --> Language Class Initialized
INFO - 2022-06-20 09:51:58 --> Language Class Initialized
INFO - 2022-06-20 09:51:58 --> Config Class Initialized
INFO - 2022-06-20 09:51:58 --> Loader Class Initialized
INFO - 2022-06-20 09:51:58 --> Helper loaded: url_helper
INFO - 2022-06-20 09:51:58 --> Database Driver Class Initialized
INFO - 2022-06-20 09:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:51:58 --> Model Class Initialized
DEBUG - 2022-06-20 09:51:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:51:58 --> Model Class Initialized
INFO - 2022-06-20 09:51:58 --> Controller Class Initialized
DEBUG - 2022-06-20 09:51:58 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:51:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:51:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:51:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:51:58 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:51:58 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:51:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:51:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:51:58 --> Final output sent to browser
DEBUG - 2022-06-20 09:51:58 --> Total execution time: 0.2211
INFO - 2022-06-20 09:52:48 --> Config Class Initialized
INFO - 2022-06-20 09:52:48 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:52:48 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:52:48 --> Utf8 Class Initialized
INFO - 2022-06-20 09:52:48 --> URI Class Initialized
INFO - 2022-06-20 09:52:48 --> Router Class Initialized
INFO - 2022-06-20 09:52:48 --> Output Class Initialized
INFO - 2022-06-20 09:52:48 --> Security Class Initialized
DEBUG - 2022-06-20 09:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:52:48 --> Input Class Initialized
INFO - 2022-06-20 09:52:48 --> Language Class Initialized
INFO - 2022-06-20 09:52:48 --> Language Class Initialized
INFO - 2022-06-20 09:52:48 --> Config Class Initialized
INFO - 2022-06-20 09:52:48 --> Loader Class Initialized
INFO - 2022-06-20 09:52:48 --> Helper loaded: url_helper
INFO - 2022-06-20 09:52:48 --> Database Driver Class Initialized
INFO - 2022-06-20 09:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:52:48 --> Model Class Initialized
DEBUG - 2022-06-20 09:52:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:52:48 --> Model Class Initialized
INFO - 2022-06-20 09:52:48 --> Controller Class Initialized
DEBUG - 2022-06-20 09:52:48 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:52:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:52:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:52:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:52:48 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:52:48 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:52:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:52:48 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:52:48 --> Final output sent to browser
DEBUG - 2022-06-20 09:52:48 --> Total execution time: 0.0382
INFO - 2022-06-20 09:52:58 --> Config Class Initialized
INFO - 2022-06-20 09:52:58 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:52:58 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:52:58 --> Utf8 Class Initialized
INFO - 2022-06-20 09:52:58 --> URI Class Initialized
INFO - 2022-06-20 09:52:58 --> Router Class Initialized
INFO - 2022-06-20 09:52:58 --> Output Class Initialized
INFO - 2022-06-20 09:52:58 --> Security Class Initialized
DEBUG - 2022-06-20 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:52:58 --> Input Class Initialized
INFO - 2022-06-20 09:52:58 --> Language Class Initialized
INFO - 2022-06-20 09:52:58 --> Language Class Initialized
INFO - 2022-06-20 09:52:58 --> Config Class Initialized
INFO - 2022-06-20 09:52:58 --> Loader Class Initialized
INFO - 2022-06-20 09:52:58 --> Helper loaded: url_helper
INFO - 2022-06-20 09:52:58 --> Database Driver Class Initialized
INFO - 2022-06-20 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:52:58 --> Model Class Initialized
DEBUG - 2022-06-20 09:52:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:52:58 --> Model Class Initialized
INFO - 2022-06-20 09:52:58 --> Controller Class Initialized
DEBUG - 2022-06-20 09:52:58 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:52:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:52:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:52:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:52:59 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:52:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:52:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:52:59 --> Final output sent to browser
DEBUG - 2022-06-20 09:52:59 --> Total execution time: 0.0400
INFO - 2022-06-20 09:53:38 --> Config Class Initialized
INFO - 2022-06-20 09:53:38 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:53:38 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:53:38 --> Utf8 Class Initialized
INFO - 2022-06-20 09:53:38 --> URI Class Initialized
INFO - 2022-06-20 09:53:38 --> Router Class Initialized
INFO - 2022-06-20 09:53:38 --> Output Class Initialized
INFO - 2022-06-20 09:53:38 --> Security Class Initialized
DEBUG - 2022-06-20 09:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:53:38 --> Input Class Initialized
INFO - 2022-06-20 09:53:38 --> Language Class Initialized
INFO - 2022-06-20 09:53:38 --> Language Class Initialized
INFO - 2022-06-20 09:53:38 --> Config Class Initialized
INFO - 2022-06-20 09:53:38 --> Loader Class Initialized
INFO - 2022-06-20 09:53:38 --> Helper loaded: url_helper
INFO - 2022-06-20 09:53:38 --> Database Driver Class Initialized
INFO - 2022-06-20 09:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:53:38 --> Model Class Initialized
DEBUG - 2022-06-20 09:53:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:53:38 --> Model Class Initialized
INFO - 2022-06-20 09:53:38 --> Controller Class Initialized
DEBUG - 2022-06-20 09:53:38 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:53:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:53:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:53:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:53:38 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:53:38 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:53:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:53:38 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:53:38 --> Final output sent to browser
DEBUG - 2022-06-20 09:53:38 --> Total execution time: 0.0276
INFO - 2022-06-20 09:53:46 --> Config Class Initialized
INFO - 2022-06-20 09:53:46 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:53:46 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:53:46 --> Utf8 Class Initialized
INFO - 2022-06-20 09:53:46 --> URI Class Initialized
INFO - 2022-06-20 09:53:46 --> Router Class Initialized
INFO - 2022-06-20 09:53:46 --> Output Class Initialized
INFO - 2022-06-20 09:53:46 --> Security Class Initialized
DEBUG - 2022-06-20 09:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:53:46 --> Input Class Initialized
INFO - 2022-06-20 09:53:46 --> Language Class Initialized
INFO - 2022-06-20 09:53:46 --> Language Class Initialized
INFO - 2022-06-20 09:53:46 --> Config Class Initialized
INFO - 2022-06-20 09:53:46 --> Loader Class Initialized
INFO - 2022-06-20 09:53:46 --> Helper loaded: url_helper
INFO - 2022-06-20 09:53:46 --> Database Driver Class Initialized
INFO - 2022-06-20 09:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:53:46 --> Model Class Initialized
DEBUG - 2022-06-20 09:53:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:53:46 --> Model Class Initialized
INFO - 2022-06-20 09:53:46 --> Controller Class Initialized
DEBUG - 2022-06-20 09:53:46 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:53:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:53:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:53:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:53:46 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:53:46 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:53:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:53:46 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:53:46 --> Final output sent to browser
DEBUG - 2022-06-20 09:53:46 --> Total execution time: 0.0370
INFO - 2022-06-20 09:55:04 --> Config Class Initialized
INFO - 2022-06-20 09:55:04 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:55:04 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:55:04 --> Utf8 Class Initialized
INFO - 2022-06-20 09:55:04 --> URI Class Initialized
INFO - 2022-06-20 09:55:04 --> Router Class Initialized
INFO - 2022-06-20 09:55:04 --> Output Class Initialized
INFO - 2022-06-20 09:55:04 --> Security Class Initialized
DEBUG - 2022-06-20 09:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:55:04 --> Input Class Initialized
INFO - 2022-06-20 09:55:04 --> Language Class Initialized
INFO - 2022-06-20 09:55:04 --> Language Class Initialized
INFO - 2022-06-20 09:55:04 --> Config Class Initialized
INFO - 2022-06-20 09:55:04 --> Loader Class Initialized
INFO - 2022-06-20 09:55:04 --> Helper loaded: url_helper
INFO - 2022-06-20 09:55:04 --> Database Driver Class Initialized
INFO - 2022-06-20 09:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:55:04 --> Model Class Initialized
DEBUG - 2022-06-20 09:55:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:55:04 --> Model Class Initialized
INFO - 2022-06-20 09:55:04 --> Controller Class Initialized
DEBUG - 2022-06-20 09:55:04 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:55:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:55:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:55:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:55:04 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:55:04 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:55:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:55:04 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:55:04 --> Final output sent to browser
DEBUG - 2022-06-20 09:55:04 --> Total execution time: 0.0366
INFO - 2022-06-20 09:55:24 --> Config Class Initialized
INFO - 2022-06-20 09:55:24 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:55:24 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:55:24 --> Utf8 Class Initialized
INFO - 2022-06-20 09:55:24 --> URI Class Initialized
INFO - 2022-06-20 09:55:24 --> Router Class Initialized
INFO - 2022-06-20 09:55:24 --> Output Class Initialized
INFO - 2022-06-20 09:55:24 --> Security Class Initialized
DEBUG - 2022-06-20 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:55:24 --> Input Class Initialized
INFO - 2022-06-20 09:55:24 --> Language Class Initialized
INFO - 2022-06-20 09:55:24 --> Language Class Initialized
INFO - 2022-06-20 09:55:24 --> Config Class Initialized
INFO - 2022-06-20 09:55:24 --> Loader Class Initialized
INFO - 2022-06-20 09:55:24 --> Helper loaded: url_helper
INFO - 2022-06-20 09:55:24 --> Database Driver Class Initialized
INFO - 2022-06-20 09:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:55:24 --> Model Class Initialized
DEBUG - 2022-06-20 09:55:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:55:24 --> Model Class Initialized
INFO - 2022-06-20 09:55:24 --> Controller Class Initialized
DEBUG - 2022-06-20 09:55:24 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:55:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:55:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:55:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:55:24 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:55:24 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:55:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:55:24 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:55:24 --> Final output sent to browser
DEBUG - 2022-06-20 09:55:24 --> Total execution time: 1.5424
INFO - 2022-06-20 09:57:43 --> Config Class Initialized
INFO - 2022-06-20 09:57:43 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:57:43 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:57:43 --> Utf8 Class Initialized
INFO - 2022-06-20 09:57:43 --> URI Class Initialized
INFO - 2022-06-20 09:57:43 --> Router Class Initialized
INFO - 2022-06-20 09:57:43 --> Output Class Initialized
INFO - 2022-06-20 09:57:43 --> Security Class Initialized
DEBUG - 2022-06-20 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:57:43 --> Input Class Initialized
INFO - 2022-06-20 09:57:43 --> Language Class Initialized
INFO - 2022-06-20 09:57:43 --> Language Class Initialized
INFO - 2022-06-20 09:57:43 --> Config Class Initialized
INFO - 2022-06-20 09:57:43 --> Loader Class Initialized
INFO - 2022-06-20 09:57:43 --> Helper loaded: url_helper
INFO - 2022-06-20 09:57:43 --> Database Driver Class Initialized
INFO - 2022-06-20 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:57:43 --> Model Class Initialized
DEBUG - 2022-06-20 09:57:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:57:43 --> Model Class Initialized
INFO - 2022-06-20 09:57:43 --> Controller Class Initialized
DEBUG - 2022-06-20 09:57:43 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:57:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:57:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:57:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:57:43 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:57:43 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:57:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:57:43 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:57:43 --> Final output sent to browser
DEBUG - 2022-06-20 09:57:43 --> Total execution time: 0.0412
INFO - 2022-06-20 09:58:05 --> Config Class Initialized
INFO - 2022-06-20 09:58:05 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:58:05 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:58:05 --> Utf8 Class Initialized
INFO - 2022-06-20 09:58:05 --> URI Class Initialized
INFO - 2022-06-20 09:58:05 --> Router Class Initialized
INFO - 2022-06-20 09:58:05 --> Output Class Initialized
INFO - 2022-06-20 09:58:05 --> Security Class Initialized
DEBUG - 2022-06-20 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:58:05 --> Input Class Initialized
INFO - 2022-06-20 09:58:05 --> Language Class Initialized
INFO - 2022-06-20 09:58:05 --> Language Class Initialized
INFO - 2022-06-20 09:58:05 --> Config Class Initialized
INFO - 2022-06-20 09:58:05 --> Loader Class Initialized
INFO - 2022-06-20 09:58:05 --> Helper loaded: url_helper
INFO - 2022-06-20 09:58:05 --> Database Driver Class Initialized
INFO - 2022-06-20 09:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:58:05 --> Model Class Initialized
DEBUG - 2022-06-20 09:58:05 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:58:05 --> Model Class Initialized
INFO - 2022-06-20 09:58:05 --> Controller Class Initialized
DEBUG - 2022-06-20 09:58:05 --> Admin MX_Controller Initialized
INFO - 2022-06-20 09:58:07 --> Config Class Initialized
INFO - 2022-06-20 09:58:07 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:58:07 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:58:07 --> Utf8 Class Initialized
INFO - 2022-06-20 09:58:07 --> URI Class Initialized
INFO - 2022-06-20 09:58:07 --> Router Class Initialized
INFO - 2022-06-20 09:58:07 --> Output Class Initialized
INFO - 2022-06-20 09:58:07 --> Security Class Initialized
DEBUG - 2022-06-20 09:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:58:07 --> Input Class Initialized
INFO - 2022-06-20 09:58:07 --> Language Class Initialized
INFO - 2022-06-20 09:58:07 --> Language Class Initialized
INFO - 2022-06-20 09:58:07 --> Config Class Initialized
INFO - 2022-06-20 09:58:07 --> Loader Class Initialized
INFO - 2022-06-20 09:58:07 --> Helper loaded: url_helper
INFO - 2022-06-20 09:58:07 --> Database Driver Class Initialized
INFO - 2022-06-20 09:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:58:07 --> Model Class Initialized
DEBUG - 2022-06-20 09:58:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:58:07 --> Model Class Initialized
INFO - 2022-06-20 09:58:07 --> Controller Class Initialized
DEBUG - 2022-06-20 09:58:07 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:58:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:58:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:58:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:58:07 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:58:07 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:58:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:58:07 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:58:07 --> Final output sent to browser
DEBUG - 2022-06-20 09:58:07 --> Total execution time: 0.0364
INFO - 2022-06-20 09:58:47 --> Config Class Initialized
INFO - 2022-06-20 09:58:47 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:58:47 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:58:47 --> Utf8 Class Initialized
INFO - 2022-06-20 09:58:47 --> URI Class Initialized
INFO - 2022-06-20 09:58:47 --> Router Class Initialized
INFO - 2022-06-20 09:58:47 --> Output Class Initialized
INFO - 2022-06-20 09:58:47 --> Security Class Initialized
DEBUG - 2022-06-20 09:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:58:47 --> Input Class Initialized
INFO - 2022-06-20 09:58:47 --> Language Class Initialized
INFO - 2022-06-20 09:58:47 --> Language Class Initialized
INFO - 2022-06-20 09:58:47 --> Config Class Initialized
INFO - 2022-06-20 09:58:47 --> Loader Class Initialized
INFO - 2022-06-20 09:58:47 --> Helper loaded: url_helper
INFO - 2022-06-20 09:58:47 --> Database Driver Class Initialized
INFO - 2022-06-20 09:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:58:47 --> Model Class Initialized
DEBUG - 2022-06-20 09:58:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:58:47 --> Model Class Initialized
INFO - 2022-06-20 09:58:47 --> Controller Class Initialized
DEBUG - 2022-06-20 09:58:47 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:58:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:58:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:58:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:58:47 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:58:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:58:47 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:58:47 --> Final output sent to browser
DEBUG - 2022-06-20 09:58:47 --> Total execution time: 0.0420
INFO - 2022-06-20 09:59:02 --> Config Class Initialized
INFO - 2022-06-20 09:59:02 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:59:02 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:59:02 --> Utf8 Class Initialized
INFO - 2022-06-20 09:59:02 --> URI Class Initialized
INFO - 2022-06-20 09:59:02 --> Router Class Initialized
INFO - 2022-06-20 09:59:02 --> Output Class Initialized
INFO - 2022-06-20 09:59:02 --> Security Class Initialized
DEBUG - 2022-06-20 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:59:02 --> Input Class Initialized
INFO - 2022-06-20 09:59:02 --> Language Class Initialized
INFO - 2022-06-20 09:59:02 --> Language Class Initialized
INFO - 2022-06-20 09:59:02 --> Config Class Initialized
INFO - 2022-06-20 09:59:02 --> Loader Class Initialized
INFO - 2022-06-20 09:59:02 --> Helper loaded: url_helper
INFO - 2022-06-20 09:59:02 --> Database Driver Class Initialized
INFO - 2022-06-20 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:59:02 --> Model Class Initialized
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:59:02 --> Model Class Initialized
INFO - 2022-06-20 09:59:02 --> Controller Class Initialized
DEBUG - 2022-06-20 09:59:02 --> Admin MX_Controller Initialized
INFO - 2022-06-20 09:59:02 --> Config Class Initialized
INFO - 2022-06-20 09:59:02 --> Hooks Class Initialized
DEBUG - 2022-06-20 09:59:02 --> UTF-8 Support Enabled
INFO - 2022-06-20 09:59:02 --> Utf8 Class Initialized
INFO - 2022-06-20 09:59:02 --> URI Class Initialized
INFO - 2022-06-20 09:59:02 --> Router Class Initialized
INFO - 2022-06-20 09:59:02 --> Output Class Initialized
INFO - 2022-06-20 09:59:02 --> Security Class Initialized
DEBUG - 2022-06-20 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 09:59:02 --> Input Class Initialized
INFO - 2022-06-20 09:59:02 --> Language Class Initialized
INFO - 2022-06-20 09:59:02 --> Language Class Initialized
INFO - 2022-06-20 09:59:02 --> Config Class Initialized
INFO - 2022-06-20 09:59:02 --> Loader Class Initialized
INFO - 2022-06-20 09:59:02 --> Helper loaded: url_helper
INFO - 2022-06-20 09:59:02 --> Database Driver Class Initialized
INFO - 2022-06-20 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 09:59:02 --> Model Class Initialized
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 09:59:02 --> Model Class Initialized
INFO - 2022-06-20 09:59:02 --> Controller Class Initialized
DEBUG - 2022-06-20 09:59:02 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 09:59:02 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 09:59:02 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 09:59:02 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 09:59:02 --> Final output sent to browser
DEBUG - 2022-06-20 09:59:02 --> Total execution time: 0.0476
INFO - 2022-06-20 10:02:44 --> Config Class Initialized
INFO - 2022-06-20 10:02:44 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:02:44 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:02:44 --> Utf8 Class Initialized
INFO - 2022-06-20 10:02:44 --> URI Class Initialized
INFO - 2022-06-20 10:02:44 --> Router Class Initialized
INFO - 2022-06-20 10:02:44 --> Output Class Initialized
INFO - 2022-06-20 10:02:44 --> Security Class Initialized
DEBUG - 2022-06-20 10:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:02:44 --> Input Class Initialized
INFO - 2022-06-20 10:02:44 --> Language Class Initialized
INFO - 2022-06-20 10:02:44 --> Language Class Initialized
INFO - 2022-06-20 10:02:44 --> Config Class Initialized
INFO - 2022-06-20 10:02:44 --> Loader Class Initialized
INFO - 2022-06-20 10:02:44 --> Helper loaded: url_helper
INFO - 2022-06-20 10:02:44 --> Database Driver Class Initialized
INFO - 2022-06-20 10:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:02:44 --> Model Class Initialized
DEBUG - 2022-06-20 10:02:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:02:44 --> Model Class Initialized
INFO - 2022-06-20 10:02:44 --> Controller Class Initialized
DEBUG - 2022-06-20 10:02:44 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:02:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:02:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:02:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 10:02:44 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 10:02:44 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 10:02:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:02:44 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:02:44 --> Final output sent to browser
DEBUG - 2022-06-20 10:02:44 --> Total execution time: 0.0491
INFO - 2022-06-20 10:02:57 --> Config Class Initialized
INFO - 2022-06-20 10:02:57 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:02:57 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:02:57 --> Utf8 Class Initialized
INFO - 2022-06-20 10:02:57 --> URI Class Initialized
INFO - 2022-06-20 10:02:57 --> Router Class Initialized
INFO - 2022-06-20 10:02:57 --> Output Class Initialized
INFO - 2022-06-20 10:02:57 --> Security Class Initialized
DEBUG - 2022-06-20 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:02:57 --> Input Class Initialized
INFO - 2022-06-20 10:02:57 --> Language Class Initialized
INFO - 2022-06-20 10:02:57 --> Language Class Initialized
INFO - 2022-06-20 10:02:57 --> Config Class Initialized
INFO - 2022-06-20 10:02:57 --> Loader Class Initialized
INFO - 2022-06-20 10:02:57 --> Helper loaded: url_helper
INFO - 2022-06-20 10:02:57 --> Database Driver Class Initialized
INFO - 2022-06-20 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:02:57 --> Model Class Initialized
DEBUG - 2022-06-20 10:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:02:57 --> Model Class Initialized
INFO - 2022-06-20 10:02:57 --> Controller Class Initialized
DEBUG - 2022-06-20 10:02:57 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 10:02:57 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 10:02:57 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 10:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:02:57 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:02:57 --> Final output sent to browser
DEBUG - 2022-06-20 10:02:57 --> Total execution time: 0.0386
INFO - 2022-06-20 10:03:20 --> Config Class Initialized
INFO - 2022-06-20 10:03:20 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:03:20 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:03:20 --> Utf8 Class Initialized
INFO - 2022-06-20 10:03:20 --> URI Class Initialized
INFO - 2022-06-20 10:03:20 --> Router Class Initialized
INFO - 2022-06-20 10:03:20 --> Output Class Initialized
INFO - 2022-06-20 10:03:20 --> Security Class Initialized
DEBUG - 2022-06-20 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:03:20 --> Input Class Initialized
INFO - 2022-06-20 10:03:20 --> Language Class Initialized
INFO - 2022-06-20 10:03:20 --> Language Class Initialized
INFO - 2022-06-20 10:03:20 --> Config Class Initialized
INFO - 2022-06-20 10:03:20 --> Loader Class Initialized
INFO - 2022-06-20 10:03:20 --> Helper loaded: url_helper
INFO - 2022-06-20 10:03:20 --> Database Driver Class Initialized
INFO - 2022-06-20 10:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:03:20 --> Model Class Initialized
DEBUG - 2022-06-20 10:03:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:03:20 --> Model Class Initialized
INFO - 2022-06-20 10:03:20 --> Controller Class Initialized
DEBUG - 2022-06-20 10:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:03:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:03:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:03:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 10:03:20 --> Severity: Notice --> Undefined variable: com N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
ERROR - 2022-06-20 10:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 110
DEBUG - 2022-06-20 10:03:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:03:20 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:03:20 --> Final output sent to browser
DEBUG - 2022-06-20 10:03:20 --> Total execution time: 0.0290
INFO - 2022-06-20 10:04:40 --> Config Class Initialized
INFO - 2022-06-20 10:04:40 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:04:40 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:04:40 --> Utf8 Class Initialized
INFO - 2022-06-20 10:04:40 --> URI Class Initialized
INFO - 2022-06-20 10:04:40 --> Router Class Initialized
INFO - 2022-06-20 10:04:40 --> Output Class Initialized
INFO - 2022-06-20 10:04:40 --> Security Class Initialized
DEBUG - 2022-06-20 10:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:04:40 --> Input Class Initialized
INFO - 2022-06-20 10:04:40 --> Language Class Initialized
INFO - 2022-06-20 10:04:40 --> Language Class Initialized
INFO - 2022-06-20 10:04:40 --> Config Class Initialized
INFO - 2022-06-20 10:04:40 --> Loader Class Initialized
INFO - 2022-06-20 10:04:40 --> Helper loaded: url_helper
INFO - 2022-06-20 10:04:40 --> Database Driver Class Initialized
INFO - 2022-06-20 10:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:04:40 --> Model Class Initialized
DEBUG - 2022-06-20 10:04:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:04:40 --> Model Class Initialized
INFO - 2022-06-20 10:04:40 --> Controller Class Initialized
DEBUG - 2022-06-20 10:04:40 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:04:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:04:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:04:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:04:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:04:40 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:04:40 --> Final output sent to browser
DEBUG - 2022-06-20 10:04:40 --> Total execution time: 0.0359
INFO - 2022-06-20 10:12:58 --> Config Class Initialized
INFO - 2022-06-20 10:12:58 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:12:58 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:12:58 --> Utf8 Class Initialized
INFO - 2022-06-20 10:12:58 --> URI Class Initialized
INFO - 2022-06-20 10:12:58 --> Router Class Initialized
INFO - 2022-06-20 10:12:58 --> Output Class Initialized
INFO - 2022-06-20 10:12:58 --> Security Class Initialized
DEBUG - 2022-06-20 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:12:58 --> Input Class Initialized
INFO - 2022-06-20 10:12:58 --> Language Class Initialized
INFO - 2022-06-20 10:12:58 --> Language Class Initialized
INFO - 2022-06-20 10:12:58 --> Config Class Initialized
INFO - 2022-06-20 10:12:58 --> Loader Class Initialized
INFO - 2022-06-20 10:12:58 --> Helper loaded: url_helper
INFO - 2022-06-20 10:12:58 --> Database Driver Class Initialized
INFO - 2022-06-20 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:12:58 --> Model Class Initialized
DEBUG - 2022-06-20 10:12:58 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:12:58 --> Model Class Initialized
INFO - 2022-06-20 10:12:58 --> Controller Class Initialized
DEBUG - 2022-06-20 10:12:58 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 10:12:59 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_group() N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 264
ERROR - 2022-06-20 10:12:59 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in N:\Xampp\htdocs\dhired\system\core\Common.php on line 658 and defined in N:\Xampp\htdocs\dhired\system\core\Exceptions.php:190
Stack trace:
#0 N:\Xampp\htdocs\dhired\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown N:\Xampp\htdocs\dhired\system\core\Exceptions.php 190
INFO - 2022-06-20 10:13:29 --> Config Class Initialized
INFO - 2022-06-20 10:13:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:13:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:13:29 --> Utf8 Class Initialized
INFO - 2022-06-20 10:13:29 --> URI Class Initialized
INFO - 2022-06-20 10:13:29 --> Router Class Initialized
INFO - 2022-06-20 10:13:29 --> Output Class Initialized
INFO - 2022-06-20 10:13:29 --> Security Class Initialized
DEBUG - 2022-06-20 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:13:29 --> Input Class Initialized
INFO - 2022-06-20 10:13:29 --> Language Class Initialized
INFO - 2022-06-20 10:13:29 --> Language Class Initialized
INFO - 2022-06-20 10:13:29 --> Config Class Initialized
INFO - 2022-06-20 10:13:29 --> Loader Class Initialized
INFO - 2022-06-20 10:13:29 --> Helper loaded: url_helper
INFO - 2022-06-20 10:13:29 --> Database Driver Class Initialized
INFO - 2022-06-20 10:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:13:29 --> Model Class Initialized
DEBUG - 2022-06-20 10:13:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:13:29 --> Model Class Initialized
INFO - 2022-06-20 10:13:29 --> Controller Class Initialized
DEBUG - 2022-06-20 10:13:29 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 10:13:29 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_group() N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 264
ERROR - 2022-06-20 10:13:29 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in N:\Xampp\htdocs\dhired\system\core\Common.php on line 658 and defined in N:\Xampp\htdocs\dhired\system\core\Exceptions.php:190
Stack trace:
#0 N:\Xampp\htdocs\dhired\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown N:\Xampp\htdocs\dhired\system\core\Exceptions.php 190
INFO - 2022-06-20 10:13:31 --> Config Class Initialized
INFO - 2022-06-20 10:13:31 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:13:31 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:13:31 --> Utf8 Class Initialized
INFO - 2022-06-20 10:13:31 --> URI Class Initialized
INFO - 2022-06-20 10:13:31 --> Router Class Initialized
INFO - 2022-06-20 10:13:31 --> Output Class Initialized
INFO - 2022-06-20 10:13:31 --> Security Class Initialized
DEBUG - 2022-06-20 10:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:13:31 --> Input Class Initialized
INFO - 2022-06-20 10:13:31 --> Language Class Initialized
INFO - 2022-06-20 10:13:31 --> Language Class Initialized
INFO - 2022-06-20 10:13:31 --> Config Class Initialized
INFO - 2022-06-20 10:13:31 --> Loader Class Initialized
INFO - 2022-06-20 10:13:31 --> Helper loaded: url_helper
INFO - 2022-06-20 10:13:31 --> Database Driver Class Initialized
INFO - 2022-06-20 10:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:13:31 --> Model Class Initialized
DEBUG - 2022-06-20 10:13:31 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:13:31 --> Model Class Initialized
INFO - 2022-06-20 10:13:31 --> Controller Class Initialized
DEBUG - 2022-06-20 10:13:31 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 10:13:31 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_group() N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 264
ERROR - 2022-06-20 10:13:31 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in N:\Xampp\htdocs\dhired\system\core\Common.php on line 658 and defined in N:\Xampp\htdocs\dhired\system\core\Exceptions.php:190
Stack trace:
#0 N:\Xampp\htdocs\dhired\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown N:\Xampp\htdocs\dhired\system\core\Exceptions.php 190
INFO - 2022-06-20 10:13:39 --> Config Class Initialized
INFO - 2022-06-20 10:13:39 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:13:39 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:13:39 --> Utf8 Class Initialized
INFO - 2022-06-20 10:13:39 --> URI Class Initialized
INFO - 2022-06-20 10:13:39 --> Router Class Initialized
INFO - 2022-06-20 10:13:39 --> Output Class Initialized
INFO - 2022-06-20 10:13:39 --> Security Class Initialized
DEBUG - 2022-06-20 10:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:13:39 --> Input Class Initialized
INFO - 2022-06-20 10:13:39 --> Language Class Initialized
INFO - 2022-06-20 10:13:39 --> Language Class Initialized
INFO - 2022-06-20 10:13:39 --> Config Class Initialized
INFO - 2022-06-20 10:13:39 --> Loader Class Initialized
INFO - 2022-06-20 10:13:39 --> Helper loaded: url_helper
INFO - 2022-06-20 10:13:39 --> Database Driver Class Initialized
INFO - 2022-06-20 10:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:13:39 --> Model Class Initialized
DEBUG - 2022-06-20 10:13:39 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:13:39 --> Model Class Initialized
INFO - 2022-06-20 10:13:39 --> Controller Class Initialized
DEBUG - 2022-06-20 10:13:39 --> Admin MX_Controller Initialized
ERROR - 2022-06-20 10:13:39 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::get_group() N:\Xampp\htdocs\dhired\application\modules\admin\controllers\Admin.php 264
ERROR - 2022-06-20 10:13:39 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in N:\Xampp\htdocs\dhired\system\core\Common.php on line 658 and defined in N:\Xampp\htdocs\dhired\system\core\Exceptions.php:190
Stack trace:
#0 N:\Xampp\htdocs\dhired\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown N:\Xampp\htdocs\dhired\system\core\Exceptions.php 190
INFO - 2022-06-20 10:14:03 --> Config Class Initialized
INFO - 2022-06-20 10:14:03 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:14:03 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:14:03 --> Utf8 Class Initialized
INFO - 2022-06-20 10:14:03 --> URI Class Initialized
INFO - 2022-06-20 10:14:03 --> Router Class Initialized
INFO - 2022-06-20 10:14:03 --> Output Class Initialized
INFO - 2022-06-20 10:14:03 --> Security Class Initialized
DEBUG - 2022-06-20 10:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:14:03 --> Input Class Initialized
INFO - 2022-06-20 10:14:03 --> Language Class Initialized
INFO - 2022-06-20 10:14:03 --> Language Class Initialized
INFO - 2022-06-20 10:14:03 --> Config Class Initialized
INFO - 2022-06-20 10:14:03 --> Loader Class Initialized
INFO - 2022-06-20 10:14:03 --> Helper loaded: url_helper
INFO - 2022-06-20 10:14:03 --> Database Driver Class Initialized
INFO - 2022-06-20 10:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:14:03 --> Model Class Initialized
DEBUG - 2022-06-20 10:14:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:14:03 --> Model Class Initialized
INFO - 2022-06-20 10:14:03 --> Controller Class Initialized
DEBUG - 2022-06-20 10:14:03 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:14:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:14:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:14:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
ERROR - 2022-06-20 10:14:03 --> Severity: Notice --> Undefined index: id N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 112
ERROR - 2022-06-20 10:14:03 --> Severity: Notice --> Undefined index: id N:\Xampp\htdocs\dhired\application\modules\admin\views\add_group.php 112
DEBUG - 2022-06-20 10:14:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:14:03 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:14:03 --> Final output sent to browser
DEBUG - 2022-06-20 10:14:03 --> Total execution time: 0.0398
INFO - 2022-06-20 10:14:14 --> Config Class Initialized
INFO - 2022-06-20 10:14:14 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:14:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:14:14 --> Utf8 Class Initialized
INFO - 2022-06-20 10:14:14 --> URI Class Initialized
INFO - 2022-06-20 10:14:14 --> Router Class Initialized
INFO - 2022-06-20 10:14:14 --> Output Class Initialized
INFO - 2022-06-20 10:14:14 --> Security Class Initialized
DEBUG - 2022-06-20 10:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:14:14 --> Input Class Initialized
INFO - 2022-06-20 10:14:14 --> Language Class Initialized
INFO - 2022-06-20 10:14:14 --> Language Class Initialized
INFO - 2022-06-20 10:14:14 --> Config Class Initialized
INFO - 2022-06-20 10:14:14 --> Loader Class Initialized
INFO - 2022-06-20 10:14:14 --> Helper loaded: url_helper
INFO - 2022-06-20 10:14:14 --> Database Driver Class Initialized
INFO - 2022-06-20 10:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:14:14 --> Model Class Initialized
DEBUG - 2022-06-20 10:14:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:14:14 --> Model Class Initialized
INFO - 2022-06-20 10:14:14 --> Controller Class Initialized
DEBUG - 2022-06-20 10:14:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:14:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:14:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:14:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:14:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:14:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:14:14 --> Final output sent to browser
DEBUG - 2022-06-20 10:14:14 --> Total execution time: 0.0402
INFO - 2022-06-20 10:15:51 --> Config Class Initialized
INFO - 2022-06-20 10:15:51 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:15:51 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:15:51 --> Utf8 Class Initialized
INFO - 2022-06-20 10:15:51 --> URI Class Initialized
INFO - 2022-06-20 10:15:51 --> Router Class Initialized
INFO - 2022-06-20 10:15:51 --> Output Class Initialized
INFO - 2022-06-20 10:15:51 --> Security Class Initialized
DEBUG - 2022-06-20 10:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:15:51 --> Input Class Initialized
INFO - 2022-06-20 10:15:51 --> Language Class Initialized
INFO - 2022-06-20 10:15:51 --> Language Class Initialized
INFO - 2022-06-20 10:15:51 --> Config Class Initialized
INFO - 2022-06-20 10:15:51 --> Loader Class Initialized
INFO - 2022-06-20 10:15:51 --> Helper loaded: url_helper
INFO - 2022-06-20 10:15:51 --> Database Driver Class Initialized
INFO - 2022-06-20 10:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:15:51 --> Model Class Initialized
DEBUG - 2022-06-20 10:15:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:15:51 --> Model Class Initialized
INFO - 2022-06-20 10:15:51 --> Controller Class Initialized
DEBUG - 2022-06-20 10:15:51 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:15:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:15:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:15:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:15:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:15:51 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:15:51 --> Final output sent to browser
DEBUG - 2022-06-20 10:15:51 --> Total execution time: 0.0371
INFO - 2022-06-20 10:16:08 --> Config Class Initialized
INFO - 2022-06-20 10:16:08 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:16:08 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:16:08 --> Utf8 Class Initialized
INFO - 2022-06-20 10:16:08 --> URI Class Initialized
INFO - 2022-06-20 10:16:08 --> Router Class Initialized
INFO - 2022-06-20 10:16:08 --> Output Class Initialized
INFO - 2022-06-20 10:16:08 --> Security Class Initialized
DEBUG - 2022-06-20 10:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:16:08 --> Input Class Initialized
INFO - 2022-06-20 10:16:08 --> Language Class Initialized
INFO - 2022-06-20 10:16:08 --> Language Class Initialized
INFO - 2022-06-20 10:16:08 --> Config Class Initialized
INFO - 2022-06-20 10:16:08 --> Loader Class Initialized
INFO - 2022-06-20 10:16:08 --> Helper loaded: url_helper
INFO - 2022-06-20 10:16:08 --> Database Driver Class Initialized
INFO - 2022-06-20 10:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:16:08 --> Model Class Initialized
DEBUG - 2022-06-20 10:16:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:16:08 --> Model Class Initialized
INFO - 2022-06-20 10:16:08 --> Controller Class Initialized
DEBUG - 2022-06-20 10:16:08 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:16:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:16:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:16:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:16:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:16:08 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:16:08 --> Final output sent to browser
DEBUG - 2022-06-20 10:16:08 --> Total execution time: 0.0374
INFO - 2022-06-20 10:16:28 --> Config Class Initialized
INFO - 2022-06-20 10:16:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:16:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:16:28 --> Utf8 Class Initialized
INFO - 2022-06-20 10:16:28 --> URI Class Initialized
INFO - 2022-06-20 10:16:28 --> Router Class Initialized
INFO - 2022-06-20 10:16:28 --> Output Class Initialized
INFO - 2022-06-20 10:16:28 --> Security Class Initialized
DEBUG - 2022-06-20 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:16:28 --> Input Class Initialized
INFO - 2022-06-20 10:16:28 --> Language Class Initialized
INFO - 2022-06-20 10:16:28 --> Language Class Initialized
INFO - 2022-06-20 10:16:28 --> Config Class Initialized
INFO - 2022-06-20 10:16:28 --> Loader Class Initialized
INFO - 2022-06-20 10:16:28 --> Helper loaded: url_helper
INFO - 2022-06-20 10:16:28 --> Database Driver Class Initialized
INFO - 2022-06-20 10:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:16:28 --> Model Class Initialized
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:16:28 --> Model Class Initialized
INFO - 2022-06-20 10:16:28 --> Controller Class Initialized
DEBUG - 2022-06-20 10:16:28 --> Admin MX_Controller Initialized
INFO - 2022-06-20 10:16:28 --> Config Class Initialized
INFO - 2022-06-20 10:16:28 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:16:28 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:16:28 --> Utf8 Class Initialized
INFO - 2022-06-20 10:16:28 --> URI Class Initialized
INFO - 2022-06-20 10:16:28 --> Router Class Initialized
INFO - 2022-06-20 10:16:28 --> Output Class Initialized
INFO - 2022-06-20 10:16:28 --> Security Class Initialized
DEBUG - 2022-06-20 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:16:28 --> Input Class Initialized
INFO - 2022-06-20 10:16:28 --> Language Class Initialized
INFO - 2022-06-20 10:16:28 --> Language Class Initialized
INFO - 2022-06-20 10:16:28 --> Config Class Initialized
INFO - 2022-06-20 10:16:28 --> Loader Class Initialized
INFO - 2022-06-20 10:16:28 --> Helper loaded: url_helper
INFO - 2022-06-20 10:16:28 --> Database Driver Class Initialized
INFO - 2022-06-20 10:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:16:28 --> Model Class Initialized
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:16:28 --> Model Class Initialized
INFO - 2022-06-20 10:16:28 --> Controller Class Initialized
DEBUG - 2022-06-20 10:16:28 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:16:28 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:16:28 --> Final output sent to browser
DEBUG - 2022-06-20 10:16:28 --> Total execution time: 0.0350
INFO - 2022-06-20 10:17:08 --> Config Class Initialized
INFO - 2022-06-20 10:17:08 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:17:08 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:17:08 --> Utf8 Class Initialized
INFO - 2022-06-20 10:17:08 --> URI Class Initialized
INFO - 2022-06-20 10:17:08 --> Router Class Initialized
INFO - 2022-06-20 10:17:08 --> Output Class Initialized
INFO - 2022-06-20 10:17:08 --> Security Class Initialized
DEBUG - 2022-06-20 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:17:08 --> Input Class Initialized
INFO - 2022-06-20 10:17:08 --> Language Class Initialized
INFO - 2022-06-20 10:17:08 --> Language Class Initialized
INFO - 2022-06-20 10:17:08 --> Config Class Initialized
INFO - 2022-06-20 10:17:08 --> Loader Class Initialized
INFO - 2022-06-20 10:17:08 --> Helper loaded: url_helper
INFO - 2022-06-20 10:17:08 --> Database Driver Class Initialized
INFO - 2022-06-20 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:17:09 --> Model Class Initialized
DEBUG - 2022-06-20 10:17:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:17:09 --> Model Class Initialized
INFO - 2022-06-20 10:17:09 --> Controller Class Initialized
DEBUG - 2022-06-20 10:17:09 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:17:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:17:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:17:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:17:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:17:09 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:17:09 --> Final output sent to browser
DEBUG - 2022-06-20 10:17:09 --> Total execution time: 0.0413
INFO - 2022-06-20 10:17:35 --> Config Class Initialized
INFO - 2022-06-20 10:17:35 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:17:35 --> Utf8 Class Initialized
INFO - 2022-06-20 10:17:35 --> URI Class Initialized
INFO - 2022-06-20 10:17:35 --> Router Class Initialized
INFO - 2022-06-20 10:17:35 --> Output Class Initialized
INFO - 2022-06-20 10:17:35 --> Security Class Initialized
DEBUG - 2022-06-20 10:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:17:35 --> Input Class Initialized
INFO - 2022-06-20 10:17:35 --> Language Class Initialized
INFO - 2022-06-20 10:17:35 --> Language Class Initialized
INFO - 2022-06-20 10:17:35 --> Config Class Initialized
INFO - 2022-06-20 10:17:35 --> Loader Class Initialized
INFO - 2022-06-20 10:17:35 --> Helper loaded: url_helper
INFO - 2022-06-20 10:17:35 --> Database Driver Class Initialized
INFO - 2022-06-20 10:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:17:35 --> Model Class Initialized
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:17:35 --> Model Class Initialized
INFO - 2022-06-20 10:17:35 --> Controller Class Initialized
DEBUG - 2022-06-20 10:17:35 --> Admin MX_Controller Initialized
INFO - 2022-06-20 10:17:35 --> Config Class Initialized
INFO - 2022-06-20 10:17:35 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:17:35 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:17:35 --> Utf8 Class Initialized
INFO - 2022-06-20 10:17:35 --> URI Class Initialized
INFO - 2022-06-20 10:17:35 --> Router Class Initialized
INFO - 2022-06-20 10:17:35 --> Output Class Initialized
INFO - 2022-06-20 10:17:35 --> Security Class Initialized
DEBUG - 2022-06-20 10:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:17:35 --> Input Class Initialized
INFO - 2022-06-20 10:17:35 --> Language Class Initialized
INFO - 2022-06-20 10:17:35 --> Language Class Initialized
INFO - 2022-06-20 10:17:35 --> Config Class Initialized
INFO - 2022-06-20 10:17:35 --> Loader Class Initialized
INFO - 2022-06-20 10:17:35 --> Helper loaded: url_helper
INFO - 2022-06-20 10:17:35 --> Database Driver Class Initialized
INFO - 2022-06-20 10:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:17:35 --> Model Class Initialized
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:17:35 --> Model Class Initialized
INFO - 2022-06-20 10:17:35 --> Controller Class Initialized
DEBUG - 2022-06-20 10:17:35 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:17:35 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:17:35 --> Final output sent to browser
DEBUG - 2022-06-20 10:17:35 --> Total execution time: 0.0361
INFO - 2022-06-20 10:18:11 --> Config Class Initialized
INFO - 2022-06-20 10:18:11 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:18:11 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:18:11 --> Utf8 Class Initialized
INFO - 2022-06-20 10:18:11 --> URI Class Initialized
INFO - 2022-06-20 10:18:11 --> Router Class Initialized
INFO - 2022-06-20 10:18:11 --> Output Class Initialized
INFO - 2022-06-20 10:18:11 --> Security Class Initialized
DEBUG - 2022-06-20 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:18:11 --> Input Class Initialized
INFO - 2022-06-20 10:18:11 --> Language Class Initialized
INFO - 2022-06-20 10:18:11 --> Language Class Initialized
INFO - 2022-06-20 10:18:11 --> Config Class Initialized
INFO - 2022-06-20 10:18:11 --> Loader Class Initialized
INFO - 2022-06-20 10:18:11 --> Helper loaded: url_helper
INFO - 2022-06-20 10:18:11 --> Database Driver Class Initialized
INFO - 2022-06-20 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:18:11 --> Model Class Initialized
DEBUG - 2022-06-20 10:18:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:18:11 --> Model Class Initialized
INFO - 2022-06-20 10:18:11 --> Controller Class Initialized
DEBUG - 2022-06-20 10:18:11 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:18:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:18:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:18:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:18:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:18:11 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:18:11 --> Final output sent to browser
DEBUG - 2022-06-20 10:18:11 --> Total execution time: 0.0403
INFO - 2022-06-20 10:18:13 --> Config Class Initialized
INFO - 2022-06-20 10:18:13 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:18:14 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:18:14 --> Utf8 Class Initialized
INFO - 2022-06-20 10:18:14 --> URI Class Initialized
INFO - 2022-06-20 10:18:14 --> Router Class Initialized
INFO - 2022-06-20 10:18:14 --> Output Class Initialized
INFO - 2022-06-20 10:18:14 --> Security Class Initialized
DEBUG - 2022-06-20 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:18:14 --> Input Class Initialized
INFO - 2022-06-20 10:18:14 --> Language Class Initialized
INFO - 2022-06-20 10:18:14 --> Language Class Initialized
INFO - 2022-06-20 10:18:14 --> Config Class Initialized
INFO - 2022-06-20 10:18:14 --> Loader Class Initialized
INFO - 2022-06-20 10:18:14 --> Helper loaded: url_helper
INFO - 2022-06-20 10:18:14 --> Database Driver Class Initialized
INFO - 2022-06-20 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:18:14 --> Model Class Initialized
DEBUG - 2022-06-20 10:18:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:18:14 --> Model Class Initialized
INFO - 2022-06-20 10:18:14 --> Controller Class Initialized
DEBUG - 2022-06-20 10:18:14 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:18:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:18:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:18:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:18:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:18:14 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:18:14 --> Final output sent to browser
DEBUG - 2022-06-20 10:18:14 --> Total execution time: 0.0437
INFO - 2022-06-20 10:18:29 --> Config Class Initialized
INFO - 2022-06-20 10:18:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:18:29 --> Utf8 Class Initialized
INFO - 2022-06-20 10:18:29 --> URI Class Initialized
INFO - 2022-06-20 10:18:29 --> Router Class Initialized
INFO - 2022-06-20 10:18:29 --> Output Class Initialized
INFO - 2022-06-20 10:18:29 --> Security Class Initialized
DEBUG - 2022-06-20 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:18:29 --> Input Class Initialized
INFO - 2022-06-20 10:18:29 --> Language Class Initialized
INFO - 2022-06-20 10:18:29 --> Language Class Initialized
INFO - 2022-06-20 10:18:29 --> Config Class Initialized
INFO - 2022-06-20 10:18:29 --> Loader Class Initialized
INFO - 2022-06-20 10:18:29 --> Helper loaded: url_helper
INFO - 2022-06-20 10:18:29 --> Database Driver Class Initialized
INFO - 2022-06-20 10:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:18:29 --> Model Class Initialized
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:18:29 --> Model Class Initialized
INFO - 2022-06-20 10:18:29 --> Controller Class Initialized
DEBUG - 2022-06-20 10:18:29 --> Admin MX_Controller Initialized
INFO - 2022-06-20 10:18:29 --> Config Class Initialized
INFO - 2022-06-20 10:18:29 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:18:29 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:18:29 --> Utf8 Class Initialized
INFO - 2022-06-20 10:18:29 --> URI Class Initialized
INFO - 2022-06-20 10:18:29 --> Router Class Initialized
INFO - 2022-06-20 10:18:29 --> Output Class Initialized
INFO - 2022-06-20 10:18:29 --> Security Class Initialized
DEBUG - 2022-06-20 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:18:29 --> Input Class Initialized
INFO - 2022-06-20 10:18:29 --> Language Class Initialized
INFO - 2022-06-20 10:18:29 --> Language Class Initialized
INFO - 2022-06-20 10:18:29 --> Config Class Initialized
INFO - 2022-06-20 10:18:29 --> Loader Class Initialized
INFO - 2022-06-20 10:18:29 --> Helper loaded: url_helper
INFO - 2022-06-20 10:18:29 --> Database Driver Class Initialized
INFO - 2022-06-20 10:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:18:29 --> Model Class Initialized
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:18:29 --> Model Class Initialized
INFO - 2022-06-20 10:18:29 --> Controller Class Initialized
DEBUG - 2022-06-20 10:18:29 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:18:29 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:18:29 --> Final output sent to browser
DEBUG - 2022-06-20 10:18:29 --> Total execution time: 0.0455
INFO - 2022-06-20 10:19:59 --> Config Class Initialized
INFO - 2022-06-20 10:19:59 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:19:59 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:19:59 --> Utf8 Class Initialized
INFO - 2022-06-20 10:19:59 --> URI Class Initialized
INFO - 2022-06-20 10:19:59 --> Router Class Initialized
INFO - 2022-06-20 10:19:59 --> Output Class Initialized
INFO - 2022-06-20 10:19:59 --> Security Class Initialized
DEBUG - 2022-06-20 10:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:19:59 --> Input Class Initialized
INFO - 2022-06-20 10:19:59 --> Language Class Initialized
INFO - 2022-06-20 10:19:59 --> Language Class Initialized
INFO - 2022-06-20 10:19:59 --> Config Class Initialized
INFO - 2022-06-20 10:19:59 --> Loader Class Initialized
INFO - 2022-06-20 10:19:59 --> Helper loaded: url_helper
INFO - 2022-06-20 10:19:59 --> Database Driver Class Initialized
INFO - 2022-06-20 10:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:19:59 --> Model Class Initialized
DEBUG - 2022-06-20 10:19:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:19:59 --> Model Class Initialized
INFO - 2022-06-20 10:19:59 --> Controller Class Initialized
DEBUG - 2022-06-20 10:19:59 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:19:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:19:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:19:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:19:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:19:59 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:19:59 --> Final output sent to browser
DEBUG - 2022-06-20 10:19:59 --> Total execution time: 0.0409
INFO - 2022-06-20 10:20:32 --> Config Class Initialized
INFO - 2022-06-20 10:20:32 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:20:32 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:20:32 --> Utf8 Class Initialized
INFO - 2022-06-20 10:20:32 --> URI Class Initialized
INFO - 2022-06-20 10:20:32 --> Router Class Initialized
INFO - 2022-06-20 10:20:32 --> Output Class Initialized
INFO - 2022-06-20 10:20:32 --> Security Class Initialized
DEBUG - 2022-06-20 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:20:32 --> Input Class Initialized
INFO - 2022-06-20 10:20:32 --> Language Class Initialized
INFO - 2022-06-20 10:20:32 --> Language Class Initialized
INFO - 2022-06-20 10:20:32 --> Config Class Initialized
INFO - 2022-06-20 10:20:32 --> Loader Class Initialized
INFO - 2022-06-20 10:20:32 --> Helper loaded: url_helper
INFO - 2022-06-20 10:20:32 --> Database Driver Class Initialized
INFO - 2022-06-20 10:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:20:32 --> Model Class Initialized
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:20:32 --> Model Class Initialized
INFO - 2022-06-20 10:20:32 --> Controller Class Initialized
DEBUG - 2022-06-20 10:20:32 --> Admin MX_Controller Initialized
INFO - 2022-06-20 10:20:32 --> Config Class Initialized
INFO - 2022-06-20 10:20:32 --> Hooks Class Initialized
DEBUG - 2022-06-20 10:20:32 --> UTF-8 Support Enabled
INFO - 2022-06-20 10:20:32 --> Utf8 Class Initialized
INFO - 2022-06-20 10:20:32 --> URI Class Initialized
INFO - 2022-06-20 10:20:32 --> Router Class Initialized
INFO - 2022-06-20 10:20:32 --> Output Class Initialized
INFO - 2022-06-20 10:20:32 --> Security Class Initialized
DEBUG - 2022-06-20 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-20 10:20:32 --> Input Class Initialized
INFO - 2022-06-20 10:20:32 --> Language Class Initialized
INFO - 2022-06-20 10:20:32 --> Language Class Initialized
INFO - 2022-06-20 10:20:32 --> Config Class Initialized
INFO - 2022-06-20 10:20:32 --> Loader Class Initialized
INFO - 2022-06-20 10:20:32 --> Helper loaded: url_helper
INFO - 2022-06-20 10:20:32 --> Database Driver Class Initialized
INFO - 2022-06-20 10:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-20 10:20:32 --> Model Class Initialized
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/models/Admin_model.php
INFO - 2022-06-20 10:20:32 --> Model Class Initialized
INFO - 2022-06-20 10:20:32 --> Controller Class Initialized
DEBUG - 2022-06-20 10:20:32 --> Admin MX_Controller Initialized
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/head.php
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/header.php
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/sidebar.php
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin/views/add_group.php
DEBUG - 2022-06-20 10:20:32 --> File loaded: N:\Xampp\htdocs\dhired\application\modules/admin_common/views/footer.php
INFO - 2022-06-20 10:20:32 --> Final output sent to browser
DEBUG - 2022-06-20 10:20:32 --> Total execution time: 0.0360
