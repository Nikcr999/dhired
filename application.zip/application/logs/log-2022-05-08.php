<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
DEBUG - 2022-05-08 10:52:24 --> No URI present. Default controller set.
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Loader Class Initialized
INFO - 2022-05-08 10:52:24 --> Helper loaded: url_helper
INFO - 2022-05-08 10:52:24 --> Database Driver Class Initialized
INFO - 2022-05-08 10:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:52:24 --> Controller Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:52:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-08 10:52:24 --> Final output sent to browser
DEBUG - 2022-05-08 10:52:24 --> Total execution time: 0.3134
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Config Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> Hooks Class Initialized
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
DEBUG - 2022-05-08 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:24 --> URI Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:24 --> Router Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
INFO - 2022-05-08 10:52:24 --> Output Class Initialized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:24 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:24 --> Input Class Initialized
INFO - 2022-05-08 10:52:24 --> Language Class Initialized
ERROR - 2022-05-08 10:52:24 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:25 --> Config Class Initialized
INFO - 2022-05-08 10:52:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:25 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:25 --> URI Class Initialized
INFO - 2022-05-08 10:52:25 --> Router Class Initialized
INFO - 2022-05-08 10:52:25 --> Output Class Initialized
INFO - 2022-05-08 10:52:25 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:25 --> Input Class Initialized
INFO - 2022-05-08 10:52:25 --> Language Class Initialized
ERROR - 2022-05-08 10:52:25 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:25 --> Config Class Initialized
INFO - 2022-05-08 10:52:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:25 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:25 --> URI Class Initialized
INFO - 2022-05-08 10:52:25 --> Router Class Initialized
INFO - 2022-05-08 10:52:25 --> Output Class Initialized
INFO - 2022-05-08 10:52:25 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:25 --> Input Class Initialized
INFO - 2022-05-08 10:52:25 --> Language Class Initialized
ERROR - 2022-05-08 10:52:25 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:25 --> Config Class Initialized
INFO - 2022-05-08 10:52:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:25 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:25 --> URI Class Initialized
INFO - 2022-05-08 10:52:25 --> Router Class Initialized
INFO - 2022-05-08 10:52:25 --> Output Class Initialized
INFO - 2022-05-08 10:52:25 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:25 --> Input Class Initialized
INFO - 2022-05-08 10:52:25 --> Language Class Initialized
ERROR - 2022-05-08 10:52:25 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:25 --> Config Class Initialized
INFO - 2022-05-08 10:52:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:25 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:25 --> URI Class Initialized
INFO - 2022-05-08 10:52:25 --> Router Class Initialized
INFO - 2022-05-08 10:52:25 --> Output Class Initialized
INFO - 2022-05-08 10:52:25 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:25 --> Input Class Initialized
INFO - 2022-05-08 10:52:25 --> Language Class Initialized
ERROR - 2022-05-08 10:52:25 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:52:25 --> Config Class Initialized
INFO - 2022-05-08 10:52:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:52:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:52:25 --> Utf8 Class Initialized
INFO - 2022-05-08 10:52:25 --> URI Class Initialized
INFO - 2022-05-08 10:52:25 --> Router Class Initialized
INFO - 2022-05-08 10:52:25 --> Output Class Initialized
INFO - 2022-05-08 10:52:25 --> Security Class Initialized
DEBUG - 2022-05-08 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:52:25 --> Input Class Initialized
INFO - 2022-05-08 10:52:25 --> Language Class Initialized
ERROR - 2022-05-08 10:52:25 --> 404 Page Not Found: /index
INFO - 2022-05-08 10:57:15 --> Config Class Initialized
INFO - 2022-05-08 10:57:15 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:57:15 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:15 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:15 --> URI Class Initialized
DEBUG - 2022-05-08 10:57:15 --> No URI present. Default controller set.
INFO - 2022-05-08 10:57:15 --> Router Class Initialized
INFO - 2022-05-08 10:57:15 --> Output Class Initialized
INFO - 2022-05-08 10:57:15 --> Security Class Initialized
DEBUG - 2022-05-08 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:15 --> Input Class Initialized
INFO - 2022-05-08 10:57:15 --> Language Class Initialized
INFO - 2022-05-08 10:57:15 --> Language Class Initialized
INFO - 2022-05-08 10:57:15 --> Config Class Initialized
INFO - 2022-05-08 10:57:15 --> Loader Class Initialized
INFO - 2022-05-08 10:57:15 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:15 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:15 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:15 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-08 10:57:15 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:15 --> Total execution time: 0.0375
INFO - 2022-05-08 10:57:18 --> Config Class Initialized
INFO - 2022-05-08 10:57:18 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:57:18 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:18 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:18 --> URI Class Initialized
DEBUG - 2022-05-08 10:57:18 --> No URI present. Default controller set.
INFO - 2022-05-08 10:57:18 --> Router Class Initialized
INFO - 2022-05-08 10:57:18 --> Output Class Initialized
INFO - 2022-05-08 10:57:18 --> Security Class Initialized
DEBUG - 2022-05-08 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:18 --> Input Class Initialized
INFO - 2022-05-08 10:57:18 --> Language Class Initialized
INFO - 2022-05-08 10:57:18 --> Language Class Initialized
INFO - 2022-05-08 10:57:18 --> Config Class Initialized
INFO - 2022-05-08 10:57:18 --> Loader Class Initialized
INFO - 2022-05-08 10:57:18 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:18 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:18 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:18 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-08 10:57:18 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:18 --> Total execution time: 0.0436
INFO - 2022-05-08 10:57:30 --> Config Class Initialized
INFO - 2022-05-08 10:57:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:57:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:30 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:30 --> URI Class Initialized
INFO - 2022-05-08 10:57:30 --> Router Class Initialized
INFO - 2022-05-08 10:57:30 --> Output Class Initialized
INFO - 2022-05-08 10:57:30 --> Security Class Initialized
DEBUG - 2022-05-08 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:30 --> Input Class Initialized
INFO - 2022-05-08 10:57:30 --> Language Class Initialized
INFO - 2022-05-08 10:57:30 --> Language Class Initialized
INFO - 2022-05-08 10:57:30 --> Config Class Initialized
INFO - 2022-05-08 10:57:30 --> Loader Class Initialized
INFO - 2022-05-08 10:57:30 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:30 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:30 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:30 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:30 --> Total execution time: 0.0485
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0423
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0463
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0504
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0570
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
INFO - 2022-05-08 10:57:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
DEBUG - 2022-05-08 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Utf8 Class Initialized
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0607
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> URI Class Initialized
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 10:57:34 --> Router Class Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0668
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
INFO - 2022-05-08 10:57:34 --> Output Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Security Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:57:34 --> Input Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Language Class Initialized
INFO - 2022-05-08 10:57:34 --> Config Class Initialized
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Loader Class Initialized
INFO - 2022-05-08 10:57:34 --> Helper loaded: url_helper
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Database Driver Class Initialized
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0455
INFO - 2022-05-08 10:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:57:34 --> Controller Class Initialized
DEBUG - 2022-05-08 10:57:34 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:57:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:57:34 --> Final output sent to browser
DEBUG - 2022-05-08 10:57:34 --> Total execution time: 0.0432
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0398
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0479
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0512
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0580
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0631
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:58:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 10:58:29 --> URI Class Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0681
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
INFO - 2022-05-08 10:58:29 --> Router Class Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Output Class Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0761
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Security Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:58:29 --> Input Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Language Class Initialized
INFO - 2022-05-08 10:58:29 --> Config Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Loader Class Initialized
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Helper loaded: url_helper
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Database Driver Class Initialized
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0466
INFO - 2022-05-08 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:58:29 --> Controller Class Initialized
DEBUG - 2022-05-08 10:58:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:58:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:58:29 --> Final output sent to browser
DEBUG - 2022-05-08 10:58:29 --> Total execution time: 0.0519
INFO - 2022-05-08 10:59:07 --> Config Class Initialized
INFO - 2022-05-08 10:59:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:59:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:07 --> Utf8 Class Initialized
INFO - 2022-05-08 10:59:07 --> URI Class Initialized
INFO - 2022-05-08 10:59:07 --> Router Class Initialized
INFO - 2022-05-08 10:59:07 --> Output Class Initialized
INFO - 2022-05-08 10:59:07 --> Security Class Initialized
DEBUG - 2022-05-08 10:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:07 --> Input Class Initialized
INFO - 2022-05-08 10:59:07 --> Language Class Initialized
INFO - 2022-05-08 10:59:07 --> Language Class Initialized
INFO - 2022-05-08 10:59:07 --> Config Class Initialized
INFO - 2022-05-08 10:59:07 --> Loader Class Initialized
INFO - 2022-05-08 10:59:07 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:07 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:07 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:07 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:59:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:07 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:07 --> Total execution time: 0.0376
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0414
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0466
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0513
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0571
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Hooks Class Initialized
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 10:59:08 --> Utf8 Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0622
INFO - 2022-05-08 10:59:08 --> URI Class Initialized
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 10:59:08 --> Router Class Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0670
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Output Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
INFO - 2022-05-08 10:59:08 --> Security Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 10:59:08 --> Input Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Language Class Initialized
INFO - 2022-05-08 10:59:08 --> Config Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Loader Class Initialized
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Helper loaded: url_helper
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:08 --> Database Driver Class Initialized
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0365
INFO - 2022-05-08 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 10:59:08 --> Controller Class Initialized
DEBUG - 2022-05-08 10:59:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 10:59:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 10:59:08 --> Final output sent to browser
DEBUG - 2022-05-08 10:59:08 --> Total execution time: 0.0523
INFO - 2022-05-08 11:01:10 --> Config Class Initialized
INFO - 2022-05-08 11:01:10 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:10 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:10 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:10 --> URI Class Initialized
INFO - 2022-05-08 11:01:10 --> Router Class Initialized
INFO - 2022-05-08 11:01:10 --> Output Class Initialized
INFO - 2022-05-08 11:01:10 --> Security Class Initialized
DEBUG - 2022-05-08 11:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:10 --> Input Class Initialized
INFO - 2022-05-08 11:01:10 --> Language Class Initialized
INFO - 2022-05-08 11:01:10 --> Language Class Initialized
INFO - 2022-05-08 11:01:10 --> Config Class Initialized
INFO - 2022-05-08 11:01:10 --> Loader Class Initialized
INFO - 2022-05-08 11:01:10 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:10 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:10 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:10 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:10 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:10 --> Total execution time: 0.0378
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0452
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0491
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0535
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0596
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:01:11 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> URI Class Initialized
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0660
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:01:11 --> Router Class Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0708
INFO - 2022-05-08 11:01:11 --> Output Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Security Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:11 --> Input Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Language Class Initialized
INFO - 2022-05-08 11:01:11 --> Config Class Initialized
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Loader Class Initialized
INFO - 2022-05-08 11:01:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0450
INFO - 2022-05-08 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:11 --> Total execution time: 0.0451
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0398
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0465
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0504
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0554
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0606
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:01:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
DEBUG - 2022-05-08 11:01:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:01:37 --> Utf8 Class Initialized
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0647
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> URI Class Initialized
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:01:37 --> Router Class Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0685
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Output Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
INFO - 2022-05-08 11:01:37 --> Security Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:01:37 --> Input Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Language Class Initialized
INFO - 2022-05-08 11:01:37 --> Config Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Loader Class Initialized
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0372
INFO - 2022-05-08 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:01:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:01:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:01:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:01:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:01:37 --> Total execution time: 0.0370
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0278
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0489
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0534
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0575
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
INFO - 2022-05-08 11:02:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0639
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:02:29 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:02:29 --> URI Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0747
INFO - 2022-05-08 11:02:29 --> Router Class Initialized
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Output Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:02:29 --> Security Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0760
DEBUG - 2022-05-08 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Input Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Language Class Initialized
INFO - 2022-05-08 11:02:29 --> Config Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Loader Class Initialized
INFO - 2022-05-08 11:02:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0499
INFO - 2022-05-08 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:02:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:02:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:02:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:02:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:02:29 --> Total execution time: 0.0532
INFO - 2022-05-08 11:03:18 --> Config Class Initialized
INFO - 2022-05-08 11:03:18 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:18 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:18 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:18 --> URI Class Initialized
INFO - 2022-05-08 11:03:18 --> Router Class Initialized
INFO - 2022-05-08 11:03:18 --> Output Class Initialized
INFO - 2022-05-08 11:03:18 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:18 --> Input Class Initialized
INFO - 2022-05-08 11:03:18 --> Language Class Initialized
INFO - 2022-05-08 11:03:18 --> Language Class Initialized
INFO - 2022-05-08 11:03:18 --> Config Class Initialized
INFO - 2022-05-08 11:03:18 --> Loader Class Initialized
INFO - 2022-05-08 11:03:18 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:18 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:18 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:18 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:19 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:19 --> Total execution time: 0.7248
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:19 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:19 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:19 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:03:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:19 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:19 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:19 --> URI Class Initialized
DEBUG - 2022-05-08 11:03:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:19 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:19 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:19 --> URI Class Initialized
INFO - 2022-05-08 11:03:19 --> URI Class Initialized
INFO - 2022-05-08 11:03:19 --> URI Class Initialized
INFO - 2022-05-08 11:03:19 --> URI Class Initialized
INFO - 2022-05-08 11:03:19 --> Router Class Initialized
INFO - 2022-05-08 11:03:19 --> Router Class Initialized
INFO - 2022-05-08 11:03:19 --> Router Class Initialized
INFO - 2022-05-08 11:03:19 --> Router Class Initialized
INFO - 2022-05-08 11:03:19 --> Router Class Initialized
INFO - 2022-05-08 11:03:19 --> Output Class Initialized
DEBUG - 2022-05-08 11:03:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:19 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:19 --> Security Class Initialized
INFO - 2022-05-08 11:03:19 --> Output Class Initialized
INFO - 2022-05-08 11:03:19 --> Output Class Initialized
INFO - 2022-05-08 11:03:19 --> Output Class Initialized
INFO - 2022-05-08 11:03:19 --> URI Class Initialized
INFO - 2022-05-08 11:03:19 --> Output Class Initialized
INFO - 2022-05-08 11:03:19 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:19 --> Security Class Initialized
INFO - 2022-05-08 11:03:19 --> Input Class Initialized
INFO - 2022-05-08 11:03:19 --> Security Class Initialized
INFO - 2022-05-08 11:03:19 --> Security Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:19 --> Input Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:19 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:19 --> Input Class Initialized
INFO - 2022-05-08 11:03:19 --> Input Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:19 --> Input Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Output Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Security Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Loader Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:19 --> Input Class Initialized
INFO - 2022-05-08 11:03:19 --> Loader Class Initialized
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Loader Class Initialized
INFO - 2022-05-08 11:03:19 --> Loader Class Initialized
INFO - 2022-05-08 11:03:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:19 --> Loader Class Initialized
INFO - 2022-05-08 11:03:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:19 --> Language Class Initialized
INFO - 2022-05-08 11:03:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:19 --> Config Class Initialized
INFO - 2022-05-08 11:03:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:19 --> Loader Class Initialized
INFO - 2022-05-08 11:03:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:19 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:19 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:19 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:19 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:19 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:19 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:19 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:03:19 --> Database Driver Class Initialized
DEBUG - 2022-05-08 11:03:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.5430
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.5458
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.5519
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:03:20 --> Config Class Initialized
INFO - 2022-05-08 11:03:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.5571
INFO - 2022-05-08 11:03:20 --> Config Class Initialized
INFO - 2022-05-08 11:03:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:20 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:03:20 --> URI Class Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:20 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> URI Class Initialized
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.5618
INFO - 2022-05-08 11:03:20 --> Router Class Initialized
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:03:20 --> Output Class Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:03:20 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:03:20 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Output Class Initialized
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.5666
DEBUG - 2022-05-08 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:20 --> Security Class Initialized
INFO - 2022-05-08 11:03:20 --> Input Class Initialized
INFO - 2022-05-08 11:03:20 --> Language Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:20 --> Input Class Initialized
INFO - 2022-05-08 11:03:20 --> Language Class Initialized
INFO - 2022-05-08 11:03:20 --> Language Class Initialized
INFO - 2022-05-08 11:03:20 --> Config Class Initialized
INFO - 2022-05-08 11:03:20 --> Language Class Initialized
INFO - 2022-05-08 11:03:20 --> Config Class Initialized
INFO - 2022-05-08 11:03:20 --> Loader Class Initialized
INFO - 2022-05-08 11:03:20 --> Loader Class Initialized
INFO - 2022-05-08 11:03:20 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:20 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:20 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:20 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.0350
INFO - 2022-05-08 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:20 --> Total execution time: 0.0365
INFO - 2022-05-08 11:03:29 --> Config Class Initialized
INFO - 2022-05-08 11:03:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:29 --> URI Class Initialized
INFO - 2022-05-08 11:03:29 --> Router Class Initialized
INFO - 2022-05-08 11:03:29 --> Output Class Initialized
INFO - 2022-05-08 11:03:29 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:29 --> Input Class Initialized
INFO - 2022-05-08 11:03:29 --> Language Class Initialized
INFO - 2022-05-08 11:03:29 --> Language Class Initialized
INFO - 2022-05-08 11:03:29 --> Config Class Initialized
INFO - 2022-05-08 11:03:29 --> Loader Class Initialized
INFO - 2022-05-08 11:03:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:29 --> Total execution time: 0.0968
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0473
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0524
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0583
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0648
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:30 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:03:30 --> URI Class Initialized
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0695
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:03:30 --> Output Class Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0745
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:30 --> Input Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Language Class Initialized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Config Class Initialized
INFO - 2022-05-08 11:03:30 --> Loader Class Initialized
INFO - 2022-05-08 11:03:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0392
INFO - 2022-05-08 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:30 --> Total execution time: 0.0385
INFO - 2022-05-08 11:03:54 --> Config Class Initialized
INFO - 2022-05-08 11:03:54 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:54 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:54 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:54 --> URI Class Initialized
INFO - 2022-05-08 11:03:54 --> Router Class Initialized
INFO - 2022-05-08 11:03:54 --> Output Class Initialized
INFO - 2022-05-08 11:03:54 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:54 --> Input Class Initialized
INFO - 2022-05-08 11:03:54 --> Language Class Initialized
INFO - 2022-05-08 11:03:54 --> Language Class Initialized
INFO - 2022-05-08 11:03:54 --> Config Class Initialized
INFO - 2022-05-08 11:03:54 --> Loader Class Initialized
INFO - 2022-05-08 11:03:54 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:54 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:54 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:54 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 2.2838
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0478
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0503
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0573
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0640
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Hooks Class Initialized
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
INFO - 2022-05-08 11:03:56 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> URI Class Initialized
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0717
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:03:56 --> Router Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0767
INFO - 2022-05-08 11:03:56 --> Output Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:03:56 --> Input Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Language Class Initialized
INFO - 2022-05-08 11:03:56 --> Config Class Initialized
INFO - 2022-05-08 11:03:56 --> Loader Class Initialized
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:03:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 11:03:56 --> Database Driver Class Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0361
INFO - 2022-05-08 11:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:03:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:03:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:03:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:03:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:03:56 --> Total execution time: 0.0372
INFO - 2022-05-08 11:05:14 --> Config Class Initialized
INFO - 2022-05-08 11:05:14 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:05:14 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:05:14 --> Utf8 Class Initialized
INFO - 2022-05-08 11:05:14 --> URI Class Initialized
INFO - 2022-05-08 11:05:14 --> Router Class Initialized
INFO - 2022-05-08 11:05:15 --> Output Class Initialized
INFO - 2022-05-08 11:05:15 --> Security Class Initialized
DEBUG - 2022-05-08 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:05:15 --> Input Class Initialized
INFO - 2022-05-08 11:05:15 --> Language Class Initialized
ERROR - 2022-05-08 11:05:15 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:07:17 --> Config Class Initialized
INFO - 2022-05-08 11:07:17 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:07:17 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:17 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:17 --> URI Class Initialized
INFO - 2022-05-08 11:07:17 --> Router Class Initialized
INFO - 2022-05-08 11:07:17 --> Output Class Initialized
INFO - 2022-05-08 11:07:17 --> Security Class Initialized
DEBUG - 2022-05-08 11:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:17 --> Input Class Initialized
INFO - 2022-05-08 11:07:17 --> Language Class Initialized
INFO - 2022-05-08 11:07:17 --> Language Class Initialized
INFO - 2022-05-08 11:07:17 --> Config Class Initialized
INFO - 2022-05-08 11:07:17 --> Loader Class Initialized
INFO - 2022-05-08 11:07:17 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:17 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:17 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:17 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:17 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:17 --> Total execution time: 0.0376
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0441
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0485
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0534
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0594
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Hooks Class Initialized
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:22 --> Utf8 Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> URI Class Initialized
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0644
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
INFO - 2022-05-08 11:07:22 --> Router Class Initialized
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0681
INFO - 2022-05-08 11:07:22 --> Output Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
INFO - 2022-05-08 11:07:22 --> Security Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:22 --> Input Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Language Class Initialized
INFO - 2022-05-08 11:07:22 --> Config Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Loader Class Initialized
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Helper loaded: url_helper
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Database Driver Class Initialized
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0390
INFO - 2022-05-08 11:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:07:22 --> Controller Class Initialized
DEBUG - 2022-05-08 11:07:22 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:07:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:07:22 --> Final output sent to browser
DEBUG - 2022-05-08 11:07:22 --> Total execution time: 0.0398
INFO - 2022-05-08 11:07:25 --> Config Class Initialized
INFO - 2022-05-08 11:07:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:07:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:07:25 --> Utf8 Class Initialized
INFO - 2022-05-08 11:07:25 --> URI Class Initialized
INFO - 2022-05-08 11:07:25 --> Router Class Initialized
INFO - 2022-05-08 11:07:25 --> Output Class Initialized
INFO - 2022-05-08 11:07:25 --> Security Class Initialized
DEBUG - 2022-05-08 11:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:07:25 --> Input Class Initialized
INFO - 2022-05-08 11:07:25 --> Language Class Initialized
ERROR - 2022-05-08 11:07:25 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:08:50 --> Config Class Initialized
INFO - 2022-05-08 11:08:50 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:08:50 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:08:50 --> Utf8 Class Initialized
INFO - 2022-05-08 11:08:50 --> URI Class Initialized
INFO - 2022-05-08 11:08:50 --> Router Class Initialized
INFO - 2022-05-08 11:08:50 --> Output Class Initialized
INFO - 2022-05-08 11:08:50 --> Security Class Initialized
DEBUG - 2022-05-08 11:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:08:50 --> Input Class Initialized
INFO - 2022-05-08 11:08:50 --> Language Class Initialized
INFO - 2022-05-08 11:08:50 --> Language Class Initialized
INFO - 2022-05-08 11:08:50 --> Config Class Initialized
INFO - 2022-05-08 11:08:50 --> Loader Class Initialized
INFO - 2022-05-08 11:08:50 --> Helper loaded: url_helper
INFO - 2022-05-08 11:08:50 --> Database Driver Class Initialized
INFO - 2022-05-08 11:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:08:50 --> Controller Class Initialized
DEBUG - 2022-05-08 11:08:50 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:08:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:08:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:08:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:08:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:08:50 --> Final output sent to browser
DEBUG - 2022-05-08 11:08:50 --> Total execution time: 0.0431
INFO - 2022-05-08 11:08:52 --> Config Class Initialized
INFO - 2022-05-08 11:08:52 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:08:52 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:08:52 --> Utf8 Class Initialized
INFO - 2022-05-08 11:08:52 --> URI Class Initialized
INFO - 2022-05-08 11:08:52 --> Router Class Initialized
INFO - 2022-05-08 11:08:52 --> Output Class Initialized
INFO - 2022-05-08 11:08:52 --> Security Class Initialized
DEBUG - 2022-05-08 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:08:52 --> Input Class Initialized
INFO - 2022-05-08 11:08:52 --> Language Class Initialized
ERROR - 2022-05-08 11:08:52 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:11:10 --> Config Class Initialized
INFO - 2022-05-08 11:11:10 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:11:10 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:11:10 --> Utf8 Class Initialized
INFO - 2022-05-08 11:11:10 --> URI Class Initialized
INFO - 2022-05-08 11:11:10 --> Router Class Initialized
INFO - 2022-05-08 11:11:10 --> Output Class Initialized
INFO - 2022-05-08 11:11:10 --> Security Class Initialized
DEBUG - 2022-05-08 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:11:10 --> Input Class Initialized
INFO - 2022-05-08 11:11:10 --> Language Class Initialized
INFO - 2022-05-08 11:11:10 --> Language Class Initialized
INFO - 2022-05-08 11:11:10 --> Config Class Initialized
INFO - 2022-05-08 11:11:10 --> Loader Class Initialized
INFO - 2022-05-08 11:11:10 --> Helper loaded: url_helper
INFO - 2022-05-08 11:11:10 --> Database Driver Class Initialized
INFO - 2022-05-08 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:11:10 --> Controller Class Initialized
DEBUG - 2022-05-08 11:11:10 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:11:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:11:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:11:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:11:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:11:10 --> Final output sent to browser
DEBUG - 2022-05-08 11:11:10 --> Total execution time: 0.1209
INFO - 2022-05-08 11:11:10 --> Config Class Initialized
INFO - 2022-05-08 11:11:10 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:11:10 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:11:10 --> Utf8 Class Initialized
INFO - 2022-05-08 11:11:10 --> URI Class Initialized
INFO - 2022-05-08 11:11:10 --> Router Class Initialized
INFO - 2022-05-08 11:11:10 --> Output Class Initialized
INFO - 2022-05-08 11:11:10 --> Security Class Initialized
DEBUG - 2022-05-08 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:11:10 --> Input Class Initialized
INFO - 2022-05-08 11:11:10 --> Language Class Initialized
ERROR - 2022-05-08 11:11:10 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:12:04 --> Config Class Initialized
INFO - 2022-05-08 11:12:04 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:12:04 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:12:04 --> Utf8 Class Initialized
INFO - 2022-05-08 11:12:04 --> URI Class Initialized
INFO - 2022-05-08 11:12:04 --> Router Class Initialized
INFO - 2022-05-08 11:12:04 --> Output Class Initialized
INFO - 2022-05-08 11:12:04 --> Security Class Initialized
DEBUG - 2022-05-08 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:12:04 --> Input Class Initialized
INFO - 2022-05-08 11:12:04 --> Language Class Initialized
INFO - 2022-05-08 11:12:04 --> Language Class Initialized
INFO - 2022-05-08 11:12:04 --> Config Class Initialized
INFO - 2022-05-08 11:12:04 --> Loader Class Initialized
INFO - 2022-05-08 11:12:04 --> Helper loaded: url_helper
INFO - 2022-05-08 11:12:04 --> Database Driver Class Initialized
INFO - 2022-05-08 11:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:12:04 --> Controller Class Initialized
DEBUG - 2022-05-08 11:12:04 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:12:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:12:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:12:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:12:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:12:07 --> Final output sent to browser
DEBUG - 2022-05-08 11:12:07 --> Total execution time: 3.1297
INFO - 2022-05-08 11:12:08 --> Config Class Initialized
INFO - 2022-05-08 11:12:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:12:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:12:08 --> Utf8 Class Initialized
INFO - 2022-05-08 11:12:08 --> URI Class Initialized
INFO - 2022-05-08 11:12:08 --> Router Class Initialized
INFO - 2022-05-08 11:12:08 --> Output Class Initialized
INFO - 2022-05-08 11:12:08 --> Security Class Initialized
DEBUG - 2022-05-08 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:12:08 --> Input Class Initialized
INFO - 2022-05-08 11:12:08 --> Language Class Initialized
ERROR - 2022-05-08 11:12:08 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:12:42 --> Config Class Initialized
INFO - 2022-05-08 11:12:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:12:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:12:42 --> Utf8 Class Initialized
INFO - 2022-05-08 11:12:42 --> URI Class Initialized
INFO - 2022-05-08 11:12:42 --> Router Class Initialized
INFO - 2022-05-08 11:12:42 --> Output Class Initialized
INFO - 2022-05-08 11:12:42 --> Security Class Initialized
DEBUG - 2022-05-08 11:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:12:42 --> Input Class Initialized
INFO - 2022-05-08 11:12:42 --> Language Class Initialized
ERROR - 2022-05-08 11:12:42 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:16:37 --> Config Class Initialized
INFO - 2022-05-08 11:16:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:16:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:16:37 --> Utf8 Class Initialized
INFO - 2022-05-08 11:16:37 --> URI Class Initialized
INFO - 2022-05-08 11:16:37 --> Router Class Initialized
INFO - 2022-05-08 11:16:37 --> Output Class Initialized
INFO - 2022-05-08 11:16:37 --> Security Class Initialized
DEBUG - 2022-05-08 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:16:37 --> Input Class Initialized
INFO - 2022-05-08 11:16:37 --> Language Class Initialized
INFO - 2022-05-08 11:16:37 --> Language Class Initialized
INFO - 2022-05-08 11:16:37 --> Config Class Initialized
INFO - 2022-05-08 11:16:37 --> Loader Class Initialized
INFO - 2022-05-08 11:16:37 --> Helper loaded: url_helper
INFO - 2022-05-08 11:16:37 --> Database Driver Class Initialized
INFO - 2022-05-08 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:16:37 --> Controller Class Initialized
DEBUG - 2022-05-08 11:16:37 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:16:37 --> Final output sent to browser
DEBUG - 2022-05-08 11:16:37 --> Total execution time: 0.0347
INFO - 2022-05-08 11:17:25 --> Config Class Initialized
INFO - 2022-05-08 11:17:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:17:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:17:25 --> Utf8 Class Initialized
INFO - 2022-05-08 11:17:25 --> URI Class Initialized
INFO - 2022-05-08 11:17:25 --> Router Class Initialized
INFO - 2022-05-08 11:17:25 --> Output Class Initialized
INFO - 2022-05-08 11:17:25 --> Security Class Initialized
DEBUG - 2022-05-08 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:17:25 --> Input Class Initialized
INFO - 2022-05-08 11:17:25 --> Language Class Initialized
INFO - 2022-05-08 11:17:25 --> Language Class Initialized
INFO - 2022-05-08 11:17:25 --> Config Class Initialized
INFO - 2022-05-08 11:17:25 --> Loader Class Initialized
INFO - 2022-05-08 11:17:25 --> Helper loaded: url_helper
INFO - 2022-05-08 11:17:25 --> Database Driver Class Initialized
INFO - 2022-05-08 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:17:25 --> Controller Class Initialized
DEBUG - 2022-05-08 11:17:25 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:17:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:17:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:17:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:17:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:17:25 --> Final output sent to browser
DEBUG - 2022-05-08 11:17:25 --> Total execution time: 0.0411
INFO - 2022-05-08 11:17:33 --> Config Class Initialized
INFO - 2022-05-08 11:17:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:17:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:17:33 --> Utf8 Class Initialized
INFO - 2022-05-08 11:17:33 --> URI Class Initialized
INFO - 2022-05-08 11:17:33 --> Router Class Initialized
INFO - 2022-05-08 11:17:33 --> Output Class Initialized
INFO - 2022-05-08 11:17:33 --> Security Class Initialized
DEBUG - 2022-05-08 11:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:17:33 --> Input Class Initialized
INFO - 2022-05-08 11:17:33 --> Language Class Initialized
INFO - 2022-05-08 11:17:33 --> Language Class Initialized
INFO - 2022-05-08 11:17:33 --> Config Class Initialized
INFO - 2022-05-08 11:17:33 --> Loader Class Initialized
INFO - 2022-05-08 11:17:33 --> Helper loaded: url_helper
INFO - 2022-05-08 11:17:33 --> Database Driver Class Initialized
INFO - 2022-05-08 11:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:17:33 --> Controller Class Initialized
DEBUG - 2022-05-08 11:17:33 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:17:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:17:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:17:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:17:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:17:33 --> Final output sent to browser
DEBUG - 2022-05-08 11:17:33 --> Total execution time: 0.0351
INFO - 2022-05-08 11:17:41 --> Config Class Initialized
INFO - 2022-05-08 11:17:41 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:17:41 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:17:41 --> Utf8 Class Initialized
INFO - 2022-05-08 11:17:41 --> URI Class Initialized
INFO - 2022-05-08 11:17:41 --> Router Class Initialized
INFO - 2022-05-08 11:17:41 --> Output Class Initialized
INFO - 2022-05-08 11:17:41 --> Security Class Initialized
DEBUG - 2022-05-08 11:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:17:41 --> Input Class Initialized
INFO - 2022-05-08 11:17:41 --> Language Class Initialized
INFO - 2022-05-08 11:17:41 --> Language Class Initialized
INFO - 2022-05-08 11:17:41 --> Config Class Initialized
INFO - 2022-05-08 11:17:41 --> Loader Class Initialized
INFO - 2022-05-08 11:17:41 --> Helper loaded: url_helper
INFO - 2022-05-08 11:17:41 --> Database Driver Class Initialized
INFO - 2022-05-08 11:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:17:41 --> Controller Class Initialized
DEBUG - 2022-05-08 11:17:41 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:17:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:17:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:17:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:17:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:17:41 --> Final output sent to browser
DEBUG - 2022-05-08 11:17:41 --> Total execution time: 0.0290
INFO - 2022-05-08 11:17:50 --> Config Class Initialized
INFO - 2022-05-08 11:17:50 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:17:50 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:17:50 --> Utf8 Class Initialized
INFO - 2022-05-08 11:17:50 --> URI Class Initialized
INFO - 2022-05-08 11:17:50 --> Router Class Initialized
INFO - 2022-05-08 11:17:50 --> Output Class Initialized
INFO - 2022-05-08 11:17:50 --> Security Class Initialized
DEBUG - 2022-05-08 11:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:17:50 --> Input Class Initialized
INFO - 2022-05-08 11:17:50 --> Language Class Initialized
INFO - 2022-05-08 11:17:50 --> Language Class Initialized
INFO - 2022-05-08 11:17:50 --> Config Class Initialized
INFO - 2022-05-08 11:17:50 --> Loader Class Initialized
INFO - 2022-05-08 11:17:50 --> Helper loaded: url_helper
INFO - 2022-05-08 11:17:50 --> Database Driver Class Initialized
INFO - 2022-05-08 11:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:17:50 --> Controller Class Initialized
DEBUG - 2022-05-08 11:17:50 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:17:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:17:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:17:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:17:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:17:50 --> Final output sent to browser
DEBUG - 2022-05-08 11:17:50 --> Total execution time: 0.0348
INFO - 2022-05-08 11:20:45 --> Config Class Initialized
INFO - 2022-05-08 11:20:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:20:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:20:45 --> Utf8 Class Initialized
INFO - 2022-05-08 11:20:45 --> URI Class Initialized
INFO - 2022-05-08 11:20:45 --> Router Class Initialized
INFO - 2022-05-08 11:20:45 --> Output Class Initialized
INFO - 2022-05-08 11:20:45 --> Security Class Initialized
DEBUG - 2022-05-08 11:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:20:45 --> Input Class Initialized
INFO - 2022-05-08 11:20:45 --> Language Class Initialized
INFO - 2022-05-08 11:20:45 --> Language Class Initialized
INFO - 2022-05-08 11:20:45 --> Config Class Initialized
INFO - 2022-05-08 11:20:45 --> Loader Class Initialized
INFO - 2022-05-08 11:20:45 --> Helper loaded: url_helper
INFO - 2022-05-08 11:20:45 --> Database Driver Class Initialized
INFO - 2022-05-08 11:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:20:45 --> Controller Class Initialized
DEBUG - 2022-05-08 11:20:45 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:20:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:20:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:20:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:20:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:20:45 --> Final output sent to browser
DEBUG - 2022-05-08 11:20:45 --> Total execution time: 0.0363
INFO - 2022-05-08 11:21:52 --> Config Class Initialized
INFO - 2022-05-08 11:21:52 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:21:52 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:21:52 --> Utf8 Class Initialized
INFO - 2022-05-08 11:21:52 --> URI Class Initialized
INFO - 2022-05-08 11:21:52 --> Router Class Initialized
INFO - 2022-05-08 11:21:52 --> Output Class Initialized
INFO - 2022-05-08 11:21:52 --> Security Class Initialized
DEBUG - 2022-05-08 11:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:21:52 --> Input Class Initialized
INFO - 2022-05-08 11:21:52 --> Language Class Initialized
INFO - 2022-05-08 11:21:52 --> Language Class Initialized
INFO - 2022-05-08 11:21:52 --> Config Class Initialized
INFO - 2022-05-08 11:21:52 --> Loader Class Initialized
INFO - 2022-05-08 11:21:52 --> Helper loaded: url_helper
INFO - 2022-05-08 11:21:52 --> Database Driver Class Initialized
INFO - 2022-05-08 11:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:21:52 --> Controller Class Initialized
DEBUG - 2022-05-08 11:21:52 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:21:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:21:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:21:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:21:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:21:52 --> Final output sent to browser
DEBUG - 2022-05-08 11:21:52 --> Total execution time: 0.0347
INFO - 2022-05-08 11:25:11 --> Config Class Initialized
INFO - 2022-05-08 11:25:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:25:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:25:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:25:11 --> URI Class Initialized
INFO - 2022-05-08 11:25:11 --> Router Class Initialized
INFO - 2022-05-08 11:25:11 --> Output Class Initialized
INFO - 2022-05-08 11:25:11 --> Security Class Initialized
DEBUG - 2022-05-08 11:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:25:11 --> Input Class Initialized
INFO - 2022-05-08 11:25:11 --> Language Class Initialized
INFO - 2022-05-08 11:25:11 --> Language Class Initialized
INFO - 2022-05-08 11:25:11 --> Config Class Initialized
INFO - 2022-05-08 11:25:11 --> Loader Class Initialized
INFO - 2022-05-08 11:25:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:25:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:25:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:25:11 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:25:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:25:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:25:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:25:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:25:11 --> Final output sent to browser
DEBUG - 2022-05-08 11:25:11 --> Total execution time: 0.0933
INFO - 2022-05-08 11:25:26 --> Config Class Initialized
INFO - 2022-05-08 11:25:26 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:25:26 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:25:26 --> Utf8 Class Initialized
INFO - 2022-05-08 11:25:26 --> URI Class Initialized
INFO - 2022-05-08 11:25:26 --> Router Class Initialized
INFO - 2022-05-08 11:25:26 --> Output Class Initialized
INFO - 2022-05-08 11:25:26 --> Security Class Initialized
DEBUG - 2022-05-08 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:25:26 --> Input Class Initialized
INFO - 2022-05-08 11:25:26 --> Language Class Initialized
INFO - 2022-05-08 11:25:26 --> Language Class Initialized
INFO - 2022-05-08 11:25:26 --> Config Class Initialized
INFO - 2022-05-08 11:25:26 --> Loader Class Initialized
INFO - 2022-05-08 11:25:26 --> Helper loaded: url_helper
INFO - 2022-05-08 11:25:26 --> Database Driver Class Initialized
INFO - 2022-05-08 11:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:25:26 --> Controller Class Initialized
DEBUG - 2022-05-08 11:25:26 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:25:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:25:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:25:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:25:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:25:26 --> Final output sent to browser
DEBUG - 2022-05-08 11:25:26 --> Total execution time: 0.0389
INFO - 2022-05-08 11:25:36 --> Config Class Initialized
INFO - 2022-05-08 11:25:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:25:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:25:36 --> Utf8 Class Initialized
INFO - 2022-05-08 11:25:36 --> URI Class Initialized
INFO - 2022-05-08 11:25:36 --> Router Class Initialized
INFO - 2022-05-08 11:25:36 --> Output Class Initialized
INFO - 2022-05-08 11:25:36 --> Security Class Initialized
DEBUG - 2022-05-08 11:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:25:36 --> Input Class Initialized
INFO - 2022-05-08 11:25:36 --> Language Class Initialized
INFO - 2022-05-08 11:25:36 --> Language Class Initialized
INFO - 2022-05-08 11:25:36 --> Config Class Initialized
INFO - 2022-05-08 11:25:36 --> Loader Class Initialized
INFO - 2022-05-08 11:25:36 --> Helper loaded: url_helper
INFO - 2022-05-08 11:25:36 --> Database Driver Class Initialized
INFO - 2022-05-08 11:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:25:36 --> Controller Class Initialized
DEBUG - 2022-05-08 11:25:36 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:25:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:25:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:25:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:25:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:25:36 --> Final output sent to browser
DEBUG - 2022-05-08 11:25:36 --> Total execution time: 0.0364
INFO - 2022-05-08 11:25:58 --> Config Class Initialized
INFO - 2022-05-08 11:25:58 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:25:58 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:25:58 --> Utf8 Class Initialized
INFO - 2022-05-08 11:25:58 --> URI Class Initialized
INFO - 2022-05-08 11:25:58 --> Router Class Initialized
INFO - 2022-05-08 11:25:58 --> Output Class Initialized
INFO - 2022-05-08 11:25:58 --> Security Class Initialized
DEBUG - 2022-05-08 11:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:25:58 --> Input Class Initialized
INFO - 2022-05-08 11:25:58 --> Language Class Initialized
INFO - 2022-05-08 11:25:58 --> Language Class Initialized
INFO - 2022-05-08 11:25:58 --> Config Class Initialized
INFO - 2022-05-08 11:25:58 --> Loader Class Initialized
INFO - 2022-05-08 11:25:58 --> Helper loaded: url_helper
INFO - 2022-05-08 11:25:58 --> Database Driver Class Initialized
INFO - 2022-05-08 11:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:25:58 --> Controller Class Initialized
DEBUG - 2022-05-08 11:25:58 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:25:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:25:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:25:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:25:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:25:58 --> Final output sent to browser
DEBUG - 2022-05-08 11:25:58 --> Total execution time: 0.0351
INFO - 2022-05-08 11:26:26 --> Config Class Initialized
INFO - 2022-05-08 11:26:26 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:26:26 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:26:26 --> Utf8 Class Initialized
INFO - 2022-05-08 11:26:26 --> URI Class Initialized
INFO - 2022-05-08 11:26:26 --> Router Class Initialized
INFO - 2022-05-08 11:26:26 --> Output Class Initialized
INFO - 2022-05-08 11:26:26 --> Security Class Initialized
DEBUG - 2022-05-08 11:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:26:26 --> Input Class Initialized
INFO - 2022-05-08 11:26:26 --> Language Class Initialized
INFO - 2022-05-08 11:26:26 --> Language Class Initialized
INFO - 2022-05-08 11:26:26 --> Config Class Initialized
INFO - 2022-05-08 11:26:26 --> Loader Class Initialized
INFO - 2022-05-08 11:26:26 --> Helper loaded: url_helper
INFO - 2022-05-08 11:26:26 --> Database Driver Class Initialized
INFO - 2022-05-08 11:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:26:26 --> Controller Class Initialized
DEBUG - 2022-05-08 11:26:26 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:26:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:26:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:26:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:26:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:26:26 --> Final output sent to browser
DEBUG - 2022-05-08 11:26:26 --> Total execution time: 0.0367
INFO - 2022-05-08 11:26:51 --> Config Class Initialized
INFO - 2022-05-08 11:26:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:26:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:26:51 --> Utf8 Class Initialized
INFO - 2022-05-08 11:26:51 --> URI Class Initialized
INFO - 2022-05-08 11:26:51 --> Router Class Initialized
INFO - 2022-05-08 11:26:51 --> Output Class Initialized
INFO - 2022-05-08 11:26:51 --> Security Class Initialized
DEBUG - 2022-05-08 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:26:51 --> Input Class Initialized
INFO - 2022-05-08 11:26:51 --> Language Class Initialized
INFO - 2022-05-08 11:26:51 --> Language Class Initialized
INFO - 2022-05-08 11:26:51 --> Config Class Initialized
INFO - 2022-05-08 11:26:51 --> Loader Class Initialized
INFO - 2022-05-08 11:26:51 --> Helper loaded: url_helper
INFO - 2022-05-08 11:26:51 --> Database Driver Class Initialized
INFO - 2022-05-08 11:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:26:51 --> Controller Class Initialized
DEBUG - 2022-05-08 11:26:51 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:26:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:26:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:26:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:26:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:26:51 --> Final output sent to browser
DEBUG - 2022-05-08 11:26:51 --> Total execution time: 0.0361
INFO - 2022-05-08 11:27:08 --> Config Class Initialized
INFO - 2022-05-08 11:27:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:27:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:27:08 --> Utf8 Class Initialized
INFO - 2022-05-08 11:27:08 --> URI Class Initialized
INFO - 2022-05-08 11:27:08 --> Router Class Initialized
INFO - 2022-05-08 11:27:08 --> Output Class Initialized
INFO - 2022-05-08 11:27:08 --> Security Class Initialized
DEBUG - 2022-05-08 11:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:27:08 --> Input Class Initialized
INFO - 2022-05-08 11:27:08 --> Language Class Initialized
INFO - 2022-05-08 11:27:08 --> Language Class Initialized
INFO - 2022-05-08 11:27:08 --> Config Class Initialized
INFO - 2022-05-08 11:27:08 --> Loader Class Initialized
INFO - 2022-05-08 11:27:08 --> Helper loaded: url_helper
INFO - 2022-05-08 11:27:08 --> Database Driver Class Initialized
INFO - 2022-05-08 11:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:27:08 --> Controller Class Initialized
DEBUG - 2022-05-08 11:27:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:27:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-08 11:27:08 --> Final output sent to browser
DEBUG - 2022-05-08 11:27:08 --> Total execution time: 0.0553
INFO - 2022-05-08 11:27:14 --> Config Class Initialized
INFO - 2022-05-08 11:27:14 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:27:14 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:27:14 --> Utf8 Class Initialized
INFO - 2022-05-08 11:27:14 --> URI Class Initialized
INFO - 2022-05-08 11:27:14 --> Router Class Initialized
INFO - 2022-05-08 11:27:14 --> Output Class Initialized
INFO - 2022-05-08 11:27:14 --> Security Class Initialized
DEBUG - 2022-05-08 11:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:27:14 --> Input Class Initialized
INFO - 2022-05-08 11:27:14 --> Language Class Initialized
INFO - 2022-05-08 11:27:14 --> Language Class Initialized
INFO - 2022-05-08 11:27:14 --> Config Class Initialized
INFO - 2022-05-08 11:27:14 --> Loader Class Initialized
INFO - 2022-05-08 11:27:14 --> Helper loaded: url_helper
INFO - 2022-05-08 11:27:14 --> Database Driver Class Initialized
INFO - 2022-05-08 11:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:27:14 --> Controller Class Initialized
DEBUG - 2022-05-08 11:27:14 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:27:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:27:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:27:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:27:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:27:14 --> Final output sent to browser
DEBUG - 2022-05-08 11:27:14 --> Total execution time: 0.0555
INFO - 2022-05-08 11:28:07 --> Config Class Initialized
INFO - 2022-05-08 11:28:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:28:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:28:07 --> Utf8 Class Initialized
INFO - 2022-05-08 11:28:07 --> URI Class Initialized
INFO - 2022-05-08 11:28:07 --> Router Class Initialized
INFO - 2022-05-08 11:28:07 --> Output Class Initialized
INFO - 2022-05-08 11:28:07 --> Security Class Initialized
DEBUG - 2022-05-08 11:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:28:07 --> Input Class Initialized
INFO - 2022-05-08 11:28:07 --> Language Class Initialized
INFO - 2022-05-08 11:28:07 --> Language Class Initialized
INFO - 2022-05-08 11:28:07 --> Config Class Initialized
INFO - 2022-05-08 11:28:07 --> Loader Class Initialized
INFO - 2022-05-08 11:28:07 --> Helper loaded: url_helper
INFO - 2022-05-08 11:28:07 --> Database Driver Class Initialized
INFO - 2022-05-08 11:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:28:07 --> Controller Class Initialized
DEBUG - 2022-05-08 11:28:07 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:28:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:28:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:28:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:28:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:28:07 --> Final output sent to browser
DEBUG - 2022-05-08 11:28:07 --> Total execution time: 0.0256
INFO - 2022-05-08 11:29:21 --> Config Class Initialized
INFO - 2022-05-08 11:29:21 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:29:21 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:29:21 --> Utf8 Class Initialized
INFO - 2022-05-08 11:29:21 --> URI Class Initialized
INFO - 2022-05-08 11:29:21 --> Router Class Initialized
INFO - 2022-05-08 11:29:21 --> Output Class Initialized
INFO - 2022-05-08 11:29:21 --> Security Class Initialized
DEBUG - 2022-05-08 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:29:21 --> Input Class Initialized
INFO - 2022-05-08 11:29:21 --> Language Class Initialized
INFO - 2022-05-08 11:29:21 --> Language Class Initialized
INFO - 2022-05-08 11:29:21 --> Config Class Initialized
INFO - 2022-05-08 11:29:21 --> Loader Class Initialized
INFO - 2022-05-08 11:29:21 --> Helper loaded: url_helper
INFO - 2022-05-08 11:29:21 --> Database Driver Class Initialized
INFO - 2022-05-08 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:29:21 --> Controller Class Initialized
DEBUG - 2022-05-08 11:29:21 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:29:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:29:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:29:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:29:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:29:21 --> Final output sent to browser
DEBUG - 2022-05-08 11:29:21 --> Total execution time: 0.0397
INFO - 2022-05-08 11:30:19 --> Config Class Initialized
INFO - 2022-05-08 11:30:19 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:30:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:30:19 --> Utf8 Class Initialized
INFO - 2022-05-08 11:30:19 --> URI Class Initialized
INFO - 2022-05-08 11:30:19 --> Router Class Initialized
INFO - 2022-05-08 11:30:19 --> Output Class Initialized
INFO - 2022-05-08 11:30:19 --> Security Class Initialized
DEBUG - 2022-05-08 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:30:19 --> Input Class Initialized
INFO - 2022-05-08 11:30:19 --> Language Class Initialized
INFO - 2022-05-08 11:30:19 --> Language Class Initialized
INFO - 2022-05-08 11:30:19 --> Config Class Initialized
INFO - 2022-05-08 11:30:19 --> Loader Class Initialized
INFO - 2022-05-08 11:30:19 --> Helper loaded: url_helper
INFO - 2022-05-08 11:30:19 --> Database Driver Class Initialized
INFO - 2022-05-08 11:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:30:19 --> Controller Class Initialized
DEBUG - 2022-05-08 11:30:19 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:30:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:30:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:30:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:30:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:30:19 --> Final output sent to browser
DEBUG - 2022-05-08 11:30:19 --> Total execution time: 0.0262
INFO - 2022-05-08 11:30:20 --> Config Class Initialized
INFO - 2022-05-08 11:30:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:30:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:30:20 --> Utf8 Class Initialized
INFO - 2022-05-08 11:30:20 --> URI Class Initialized
INFO - 2022-05-08 11:30:20 --> Router Class Initialized
INFO - 2022-05-08 11:30:20 --> Output Class Initialized
INFO - 2022-05-08 11:30:20 --> Security Class Initialized
DEBUG - 2022-05-08 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:30:20 --> Input Class Initialized
INFO - 2022-05-08 11:30:20 --> Language Class Initialized
INFO - 2022-05-08 11:30:20 --> Language Class Initialized
INFO - 2022-05-08 11:30:20 --> Config Class Initialized
INFO - 2022-05-08 11:30:20 --> Loader Class Initialized
INFO - 2022-05-08 11:30:20 --> Helper loaded: url_helper
INFO - 2022-05-08 11:30:20 --> Database Driver Class Initialized
INFO - 2022-05-08 11:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:30:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:30:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:30:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:30:20 --> Total execution time: 0.0362
INFO - 2022-05-08 11:30:20 --> Config Class Initialized
INFO - 2022-05-08 11:30:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:30:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:30:20 --> Utf8 Class Initialized
INFO - 2022-05-08 11:30:20 --> URI Class Initialized
INFO - 2022-05-08 11:30:20 --> Router Class Initialized
INFO - 2022-05-08 11:30:20 --> Output Class Initialized
INFO - 2022-05-08 11:30:20 --> Security Class Initialized
DEBUG - 2022-05-08 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:30:20 --> Input Class Initialized
INFO - 2022-05-08 11:30:20 --> Language Class Initialized
INFO - 2022-05-08 11:30:20 --> Language Class Initialized
INFO - 2022-05-08 11:30:20 --> Config Class Initialized
INFO - 2022-05-08 11:30:20 --> Loader Class Initialized
INFO - 2022-05-08 11:30:20 --> Helper loaded: url_helper
INFO - 2022-05-08 11:30:20 --> Database Driver Class Initialized
INFO - 2022-05-08 11:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:30:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:30:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:30:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:30:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:30:20 --> Total execution time: 0.0299
INFO - 2022-05-08 11:33:10 --> Config Class Initialized
INFO - 2022-05-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:33:10 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:33:10 --> Utf8 Class Initialized
INFO - 2022-05-08 11:33:10 --> URI Class Initialized
INFO - 2022-05-08 11:33:10 --> Router Class Initialized
INFO - 2022-05-08 11:33:10 --> Output Class Initialized
INFO - 2022-05-08 11:33:10 --> Security Class Initialized
DEBUG - 2022-05-08 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:33:10 --> Input Class Initialized
INFO - 2022-05-08 11:33:10 --> Language Class Initialized
INFO - 2022-05-08 11:33:10 --> Language Class Initialized
INFO - 2022-05-08 11:33:10 --> Config Class Initialized
INFO - 2022-05-08 11:33:10 --> Loader Class Initialized
INFO - 2022-05-08 11:33:10 --> Helper loaded: url_helper
INFO - 2022-05-08 11:33:10 --> Database Driver Class Initialized
INFO - 2022-05-08 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:33:10 --> Controller Class Initialized
DEBUG - 2022-05-08 11:33:10 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:33:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:33:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:33:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:33:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:33:10 --> Final output sent to browser
DEBUG - 2022-05-08 11:33:10 --> Total execution time: 0.0602
INFO - 2022-05-08 11:33:20 --> Config Class Initialized
INFO - 2022-05-08 11:33:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:33:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:33:20 --> Utf8 Class Initialized
INFO - 2022-05-08 11:33:20 --> URI Class Initialized
INFO - 2022-05-08 11:33:20 --> Router Class Initialized
INFO - 2022-05-08 11:33:20 --> Output Class Initialized
INFO - 2022-05-08 11:33:20 --> Security Class Initialized
DEBUG - 2022-05-08 11:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:33:20 --> Input Class Initialized
INFO - 2022-05-08 11:33:20 --> Language Class Initialized
INFO - 2022-05-08 11:33:20 --> Language Class Initialized
INFO - 2022-05-08 11:33:20 --> Config Class Initialized
INFO - 2022-05-08 11:33:20 --> Loader Class Initialized
INFO - 2022-05-08 11:33:20 --> Helper loaded: url_helper
INFO - 2022-05-08 11:33:20 --> Database Driver Class Initialized
INFO - 2022-05-08 11:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:33:20 --> Controller Class Initialized
DEBUG - 2022-05-08 11:33:20 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:33:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:33:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:33:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:33:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:33:20 --> Final output sent to browser
DEBUG - 2022-05-08 11:33:20 --> Total execution time: 0.0503
INFO - 2022-05-08 11:33:43 --> Config Class Initialized
INFO - 2022-05-08 11:33:43 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:33:43 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:33:43 --> Utf8 Class Initialized
INFO - 2022-05-08 11:33:43 --> URI Class Initialized
INFO - 2022-05-08 11:33:43 --> Router Class Initialized
INFO - 2022-05-08 11:33:43 --> Output Class Initialized
INFO - 2022-05-08 11:33:43 --> Security Class Initialized
DEBUG - 2022-05-08 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:33:43 --> Input Class Initialized
INFO - 2022-05-08 11:33:43 --> Language Class Initialized
INFO - 2022-05-08 11:33:43 --> Language Class Initialized
INFO - 2022-05-08 11:33:43 --> Config Class Initialized
INFO - 2022-05-08 11:33:43 --> Loader Class Initialized
INFO - 2022-05-08 11:33:43 --> Helper loaded: url_helper
INFO - 2022-05-08 11:33:43 --> Database Driver Class Initialized
INFO - 2022-05-08 11:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:33:43 --> Controller Class Initialized
DEBUG - 2022-05-08 11:33:43 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:33:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:33:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:33:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 11:33:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:33:43 --> Final output sent to browser
DEBUG - 2022-05-08 11:33:43 --> Total execution time: 0.0432
INFO - 2022-05-08 11:34:52 --> Config Class Initialized
INFO - 2022-05-08 11:34:52 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:34:52 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:34:52 --> Utf8 Class Initialized
INFO - 2022-05-08 11:34:52 --> URI Class Initialized
INFO - 2022-05-08 11:34:52 --> Router Class Initialized
INFO - 2022-05-08 11:34:52 --> Output Class Initialized
INFO - 2022-05-08 11:34:52 --> Security Class Initialized
DEBUG - 2022-05-08 11:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:34:52 --> Input Class Initialized
INFO - 2022-05-08 11:34:52 --> Language Class Initialized
INFO - 2022-05-08 11:34:52 --> Language Class Initialized
INFO - 2022-05-08 11:34:52 --> Config Class Initialized
INFO - 2022-05-08 11:34:52 --> Loader Class Initialized
INFO - 2022-05-08 11:34:52 --> Helper loaded: url_helper
INFO - 2022-05-08 11:34:52 --> Database Driver Class Initialized
INFO - 2022-05-08 11:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:34:52 --> Controller Class Initialized
DEBUG - 2022-05-08 11:34:52 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:34:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:34:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:34:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:34:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:34:52 --> Final output sent to browser
DEBUG - 2022-05-08 11:34:52 --> Total execution time: 0.0482
INFO - 2022-05-08 11:35:29 --> Config Class Initialized
INFO - 2022-05-08 11:35:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:35:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:35:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:35:29 --> URI Class Initialized
INFO - 2022-05-08 11:35:29 --> Router Class Initialized
INFO - 2022-05-08 11:35:29 --> Output Class Initialized
INFO - 2022-05-08 11:35:29 --> Security Class Initialized
DEBUG - 2022-05-08 11:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:35:29 --> Input Class Initialized
INFO - 2022-05-08 11:35:29 --> Language Class Initialized
INFO - 2022-05-08 11:35:29 --> Language Class Initialized
INFO - 2022-05-08 11:35:29 --> Config Class Initialized
INFO - 2022-05-08 11:35:29 --> Loader Class Initialized
INFO - 2022-05-08 11:35:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:35:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:35:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:35:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:35:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:35:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:35:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:35:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:35:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:35:29 --> Total execution time: 0.0743
INFO - 2022-05-08 11:36:30 --> Config Class Initialized
INFO - 2022-05-08 11:36:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:36:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:36:30 --> Utf8 Class Initialized
INFO - 2022-05-08 11:36:30 --> URI Class Initialized
INFO - 2022-05-08 11:36:30 --> Router Class Initialized
INFO - 2022-05-08 11:36:30 --> Output Class Initialized
INFO - 2022-05-08 11:36:30 --> Security Class Initialized
DEBUG - 2022-05-08 11:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:36:30 --> Input Class Initialized
INFO - 2022-05-08 11:36:30 --> Language Class Initialized
INFO - 2022-05-08 11:36:30 --> Language Class Initialized
INFO - 2022-05-08 11:36:30 --> Config Class Initialized
INFO - 2022-05-08 11:36:30 --> Loader Class Initialized
INFO - 2022-05-08 11:36:30 --> Helper loaded: url_helper
INFO - 2022-05-08 11:36:30 --> Database Driver Class Initialized
INFO - 2022-05-08 11:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:36:30 --> Controller Class Initialized
DEBUG - 2022-05-08 11:36:30 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:36:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:36:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:36:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:36:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:36:30 --> Final output sent to browser
DEBUG - 2022-05-08 11:36:30 --> Total execution time: 0.0448
INFO - 2022-05-08 11:37:03 --> Config Class Initialized
INFO - 2022-05-08 11:37:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:37:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:37:03 --> Utf8 Class Initialized
INFO - 2022-05-08 11:37:03 --> URI Class Initialized
INFO - 2022-05-08 11:37:03 --> Router Class Initialized
INFO - 2022-05-08 11:37:03 --> Output Class Initialized
INFO - 2022-05-08 11:37:03 --> Security Class Initialized
DEBUG - 2022-05-08 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:37:03 --> Input Class Initialized
INFO - 2022-05-08 11:37:03 --> Language Class Initialized
INFO - 2022-05-08 11:37:03 --> Language Class Initialized
INFO - 2022-05-08 11:37:03 --> Config Class Initialized
INFO - 2022-05-08 11:37:03 --> Loader Class Initialized
INFO - 2022-05-08 11:37:03 --> Helper loaded: url_helper
INFO - 2022-05-08 11:37:03 --> Database Driver Class Initialized
INFO - 2022-05-08 11:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:37:04 --> Controller Class Initialized
DEBUG - 2022-05-08 11:37:04 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:37:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:37:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:37:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:37:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:37:04 --> Final output sent to browser
DEBUG - 2022-05-08 11:37:04 --> Total execution time: 0.8754
INFO - 2022-05-08 11:37:39 --> Config Class Initialized
INFO - 2022-05-08 11:37:39 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:37:39 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:37:39 --> Utf8 Class Initialized
INFO - 2022-05-08 11:37:39 --> URI Class Initialized
INFO - 2022-05-08 11:37:39 --> Router Class Initialized
INFO - 2022-05-08 11:37:39 --> Output Class Initialized
INFO - 2022-05-08 11:37:39 --> Security Class Initialized
DEBUG - 2022-05-08 11:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:37:39 --> Input Class Initialized
INFO - 2022-05-08 11:37:39 --> Language Class Initialized
INFO - 2022-05-08 11:37:39 --> Language Class Initialized
INFO - 2022-05-08 11:37:39 --> Config Class Initialized
INFO - 2022-05-08 11:37:39 --> Loader Class Initialized
INFO - 2022-05-08 11:37:39 --> Helper loaded: url_helper
INFO - 2022-05-08 11:37:39 --> Database Driver Class Initialized
INFO - 2022-05-08 11:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:37:39 --> Controller Class Initialized
DEBUG - 2022-05-08 11:37:39 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:37:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:37:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:37:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:37:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:37:39 --> Final output sent to browser
DEBUG - 2022-05-08 11:37:39 --> Total execution time: 0.0477
INFO - 2022-05-08 11:37:57 --> Config Class Initialized
INFO - 2022-05-08 11:37:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:37:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:37:57 --> Utf8 Class Initialized
INFO - 2022-05-08 11:37:57 --> URI Class Initialized
INFO - 2022-05-08 11:37:57 --> Router Class Initialized
INFO - 2022-05-08 11:37:57 --> Output Class Initialized
INFO - 2022-05-08 11:37:57 --> Security Class Initialized
DEBUG - 2022-05-08 11:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:37:57 --> Input Class Initialized
INFO - 2022-05-08 11:37:57 --> Language Class Initialized
INFO - 2022-05-08 11:37:57 --> Language Class Initialized
INFO - 2022-05-08 11:37:57 --> Config Class Initialized
INFO - 2022-05-08 11:37:57 --> Loader Class Initialized
INFO - 2022-05-08 11:37:57 --> Helper loaded: url_helper
INFO - 2022-05-08 11:37:57 --> Database Driver Class Initialized
INFO - 2022-05-08 11:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:37:57 --> Controller Class Initialized
DEBUG - 2022-05-08 11:37:57 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:37:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:37:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:37:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:37:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:37:57 --> Final output sent to browser
DEBUG - 2022-05-08 11:37:57 --> Total execution time: 0.0491
INFO - 2022-05-08 11:38:13 --> Config Class Initialized
INFO - 2022-05-08 11:38:13 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:38:13 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:38:13 --> Utf8 Class Initialized
INFO - 2022-05-08 11:38:13 --> URI Class Initialized
INFO - 2022-05-08 11:38:13 --> Router Class Initialized
INFO - 2022-05-08 11:38:13 --> Output Class Initialized
INFO - 2022-05-08 11:38:13 --> Security Class Initialized
DEBUG - 2022-05-08 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:38:13 --> Input Class Initialized
INFO - 2022-05-08 11:38:13 --> Language Class Initialized
INFO - 2022-05-08 11:38:13 --> Language Class Initialized
INFO - 2022-05-08 11:38:13 --> Config Class Initialized
INFO - 2022-05-08 11:38:13 --> Loader Class Initialized
INFO - 2022-05-08 11:38:13 --> Helper loaded: url_helper
INFO - 2022-05-08 11:38:13 --> Database Driver Class Initialized
INFO - 2022-05-08 11:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:38:13 --> Controller Class Initialized
DEBUG - 2022-05-08 11:38:13 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:38:13 --> Final output sent to browser
DEBUG - 2022-05-08 11:38:13 --> Total execution time: 0.0455
INFO - 2022-05-08 11:38:15 --> Config Class Initialized
INFO - 2022-05-08 11:38:15 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:38:15 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:38:15 --> Utf8 Class Initialized
INFO - 2022-05-08 11:38:15 --> URI Class Initialized
INFO - 2022-05-08 11:38:15 --> Router Class Initialized
INFO - 2022-05-08 11:38:15 --> Output Class Initialized
INFO - 2022-05-08 11:38:15 --> Security Class Initialized
DEBUG - 2022-05-08 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:38:15 --> Input Class Initialized
INFO - 2022-05-08 11:38:15 --> Language Class Initialized
INFO - 2022-05-08 11:38:15 --> Language Class Initialized
INFO - 2022-05-08 11:38:15 --> Config Class Initialized
INFO - 2022-05-08 11:38:15 --> Loader Class Initialized
INFO - 2022-05-08 11:38:15 --> Helper loaded: url_helper
INFO - 2022-05-08 11:38:15 --> Database Driver Class Initialized
INFO - 2022-05-08 11:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:38:15 --> Controller Class Initialized
DEBUG - 2022-05-08 11:38:15 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:38:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:38:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:38:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:38:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:38:15 --> Final output sent to browser
DEBUG - 2022-05-08 11:38:15 --> Total execution time: 0.0430
INFO - 2022-05-08 11:38:40 --> Config Class Initialized
INFO - 2022-05-08 11:38:40 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:38:40 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:38:40 --> Utf8 Class Initialized
INFO - 2022-05-08 11:38:40 --> URI Class Initialized
INFO - 2022-05-08 11:38:40 --> Router Class Initialized
INFO - 2022-05-08 11:38:40 --> Output Class Initialized
INFO - 2022-05-08 11:38:40 --> Security Class Initialized
DEBUG - 2022-05-08 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:38:40 --> Input Class Initialized
INFO - 2022-05-08 11:38:40 --> Language Class Initialized
INFO - 2022-05-08 11:38:40 --> Language Class Initialized
INFO - 2022-05-08 11:38:40 --> Config Class Initialized
INFO - 2022-05-08 11:38:40 --> Loader Class Initialized
INFO - 2022-05-08 11:38:40 --> Helper loaded: url_helper
INFO - 2022-05-08 11:38:40 --> Database Driver Class Initialized
INFO - 2022-05-08 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:38:40 --> Controller Class Initialized
DEBUG - 2022-05-08 11:38:40 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:38:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:38:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:38:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:38:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:38:40 --> Final output sent to browser
DEBUG - 2022-05-08 11:38:40 --> Total execution time: 0.0538
INFO - 2022-05-08 11:38:59 --> Config Class Initialized
INFO - 2022-05-08 11:38:59 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:38:59 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:38:59 --> Utf8 Class Initialized
INFO - 2022-05-08 11:38:59 --> URI Class Initialized
INFO - 2022-05-08 11:38:59 --> Router Class Initialized
INFO - 2022-05-08 11:38:59 --> Output Class Initialized
INFO - 2022-05-08 11:38:59 --> Security Class Initialized
DEBUG - 2022-05-08 11:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:38:59 --> Input Class Initialized
INFO - 2022-05-08 11:38:59 --> Language Class Initialized
INFO - 2022-05-08 11:38:59 --> Language Class Initialized
INFO - 2022-05-08 11:38:59 --> Config Class Initialized
INFO - 2022-05-08 11:38:59 --> Loader Class Initialized
INFO - 2022-05-08 11:38:59 --> Helper loaded: url_helper
INFO - 2022-05-08 11:38:59 --> Database Driver Class Initialized
INFO - 2022-05-08 11:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:38:59 --> Controller Class Initialized
DEBUG - 2022-05-08 11:38:59 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:38:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:38:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:38:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:38:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:38:59 --> Final output sent to browser
DEBUG - 2022-05-08 11:38:59 --> Total execution time: 0.0557
INFO - 2022-05-08 11:39:54 --> Config Class Initialized
INFO - 2022-05-08 11:39:54 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:39:54 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:39:54 --> Utf8 Class Initialized
INFO - 2022-05-08 11:39:54 --> URI Class Initialized
INFO - 2022-05-08 11:39:54 --> Router Class Initialized
INFO - 2022-05-08 11:39:54 --> Output Class Initialized
INFO - 2022-05-08 11:39:54 --> Security Class Initialized
DEBUG - 2022-05-08 11:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:39:54 --> Input Class Initialized
INFO - 2022-05-08 11:39:54 --> Language Class Initialized
INFO - 2022-05-08 11:39:54 --> Language Class Initialized
INFO - 2022-05-08 11:39:54 --> Config Class Initialized
INFO - 2022-05-08 11:39:54 --> Loader Class Initialized
INFO - 2022-05-08 11:39:54 --> Helper loaded: url_helper
INFO - 2022-05-08 11:39:54 --> Database Driver Class Initialized
INFO - 2022-05-08 11:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:39:54 --> Controller Class Initialized
DEBUG - 2022-05-08 11:39:54 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:39:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:39:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:39:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:39:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:39:54 --> Final output sent to browser
DEBUG - 2022-05-08 11:39:54 --> Total execution time: 0.0484
INFO - 2022-05-08 11:40:33 --> Config Class Initialized
INFO - 2022-05-08 11:40:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:40:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:40:33 --> Utf8 Class Initialized
INFO - 2022-05-08 11:40:33 --> URI Class Initialized
INFO - 2022-05-08 11:40:33 --> Router Class Initialized
INFO - 2022-05-08 11:40:33 --> Output Class Initialized
INFO - 2022-05-08 11:40:33 --> Security Class Initialized
DEBUG - 2022-05-08 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:40:33 --> Input Class Initialized
INFO - 2022-05-08 11:40:33 --> Language Class Initialized
INFO - 2022-05-08 11:40:33 --> Language Class Initialized
INFO - 2022-05-08 11:40:33 --> Config Class Initialized
INFO - 2022-05-08 11:40:33 --> Loader Class Initialized
INFO - 2022-05-08 11:40:33 --> Helper loaded: url_helper
INFO - 2022-05-08 11:40:33 --> Database Driver Class Initialized
INFO - 2022-05-08 11:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:40:35 --> Controller Class Initialized
DEBUG - 2022-05-08 11:40:35 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:40:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:40:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:40:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:40:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:40:35 --> Final output sent to browser
DEBUG - 2022-05-08 11:40:35 --> Total execution time: 1.9860
INFO - 2022-05-08 11:40:55 --> Config Class Initialized
INFO - 2022-05-08 11:40:55 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:40:55 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:40:55 --> Utf8 Class Initialized
INFO - 2022-05-08 11:40:55 --> URI Class Initialized
INFO - 2022-05-08 11:40:55 --> Router Class Initialized
INFO - 2022-05-08 11:40:55 --> Output Class Initialized
INFO - 2022-05-08 11:40:55 --> Security Class Initialized
DEBUG - 2022-05-08 11:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:40:55 --> Input Class Initialized
INFO - 2022-05-08 11:40:55 --> Language Class Initialized
INFO - 2022-05-08 11:40:55 --> Language Class Initialized
INFO - 2022-05-08 11:40:55 --> Config Class Initialized
INFO - 2022-05-08 11:40:55 --> Loader Class Initialized
INFO - 2022-05-08 11:40:55 --> Helper loaded: url_helper
INFO - 2022-05-08 11:40:55 --> Database Driver Class Initialized
INFO - 2022-05-08 11:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:40:55 --> Controller Class Initialized
DEBUG - 2022-05-08 11:40:55 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:40:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:40:55 --> Final output sent to browser
DEBUG - 2022-05-08 11:40:55 --> Total execution time: 0.0391
INFO - 2022-05-08 11:41:09 --> Config Class Initialized
INFO - 2022-05-08 11:41:09 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:41:09 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:41:09 --> Utf8 Class Initialized
INFO - 2022-05-08 11:41:09 --> URI Class Initialized
INFO - 2022-05-08 11:41:09 --> Router Class Initialized
INFO - 2022-05-08 11:41:09 --> Output Class Initialized
INFO - 2022-05-08 11:41:09 --> Security Class Initialized
DEBUG - 2022-05-08 11:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:41:09 --> Input Class Initialized
INFO - 2022-05-08 11:41:09 --> Language Class Initialized
INFO - 2022-05-08 11:41:09 --> Language Class Initialized
INFO - 2022-05-08 11:41:09 --> Config Class Initialized
INFO - 2022-05-08 11:41:09 --> Loader Class Initialized
INFO - 2022-05-08 11:41:09 --> Helper loaded: url_helper
INFO - 2022-05-08 11:41:09 --> Database Driver Class Initialized
INFO - 2022-05-08 11:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:41:09 --> Controller Class Initialized
DEBUG - 2022-05-08 11:41:09 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:41:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:41:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:41:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:41:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:41:09 --> Final output sent to browser
DEBUG - 2022-05-08 11:41:09 --> Total execution time: 0.0372
INFO - 2022-05-08 11:41:29 --> Config Class Initialized
INFO - 2022-05-08 11:41:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:41:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:41:29 --> Utf8 Class Initialized
INFO - 2022-05-08 11:41:29 --> URI Class Initialized
INFO - 2022-05-08 11:41:29 --> Router Class Initialized
INFO - 2022-05-08 11:41:29 --> Output Class Initialized
INFO - 2022-05-08 11:41:29 --> Security Class Initialized
DEBUG - 2022-05-08 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:41:29 --> Input Class Initialized
INFO - 2022-05-08 11:41:29 --> Language Class Initialized
INFO - 2022-05-08 11:41:29 --> Language Class Initialized
INFO - 2022-05-08 11:41:29 --> Config Class Initialized
INFO - 2022-05-08 11:41:29 --> Loader Class Initialized
INFO - 2022-05-08 11:41:29 --> Helper loaded: url_helper
INFO - 2022-05-08 11:41:29 --> Database Driver Class Initialized
INFO - 2022-05-08 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:41:29 --> Controller Class Initialized
DEBUG - 2022-05-08 11:41:29 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:41:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:41:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:41:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:41:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:41:29 --> Final output sent to browser
DEBUG - 2022-05-08 11:41:29 --> Total execution time: 0.0513
INFO - 2022-05-08 11:41:59 --> Config Class Initialized
INFO - 2022-05-08 11:41:59 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:41:59 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:41:59 --> Utf8 Class Initialized
INFO - 2022-05-08 11:41:59 --> URI Class Initialized
INFO - 2022-05-08 11:41:59 --> Router Class Initialized
INFO - 2022-05-08 11:41:59 --> Output Class Initialized
INFO - 2022-05-08 11:41:59 --> Security Class Initialized
DEBUG - 2022-05-08 11:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:41:59 --> Input Class Initialized
INFO - 2022-05-08 11:41:59 --> Language Class Initialized
INFO - 2022-05-08 11:41:59 --> Language Class Initialized
INFO - 2022-05-08 11:41:59 --> Config Class Initialized
INFO - 2022-05-08 11:41:59 --> Loader Class Initialized
INFO - 2022-05-08 11:41:59 --> Helper loaded: url_helper
INFO - 2022-05-08 11:41:59 --> Database Driver Class Initialized
INFO - 2022-05-08 11:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:41:59 --> Controller Class Initialized
DEBUG - 2022-05-08 11:41:59 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:41:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:41:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:42:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:42:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:42:00 --> Final output sent to browser
DEBUG - 2022-05-08 11:42:00 --> Total execution time: 1.1885
INFO - 2022-05-08 11:42:26 --> Config Class Initialized
INFO - 2022-05-08 11:42:26 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:42:26 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:42:26 --> Utf8 Class Initialized
INFO - 2022-05-08 11:42:26 --> URI Class Initialized
INFO - 2022-05-08 11:42:26 --> Router Class Initialized
INFO - 2022-05-08 11:42:26 --> Output Class Initialized
INFO - 2022-05-08 11:42:26 --> Security Class Initialized
DEBUG - 2022-05-08 11:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:42:26 --> Input Class Initialized
INFO - 2022-05-08 11:42:26 --> Language Class Initialized
INFO - 2022-05-08 11:42:26 --> Language Class Initialized
INFO - 2022-05-08 11:42:26 --> Config Class Initialized
INFO - 2022-05-08 11:42:26 --> Loader Class Initialized
INFO - 2022-05-08 11:42:26 --> Helper loaded: url_helper
INFO - 2022-05-08 11:42:26 --> Database Driver Class Initialized
INFO - 2022-05-08 11:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:42:26 --> Controller Class Initialized
DEBUG - 2022-05-08 11:42:26 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:42:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:42:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:42:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:42:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:42:26 --> Final output sent to browser
DEBUG - 2022-05-08 11:42:26 --> Total execution time: 0.0462
INFO - 2022-05-08 11:42:58 --> Config Class Initialized
INFO - 2022-05-08 11:42:58 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:42:58 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:42:58 --> Utf8 Class Initialized
INFO - 2022-05-08 11:42:58 --> URI Class Initialized
INFO - 2022-05-08 11:42:58 --> Router Class Initialized
INFO - 2022-05-08 11:42:58 --> Output Class Initialized
INFO - 2022-05-08 11:42:58 --> Security Class Initialized
DEBUG - 2022-05-08 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:42:58 --> Input Class Initialized
INFO - 2022-05-08 11:42:58 --> Language Class Initialized
INFO - 2022-05-08 11:42:58 --> Language Class Initialized
INFO - 2022-05-08 11:42:58 --> Config Class Initialized
INFO - 2022-05-08 11:42:58 --> Loader Class Initialized
INFO - 2022-05-08 11:42:58 --> Helper loaded: url_helper
INFO - 2022-05-08 11:42:58 --> Database Driver Class Initialized
INFO - 2022-05-08 11:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:42:58 --> Controller Class Initialized
DEBUG - 2022-05-08 11:42:58 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:42:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:42:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:42:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:42:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:42:58 --> Final output sent to browser
DEBUG - 2022-05-08 11:42:58 --> Total execution time: 0.2035
INFO - 2022-05-08 11:43:18 --> Config Class Initialized
INFO - 2022-05-08 11:43:18 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:43:18 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:43:18 --> Utf8 Class Initialized
INFO - 2022-05-08 11:43:18 --> URI Class Initialized
INFO - 2022-05-08 11:43:18 --> Router Class Initialized
INFO - 2022-05-08 11:43:18 --> Output Class Initialized
INFO - 2022-05-08 11:43:18 --> Security Class Initialized
DEBUG - 2022-05-08 11:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:43:18 --> Input Class Initialized
INFO - 2022-05-08 11:43:18 --> Language Class Initialized
INFO - 2022-05-08 11:43:18 --> Language Class Initialized
INFO - 2022-05-08 11:43:18 --> Config Class Initialized
INFO - 2022-05-08 11:43:18 --> Loader Class Initialized
INFO - 2022-05-08 11:43:18 --> Helper loaded: url_helper
INFO - 2022-05-08 11:43:18 --> Database Driver Class Initialized
INFO - 2022-05-08 11:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:43:18 --> Controller Class Initialized
DEBUG - 2022-05-08 11:43:18 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:43:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:43:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:43:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:43:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:43:18 --> Final output sent to browser
DEBUG - 2022-05-08 11:43:18 --> Total execution time: 0.0468
INFO - 2022-05-08 11:43:47 --> Config Class Initialized
INFO - 2022-05-08 11:43:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:43:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:43:47 --> Utf8 Class Initialized
INFO - 2022-05-08 11:43:47 --> URI Class Initialized
INFO - 2022-05-08 11:43:47 --> Router Class Initialized
INFO - 2022-05-08 11:43:47 --> Output Class Initialized
INFO - 2022-05-08 11:43:47 --> Security Class Initialized
DEBUG - 2022-05-08 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:43:47 --> Input Class Initialized
INFO - 2022-05-08 11:43:47 --> Language Class Initialized
INFO - 2022-05-08 11:43:47 --> Language Class Initialized
INFO - 2022-05-08 11:43:47 --> Config Class Initialized
INFO - 2022-05-08 11:43:47 --> Loader Class Initialized
INFO - 2022-05-08 11:43:47 --> Helper loaded: url_helper
INFO - 2022-05-08 11:43:47 --> Database Driver Class Initialized
INFO - 2022-05-08 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:43:47 --> Controller Class Initialized
DEBUG - 2022-05-08 11:43:47 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:43:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:43:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:43:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:43:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:43:47 --> Final output sent to browser
DEBUG - 2022-05-08 11:43:47 --> Total execution time: 0.0521
INFO - 2022-05-08 11:43:58 --> Config Class Initialized
INFO - 2022-05-08 11:43:58 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:43:58 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:43:58 --> Utf8 Class Initialized
INFO - 2022-05-08 11:43:58 --> URI Class Initialized
INFO - 2022-05-08 11:43:58 --> Router Class Initialized
INFO - 2022-05-08 11:43:58 --> Output Class Initialized
INFO - 2022-05-08 11:43:58 --> Security Class Initialized
DEBUG - 2022-05-08 11:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:43:58 --> Input Class Initialized
INFO - 2022-05-08 11:43:58 --> Language Class Initialized
ERROR - 2022-05-08 11:43:58 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:44:27 --> Config Class Initialized
INFO - 2022-05-08 11:44:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:44:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:44:27 --> Utf8 Class Initialized
INFO - 2022-05-08 11:44:27 --> URI Class Initialized
INFO - 2022-05-08 11:44:27 --> Router Class Initialized
INFO - 2022-05-08 11:44:27 --> Output Class Initialized
INFO - 2022-05-08 11:44:27 --> Security Class Initialized
DEBUG - 2022-05-08 11:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:44:27 --> Input Class Initialized
INFO - 2022-05-08 11:44:27 --> Language Class Initialized
INFO - 2022-05-08 11:44:27 --> Language Class Initialized
INFO - 2022-05-08 11:44:27 --> Config Class Initialized
INFO - 2022-05-08 11:44:27 --> Loader Class Initialized
INFO - 2022-05-08 11:44:27 --> Helper loaded: url_helper
INFO - 2022-05-08 11:44:27 --> Database Driver Class Initialized
INFO - 2022-05-08 11:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:44:27 --> Controller Class Initialized
DEBUG - 2022-05-08 11:44:27 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:44:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:44:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:44:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:44:28 --> Final output sent to browser
DEBUG - 2022-05-08 11:44:28 --> Total execution time: 0.3627
INFO - 2022-05-08 11:44:43 --> Config Class Initialized
INFO - 2022-05-08 11:44:43 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:44:43 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:44:43 --> Utf8 Class Initialized
INFO - 2022-05-08 11:44:43 --> URI Class Initialized
INFO - 2022-05-08 11:44:43 --> Router Class Initialized
INFO - 2022-05-08 11:44:43 --> Output Class Initialized
INFO - 2022-05-08 11:44:43 --> Security Class Initialized
DEBUG - 2022-05-08 11:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:44:43 --> Input Class Initialized
INFO - 2022-05-08 11:44:43 --> Language Class Initialized
INFO - 2022-05-08 11:44:43 --> Language Class Initialized
INFO - 2022-05-08 11:44:43 --> Config Class Initialized
INFO - 2022-05-08 11:44:43 --> Loader Class Initialized
INFO - 2022-05-08 11:44:43 --> Helper loaded: url_helper
INFO - 2022-05-08 11:44:43 --> Database Driver Class Initialized
INFO - 2022-05-08 11:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:44:43 --> Controller Class Initialized
DEBUG - 2022-05-08 11:44:43 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:44:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:44:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:44:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:44:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:44:43 --> Final output sent to browser
DEBUG - 2022-05-08 11:44:43 --> Total execution time: 0.0981
INFO - 2022-05-08 11:44:49 --> Config Class Initialized
INFO - 2022-05-08 11:44:49 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:44:49 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:44:49 --> Utf8 Class Initialized
INFO - 2022-05-08 11:44:49 --> URI Class Initialized
INFO - 2022-05-08 11:44:49 --> Router Class Initialized
INFO - 2022-05-08 11:44:49 --> Output Class Initialized
INFO - 2022-05-08 11:44:49 --> Security Class Initialized
DEBUG - 2022-05-08 11:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:44:49 --> Input Class Initialized
INFO - 2022-05-08 11:44:49 --> Language Class Initialized
INFO - 2022-05-08 11:44:49 --> Language Class Initialized
INFO - 2022-05-08 11:44:49 --> Config Class Initialized
INFO - 2022-05-08 11:44:49 --> Loader Class Initialized
INFO - 2022-05-08 11:44:49 --> Helper loaded: url_helper
INFO - 2022-05-08 11:44:49 --> Database Driver Class Initialized
INFO - 2022-05-08 11:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:44:49 --> Controller Class Initialized
DEBUG - 2022-05-08 11:44:49 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:44:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:44:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:44:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:44:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:44:49 --> Final output sent to browser
DEBUG - 2022-05-08 11:44:49 --> Total execution time: 0.0394
INFO - 2022-05-08 11:45:06 --> Config Class Initialized
INFO - 2022-05-08 11:45:06 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:45:06 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:45:06 --> Utf8 Class Initialized
INFO - 2022-05-08 11:45:06 --> URI Class Initialized
INFO - 2022-05-08 11:45:06 --> Router Class Initialized
INFO - 2022-05-08 11:45:06 --> Output Class Initialized
INFO - 2022-05-08 11:45:06 --> Security Class Initialized
DEBUG - 2022-05-08 11:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:45:06 --> Input Class Initialized
INFO - 2022-05-08 11:45:06 --> Language Class Initialized
INFO - 2022-05-08 11:45:06 --> Language Class Initialized
INFO - 2022-05-08 11:45:06 --> Config Class Initialized
INFO - 2022-05-08 11:45:06 --> Loader Class Initialized
INFO - 2022-05-08 11:45:06 --> Helper loaded: url_helper
INFO - 2022-05-08 11:45:06 --> Database Driver Class Initialized
INFO - 2022-05-08 11:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:45:06 --> Controller Class Initialized
DEBUG - 2022-05-08 11:45:06 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:45:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:45:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:45:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:45:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:45:06 --> Final output sent to browser
DEBUG - 2022-05-08 11:45:06 --> Total execution time: 0.8036
INFO - 2022-05-08 11:45:15 --> Config Class Initialized
INFO - 2022-05-08 11:45:15 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:45:15 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:45:15 --> Utf8 Class Initialized
INFO - 2022-05-08 11:45:15 --> URI Class Initialized
INFO - 2022-05-08 11:45:15 --> Router Class Initialized
INFO - 2022-05-08 11:45:15 --> Output Class Initialized
INFO - 2022-05-08 11:45:15 --> Security Class Initialized
DEBUG - 2022-05-08 11:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:45:15 --> Input Class Initialized
INFO - 2022-05-08 11:45:15 --> Language Class Initialized
INFO - 2022-05-08 11:45:15 --> Language Class Initialized
INFO - 2022-05-08 11:45:15 --> Config Class Initialized
INFO - 2022-05-08 11:45:15 --> Loader Class Initialized
INFO - 2022-05-08 11:45:15 --> Helper loaded: url_helper
INFO - 2022-05-08 11:45:15 --> Database Driver Class Initialized
INFO - 2022-05-08 11:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:45:15 --> Controller Class Initialized
DEBUG - 2022-05-08 11:45:15 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:45:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:45:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:45:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:45:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:45:15 --> Final output sent to browser
DEBUG - 2022-05-08 11:45:15 --> Total execution time: 0.0521
INFO - 2022-05-08 11:45:43 --> Config Class Initialized
INFO - 2022-05-08 11:45:43 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:45:43 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:45:43 --> Utf8 Class Initialized
INFO - 2022-05-08 11:45:43 --> URI Class Initialized
INFO - 2022-05-08 11:45:43 --> Router Class Initialized
INFO - 2022-05-08 11:45:43 --> Output Class Initialized
INFO - 2022-05-08 11:45:43 --> Security Class Initialized
DEBUG - 2022-05-08 11:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:45:43 --> Input Class Initialized
INFO - 2022-05-08 11:45:43 --> Language Class Initialized
INFO - 2022-05-08 11:45:43 --> Language Class Initialized
INFO - 2022-05-08 11:45:43 --> Config Class Initialized
INFO - 2022-05-08 11:45:43 --> Loader Class Initialized
INFO - 2022-05-08 11:45:43 --> Helper loaded: url_helper
INFO - 2022-05-08 11:45:43 --> Database Driver Class Initialized
INFO - 2022-05-08 11:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:45:43 --> Controller Class Initialized
DEBUG - 2022-05-08 11:45:43 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:45:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:45:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:45:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:45:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:45:43 --> Final output sent to browser
DEBUG - 2022-05-08 11:45:43 --> Total execution time: 0.0384
INFO - 2022-05-08 11:45:49 --> Config Class Initialized
INFO - 2022-05-08 11:45:49 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:45:49 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:45:49 --> Utf8 Class Initialized
INFO - 2022-05-08 11:45:49 --> URI Class Initialized
INFO - 2022-05-08 11:45:49 --> Router Class Initialized
INFO - 2022-05-08 11:45:49 --> Output Class Initialized
INFO - 2022-05-08 11:45:49 --> Security Class Initialized
DEBUG - 2022-05-08 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:45:49 --> Input Class Initialized
INFO - 2022-05-08 11:45:49 --> Language Class Initialized
INFO - 2022-05-08 11:45:49 --> Language Class Initialized
INFO - 2022-05-08 11:45:49 --> Config Class Initialized
INFO - 2022-05-08 11:45:49 --> Loader Class Initialized
INFO - 2022-05-08 11:45:49 --> Helper loaded: url_helper
INFO - 2022-05-08 11:45:49 --> Database Driver Class Initialized
INFO - 2022-05-08 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:45:49 --> Controller Class Initialized
DEBUG - 2022-05-08 11:45:49 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:45:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:45:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:45:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:45:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:45:49 --> Final output sent to browser
DEBUG - 2022-05-08 11:45:49 --> Total execution time: 0.0467
INFO - 2022-05-08 11:45:56 --> Config Class Initialized
INFO - 2022-05-08 11:45:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:45:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:45:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:45:56 --> URI Class Initialized
INFO - 2022-05-08 11:45:56 --> Router Class Initialized
INFO - 2022-05-08 11:45:56 --> Output Class Initialized
INFO - 2022-05-08 11:45:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:45:56 --> Input Class Initialized
INFO - 2022-05-08 11:45:56 --> Language Class Initialized
INFO - 2022-05-08 11:45:56 --> Language Class Initialized
INFO - 2022-05-08 11:45:56 --> Config Class Initialized
INFO - 2022-05-08 11:45:56 --> Loader Class Initialized
INFO - 2022-05-08 11:45:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:45:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:45:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:45:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:45:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:45:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:45:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:45:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:45:58 --> Final output sent to browser
DEBUG - 2022-05-08 11:45:58 --> Total execution time: 3.3089
INFO - 2022-05-08 11:46:08 --> Config Class Initialized
INFO - 2022-05-08 11:46:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:46:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:46:08 --> Utf8 Class Initialized
INFO - 2022-05-08 11:46:08 --> URI Class Initialized
INFO - 2022-05-08 11:46:08 --> Router Class Initialized
INFO - 2022-05-08 11:46:08 --> Output Class Initialized
INFO - 2022-05-08 11:46:08 --> Security Class Initialized
DEBUG - 2022-05-08 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:46:08 --> Input Class Initialized
INFO - 2022-05-08 11:46:08 --> Language Class Initialized
INFO - 2022-05-08 11:46:08 --> Language Class Initialized
INFO - 2022-05-08 11:46:08 --> Config Class Initialized
INFO - 2022-05-08 11:46:08 --> Loader Class Initialized
INFO - 2022-05-08 11:46:08 --> Helper loaded: url_helper
INFO - 2022-05-08 11:46:08 --> Database Driver Class Initialized
INFO - 2022-05-08 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:46:08 --> Controller Class Initialized
DEBUG - 2022-05-08 11:46:08 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:46:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:46:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:46:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:46:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:46:09 --> Final output sent to browser
DEBUG - 2022-05-08 11:46:09 --> Total execution time: 1.7484
INFO - 2022-05-08 11:46:21 --> Config Class Initialized
INFO - 2022-05-08 11:46:21 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:46:21 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:46:21 --> Utf8 Class Initialized
INFO - 2022-05-08 11:46:21 --> URI Class Initialized
INFO - 2022-05-08 11:46:21 --> Router Class Initialized
INFO - 2022-05-08 11:46:21 --> Output Class Initialized
INFO - 2022-05-08 11:46:21 --> Security Class Initialized
DEBUG - 2022-05-08 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:46:21 --> Input Class Initialized
INFO - 2022-05-08 11:46:21 --> Language Class Initialized
INFO - 2022-05-08 11:46:21 --> Language Class Initialized
INFO - 2022-05-08 11:46:21 --> Config Class Initialized
INFO - 2022-05-08 11:46:21 --> Loader Class Initialized
INFO - 2022-05-08 11:46:21 --> Helper loaded: url_helper
INFO - 2022-05-08 11:46:21 --> Database Driver Class Initialized
INFO - 2022-05-08 11:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:46:21 --> Controller Class Initialized
DEBUG - 2022-05-08 11:46:21 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:46:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:46:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:46:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:46:21 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:46:21 --> Final output sent to browser
DEBUG - 2022-05-08 11:46:21 --> Total execution time: 0.0533
INFO - 2022-05-08 11:47:14 --> Config Class Initialized
INFO - 2022-05-08 11:47:14 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:47:14 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:47:14 --> Utf8 Class Initialized
INFO - 2022-05-08 11:47:14 --> URI Class Initialized
INFO - 2022-05-08 11:47:14 --> Router Class Initialized
INFO - 2022-05-08 11:47:14 --> Output Class Initialized
INFO - 2022-05-08 11:47:14 --> Security Class Initialized
DEBUG - 2022-05-08 11:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:47:14 --> Input Class Initialized
INFO - 2022-05-08 11:47:14 --> Language Class Initialized
INFO - 2022-05-08 11:47:14 --> Language Class Initialized
INFO - 2022-05-08 11:47:14 --> Config Class Initialized
INFO - 2022-05-08 11:47:14 --> Loader Class Initialized
INFO - 2022-05-08 11:47:14 --> Helper loaded: url_helper
INFO - 2022-05-08 11:47:14 --> Database Driver Class Initialized
INFO - 2022-05-08 11:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:47:14 --> Controller Class Initialized
DEBUG - 2022-05-08 11:47:14 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:47:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:47:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:47:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:47:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:47:14 --> Final output sent to browser
DEBUG - 2022-05-08 11:47:14 --> Total execution time: 0.0555
INFO - 2022-05-08 11:47:27 --> Config Class Initialized
INFO - 2022-05-08 11:47:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:47:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:47:27 --> Utf8 Class Initialized
INFO - 2022-05-08 11:47:27 --> URI Class Initialized
INFO - 2022-05-08 11:47:27 --> Router Class Initialized
INFO - 2022-05-08 11:47:27 --> Output Class Initialized
INFO - 2022-05-08 11:47:27 --> Security Class Initialized
DEBUG - 2022-05-08 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:47:27 --> Input Class Initialized
INFO - 2022-05-08 11:47:27 --> Language Class Initialized
INFO - 2022-05-08 11:47:27 --> Language Class Initialized
INFO - 2022-05-08 11:47:27 --> Config Class Initialized
INFO - 2022-05-08 11:47:27 --> Loader Class Initialized
INFO - 2022-05-08 11:47:27 --> Helper loaded: url_helper
INFO - 2022-05-08 11:47:27 --> Database Driver Class Initialized
INFO - 2022-05-08 11:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:47:27 --> Controller Class Initialized
DEBUG - 2022-05-08 11:47:27 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:47:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:47:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:47:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:47:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:47:28 --> Final output sent to browser
DEBUG - 2022-05-08 11:47:28 --> Total execution time: 0.2671
INFO - 2022-05-08 11:47:48 --> Config Class Initialized
INFO - 2022-05-08 11:47:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:47:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:47:48 --> Utf8 Class Initialized
INFO - 2022-05-08 11:47:48 --> URI Class Initialized
INFO - 2022-05-08 11:47:48 --> Router Class Initialized
INFO - 2022-05-08 11:47:48 --> Output Class Initialized
INFO - 2022-05-08 11:47:48 --> Security Class Initialized
DEBUG - 2022-05-08 11:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:47:48 --> Input Class Initialized
INFO - 2022-05-08 11:47:48 --> Language Class Initialized
INFO - 2022-05-08 11:47:48 --> Language Class Initialized
INFO - 2022-05-08 11:47:48 --> Config Class Initialized
INFO - 2022-05-08 11:47:48 --> Loader Class Initialized
INFO - 2022-05-08 11:47:48 --> Helper loaded: url_helper
INFO - 2022-05-08 11:47:48 --> Database Driver Class Initialized
INFO - 2022-05-08 11:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:47:48 --> Controller Class Initialized
DEBUG - 2022-05-08 11:47:48 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:47:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:47:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:47:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:47:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:47:48 --> Final output sent to browser
DEBUG - 2022-05-08 11:47:48 --> Total execution time: 0.0542
INFO - 2022-05-08 11:47:55 --> Config Class Initialized
INFO - 2022-05-08 11:47:55 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:47:55 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:47:55 --> Utf8 Class Initialized
INFO - 2022-05-08 11:47:55 --> URI Class Initialized
INFO - 2022-05-08 11:47:55 --> Router Class Initialized
INFO - 2022-05-08 11:47:55 --> Output Class Initialized
INFO - 2022-05-08 11:47:55 --> Security Class Initialized
DEBUG - 2022-05-08 11:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:47:55 --> Input Class Initialized
INFO - 2022-05-08 11:47:55 --> Language Class Initialized
INFO - 2022-05-08 11:47:55 --> Language Class Initialized
INFO - 2022-05-08 11:47:55 --> Config Class Initialized
INFO - 2022-05-08 11:47:55 --> Loader Class Initialized
INFO - 2022-05-08 11:47:55 --> Helper loaded: url_helper
INFO - 2022-05-08 11:47:55 --> Database Driver Class Initialized
INFO - 2022-05-08 11:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:47:55 --> Controller Class Initialized
DEBUG - 2022-05-08 11:47:55 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:47:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:47:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:47:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:47:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:47:55 --> Final output sent to browser
DEBUG - 2022-05-08 11:47:55 --> Total execution time: 0.0572
INFO - 2022-05-08 11:48:02 --> Config Class Initialized
INFO - 2022-05-08 11:48:02 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:48:02 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:48:02 --> Utf8 Class Initialized
INFO - 2022-05-08 11:48:02 --> URI Class Initialized
INFO - 2022-05-08 11:48:02 --> Router Class Initialized
INFO - 2022-05-08 11:48:02 --> Output Class Initialized
INFO - 2022-05-08 11:48:02 --> Security Class Initialized
DEBUG - 2022-05-08 11:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:48:02 --> Input Class Initialized
INFO - 2022-05-08 11:48:02 --> Language Class Initialized
INFO - 2022-05-08 11:48:02 --> Language Class Initialized
INFO - 2022-05-08 11:48:02 --> Config Class Initialized
INFO - 2022-05-08 11:48:02 --> Loader Class Initialized
INFO - 2022-05-08 11:48:02 --> Helper loaded: url_helper
INFO - 2022-05-08 11:48:02 --> Database Driver Class Initialized
INFO - 2022-05-08 11:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:48:02 --> Controller Class Initialized
DEBUG - 2022-05-08 11:48:02 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:48:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:48:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:48:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:48:02 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:48:02 --> Final output sent to browser
DEBUG - 2022-05-08 11:48:02 --> Total execution time: 0.0553
INFO - 2022-05-08 11:48:07 --> Config Class Initialized
INFO - 2022-05-08 11:48:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:48:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:48:07 --> Utf8 Class Initialized
INFO - 2022-05-08 11:48:07 --> URI Class Initialized
INFO - 2022-05-08 11:48:07 --> Router Class Initialized
INFO - 2022-05-08 11:48:07 --> Output Class Initialized
INFO - 2022-05-08 11:48:07 --> Security Class Initialized
DEBUG - 2022-05-08 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:48:07 --> Input Class Initialized
INFO - 2022-05-08 11:48:07 --> Language Class Initialized
INFO - 2022-05-08 11:48:07 --> Language Class Initialized
INFO - 2022-05-08 11:48:07 --> Config Class Initialized
INFO - 2022-05-08 11:48:07 --> Loader Class Initialized
INFO - 2022-05-08 11:48:07 --> Helper loaded: url_helper
INFO - 2022-05-08 11:48:07 --> Database Driver Class Initialized
INFO - 2022-05-08 11:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:48:07 --> Controller Class Initialized
DEBUG - 2022-05-08 11:48:07 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:48:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:48:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:48:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:48:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:48:09 --> Final output sent to browser
DEBUG - 2022-05-08 11:48:09 --> Total execution time: 1.4589
INFO - 2022-05-08 11:48:15 --> Config Class Initialized
INFO - 2022-05-08 11:48:15 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:48:15 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:48:15 --> Utf8 Class Initialized
INFO - 2022-05-08 11:48:15 --> URI Class Initialized
INFO - 2022-05-08 11:48:15 --> Router Class Initialized
INFO - 2022-05-08 11:48:15 --> Output Class Initialized
INFO - 2022-05-08 11:48:15 --> Security Class Initialized
DEBUG - 2022-05-08 11:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:48:15 --> Input Class Initialized
INFO - 2022-05-08 11:48:15 --> Language Class Initialized
ERROR - 2022-05-08 11:48:15 --> 404 Page Not Found: /index
INFO - 2022-05-08 11:52:56 --> Config Class Initialized
INFO - 2022-05-08 11:52:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:52:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:52:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:52:56 --> URI Class Initialized
INFO - 2022-05-08 11:52:56 --> Router Class Initialized
INFO - 2022-05-08 11:52:56 --> Output Class Initialized
INFO - 2022-05-08 11:52:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:52:56 --> Input Class Initialized
INFO - 2022-05-08 11:52:56 --> Language Class Initialized
INFO - 2022-05-08 11:52:56 --> Language Class Initialized
INFO - 2022-05-08 11:52:56 --> Config Class Initialized
INFO - 2022-05-08 11:52:56 --> Loader Class Initialized
INFO - 2022-05-08 11:52:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:52:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:52:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:52:56 --> Admin MX_Controller Initialized
DEBUG - 2022-05-08 11:52:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:52:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:52:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:52:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:52:56 --> Final output sent to browser
DEBUG - 2022-05-08 11:52:56 --> Total execution time: 0.0517
INFO - 2022-05-08 11:53:04 --> Config Class Initialized
INFO - 2022-05-08 11:53:04 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:53:04 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:53:04 --> Utf8 Class Initialized
INFO - 2022-05-08 11:53:04 --> URI Class Initialized
INFO - 2022-05-08 11:53:04 --> Router Class Initialized
INFO - 2022-05-08 11:53:04 --> Output Class Initialized
INFO - 2022-05-08 11:53:04 --> Security Class Initialized
DEBUG - 2022-05-08 11:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:53:04 --> Input Class Initialized
INFO - 2022-05-08 11:53:04 --> Language Class Initialized
INFO - 2022-05-08 11:53:04 --> Language Class Initialized
INFO - 2022-05-08 11:53:04 --> Config Class Initialized
INFO - 2022-05-08 11:53:04 --> Loader Class Initialized
INFO - 2022-05-08 11:53:04 --> Helper loaded: url_helper
INFO - 2022-05-08 11:53:04 --> Database Driver Class Initialized
INFO - 2022-05-08 11:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:53:04 --> Controller Class Initialized
DEBUG - 2022-05-08 11:53:04 --> Admin MX_Controller Initialized
ERROR - 2022-05-08 11:53:04 --> Severity: Notice --> Undefined property: CI::$Admin_model N:\Xampp\htdocs\motodeal\application\third_party\MX\Controller.php 59
ERROR - 2022-05-08 11:53:05 --> Severity: Error --> Call to a member function add_category() on a non-object N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 21
INFO - 2022-05-08 11:56:50 --> Config Class Initialized
INFO - 2022-05-08 11:56:50 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:56:50 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:56:50 --> Utf8 Class Initialized
INFO - 2022-05-08 11:56:50 --> URI Class Initialized
INFO - 2022-05-08 11:56:50 --> Router Class Initialized
INFO - 2022-05-08 11:56:50 --> Output Class Initialized
INFO - 2022-05-08 11:56:50 --> Security Class Initialized
DEBUG - 2022-05-08 11:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:56:50 --> Input Class Initialized
INFO - 2022-05-08 11:56:50 --> Language Class Initialized
INFO - 2022-05-08 11:56:50 --> Language Class Initialized
INFO - 2022-05-08 11:56:50 --> Config Class Initialized
INFO - 2022-05-08 11:56:50 --> Loader Class Initialized
INFO - 2022-05-08 11:56:50 --> Helper loaded: url_helper
INFO - 2022-05-08 11:56:50 --> Database Driver Class Initialized
INFO - 2022-05-08 11:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:56:50 --> Controller Class Initialized
DEBUG - 2022-05-08 11:56:50 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:56:50 --> Model Class Initialized
DEBUG - 2022-05-08 11:56:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
ERROR - 2022-05-08 11:56:50 --> Severity: Error --> Class 'Admin_model' not found N:\Xampp\htdocs\motodeal\application\third_party\MX\Loader.php 225
INFO - 2022-05-08 11:57:11 --> Config Class Initialized
INFO - 2022-05-08 11:57:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:57:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:57:11 --> Utf8 Class Initialized
INFO - 2022-05-08 11:57:11 --> URI Class Initialized
INFO - 2022-05-08 11:57:11 --> Router Class Initialized
INFO - 2022-05-08 11:57:11 --> Output Class Initialized
INFO - 2022-05-08 11:57:11 --> Security Class Initialized
DEBUG - 2022-05-08 11:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:57:11 --> Input Class Initialized
INFO - 2022-05-08 11:57:11 --> Language Class Initialized
INFO - 2022-05-08 11:57:11 --> Language Class Initialized
INFO - 2022-05-08 11:57:11 --> Config Class Initialized
INFO - 2022-05-08 11:57:11 --> Loader Class Initialized
INFO - 2022-05-08 11:57:11 --> Helper loaded: url_helper
INFO - 2022-05-08 11:57:11 --> Database Driver Class Initialized
INFO - 2022-05-08 11:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:57:11 --> Controller Class Initialized
DEBUG - 2022-05-08 11:57:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:57:11 --> Model Class Initialized
DEBUG - 2022-05-08 11:57:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 11:57:11 --> Model Class Initialized
DEBUG - 2022-05-08 11:57:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:57:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:57:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:57:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:57:12 --> Final output sent to browser
DEBUG - 2022-05-08 11:57:12 --> Total execution time: 1.2262
INFO - 2022-05-08 11:57:56 --> Config Class Initialized
INFO - 2022-05-08 11:57:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:57:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:57:56 --> Utf8 Class Initialized
INFO - 2022-05-08 11:57:56 --> URI Class Initialized
INFO - 2022-05-08 11:57:56 --> Router Class Initialized
INFO - 2022-05-08 11:57:56 --> Output Class Initialized
INFO - 2022-05-08 11:57:56 --> Security Class Initialized
DEBUG - 2022-05-08 11:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:57:56 --> Input Class Initialized
INFO - 2022-05-08 11:57:56 --> Language Class Initialized
INFO - 2022-05-08 11:57:56 --> Language Class Initialized
INFO - 2022-05-08 11:57:56 --> Config Class Initialized
INFO - 2022-05-08 11:57:56 --> Loader Class Initialized
INFO - 2022-05-08 11:57:56 --> Helper loaded: url_helper
INFO - 2022-05-08 11:57:56 --> Database Driver Class Initialized
INFO - 2022-05-08 11:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:57:56 --> Controller Class Initialized
DEBUG - 2022-05-08 11:57:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:57:56 --> Model Class Initialized
DEBUG - 2022-05-08 11:57:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 11:57:56 --> Model Class Initialized
DEBUG - 2022-05-08 11:57:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:57:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:57:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:57:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:57:57 --> Final output sent to browser
DEBUG - 2022-05-08 11:57:57 --> Total execution time: 0.3304
INFO - 2022-05-08 11:58:12 --> Config Class Initialized
INFO - 2022-05-08 11:58:12 --> Hooks Class Initialized
DEBUG - 2022-05-08 11:58:12 --> UTF-8 Support Enabled
INFO - 2022-05-08 11:58:12 --> Utf8 Class Initialized
INFO - 2022-05-08 11:58:12 --> URI Class Initialized
INFO - 2022-05-08 11:58:12 --> Router Class Initialized
INFO - 2022-05-08 11:58:12 --> Output Class Initialized
INFO - 2022-05-08 11:58:12 --> Security Class Initialized
DEBUG - 2022-05-08 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 11:58:12 --> Input Class Initialized
INFO - 2022-05-08 11:58:12 --> Language Class Initialized
INFO - 2022-05-08 11:58:12 --> Language Class Initialized
INFO - 2022-05-08 11:58:12 --> Config Class Initialized
INFO - 2022-05-08 11:58:12 --> Loader Class Initialized
INFO - 2022-05-08 11:58:12 --> Helper loaded: url_helper
INFO - 2022-05-08 11:58:12 --> Database Driver Class Initialized
INFO - 2022-05-08 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 11:58:12 --> Controller Class Initialized
DEBUG - 2022-05-08 11:58:12 --> Admin MX_Controller Initialized
INFO - 2022-05-08 11:58:12 --> Model Class Initialized
DEBUG - 2022-05-08 11:58:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 11:58:12 --> Model Class Initialized
DEBUG - 2022-05-08 11:58:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 11:58:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 11:58:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 11:58:15 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 11:58:15 --> Final output sent to browser
DEBUG - 2022-05-08 11:58:15 --> Total execution time: 2.4719
INFO - 2022-05-08 12:00:50 --> Config Class Initialized
INFO - 2022-05-08 12:00:50 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:00:50 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:00:50 --> Utf8 Class Initialized
INFO - 2022-05-08 12:00:50 --> URI Class Initialized
INFO - 2022-05-08 12:00:50 --> Router Class Initialized
INFO - 2022-05-08 12:00:50 --> Output Class Initialized
INFO - 2022-05-08 12:00:50 --> Security Class Initialized
DEBUG - 2022-05-08 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:00:50 --> Input Class Initialized
INFO - 2022-05-08 12:00:50 --> Language Class Initialized
INFO - 2022-05-08 12:00:50 --> Language Class Initialized
INFO - 2022-05-08 12:00:50 --> Config Class Initialized
INFO - 2022-05-08 12:00:50 --> Loader Class Initialized
INFO - 2022-05-08 12:00:50 --> Helper loaded: url_helper
INFO - 2022-05-08 12:00:50 --> Database Driver Class Initialized
INFO - 2022-05-08 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:00:51 --> Controller Class Initialized
DEBUG - 2022-05-08 12:00:51 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:00:51 --> Model Class Initialized
DEBUG - 2022-05-08 12:00:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:00:51 --> Model Class Initialized
DEBUG - 2022-05-08 12:00:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:00:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:00:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:00:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:00:51 --> Final output sent to browser
DEBUG - 2022-05-08 12:00:51 --> Total execution time: 1.8914
INFO - 2022-05-08 12:01:52 --> Config Class Initialized
INFO - 2022-05-08 12:01:52 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:01:52 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:01:52 --> Utf8 Class Initialized
INFO - 2022-05-08 12:01:52 --> URI Class Initialized
INFO - 2022-05-08 12:01:52 --> Router Class Initialized
INFO - 2022-05-08 12:01:52 --> Output Class Initialized
INFO - 2022-05-08 12:01:52 --> Security Class Initialized
DEBUG - 2022-05-08 12:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:01:52 --> Input Class Initialized
INFO - 2022-05-08 12:01:52 --> Language Class Initialized
INFO - 2022-05-08 12:01:52 --> Language Class Initialized
INFO - 2022-05-08 12:01:52 --> Config Class Initialized
INFO - 2022-05-08 12:01:52 --> Loader Class Initialized
INFO - 2022-05-08 12:01:52 --> Helper loaded: url_helper
INFO - 2022-05-08 12:01:52 --> Database Driver Class Initialized
INFO - 2022-05-08 12:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:01:52 --> Controller Class Initialized
DEBUG - 2022-05-08 12:01:52 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:01:52 --> Model Class Initialized
DEBUG - 2022-05-08 12:01:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:01:52 --> Model Class Initialized
DEBUG - 2022-05-08 12:01:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:01:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:01:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:01:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:01:54 --> Final output sent to browser
DEBUG - 2022-05-08 12:01:54 --> Total execution time: 1.3136
INFO - 2022-05-08 12:02:38 --> Config Class Initialized
INFO - 2022-05-08 12:02:38 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:02:38 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:02:38 --> Utf8 Class Initialized
INFO - 2022-05-08 12:02:38 --> URI Class Initialized
INFO - 2022-05-08 12:02:38 --> Router Class Initialized
INFO - 2022-05-08 12:02:38 --> Output Class Initialized
INFO - 2022-05-08 12:02:38 --> Security Class Initialized
DEBUG - 2022-05-08 12:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:02:38 --> Input Class Initialized
INFO - 2022-05-08 12:02:38 --> Language Class Initialized
INFO - 2022-05-08 12:02:38 --> Language Class Initialized
INFO - 2022-05-08 12:02:38 --> Config Class Initialized
INFO - 2022-05-08 12:02:38 --> Loader Class Initialized
INFO - 2022-05-08 12:02:38 --> Helper loaded: url_helper
INFO - 2022-05-08 12:02:38 --> Database Driver Class Initialized
INFO - 2022-05-08 12:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:02:38 --> Controller Class Initialized
DEBUG - 2022-05-08 12:02:38 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:02:38 --> Model Class Initialized
DEBUG - 2022-05-08 12:02:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:02:38 --> Model Class Initialized
DEBUG - 2022-05-08 12:02:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:02:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:02:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:02:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:02:39 --> Final output sent to browser
DEBUG - 2022-05-08 12:02:39 --> Total execution time: 1.0853
INFO - 2022-05-08 12:02:42 --> Config Class Initialized
INFO - 2022-05-08 12:02:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:02:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:02:42 --> Utf8 Class Initialized
INFO - 2022-05-08 12:02:42 --> URI Class Initialized
INFO - 2022-05-08 12:02:42 --> Router Class Initialized
INFO - 2022-05-08 12:02:42 --> Output Class Initialized
INFO - 2022-05-08 12:02:42 --> Security Class Initialized
DEBUG - 2022-05-08 12:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:02:42 --> Input Class Initialized
INFO - 2022-05-08 12:02:42 --> Language Class Initialized
INFO - 2022-05-08 12:02:42 --> Language Class Initialized
INFO - 2022-05-08 12:02:42 --> Config Class Initialized
INFO - 2022-05-08 12:02:42 --> Loader Class Initialized
INFO - 2022-05-08 12:02:42 --> Helper loaded: url_helper
INFO - 2022-05-08 12:02:42 --> Database Driver Class Initialized
INFO - 2022-05-08 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:02:42 --> Controller Class Initialized
DEBUG - 2022-05-08 12:02:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:02:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:02:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:02:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:02:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:02:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:02:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:02:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:02:42 --> Final output sent to browser
DEBUG - 2022-05-08 12:02:42 --> Total execution time: 0.0883
INFO - 2022-05-08 12:03:42 --> Config Class Initialized
INFO - 2022-05-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:03:42 --> Utf8 Class Initialized
INFO - 2022-05-08 12:03:42 --> URI Class Initialized
INFO - 2022-05-08 12:03:42 --> Router Class Initialized
INFO - 2022-05-08 12:03:42 --> Output Class Initialized
INFO - 2022-05-08 12:03:42 --> Security Class Initialized
DEBUG - 2022-05-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:03:42 --> Input Class Initialized
INFO - 2022-05-08 12:03:42 --> Language Class Initialized
INFO - 2022-05-08 12:03:42 --> Language Class Initialized
INFO - 2022-05-08 12:03:42 --> Config Class Initialized
INFO - 2022-05-08 12:03:42 --> Loader Class Initialized
INFO - 2022-05-08 12:03:42 --> Helper loaded: url_helper
INFO - 2022-05-08 12:03:42 --> Database Driver Class Initialized
INFO - 2022-05-08 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:03:42 --> Controller Class Initialized
DEBUG - 2022-05-08 12:03:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:03:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:03:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:03:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:03:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:03:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:03:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:03:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:03:42 --> Final output sent to browser
DEBUG - 2022-05-08 12:03:42 --> Total execution time: 0.0487
INFO - 2022-05-08 12:04:11 --> Config Class Initialized
INFO - 2022-05-08 12:04:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:04:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:04:11 --> Utf8 Class Initialized
INFO - 2022-05-08 12:04:11 --> URI Class Initialized
INFO - 2022-05-08 12:04:11 --> Router Class Initialized
INFO - 2022-05-08 12:04:11 --> Output Class Initialized
INFO - 2022-05-08 12:04:11 --> Security Class Initialized
DEBUG - 2022-05-08 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:04:11 --> Input Class Initialized
INFO - 2022-05-08 12:04:11 --> Language Class Initialized
INFO - 2022-05-08 12:04:11 --> Language Class Initialized
INFO - 2022-05-08 12:04:11 --> Config Class Initialized
INFO - 2022-05-08 12:04:11 --> Loader Class Initialized
INFO - 2022-05-08 12:04:11 --> Helper loaded: url_helper
INFO - 2022-05-08 12:04:11 --> Database Driver Class Initialized
INFO - 2022-05-08 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:04:11 --> Controller Class Initialized
DEBUG - 2022-05-08 12:04:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:04:11 --> Model Class Initialized
DEBUG - 2022-05-08 12:04:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:04:11 --> Model Class Initialized
DEBUG - 2022-05-08 12:04:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:04:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:04:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:04:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:04:11 --> Final output sent to browser
DEBUG - 2022-05-08 12:04:11 --> Total execution time: 1.7366
INFO - 2022-05-08 12:04:51 --> Config Class Initialized
INFO - 2022-05-08 12:04:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:04:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:04:51 --> Utf8 Class Initialized
INFO - 2022-05-08 12:04:51 --> URI Class Initialized
INFO - 2022-05-08 12:04:51 --> Router Class Initialized
INFO - 2022-05-08 12:04:51 --> Output Class Initialized
INFO - 2022-05-08 12:04:51 --> Security Class Initialized
DEBUG - 2022-05-08 12:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:04:51 --> Input Class Initialized
INFO - 2022-05-08 12:04:51 --> Language Class Initialized
INFO - 2022-05-08 12:04:51 --> Language Class Initialized
INFO - 2022-05-08 12:04:51 --> Config Class Initialized
INFO - 2022-05-08 12:04:51 --> Loader Class Initialized
INFO - 2022-05-08 12:04:51 --> Helper loaded: url_helper
INFO - 2022-05-08 12:04:51 --> Database Driver Class Initialized
INFO - 2022-05-08 12:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:04:51 --> Controller Class Initialized
DEBUG - 2022-05-08 12:04:51 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:04:51 --> Model Class Initialized
DEBUG - 2022-05-08 12:04:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:04:51 --> Model Class Initialized
DEBUG - 2022-05-08 12:04:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:04:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:04:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:04:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:04:51 --> Final output sent to browser
DEBUG - 2022-05-08 12:04:51 --> Total execution time: 0.0537
INFO - 2022-05-08 12:05:36 --> Config Class Initialized
INFO - 2022-05-08 12:05:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:05:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:05:36 --> Utf8 Class Initialized
INFO - 2022-05-08 12:05:36 --> URI Class Initialized
INFO - 2022-05-08 12:05:36 --> Router Class Initialized
INFO - 2022-05-08 12:05:36 --> Output Class Initialized
INFO - 2022-05-08 12:05:36 --> Security Class Initialized
DEBUG - 2022-05-08 12:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:05:36 --> Input Class Initialized
INFO - 2022-05-08 12:05:36 --> Language Class Initialized
INFO - 2022-05-08 12:05:36 --> Language Class Initialized
INFO - 2022-05-08 12:05:36 --> Config Class Initialized
INFO - 2022-05-08 12:05:36 --> Loader Class Initialized
INFO - 2022-05-08 12:05:36 --> Helper loaded: url_helper
INFO - 2022-05-08 12:05:36 --> Database Driver Class Initialized
INFO - 2022-05-08 12:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:05:36 --> Controller Class Initialized
DEBUG - 2022-05-08 12:05:36 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:05:36 --> Model Class Initialized
DEBUG - 2022-05-08 12:05:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:05:36 --> Model Class Initialized
DEBUG - 2022-05-08 12:05:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:05:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:05:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:05:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:05:36 --> Final output sent to browser
DEBUG - 2022-05-08 12:05:36 --> Total execution time: 0.0510
INFO - 2022-05-08 12:06:00 --> Config Class Initialized
INFO - 2022-05-08 12:06:00 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:06:00 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:06:00 --> Utf8 Class Initialized
INFO - 2022-05-08 12:06:00 --> URI Class Initialized
INFO - 2022-05-08 12:06:00 --> Router Class Initialized
INFO - 2022-05-08 12:06:00 --> Output Class Initialized
INFO - 2022-05-08 12:06:00 --> Security Class Initialized
DEBUG - 2022-05-08 12:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:06:00 --> Input Class Initialized
INFO - 2022-05-08 12:06:00 --> Language Class Initialized
INFO - 2022-05-08 12:06:00 --> Language Class Initialized
INFO - 2022-05-08 12:06:00 --> Config Class Initialized
INFO - 2022-05-08 12:06:00 --> Loader Class Initialized
INFO - 2022-05-08 12:06:00 --> Helper loaded: url_helper
INFO - 2022-05-08 12:06:00 --> Database Driver Class Initialized
INFO - 2022-05-08 12:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:06:00 --> Controller Class Initialized
DEBUG - 2022-05-08 12:06:00 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:06:00 --> Model Class Initialized
DEBUG - 2022-05-08 12:06:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:06:00 --> Model Class Initialized
DEBUG - 2022-05-08 12:06:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:06:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:06:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:06:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:06:00 --> Final output sent to browser
DEBUG - 2022-05-08 12:06:00 --> Total execution time: 0.0486
INFO - 2022-05-08 12:12:30 --> Config Class Initialized
INFO - 2022-05-08 12:12:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:12:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:12:30 --> Utf8 Class Initialized
INFO - 2022-05-08 12:12:30 --> URI Class Initialized
INFO - 2022-05-08 12:12:30 --> Router Class Initialized
INFO - 2022-05-08 12:12:30 --> Output Class Initialized
INFO - 2022-05-08 12:12:30 --> Security Class Initialized
DEBUG - 2022-05-08 12:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:12:30 --> Input Class Initialized
INFO - 2022-05-08 12:12:30 --> Language Class Initialized
INFO - 2022-05-08 12:12:30 --> Language Class Initialized
INFO - 2022-05-08 12:12:30 --> Config Class Initialized
INFO - 2022-05-08 12:12:30 --> Loader Class Initialized
INFO - 2022-05-08 12:12:30 --> Helper loaded: url_helper
INFO - 2022-05-08 12:12:30 --> Database Driver Class Initialized
INFO - 2022-05-08 12:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:12:30 --> Controller Class Initialized
DEBUG - 2022-05-08 12:12:30 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:12:30 --> Model Class Initialized
DEBUG - 2022-05-08 12:12:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:12:30 --> Model Class Initialized
ERROR - 2022-05-08 12:12:30 --> Severity: Notice --> Undefined property: CI::$Admin N:\Xampp\htdocs\motodeal\application\third_party\MX\Controller.php 59
ERROR - 2022-05-08 12:12:30 --> Severity: Notice --> Trying to get property of non-object N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 37
ERROR - 2022-05-08 12:12:30 --> Severity: Error --> Call to a member function get_category() on a non-object N:\Xampp\htdocs\motodeal\application\modules\admin\controllers\Admin.php 37
INFO - 2022-05-08 12:13:37 --> Config Class Initialized
INFO - 2022-05-08 12:13:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:13:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:13:37 --> Utf8 Class Initialized
INFO - 2022-05-08 12:13:37 --> URI Class Initialized
INFO - 2022-05-08 12:13:38 --> Router Class Initialized
INFO - 2022-05-08 12:13:38 --> Output Class Initialized
INFO - 2022-05-08 12:13:38 --> Security Class Initialized
DEBUG - 2022-05-08 12:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:13:38 --> Input Class Initialized
INFO - 2022-05-08 12:13:38 --> Language Class Initialized
INFO - 2022-05-08 12:13:38 --> Language Class Initialized
INFO - 2022-05-08 12:13:38 --> Config Class Initialized
INFO - 2022-05-08 12:13:38 --> Loader Class Initialized
INFO - 2022-05-08 12:13:38 --> Helper loaded: url_helper
INFO - 2022-05-08 12:13:38 --> Database Driver Class Initialized
INFO - 2022-05-08 12:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:13:38 --> Controller Class Initialized
DEBUG - 2022-05-08 12:13:38 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:13:38 --> Model Class Initialized
DEBUG - 2022-05-08 12:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:13:38 --> Model Class Initialized
DEBUG - 2022-05-08 12:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:13:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:13:38 --> Final output sent to browser
DEBUG - 2022-05-08 12:13:38 --> Total execution time: 0.9707
INFO - 2022-05-08 12:13:44 --> Config Class Initialized
INFO - 2022-05-08 12:13:44 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:13:44 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:13:44 --> Utf8 Class Initialized
INFO - 2022-05-08 12:13:44 --> URI Class Initialized
INFO - 2022-05-08 12:13:44 --> Router Class Initialized
INFO - 2022-05-08 12:13:44 --> Output Class Initialized
INFO - 2022-05-08 12:13:44 --> Security Class Initialized
DEBUG - 2022-05-08 12:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:13:44 --> Input Class Initialized
INFO - 2022-05-08 12:13:44 --> Language Class Initialized
INFO - 2022-05-08 12:13:44 --> Language Class Initialized
INFO - 2022-05-08 12:13:44 --> Config Class Initialized
INFO - 2022-05-08 12:13:44 --> Loader Class Initialized
INFO - 2022-05-08 12:13:44 --> Helper loaded: url_helper
INFO - 2022-05-08 12:13:44 --> Database Driver Class Initialized
INFO - 2022-05-08 12:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:13:44 --> Controller Class Initialized
DEBUG - 2022-05-08 12:13:44 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:13:44 --> Model Class Initialized
DEBUG - 2022-05-08 12:13:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:13:44 --> Model Class Initialized
DEBUG - 2022-05-08 12:13:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:13:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:13:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:13:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:13:44 --> Final output sent to browser
DEBUG - 2022-05-08 12:13:44 --> Total execution time: 1.3781
INFO - 2022-05-08 12:13:56 --> Config Class Initialized
INFO - 2022-05-08 12:13:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:13:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:13:56 --> Utf8 Class Initialized
INFO - 2022-05-08 12:13:56 --> URI Class Initialized
INFO - 2022-05-08 12:13:56 --> Router Class Initialized
INFO - 2022-05-08 12:13:56 --> Output Class Initialized
INFO - 2022-05-08 12:13:56 --> Security Class Initialized
DEBUG - 2022-05-08 12:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:13:56 --> Input Class Initialized
INFO - 2022-05-08 12:13:56 --> Language Class Initialized
INFO - 2022-05-08 12:13:56 --> Language Class Initialized
INFO - 2022-05-08 12:13:56 --> Config Class Initialized
INFO - 2022-05-08 12:13:56 --> Loader Class Initialized
INFO - 2022-05-08 12:13:56 --> Helper loaded: url_helper
INFO - 2022-05-08 12:13:56 --> Database Driver Class Initialized
INFO - 2022-05-08 12:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:13:56 --> Controller Class Initialized
DEBUG - 2022-05-08 12:13:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:13:56 --> Model Class Initialized
DEBUG - 2022-05-08 12:13:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:13:56 --> Model Class Initialized
DEBUG - 2022-05-08 12:13:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:13:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:13:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:13:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:13:56 --> Final output sent to browser
DEBUG - 2022-05-08 12:13:56 --> Total execution time: 0.4573
INFO - 2022-05-08 12:15:01 --> Config Class Initialized
INFO - 2022-05-08 12:15:01 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:15:01 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:15:01 --> Utf8 Class Initialized
INFO - 2022-05-08 12:15:01 --> URI Class Initialized
INFO - 2022-05-08 12:15:01 --> Router Class Initialized
INFO - 2022-05-08 12:15:01 --> Output Class Initialized
INFO - 2022-05-08 12:15:01 --> Security Class Initialized
DEBUG - 2022-05-08 12:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:15:01 --> Input Class Initialized
INFO - 2022-05-08 12:15:01 --> Language Class Initialized
INFO - 2022-05-08 12:15:01 --> Language Class Initialized
INFO - 2022-05-08 12:15:01 --> Config Class Initialized
INFO - 2022-05-08 12:15:01 --> Loader Class Initialized
INFO - 2022-05-08 12:15:01 --> Helper loaded: url_helper
INFO - 2022-05-08 12:15:01 --> Database Driver Class Initialized
INFO - 2022-05-08 12:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:15:01 --> Controller Class Initialized
DEBUG - 2022-05-08 12:15:01 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:15:01 --> Model Class Initialized
DEBUG - 2022-05-08 12:15:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:15:01 --> Model Class Initialized
INFO - 2022-05-08 12:15:03 --> Config Class Initialized
INFO - 2022-05-08 12:15:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:15:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:15:03 --> Utf8 Class Initialized
INFO - 2022-05-08 12:15:03 --> URI Class Initialized
INFO - 2022-05-08 12:15:03 --> Router Class Initialized
INFO - 2022-05-08 12:15:03 --> Output Class Initialized
INFO - 2022-05-08 12:15:03 --> Security Class Initialized
DEBUG - 2022-05-08 12:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:15:03 --> Input Class Initialized
INFO - 2022-05-08 12:15:03 --> Language Class Initialized
INFO - 2022-05-08 12:15:03 --> Language Class Initialized
INFO - 2022-05-08 12:15:03 --> Config Class Initialized
INFO - 2022-05-08 12:15:03 --> Loader Class Initialized
INFO - 2022-05-08 12:15:03 --> Helper loaded: url_helper
INFO - 2022-05-08 12:15:04 --> Database Driver Class Initialized
INFO - 2022-05-08 12:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:15:04 --> Controller Class Initialized
DEBUG - 2022-05-08 12:15:04 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:15:04 --> Model Class Initialized
DEBUG - 2022-05-08 12:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:15:04 --> Model Class Initialized
DEBUG - 2022-05-08 12:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:15:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:15:04 --> Final output sent to browser
DEBUG - 2022-05-08 12:15:04 --> Total execution time: 0.0576
INFO - 2022-05-08 12:17:27 --> Config Class Initialized
INFO - 2022-05-08 12:17:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:17:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:17:27 --> Utf8 Class Initialized
INFO - 2022-05-08 12:17:27 --> URI Class Initialized
INFO - 2022-05-08 12:17:27 --> Router Class Initialized
INFO - 2022-05-08 12:17:27 --> Output Class Initialized
INFO - 2022-05-08 12:17:27 --> Security Class Initialized
DEBUG - 2022-05-08 12:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:17:27 --> Input Class Initialized
INFO - 2022-05-08 12:17:27 --> Language Class Initialized
INFO - 2022-05-08 12:17:27 --> Language Class Initialized
INFO - 2022-05-08 12:17:27 --> Config Class Initialized
INFO - 2022-05-08 12:17:27 --> Loader Class Initialized
INFO - 2022-05-08 12:17:27 --> Helper loaded: url_helper
INFO - 2022-05-08 12:17:27 --> Database Driver Class Initialized
INFO - 2022-05-08 12:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:17:27 --> Controller Class Initialized
DEBUG - 2022-05-08 12:17:27 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:17:27 --> Model Class Initialized
DEBUG - 2022-05-08 12:17:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:17:27 --> Model Class Initialized
DEBUG - 2022-05-08 12:17:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:17:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:17:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:17:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:17:27 --> Final output sent to browser
DEBUG - 2022-05-08 12:17:27 --> Total execution time: 0.0515
INFO - 2022-05-08 12:17:29 --> Config Class Initialized
INFO - 2022-05-08 12:17:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:17:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:17:29 --> Utf8 Class Initialized
INFO - 2022-05-08 12:17:29 --> URI Class Initialized
INFO - 2022-05-08 12:17:29 --> Router Class Initialized
INFO - 2022-05-08 12:17:29 --> Output Class Initialized
INFO - 2022-05-08 12:17:29 --> Security Class Initialized
DEBUG - 2022-05-08 12:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:17:29 --> Input Class Initialized
INFO - 2022-05-08 12:17:29 --> Language Class Initialized
INFO - 2022-05-08 12:17:29 --> Language Class Initialized
INFO - 2022-05-08 12:17:29 --> Config Class Initialized
INFO - 2022-05-08 12:17:29 --> Loader Class Initialized
INFO - 2022-05-08 12:17:29 --> Helper loaded: url_helper
INFO - 2022-05-08 12:17:29 --> Database Driver Class Initialized
INFO - 2022-05-08 12:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:17:29 --> Controller Class Initialized
DEBUG - 2022-05-08 12:17:29 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:17:29 --> Model Class Initialized
DEBUG - 2022-05-08 12:17:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:17:29 --> Model Class Initialized
DEBUG - 2022-05-08 12:17:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:17:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-08 12:17:29 --> Severity: Notice --> Undefined variable: cat N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 42
ERROR - 2022-05-08 12:17:29 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 42
DEBUG - 2022-05-08 12:17:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:17:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:17:29 --> Final output sent to browser
DEBUG - 2022-05-08 12:17:29 --> Total execution time: 0.0631
INFO - 2022-05-08 12:19:39 --> Config Class Initialized
INFO - 2022-05-08 12:19:39 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:19:39 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:19:39 --> Utf8 Class Initialized
INFO - 2022-05-08 12:19:39 --> URI Class Initialized
INFO - 2022-05-08 12:19:39 --> Router Class Initialized
INFO - 2022-05-08 12:19:39 --> Output Class Initialized
INFO - 2022-05-08 12:19:39 --> Security Class Initialized
DEBUG - 2022-05-08 12:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:19:39 --> Input Class Initialized
INFO - 2022-05-08 12:19:39 --> Language Class Initialized
INFO - 2022-05-08 12:19:39 --> Language Class Initialized
INFO - 2022-05-08 12:19:39 --> Config Class Initialized
INFO - 2022-05-08 12:19:39 --> Loader Class Initialized
INFO - 2022-05-08 12:19:39 --> Helper loaded: url_helper
INFO - 2022-05-08 12:19:39 --> Database Driver Class Initialized
INFO - 2022-05-08 12:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:19:39 --> Controller Class Initialized
DEBUG - 2022-05-08 12:19:39 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:19:39 --> Model Class Initialized
DEBUG - 2022-05-08 12:19:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:19:39 --> Model Class Initialized
DEBUG - 2022-05-08 12:19:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:19:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 12:20:12 --> Config Class Initialized
INFO - 2022-05-08 12:20:12 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:20:12 --> Utf8 Class Initialized
INFO - 2022-05-08 12:20:12 --> URI Class Initialized
INFO - 2022-05-08 12:20:12 --> Router Class Initialized
INFO - 2022-05-08 12:20:12 --> Output Class Initialized
INFO - 2022-05-08 12:20:12 --> Security Class Initialized
DEBUG - 2022-05-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:20:12 --> Input Class Initialized
INFO - 2022-05-08 12:20:12 --> Language Class Initialized
INFO - 2022-05-08 12:20:12 --> Language Class Initialized
INFO - 2022-05-08 12:20:12 --> Config Class Initialized
INFO - 2022-05-08 12:20:12 --> Loader Class Initialized
INFO - 2022-05-08 12:20:12 --> Helper loaded: url_helper
INFO - 2022-05-08 12:20:12 --> Database Driver Class Initialized
INFO - 2022-05-08 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:20:12 --> Controller Class Initialized
DEBUG - 2022-05-08 12:20:12 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:20:12 --> Model Class Initialized
DEBUG - 2022-05-08 12:20:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:20:12 --> Model Class Initialized
DEBUG - 2022-05-08 12:20:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:20:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 12:20:49 --> Config Class Initialized
INFO - 2022-05-08 12:20:49 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:20:49 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:20:49 --> Utf8 Class Initialized
INFO - 2022-05-08 12:20:49 --> URI Class Initialized
INFO - 2022-05-08 12:20:49 --> Router Class Initialized
INFO - 2022-05-08 12:20:49 --> Output Class Initialized
INFO - 2022-05-08 12:20:49 --> Security Class Initialized
DEBUG - 2022-05-08 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:20:49 --> Input Class Initialized
INFO - 2022-05-08 12:20:49 --> Language Class Initialized
INFO - 2022-05-08 12:20:49 --> Language Class Initialized
INFO - 2022-05-08 12:20:49 --> Config Class Initialized
INFO - 2022-05-08 12:20:49 --> Loader Class Initialized
INFO - 2022-05-08 12:20:49 --> Helper loaded: url_helper
INFO - 2022-05-08 12:20:49 --> Database Driver Class Initialized
INFO - 2022-05-08 12:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:20:49 --> Controller Class Initialized
DEBUG - 2022-05-08 12:20:49 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:20:49 --> Model Class Initialized
DEBUG - 2022-05-08 12:20:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:20:49 --> Model Class Initialized
DEBUG - 2022-05-08 12:20:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:20:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_id' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_id' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_name' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_id' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_id' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_name' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_name' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
ERROR - 2022-05-08 12:20:50 --> Severity: Warning --> Illegal string offset 'c_name' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 46
DEBUG - 2022-05-08 12:20:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:20:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:20:50 --> Final output sent to browser
DEBUG - 2022-05-08 12:20:50 --> Total execution time: 0.6448
INFO - 2022-05-08 12:21:39 --> Config Class Initialized
INFO - 2022-05-08 12:21:39 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:21:39 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:21:39 --> Utf8 Class Initialized
INFO - 2022-05-08 12:21:39 --> URI Class Initialized
INFO - 2022-05-08 12:21:40 --> Router Class Initialized
INFO - 2022-05-08 12:21:40 --> Output Class Initialized
INFO - 2022-05-08 12:21:40 --> Security Class Initialized
DEBUG - 2022-05-08 12:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:21:40 --> Input Class Initialized
INFO - 2022-05-08 12:21:40 --> Language Class Initialized
INFO - 2022-05-08 12:21:40 --> Language Class Initialized
INFO - 2022-05-08 12:21:40 --> Config Class Initialized
INFO - 2022-05-08 12:21:40 --> Loader Class Initialized
INFO - 2022-05-08 12:21:40 --> Helper loaded: url_helper
INFO - 2022-05-08 12:21:40 --> Database Driver Class Initialized
INFO - 2022-05-08 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:21:40 --> Controller Class Initialized
DEBUG - 2022-05-08 12:21:40 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:21:40 --> Model Class Initialized
DEBUG - 2022-05-08 12:21:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:21:40 --> Model Class Initialized
DEBUG - 2022-05-08 12:21:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:21:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 12:21:49 --> Config Class Initialized
INFO - 2022-05-08 12:21:49 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:21:49 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:21:49 --> Utf8 Class Initialized
INFO - 2022-05-08 12:21:49 --> URI Class Initialized
INFO - 2022-05-08 12:21:49 --> Router Class Initialized
INFO - 2022-05-08 12:21:49 --> Output Class Initialized
INFO - 2022-05-08 12:21:49 --> Security Class Initialized
DEBUG - 2022-05-08 12:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:21:49 --> Input Class Initialized
INFO - 2022-05-08 12:21:49 --> Language Class Initialized
INFO - 2022-05-08 12:21:49 --> Language Class Initialized
INFO - 2022-05-08 12:21:49 --> Config Class Initialized
INFO - 2022-05-08 12:21:49 --> Loader Class Initialized
INFO - 2022-05-08 12:21:49 --> Helper loaded: url_helper
INFO - 2022-05-08 12:21:49 --> Database Driver Class Initialized
INFO - 2022-05-08 12:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:21:49 --> Controller Class Initialized
DEBUG - 2022-05-08 12:21:49 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:21:49 --> Model Class Initialized
DEBUG - 2022-05-08 12:21:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:21:49 --> Model Class Initialized
DEBUG - 2022-05-08 12:21:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:21:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-08 12:21:49 --> Severity: Parsing Error --> syntax error, unexpected ';' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_brand.php 3
INFO - 2022-05-08 12:21:57 --> Config Class Initialized
INFO - 2022-05-08 12:21:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:21:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:21:57 --> Utf8 Class Initialized
INFO - 2022-05-08 12:21:57 --> URI Class Initialized
INFO - 2022-05-08 12:21:57 --> Router Class Initialized
INFO - 2022-05-08 12:21:57 --> Output Class Initialized
INFO - 2022-05-08 12:21:57 --> Security Class Initialized
DEBUG - 2022-05-08 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:21:57 --> Input Class Initialized
INFO - 2022-05-08 12:21:57 --> Language Class Initialized
INFO - 2022-05-08 12:21:57 --> Language Class Initialized
INFO - 2022-05-08 12:21:57 --> Config Class Initialized
INFO - 2022-05-08 12:21:57 --> Loader Class Initialized
INFO - 2022-05-08 12:21:57 --> Helper loaded: url_helper
INFO - 2022-05-08 12:21:57 --> Database Driver Class Initialized
INFO - 2022-05-08 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:21:57 --> Controller Class Initialized
DEBUG - 2022-05-08 12:21:57 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:21:57 --> Model Class Initialized
DEBUG - 2022-05-08 12:21:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:21:57 --> Model Class Initialized
DEBUG - 2022-05-08 12:21:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:21:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 12:22:42 --> Config Class Initialized
INFO - 2022-05-08 12:22:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:22:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:22:42 --> Utf8 Class Initialized
INFO - 2022-05-08 12:22:42 --> URI Class Initialized
INFO - 2022-05-08 12:22:42 --> Router Class Initialized
INFO - 2022-05-08 12:22:42 --> Output Class Initialized
INFO - 2022-05-08 12:22:42 --> Security Class Initialized
DEBUG - 2022-05-08 12:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:22:42 --> Input Class Initialized
INFO - 2022-05-08 12:22:42 --> Language Class Initialized
INFO - 2022-05-08 12:22:42 --> Language Class Initialized
INFO - 2022-05-08 12:22:42 --> Config Class Initialized
INFO - 2022-05-08 12:22:42 --> Loader Class Initialized
INFO - 2022-05-08 12:22:42 --> Helper loaded: url_helper
INFO - 2022-05-08 12:22:42 --> Database Driver Class Initialized
INFO - 2022-05-08 12:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:22:42 --> Controller Class Initialized
DEBUG - 2022-05-08 12:22:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:22:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:22:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:22:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:22:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:22:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:22:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:22:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:22:43 --> Final output sent to browser
DEBUG - 2022-05-08 12:22:43 --> Total execution time: 0.9350
INFO - 2022-05-08 12:27:37 --> Config Class Initialized
INFO - 2022-05-08 12:27:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:27:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:27:37 --> Utf8 Class Initialized
INFO - 2022-05-08 12:27:37 --> URI Class Initialized
INFO - 2022-05-08 12:27:37 --> Router Class Initialized
INFO - 2022-05-08 12:27:37 --> Output Class Initialized
INFO - 2022-05-08 12:27:37 --> Security Class Initialized
DEBUG - 2022-05-08 12:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:27:37 --> Input Class Initialized
INFO - 2022-05-08 12:27:37 --> Language Class Initialized
INFO - 2022-05-08 12:27:37 --> Language Class Initialized
INFO - 2022-05-08 12:27:37 --> Config Class Initialized
INFO - 2022-05-08 12:27:37 --> Loader Class Initialized
INFO - 2022-05-08 12:27:37 --> Helper loaded: url_helper
INFO - 2022-05-08 12:27:37 --> Database Driver Class Initialized
INFO - 2022-05-08 12:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:27:37 --> Controller Class Initialized
DEBUG - 2022-05-08 12:27:37 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:27:37 --> Model Class Initialized
DEBUG - 2022-05-08 12:27:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:27:37 --> Model Class Initialized
DEBUG - 2022-05-08 12:27:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:27:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:27:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:27:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:27:37 --> Final output sent to browser
DEBUG - 2022-05-08 12:27:37 --> Total execution time: 0.0550
INFO - 2022-05-08 12:29:57 --> Config Class Initialized
INFO - 2022-05-08 12:29:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:29:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:29:57 --> Utf8 Class Initialized
INFO - 2022-05-08 12:29:57 --> URI Class Initialized
INFO - 2022-05-08 12:29:57 --> Router Class Initialized
INFO - 2022-05-08 12:29:57 --> Output Class Initialized
INFO - 2022-05-08 12:29:57 --> Security Class Initialized
DEBUG - 2022-05-08 12:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:29:57 --> Input Class Initialized
INFO - 2022-05-08 12:29:57 --> Language Class Initialized
INFO - 2022-05-08 12:29:57 --> Language Class Initialized
INFO - 2022-05-08 12:29:57 --> Config Class Initialized
INFO - 2022-05-08 12:29:57 --> Loader Class Initialized
INFO - 2022-05-08 12:29:57 --> Helper loaded: url_helper
INFO - 2022-05-08 12:29:57 --> Database Driver Class Initialized
INFO - 2022-05-08 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:29:57 --> Controller Class Initialized
DEBUG - 2022-05-08 12:29:57 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:29:57 --> Model Class Initialized
DEBUG - 2022-05-08 12:29:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:29:57 --> Model Class Initialized
DEBUG - 2022-05-08 12:29:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:29:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:29:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:29:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:29:57 --> Final output sent to browser
DEBUG - 2022-05-08 12:29:57 --> Total execution time: 0.0606
INFO - 2022-05-08 12:32:57 --> Config Class Initialized
INFO - 2022-05-08 12:32:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:32:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:32:57 --> Utf8 Class Initialized
INFO - 2022-05-08 12:32:57 --> URI Class Initialized
INFO - 2022-05-08 12:32:57 --> Router Class Initialized
INFO - 2022-05-08 12:32:57 --> Output Class Initialized
INFO - 2022-05-08 12:32:57 --> Security Class Initialized
DEBUG - 2022-05-08 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:32:57 --> Input Class Initialized
INFO - 2022-05-08 12:32:57 --> Language Class Initialized
INFO - 2022-05-08 12:32:57 --> Language Class Initialized
INFO - 2022-05-08 12:32:57 --> Config Class Initialized
INFO - 2022-05-08 12:32:57 --> Loader Class Initialized
INFO - 2022-05-08 12:32:57 --> Helper loaded: url_helper
INFO - 2022-05-08 12:32:57 --> Database Driver Class Initialized
INFO - 2022-05-08 12:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:32:57 --> Controller Class Initialized
DEBUG - 2022-05-08 12:32:57 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:32:57 --> Model Class Initialized
DEBUG - 2022-05-08 12:32:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:32:57 --> Model Class Initialized
DEBUG - 2022-05-08 12:32:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:32:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:32:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:32:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:32:57 --> Final output sent to browser
DEBUG - 2022-05-08 12:32:57 --> Total execution time: 0.0574
INFO - 2022-05-08 12:32:57 --> Config Class Initialized
INFO - 2022-05-08 12:32:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:32:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:32:57 --> Utf8 Class Initialized
INFO - 2022-05-08 12:32:57 --> URI Class Initialized
INFO - 2022-05-08 12:32:57 --> Router Class Initialized
INFO - 2022-05-08 12:32:57 --> Output Class Initialized
INFO - 2022-05-08 12:32:57 --> Security Class Initialized
DEBUG - 2022-05-08 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:32:57 --> Input Class Initialized
INFO - 2022-05-08 12:32:57 --> Language Class Initialized
ERROR - 2022-05-08 12:32:57 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:32:57 --> Config Class Initialized
INFO - 2022-05-08 12:32:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:32:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:32:57 --> Utf8 Class Initialized
INFO - 2022-05-08 12:32:57 --> URI Class Initialized
INFO - 2022-05-08 12:32:57 --> Router Class Initialized
INFO - 2022-05-08 12:32:57 --> Output Class Initialized
INFO - 2022-05-08 12:32:57 --> Security Class Initialized
DEBUG - 2022-05-08 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:32:57 --> Input Class Initialized
INFO - 2022-05-08 12:32:57 --> Language Class Initialized
ERROR - 2022-05-08 12:32:57 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:32:57 --> Config Class Initialized
INFO - 2022-05-08 12:32:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:32:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:32:57 --> Utf8 Class Initialized
INFO - 2022-05-08 12:32:57 --> URI Class Initialized
INFO - 2022-05-08 12:32:57 --> Router Class Initialized
INFO - 2022-05-08 12:32:57 --> Output Class Initialized
INFO - 2022-05-08 12:32:57 --> Security Class Initialized
DEBUG - 2022-05-08 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:32:57 --> Input Class Initialized
INFO - 2022-05-08 12:32:57 --> Language Class Initialized
ERROR - 2022-05-08 12:32:57 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:33:46 --> Config Class Initialized
INFO - 2022-05-08 12:33:46 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:33:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:33:46 --> Utf8 Class Initialized
INFO - 2022-05-08 12:33:46 --> URI Class Initialized
INFO - 2022-05-08 12:33:46 --> Router Class Initialized
INFO - 2022-05-08 12:33:46 --> Output Class Initialized
INFO - 2022-05-08 12:33:46 --> Security Class Initialized
DEBUG - 2022-05-08 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:33:46 --> Input Class Initialized
INFO - 2022-05-08 12:33:46 --> Language Class Initialized
INFO - 2022-05-08 12:33:46 --> Language Class Initialized
INFO - 2022-05-08 12:33:46 --> Config Class Initialized
INFO - 2022-05-08 12:33:46 --> Loader Class Initialized
INFO - 2022-05-08 12:33:46 --> Helper loaded: url_helper
INFO - 2022-05-08 12:33:46 --> Database Driver Class Initialized
INFO - 2022-05-08 12:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:33:46 --> Controller Class Initialized
DEBUG - 2022-05-08 12:33:46 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:33:46 --> Model Class Initialized
DEBUG - 2022-05-08 12:33:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:33:46 --> Model Class Initialized
DEBUG - 2022-05-08 12:33:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:33:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:33:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:33:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:33:46 --> Final output sent to browser
DEBUG - 2022-05-08 12:33:46 --> Total execution time: 0.0396
INFO - 2022-05-08 12:33:46 --> Config Class Initialized
INFO - 2022-05-08 12:33:46 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:33:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:33:46 --> Utf8 Class Initialized
INFO - 2022-05-08 12:33:46 --> URI Class Initialized
INFO - 2022-05-08 12:33:46 --> Config Class Initialized
INFO - 2022-05-08 12:33:46 --> Hooks Class Initialized
INFO - 2022-05-08 12:33:46 --> Router Class Initialized
INFO - 2022-05-08 12:33:46 --> Output Class Initialized
DEBUG - 2022-05-08 12:33:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:33:46 --> Utf8 Class Initialized
INFO - 2022-05-08 12:33:46 --> URI Class Initialized
INFO - 2022-05-08 12:33:46 --> Security Class Initialized
DEBUG - 2022-05-08 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:33:46 --> Input Class Initialized
INFO - 2022-05-08 12:33:46 --> Language Class Initialized
INFO - 2022-05-08 12:33:46 --> Router Class Initialized
ERROR - 2022-05-08 12:33:46 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:33:46 --> Output Class Initialized
INFO - 2022-05-08 12:33:46 --> Security Class Initialized
DEBUG - 2022-05-08 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:33:46 --> Input Class Initialized
INFO - 2022-05-08 12:33:46 --> Language Class Initialized
ERROR - 2022-05-08 12:33:46 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:33:47 --> Config Class Initialized
INFO - 2022-05-08 12:33:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:33:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:33:47 --> Utf8 Class Initialized
INFO - 2022-05-08 12:33:47 --> URI Class Initialized
INFO - 2022-05-08 12:33:47 --> Router Class Initialized
INFO - 2022-05-08 12:33:47 --> Output Class Initialized
INFO - 2022-05-08 12:33:47 --> Security Class Initialized
DEBUG - 2022-05-08 12:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:33:47 --> Input Class Initialized
INFO - 2022-05-08 12:33:47 --> Language Class Initialized
ERROR - 2022-05-08 12:33:47 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:34:03 --> Config Class Initialized
INFO - 2022-05-08 12:34:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:34:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:34:03 --> Utf8 Class Initialized
INFO - 2022-05-08 12:34:03 --> URI Class Initialized
INFO - 2022-05-08 12:34:03 --> Router Class Initialized
INFO - 2022-05-08 12:34:03 --> Output Class Initialized
INFO - 2022-05-08 12:34:03 --> Security Class Initialized
DEBUG - 2022-05-08 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:34:03 --> Input Class Initialized
INFO - 2022-05-08 12:34:03 --> Language Class Initialized
INFO - 2022-05-08 12:34:03 --> Language Class Initialized
INFO - 2022-05-08 12:34:03 --> Config Class Initialized
INFO - 2022-05-08 12:34:03 --> Loader Class Initialized
INFO - 2022-05-08 12:34:03 --> Helper loaded: url_helper
INFO - 2022-05-08 12:34:03 --> Database Driver Class Initialized
INFO - 2022-05-08 12:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:34:03 --> Controller Class Initialized
DEBUG - 2022-05-08 12:34:03 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:34:03 --> Model Class Initialized
DEBUG - 2022-05-08 12:34:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:34:03 --> Model Class Initialized
DEBUG - 2022-05-08 12:34:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:34:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:34:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:34:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:34:03 --> Final output sent to browser
DEBUG - 2022-05-08 12:34:03 --> Total execution time: 0.0512
INFO - 2022-05-08 12:34:03 --> Config Class Initialized
INFO - 2022-05-08 12:34:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:34:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:34:03 --> Utf8 Class Initialized
INFO - 2022-05-08 12:34:03 --> URI Class Initialized
INFO - 2022-05-08 12:34:03 --> Router Class Initialized
INFO - 2022-05-08 12:34:03 --> Output Class Initialized
INFO - 2022-05-08 12:34:03 --> Security Class Initialized
DEBUG - 2022-05-08 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:34:03 --> Input Class Initialized
INFO - 2022-05-08 12:34:03 --> Language Class Initialized
ERROR - 2022-05-08 12:34:03 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:34:03 --> Config Class Initialized
INFO - 2022-05-08 12:34:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:34:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:34:03 --> Utf8 Class Initialized
INFO - 2022-05-08 12:34:03 --> URI Class Initialized
INFO - 2022-05-08 12:34:03 --> Router Class Initialized
INFO - 2022-05-08 12:34:03 --> Output Class Initialized
INFO - 2022-05-08 12:34:03 --> Security Class Initialized
DEBUG - 2022-05-08 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:34:03 --> Input Class Initialized
INFO - 2022-05-08 12:34:03 --> Language Class Initialized
ERROR - 2022-05-08 12:34:03 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:34:03 --> Config Class Initialized
INFO - 2022-05-08 12:34:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:34:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:34:03 --> Utf8 Class Initialized
INFO - 2022-05-08 12:34:03 --> URI Class Initialized
INFO - 2022-05-08 12:34:03 --> Router Class Initialized
INFO - 2022-05-08 12:34:03 --> Output Class Initialized
INFO - 2022-05-08 12:34:03 --> Security Class Initialized
DEBUG - 2022-05-08 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:34:03 --> Input Class Initialized
INFO - 2022-05-08 12:34:03 --> Language Class Initialized
ERROR - 2022-05-08 12:34:03 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:36:19 --> Config Class Initialized
INFO - 2022-05-08 12:36:19 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:36:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:36:19 --> Utf8 Class Initialized
INFO - 2022-05-08 12:36:19 --> URI Class Initialized
INFO - 2022-05-08 12:36:19 --> Router Class Initialized
INFO - 2022-05-08 12:36:19 --> Output Class Initialized
INFO - 2022-05-08 12:36:19 --> Security Class Initialized
DEBUG - 2022-05-08 12:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:36:19 --> Input Class Initialized
INFO - 2022-05-08 12:36:19 --> Language Class Initialized
INFO - 2022-05-08 12:36:19 --> Language Class Initialized
INFO - 2022-05-08 12:36:19 --> Config Class Initialized
INFO - 2022-05-08 12:36:19 --> Loader Class Initialized
INFO - 2022-05-08 12:36:19 --> Helper loaded: url_helper
INFO - 2022-05-08 12:36:19 --> Database Driver Class Initialized
INFO - 2022-05-08 12:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:36:19 --> Controller Class Initialized
DEBUG - 2022-05-08 12:36:19 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:36:19 --> Model Class Initialized
DEBUG - 2022-05-08 12:36:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:36:19 --> Model Class Initialized
DEBUG - 2022-05-08 12:36:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:36:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:36:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:36:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:36:19 --> Final output sent to browser
DEBUG - 2022-05-08 12:36:19 --> Total execution time: 0.0376
INFO - 2022-05-08 12:36:19 --> Config Class Initialized
INFO - 2022-05-08 12:36:19 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:36:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:36:19 --> Utf8 Class Initialized
INFO - 2022-05-08 12:36:19 --> URI Class Initialized
INFO - 2022-05-08 12:36:19 --> Router Class Initialized
INFO - 2022-05-08 12:36:19 --> Config Class Initialized
INFO - 2022-05-08 12:36:19 --> Hooks Class Initialized
INFO - 2022-05-08 12:36:19 --> Output Class Initialized
DEBUG - 2022-05-08 12:36:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:36:19 --> Utf8 Class Initialized
INFO - 2022-05-08 12:36:19 --> Security Class Initialized
INFO - 2022-05-08 12:36:19 --> URI Class Initialized
DEBUG - 2022-05-08 12:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:36:19 --> Input Class Initialized
INFO - 2022-05-08 12:36:19 --> Language Class Initialized
INFO - 2022-05-08 12:36:19 --> Router Class Initialized
ERROR - 2022-05-08 12:36:19 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:36:19 --> Output Class Initialized
INFO - 2022-05-08 12:36:19 --> Security Class Initialized
DEBUG - 2022-05-08 12:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:36:19 --> Input Class Initialized
INFO - 2022-05-08 12:36:19 --> Language Class Initialized
ERROR - 2022-05-08 12:36:19 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:36:19 --> Config Class Initialized
INFO - 2022-05-08 12:36:19 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:36:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:36:19 --> Utf8 Class Initialized
INFO - 2022-05-08 12:36:19 --> URI Class Initialized
INFO - 2022-05-08 12:36:19 --> Router Class Initialized
INFO - 2022-05-08 12:36:19 --> Output Class Initialized
INFO - 2022-05-08 12:36:19 --> Security Class Initialized
DEBUG - 2022-05-08 12:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:36:19 --> Input Class Initialized
INFO - 2022-05-08 12:36:19 --> Language Class Initialized
ERROR - 2022-05-08 12:36:19 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:38:13 --> Config Class Initialized
INFO - 2022-05-08 12:38:13 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:38:13 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:38:13 --> Utf8 Class Initialized
INFO - 2022-05-08 12:38:13 --> URI Class Initialized
INFO - 2022-05-08 12:38:13 --> Router Class Initialized
INFO - 2022-05-08 12:38:13 --> Output Class Initialized
INFO - 2022-05-08 12:38:13 --> Security Class Initialized
DEBUG - 2022-05-08 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:38:13 --> Input Class Initialized
INFO - 2022-05-08 12:38:13 --> Language Class Initialized
INFO - 2022-05-08 12:38:13 --> Language Class Initialized
INFO - 2022-05-08 12:38:13 --> Config Class Initialized
INFO - 2022-05-08 12:38:13 --> Loader Class Initialized
INFO - 2022-05-08 12:38:13 --> Helper loaded: url_helper
INFO - 2022-05-08 12:38:13 --> Database Driver Class Initialized
INFO - 2022-05-08 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:38:13 --> Controller Class Initialized
DEBUG - 2022-05-08 12:38:13 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:38:13 --> Model Class Initialized
DEBUG - 2022-05-08 12:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:38:13 --> Model Class Initialized
DEBUG - 2022-05-08 12:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 12:38:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:38:13 --> Final output sent to browser
DEBUG - 2022-05-08 12:38:13 --> Total execution time: 0.3942
INFO - 2022-05-08 12:40:53 --> Config Class Initialized
INFO - 2022-05-08 12:40:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:40:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:40:53 --> Utf8 Class Initialized
INFO - 2022-05-08 12:40:53 --> URI Class Initialized
INFO - 2022-05-08 12:40:53 --> Router Class Initialized
INFO - 2022-05-08 12:40:53 --> Output Class Initialized
INFO - 2022-05-08 12:40:53 --> Security Class Initialized
DEBUG - 2022-05-08 12:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:40:53 --> Input Class Initialized
INFO - 2022-05-08 12:40:53 --> Language Class Initialized
INFO - 2022-05-08 12:40:53 --> Language Class Initialized
INFO - 2022-05-08 12:40:53 --> Config Class Initialized
INFO - 2022-05-08 12:40:53 --> Loader Class Initialized
INFO - 2022-05-08 12:40:53 --> Helper loaded: url_helper
INFO - 2022-05-08 12:40:53 --> Database Driver Class Initialized
INFO - 2022-05-08 12:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:40:53 --> Controller Class Initialized
DEBUG - 2022-05-08 12:40:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:40:53 --> Model Class Initialized
DEBUG - 2022-05-08 12:40:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:40:53 --> Model Class Initialized
DEBUG - 2022-05-08 12:40:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:40:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:40:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:40:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:40:53 --> Final output sent to browser
DEBUG - 2022-05-08 12:40:53 --> Total execution time: 0.0370
INFO - 2022-05-08 12:44:35 --> Config Class Initialized
INFO - 2022-05-08 12:44:35 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:44:35 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:44:35 --> Utf8 Class Initialized
INFO - 2022-05-08 12:44:35 --> URI Class Initialized
INFO - 2022-05-08 12:44:35 --> Router Class Initialized
INFO - 2022-05-08 12:44:35 --> Output Class Initialized
INFO - 2022-05-08 12:44:35 --> Security Class Initialized
DEBUG - 2022-05-08 12:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:44:35 --> Input Class Initialized
INFO - 2022-05-08 12:44:35 --> Language Class Initialized
INFO - 2022-05-08 12:44:35 --> Language Class Initialized
INFO - 2022-05-08 12:44:35 --> Config Class Initialized
INFO - 2022-05-08 12:44:35 --> Loader Class Initialized
INFO - 2022-05-08 12:44:35 --> Helper loaded: url_helper
INFO - 2022-05-08 12:44:35 --> Database Driver Class Initialized
INFO - 2022-05-08 12:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:44:35 --> Controller Class Initialized
DEBUG - 2022-05-08 12:44:35 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:44:35 --> Model Class Initialized
DEBUG - 2022-05-08 12:44:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:44:35 --> Model Class Initialized
DEBUG - 2022-05-08 12:44:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:44:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:44:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:44:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:44:35 --> Final output sent to browser
DEBUG - 2022-05-08 12:44:35 --> Total execution time: 0.0357
INFO - 2022-05-08 12:45:30 --> Config Class Initialized
INFO - 2022-05-08 12:45:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:45:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:45:30 --> Utf8 Class Initialized
INFO - 2022-05-08 12:45:30 --> URI Class Initialized
INFO - 2022-05-08 12:45:30 --> Router Class Initialized
INFO - 2022-05-08 12:45:30 --> Output Class Initialized
INFO - 2022-05-08 12:45:30 --> Security Class Initialized
DEBUG - 2022-05-08 12:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:45:30 --> Input Class Initialized
INFO - 2022-05-08 12:45:30 --> Language Class Initialized
INFO - 2022-05-08 12:45:30 --> Language Class Initialized
INFO - 2022-05-08 12:45:30 --> Config Class Initialized
INFO - 2022-05-08 12:45:30 --> Loader Class Initialized
INFO - 2022-05-08 12:45:30 --> Helper loaded: url_helper
INFO - 2022-05-08 12:45:30 --> Database Driver Class Initialized
INFO - 2022-05-08 12:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:45:30 --> Controller Class Initialized
DEBUG - 2022-05-08 12:45:30 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:45:30 --> Model Class Initialized
DEBUG - 2022-05-08 12:45:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:45:30 --> Model Class Initialized
DEBUG - 2022-05-08 12:45:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:45:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:45:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:45:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:45:30 --> Final output sent to browser
DEBUG - 2022-05-08 12:45:30 --> Total execution time: 0.0379
INFO - 2022-05-08 12:45:36 --> Config Class Initialized
INFO - 2022-05-08 12:45:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:45:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:45:36 --> Utf8 Class Initialized
INFO - 2022-05-08 12:45:36 --> URI Class Initialized
INFO - 2022-05-08 12:45:36 --> Router Class Initialized
INFO - 2022-05-08 12:45:36 --> Output Class Initialized
INFO - 2022-05-08 12:45:36 --> Security Class Initialized
DEBUG - 2022-05-08 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:45:36 --> Input Class Initialized
INFO - 2022-05-08 12:45:36 --> Language Class Initialized
INFO - 2022-05-08 12:45:36 --> Language Class Initialized
INFO - 2022-05-08 12:45:36 --> Config Class Initialized
INFO - 2022-05-08 12:45:36 --> Loader Class Initialized
INFO - 2022-05-08 12:45:36 --> Helper loaded: url_helper
INFO - 2022-05-08 12:45:36 --> Database Driver Class Initialized
INFO - 2022-05-08 12:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:45:36 --> Controller Class Initialized
DEBUG - 2022-05-08 12:45:36 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:45:36 --> Model Class Initialized
DEBUG - 2022-05-08 12:45:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:45:36 --> Model Class Initialized
DEBUG - 2022-05-08 12:45:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:45:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:45:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:45:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:45:36 --> Final output sent to browser
DEBUG - 2022-05-08 12:45:36 --> Total execution time: 0.0373
INFO - 2022-05-08 12:46:11 --> Config Class Initialized
INFO - 2022-05-08 12:46:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:46:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:46:11 --> Utf8 Class Initialized
INFO - 2022-05-08 12:46:11 --> URI Class Initialized
INFO - 2022-05-08 12:46:11 --> Router Class Initialized
INFO - 2022-05-08 12:46:11 --> Output Class Initialized
INFO - 2022-05-08 12:46:11 --> Security Class Initialized
DEBUG - 2022-05-08 12:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:46:11 --> Input Class Initialized
INFO - 2022-05-08 12:46:11 --> Language Class Initialized
INFO - 2022-05-08 12:46:11 --> Language Class Initialized
INFO - 2022-05-08 12:46:11 --> Config Class Initialized
INFO - 2022-05-08 12:46:11 --> Loader Class Initialized
INFO - 2022-05-08 12:46:11 --> Helper loaded: url_helper
INFO - 2022-05-08 12:46:11 --> Database Driver Class Initialized
INFO - 2022-05-08 12:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:46:11 --> Controller Class Initialized
DEBUG - 2022-05-08 12:46:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:46:11 --> Model Class Initialized
DEBUG - 2022-05-08 12:46:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:46:11 --> Model Class Initialized
DEBUG - 2022-05-08 12:46:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:46:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:46:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:46:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:46:11 --> Final output sent to browser
DEBUG - 2022-05-08 12:46:11 --> Total execution time: 0.0382
INFO - 2022-05-08 12:46:27 --> Config Class Initialized
INFO - 2022-05-08 12:46:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:46:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:46:27 --> Utf8 Class Initialized
INFO - 2022-05-08 12:46:27 --> URI Class Initialized
INFO - 2022-05-08 12:46:27 --> Router Class Initialized
INFO - 2022-05-08 12:46:27 --> Output Class Initialized
INFO - 2022-05-08 12:46:27 --> Security Class Initialized
DEBUG - 2022-05-08 12:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:46:27 --> Input Class Initialized
INFO - 2022-05-08 12:46:27 --> Language Class Initialized
INFO - 2022-05-08 12:46:27 --> Language Class Initialized
INFO - 2022-05-08 12:46:27 --> Config Class Initialized
INFO - 2022-05-08 12:46:27 --> Loader Class Initialized
INFO - 2022-05-08 12:46:27 --> Helper loaded: url_helper
INFO - 2022-05-08 12:46:27 --> Database Driver Class Initialized
INFO - 2022-05-08 12:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:46:27 --> Controller Class Initialized
DEBUG - 2022-05-08 12:46:27 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:46:27 --> Model Class Initialized
DEBUG - 2022-05-08 12:46:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:46:27 --> Model Class Initialized
DEBUG - 2022-05-08 12:46:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:46:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:46:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:46:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:46:27 --> Final output sent to browser
DEBUG - 2022-05-08 12:46:27 --> Total execution time: 0.0308
INFO - 2022-05-08 12:47:01 --> Config Class Initialized
INFO - 2022-05-08 12:47:01 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:47:01 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:47:01 --> Utf8 Class Initialized
INFO - 2022-05-08 12:47:01 --> URI Class Initialized
INFO - 2022-05-08 12:47:01 --> Router Class Initialized
INFO - 2022-05-08 12:47:01 --> Output Class Initialized
INFO - 2022-05-08 12:47:01 --> Security Class Initialized
DEBUG - 2022-05-08 12:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:47:01 --> Input Class Initialized
INFO - 2022-05-08 12:47:01 --> Language Class Initialized
INFO - 2022-05-08 12:47:01 --> Language Class Initialized
INFO - 2022-05-08 12:47:01 --> Config Class Initialized
INFO - 2022-05-08 12:47:01 --> Loader Class Initialized
INFO - 2022-05-08 12:47:01 --> Helper loaded: url_helper
INFO - 2022-05-08 12:47:01 --> Database Driver Class Initialized
INFO - 2022-05-08 12:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:47:01 --> Controller Class Initialized
DEBUG - 2022-05-08 12:47:01 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:47:01 --> Model Class Initialized
DEBUG - 2022-05-08 12:47:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:47:01 --> Model Class Initialized
DEBUG - 2022-05-08 12:47:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:47:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:47:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:47:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:47:01 --> Final output sent to browser
DEBUG - 2022-05-08 12:47:01 --> Total execution time: 0.0352
INFO - 2022-05-08 12:47:30 --> Config Class Initialized
INFO - 2022-05-08 12:47:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:47:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:47:30 --> Utf8 Class Initialized
INFO - 2022-05-08 12:47:30 --> URI Class Initialized
INFO - 2022-05-08 12:47:30 --> Router Class Initialized
INFO - 2022-05-08 12:47:30 --> Output Class Initialized
INFO - 2022-05-08 12:47:30 --> Security Class Initialized
DEBUG - 2022-05-08 12:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:47:30 --> Input Class Initialized
INFO - 2022-05-08 12:47:30 --> Language Class Initialized
INFO - 2022-05-08 12:47:30 --> Language Class Initialized
INFO - 2022-05-08 12:47:30 --> Config Class Initialized
INFO - 2022-05-08 12:47:30 --> Loader Class Initialized
INFO - 2022-05-08 12:47:30 --> Helper loaded: url_helper
INFO - 2022-05-08 12:47:30 --> Database Driver Class Initialized
INFO - 2022-05-08 12:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:47:30 --> Controller Class Initialized
DEBUG - 2022-05-08 12:47:30 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:47:30 --> Model Class Initialized
DEBUG - 2022-05-08 12:47:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:47:30 --> Model Class Initialized
DEBUG - 2022-05-08 12:47:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:47:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:47:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:47:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:47:30 --> Final output sent to browser
DEBUG - 2022-05-08 12:47:30 --> Total execution time: 0.0377
INFO - 2022-05-08 12:47:42 --> Config Class Initialized
INFO - 2022-05-08 12:47:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:47:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:47:42 --> Utf8 Class Initialized
INFO - 2022-05-08 12:47:42 --> URI Class Initialized
INFO - 2022-05-08 12:47:42 --> Router Class Initialized
INFO - 2022-05-08 12:47:42 --> Output Class Initialized
INFO - 2022-05-08 12:47:42 --> Security Class Initialized
DEBUG - 2022-05-08 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:47:42 --> Input Class Initialized
INFO - 2022-05-08 12:47:42 --> Language Class Initialized
INFO - 2022-05-08 12:47:42 --> Language Class Initialized
INFO - 2022-05-08 12:47:42 --> Config Class Initialized
INFO - 2022-05-08 12:47:42 --> Loader Class Initialized
INFO - 2022-05-08 12:47:42 --> Helper loaded: url_helper
INFO - 2022-05-08 12:47:42 --> Database Driver Class Initialized
INFO - 2022-05-08 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:47:42 --> Controller Class Initialized
DEBUG - 2022-05-08 12:47:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:47:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:47:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:47:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:47:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:47:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:47:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:47:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:47:42 --> Final output sent to browser
DEBUG - 2022-05-08 12:47:42 --> Total execution time: 0.0262
INFO - 2022-05-08 12:48:01 --> Config Class Initialized
INFO - 2022-05-08 12:48:01 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:48:01 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:48:01 --> Utf8 Class Initialized
INFO - 2022-05-08 12:48:01 --> URI Class Initialized
INFO - 2022-05-08 12:48:01 --> Router Class Initialized
INFO - 2022-05-08 12:48:01 --> Output Class Initialized
INFO - 2022-05-08 12:48:01 --> Security Class Initialized
DEBUG - 2022-05-08 12:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:48:01 --> Input Class Initialized
INFO - 2022-05-08 12:48:01 --> Language Class Initialized
INFO - 2022-05-08 12:48:01 --> Language Class Initialized
INFO - 2022-05-08 12:48:01 --> Config Class Initialized
INFO - 2022-05-08 12:48:01 --> Loader Class Initialized
INFO - 2022-05-08 12:48:01 --> Helper loaded: url_helper
INFO - 2022-05-08 12:48:01 --> Database Driver Class Initialized
INFO - 2022-05-08 12:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:48:01 --> Controller Class Initialized
DEBUG - 2022-05-08 12:48:01 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:48:01 --> Model Class Initialized
DEBUG - 2022-05-08 12:48:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:48:01 --> Model Class Initialized
DEBUG - 2022-05-08 12:48:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:48:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:48:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:48:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:48:01 --> Final output sent to browser
DEBUG - 2022-05-08 12:48:01 --> Total execution time: 0.0368
INFO - 2022-05-08 12:48:14 --> Config Class Initialized
INFO - 2022-05-08 12:48:14 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:48:14 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:48:14 --> Utf8 Class Initialized
INFO - 2022-05-08 12:48:14 --> URI Class Initialized
INFO - 2022-05-08 12:48:14 --> Router Class Initialized
INFO - 2022-05-08 12:48:14 --> Output Class Initialized
INFO - 2022-05-08 12:48:14 --> Security Class Initialized
DEBUG - 2022-05-08 12:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:48:14 --> Input Class Initialized
INFO - 2022-05-08 12:48:14 --> Language Class Initialized
INFO - 2022-05-08 12:48:14 --> Language Class Initialized
INFO - 2022-05-08 12:48:14 --> Config Class Initialized
INFO - 2022-05-08 12:48:14 --> Loader Class Initialized
INFO - 2022-05-08 12:48:14 --> Helper loaded: url_helper
INFO - 2022-05-08 12:48:14 --> Database Driver Class Initialized
INFO - 2022-05-08 12:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:48:14 --> Controller Class Initialized
DEBUG - 2022-05-08 12:48:14 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:48:14 --> Model Class Initialized
DEBUG - 2022-05-08 12:48:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:48:14 --> Model Class Initialized
DEBUG - 2022-05-08 12:48:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:48:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:48:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:48:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:48:14 --> Final output sent to browser
DEBUG - 2022-05-08 12:48:14 --> Total execution time: 0.0392
INFO - 2022-05-08 12:48:48 --> Config Class Initialized
INFO - 2022-05-08 12:48:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:48:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:48:48 --> Utf8 Class Initialized
INFO - 2022-05-08 12:48:48 --> URI Class Initialized
INFO - 2022-05-08 12:48:48 --> Router Class Initialized
INFO - 2022-05-08 12:48:48 --> Output Class Initialized
INFO - 2022-05-08 12:48:48 --> Security Class Initialized
DEBUG - 2022-05-08 12:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:48:48 --> Input Class Initialized
INFO - 2022-05-08 12:48:48 --> Language Class Initialized
INFO - 2022-05-08 12:48:48 --> Language Class Initialized
INFO - 2022-05-08 12:48:48 --> Config Class Initialized
INFO - 2022-05-08 12:48:48 --> Loader Class Initialized
INFO - 2022-05-08 12:48:48 --> Helper loaded: url_helper
INFO - 2022-05-08 12:48:49 --> Database Driver Class Initialized
INFO - 2022-05-08 12:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:48:49 --> Controller Class Initialized
DEBUG - 2022-05-08 12:48:49 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:48:49 --> Model Class Initialized
DEBUG - 2022-05-08 12:48:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:48:49 --> Model Class Initialized
DEBUG - 2022-05-08 12:48:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:48:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:48:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:48:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:48:49 --> Final output sent to browser
DEBUG - 2022-05-08 12:48:49 --> Total execution time: 0.0356
INFO - 2022-05-08 12:49:34 --> Config Class Initialized
INFO - 2022-05-08 12:49:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:49:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:49:34 --> Utf8 Class Initialized
INFO - 2022-05-08 12:49:34 --> URI Class Initialized
INFO - 2022-05-08 12:49:34 --> Router Class Initialized
INFO - 2022-05-08 12:49:34 --> Output Class Initialized
INFO - 2022-05-08 12:49:34 --> Security Class Initialized
DEBUG - 2022-05-08 12:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:49:34 --> Input Class Initialized
INFO - 2022-05-08 12:49:34 --> Language Class Initialized
INFO - 2022-05-08 12:49:34 --> Language Class Initialized
INFO - 2022-05-08 12:49:34 --> Config Class Initialized
INFO - 2022-05-08 12:49:34 --> Loader Class Initialized
INFO - 2022-05-08 12:49:34 --> Helper loaded: url_helper
INFO - 2022-05-08 12:49:34 --> Database Driver Class Initialized
INFO - 2022-05-08 12:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:49:34 --> Controller Class Initialized
DEBUG - 2022-05-08 12:49:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:49:34 --> Model Class Initialized
DEBUG - 2022-05-08 12:49:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:49:34 --> Model Class Initialized
DEBUG - 2022-05-08 12:49:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:49:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:49:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:49:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:49:34 --> Final output sent to browser
DEBUG - 2022-05-08 12:49:34 --> Total execution time: 0.0393
INFO - 2022-05-08 12:49:42 --> Config Class Initialized
INFO - 2022-05-08 12:49:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:49:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:49:42 --> Utf8 Class Initialized
INFO - 2022-05-08 12:49:42 --> URI Class Initialized
INFO - 2022-05-08 12:49:42 --> Router Class Initialized
INFO - 2022-05-08 12:49:42 --> Output Class Initialized
INFO - 2022-05-08 12:49:42 --> Security Class Initialized
DEBUG - 2022-05-08 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:49:42 --> Input Class Initialized
INFO - 2022-05-08 12:49:42 --> Language Class Initialized
INFO - 2022-05-08 12:49:42 --> Language Class Initialized
INFO - 2022-05-08 12:49:42 --> Config Class Initialized
INFO - 2022-05-08 12:49:42 --> Loader Class Initialized
INFO - 2022-05-08 12:49:42 --> Helper loaded: url_helper
INFO - 2022-05-08 12:49:42 --> Database Driver Class Initialized
INFO - 2022-05-08 12:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:49:42 --> Controller Class Initialized
DEBUG - 2022-05-08 12:49:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:49:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:49:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:49:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:49:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:49:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:49:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:49:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:49:42 --> Final output sent to browser
DEBUG - 2022-05-08 12:49:42 --> Total execution time: 0.0311
INFO - 2022-05-08 12:49:56 --> Config Class Initialized
INFO - 2022-05-08 12:49:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:49:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:49:56 --> Utf8 Class Initialized
INFO - 2022-05-08 12:49:56 --> URI Class Initialized
INFO - 2022-05-08 12:49:56 --> Router Class Initialized
INFO - 2022-05-08 12:49:56 --> Output Class Initialized
INFO - 2022-05-08 12:49:56 --> Security Class Initialized
DEBUG - 2022-05-08 12:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:49:56 --> Input Class Initialized
INFO - 2022-05-08 12:49:56 --> Language Class Initialized
INFO - 2022-05-08 12:49:56 --> Language Class Initialized
INFO - 2022-05-08 12:49:56 --> Config Class Initialized
INFO - 2022-05-08 12:49:56 --> Loader Class Initialized
INFO - 2022-05-08 12:49:56 --> Helper loaded: url_helper
INFO - 2022-05-08 12:49:56 --> Database Driver Class Initialized
INFO - 2022-05-08 12:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:49:56 --> Controller Class Initialized
DEBUG - 2022-05-08 12:49:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:49:56 --> Model Class Initialized
DEBUG - 2022-05-08 12:49:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:49:56 --> Model Class Initialized
DEBUG - 2022-05-08 12:49:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:49:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:49:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:49:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:49:56 --> Final output sent to browser
DEBUG - 2022-05-08 12:49:56 --> Total execution time: 0.0360
INFO - 2022-05-08 12:50:47 --> Config Class Initialized
INFO - 2022-05-08 12:50:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:50:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:50:47 --> Utf8 Class Initialized
INFO - 2022-05-08 12:50:47 --> URI Class Initialized
INFO - 2022-05-08 12:50:47 --> Router Class Initialized
INFO - 2022-05-08 12:50:47 --> Output Class Initialized
INFO - 2022-05-08 12:50:47 --> Security Class Initialized
DEBUG - 2022-05-08 12:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:50:47 --> Input Class Initialized
INFO - 2022-05-08 12:50:47 --> Language Class Initialized
INFO - 2022-05-08 12:50:47 --> Language Class Initialized
INFO - 2022-05-08 12:50:47 --> Config Class Initialized
INFO - 2022-05-08 12:50:47 --> Loader Class Initialized
INFO - 2022-05-08 12:50:47 --> Helper loaded: url_helper
INFO - 2022-05-08 12:50:47 --> Database Driver Class Initialized
INFO - 2022-05-08 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:50:47 --> Controller Class Initialized
DEBUG - 2022-05-08 12:50:47 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:50:47 --> Model Class Initialized
DEBUG - 2022-05-08 12:50:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:50:47 --> Model Class Initialized
DEBUG - 2022-05-08 12:50:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:50:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:50:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:50:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:50:47 --> Final output sent to browser
DEBUG - 2022-05-08 12:50:47 --> Total execution time: 0.0269
INFO - 2022-05-08 12:51:08 --> Config Class Initialized
INFO - 2022-05-08 12:51:08 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:51:08 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:51:08 --> Utf8 Class Initialized
INFO - 2022-05-08 12:51:08 --> URI Class Initialized
INFO - 2022-05-08 12:51:08 --> Router Class Initialized
INFO - 2022-05-08 12:51:08 --> Output Class Initialized
INFO - 2022-05-08 12:51:08 --> Security Class Initialized
DEBUG - 2022-05-08 12:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:51:08 --> Input Class Initialized
INFO - 2022-05-08 12:51:08 --> Language Class Initialized
INFO - 2022-05-08 12:51:08 --> Language Class Initialized
INFO - 2022-05-08 12:51:08 --> Config Class Initialized
INFO - 2022-05-08 12:51:08 --> Loader Class Initialized
INFO - 2022-05-08 12:51:08 --> Helper loaded: url_helper
INFO - 2022-05-08 12:51:08 --> Database Driver Class Initialized
INFO - 2022-05-08 12:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:51:08 --> Controller Class Initialized
DEBUG - 2022-05-08 12:51:08 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:51:08 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:51:08 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:51:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:51:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:51:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:51:08 --> Final output sent to browser
DEBUG - 2022-05-08 12:51:08 --> Total execution time: 0.0377
INFO - 2022-05-08 12:51:18 --> Config Class Initialized
INFO - 2022-05-08 12:51:18 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:51:18 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:51:18 --> Utf8 Class Initialized
INFO - 2022-05-08 12:51:18 --> URI Class Initialized
INFO - 2022-05-08 12:51:18 --> Router Class Initialized
INFO - 2022-05-08 12:51:18 --> Output Class Initialized
INFO - 2022-05-08 12:51:18 --> Security Class Initialized
DEBUG - 2022-05-08 12:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:51:18 --> Input Class Initialized
INFO - 2022-05-08 12:51:18 --> Language Class Initialized
INFO - 2022-05-08 12:51:18 --> Language Class Initialized
INFO - 2022-05-08 12:51:18 --> Config Class Initialized
INFO - 2022-05-08 12:51:18 --> Loader Class Initialized
INFO - 2022-05-08 12:51:18 --> Helper loaded: url_helper
INFO - 2022-05-08 12:51:18 --> Database Driver Class Initialized
INFO - 2022-05-08 12:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:51:18 --> Controller Class Initialized
DEBUG - 2022-05-08 12:51:18 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:51:18 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:51:18 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:51:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:51:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:51:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:51:18 --> Final output sent to browser
DEBUG - 2022-05-08 12:51:18 --> Total execution time: 0.0358
INFO - 2022-05-08 12:51:33 --> Config Class Initialized
INFO - 2022-05-08 12:51:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:51:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:51:33 --> Utf8 Class Initialized
INFO - 2022-05-08 12:51:33 --> URI Class Initialized
INFO - 2022-05-08 12:51:33 --> Router Class Initialized
INFO - 2022-05-08 12:51:33 --> Output Class Initialized
INFO - 2022-05-08 12:51:33 --> Security Class Initialized
DEBUG - 2022-05-08 12:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:51:33 --> Input Class Initialized
INFO - 2022-05-08 12:51:33 --> Language Class Initialized
INFO - 2022-05-08 12:51:33 --> Language Class Initialized
INFO - 2022-05-08 12:51:33 --> Config Class Initialized
INFO - 2022-05-08 12:51:33 --> Loader Class Initialized
INFO - 2022-05-08 12:51:33 --> Helper loaded: url_helper
INFO - 2022-05-08 12:51:33 --> Database Driver Class Initialized
INFO - 2022-05-08 12:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:51:33 --> Controller Class Initialized
DEBUG - 2022-05-08 12:51:33 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:51:33 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:51:33 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:51:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:51:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:51:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:51:33 --> Final output sent to browser
DEBUG - 2022-05-08 12:51:33 --> Total execution time: 0.0379
INFO - 2022-05-08 12:51:53 --> Config Class Initialized
INFO - 2022-05-08 12:51:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:51:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:51:53 --> Utf8 Class Initialized
INFO - 2022-05-08 12:51:53 --> URI Class Initialized
INFO - 2022-05-08 12:51:53 --> Router Class Initialized
INFO - 2022-05-08 12:51:53 --> Output Class Initialized
INFO - 2022-05-08 12:51:53 --> Security Class Initialized
DEBUG - 2022-05-08 12:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:51:53 --> Input Class Initialized
INFO - 2022-05-08 12:51:53 --> Language Class Initialized
INFO - 2022-05-08 12:51:53 --> Language Class Initialized
INFO - 2022-05-08 12:51:53 --> Config Class Initialized
INFO - 2022-05-08 12:51:53 --> Loader Class Initialized
INFO - 2022-05-08 12:51:53 --> Helper loaded: url_helper
INFO - 2022-05-08 12:51:53 --> Database Driver Class Initialized
INFO - 2022-05-08 12:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:51:53 --> Controller Class Initialized
DEBUG - 2022-05-08 12:51:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:51:53 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:51:53 --> Model Class Initialized
DEBUG - 2022-05-08 12:51:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:51:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:51:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:51:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:51:53 --> Final output sent to browser
DEBUG - 2022-05-08 12:51:53 --> Total execution time: 0.0388
INFO - 2022-05-08 12:52:14 --> Config Class Initialized
INFO - 2022-05-08 12:52:14 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:52:14 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:52:14 --> Utf8 Class Initialized
INFO - 2022-05-08 12:52:14 --> URI Class Initialized
INFO - 2022-05-08 12:52:14 --> Router Class Initialized
INFO - 2022-05-08 12:52:14 --> Output Class Initialized
INFO - 2022-05-08 12:52:14 --> Security Class Initialized
DEBUG - 2022-05-08 12:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:52:14 --> Input Class Initialized
INFO - 2022-05-08 12:52:14 --> Language Class Initialized
INFO - 2022-05-08 12:52:14 --> Language Class Initialized
INFO - 2022-05-08 12:52:14 --> Config Class Initialized
INFO - 2022-05-08 12:52:14 --> Loader Class Initialized
INFO - 2022-05-08 12:52:14 --> Helper loaded: url_helper
INFO - 2022-05-08 12:52:14 --> Database Driver Class Initialized
INFO - 2022-05-08 12:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:52:14 --> Controller Class Initialized
DEBUG - 2022-05-08 12:52:14 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:52:14 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:52:14 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:52:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:52:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:52:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:52:14 --> Final output sent to browser
DEBUG - 2022-05-08 12:52:14 --> Total execution time: 0.0359
INFO - 2022-05-08 12:52:22 --> Config Class Initialized
INFO - 2022-05-08 12:52:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:52:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:52:22 --> Utf8 Class Initialized
INFO - 2022-05-08 12:52:22 --> URI Class Initialized
INFO - 2022-05-08 12:52:22 --> Router Class Initialized
INFO - 2022-05-08 12:52:22 --> Output Class Initialized
INFO - 2022-05-08 12:52:22 --> Security Class Initialized
DEBUG - 2022-05-08 12:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:52:22 --> Input Class Initialized
INFO - 2022-05-08 12:52:22 --> Language Class Initialized
INFO - 2022-05-08 12:52:22 --> Language Class Initialized
INFO - 2022-05-08 12:52:22 --> Config Class Initialized
INFO - 2022-05-08 12:52:22 --> Loader Class Initialized
INFO - 2022-05-08 12:52:22 --> Helper loaded: url_helper
INFO - 2022-05-08 12:52:22 --> Database Driver Class Initialized
INFO - 2022-05-08 12:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:52:22 --> Controller Class Initialized
DEBUG - 2022-05-08 12:52:22 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:52:22 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:52:22 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:52:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:52:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:52:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:52:22 --> Final output sent to browser
DEBUG - 2022-05-08 12:52:22 --> Total execution time: 0.0384
INFO - 2022-05-08 12:52:42 --> Config Class Initialized
INFO - 2022-05-08 12:52:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:52:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:52:42 --> Utf8 Class Initialized
INFO - 2022-05-08 12:52:42 --> URI Class Initialized
INFO - 2022-05-08 12:52:42 --> Router Class Initialized
INFO - 2022-05-08 12:52:42 --> Output Class Initialized
INFO - 2022-05-08 12:52:42 --> Security Class Initialized
DEBUG - 2022-05-08 12:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:52:42 --> Input Class Initialized
INFO - 2022-05-08 12:52:42 --> Language Class Initialized
INFO - 2022-05-08 12:52:42 --> Language Class Initialized
INFO - 2022-05-08 12:52:42 --> Config Class Initialized
INFO - 2022-05-08 12:52:42 --> Loader Class Initialized
INFO - 2022-05-08 12:52:42 --> Helper loaded: url_helper
INFO - 2022-05-08 12:52:42 --> Database Driver Class Initialized
INFO - 2022-05-08 12:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:52:42 --> Controller Class Initialized
DEBUG - 2022-05-08 12:52:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:52:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:52:42 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:52:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:52:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:52:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:52:42 --> Final output sent to browser
DEBUG - 2022-05-08 12:52:42 --> Total execution time: 0.0358
INFO - 2022-05-08 12:52:53 --> Config Class Initialized
INFO - 2022-05-08 12:52:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:52:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:52:53 --> Utf8 Class Initialized
INFO - 2022-05-08 12:52:53 --> URI Class Initialized
INFO - 2022-05-08 12:52:53 --> Router Class Initialized
INFO - 2022-05-08 12:52:53 --> Output Class Initialized
INFO - 2022-05-08 12:52:53 --> Security Class Initialized
DEBUG - 2022-05-08 12:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:52:53 --> Input Class Initialized
INFO - 2022-05-08 12:52:53 --> Language Class Initialized
ERROR - 2022-05-08 12:52:53 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:52:53 --> Config Class Initialized
INFO - 2022-05-08 12:52:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:52:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:52:53 --> Utf8 Class Initialized
INFO - 2022-05-08 12:52:53 --> URI Class Initialized
INFO - 2022-05-08 12:52:53 --> Router Class Initialized
INFO - 2022-05-08 12:52:53 --> Output Class Initialized
INFO - 2022-05-08 12:52:53 --> Security Class Initialized
DEBUG - 2022-05-08 12:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:52:53 --> Input Class Initialized
INFO - 2022-05-08 12:52:53 --> Language Class Initialized
INFO - 2022-05-08 12:52:53 --> Language Class Initialized
INFO - 2022-05-08 12:52:53 --> Config Class Initialized
INFO - 2022-05-08 12:52:53 --> Loader Class Initialized
INFO - 2022-05-08 12:52:53 --> Helper loaded: url_helper
INFO - 2022-05-08 12:52:53 --> Database Driver Class Initialized
INFO - 2022-05-08 12:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:52:53 --> Controller Class Initialized
DEBUG - 2022-05-08 12:52:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:52:53 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:52:53 --> Model Class Initialized
DEBUG - 2022-05-08 12:52:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:52:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:52:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:52:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:52:53 --> Final output sent to browser
DEBUG - 2022-05-08 12:52:53 --> Total execution time: 0.0380
INFO - 2022-05-08 12:53:34 --> Config Class Initialized
INFO - 2022-05-08 12:53:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:53:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:53:34 --> Utf8 Class Initialized
INFO - 2022-05-08 12:53:34 --> URI Class Initialized
INFO - 2022-05-08 12:53:34 --> Router Class Initialized
INFO - 2022-05-08 12:53:34 --> Output Class Initialized
INFO - 2022-05-08 12:53:34 --> Security Class Initialized
DEBUG - 2022-05-08 12:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:53:34 --> Input Class Initialized
INFO - 2022-05-08 12:53:34 --> Language Class Initialized
INFO - 2022-05-08 12:53:34 --> Language Class Initialized
INFO - 2022-05-08 12:53:34 --> Config Class Initialized
INFO - 2022-05-08 12:53:34 --> Loader Class Initialized
INFO - 2022-05-08 12:53:34 --> Helper loaded: url_helper
INFO - 2022-05-08 12:53:34 --> Database Driver Class Initialized
INFO - 2022-05-08 12:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:53:34 --> Controller Class Initialized
DEBUG - 2022-05-08 12:53:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:53:34 --> Model Class Initialized
DEBUG - 2022-05-08 12:53:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:53:34 --> Model Class Initialized
DEBUG - 2022-05-08 12:53:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:53:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:53:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:53:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:53:34 --> Final output sent to browser
DEBUG - 2022-05-08 12:53:34 --> Total execution time: 0.0579
INFO - 2022-05-08 12:53:48 --> Config Class Initialized
INFO - 2022-05-08 12:53:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:53:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:53:48 --> Utf8 Class Initialized
INFO - 2022-05-08 12:53:48 --> URI Class Initialized
INFO - 2022-05-08 12:53:48 --> Router Class Initialized
INFO - 2022-05-08 12:53:48 --> Output Class Initialized
INFO - 2022-05-08 12:53:48 --> Security Class Initialized
DEBUG - 2022-05-08 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:53:48 --> Input Class Initialized
INFO - 2022-05-08 12:53:48 --> Language Class Initialized
INFO - 2022-05-08 12:53:48 --> Language Class Initialized
INFO - 2022-05-08 12:53:48 --> Config Class Initialized
INFO - 2022-05-08 12:53:48 --> Loader Class Initialized
INFO - 2022-05-08 12:53:48 --> Helper loaded: url_helper
INFO - 2022-05-08 12:53:48 --> Database Driver Class Initialized
INFO - 2022-05-08 12:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:53:48 --> Controller Class Initialized
DEBUG - 2022-05-08 12:53:48 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:53:48 --> Model Class Initialized
DEBUG - 2022-05-08 12:53:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:53:48 --> Model Class Initialized
DEBUG - 2022-05-08 12:53:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:53:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:53:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:53:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:53:48 --> Final output sent to browser
DEBUG - 2022-05-08 12:53:48 --> Total execution time: 0.0372
INFO - 2022-05-08 12:53:51 --> Config Class Initialized
INFO - 2022-05-08 12:53:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:53:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:53:51 --> Utf8 Class Initialized
INFO - 2022-05-08 12:53:51 --> URI Class Initialized
INFO - 2022-05-08 12:53:51 --> Router Class Initialized
INFO - 2022-05-08 12:53:51 --> Output Class Initialized
INFO - 2022-05-08 12:53:51 --> Security Class Initialized
DEBUG - 2022-05-08 12:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:53:51 --> Input Class Initialized
INFO - 2022-05-08 12:53:51 --> Language Class Initialized
ERROR - 2022-05-08 12:53:51 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:00 --> Config Class Initialized
INFO - 2022-05-08 12:54:00 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:00 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:00 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:00 --> URI Class Initialized
INFO - 2022-05-08 12:54:00 --> Router Class Initialized
INFO - 2022-05-08 12:54:00 --> Output Class Initialized
INFO - 2022-05-08 12:54:00 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:00 --> Input Class Initialized
INFO - 2022-05-08 12:54:00 --> Language Class Initialized
INFO - 2022-05-08 12:54:00 --> Language Class Initialized
INFO - 2022-05-08 12:54:00 --> Config Class Initialized
INFO - 2022-05-08 12:54:00 --> Loader Class Initialized
INFO - 2022-05-08 12:54:00 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:00 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:00 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:00 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:00 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:00 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:00 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:00 --> Total execution time: 0.0372
INFO - 2022-05-08 12:54:01 --> Config Class Initialized
INFO - 2022-05-08 12:54:01 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:01 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:01 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:01 --> URI Class Initialized
INFO - 2022-05-08 12:54:01 --> Router Class Initialized
INFO - 2022-05-08 12:54:01 --> Output Class Initialized
INFO - 2022-05-08 12:54:01 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:01 --> Input Class Initialized
INFO - 2022-05-08 12:54:01 --> Language Class Initialized
ERROR - 2022-05-08 12:54:01 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:06 --> Config Class Initialized
INFO - 2022-05-08 12:54:06 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:06 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:06 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:06 --> URI Class Initialized
INFO - 2022-05-08 12:54:06 --> Router Class Initialized
INFO - 2022-05-08 12:54:06 --> Output Class Initialized
INFO - 2022-05-08 12:54:06 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:06 --> Input Class Initialized
INFO - 2022-05-08 12:54:06 --> Language Class Initialized
INFO - 2022-05-08 12:54:06 --> Language Class Initialized
INFO - 2022-05-08 12:54:06 --> Config Class Initialized
INFO - 2022-05-08 12:54:06 --> Loader Class Initialized
INFO - 2022-05-08 12:54:06 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:06 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:06 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:06 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:06 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:06 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:06 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:06 --> Total execution time: 0.0390
INFO - 2022-05-08 12:54:07 --> Config Class Initialized
INFO - 2022-05-08 12:54:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:07 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:07 --> URI Class Initialized
INFO - 2022-05-08 12:54:07 --> Router Class Initialized
INFO - 2022-05-08 12:54:07 --> Output Class Initialized
INFO - 2022-05-08 12:54:07 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:07 --> Input Class Initialized
INFO - 2022-05-08 12:54:07 --> Language Class Initialized
ERROR - 2022-05-08 12:54:07 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:16 --> Config Class Initialized
INFO - 2022-05-08 12:54:16 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:16 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:16 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:16 --> URI Class Initialized
INFO - 2022-05-08 12:54:16 --> Router Class Initialized
INFO - 2022-05-08 12:54:16 --> Output Class Initialized
INFO - 2022-05-08 12:54:16 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:16 --> Input Class Initialized
INFO - 2022-05-08 12:54:16 --> Language Class Initialized
INFO - 2022-05-08 12:54:16 --> Language Class Initialized
INFO - 2022-05-08 12:54:16 --> Config Class Initialized
INFO - 2022-05-08 12:54:16 --> Loader Class Initialized
INFO - 2022-05-08 12:54:16 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:16 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:16 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:16 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:16 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:16 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:16 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:16 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:16 --> Total execution time: 0.0398
INFO - 2022-05-08 12:54:17 --> Config Class Initialized
INFO - 2022-05-08 12:54:17 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:17 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:17 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:17 --> URI Class Initialized
INFO - 2022-05-08 12:54:17 --> Router Class Initialized
INFO - 2022-05-08 12:54:17 --> Output Class Initialized
INFO - 2022-05-08 12:54:17 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:17 --> Input Class Initialized
INFO - 2022-05-08 12:54:17 --> Language Class Initialized
ERROR - 2022-05-08 12:54:17 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:25 --> Config Class Initialized
INFO - 2022-05-08 12:54:25 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:25 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:25 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:25 --> URI Class Initialized
INFO - 2022-05-08 12:54:25 --> Router Class Initialized
INFO - 2022-05-08 12:54:25 --> Output Class Initialized
INFO - 2022-05-08 12:54:25 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:25 --> Input Class Initialized
INFO - 2022-05-08 12:54:25 --> Language Class Initialized
INFO - 2022-05-08 12:54:25 --> Language Class Initialized
INFO - 2022-05-08 12:54:25 --> Config Class Initialized
INFO - 2022-05-08 12:54:25 --> Loader Class Initialized
INFO - 2022-05-08 12:54:25 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:25 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:25 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:25 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:25 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:25 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:25 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:25 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:25 --> Total execution time: 0.0306
INFO - 2022-05-08 12:54:26 --> Config Class Initialized
INFO - 2022-05-08 12:54:26 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:26 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:26 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:26 --> URI Class Initialized
INFO - 2022-05-08 12:54:26 --> Router Class Initialized
INFO - 2022-05-08 12:54:26 --> Output Class Initialized
INFO - 2022-05-08 12:54:26 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:26 --> Input Class Initialized
INFO - 2022-05-08 12:54:26 --> Language Class Initialized
ERROR - 2022-05-08 12:54:26 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:27 --> Config Class Initialized
INFO - 2022-05-08 12:54:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:27 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:27 --> URI Class Initialized
INFO - 2022-05-08 12:54:27 --> Router Class Initialized
INFO - 2022-05-08 12:54:27 --> Output Class Initialized
INFO - 2022-05-08 12:54:27 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:27 --> Input Class Initialized
INFO - 2022-05-08 12:54:27 --> Language Class Initialized
INFO - 2022-05-08 12:54:27 --> Language Class Initialized
INFO - 2022-05-08 12:54:27 --> Config Class Initialized
INFO - 2022-05-08 12:54:27 --> Loader Class Initialized
INFO - 2022-05-08 12:54:27 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:27 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:27 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:27 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:27 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:27 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:27 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:27 --> Total execution time: 0.0387
INFO - 2022-05-08 12:54:28 --> Config Class Initialized
INFO - 2022-05-08 12:54:28 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:28 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:28 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:28 --> URI Class Initialized
INFO - 2022-05-08 12:54:28 --> Router Class Initialized
INFO - 2022-05-08 12:54:28 --> Output Class Initialized
INFO - 2022-05-08 12:54:28 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:28 --> Input Class Initialized
INFO - 2022-05-08 12:54:28 --> Language Class Initialized
ERROR - 2022-05-08 12:54:28 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:31 --> Config Class Initialized
INFO - 2022-05-08 12:54:31 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:31 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:31 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:31 --> URI Class Initialized
INFO - 2022-05-08 12:54:31 --> Router Class Initialized
INFO - 2022-05-08 12:54:31 --> Output Class Initialized
INFO - 2022-05-08 12:54:31 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:31 --> Input Class Initialized
INFO - 2022-05-08 12:54:31 --> Language Class Initialized
INFO - 2022-05-08 12:54:31 --> Language Class Initialized
INFO - 2022-05-08 12:54:31 --> Config Class Initialized
INFO - 2022-05-08 12:54:31 --> Loader Class Initialized
INFO - 2022-05-08 12:54:31 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:31 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:31 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:31 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:31 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:31 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:31 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:31 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:31 --> Total execution time: 0.0399
INFO - 2022-05-08 12:54:32 --> Config Class Initialized
INFO - 2022-05-08 12:54:32 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:32 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:32 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:32 --> URI Class Initialized
INFO - 2022-05-08 12:54:32 --> Router Class Initialized
INFO - 2022-05-08 12:54:32 --> Output Class Initialized
INFO - 2022-05-08 12:54:32 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:32 --> Input Class Initialized
INFO - 2022-05-08 12:54:32 --> Language Class Initialized
ERROR - 2022-05-08 12:54:32 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:33 --> Config Class Initialized
INFO - 2022-05-08 12:54:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:33 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:33 --> URI Class Initialized
INFO - 2022-05-08 12:54:33 --> Router Class Initialized
INFO - 2022-05-08 12:54:33 --> Output Class Initialized
INFO - 2022-05-08 12:54:33 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:33 --> Input Class Initialized
INFO - 2022-05-08 12:54:33 --> Language Class Initialized
INFO - 2022-05-08 12:54:33 --> Language Class Initialized
INFO - 2022-05-08 12:54:33 --> Config Class Initialized
INFO - 2022-05-08 12:54:33 --> Loader Class Initialized
INFO - 2022-05-08 12:54:33 --> Helper loaded: url_helper
INFO - 2022-05-08 12:54:33 --> Database Driver Class Initialized
INFO - 2022-05-08 12:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:54:33 --> Controller Class Initialized
DEBUG - 2022-05-08 12:54:33 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:54:33 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:54:33 --> Model Class Initialized
DEBUG - 2022-05-08 12:54:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:54:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:54:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:54:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:54:33 --> Final output sent to browser
DEBUG - 2022-05-08 12:54:33 --> Total execution time: 0.0377
INFO - 2022-05-08 12:54:33 --> Config Class Initialized
INFO - 2022-05-08 12:54:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:33 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:33 --> URI Class Initialized
INFO - 2022-05-08 12:54:33 --> Router Class Initialized
INFO - 2022-05-08 12:54:33 --> Output Class Initialized
INFO - 2022-05-08 12:54:33 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:33 --> Input Class Initialized
INFO - 2022-05-08 12:54:33 --> Language Class Initialized
ERROR - 2022-05-08 12:54:33 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:54:48 --> Config Class Initialized
INFO - 2022-05-08 12:54:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:54:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:54:48 --> Utf8 Class Initialized
INFO - 2022-05-08 12:54:48 --> URI Class Initialized
INFO - 2022-05-08 12:54:48 --> Router Class Initialized
INFO - 2022-05-08 12:54:48 --> Output Class Initialized
INFO - 2022-05-08 12:54:48 --> Security Class Initialized
DEBUG - 2022-05-08 12:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:54:48 --> Input Class Initialized
INFO - 2022-05-08 12:54:48 --> Language Class Initialized
ERROR - 2022-05-08 12:54:48 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:55:20 --> Config Class Initialized
INFO - 2022-05-08 12:55:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:55:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:55:20 --> Utf8 Class Initialized
INFO - 2022-05-08 12:55:20 --> URI Class Initialized
INFO - 2022-05-08 12:55:20 --> Router Class Initialized
INFO - 2022-05-08 12:55:20 --> Output Class Initialized
INFO - 2022-05-08 12:55:20 --> Security Class Initialized
DEBUG - 2022-05-08 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:55:20 --> Input Class Initialized
INFO - 2022-05-08 12:55:20 --> Language Class Initialized
INFO - 2022-05-08 12:55:20 --> Language Class Initialized
INFO - 2022-05-08 12:55:20 --> Config Class Initialized
INFO - 2022-05-08 12:55:20 --> Loader Class Initialized
INFO - 2022-05-08 12:55:20 --> Helper loaded: url_helper
INFO - 2022-05-08 12:55:20 --> Database Driver Class Initialized
INFO - 2022-05-08 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:55:20 --> Controller Class Initialized
DEBUG - 2022-05-08 12:55:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:55:20 --> Model Class Initialized
DEBUG - 2022-05-08 12:55:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:55:20 --> Model Class Initialized
DEBUG - 2022-05-08 12:55:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:55:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:55:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:55:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:55:20 --> Final output sent to browser
DEBUG - 2022-05-08 12:55:20 --> Total execution time: 0.0373
INFO - 2022-05-08 12:55:21 --> Config Class Initialized
INFO - 2022-05-08 12:55:21 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:55:21 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:55:21 --> Utf8 Class Initialized
INFO - 2022-05-08 12:55:21 --> URI Class Initialized
INFO - 2022-05-08 12:55:21 --> Router Class Initialized
INFO - 2022-05-08 12:55:21 --> Output Class Initialized
INFO - 2022-05-08 12:55:21 --> Security Class Initialized
DEBUG - 2022-05-08 12:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:55:21 --> Input Class Initialized
INFO - 2022-05-08 12:55:21 --> Language Class Initialized
ERROR - 2022-05-08 12:55:21 --> 404 Page Not Found: /index
INFO - 2022-05-08 12:55:44 --> Config Class Initialized
INFO - 2022-05-08 12:55:44 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:55:44 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:55:44 --> Utf8 Class Initialized
INFO - 2022-05-08 12:55:44 --> URI Class Initialized
INFO - 2022-05-08 12:55:44 --> Router Class Initialized
INFO - 2022-05-08 12:55:44 --> Output Class Initialized
INFO - 2022-05-08 12:55:44 --> Security Class Initialized
DEBUG - 2022-05-08 12:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:55:44 --> Input Class Initialized
INFO - 2022-05-08 12:55:44 --> Language Class Initialized
INFO - 2022-05-08 12:55:44 --> Language Class Initialized
INFO - 2022-05-08 12:55:44 --> Config Class Initialized
INFO - 2022-05-08 12:55:44 --> Loader Class Initialized
INFO - 2022-05-08 12:55:44 --> Helper loaded: url_helper
INFO - 2022-05-08 12:55:44 --> Database Driver Class Initialized
INFO - 2022-05-08 12:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 12:55:44 --> Controller Class Initialized
DEBUG - 2022-05-08 12:55:44 --> Admin MX_Controller Initialized
INFO - 2022-05-08 12:55:44 --> Model Class Initialized
DEBUG - 2022-05-08 12:55:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 12:55:44 --> Model Class Initialized
DEBUG - 2022-05-08 12:55:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 12:55:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 12:55:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 12:55:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 12:55:44 --> Final output sent to browser
DEBUG - 2022-05-08 12:55:44 --> Total execution time: 0.0364
INFO - 2022-05-08 12:55:48 --> Config Class Initialized
INFO - 2022-05-08 12:55:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 12:55:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 12:55:48 --> Utf8 Class Initialized
INFO - 2022-05-08 12:55:48 --> URI Class Initialized
INFO - 2022-05-08 12:55:48 --> Router Class Initialized
INFO - 2022-05-08 12:55:48 --> Output Class Initialized
INFO - 2022-05-08 12:55:48 --> Security Class Initialized
DEBUG - 2022-05-08 12:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 12:55:48 --> Input Class Initialized
INFO - 2022-05-08 12:55:48 --> Language Class Initialized
ERROR - 2022-05-08 12:55:48 --> 404 Page Not Found: /index
INFO - 2022-05-08 13:01:36 --> Config Class Initialized
INFO - 2022-05-08 13:01:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:01:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:01:36 --> Utf8 Class Initialized
INFO - 2022-05-08 13:01:36 --> URI Class Initialized
INFO - 2022-05-08 13:01:36 --> Router Class Initialized
INFO - 2022-05-08 13:01:36 --> Output Class Initialized
INFO - 2022-05-08 13:01:36 --> Security Class Initialized
DEBUG - 2022-05-08 13:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:01:36 --> Input Class Initialized
INFO - 2022-05-08 13:01:36 --> Language Class Initialized
INFO - 2022-05-08 13:01:36 --> Language Class Initialized
INFO - 2022-05-08 13:01:36 --> Config Class Initialized
INFO - 2022-05-08 13:01:36 --> Loader Class Initialized
INFO - 2022-05-08 13:01:36 --> Helper loaded: url_helper
INFO - 2022-05-08 13:01:36 --> Database Driver Class Initialized
INFO - 2022-05-08 13:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:01:36 --> Controller Class Initialized
DEBUG - 2022-05-08 13:01:36 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:01:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:01:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:01:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:01:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:01:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_id N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 83
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 84
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_id N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 83
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 84
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_id N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 83
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 84
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_id N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 83
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 84
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_id N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 83
ERROR - 2022-05-08 13:01:36 --> Severity: Notice --> Undefined index: c_name N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 84
DEBUG - 2022-05-08 13:01:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:01:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:01:36 --> Final output sent to browser
DEBUG - 2022-05-08 13:01:36 --> Total execution time: 0.0327
INFO - 2022-05-08 13:02:04 --> Config Class Initialized
INFO - 2022-05-08 13:02:04 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:02:04 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:02:04 --> Utf8 Class Initialized
INFO - 2022-05-08 13:02:04 --> URI Class Initialized
INFO - 2022-05-08 13:02:04 --> Router Class Initialized
INFO - 2022-05-08 13:02:04 --> Output Class Initialized
INFO - 2022-05-08 13:02:04 --> Security Class Initialized
DEBUG - 2022-05-08 13:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:02:04 --> Input Class Initialized
INFO - 2022-05-08 13:02:04 --> Language Class Initialized
INFO - 2022-05-08 13:02:04 --> Language Class Initialized
INFO - 2022-05-08 13:02:04 --> Config Class Initialized
INFO - 2022-05-08 13:02:04 --> Loader Class Initialized
INFO - 2022-05-08 13:02:04 --> Helper loaded: url_helper
INFO - 2022-05-08 13:02:04 --> Database Driver Class Initialized
INFO - 2022-05-08 13:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:02:04 --> Controller Class Initialized
DEBUG - 2022-05-08 13:02:04 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:02:04 --> Model Class Initialized
DEBUG - 2022-05-08 13:02:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:02:04 --> Model Class Initialized
DEBUG - 2022-05-08 13:02:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:02:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-08 13:02:04 --> Severity: Parsing Error --> syntax error, unexpected ')' N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_category.php 3
INFO - 2022-05-08 13:02:24 --> Config Class Initialized
INFO - 2022-05-08 13:02:24 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:02:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:02:24 --> Utf8 Class Initialized
INFO - 2022-05-08 13:02:24 --> URI Class Initialized
INFO - 2022-05-08 13:02:24 --> Router Class Initialized
INFO - 2022-05-08 13:02:24 --> Output Class Initialized
INFO - 2022-05-08 13:02:24 --> Security Class Initialized
DEBUG - 2022-05-08 13:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:02:24 --> Input Class Initialized
INFO - 2022-05-08 13:02:24 --> Language Class Initialized
INFO - 2022-05-08 13:02:24 --> Language Class Initialized
INFO - 2022-05-08 13:02:24 --> Config Class Initialized
INFO - 2022-05-08 13:02:24 --> Loader Class Initialized
INFO - 2022-05-08 13:02:24 --> Helper loaded: url_helper
INFO - 2022-05-08 13:02:24 --> Database Driver Class Initialized
INFO - 2022-05-08 13:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:02:24 --> Controller Class Initialized
DEBUG - 2022-05-08 13:02:24 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:02:24 --> Model Class Initialized
DEBUG - 2022-05-08 13:02:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:02:24 --> Model Class Initialized
DEBUG - 2022-05-08 13:02:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:02:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
INFO - 2022-05-08 13:03:09 --> Config Class Initialized
INFO - 2022-05-08 13:03:09 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:03:09 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:03:09 --> Utf8 Class Initialized
INFO - 2022-05-08 13:03:09 --> URI Class Initialized
INFO - 2022-05-08 13:03:09 --> Router Class Initialized
INFO - 2022-05-08 13:03:09 --> Output Class Initialized
INFO - 2022-05-08 13:03:09 --> Security Class Initialized
DEBUG - 2022-05-08 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:03:09 --> Input Class Initialized
INFO - 2022-05-08 13:03:09 --> Language Class Initialized
INFO - 2022-05-08 13:03:09 --> Language Class Initialized
INFO - 2022-05-08 13:03:09 --> Config Class Initialized
INFO - 2022-05-08 13:03:09 --> Loader Class Initialized
INFO - 2022-05-08 13:03:09 --> Helper loaded: url_helper
INFO - 2022-05-08 13:03:09 --> Database Driver Class Initialized
INFO - 2022-05-08 13:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:03:09 --> Controller Class Initialized
DEBUG - 2022-05-08 13:03:09 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:03:09 --> Model Class Initialized
DEBUG - 2022-05-08 13:03:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:03:09 --> Model Class Initialized
DEBUG - 2022-05-08 13:03:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:03:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:03:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:03:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:03:09 --> Final output sent to browser
DEBUG - 2022-05-08 13:03:09 --> Total execution time: 0.0315
INFO - 2022-05-08 13:03:22 --> Config Class Initialized
INFO - 2022-05-08 13:03:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:03:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:03:22 --> Utf8 Class Initialized
INFO - 2022-05-08 13:03:22 --> URI Class Initialized
INFO - 2022-05-08 13:03:22 --> Router Class Initialized
INFO - 2022-05-08 13:03:22 --> Output Class Initialized
INFO - 2022-05-08 13:03:22 --> Security Class Initialized
DEBUG - 2022-05-08 13:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:03:22 --> Input Class Initialized
INFO - 2022-05-08 13:03:22 --> Language Class Initialized
INFO - 2022-05-08 13:03:22 --> Language Class Initialized
INFO - 2022-05-08 13:03:22 --> Config Class Initialized
INFO - 2022-05-08 13:03:22 --> Loader Class Initialized
INFO - 2022-05-08 13:03:22 --> Helper loaded: url_helper
INFO - 2022-05-08 13:03:22 --> Database Driver Class Initialized
INFO - 2022-05-08 13:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:03:22 --> Controller Class Initialized
DEBUG - 2022-05-08 13:03:22 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:03:22 --> Model Class Initialized
DEBUG - 2022-05-08 13:03:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:03:22 --> Model Class Initialized
DEBUG - 2022-05-08 13:03:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:03:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:03:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:03:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:03:22 --> Final output sent to browser
DEBUG - 2022-05-08 13:03:22 --> Total execution time: 0.0280
INFO - 2022-05-08 13:09:30 --> Config Class Initialized
INFO - 2022-05-08 13:09:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:09:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:09:30 --> Utf8 Class Initialized
INFO - 2022-05-08 13:09:30 --> URI Class Initialized
INFO - 2022-05-08 13:09:30 --> Router Class Initialized
INFO - 2022-05-08 13:09:30 --> Output Class Initialized
INFO - 2022-05-08 13:09:30 --> Security Class Initialized
DEBUG - 2022-05-08 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:09:30 --> Input Class Initialized
INFO - 2022-05-08 13:09:30 --> Language Class Initialized
INFO - 2022-05-08 13:09:30 --> Language Class Initialized
INFO - 2022-05-08 13:09:30 --> Config Class Initialized
INFO - 2022-05-08 13:09:30 --> Loader Class Initialized
INFO - 2022-05-08 13:09:30 --> Helper loaded: url_helper
INFO - 2022-05-08 13:09:30 --> Database Driver Class Initialized
INFO - 2022-05-08 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:09:30 --> Controller Class Initialized
DEBUG - 2022-05-08 13:09:30 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:09:30 --> Model Class Initialized
DEBUG - 2022-05-08 13:09:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:09:30 --> Model Class Initialized
DEBUG - 2022-05-08 13:09:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:09:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:09:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:09:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:09:30 --> Final output sent to browser
DEBUG - 2022-05-08 13:09:30 --> Total execution time: 0.0404
INFO - 2022-05-08 13:09:34 --> Config Class Initialized
INFO - 2022-05-08 13:09:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:09:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:09:34 --> Utf8 Class Initialized
INFO - 2022-05-08 13:09:34 --> URI Class Initialized
INFO - 2022-05-08 13:09:34 --> Router Class Initialized
INFO - 2022-05-08 13:09:34 --> Output Class Initialized
INFO - 2022-05-08 13:09:34 --> Security Class Initialized
DEBUG - 2022-05-08 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:09:34 --> Input Class Initialized
INFO - 2022-05-08 13:09:34 --> Language Class Initialized
INFO - 2022-05-08 13:09:34 --> Language Class Initialized
INFO - 2022-05-08 13:09:34 --> Config Class Initialized
INFO - 2022-05-08 13:09:34 --> Loader Class Initialized
INFO - 2022-05-08 13:09:34 --> Helper loaded: url_helper
INFO - 2022-05-08 13:09:34 --> Database Driver Class Initialized
INFO - 2022-05-08 13:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:09:34 --> Controller Class Initialized
DEBUG - 2022-05-08 13:09:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:09:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:09:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:09:34 --> Model Class Initialized
INFO - 2022-05-08 13:09:37 --> Final output sent to browser
DEBUG - 2022-05-08 13:09:37 --> Total execution time: 2.5620
INFO - 2022-05-08 13:10:17 --> Config Class Initialized
INFO - 2022-05-08 13:10:17 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:10:17 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:10:17 --> Utf8 Class Initialized
INFO - 2022-05-08 13:10:17 --> URI Class Initialized
INFO - 2022-05-08 13:10:17 --> Router Class Initialized
INFO - 2022-05-08 13:10:17 --> Output Class Initialized
INFO - 2022-05-08 13:10:17 --> Security Class Initialized
DEBUG - 2022-05-08 13:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:10:17 --> Input Class Initialized
INFO - 2022-05-08 13:10:17 --> Language Class Initialized
INFO - 2022-05-08 13:10:17 --> Language Class Initialized
INFO - 2022-05-08 13:10:17 --> Config Class Initialized
INFO - 2022-05-08 13:10:17 --> Loader Class Initialized
INFO - 2022-05-08 13:10:17 --> Helper loaded: url_helper
INFO - 2022-05-08 13:10:17 --> Database Driver Class Initialized
INFO - 2022-05-08 13:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:10:17 --> Controller Class Initialized
DEBUG - 2022-05-08 13:10:17 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:10:17 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:10:17 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:10:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:10:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:10:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:10:17 --> Final output sent to browser
DEBUG - 2022-05-08 13:10:17 --> Total execution time: 0.0406
INFO - 2022-05-08 13:10:20 --> Config Class Initialized
INFO - 2022-05-08 13:10:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:10:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:10:20 --> Utf8 Class Initialized
INFO - 2022-05-08 13:10:20 --> URI Class Initialized
INFO - 2022-05-08 13:10:20 --> Router Class Initialized
INFO - 2022-05-08 13:10:20 --> Output Class Initialized
INFO - 2022-05-08 13:10:20 --> Security Class Initialized
DEBUG - 2022-05-08 13:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:10:20 --> Input Class Initialized
INFO - 2022-05-08 13:10:20 --> Language Class Initialized
INFO - 2022-05-08 13:10:20 --> Language Class Initialized
INFO - 2022-05-08 13:10:20 --> Config Class Initialized
INFO - 2022-05-08 13:10:20 --> Loader Class Initialized
INFO - 2022-05-08 13:10:20 --> Helper loaded: url_helper
INFO - 2022-05-08 13:10:20 --> Database Driver Class Initialized
INFO - 2022-05-08 13:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:10:20 --> Controller Class Initialized
DEBUG - 2022-05-08 13:10:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:10:20 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:10:20 --> Model Class Initialized
INFO - 2022-05-08 13:10:20 --> Config Class Initialized
INFO - 2022-05-08 13:10:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:10:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:10:20 --> Utf8 Class Initialized
INFO - 2022-05-08 13:10:20 --> URI Class Initialized
INFO - 2022-05-08 13:10:20 --> Router Class Initialized
INFO - 2022-05-08 13:10:20 --> Output Class Initialized
INFO - 2022-05-08 13:10:20 --> Security Class Initialized
DEBUG - 2022-05-08 13:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:10:20 --> Input Class Initialized
INFO - 2022-05-08 13:10:20 --> Language Class Initialized
INFO - 2022-05-08 13:10:20 --> Language Class Initialized
INFO - 2022-05-08 13:10:20 --> Config Class Initialized
INFO - 2022-05-08 13:10:20 --> Loader Class Initialized
INFO - 2022-05-08 13:10:20 --> Helper loaded: url_helper
INFO - 2022-05-08 13:10:20 --> Database Driver Class Initialized
INFO - 2022-05-08 13:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:10:20 --> Controller Class Initialized
DEBUG - 2022-05-08 13:10:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:10:20 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:10:20 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:10:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:10:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:10:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:10:20 --> Final output sent to browser
DEBUG - 2022-05-08 13:10:20 --> Total execution time: 0.0272
INFO - 2022-05-08 13:10:42 --> Config Class Initialized
INFO - 2022-05-08 13:10:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:10:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:10:42 --> Utf8 Class Initialized
INFO - 2022-05-08 13:10:42 --> URI Class Initialized
INFO - 2022-05-08 13:10:42 --> Router Class Initialized
INFO - 2022-05-08 13:10:42 --> Output Class Initialized
INFO - 2022-05-08 13:10:42 --> Security Class Initialized
DEBUG - 2022-05-08 13:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:10:42 --> Input Class Initialized
INFO - 2022-05-08 13:10:42 --> Language Class Initialized
INFO - 2022-05-08 13:10:42 --> Language Class Initialized
INFO - 2022-05-08 13:10:42 --> Config Class Initialized
INFO - 2022-05-08 13:10:42 --> Loader Class Initialized
INFO - 2022-05-08 13:10:42 --> Helper loaded: url_helper
INFO - 2022-05-08 13:10:42 --> Database Driver Class Initialized
INFO - 2022-05-08 13:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:10:42 --> Controller Class Initialized
DEBUG - 2022-05-08 13:10:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:10:42 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:10:42 --> Model Class Initialized
DEBUG - 2022-05-08 13:10:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:10:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:10:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:10:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:10:42 --> Final output sent to browser
DEBUG - 2022-05-08 13:10:42 --> Total execution time: 0.0376
INFO - 2022-05-08 13:13:03 --> Config Class Initialized
INFO - 2022-05-08 13:13:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:13:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:13:03 --> Utf8 Class Initialized
INFO - 2022-05-08 13:13:03 --> URI Class Initialized
INFO - 2022-05-08 13:13:03 --> Router Class Initialized
INFO - 2022-05-08 13:13:03 --> Output Class Initialized
INFO - 2022-05-08 13:13:03 --> Security Class Initialized
DEBUG - 2022-05-08 13:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:13:03 --> Input Class Initialized
INFO - 2022-05-08 13:13:03 --> Language Class Initialized
INFO - 2022-05-08 13:13:03 --> Language Class Initialized
INFO - 2022-05-08 13:13:03 --> Config Class Initialized
INFO - 2022-05-08 13:13:03 --> Loader Class Initialized
INFO - 2022-05-08 13:13:03 --> Helper loaded: url_helper
INFO - 2022-05-08 13:13:03 --> Database Driver Class Initialized
INFO - 2022-05-08 13:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:13:03 --> Controller Class Initialized
DEBUG - 2022-05-08 13:13:03 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:13:03 --> Model Class Initialized
DEBUG - 2022-05-08 13:13:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:13:03 --> Model Class Initialized
DEBUG - 2022-05-08 13:13:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:13:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:13:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:13:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:13:03 --> Final output sent to browser
DEBUG - 2022-05-08 13:13:03 --> Total execution time: 0.0397
INFO - 2022-05-08 13:13:26 --> Config Class Initialized
INFO - 2022-05-08 13:13:26 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:13:26 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:13:26 --> Utf8 Class Initialized
INFO - 2022-05-08 13:13:26 --> URI Class Initialized
INFO - 2022-05-08 13:13:26 --> Router Class Initialized
INFO - 2022-05-08 13:13:26 --> Output Class Initialized
INFO - 2022-05-08 13:13:26 --> Security Class Initialized
DEBUG - 2022-05-08 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:13:26 --> Input Class Initialized
INFO - 2022-05-08 13:13:26 --> Language Class Initialized
INFO - 2022-05-08 13:13:26 --> Language Class Initialized
INFO - 2022-05-08 13:13:26 --> Config Class Initialized
INFO - 2022-05-08 13:13:26 --> Loader Class Initialized
INFO - 2022-05-08 13:13:26 --> Helper loaded: url_helper
INFO - 2022-05-08 13:13:26 --> Database Driver Class Initialized
INFO - 2022-05-08 13:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:13:26 --> Controller Class Initialized
DEBUG - 2022-05-08 13:13:26 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:13:26 --> Model Class Initialized
DEBUG - 2022-05-08 13:13:26 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:13:26 --> Model Class Initialized
INFO - 2022-05-08 13:13:27 --> Upload Class Initialized
DEBUG - 2022-05-08 13:13:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:13:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:13:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:13:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:13:27 --> Final output sent to browser
DEBUG - 2022-05-08 13:13:27 --> Total execution time: 0.7888
INFO - 2022-05-08 13:16:07 --> Config Class Initialized
INFO - 2022-05-08 13:16:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:16:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:16:07 --> Utf8 Class Initialized
INFO - 2022-05-08 13:16:07 --> URI Class Initialized
INFO - 2022-05-08 13:16:07 --> Router Class Initialized
INFO - 2022-05-08 13:16:07 --> Output Class Initialized
INFO - 2022-05-08 13:16:07 --> Security Class Initialized
DEBUG - 2022-05-08 13:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:16:07 --> Input Class Initialized
INFO - 2022-05-08 13:16:07 --> Language Class Initialized
INFO - 2022-05-08 13:16:07 --> Language Class Initialized
INFO - 2022-05-08 13:16:07 --> Config Class Initialized
INFO - 2022-05-08 13:16:07 --> Loader Class Initialized
INFO - 2022-05-08 13:16:07 --> Helper loaded: url_helper
INFO - 2022-05-08 13:16:07 --> Database Driver Class Initialized
INFO - 2022-05-08 13:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:16:08 --> Controller Class Initialized
DEBUG - 2022-05-08 13:16:08 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:16:08 --> Model Class Initialized
DEBUG - 2022-05-08 13:16:08 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:16:08 --> Model Class Initialized
INFO - 2022-05-08 13:16:08 --> Upload Class Initialized
INFO - 2022-05-08 13:16:09 --> Config Class Initialized
INFO - 2022-05-08 13:16:09 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:16:09 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:16:09 --> Utf8 Class Initialized
INFO - 2022-05-08 13:16:09 --> URI Class Initialized
INFO - 2022-05-08 13:16:09 --> Router Class Initialized
INFO - 2022-05-08 13:16:09 --> Output Class Initialized
INFO - 2022-05-08 13:16:09 --> Security Class Initialized
DEBUG - 2022-05-08 13:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:16:09 --> Input Class Initialized
INFO - 2022-05-08 13:16:09 --> Language Class Initialized
INFO - 2022-05-08 13:16:09 --> Language Class Initialized
INFO - 2022-05-08 13:16:09 --> Config Class Initialized
INFO - 2022-05-08 13:16:09 --> Loader Class Initialized
INFO - 2022-05-08 13:16:09 --> Helper loaded: url_helper
INFO - 2022-05-08 13:16:09 --> Database Driver Class Initialized
INFO - 2022-05-08 13:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:16:09 --> Controller Class Initialized
DEBUG - 2022-05-08 13:16:09 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:16:10 --> Model Class Initialized
DEBUG - 2022-05-08 13:16:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:16:10 --> Model Class Initialized
DEBUG - 2022-05-08 13:16:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:16:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:16:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:16:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:16:10 --> Final output sent to browser
DEBUG - 2022-05-08 13:16:10 --> Total execution time: 0.0269
INFO - 2022-05-08 13:17:27 --> Config Class Initialized
INFO - 2022-05-08 13:17:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:17:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:17:27 --> Utf8 Class Initialized
INFO - 2022-05-08 13:17:27 --> URI Class Initialized
INFO - 2022-05-08 13:17:27 --> Router Class Initialized
INFO - 2022-05-08 13:17:27 --> Output Class Initialized
INFO - 2022-05-08 13:17:27 --> Security Class Initialized
DEBUG - 2022-05-08 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:17:27 --> Input Class Initialized
INFO - 2022-05-08 13:17:27 --> Language Class Initialized
INFO - 2022-05-08 13:17:27 --> Language Class Initialized
INFO - 2022-05-08 13:17:27 --> Config Class Initialized
INFO - 2022-05-08 13:17:27 --> Loader Class Initialized
INFO - 2022-05-08 13:17:27 --> Helper loaded: url_helper
INFO - 2022-05-08 13:17:27 --> Database Driver Class Initialized
INFO - 2022-05-08 13:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:17:27 --> Controller Class Initialized
DEBUG - 2022-05-08 13:17:27 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:17:27 --> Model Class Initialized
DEBUG - 2022-05-08 13:17:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:17:27 --> Model Class Initialized
INFO - 2022-05-08 13:17:27 --> Upload Class Initialized
INFO - 2022-05-08 13:17:28 --> Config Class Initialized
INFO - 2022-05-08 13:17:28 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:17:28 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:17:28 --> Utf8 Class Initialized
INFO - 2022-05-08 13:17:28 --> URI Class Initialized
INFO - 2022-05-08 13:17:28 --> Router Class Initialized
INFO - 2022-05-08 13:17:28 --> Output Class Initialized
INFO - 2022-05-08 13:17:28 --> Security Class Initialized
DEBUG - 2022-05-08 13:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:17:28 --> Input Class Initialized
INFO - 2022-05-08 13:17:28 --> Language Class Initialized
INFO - 2022-05-08 13:17:28 --> Language Class Initialized
INFO - 2022-05-08 13:17:28 --> Config Class Initialized
INFO - 2022-05-08 13:17:28 --> Loader Class Initialized
INFO - 2022-05-08 13:17:28 --> Helper loaded: url_helper
INFO - 2022-05-08 13:17:28 --> Database Driver Class Initialized
INFO - 2022-05-08 13:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:17:28 --> Controller Class Initialized
DEBUG - 2022-05-08 13:17:28 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:17:28 --> Model Class Initialized
DEBUG - 2022-05-08 13:17:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:17:28 --> Model Class Initialized
DEBUG - 2022-05-08 13:17:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:17:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:17:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:17:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:17:28 --> Final output sent to browser
DEBUG - 2022-05-08 13:17:28 --> Total execution time: 0.0376
INFO - 2022-05-08 13:18:27 --> Config Class Initialized
INFO - 2022-05-08 13:18:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:18:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:18:27 --> Utf8 Class Initialized
INFO - 2022-05-08 13:18:27 --> URI Class Initialized
INFO - 2022-05-08 13:18:27 --> Router Class Initialized
INFO - 2022-05-08 13:18:27 --> Output Class Initialized
INFO - 2022-05-08 13:18:27 --> Security Class Initialized
DEBUG - 2022-05-08 13:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:18:27 --> Input Class Initialized
INFO - 2022-05-08 13:18:27 --> Language Class Initialized
INFO - 2022-05-08 13:18:27 --> Language Class Initialized
INFO - 2022-05-08 13:18:27 --> Config Class Initialized
INFO - 2022-05-08 13:18:27 --> Loader Class Initialized
INFO - 2022-05-08 13:18:27 --> Helper loaded: url_helper
INFO - 2022-05-08 13:18:27 --> Database Driver Class Initialized
INFO - 2022-05-08 13:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:18:27 --> Controller Class Initialized
ERROR - 2022-05-08 13:18:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/add_model
INFO - 2022-05-08 13:19:11 --> Config Class Initialized
INFO - 2022-05-08 13:19:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:19:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:19:11 --> Utf8 Class Initialized
INFO - 2022-05-08 13:19:11 --> URI Class Initialized
INFO - 2022-05-08 13:19:11 --> Router Class Initialized
INFO - 2022-05-08 13:19:11 --> Output Class Initialized
INFO - 2022-05-08 13:19:11 --> Security Class Initialized
DEBUG - 2022-05-08 13:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:19:11 --> Input Class Initialized
INFO - 2022-05-08 13:19:11 --> Language Class Initialized
INFO - 2022-05-08 13:19:11 --> Language Class Initialized
INFO - 2022-05-08 13:19:11 --> Config Class Initialized
INFO - 2022-05-08 13:19:11 --> Loader Class Initialized
INFO - 2022-05-08 13:19:11 --> Helper loaded: url_helper
INFO - 2022-05-08 13:19:11 --> Database Driver Class Initialized
INFO - 2022-05-08 13:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:19:11 --> Controller Class Initialized
DEBUG - 2022-05-08 13:19:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:19:11 --> Model Class Initialized
DEBUG - 2022-05-08 13:19:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:19:11 --> Model Class Initialized
DEBUG - 2022-05-08 13:19:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:19:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:19:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:19:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:19:11 --> Final output sent to browser
DEBUG - 2022-05-08 13:19:11 --> Total execution time: 0.0387
INFO - 2022-05-08 13:19:13 --> Config Class Initialized
INFO - 2022-05-08 13:19:13 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:19:13 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:19:13 --> Utf8 Class Initialized
INFO - 2022-05-08 13:19:13 --> URI Class Initialized
INFO - 2022-05-08 13:19:13 --> Router Class Initialized
INFO - 2022-05-08 13:19:13 --> Output Class Initialized
INFO - 2022-05-08 13:19:13 --> Security Class Initialized
DEBUG - 2022-05-08 13:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:19:13 --> Input Class Initialized
INFO - 2022-05-08 13:19:13 --> Language Class Initialized
INFO - 2022-05-08 13:19:13 --> Language Class Initialized
INFO - 2022-05-08 13:19:13 --> Config Class Initialized
INFO - 2022-05-08 13:19:13 --> Loader Class Initialized
INFO - 2022-05-08 13:19:13 --> Helper loaded: url_helper
INFO - 2022-05-08 13:19:13 --> Database Driver Class Initialized
INFO - 2022-05-08 13:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:19:13 --> Controller Class Initialized
DEBUG - 2022-05-08 13:19:13 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:19:13 --> Model Class Initialized
DEBUG - 2022-05-08 13:19:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:19:13 --> Model Class Initialized
DEBUG - 2022-05-08 13:19:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:19:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
ERROR - 2022-05-08 13:19:13 --> Severity: Notice --> Undefined variable: b N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_model.php 45
ERROR - 2022-05-08 13:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() N:\Xampp\htdocs\motodeal\application\modules\admin\views\add_model.php 45
DEBUG - 2022-05-08 13:19:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:19:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:19:13 --> Final output sent to browser
DEBUG - 2022-05-08 13:19:13 --> Total execution time: 0.0382
INFO - 2022-05-08 13:21:05 --> Config Class Initialized
INFO - 2022-05-08 13:21:05 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:21:05 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:21:05 --> Utf8 Class Initialized
INFO - 2022-05-08 13:21:05 --> URI Class Initialized
INFO - 2022-05-08 13:21:05 --> Router Class Initialized
INFO - 2022-05-08 13:21:05 --> Output Class Initialized
INFO - 2022-05-08 13:21:05 --> Security Class Initialized
DEBUG - 2022-05-08 13:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:21:05 --> Input Class Initialized
INFO - 2022-05-08 13:21:05 --> Language Class Initialized
INFO - 2022-05-08 13:21:05 --> Language Class Initialized
INFO - 2022-05-08 13:21:05 --> Config Class Initialized
INFO - 2022-05-08 13:21:05 --> Loader Class Initialized
INFO - 2022-05-08 13:21:05 --> Helper loaded: url_helper
INFO - 2022-05-08 13:21:05 --> Database Driver Class Initialized
INFO - 2022-05-08 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:21:05 --> Controller Class Initialized
DEBUG - 2022-05-08 13:21:05 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:21:05 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:21:05 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:21:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:21:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:21:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:21:05 --> Final output sent to browser
DEBUG - 2022-05-08 13:21:05 --> Total execution time: 0.0402
INFO - 2022-05-08 13:21:12 --> Config Class Initialized
INFO - 2022-05-08 13:21:12 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:21:12 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:21:12 --> Utf8 Class Initialized
INFO - 2022-05-08 13:21:12 --> URI Class Initialized
INFO - 2022-05-08 13:21:12 --> Router Class Initialized
INFO - 2022-05-08 13:21:12 --> Output Class Initialized
INFO - 2022-05-08 13:21:12 --> Security Class Initialized
DEBUG - 2022-05-08 13:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:21:12 --> Input Class Initialized
INFO - 2022-05-08 13:21:12 --> Language Class Initialized
INFO - 2022-05-08 13:21:12 --> Language Class Initialized
INFO - 2022-05-08 13:21:12 --> Config Class Initialized
INFO - 2022-05-08 13:21:12 --> Loader Class Initialized
INFO - 2022-05-08 13:21:12 --> Helper loaded: url_helper
INFO - 2022-05-08 13:21:12 --> Database Driver Class Initialized
INFO - 2022-05-08 13:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:21:12 --> Controller Class Initialized
DEBUG - 2022-05-08 13:21:12 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:21:12 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:21:12 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:21:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:21:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:21:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:21:12 --> Final output sent to browser
DEBUG - 2022-05-08 13:21:12 --> Total execution time: 0.0398
INFO - 2022-05-08 13:21:45 --> Config Class Initialized
INFO - 2022-05-08 13:21:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:21:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:21:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:21:45 --> URI Class Initialized
INFO - 2022-05-08 13:21:45 --> Router Class Initialized
INFO - 2022-05-08 13:21:45 --> Output Class Initialized
INFO - 2022-05-08 13:21:45 --> Security Class Initialized
DEBUG - 2022-05-08 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:21:45 --> Input Class Initialized
INFO - 2022-05-08 13:21:45 --> Language Class Initialized
INFO - 2022-05-08 13:21:45 --> Language Class Initialized
INFO - 2022-05-08 13:21:45 --> Config Class Initialized
INFO - 2022-05-08 13:21:45 --> Loader Class Initialized
INFO - 2022-05-08 13:21:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:21:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:21:45 --> Controller Class Initialized
DEBUG - 2022-05-08 13:21:45 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:21:45 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:21:45 --> Model Class Initialized
INFO - 2022-05-08 13:21:45 --> Upload Class Initialized
INFO - 2022-05-08 13:21:47 --> Config Class Initialized
INFO - 2022-05-08 13:21:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:21:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:21:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:21:47 --> URI Class Initialized
INFO - 2022-05-08 13:21:47 --> Router Class Initialized
INFO - 2022-05-08 13:21:47 --> Output Class Initialized
INFO - 2022-05-08 13:21:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:21:47 --> Input Class Initialized
INFO - 2022-05-08 13:21:47 --> Language Class Initialized
INFO - 2022-05-08 13:21:47 --> Language Class Initialized
INFO - 2022-05-08 13:21:47 --> Config Class Initialized
INFO - 2022-05-08 13:21:47 --> Loader Class Initialized
INFO - 2022-05-08 13:21:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:21:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:21:47 --> Controller Class Initialized
DEBUG - 2022-05-08 13:21:47 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:21:47 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:21:47 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:21:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:21:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:21:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:21:47 --> Final output sent to browser
DEBUG - 2022-05-08 13:21:47 --> Total execution time: 0.0372
INFO - 2022-05-08 13:21:51 --> Config Class Initialized
INFO - 2022-05-08 13:21:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:21:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:21:51 --> Utf8 Class Initialized
INFO - 2022-05-08 13:21:51 --> URI Class Initialized
INFO - 2022-05-08 13:21:51 --> Router Class Initialized
INFO - 2022-05-08 13:21:51 --> Output Class Initialized
INFO - 2022-05-08 13:21:51 --> Security Class Initialized
DEBUG - 2022-05-08 13:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:21:51 --> Input Class Initialized
INFO - 2022-05-08 13:21:51 --> Language Class Initialized
INFO - 2022-05-08 13:21:51 --> Language Class Initialized
INFO - 2022-05-08 13:21:51 --> Config Class Initialized
INFO - 2022-05-08 13:21:51 --> Loader Class Initialized
INFO - 2022-05-08 13:21:51 --> Helper loaded: url_helper
INFO - 2022-05-08 13:21:51 --> Database Driver Class Initialized
INFO - 2022-05-08 13:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:21:51 --> Controller Class Initialized
DEBUG - 2022-05-08 13:21:51 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:21:51 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:21:51 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:21:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:21:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:21:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:21:51 --> Final output sent to browser
DEBUG - 2022-05-08 13:21:51 --> Total execution time: 0.0363
INFO - 2022-05-08 13:21:53 --> Config Class Initialized
INFO - 2022-05-08 13:21:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:21:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:21:53 --> Utf8 Class Initialized
INFO - 2022-05-08 13:21:53 --> URI Class Initialized
INFO - 2022-05-08 13:21:53 --> Router Class Initialized
INFO - 2022-05-08 13:21:53 --> Output Class Initialized
INFO - 2022-05-08 13:21:53 --> Security Class Initialized
DEBUG - 2022-05-08 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:21:53 --> Input Class Initialized
INFO - 2022-05-08 13:21:53 --> Language Class Initialized
INFO - 2022-05-08 13:21:53 --> Language Class Initialized
INFO - 2022-05-08 13:21:53 --> Config Class Initialized
INFO - 2022-05-08 13:21:53 --> Loader Class Initialized
INFO - 2022-05-08 13:21:53 --> Helper loaded: url_helper
INFO - 2022-05-08 13:21:53 --> Database Driver Class Initialized
INFO - 2022-05-08 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:21:53 --> Controller Class Initialized
DEBUG - 2022-05-08 13:21:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:21:53 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:21:53 --> Model Class Initialized
DEBUG - 2022-05-08 13:21:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:21:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:21:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:21:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:21:53 --> Final output sent to browser
DEBUG - 2022-05-08 13:21:53 --> Total execution time: 0.0372
INFO - 2022-05-08 13:25:17 --> Config Class Initialized
INFO - 2022-05-08 13:25:17 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:25:17 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:25:17 --> Utf8 Class Initialized
INFO - 2022-05-08 13:25:17 --> URI Class Initialized
INFO - 2022-05-08 13:25:17 --> Router Class Initialized
INFO - 2022-05-08 13:25:17 --> Output Class Initialized
INFO - 2022-05-08 13:25:17 --> Security Class Initialized
DEBUG - 2022-05-08 13:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:25:17 --> Input Class Initialized
INFO - 2022-05-08 13:25:17 --> Language Class Initialized
INFO - 2022-05-08 13:25:17 --> Language Class Initialized
INFO - 2022-05-08 13:25:17 --> Config Class Initialized
INFO - 2022-05-08 13:25:17 --> Loader Class Initialized
INFO - 2022-05-08 13:25:17 --> Helper loaded: url_helper
INFO - 2022-05-08 13:25:17 --> Database Driver Class Initialized
INFO - 2022-05-08 13:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:25:17 --> Controller Class Initialized
DEBUG - 2022-05-08 13:25:17 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:25:17 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:25:17 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:25:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:25:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:25:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:25:17 --> Final output sent to browser
DEBUG - 2022-05-08 13:25:17 --> Total execution time: 0.0421
INFO - 2022-05-08 13:25:33 --> Config Class Initialized
INFO - 2022-05-08 13:25:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:25:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:25:33 --> Utf8 Class Initialized
INFO - 2022-05-08 13:25:33 --> URI Class Initialized
INFO - 2022-05-08 13:25:33 --> Router Class Initialized
INFO - 2022-05-08 13:25:33 --> Output Class Initialized
INFO - 2022-05-08 13:25:33 --> Security Class Initialized
DEBUG - 2022-05-08 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:25:33 --> Input Class Initialized
INFO - 2022-05-08 13:25:33 --> Language Class Initialized
INFO - 2022-05-08 13:25:33 --> Language Class Initialized
INFO - 2022-05-08 13:25:33 --> Config Class Initialized
INFO - 2022-05-08 13:25:33 --> Loader Class Initialized
INFO - 2022-05-08 13:25:33 --> Helper loaded: url_helper
INFO - 2022-05-08 13:25:33 --> Database Driver Class Initialized
INFO - 2022-05-08 13:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:25:33 --> Controller Class Initialized
DEBUG - 2022-05-08 13:25:33 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:25:33 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:25:33 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:25:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:25:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:25:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:25:33 --> Final output sent to browser
DEBUG - 2022-05-08 13:25:33 --> Total execution time: 0.0377
INFO - 2022-05-08 13:25:40 --> Config Class Initialized
INFO - 2022-05-08 13:25:40 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:25:40 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:25:40 --> Utf8 Class Initialized
INFO - 2022-05-08 13:25:40 --> URI Class Initialized
INFO - 2022-05-08 13:25:40 --> Router Class Initialized
INFO - 2022-05-08 13:25:40 --> Output Class Initialized
INFO - 2022-05-08 13:25:40 --> Security Class Initialized
DEBUG - 2022-05-08 13:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:25:40 --> Input Class Initialized
INFO - 2022-05-08 13:25:40 --> Language Class Initialized
INFO - 2022-05-08 13:25:40 --> Language Class Initialized
INFO - 2022-05-08 13:25:40 --> Config Class Initialized
INFO - 2022-05-08 13:25:40 --> Loader Class Initialized
INFO - 2022-05-08 13:25:40 --> Helper loaded: url_helper
INFO - 2022-05-08 13:25:40 --> Database Driver Class Initialized
INFO - 2022-05-08 13:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:25:40 --> Controller Class Initialized
DEBUG - 2022-05-08 13:25:40 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:25:40 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:25:40 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:25:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:25:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:25:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:25:40 --> Final output sent to browser
DEBUG - 2022-05-08 13:25:40 --> Total execution time: 0.0363
INFO - 2022-05-08 13:25:44 --> Config Class Initialized
INFO - 2022-05-08 13:25:44 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:25:44 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:25:44 --> Utf8 Class Initialized
INFO - 2022-05-08 13:25:44 --> URI Class Initialized
INFO - 2022-05-08 13:25:44 --> Router Class Initialized
INFO - 2022-05-08 13:25:44 --> Output Class Initialized
INFO - 2022-05-08 13:25:44 --> Security Class Initialized
DEBUG - 2022-05-08 13:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:25:44 --> Input Class Initialized
INFO - 2022-05-08 13:25:44 --> Language Class Initialized
INFO - 2022-05-08 13:25:44 --> Language Class Initialized
INFO - 2022-05-08 13:25:44 --> Config Class Initialized
INFO - 2022-05-08 13:25:44 --> Loader Class Initialized
INFO - 2022-05-08 13:25:44 --> Helper loaded: url_helper
INFO - 2022-05-08 13:25:44 --> Database Driver Class Initialized
INFO - 2022-05-08 13:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:25:44 --> Controller Class Initialized
DEBUG - 2022-05-08 13:25:44 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:25:44 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:25:44 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:25:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:25:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:25:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:25:44 --> Final output sent to browser
DEBUG - 2022-05-08 13:25:44 --> Total execution time: 0.0380
INFO - 2022-05-08 13:25:51 --> Config Class Initialized
INFO - 2022-05-08 13:25:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:25:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:25:51 --> Utf8 Class Initialized
INFO - 2022-05-08 13:25:51 --> URI Class Initialized
INFO - 2022-05-08 13:25:51 --> Router Class Initialized
INFO - 2022-05-08 13:25:51 --> Output Class Initialized
INFO - 2022-05-08 13:25:51 --> Security Class Initialized
DEBUG - 2022-05-08 13:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:25:51 --> Input Class Initialized
INFO - 2022-05-08 13:25:51 --> Language Class Initialized
INFO - 2022-05-08 13:25:51 --> Language Class Initialized
INFO - 2022-05-08 13:25:51 --> Config Class Initialized
INFO - 2022-05-08 13:25:51 --> Loader Class Initialized
INFO - 2022-05-08 13:25:51 --> Helper loaded: url_helper
INFO - 2022-05-08 13:25:51 --> Database Driver Class Initialized
INFO - 2022-05-08 13:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:25:51 --> Controller Class Initialized
DEBUG - 2022-05-08 13:25:51 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:25:51 --> Model Class Initialized
DEBUG - 2022-05-08 13:25:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:25:51 --> Model Class Initialized
INFO - 2022-05-08 13:27:54 --> Config Class Initialized
INFO - 2022-05-08 13:27:54 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:27:54 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:27:54 --> Utf8 Class Initialized
INFO - 2022-05-08 13:27:54 --> URI Class Initialized
INFO - 2022-05-08 13:27:54 --> Router Class Initialized
INFO - 2022-05-08 13:27:54 --> Output Class Initialized
INFO - 2022-05-08 13:27:54 --> Security Class Initialized
DEBUG - 2022-05-08 13:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:27:54 --> Input Class Initialized
INFO - 2022-05-08 13:27:54 --> Language Class Initialized
INFO - 2022-05-08 13:27:54 --> Language Class Initialized
INFO - 2022-05-08 13:27:54 --> Config Class Initialized
INFO - 2022-05-08 13:27:54 --> Loader Class Initialized
INFO - 2022-05-08 13:27:54 --> Helper loaded: url_helper
INFO - 2022-05-08 13:27:54 --> Database Driver Class Initialized
INFO - 2022-05-08 13:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:27:54 --> Controller Class Initialized
DEBUG - 2022-05-08 13:27:54 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:27:54 --> Model Class Initialized
DEBUG - 2022-05-08 13:27:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:27:54 --> Model Class Initialized
INFO - 2022-05-08 13:27:55 --> Config Class Initialized
INFO - 2022-05-08 13:27:55 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:27:55 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:27:55 --> Utf8 Class Initialized
INFO - 2022-05-08 13:27:55 --> URI Class Initialized
INFO - 2022-05-08 13:27:55 --> Router Class Initialized
INFO - 2022-05-08 13:27:55 --> Output Class Initialized
INFO - 2022-05-08 13:27:55 --> Security Class Initialized
DEBUG - 2022-05-08 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:27:55 --> Input Class Initialized
INFO - 2022-05-08 13:27:55 --> Language Class Initialized
INFO - 2022-05-08 13:27:55 --> Language Class Initialized
INFO - 2022-05-08 13:27:55 --> Config Class Initialized
INFO - 2022-05-08 13:27:55 --> Loader Class Initialized
INFO - 2022-05-08 13:27:55 --> Helper loaded: url_helper
INFO - 2022-05-08 13:27:55 --> Database Driver Class Initialized
INFO - 2022-05-08 13:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:27:55 --> Controller Class Initialized
DEBUG - 2022-05-08 13:27:55 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:27:55 --> Model Class Initialized
DEBUG - 2022-05-08 13:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:27:55 --> Model Class Initialized
DEBUG - 2022-05-08 13:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:27:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:27:55 --> Final output sent to browser
DEBUG - 2022-05-08 13:27:55 --> Total execution time: 0.0386
INFO - 2022-05-08 13:28:01 --> Config Class Initialized
INFO - 2022-05-08 13:28:01 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:28:01 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:28:01 --> Utf8 Class Initialized
INFO - 2022-05-08 13:28:01 --> URI Class Initialized
INFO - 2022-05-08 13:28:01 --> Router Class Initialized
INFO - 2022-05-08 13:28:01 --> Output Class Initialized
INFO - 2022-05-08 13:28:01 --> Security Class Initialized
DEBUG - 2022-05-08 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:28:01 --> Input Class Initialized
INFO - 2022-05-08 13:28:01 --> Language Class Initialized
INFO - 2022-05-08 13:28:01 --> Language Class Initialized
INFO - 2022-05-08 13:28:01 --> Config Class Initialized
INFO - 2022-05-08 13:28:01 --> Loader Class Initialized
INFO - 2022-05-08 13:28:01 --> Helper loaded: url_helper
INFO - 2022-05-08 13:28:01 --> Database Driver Class Initialized
INFO - 2022-05-08 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:28:01 --> Controller Class Initialized
DEBUG - 2022-05-08 13:28:01 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:28:01 --> Model Class Initialized
DEBUG - 2022-05-08 13:28:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:28:01 --> Model Class Initialized
INFO - 2022-05-08 13:28:34 --> Config Class Initialized
INFO - 2022-05-08 13:28:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:28:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:28:34 --> Utf8 Class Initialized
INFO - 2022-05-08 13:28:34 --> URI Class Initialized
INFO - 2022-05-08 13:28:34 --> Router Class Initialized
INFO - 2022-05-08 13:28:34 --> Output Class Initialized
INFO - 2022-05-08 13:28:34 --> Security Class Initialized
DEBUG - 2022-05-08 13:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:28:34 --> Input Class Initialized
INFO - 2022-05-08 13:28:34 --> Language Class Initialized
INFO - 2022-05-08 13:28:34 --> Language Class Initialized
INFO - 2022-05-08 13:28:34 --> Config Class Initialized
INFO - 2022-05-08 13:28:34 --> Loader Class Initialized
INFO - 2022-05-08 13:28:34 --> Helper loaded: url_helper
INFO - 2022-05-08 13:28:34 --> Database Driver Class Initialized
INFO - 2022-05-08 13:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:28:34 --> Controller Class Initialized
DEBUG - 2022-05-08 13:28:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:28:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:28:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:28:34 --> Model Class Initialized
INFO - 2022-05-08 13:28:36 --> Config Class Initialized
INFO - 2022-05-08 13:28:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:28:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:28:36 --> Utf8 Class Initialized
INFO - 2022-05-08 13:28:36 --> URI Class Initialized
INFO - 2022-05-08 13:28:36 --> Router Class Initialized
INFO - 2022-05-08 13:28:36 --> Output Class Initialized
INFO - 2022-05-08 13:28:36 --> Security Class Initialized
DEBUG - 2022-05-08 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:28:36 --> Input Class Initialized
INFO - 2022-05-08 13:28:36 --> Language Class Initialized
INFO - 2022-05-08 13:28:36 --> Language Class Initialized
INFO - 2022-05-08 13:28:36 --> Config Class Initialized
INFO - 2022-05-08 13:28:36 --> Loader Class Initialized
INFO - 2022-05-08 13:28:36 --> Helper loaded: url_helper
INFO - 2022-05-08 13:28:36 --> Database Driver Class Initialized
INFO - 2022-05-08 13:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:28:36 --> Controller Class Initialized
DEBUG - 2022-05-08 13:28:36 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:28:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:28:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:28:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:28:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:28:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:28:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:28:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:28:36 --> Final output sent to browser
DEBUG - 2022-05-08 13:28:36 --> Total execution time: 0.0371
INFO - 2022-05-08 13:28:45 --> Config Class Initialized
INFO - 2022-05-08 13:28:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:28:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:28:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:28:45 --> URI Class Initialized
INFO - 2022-05-08 13:28:45 --> Router Class Initialized
INFO - 2022-05-08 13:28:45 --> Output Class Initialized
INFO - 2022-05-08 13:28:45 --> Security Class Initialized
DEBUG - 2022-05-08 13:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:28:45 --> Input Class Initialized
INFO - 2022-05-08 13:28:45 --> Language Class Initialized
INFO - 2022-05-08 13:28:45 --> Language Class Initialized
INFO - 2022-05-08 13:28:45 --> Config Class Initialized
INFO - 2022-05-08 13:28:45 --> Loader Class Initialized
INFO - 2022-05-08 13:28:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:28:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:28:45 --> Controller Class Initialized
DEBUG - 2022-05-08 13:28:45 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:28:45 --> Model Class Initialized
DEBUG - 2022-05-08 13:28:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:28:45 --> Model Class Initialized
INFO - 2022-05-08 13:29:47 --> Config Class Initialized
INFO - 2022-05-08 13:29:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:29:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:29:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:29:47 --> URI Class Initialized
INFO - 2022-05-08 13:29:47 --> Router Class Initialized
INFO - 2022-05-08 13:29:47 --> Output Class Initialized
INFO - 2022-05-08 13:29:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:29:47 --> Input Class Initialized
INFO - 2022-05-08 13:29:47 --> Language Class Initialized
INFO - 2022-05-08 13:29:47 --> Language Class Initialized
INFO - 2022-05-08 13:29:47 --> Config Class Initialized
INFO - 2022-05-08 13:29:47 --> Loader Class Initialized
INFO - 2022-05-08 13:29:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:29:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:29:47 --> Controller Class Initialized
DEBUG - 2022-05-08 13:29:47 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:29:47 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:29:47 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:29:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:29:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:29:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:29:47 --> Final output sent to browser
DEBUG - 2022-05-08 13:29:47 --> Total execution time: 0.0367
INFO - 2022-05-08 13:29:52 --> Config Class Initialized
INFO - 2022-05-08 13:29:52 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:29:52 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:29:52 --> Utf8 Class Initialized
INFO - 2022-05-08 13:29:52 --> URI Class Initialized
INFO - 2022-05-08 13:29:52 --> Router Class Initialized
INFO - 2022-05-08 13:29:52 --> Output Class Initialized
INFO - 2022-05-08 13:29:52 --> Security Class Initialized
DEBUG - 2022-05-08 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:29:52 --> Input Class Initialized
INFO - 2022-05-08 13:29:52 --> Language Class Initialized
INFO - 2022-05-08 13:29:52 --> Language Class Initialized
INFO - 2022-05-08 13:29:52 --> Config Class Initialized
INFO - 2022-05-08 13:29:52 --> Loader Class Initialized
INFO - 2022-05-08 13:29:52 --> Helper loaded: url_helper
INFO - 2022-05-08 13:29:52 --> Database Driver Class Initialized
INFO - 2022-05-08 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:29:52 --> Controller Class Initialized
DEBUG - 2022-05-08 13:29:52 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:29:52 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:29:52 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:29:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:29:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:29:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:29:52 --> Final output sent to browser
DEBUG - 2022-05-08 13:29:52 --> Total execution time: 0.0409
INFO - 2022-05-08 13:29:59 --> Config Class Initialized
INFO - 2022-05-08 13:29:59 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:29:59 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:29:59 --> Utf8 Class Initialized
INFO - 2022-05-08 13:29:59 --> URI Class Initialized
INFO - 2022-05-08 13:29:59 --> Router Class Initialized
INFO - 2022-05-08 13:29:59 --> Output Class Initialized
INFO - 2022-05-08 13:29:59 --> Security Class Initialized
DEBUG - 2022-05-08 13:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:29:59 --> Input Class Initialized
INFO - 2022-05-08 13:29:59 --> Language Class Initialized
INFO - 2022-05-08 13:29:59 --> Language Class Initialized
INFO - 2022-05-08 13:29:59 --> Config Class Initialized
INFO - 2022-05-08 13:29:59 --> Loader Class Initialized
INFO - 2022-05-08 13:29:59 --> Helper loaded: url_helper
INFO - 2022-05-08 13:29:59 --> Database Driver Class Initialized
INFO - 2022-05-08 13:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:29:59 --> Controller Class Initialized
DEBUG - 2022-05-08 13:29:59 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:29:59 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:29:59 --> Model Class Initialized
INFO - 2022-05-08 13:29:59 --> Config Class Initialized
INFO - 2022-05-08 13:29:59 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:29:59 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:29:59 --> Utf8 Class Initialized
INFO - 2022-05-08 13:29:59 --> URI Class Initialized
INFO - 2022-05-08 13:29:59 --> Router Class Initialized
INFO - 2022-05-08 13:29:59 --> Output Class Initialized
INFO - 2022-05-08 13:29:59 --> Security Class Initialized
DEBUG - 2022-05-08 13:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:29:59 --> Input Class Initialized
INFO - 2022-05-08 13:29:59 --> Language Class Initialized
INFO - 2022-05-08 13:29:59 --> Language Class Initialized
INFO - 2022-05-08 13:29:59 --> Config Class Initialized
INFO - 2022-05-08 13:29:59 --> Loader Class Initialized
INFO - 2022-05-08 13:29:59 --> Helper loaded: url_helper
INFO - 2022-05-08 13:29:59 --> Database Driver Class Initialized
INFO - 2022-05-08 13:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:29:59 --> Controller Class Initialized
DEBUG - 2022-05-08 13:29:59 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:29:59 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:29:59 --> Model Class Initialized
DEBUG - 2022-05-08 13:29:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:29:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:29:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:29:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:29:59 --> Final output sent to browser
DEBUG - 2022-05-08 13:29:59 --> Total execution time: 0.0460
INFO - 2022-05-08 13:32:22 --> Config Class Initialized
INFO - 2022-05-08 13:32:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:32:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:32:22 --> Utf8 Class Initialized
INFO - 2022-05-08 13:32:22 --> URI Class Initialized
INFO - 2022-05-08 13:32:22 --> Router Class Initialized
INFO - 2022-05-08 13:32:22 --> Output Class Initialized
INFO - 2022-05-08 13:32:22 --> Security Class Initialized
DEBUG - 2022-05-08 13:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:32:22 --> Input Class Initialized
INFO - 2022-05-08 13:32:22 --> Language Class Initialized
INFO - 2022-05-08 13:32:22 --> Language Class Initialized
INFO - 2022-05-08 13:32:22 --> Config Class Initialized
INFO - 2022-05-08 13:32:22 --> Loader Class Initialized
INFO - 2022-05-08 13:32:22 --> Helper loaded: url_helper
INFO - 2022-05-08 13:32:22 --> Database Driver Class Initialized
INFO - 2022-05-08 13:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:32:22 --> Controller Class Initialized
DEBUG - 2022-05-08 13:32:22 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:32:22 --> Model Class Initialized
DEBUG - 2022-05-08 13:32:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:32:22 --> Model Class Initialized
DEBUG - 2022-05-08 13:32:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:32:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:32:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:32:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:32:22 --> Final output sent to browser
DEBUG - 2022-05-08 13:32:22 --> Total execution time: 0.0420
INFO - 2022-05-08 13:32:24 --> Config Class Initialized
INFO - 2022-05-08 13:32:24 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:32:24 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:32:24 --> Utf8 Class Initialized
INFO - 2022-05-08 13:32:24 --> URI Class Initialized
INFO - 2022-05-08 13:32:24 --> Router Class Initialized
INFO - 2022-05-08 13:32:24 --> Output Class Initialized
INFO - 2022-05-08 13:32:24 --> Security Class Initialized
DEBUG - 2022-05-08 13:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:32:24 --> Input Class Initialized
INFO - 2022-05-08 13:32:24 --> Language Class Initialized
INFO - 2022-05-08 13:32:24 --> Language Class Initialized
INFO - 2022-05-08 13:32:24 --> Config Class Initialized
INFO - 2022-05-08 13:32:24 --> Loader Class Initialized
INFO - 2022-05-08 13:32:24 --> Helper loaded: url_helper
INFO - 2022-05-08 13:32:24 --> Database Driver Class Initialized
INFO - 2022-05-08 13:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:32:24 --> Controller Class Initialized
DEBUG - 2022-05-08 13:32:24 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:32:24 --> Model Class Initialized
DEBUG - 2022-05-08 13:32:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:32:24 --> Model Class Initialized
DEBUG - 2022-05-08 13:32:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:32:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:32:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:32:24 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:32:24 --> Final output sent to browser
DEBUG - 2022-05-08 13:32:24 --> Total execution time: 0.0351
INFO - 2022-05-08 13:33:49 --> Config Class Initialized
INFO - 2022-05-08 13:33:49 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:33:49 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:33:49 --> Utf8 Class Initialized
INFO - 2022-05-08 13:33:49 --> URI Class Initialized
INFO - 2022-05-08 13:33:49 --> Router Class Initialized
INFO - 2022-05-08 13:33:49 --> Output Class Initialized
INFO - 2022-05-08 13:33:49 --> Security Class Initialized
DEBUG - 2022-05-08 13:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:33:49 --> Input Class Initialized
INFO - 2022-05-08 13:33:49 --> Language Class Initialized
INFO - 2022-05-08 13:33:49 --> Language Class Initialized
INFO - 2022-05-08 13:33:49 --> Config Class Initialized
INFO - 2022-05-08 13:33:49 --> Loader Class Initialized
INFO - 2022-05-08 13:33:49 --> Helper loaded: url_helper
INFO - 2022-05-08 13:33:49 --> Database Driver Class Initialized
INFO - 2022-05-08 13:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:33:49 --> Controller Class Initialized
DEBUG - 2022-05-08 13:33:49 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:33:49 --> Model Class Initialized
DEBUG - 2022-05-08 13:33:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:33:49 --> Model Class Initialized
DEBUG - 2022-05-08 13:33:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:33:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:33:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:33:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:33:49 --> Final output sent to browser
DEBUG - 2022-05-08 13:33:49 --> Total execution time: 0.0361
INFO - 2022-05-08 13:34:19 --> Config Class Initialized
INFO - 2022-05-08 13:34:19 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:34:19 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:34:19 --> Utf8 Class Initialized
INFO - 2022-05-08 13:34:19 --> URI Class Initialized
INFO - 2022-05-08 13:34:19 --> Router Class Initialized
INFO - 2022-05-08 13:34:19 --> Output Class Initialized
INFO - 2022-05-08 13:34:19 --> Security Class Initialized
DEBUG - 2022-05-08 13:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:34:19 --> Input Class Initialized
INFO - 2022-05-08 13:34:19 --> Language Class Initialized
INFO - 2022-05-08 13:34:19 --> Language Class Initialized
INFO - 2022-05-08 13:34:19 --> Config Class Initialized
INFO - 2022-05-08 13:34:19 --> Loader Class Initialized
INFO - 2022-05-08 13:34:19 --> Helper loaded: url_helper
INFO - 2022-05-08 13:34:19 --> Database Driver Class Initialized
INFO - 2022-05-08 13:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:34:19 --> Controller Class Initialized
DEBUG - 2022-05-08 13:34:19 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:34:19 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:34:19 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:34:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:34:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:34:19 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:34:19 --> Final output sent to browser
DEBUG - 2022-05-08 13:34:19 --> Total execution time: 0.0366
INFO - 2022-05-08 13:34:34 --> Config Class Initialized
INFO - 2022-05-08 13:34:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:34:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:34:34 --> Utf8 Class Initialized
INFO - 2022-05-08 13:34:34 --> URI Class Initialized
INFO - 2022-05-08 13:34:34 --> Router Class Initialized
INFO - 2022-05-08 13:34:34 --> Output Class Initialized
INFO - 2022-05-08 13:34:34 --> Security Class Initialized
DEBUG - 2022-05-08 13:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:34:34 --> Input Class Initialized
INFO - 2022-05-08 13:34:34 --> Language Class Initialized
INFO - 2022-05-08 13:34:34 --> Language Class Initialized
INFO - 2022-05-08 13:34:34 --> Config Class Initialized
INFO - 2022-05-08 13:34:34 --> Loader Class Initialized
INFO - 2022-05-08 13:34:34 --> Helper loaded: url_helper
INFO - 2022-05-08 13:34:34 --> Database Driver Class Initialized
INFO - 2022-05-08 13:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:34:34 --> Controller Class Initialized
DEBUG - 2022-05-08 13:34:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:34:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:34:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:34:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:34:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:34:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:34:34 --> Final output sent to browser
DEBUG - 2022-05-08 13:34:34 --> Total execution time: 0.0382
INFO - 2022-05-08 13:34:37 --> Config Class Initialized
INFO - 2022-05-08 13:34:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:34:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:34:37 --> Utf8 Class Initialized
INFO - 2022-05-08 13:34:37 --> URI Class Initialized
INFO - 2022-05-08 13:34:37 --> Router Class Initialized
INFO - 2022-05-08 13:34:37 --> Output Class Initialized
INFO - 2022-05-08 13:34:37 --> Security Class Initialized
DEBUG - 2022-05-08 13:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:34:37 --> Input Class Initialized
INFO - 2022-05-08 13:34:37 --> Language Class Initialized
INFO - 2022-05-08 13:34:37 --> Language Class Initialized
INFO - 2022-05-08 13:34:37 --> Config Class Initialized
INFO - 2022-05-08 13:34:37 --> Loader Class Initialized
INFO - 2022-05-08 13:34:37 --> Helper loaded: url_helper
INFO - 2022-05-08 13:34:37 --> Database Driver Class Initialized
INFO - 2022-05-08 13:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:34:37 --> Controller Class Initialized
DEBUG - 2022-05-08 13:34:37 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:34:37 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:34:37 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:34:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:34:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:34:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:34:37 --> Final output sent to browser
DEBUG - 2022-05-08 13:34:37 --> Total execution time: 0.0367
INFO - 2022-05-08 13:34:41 --> Config Class Initialized
INFO - 2022-05-08 13:34:41 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:34:41 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:34:41 --> Utf8 Class Initialized
INFO - 2022-05-08 13:34:41 --> URI Class Initialized
INFO - 2022-05-08 13:34:41 --> Router Class Initialized
INFO - 2022-05-08 13:34:41 --> Output Class Initialized
INFO - 2022-05-08 13:34:41 --> Security Class Initialized
DEBUG - 2022-05-08 13:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:34:41 --> Input Class Initialized
INFO - 2022-05-08 13:34:41 --> Language Class Initialized
INFO - 2022-05-08 13:34:41 --> Language Class Initialized
INFO - 2022-05-08 13:34:41 --> Config Class Initialized
INFO - 2022-05-08 13:34:41 --> Loader Class Initialized
INFO - 2022-05-08 13:34:41 --> Helper loaded: url_helper
INFO - 2022-05-08 13:34:41 --> Database Driver Class Initialized
INFO - 2022-05-08 13:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:34:41 --> Controller Class Initialized
DEBUG - 2022-05-08 13:34:41 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:34:41 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:34:41 --> Model Class Initialized
DEBUG - 2022-05-08 13:34:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:34:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:34:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:34:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:34:41 --> Final output sent to browser
DEBUG - 2022-05-08 13:34:41 --> Total execution time: 0.0375
INFO - 2022-05-08 13:36:12 --> Config Class Initialized
INFO - 2022-05-08 13:36:12 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:36:12 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:36:12 --> Utf8 Class Initialized
INFO - 2022-05-08 13:36:12 --> URI Class Initialized
INFO - 2022-05-08 13:36:12 --> Router Class Initialized
INFO - 2022-05-08 13:36:12 --> Output Class Initialized
INFO - 2022-05-08 13:36:12 --> Security Class Initialized
DEBUG - 2022-05-08 13:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:36:12 --> Input Class Initialized
INFO - 2022-05-08 13:36:12 --> Language Class Initialized
INFO - 2022-05-08 13:36:12 --> Language Class Initialized
INFO - 2022-05-08 13:36:12 --> Config Class Initialized
INFO - 2022-05-08 13:36:12 --> Loader Class Initialized
INFO - 2022-05-08 13:36:12 --> Helper loaded: url_helper
INFO - 2022-05-08 13:36:12 --> Database Driver Class Initialized
INFO - 2022-05-08 13:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:36:12 --> Controller Class Initialized
DEBUG - 2022-05-08 13:36:12 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:36:12 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:36:12 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:36:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:36:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:36:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:36:12 --> Final output sent to browser
DEBUG - 2022-05-08 13:36:12 --> Total execution time: 0.0397
INFO - 2022-05-08 13:36:20 --> Config Class Initialized
INFO - 2022-05-08 13:36:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:36:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:36:20 --> Utf8 Class Initialized
INFO - 2022-05-08 13:36:20 --> URI Class Initialized
INFO - 2022-05-08 13:36:20 --> Router Class Initialized
INFO - 2022-05-08 13:36:20 --> Output Class Initialized
INFO - 2022-05-08 13:36:20 --> Security Class Initialized
DEBUG - 2022-05-08 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:36:20 --> Input Class Initialized
INFO - 2022-05-08 13:36:20 --> Language Class Initialized
INFO - 2022-05-08 13:36:20 --> Language Class Initialized
INFO - 2022-05-08 13:36:20 --> Config Class Initialized
INFO - 2022-05-08 13:36:20 --> Loader Class Initialized
INFO - 2022-05-08 13:36:20 --> Helper loaded: url_helper
INFO - 2022-05-08 13:36:20 --> Database Driver Class Initialized
INFO - 2022-05-08 13:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:36:20 --> Controller Class Initialized
DEBUG - 2022-05-08 13:36:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:36:20 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:36:20 --> Model Class Initialized
ERROR - 2022-05-08 13:36:20 --> Query error: Unknown column 't_name' in 'field list' - Invalid query: INSERT INTO `bodytype` (`t_name`) VALUES ('bt 1')
INFO - 2022-05-08 13:36:21 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-08 13:36:48 --> Config Class Initialized
INFO - 2022-05-08 13:36:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:36:49 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:36:49 --> Utf8 Class Initialized
INFO - 2022-05-08 13:36:49 --> URI Class Initialized
INFO - 2022-05-08 13:36:49 --> Router Class Initialized
INFO - 2022-05-08 13:36:49 --> Output Class Initialized
INFO - 2022-05-08 13:36:49 --> Security Class Initialized
DEBUG - 2022-05-08 13:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:36:49 --> Input Class Initialized
INFO - 2022-05-08 13:36:49 --> Language Class Initialized
INFO - 2022-05-08 13:36:49 --> Language Class Initialized
INFO - 2022-05-08 13:36:49 --> Config Class Initialized
INFO - 2022-05-08 13:36:49 --> Loader Class Initialized
INFO - 2022-05-08 13:36:49 --> Helper loaded: url_helper
INFO - 2022-05-08 13:36:49 --> Database Driver Class Initialized
INFO - 2022-05-08 13:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:36:49 --> Controller Class Initialized
DEBUG - 2022-05-08 13:36:49 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:36:49 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:36:49 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:36:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:36:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:36:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:36:49 --> Final output sent to browser
DEBUG - 2022-05-08 13:36:49 --> Total execution time: 0.0381
INFO - 2022-05-08 13:36:51 --> Config Class Initialized
INFO - 2022-05-08 13:36:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:36:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:36:51 --> Utf8 Class Initialized
INFO - 2022-05-08 13:36:51 --> URI Class Initialized
INFO - 2022-05-08 13:36:51 --> Router Class Initialized
INFO - 2022-05-08 13:36:51 --> Output Class Initialized
INFO - 2022-05-08 13:36:51 --> Security Class Initialized
DEBUG - 2022-05-08 13:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:36:51 --> Input Class Initialized
INFO - 2022-05-08 13:36:51 --> Language Class Initialized
INFO - 2022-05-08 13:36:51 --> Language Class Initialized
INFO - 2022-05-08 13:36:51 --> Config Class Initialized
INFO - 2022-05-08 13:36:51 --> Loader Class Initialized
INFO - 2022-05-08 13:36:51 --> Helper loaded: url_helper
INFO - 2022-05-08 13:36:51 --> Database Driver Class Initialized
INFO - 2022-05-08 13:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:36:51 --> Controller Class Initialized
DEBUG - 2022-05-08 13:36:51 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:36:51 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:36:51 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:36:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:36:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:36:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:36:51 --> Final output sent to browser
DEBUG - 2022-05-08 13:36:51 --> Total execution time: 0.0866
INFO - 2022-05-08 13:36:56 --> Config Class Initialized
INFO - 2022-05-08 13:36:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:36:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:36:56 --> Utf8 Class Initialized
INFO - 2022-05-08 13:36:56 --> URI Class Initialized
INFO - 2022-05-08 13:36:56 --> Router Class Initialized
INFO - 2022-05-08 13:36:56 --> Output Class Initialized
INFO - 2022-05-08 13:36:56 --> Security Class Initialized
DEBUG - 2022-05-08 13:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:36:56 --> Input Class Initialized
INFO - 2022-05-08 13:36:56 --> Language Class Initialized
INFO - 2022-05-08 13:36:56 --> Language Class Initialized
INFO - 2022-05-08 13:36:56 --> Config Class Initialized
INFO - 2022-05-08 13:36:56 --> Loader Class Initialized
INFO - 2022-05-08 13:36:56 --> Helper loaded: url_helper
INFO - 2022-05-08 13:36:56 --> Database Driver Class Initialized
INFO - 2022-05-08 13:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:36:56 --> Controller Class Initialized
DEBUG - 2022-05-08 13:36:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:36:56 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:36:56 --> Model Class Initialized
INFO - 2022-05-08 13:36:56 --> Config Class Initialized
INFO - 2022-05-08 13:36:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:36:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:36:56 --> Utf8 Class Initialized
INFO - 2022-05-08 13:36:56 --> URI Class Initialized
INFO - 2022-05-08 13:36:56 --> Router Class Initialized
INFO - 2022-05-08 13:36:56 --> Output Class Initialized
INFO - 2022-05-08 13:36:56 --> Security Class Initialized
DEBUG - 2022-05-08 13:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:36:56 --> Input Class Initialized
INFO - 2022-05-08 13:36:56 --> Language Class Initialized
INFO - 2022-05-08 13:36:56 --> Language Class Initialized
INFO - 2022-05-08 13:36:56 --> Config Class Initialized
INFO - 2022-05-08 13:36:56 --> Loader Class Initialized
INFO - 2022-05-08 13:36:56 --> Helper loaded: url_helper
INFO - 2022-05-08 13:36:56 --> Database Driver Class Initialized
INFO - 2022-05-08 13:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:36:56 --> Controller Class Initialized
DEBUG - 2022-05-08 13:36:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:36:56 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:36:56 --> Model Class Initialized
DEBUG - 2022-05-08 13:36:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:36:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:36:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:36:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:36:56 --> Final output sent to browser
DEBUG - 2022-05-08 13:36:56 --> Total execution time: 0.0420
INFO - 2022-05-08 13:40:01 --> Config Class Initialized
INFO - 2022-05-08 13:40:01 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:40:01 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:40:01 --> Utf8 Class Initialized
INFO - 2022-05-08 13:40:01 --> URI Class Initialized
INFO - 2022-05-08 13:40:01 --> Router Class Initialized
INFO - 2022-05-08 13:40:01 --> Output Class Initialized
INFO - 2022-05-08 13:40:01 --> Security Class Initialized
DEBUG - 2022-05-08 13:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:40:01 --> Input Class Initialized
INFO - 2022-05-08 13:40:01 --> Language Class Initialized
INFO - 2022-05-08 13:40:01 --> Language Class Initialized
INFO - 2022-05-08 13:40:01 --> Config Class Initialized
INFO - 2022-05-08 13:40:01 --> Loader Class Initialized
INFO - 2022-05-08 13:40:01 --> Helper loaded: url_helper
INFO - 2022-05-08 13:40:01 --> Database Driver Class Initialized
INFO - 2022-05-08 13:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:40:01 --> Controller Class Initialized
DEBUG - 2022-05-08 13:40:01 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:40:01 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:40:01 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:40:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:40:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:40:01 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:40:01 --> Final output sent to browser
DEBUG - 2022-05-08 13:40:01 --> Total execution time: 0.0289
INFO - 2022-05-08 13:40:05 --> Config Class Initialized
INFO - 2022-05-08 13:40:05 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:40:05 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:40:05 --> Utf8 Class Initialized
INFO - 2022-05-08 13:40:05 --> URI Class Initialized
INFO - 2022-05-08 13:40:05 --> Router Class Initialized
INFO - 2022-05-08 13:40:05 --> Output Class Initialized
INFO - 2022-05-08 13:40:05 --> Security Class Initialized
DEBUG - 2022-05-08 13:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:40:05 --> Input Class Initialized
INFO - 2022-05-08 13:40:05 --> Language Class Initialized
INFO - 2022-05-08 13:40:05 --> Language Class Initialized
INFO - 2022-05-08 13:40:05 --> Config Class Initialized
INFO - 2022-05-08 13:40:05 --> Loader Class Initialized
INFO - 2022-05-08 13:40:05 --> Helper loaded: url_helper
INFO - 2022-05-08 13:40:05 --> Database Driver Class Initialized
INFO - 2022-05-08 13:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:40:05 --> Controller Class Initialized
ERROR - 2022-05-08 13:40:05 --> 404 Page Not Found: ../modules/admin/controllers/Admin/add_vehicle_color
INFO - 2022-05-08 13:40:33 --> Config Class Initialized
INFO - 2022-05-08 13:40:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:40:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:40:33 --> Utf8 Class Initialized
INFO - 2022-05-08 13:40:33 --> URI Class Initialized
INFO - 2022-05-08 13:40:33 --> Router Class Initialized
INFO - 2022-05-08 13:40:33 --> Output Class Initialized
INFO - 2022-05-08 13:40:33 --> Security Class Initialized
DEBUG - 2022-05-08 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:40:33 --> Input Class Initialized
INFO - 2022-05-08 13:40:33 --> Language Class Initialized
INFO - 2022-05-08 13:40:33 --> Language Class Initialized
INFO - 2022-05-08 13:40:33 --> Config Class Initialized
INFO - 2022-05-08 13:40:33 --> Loader Class Initialized
INFO - 2022-05-08 13:40:33 --> Helper loaded: url_helper
INFO - 2022-05-08 13:40:33 --> Database Driver Class Initialized
INFO - 2022-05-08 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:40:33 --> Controller Class Initialized
DEBUG - 2022-05-08 13:40:33 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:40:33 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:40:33 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:40:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:40:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:40:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:40:33 --> Final output sent to browser
DEBUG - 2022-05-08 13:40:33 --> Total execution time: 0.0367
INFO - 2022-05-08 13:40:34 --> Config Class Initialized
INFO - 2022-05-08 13:40:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:40:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:40:34 --> Utf8 Class Initialized
INFO - 2022-05-08 13:40:34 --> URI Class Initialized
INFO - 2022-05-08 13:40:34 --> Router Class Initialized
INFO - 2022-05-08 13:40:34 --> Output Class Initialized
INFO - 2022-05-08 13:40:34 --> Security Class Initialized
DEBUG - 2022-05-08 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:40:34 --> Input Class Initialized
INFO - 2022-05-08 13:40:34 --> Language Class Initialized
INFO - 2022-05-08 13:40:34 --> Language Class Initialized
INFO - 2022-05-08 13:40:34 --> Config Class Initialized
INFO - 2022-05-08 13:40:34 --> Loader Class Initialized
INFO - 2022-05-08 13:40:34 --> Helper loaded: url_helper
INFO - 2022-05-08 13:40:34 --> Database Driver Class Initialized
INFO - 2022-05-08 13:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:40:34 --> Controller Class Initialized
DEBUG - 2022-05-08 13:40:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:40:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:40:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:40:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:40:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:40:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:40:34 --> Final output sent to browser
DEBUG - 2022-05-08 13:40:34 --> Total execution time: 0.0352
INFO - 2022-05-08 13:40:36 --> Config Class Initialized
INFO - 2022-05-08 13:40:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:40:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:40:36 --> Utf8 Class Initialized
INFO - 2022-05-08 13:40:36 --> URI Class Initialized
INFO - 2022-05-08 13:40:36 --> Router Class Initialized
INFO - 2022-05-08 13:40:36 --> Output Class Initialized
INFO - 2022-05-08 13:40:36 --> Security Class Initialized
DEBUG - 2022-05-08 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:40:36 --> Input Class Initialized
INFO - 2022-05-08 13:40:36 --> Language Class Initialized
INFO - 2022-05-08 13:40:36 --> Language Class Initialized
INFO - 2022-05-08 13:40:36 --> Config Class Initialized
INFO - 2022-05-08 13:40:36 --> Loader Class Initialized
INFO - 2022-05-08 13:40:36 --> Helper loaded: url_helper
INFO - 2022-05-08 13:40:36 --> Database Driver Class Initialized
INFO - 2022-05-08 13:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:40:36 --> Controller Class Initialized
DEBUG - 2022-05-08 13:40:36 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:40:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:40:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:40:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:40:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:40:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-08 13:40:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:40:36 --> Final output sent to browser
DEBUG - 2022-05-08 13:40:36 --> Total execution time: 0.0363
INFO - 2022-05-08 13:41:27 --> Config Class Initialized
INFO - 2022-05-08 13:41:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:41:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:41:27 --> Utf8 Class Initialized
INFO - 2022-05-08 13:41:27 --> URI Class Initialized
INFO - 2022-05-08 13:41:27 --> Router Class Initialized
INFO - 2022-05-08 13:41:27 --> Output Class Initialized
INFO - 2022-05-08 13:41:27 --> Security Class Initialized
DEBUG - 2022-05-08 13:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:41:27 --> Input Class Initialized
INFO - 2022-05-08 13:41:27 --> Language Class Initialized
INFO - 2022-05-08 13:41:27 --> Language Class Initialized
INFO - 2022-05-08 13:41:27 --> Config Class Initialized
INFO - 2022-05-08 13:41:27 --> Loader Class Initialized
INFO - 2022-05-08 13:41:27 --> Helper loaded: url_helper
INFO - 2022-05-08 13:41:27 --> Database Driver Class Initialized
INFO - 2022-05-08 13:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:41:27 --> Controller Class Initialized
DEBUG - 2022-05-08 13:41:27 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:41:27 --> Model Class Initialized
DEBUG - 2022-05-08 13:41:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:41:27 --> Model Class Initialized
DEBUG - 2022-05-08 13:41:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:41:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:41:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-08 13:41:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:41:27 --> Final output sent to browser
DEBUG - 2022-05-08 13:41:27 --> Total execution time: 0.0278
INFO - 2022-05-08 13:41:34 --> Config Class Initialized
INFO - 2022-05-08 13:41:34 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:41:34 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:41:34 --> Utf8 Class Initialized
INFO - 2022-05-08 13:41:34 --> URI Class Initialized
INFO - 2022-05-08 13:41:34 --> Router Class Initialized
INFO - 2022-05-08 13:41:34 --> Output Class Initialized
INFO - 2022-05-08 13:41:34 --> Security Class Initialized
DEBUG - 2022-05-08 13:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:41:34 --> Input Class Initialized
INFO - 2022-05-08 13:41:34 --> Language Class Initialized
INFO - 2022-05-08 13:41:34 --> Language Class Initialized
INFO - 2022-05-08 13:41:34 --> Config Class Initialized
INFO - 2022-05-08 13:41:34 --> Loader Class Initialized
INFO - 2022-05-08 13:41:34 --> Helper loaded: url_helper
INFO - 2022-05-08 13:41:34 --> Database Driver Class Initialized
INFO - 2022-05-08 13:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:41:34 --> Controller Class Initialized
DEBUG - 2022-05-08 13:41:34 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:41:34 --> Model Class Initialized
DEBUG - 2022-05-08 13:41:34 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:41:34 --> Model Class Initialized
INFO - 2022-05-08 13:41:36 --> Config Class Initialized
INFO - 2022-05-08 13:41:36 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:41:36 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:41:36 --> Utf8 Class Initialized
INFO - 2022-05-08 13:41:36 --> URI Class Initialized
INFO - 2022-05-08 13:41:36 --> Router Class Initialized
INFO - 2022-05-08 13:41:36 --> Output Class Initialized
INFO - 2022-05-08 13:41:36 --> Security Class Initialized
DEBUG - 2022-05-08 13:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:41:36 --> Input Class Initialized
INFO - 2022-05-08 13:41:36 --> Language Class Initialized
INFO - 2022-05-08 13:41:36 --> Language Class Initialized
INFO - 2022-05-08 13:41:36 --> Config Class Initialized
INFO - 2022-05-08 13:41:36 --> Loader Class Initialized
INFO - 2022-05-08 13:41:36 --> Helper loaded: url_helper
INFO - 2022-05-08 13:41:36 --> Database Driver Class Initialized
INFO - 2022-05-08 13:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:41:36 --> Controller Class Initialized
DEBUG - 2022-05-08 13:41:36 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:41:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:41:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:41:36 --> Model Class Initialized
DEBUG - 2022-05-08 13:41:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:41:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:41:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-08 13:41:36 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:41:36 --> Final output sent to browser
DEBUG - 2022-05-08 13:41:36 --> Total execution time: 0.0359
INFO - 2022-05-08 13:42:40 --> Config Class Initialized
INFO - 2022-05-08 13:42:40 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:42:40 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:42:40 --> Utf8 Class Initialized
INFO - 2022-05-08 13:42:40 --> URI Class Initialized
INFO - 2022-05-08 13:42:40 --> Router Class Initialized
INFO - 2022-05-08 13:42:40 --> Output Class Initialized
INFO - 2022-05-08 13:42:40 --> Security Class Initialized
DEBUG - 2022-05-08 13:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:42:40 --> Input Class Initialized
INFO - 2022-05-08 13:42:40 --> Language Class Initialized
INFO - 2022-05-08 13:42:40 --> Language Class Initialized
INFO - 2022-05-08 13:42:40 --> Config Class Initialized
INFO - 2022-05-08 13:42:40 --> Loader Class Initialized
INFO - 2022-05-08 13:42:40 --> Helper loaded: url_helper
INFO - 2022-05-08 13:42:40 --> Database Driver Class Initialized
INFO - 2022-05-08 13:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:42:40 --> Controller Class Initialized
DEBUG - 2022-05-08 13:42:40 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:42:40 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:42:40 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:42:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:42:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 13:42:40 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:42:40 --> Final output sent to browser
DEBUG - 2022-05-08 13:42:40 --> Total execution time: 0.0368
INFO - 2022-05-08 13:42:43 --> Config Class Initialized
INFO - 2022-05-08 13:42:43 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:42:43 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:42:43 --> Utf8 Class Initialized
INFO - 2022-05-08 13:42:43 --> URI Class Initialized
INFO - 2022-05-08 13:42:43 --> Router Class Initialized
INFO - 2022-05-08 13:42:43 --> Output Class Initialized
INFO - 2022-05-08 13:42:43 --> Security Class Initialized
DEBUG - 2022-05-08 13:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:42:43 --> Input Class Initialized
INFO - 2022-05-08 13:42:43 --> Language Class Initialized
INFO - 2022-05-08 13:42:43 --> Language Class Initialized
INFO - 2022-05-08 13:42:43 --> Config Class Initialized
INFO - 2022-05-08 13:42:43 --> Loader Class Initialized
INFO - 2022-05-08 13:42:43 --> Helper loaded: url_helper
INFO - 2022-05-08 13:42:43 --> Database Driver Class Initialized
INFO - 2022-05-08 13:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:42:43 --> Controller Class Initialized
DEBUG - 2022-05-08 13:42:43 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:42:43 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:42:43 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:42:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:42:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:42:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:42:43 --> Final output sent to browser
DEBUG - 2022-05-08 13:42:43 --> Total execution time: 0.0362
INFO - 2022-05-08 13:42:45 --> Config Class Initialized
INFO - 2022-05-08 13:42:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:42:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:42:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:42:45 --> URI Class Initialized
INFO - 2022-05-08 13:42:45 --> Router Class Initialized
INFO - 2022-05-08 13:42:45 --> Output Class Initialized
INFO - 2022-05-08 13:42:45 --> Security Class Initialized
DEBUG - 2022-05-08 13:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:42:45 --> Input Class Initialized
INFO - 2022-05-08 13:42:45 --> Language Class Initialized
INFO - 2022-05-08 13:42:45 --> Language Class Initialized
INFO - 2022-05-08 13:42:45 --> Config Class Initialized
INFO - 2022-05-08 13:42:45 --> Loader Class Initialized
INFO - 2022-05-08 13:42:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:42:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:42:45 --> Controller Class Initialized
DEBUG - 2022-05-08 13:42:45 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:42:45 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:42:45 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:42:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:42:45 --> Final output sent to browser
DEBUG - 2022-05-08 13:42:45 --> Total execution time: 0.0374
INFO - 2022-05-08 13:42:48 --> Config Class Initialized
INFO - 2022-05-08 13:42:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:42:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:42:48 --> Utf8 Class Initialized
INFO - 2022-05-08 13:42:48 --> URI Class Initialized
INFO - 2022-05-08 13:42:48 --> Router Class Initialized
INFO - 2022-05-08 13:42:48 --> Output Class Initialized
INFO - 2022-05-08 13:42:48 --> Security Class Initialized
DEBUG - 2022-05-08 13:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:42:48 --> Input Class Initialized
INFO - 2022-05-08 13:42:48 --> Language Class Initialized
INFO - 2022-05-08 13:42:48 --> Language Class Initialized
INFO - 2022-05-08 13:42:48 --> Config Class Initialized
INFO - 2022-05-08 13:42:48 --> Loader Class Initialized
INFO - 2022-05-08 13:42:48 --> Helper loaded: url_helper
INFO - 2022-05-08 13:42:48 --> Database Driver Class Initialized
INFO - 2022-05-08 13:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:42:48 --> Controller Class Initialized
DEBUG - 2022-05-08 13:42:48 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:42:48 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:42:48 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:42:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:42:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:42:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:42:48 --> Final output sent to browser
DEBUG - 2022-05-08 13:42:48 --> Total execution time: 0.0376
INFO - 2022-05-08 13:42:50 --> Config Class Initialized
INFO - 2022-05-08 13:42:50 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:42:50 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:42:50 --> Utf8 Class Initialized
INFO - 2022-05-08 13:42:50 --> URI Class Initialized
INFO - 2022-05-08 13:42:50 --> Router Class Initialized
INFO - 2022-05-08 13:42:50 --> Output Class Initialized
INFO - 2022-05-08 13:42:50 --> Security Class Initialized
DEBUG - 2022-05-08 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:42:50 --> Input Class Initialized
INFO - 2022-05-08 13:42:50 --> Language Class Initialized
INFO - 2022-05-08 13:42:50 --> Language Class Initialized
INFO - 2022-05-08 13:42:50 --> Config Class Initialized
INFO - 2022-05-08 13:42:50 --> Loader Class Initialized
INFO - 2022-05-08 13:42:50 --> Helper loaded: url_helper
INFO - 2022-05-08 13:42:50 --> Database Driver Class Initialized
INFO - 2022-05-08 13:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:42:50 --> Controller Class Initialized
DEBUG - 2022-05-08 13:42:50 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:42:50 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:42:50 --> Model Class Initialized
DEBUG - 2022-05-08 13:42:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:42:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:42:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:42:52 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:42:52 --> Final output sent to browser
DEBUG - 2022-05-08 13:42:52 --> Total execution time: 1.8772
INFO - 2022-05-08 13:45:27 --> Config Class Initialized
INFO - 2022-05-08 13:45:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:45:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:45:27 --> Utf8 Class Initialized
INFO - 2022-05-08 13:45:27 --> URI Class Initialized
INFO - 2022-05-08 13:45:27 --> Router Class Initialized
INFO - 2022-05-08 13:45:28 --> Output Class Initialized
INFO - 2022-05-08 13:45:28 --> Security Class Initialized
DEBUG - 2022-05-08 13:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:45:28 --> Input Class Initialized
INFO - 2022-05-08 13:45:28 --> Language Class Initialized
INFO - 2022-05-08 13:45:28 --> Language Class Initialized
INFO - 2022-05-08 13:45:28 --> Config Class Initialized
INFO - 2022-05-08 13:45:28 --> Loader Class Initialized
INFO - 2022-05-08 13:45:28 --> Helper loaded: url_helper
INFO - 2022-05-08 13:45:28 --> Database Driver Class Initialized
INFO - 2022-05-08 13:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:45:28 --> Controller Class Initialized
DEBUG - 2022-05-08 13:45:28 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:45:28 --> Model Class Initialized
DEBUG - 2022-05-08 13:45:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:45:28 --> Model Class Initialized
DEBUG - 2022-05-08 13:45:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:45:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:45:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:45:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:45:28 --> Final output sent to browser
DEBUG - 2022-05-08 13:45:28 --> Total execution time: 0.0371
INFO - 2022-05-08 13:45:46 --> Config Class Initialized
INFO - 2022-05-08 13:45:46 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:45:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:45:46 --> Utf8 Class Initialized
INFO - 2022-05-08 13:45:46 --> URI Class Initialized
INFO - 2022-05-08 13:45:46 --> Router Class Initialized
INFO - 2022-05-08 13:45:46 --> Output Class Initialized
INFO - 2022-05-08 13:45:46 --> Security Class Initialized
DEBUG - 2022-05-08 13:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:45:46 --> Input Class Initialized
INFO - 2022-05-08 13:45:46 --> Language Class Initialized
INFO - 2022-05-08 13:45:46 --> Language Class Initialized
INFO - 2022-05-08 13:45:46 --> Config Class Initialized
INFO - 2022-05-08 13:45:46 --> Loader Class Initialized
INFO - 2022-05-08 13:45:46 --> Helper loaded: url_helper
INFO - 2022-05-08 13:45:46 --> Database Driver Class Initialized
INFO - 2022-05-08 13:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:45:46 --> Controller Class Initialized
DEBUG - 2022-05-08 13:45:46 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:45:46 --> Model Class Initialized
DEBUG - 2022-05-08 13:45:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:45:46 --> Model Class Initialized
DEBUG - 2022-05-08 13:45:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:45:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:45:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:45:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:45:47 --> Final output sent to browser
DEBUG - 2022-05-08 13:45:47 --> Total execution time: 1.3198
INFO - 2022-05-08 13:46:04 --> Config Class Initialized
INFO - 2022-05-08 13:46:04 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:46:04 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:46:04 --> Utf8 Class Initialized
INFO - 2022-05-08 13:46:04 --> URI Class Initialized
INFO - 2022-05-08 13:46:04 --> Router Class Initialized
INFO - 2022-05-08 13:46:04 --> Output Class Initialized
INFO - 2022-05-08 13:46:04 --> Security Class Initialized
DEBUG - 2022-05-08 13:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:46:04 --> Input Class Initialized
INFO - 2022-05-08 13:46:04 --> Language Class Initialized
INFO - 2022-05-08 13:46:04 --> Language Class Initialized
INFO - 2022-05-08 13:46:04 --> Config Class Initialized
INFO - 2022-05-08 13:46:04 --> Loader Class Initialized
INFO - 2022-05-08 13:46:04 --> Helper loaded: url_helper
INFO - 2022-05-08 13:46:04 --> Database Driver Class Initialized
INFO - 2022-05-08 13:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:46:04 --> Controller Class Initialized
DEBUG - 2022-05-08 13:46:04 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:46:04 --> Model Class Initialized
DEBUG - 2022-05-08 13:46:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:46:04 --> Model Class Initialized
DEBUG - 2022-05-08 13:46:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:46:04 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:46:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:46:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:46:06 --> Final output sent to browser
DEBUG - 2022-05-08 13:46:06 --> Total execution time: 1.4692
INFO - 2022-05-08 13:46:32 --> Config Class Initialized
INFO - 2022-05-08 13:46:32 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:46:32 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:46:32 --> Utf8 Class Initialized
INFO - 2022-05-08 13:46:32 --> URI Class Initialized
INFO - 2022-05-08 13:46:32 --> Router Class Initialized
INFO - 2022-05-08 13:46:32 --> Output Class Initialized
INFO - 2022-05-08 13:46:32 --> Security Class Initialized
DEBUG - 2022-05-08 13:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:46:32 --> Input Class Initialized
INFO - 2022-05-08 13:46:32 --> Language Class Initialized
INFO - 2022-05-08 13:46:32 --> Language Class Initialized
INFO - 2022-05-08 13:46:32 --> Config Class Initialized
INFO - 2022-05-08 13:46:32 --> Loader Class Initialized
INFO - 2022-05-08 13:46:32 --> Helper loaded: url_helper
INFO - 2022-05-08 13:46:32 --> Database Driver Class Initialized
INFO - 2022-05-08 13:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:46:32 --> Controller Class Initialized
DEBUG - 2022-05-08 13:46:32 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:46:32 --> Model Class Initialized
DEBUG - 2022-05-08 13:46:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:46:32 --> Model Class Initialized
DEBUG - 2022-05-08 13:46:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:46:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:46:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:46:32 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:46:32 --> Final output sent to browser
DEBUG - 2022-05-08 13:46:32 --> Total execution time: 0.0360
INFO - 2022-05-08 13:48:27 --> Config Class Initialized
INFO - 2022-05-08 13:48:27 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:48:27 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:48:27 --> Utf8 Class Initialized
INFO - 2022-05-08 13:48:27 --> URI Class Initialized
INFO - 2022-05-08 13:48:27 --> Router Class Initialized
INFO - 2022-05-08 13:48:27 --> Output Class Initialized
INFO - 2022-05-08 13:48:27 --> Security Class Initialized
DEBUG - 2022-05-08 13:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:48:27 --> Input Class Initialized
INFO - 2022-05-08 13:48:27 --> Language Class Initialized
INFO - 2022-05-08 13:48:27 --> Language Class Initialized
INFO - 2022-05-08 13:48:27 --> Config Class Initialized
INFO - 2022-05-08 13:48:27 --> Loader Class Initialized
INFO - 2022-05-08 13:48:27 --> Helper loaded: url_helper
INFO - 2022-05-08 13:48:27 --> Database Driver Class Initialized
INFO - 2022-05-08 13:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:48:27 --> Controller Class Initialized
DEBUG - 2022-05-08 13:48:27 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:48:27 --> Model Class Initialized
DEBUG - 2022-05-08 13:48:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:48:27 --> Model Class Initialized
DEBUG - 2022-05-08 13:48:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:48:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:48:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:48:27 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:48:27 --> Final output sent to browser
DEBUG - 2022-05-08 13:48:27 --> Total execution time: 0.7332
INFO - 2022-05-08 13:48:35 --> Config Class Initialized
INFO - 2022-05-08 13:48:35 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:48:35 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:48:35 --> Utf8 Class Initialized
INFO - 2022-05-08 13:48:35 --> URI Class Initialized
INFO - 2022-05-08 13:48:35 --> Router Class Initialized
INFO - 2022-05-08 13:48:35 --> Output Class Initialized
INFO - 2022-05-08 13:48:35 --> Security Class Initialized
DEBUG - 2022-05-08 13:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:48:35 --> Input Class Initialized
INFO - 2022-05-08 13:48:35 --> Language Class Initialized
INFO - 2022-05-08 13:48:35 --> Language Class Initialized
INFO - 2022-05-08 13:48:35 --> Config Class Initialized
INFO - 2022-05-08 13:48:35 --> Loader Class Initialized
INFO - 2022-05-08 13:48:35 --> Helper loaded: url_helper
INFO - 2022-05-08 13:48:35 --> Database Driver Class Initialized
INFO - 2022-05-08 13:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:48:35 --> Controller Class Initialized
DEBUG - 2022-05-08 13:48:35 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:48:35 --> Model Class Initialized
DEBUG - 2022-05-08 13:48:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:48:35 --> Model Class Initialized
DEBUG - 2022-05-08 13:48:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:48:35 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:48:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:48:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:48:44 --> Final output sent to browser
DEBUG - 2022-05-08 13:48:44 --> Total execution time: 9.3556
INFO - 2022-05-08 13:49:28 --> Config Class Initialized
INFO - 2022-05-08 13:49:28 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:49:28 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:49:28 --> Utf8 Class Initialized
INFO - 2022-05-08 13:49:28 --> URI Class Initialized
INFO - 2022-05-08 13:49:28 --> Router Class Initialized
INFO - 2022-05-08 13:49:28 --> Output Class Initialized
INFO - 2022-05-08 13:49:28 --> Security Class Initialized
DEBUG - 2022-05-08 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:49:28 --> Input Class Initialized
INFO - 2022-05-08 13:49:28 --> Language Class Initialized
INFO - 2022-05-08 13:49:28 --> Language Class Initialized
INFO - 2022-05-08 13:49:28 --> Config Class Initialized
INFO - 2022-05-08 13:49:28 --> Loader Class Initialized
INFO - 2022-05-08 13:49:28 --> Helper loaded: url_helper
INFO - 2022-05-08 13:49:28 --> Database Driver Class Initialized
INFO - 2022-05-08 13:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:49:28 --> Controller Class Initialized
DEBUG - 2022-05-08 13:49:28 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:49:28 --> Model Class Initialized
DEBUG - 2022-05-08 13:49:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:49:28 --> Model Class Initialized
DEBUG - 2022-05-08 13:49:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:49:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:49:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:49:28 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:49:28 --> Final output sent to browser
DEBUG - 2022-05-08 13:49:28 --> Total execution time: 0.0385
INFO - 2022-05-08 13:49:50 --> Config Class Initialized
INFO - 2022-05-08 13:49:50 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:49:50 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:49:50 --> Utf8 Class Initialized
INFO - 2022-05-08 13:49:50 --> URI Class Initialized
INFO - 2022-05-08 13:49:50 --> Router Class Initialized
INFO - 2022-05-08 13:49:50 --> Output Class Initialized
INFO - 2022-05-08 13:49:50 --> Security Class Initialized
DEBUG - 2022-05-08 13:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:49:50 --> Input Class Initialized
INFO - 2022-05-08 13:49:50 --> Language Class Initialized
INFO - 2022-05-08 13:49:50 --> Language Class Initialized
INFO - 2022-05-08 13:49:50 --> Config Class Initialized
INFO - 2022-05-08 13:49:50 --> Loader Class Initialized
INFO - 2022-05-08 13:49:50 --> Helper loaded: url_helper
INFO - 2022-05-08 13:49:50 --> Database Driver Class Initialized
INFO - 2022-05-08 13:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:49:50 --> Controller Class Initialized
DEBUG - 2022-05-08 13:49:50 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:49:50 --> Model Class Initialized
DEBUG - 2022-05-08 13:49:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:49:50 --> Model Class Initialized
DEBUG - 2022-05-08 13:49:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:49:50 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:49:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:49:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:49:53 --> Final output sent to browser
DEBUG - 2022-05-08 13:49:53 --> Total execution time: 3.2762
INFO - 2022-05-08 13:50:03 --> Config Class Initialized
INFO - 2022-05-08 13:50:03 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:50:03 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:50:03 --> Utf8 Class Initialized
INFO - 2022-05-08 13:50:03 --> URI Class Initialized
INFO - 2022-05-08 13:50:03 --> Router Class Initialized
INFO - 2022-05-08 13:50:03 --> Output Class Initialized
INFO - 2022-05-08 13:50:03 --> Security Class Initialized
DEBUG - 2022-05-08 13:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:50:03 --> Input Class Initialized
INFO - 2022-05-08 13:50:03 --> Language Class Initialized
INFO - 2022-05-08 13:50:03 --> Language Class Initialized
INFO - 2022-05-08 13:50:03 --> Config Class Initialized
INFO - 2022-05-08 13:50:03 --> Loader Class Initialized
INFO - 2022-05-08 13:50:03 --> Helper loaded: url_helper
INFO - 2022-05-08 13:50:03 --> Database Driver Class Initialized
INFO - 2022-05-08 13:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:50:03 --> Controller Class Initialized
DEBUG - 2022-05-08 13:50:03 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:50:03 --> Model Class Initialized
DEBUG - 2022-05-08 13:50:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:50:03 --> Model Class Initialized
DEBUG - 2022-05-08 13:50:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:50:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:50:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 13:50:03 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:50:03 --> Final output sent to browser
DEBUG - 2022-05-08 13:50:03 --> Total execution time: 0.0373
INFO - 2022-05-08 13:50:06 --> Config Class Initialized
INFO - 2022-05-08 13:50:06 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:50:06 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:50:06 --> Utf8 Class Initialized
INFO - 2022-05-08 13:50:06 --> URI Class Initialized
INFO - 2022-05-08 13:50:06 --> Router Class Initialized
INFO - 2022-05-08 13:50:06 --> Output Class Initialized
INFO - 2022-05-08 13:50:06 --> Security Class Initialized
DEBUG - 2022-05-08 13:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:50:06 --> Input Class Initialized
INFO - 2022-05-08 13:50:06 --> Language Class Initialized
INFO - 2022-05-08 13:50:06 --> Language Class Initialized
INFO - 2022-05-08 13:50:06 --> Config Class Initialized
INFO - 2022-05-08 13:50:06 --> Loader Class Initialized
INFO - 2022-05-08 13:50:06 --> Helper loaded: url_helper
INFO - 2022-05-08 13:50:06 --> Database Driver Class Initialized
INFO - 2022-05-08 13:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:50:06 --> Controller Class Initialized
DEBUG - 2022-05-08 13:50:06 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:50:06 --> Model Class Initialized
DEBUG - 2022-05-08 13:50:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:50:06 --> Model Class Initialized
DEBUG - 2022-05-08 13:50:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:50:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:50:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 13:50:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:50:06 --> Final output sent to browser
DEBUG - 2022-05-08 13:50:06 --> Total execution time: 0.0276
INFO - 2022-05-08 13:52:11 --> Config Class Initialized
INFO - 2022-05-08 13:52:11 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:52:11 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:52:11 --> Utf8 Class Initialized
INFO - 2022-05-08 13:52:11 --> URI Class Initialized
INFO - 2022-05-08 13:52:11 --> Router Class Initialized
INFO - 2022-05-08 13:52:11 --> Output Class Initialized
INFO - 2022-05-08 13:52:11 --> Security Class Initialized
DEBUG - 2022-05-08 13:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:52:11 --> Input Class Initialized
INFO - 2022-05-08 13:52:11 --> Language Class Initialized
INFO - 2022-05-08 13:52:11 --> Language Class Initialized
INFO - 2022-05-08 13:52:11 --> Config Class Initialized
INFO - 2022-05-08 13:52:11 --> Loader Class Initialized
INFO - 2022-05-08 13:52:11 --> Helper loaded: url_helper
INFO - 2022-05-08 13:52:11 --> Database Driver Class Initialized
INFO - 2022-05-08 13:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:52:11 --> Controller Class Initialized
DEBUG - 2022-05-08 13:52:11 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:52:11 --> Model Class Initialized
DEBUG - 2022-05-08 13:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:52:11 --> Model Class Initialized
DEBUG - 2022-05-08 13:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 13:52:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:52:11 --> Final output sent to browser
DEBUG - 2022-05-08 13:52:11 --> Total execution time: 0.0311
INFO - 2022-05-08 13:52:18 --> Config Class Initialized
INFO - 2022-05-08 13:52:18 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:52:18 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:52:18 --> Utf8 Class Initialized
INFO - 2022-05-08 13:52:18 --> URI Class Initialized
INFO - 2022-05-08 13:52:18 --> Router Class Initialized
INFO - 2022-05-08 13:52:18 --> Output Class Initialized
INFO - 2022-05-08 13:52:18 --> Security Class Initialized
DEBUG - 2022-05-08 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:52:18 --> Input Class Initialized
INFO - 2022-05-08 13:52:18 --> Language Class Initialized
INFO - 2022-05-08 13:52:18 --> Language Class Initialized
INFO - 2022-05-08 13:52:18 --> Config Class Initialized
INFO - 2022-05-08 13:52:18 --> Loader Class Initialized
INFO - 2022-05-08 13:52:18 --> Helper loaded: url_helper
INFO - 2022-05-08 13:52:18 --> Database Driver Class Initialized
INFO - 2022-05-08 13:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:52:18 --> Controller Class Initialized
DEBUG - 2022-05-08 13:52:18 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:52:18 --> Model Class Initialized
DEBUG - 2022-05-08 13:52:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:52:18 --> Model Class Initialized
DEBUG - 2022-05-08 13:52:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:52:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:52:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-08 13:52:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:52:18 --> Final output sent to browser
DEBUG - 2022-05-08 13:52:18 --> Total execution time: 0.0380
INFO - 2022-05-08 13:52:20 --> Config Class Initialized
INFO - 2022-05-08 13:52:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:52:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:52:20 --> Utf8 Class Initialized
INFO - 2022-05-08 13:52:20 --> URI Class Initialized
INFO - 2022-05-08 13:52:20 --> Router Class Initialized
INFO - 2022-05-08 13:52:20 --> Output Class Initialized
INFO - 2022-05-08 13:52:20 --> Security Class Initialized
DEBUG - 2022-05-08 13:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:52:20 --> Input Class Initialized
INFO - 2022-05-08 13:52:20 --> Language Class Initialized
INFO - 2022-05-08 13:52:20 --> Language Class Initialized
INFO - 2022-05-08 13:52:20 --> Config Class Initialized
INFO - 2022-05-08 13:52:20 --> Loader Class Initialized
INFO - 2022-05-08 13:52:20 --> Helper loaded: url_helper
INFO - 2022-05-08 13:52:20 --> Database Driver Class Initialized
INFO - 2022-05-08 13:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:52:20 --> Controller Class Initialized
DEBUG - 2022-05-08 13:52:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:52:20 --> Model Class Initialized
DEBUG - 2022-05-08 13:52:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:52:20 --> Model Class Initialized
DEBUG - 2022-05-08 13:52:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:52:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:52:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:52:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:52:20 --> Final output sent to browser
DEBUG - 2022-05-08 13:52:20 --> Total execution time: 0.0359
INFO - 2022-05-08 13:54:22 --> Config Class Initialized
INFO - 2022-05-08 13:54:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:54:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:54:22 --> Utf8 Class Initialized
INFO - 2022-05-08 13:54:22 --> URI Class Initialized
INFO - 2022-05-08 13:54:22 --> Router Class Initialized
INFO - 2022-05-08 13:54:22 --> Output Class Initialized
INFO - 2022-05-08 13:54:22 --> Security Class Initialized
DEBUG - 2022-05-08 13:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:54:22 --> Input Class Initialized
INFO - 2022-05-08 13:54:22 --> Language Class Initialized
INFO - 2022-05-08 13:54:22 --> Language Class Initialized
INFO - 2022-05-08 13:54:22 --> Config Class Initialized
INFO - 2022-05-08 13:54:22 --> Loader Class Initialized
INFO - 2022-05-08 13:54:22 --> Helper loaded: url_helper
INFO - 2022-05-08 13:54:22 --> Database Driver Class Initialized
INFO - 2022-05-08 13:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:54:22 --> Controller Class Initialized
DEBUG - 2022-05-08 13:54:22 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:54:22 --> Model Class Initialized
DEBUG - 2022-05-08 13:54:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:54:22 --> Model Class Initialized
DEBUG - 2022-05-08 13:54:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:54:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:54:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:54:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:54:22 --> Final output sent to browser
DEBUG - 2022-05-08 13:54:22 --> Total execution time: 0.0376
INFO - 2022-05-08 13:54:38 --> Config Class Initialized
INFO - 2022-05-08 13:54:38 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:54:38 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:54:38 --> Utf8 Class Initialized
INFO - 2022-05-08 13:54:38 --> URI Class Initialized
INFO - 2022-05-08 13:54:38 --> Router Class Initialized
INFO - 2022-05-08 13:54:38 --> Output Class Initialized
INFO - 2022-05-08 13:54:38 --> Security Class Initialized
DEBUG - 2022-05-08 13:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:54:38 --> Input Class Initialized
INFO - 2022-05-08 13:54:38 --> Language Class Initialized
INFO - 2022-05-08 13:54:38 --> Language Class Initialized
INFO - 2022-05-08 13:54:38 --> Config Class Initialized
INFO - 2022-05-08 13:54:38 --> Loader Class Initialized
INFO - 2022-05-08 13:54:38 --> Helper loaded: url_helper
INFO - 2022-05-08 13:54:38 --> Database Driver Class Initialized
INFO - 2022-05-08 13:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:54:38 --> Controller Class Initialized
DEBUG - 2022-05-08 13:54:38 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:54:38 --> Model Class Initialized
DEBUG - 2022-05-08 13:54:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:54:38 --> Model Class Initialized
DEBUG - 2022-05-08 13:54:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:54:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:54:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:54:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:54:38 --> Final output sent to browser
DEBUG - 2022-05-08 13:54:38 --> Total execution time: 0.0415
INFO - 2022-05-08 13:54:53 --> Config Class Initialized
INFO - 2022-05-08 13:54:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:54:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:54:53 --> Utf8 Class Initialized
INFO - 2022-05-08 13:54:53 --> URI Class Initialized
INFO - 2022-05-08 13:54:53 --> Router Class Initialized
INFO - 2022-05-08 13:54:53 --> Output Class Initialized
INFO - 2022-05-08 13:54:53 --> Security Class Initialized
DEBUG - 2022-05-08 13:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:54:53 --> Input Class Initialized
INFO - 2022-05-08 13:54:53 --> Language Class Initialized
INFO - 2022-05-08 13:54:53 --> Language Class Initialized
INFO - 2022-05-08 13:54:53 --> Config Class Initialized
INFO - 2022-05-08 13:54:53 --> Loader Class Initialized
INFO - 2022-05-08 13:54:53 --> Helper loaded: url_helper
INFO - 2022-05-08 13:54:53 --> Database Driver Class Initialized
INFO - 2022-05-08 13:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:54:53 --> Controller Class Initialized
DEBUG - 2022-05-08 13:54:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:54:53 --> Model Class Initialized
DEBUG - 2022-05-08 13:54:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:54:53 --> Model Class Initialized
DEBUG - 2022-05-08 13:54:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:54:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:54:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:54:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:54:53 --> Final output sent to browser
DEBUG - 2022-05-08 13:54:53 --> Total execution time: 0.0411
INFO - 2022-05-08 13:55:09 --> Config Class Initialized
INFO - 2022-05-08 13:55:09 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:55:09 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:55:09 --> Utf8 Class Initialized
INFO - 2022-05-08 13:55:09 --> URI Class Initialized
INFO - 2022-05-08 13:55:09 --> Router Class Initialized
INFO - 2022-05-08 13:55:09 --> Output Class Initialized
INFO - 2022-05-08 13:55:09 --> Security Class Initialized
DEBUG - 2022-05-08 13:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:55:09 --> Input Class Initialized
INFO - 2022-05-08 13:55:09 --> Language Class Initialized
INFO - 2022-05-08 13:55:09 --> Language Class Initialized
INFO - 2022-05-08 13:55:09 --> Config Class Initialized
INFO - 2022-05-08 13:55:09 --> Loader Class Initialized
INFO - 2022-05-08 13:55:09 --> Helper loaded: url_helper
INFO - 2022-05-08 13:55:09 --> Database Driver Class Initialized
INFO - 2022-05-08 13:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:55:09 --> Controller Class Initialized
DEBUG - 2022-05-08 13:55:09 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:55:09 --> Model Class Initialized
DEBUG - 2022-05-08 13:55:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:55:09 --> Model Class Initialized
DEBUG - 2022-05-08 13:55:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:55:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:55:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:55:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:55:09 --> Final output sent to browser
DEBUG - 2022-05-08 13:55:09 --> Total execution time: 0.0408
INFO - 2022-05-08 13:55:17 --> Config Class Initialized
INFO - 2022-05-08 13:55:17 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:55:17 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:55:17 --> Utf8 Class Initialized
INFO - 2022-05-08 13:55:17 --> URI Class Initialized
INFO - 2022-05-08 13:55:17 --> Router Class Initialized
INFO - 2022-05-08 13:55:17 --> Output Class Initialized
INFO - 2022-05-08 13:55:17 --> Security Class Initialized
DEBUG - 2022-05-08 13:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:55:17 --> Input Class Initialized
INFO - 2022-05-08 13:55:17 --> Language Class Initialized
INFO - 2022-05-08 13:55:17 --> Language Class Initialized
INFO - 2022-05-08 13:55:17 --> Config Class Initialized
INFO - 2022-05-08 13:55:17 --> Loader Class Initialized
INFO - 2022-05-08 13:55:17 --> Helper loaded: url_helper
INFO - 2022-05-08 13:55:17 --> Database Driver Class Initialized
INFO - 2022-05-08 13:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:55:17 --> Controller Class Initialized
DEBUG - 2022-05-08 13:55:17 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:55:17 --> Model Class Initialized
DEBUG - 2022-05-08 13:55:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:55:17 --> Model Class Initialized
DEBUG - 2022-05-08 13:55:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:55:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:55:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:55:17 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:55:17 --> Final output sent to browser
DEBUG - 2022-05-08 13:55:17 --> Total execution time: 0.0381
INFO - 2022-05-08 13:57:07 --> Config Class Initialized
INFO - 2022-05-08 13:57:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:57:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:57:07 --> Utf8 Class Initialized
INFO - 2022-05-08 13:57:07 --> URI Class Initialized
INFO - 2022-05-08 13:57:07 --> Router Class Initialized
INFO - 2022-05-08 13:57:07 --> Output Class Initialized
INFO - 2022-05-08 13:57:07 --> Security Class Initialized
DEBUG - 2022-05-08 13:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:57:07 --> Input Class Initialized
INFO - 2022-05-08 13:57:07 --> Language Class Initialized
INFO - 2022-05-08 13:57:07 --> Language Class Initialized
INFO - 2022-05-08 13:57:07 --> Config Class Initialized
INFO - 2022-05-08 13:57:07 --> Loader Class Initialized
INFO - 2022-05-08 13:57:07 --> Helper loaded: url_helper
INFO - 2022-05-08 13:57:07 --> Database Driver Class Initialized
INFO - 2022-05-08 13:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:57:07 --> Controller Class Initialized
DEBUG - 2022-05-08 13:57:07 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:57:07 --> Model Class Initialized
DEBUG - 2022-05-08 13:57:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:57:07 --> Model Class Initialized
DEBUG - 2022-05-08 13:57:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:57:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:57:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:57:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:57:07 --> Final output sent to browser
DEBUG - 2022-05-08 13:57:07 --> Total execution time: 0.0285
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Admin MX_Controller Initialized
INFO - 2022-05-08 13:58:45 --> Model Class Initialized
DEBUG - 2022-05-08 13:58:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 13:58:45 --> Model Class Initialized
DEBUG - 2022-05-08 13:58:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 13:58:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 13:58:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 13:58:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 13:58:45 --> Final output sent to browser
DEBUG - 2022-05-08 13:58:45 --> Total execution time: 0.0291
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 13:58:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> URI Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
INFO - 2022-05-08 13:58:45 --> Router Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Output Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Security Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
DEBUG - 2022-05-08 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:45 --> Input Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Language Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Config Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Loader Class Initialized
INFO - 2022-05-08 13:58:45 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:45 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:46 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:46 --> Config Class Initialized
INFO - 2022-05-08 13:58:46 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:46 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
DEBUG - 2022-05-08 13:58:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:46 --> Config Class Initialized
INFO - 2022-05-08 13:58:46 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:46 --> Hooks Class Initialized
INFO - 2022-05-08 13:58:46 --> URI Class Initialized
DEBUG - 2022-05-08 13:58:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:46 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:46 --> Router Class Initialized
INFO - 2022-05-08 13:58:46 --> URI Class Initialized
INFO - 2022-05-08 13:58:46 --> Output Class Initialized
INFO - 2022-05-08 13:58:46 --> Security Class Initialized
INFO - 2022-05-08 13:58:46 --> Router Class Initialized
DEBUG - 2022-05-08 13:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:46 --> Input Class Initialized
INFO - 2022-05-08 13:58:46 --> Output Class Initialized
INFO - 2022-05-08 13:58:46 --> Language Class Initialized
INFO - 2022-05-08 13:58:46 --> Security Class Initialized
INFO - 2022-05-08 13:58:46 --> Language Class Initialized
DEBUG - 2022-05-08 13:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:46 --> Config Class Initialized
INFO - 2022-05-08 13:58:46 --> Input Class Initialized
INFO - 2022-05-08 13:58:46 --> Language Class Initialized
INFO - 2022-05-08 13:58:46 --> Language Class Initialized
INFO - 2022-05-08 13:58:46 --> Loader Class Initialized
INFO - 2022-05-08 13:58:46 --> Config Class Initialized
INFO - 2022-05-08 13:58:46 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:46 --> Loader Class Initialized
INFO - 2022-05-08 13:58:46 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:46 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:46 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:46 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:46 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 13:58:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 13:58:47 --> Utf8 Class Initialized
INFO - 2022-05-08 13:58:47 --> URI Class Initialized
INFO - 2022-05-08 13:58:47 --> Router Class Initialized
INFO - 2022-05-08 13:58:47 --> Output Class Initialized
INFO - 2022-05-08 13:58:47 --> Security Class Initialized
DEBUG - 2022-05-08 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 13:58:47 --> Input Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Language Class Initialized
INFO - 2022-05-08 13:58:47 --> Config Class Initialized
INFO - 2022-05-08 13:58:47 --> Loader Class Initialized
INFO - 2022-05-08 13:58:47 --> Helper loaded: url_helper
INFO - 2022-05-08 13:58:47 --> Database Driver Class Initialized
INFO - 2022-05-08 13:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 13:58:47 --> Controller Class Initialized
ERROR - 2022-05-08 13:58:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/dist
INFO - 2022-05-08 14:00:00 --> Config Class Initialized
INFO - 2022-05-08 14:00:00 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:00:00 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:00:00 --> Utf8 Class Initialized
INFO - 2022-05-08 14:00:00 --> URI Class Initialized
INFO - 2022-05-08 14:00:00 --> Router Class Initialized
INFO - 2022-05-08 14:00:00 --> Output Class Initialized
INFO - 2022-05-08 14:00:00 --> Security Class Initialized
DEBUG - 2022-05-08 14:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:00:00 --> Input Class Initialized
INFO - 2022-05-08 14:00:00 --> Language Class Initialized
INFO - 2022-05-08 14:00:00 --> Language Class Initialized
INFO - 2022-05-08 14:00:00 --> Config Class Initialized
INFO - 2022-05-08 14:00:00 --> Loader Class Initialized
INFO - 2022-05-08 14:00:00 --> Helper loaded: url_helper
INFO - 2022-05-08 14:00:00 --> Database Driver Class Initialized
INFO - 2022-05-08 14:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:00:00 --> Controller Class Initialized
DEBUG - 2022-05-08 14:00:00 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:00:00 --> Model Class Initialized
DEBUG - 2022-05-08 14:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:00:00 --> Model Class Initialized
DEBUG - 2022-05-08 14:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:00:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:00:00 --> Final output sent to browser
DEBUG - 2022-05-08 14:00:00 --> Total execution time: 0.0494
INFO - 2022-05-08 14:03:13 --> Config Class Initialized
INFO - 2022-05-08 14:03:13 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:03:13 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:03:13 --> Utf8 Class Initialized
INFO - 2022-05-08 14:03:13 --> URI Class Initialized
INFO - 2022-05-08 14:03:13 --> Router Class Initialized
INFO - 2022-05-08 14:03:13 --> Output Class Initialized
INFO - 2022-05-08 14:03:13 --> Security Class Initialized
DEBUG - 2022-05-08 14:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:03:13 --> Input Class Initialized
INFO - 2022-05-08 14:03:13 --> Language Class Initialized
INFO - 2022-05-08 14:03:13 --> Language Class Initialized
INFO - 2022-05-08 14:03:13 --> Config Class Initialized
INFO - 2022-05-08 14:03:13 --> Loader Class Initialized
INFO - 2022-05-08 14:03:13 --> Helper loaded: url_helper
INFO - 2022-05-08 14:03:13 --> Database Driver Class Initialized
INFO - 2022-05-08 14:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:03:13 --> Controller Class Initialized
DEBUG - 2022-05-08 14:03:13 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:03:13 --> Model Class Initialized
DEBUG - 2022-05-08 14:03:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:03:13 --> Model Class Initialized
DEBUG - 2022-05-08 14:03:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:03:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:03:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:03:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:03:13 --> Final output sent to browser
DEBUG - 2022-05-08 14:03:13 --> Total execution time: 0.0284
INFO - 2022-05-08 14:07:12 --> Config Class Initialized
INFO - 2022-05-08 14:07:12 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:07:12 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:07:12 --> Utf8 Class Initialized
INFO - 2022-05-08 14:07:12 --> URI Class Initialized
INFO - 2022-05-08 14:07:12 --> Router Class Initialized
INFO - 2022-05-08 14:07:12 --> Output Class Initialized
INFO - 2022-05-08 14:07:12 --> Security Class Initialized
DEBUG - 2022-05-08 14:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:07:12 --> Input Class Initialized
INFO - 2022-05-08 14:07:12 --> Language Class Initialized
INFO - 2022-05-08 14:07:12 --> Language Class Initialized
INFO - 2022-05-08 14:07:12 --> Config Class Initialized
INFO - 2022-05-08 14:07:12 --> Loader Class Initialized
INFO - 2022-05-08 14:07:12 --> Helper loaded: url_helper
INFO - 2022-05-08 14:07:12 --> Database Driver Class Initialized
INFO - 2022-05-08 14:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:07:12 --> Controller Class Initialized
DEBUG - 2022-05-08 14:07:12 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:07:12 --> Model Class Initialized
DEBUG - 2022-05-08 14:07:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:07:12 --> Model Class Initialized
DEBUG - 2022-05-08 14:07:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:07:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:07:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:07:12 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:07:12 --> Final output sent to browser
DEBUG - 2022-05-08 14:07:12 --> Total execution time: 0.0279
INFO - 2022-05-08 14:07:29 --> Config Class Initialized
INFO - 2022-05-08 14:07:29 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:07:29 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:07:29 --> Utf8 Class Initialized
INFO - 2022-05-08 14:07:29 --> URI Class Initialized
INFO - 2022-05-08 14:07:29 --> Router Class Initialized
INFO - 2022-05-08 14:07:29 --> Output Class Initialized
INFO - 2022-05-08 14:07:29 --> Security Class Initialized
DEBUG - 2022-05-08 14:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:07:29 --> Input Class Initialized
INFO - 2022-05-08 14:07:29 --> Language Class Initialized
INFO - 2022-05-08 14:07:29 --> Language Class Initialized
INFO - 2022-05-08 14:07:29 --> Config Class Initialized
INFO - 2022-05-08 14:07:29 --> Loader Class Initialized
INFO - 2022-05-08 14:07:29 --> Helper loaded: url_helper
INFO - 2022-05-08 14:07:29 --> Database Driver Class Initialized
INFO - 2022-05-08 14:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:07:29 --> Controller Class Initialized
DEBUG - 2022-05-08 14:07:29 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:07:29 --> Model Class Initialized
DEBUG - 2022-05-08 14:07:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:07:29 --> Model Class Initialized
DEBUG - 2022-05-08 14:07:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:07:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:07:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:07:29 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:07:29 --> Final output sent to browser
DEBUG - 2022-05-08 14:07:29 --> Total execution time: 0.0357
INFO - 2022-05-08 14:08:10 --> Config Class Initialized
INFO - 2022-05-08 14:08:10 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:08:10 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:08:10 --> Utf8 Class Initialized
INFO - 2022-05-08 14:08:10 --> URI Class Initialized
INFO - 2022-05-08 14:08:10 --> Router Class Initialized
INFO - 2022-05-08 14:08:10 --> Output Class Initialized
INFO - 2022-05-08 14:08:10 --> Security Class Initialized
DEBUG - 2022-05-08 14:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:08:10 --> Input Class Initialized
INFO - 2022-05-08 14:08:10 --> Language Class Initialized
INFO - 2022-05-08 14:08:10 --> Language Class Initialized
INFO - 2022-05-08 14:08:10 --> Config Class Initialized
INFO - 2022-05-08 14:08:10 --> Loader Class Initialized
INFO - 2022-05-08 14:08:10 --> Helper loaded: url_helper
INFO - 2022-05-08 14:08:10 --> Database Driver Class Initialized
INFO - 2022-05-08 14:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:08:10 --> Controller Class Initialized
DEBUG - 2022-05-08 14:08:10 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:08:10 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:08:10 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:08:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:08:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:08:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:08:10 --> Final output sent to browser
DEBUG - 2022-05-08 14:08:10 --> Total execution time: 0.0402
INFO - 2022-05-08 14:08:20 --> Config Class Initialized
INFO - 2022-05-08 14:08:20 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:08:20 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:08:20 --> Utf8 Class Initialized
INFO - 2022-05-08 14:08:20 --> URI Class Initialized
INFO - 2022-05-08 14:08:20 --> Router Class Initialized
INFO - 2022-05-08 14:08:20 --> Output Class Initialized
INFO - 2022-05-08 14:08:20 --> Security Class Initialized
DEBUG - 2022-05-08 14:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:08:20 --> Input Class Initialized
INFO - 2022-05-08 14:08:20 --> Language Class Initialized
INFO - 2022-05-08 14:08:20 --> Language Class Initialized
INFO - 2022-05-08 14:08:20 --> Config Class Initialized
INFO - 2022-05-08 14:08:20 --> Loader Class Initialized
INFO - 2022-05-08 14:08:20 --> Helper loaded: url_helper
INFO - 2022-05-08 14:08:20 --> Database Driver Class Initialized
INFO - 2022-05-08 14:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:08:20 --> Controller Class Initialized
DEBUG - 2022-05-08 14:08:20 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:08:20 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:08:20 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:08:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:08:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:08:20 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:08:20 --> Final output sent to browser
DEBUG - 2022-05-08 14:08:20 --> Total execution time: 0.0376
INFO - 2022-05-08 14:08:39 --> Config Class Initialized
INFO - 2022-05-08 14:08:39 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:08:39 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:08:39 --> Utf8 Class Initialized
INFO - 2022-05-08 14:08:39 --> URI Class Initialized
INFO - 2022-05-08 14:08:39 --> Router Class Initialized
INFO - 2022-05-08 14:08:39 --> Output Class Initialized
INFO - 2022-05-08 14:08:39 --> Security Class Initialized
DEBUG - 2022-05-08 14:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:08:39 --> Input Class Initialized
INFO - 2022-05-08 14:08:39 --> Language Class Initialized
INFO - 2022-05-08 14:08:39 --> Language Class Initialized
INFO - 2022-05-08 14:08:39 --> Config Class Initialized
INFO - 2022-05-08 14:08:39 --> Loader Class Initialized
INFO - 2022-05-08 14:08:39 --> Helper loaded: url_helper
INFO - 2022-05-08 14:08:39 --> Database Driver Class Initialized
INFO - 2022-05-08 14:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:08:39 --> Controller Class Initialized
DEBUG - 2022-05-08 14:08:39 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:08:39 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:08:39 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:08:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:08:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:08:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:08:39 --> Final output sent to browser
DEBUG - 2022-05-08 14:08:39 --> Total execution time: 0.0381
INFO - 2022-05-08 14:08:51 --> Config Class Initialized
INFO - 2022-05-08 14:08:51 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:08:51 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:08:51 --> Utf8 Class Initialized
INFO - 2022-05-08 14:08:51 --> URI Class Initialized
INFO - 2022-05-08 14:08:51 --> Router Class Initialized
INFO - 2022-05-08 14:08:51 --> Output Class Initialized
INFO - 2022-05-08 14:08:51 --> Security Class Initialized
DEBUG - 2022-05-08 14:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:08:51 --> Input Class Initialized
INFO - 2022-05-08 14:08:51 --> Language Class Initialized
INFO - 2022-05-08 14:08:51 --> Language Class Initialized
INFO - 2022-05-08 14:08:51 --> Config Class Initialized
INFO - 2022-05-08 14:08:51 --> Loader Class Initialized
INFO - 2022-05-08 14:08:51 --> Helper loaded: url_helper
INFO - 2022-05-08 14:08:51 --> Database Driver Class Initialized
INFO - 2022-05-08 14:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:08:51 --> Controller Class Initialized
DEBUG - 2022-05-08 14:08:51 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:08:51 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:08:51 --> Model Class Initialized
DEBUG - 2022-05-08 14:08:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:08:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:08:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:08:51 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:08:51 --> Final output sent to browser
DEBUG - 2022-05-08 14:08:51 --> Total execution time: 0.0384
INFO - 2022-05-08 14:09:05 --> Config Class Initialized
INFO - 2022-05-08 14:09:05 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:09:05 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:09:05 --> Utf8 Class Initialized
INFO - 2022-05-08 14:09:05 --> URI Class Initialized
INFO - 2022-05-08 14:09:06 --> Router Class Initialized
INFO - 2022-05-08 14:09:06 --> Output Class Initialized
INFO - 2022-05-08 14:09:06 --> Security Class Initialized
DEBUG - 2022-05-08 14:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:09:06 --> Input Class Initialized
INFO - 2022-05-08 14:09:06 --> Language Class Initialized
INFO - 2022-05-08 14:09:06 --> Language Class Initialized
INFO - 2022-05-08 14:09:06 --> Config Class Initialized
INFO - 2022-05-08 14:09:06 --> Loader Class Initialized
INFO - 2022-05-08 14:09:06 --> Helper loaded: url_helper
INFO - 2022-05-08 14:09:06 --> Database Driver Class Initialized
INFO - 2022-05-08 14:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:09:06 --> Controller Class Initialized
DEBUG - 2022-05-08 14:09:06 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:09:06 --> Model Class Initialized
DEBUG - 2022-05-08 14:09:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:09:06 --> Model Class Initialized
DEBUG - 2022-05-08 14:09:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:09:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:09:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:09:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:09:06 --> Final output sent to browser
DEBUG - 2022-05-08 14:09:06 --> Total execution time: 0.0361
INFO - 2022-05-08 14:09:22 --> Config Class Initialized
INFO - 2022-05-08 14:09:22 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:09:22 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:09:22 --> Utf8 Class Initialized
INFO - 2022-05-08 14:09:22 --> URI Class Initialized
INFO - 2022-05-08 14:09:22 --> Router Class Initialized
INFO - 2022-05-08 14:09:22 --> Output Class Initialized
INFO - 2022-05-08 14:09:22 --> Security Class Initialized
DEBUG - 2022-05-08 14:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:09:22 --> Input Class Initialized
INFO - 2022-05-08 14:09:22 --> Language Class Initialized
INFO - 2022-05-08 14:09:22 --> Language Class Initialized
INFO - 2022-05-08 14:09:22 --> Config Class Initialized
INFO - 2022-05-08 14:09:22 --> Loader Class Initialized
INFO - 2022-05-08 14:09:22 --> Helper loaded: url_helper
INFO - 2022-05-08 14:09:22 --> Database Driver Class Initialized
INFO - 2022-05-08 14:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:09:22 --> Controller Class Initialized
DEBUG - 2022-05-08 14:09:22 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:09:22 --> Model Class Initialized
DEBUG - 2022-05-08 14:09:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:09:22 --> Model Class Initialized
DEBUG - 2022-05-08 14:09:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:09:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:09:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:09:22 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:09:22 --> Final output sent to browser
DEBUG - 2022-05-08 14:09:22 --> Total execution time: 0.0386
INFO - 2022-05-08 14:10:06 --> Config Class Initialized
INFO - 2022-05-08 14:10:06 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:10:06 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:10:06 --> Utf8 Class Initialized
INFO - 2022-05-08 14:10:06 --> URI Class Initialized
INFO - 2022-05-08 14:10:06 --> Router Class Initialized
INFO - 2022-05-08 14:10:06 --> Output Class Initialized
INFO - 2022-05-08 14:10:06 --> Security Class Initialized
DEBUG - 2022-05-08 14:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:10:06 --> Input Class Initialized
INFO - 2022-05-08 14:10:06 --> Language Class Initialized
INFO - 2022-05-08 14:10:06 --> Language Class Initialized
INFO - 2022-05-08 14:10:06 --> Config Class Initialized
INFO - 2022-05-08 14:10:06 --> Loader Class Initialized
INFO - 2022-05-08 14:10:06 --> Helper loaded: url_helper
INFO - 2022-05-08 14:10:06 --> Database Driver Class Initialized
INFO - 2022-05-08 14:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:10:06 --> Controller Class Initialized
DEBUG - 2022-05-08 14:10:06 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:10:06 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:10:06 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:10:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:10:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:10:06 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:10:06 --> Final output sent to browser
DEBUG - 2022-05-08 14:10:06 --> Total execution time: 0.0583
INFO - 2022-05-08 14:10:45 --> Config Class Initialized
INFO - 2022-05-08 14:10:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:10:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:10:45 --> Utf8 Class Initialized
INFO - 2022-05-08 14:10:45 --> URI Class Initialized
DEBUG - 2022-05-08 14:10:45 --> No URI present. Default controller set.
INFO - 2022-05-08 14:10:45 --> Router Class Initialized
INFO - 2022-05-08 14:10:45 --> Output Class Initialized
INFO - 2022-05-08 14:10:45 --> Security Class Initialized
DEBUG - 2022-05-08 14:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:10:45 --> Input Class Initialized
INFO - 2022-05-08 14:10:45 --> Language Class Initialized
INFO - 2022-05-08 14:10:45 --> Language Class Initialized
INFO - 2022-05-08 14:10:45 --> Config Class Initialized
INFO - 2022-05-08 14:10:45 --> Loader Class Initialized
INFO - 2022-05-08 14:10:45 --> Helper loaded: url_helper
INFO - 2022-05-08 14:10:45 --> Database Driver Class Initialized
INFO - 2022-05-08 14:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:10:45 --> Controller Class Initialized
DEBUG - 2022-05-08 14:10:45 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:10:45 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:10:45 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/login.php
INFO - 2022-05-08 14:10:45 --> Final output sent to browser
DEBUG - 2022-05-08 14:10:45 --> Total execution time: 0.0861
INFO - 2022-05-08 14:10:53 --> Config Class Initialized
INFO - 2022-05-08 14:10:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:10:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:10:53 --> Utf8 Class Initialized
INFO - 2022-05-08 14:10:53 --> URI Class Initialized
INFO - 2022-05-08 14:10:53 --> Router Class Initialized
INFO - 2022-05-08 14:10:53 --> Output Class Initialized
INFO - 2022-05-08 14:10:53 --> Security Class Initialized
DEBUG - 2022-05-08 14:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:10:53 --> Input Class Initialized
INFO - 2022-05-08 14:10:53 --> Language Class Initialized
INFO - 2022-05-08 14:10:53 --> Language Class Initialized
INFO - 2022-05-08 14:10:53 --> Config Class Initialized
INFO - 2022-05-08 14:10:53 --> Loader Class Initialized
INFO - 2022-05-08 14:10:53 --> Helper loaded: url_helper
INFO - 2022-05-08 14:10:53 --> Database Driver Class Initialized
INFO - 2022-05-08 14:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:10:53 --> Controller Class Initialized
DEBUG - 2022-05-08 14:10:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:10:53 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:10:53 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:10:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:10:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 14:10:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:10:53 --> Final output sent to browser
DEBUG - 2022-05-08 14:10:53 --> Total execution time: 0.2587
INFO - 2022-05-08 14:10:55 --> Config Class Initialized
INFO - 2022-05-08 14:10:55 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:10:55 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:10:55 --> Utf8 Class Initialized
INFO - 2022-05-08 14:10:55 --> URI Class Initialized
INFO - 2022-05-08 14:10:55 --> Router Class Initialized
INFO - 2022-05-08 14:10:55 --> Output Class Initialized
INFO - 2022-05-08 14:10:55 --> Security Class Initialized
DEBUG - 2022-05-08 14:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:10:55 --> Input Class Initialized
INFO - 2022-05-08 14:10:55 --> Language Class Initialized
INFO - 2022-05-08 14:10:55 --> Language Class Initialized
INFO - 2022-05-08 14:10:55 --> Config Class Initialized
INFO - 2022-05-08 14:10:56 --> Loader Class Initialized
INFO - 2022-05-08 14:10:56 --> Helper loaded: url_helper
INFO - 2022-05-08 14:10:56 --> Database Driver Class Initialized
INFO - 2022-05-08 14:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:10:56 --> Controller Class Initialized
DEBUG - 2022-05-08 14:10:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:10:56 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:10:56 --> Model Class Initialized
DEBUG - 2022-05-08 14:10:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:10:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:10:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:10:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:10:56 --> Final output sent to browser
DEBUG - 2022-05-08 14:10:56 --> Total execution time: 0.0362
INFO - 2022-05-08 14:11:18 --> Config Class Initialized
INFO - 2022-05-08 14:11:18 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:11:18 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:11:18 --> Utf8 Class Initialized
INFO - 2022-05-08 14:11:18 --> URI Class Initialized
INFO - 2022-05-08 14:11:18 --> Router Class Initialized
INFO - 2022-05-08 14:11:18 --> Output Class Initialized
INFO - 2022-05-08 14:11:18 --> Security Class Initialized
DEBUG - 2022-05-08 14:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:11:18 --> Input Class Initialized
INFO - 2022-05-08 14:11:18 --> Language Class Initialized
INFO - 2022-05-08 14:11:18 --> Language Class Initialized
INFO - 2022-05-08 14:11:18 --> Config Class Initialized
INFO - 2022-05-08 14:11:18 --> Loader Class Initialized
INFO - 2022-05-08 14:11:18 --> Helper loaded: url_helper
INFO - 2022-05-08 14:11:18 --> Database Driver Class Initialized
INFO - 2022-05-08 14:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:11:18 --> Controller Class Initialized
DEBUG - 2022-05-08 14:11:18 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:11:18 --> Model Class Initialized
DEBUG - 2022-05-08 14:11:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:11:18 --> Model Class Initialized
DEBUG - 2022-05-08 14:11:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:11:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:11:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:11:18 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:11:18 --> Final output sent to browser
DEBUG - 2022-05-08 14:11:18 --> Total execution time: 0.0433
INFO - 2022-05-08 14:11:59 --> Config Class Initialized
INFO - 2022-05-08 14:11:59 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:11:59 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:11:59 --> Utf8 Class Initialized
INFO - 2022-05-08 14:11:59 --> URI Class Initialized
INFO - 2022-05-08 14:11:59 --> Router Class Initialized
INFO - 2022-05-08 14:11:59 --> Output Class Initialized
INFO - 2022-05-08 14:11:59 --> Security Class Initialized
DEBUG - 2022-05-08 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:11:59 --> Input Class Initialized
INFO - 2022-05-08 14:11:59 --> Language Class Initialized
INFO - 2022-05-08 14:11:59 --> Language Class Initialized
INFO - 2022-05-08 14:11:59 --> Config Class Initialized
INFO - 2022-05-08 14:11:59 --> Loader Class Initialized
INFO - 2022-05-08 14:11:59 --> Helper loaded: url_helper
INFO - 2022-05-08 14:11:59 --> Database Driver Class Initialized
INFO - 2022-05-08 14:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:11:59 --> Controller Class Initialized
DEBUG - 2022-05-08 14:11:59 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:11:59 --> Model Class Initialized
DEBUG - 2022-05-08 14:11:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:11:59 --> Model Class Initialized
DEBUG - 2022-05-08 14:11:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:11:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:11:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:11:59 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:11:59 --> Final output sent to browser
DEBUG - 2022-05-08 14:11:59 --> Total execution time: 0.0386
INFO - 2022-05-08 14:12:38 --> Config Class Initialized
INFO - 2022-05-08 14:12:38 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:12:38 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:12:38 --> Utf8 Class Initialized
INFO - 2022-05-08 14:12:38 --> URI Class Initialized
INFO - 2022-05-08 14:12:38 --> Router Class Initialized
INFO - 2022-05-08 14:12:38 --> Output Class Initialized
INFO - 2022-05-08 14:12:38 --> Security Class Initialized
DEBUG - 2022-05-08 14:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:12:38 --> Input Class Initialized
INFO - 2022-05-08 14:12:38 --> Language Class Initialized
INFO - 2022-05-08 14:12:38 --> Language Class Initialized
INFO - 2022-05-08 14:12:38 --> Config Class Initialized
INFO - 2022-05-08 14:12:38 --> Loader Class Initialized
INFO - 2022-05-08 14:12:38 --> Helper loaded: url_helper
INFO - 2022-05-08 14:12:38 --> Database Driver Class Initialized
INFO - 2022-05-08 14:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:12:39 --> Controller Class Initialized
DEBUG - 2022-05-08 14:12:39 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:12:39 --> Model Class Initialized
DEBUG - 2022-05-08 14:12:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:12:39 --> Model Class Initialized
DEBUG - 2022-05-08 14:12:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:12:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:12:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:12:39 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:12:39 --> Final output sent to browser
DEBUG - 2022-05-08 14:12:39 --> Total execution time: 0.0365
INFO - 2022-05-08 14:12:54 --> Config Class Initialized
INFO - 2022-05-08 14:12:54 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:12:54 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:12:54 --> Utf8 Class Initialized
INFO - 2022-05-08 14:12:54 --> URI Class Initialized
INFO - 2022-05-08 14:12:54 --> Router Class Initialized
INFO - 2022-05-08 14:12:54 --> Output Class Initialized
INFO - 2022-05-08 14:12:54 --> Security Class Initialized
DEBUG - 2022-05-08 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:12:54 --> Input Class Initialized
INFO - 2022-05-08 14:12:54 --> Language Class Initialized
INFO - 2022-05-08 14:12:54 --> Language Class Initialized
INFO - 2022-05-08 14:12:54 --> Config Class Initialized
INFO - 2022-05-08 14:12:54 --> Loader Class Initialized
INFO - 2022-05-08 14:12:54 --> Helper loaded: url_helper
INFO - 2022-05-08 14:12:54 --> Database Driver Class Initialized
INFO - 2022-05-08 14:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:12:54 --> Controller Class Initialized
DEBUG - 2022-05-08 14:12:54 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:12:54 --> Model Class Initialized
DEBUG - 2022-05-08 14:12:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:12:54 --> Model Class Initialized
DEBUG - 2022-05-08 14:12:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:12:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:12:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:12:54 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:12:54 --> Final output sent to browser
DEBUG - 2022-05-08 14:12:54 --> Total execution time: 0.0388
INFO - 2022-05-08 14:14:09 --> Config Class Initialized
INFO - 2022-05-08 14:14:09 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:14:09 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:14:09 --> Utf8 Class Initialized
INFO - 2022-05-08 14:14:09 --> URI Class Initialized
INFO - 2022-05-08 14:14:09 --> Router Class Initialized
INFO - 2022-05-08 14:14:09 --> Output Class Initialized
INFO - 2022-05-08 14:14:09 --> Security Class Initialized
DEBUG - 2022-05-08 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:14:09 --> Input Class Initialized
INFO - 2022-05-08 14:14:09 --> Language Class Initialized
INFO - 2022-05-08 14:14:09 --> Language Class Initialized
INFO - 2022-05-08 14:14:09 --> Config Class Initialized
INFO - 2022-05-08 14:14:09 --> Loader Class Initialized
INFO - 2022-05-08 14:14:09 --> Helper loaded: url_helper
INFO - 2022-05-08 14:14:09 --> Database Driver Class Initialized
INFO - 2022-05-08 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:14:09 --> Controller Class Initialized
DEBUG - 2022-05-08 14:14:09 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:14:09 --> Model Class Initialized
DEBUG - 2022-05-08 14:14:09 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:14:09 --> Model Class Initialized
DEBUG - 2022-05-08 14:14:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:14:10 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:14:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:14:11 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:14:11 --> Final output sent to browser
DEBUG - 2022-05-08 14:14:11 --> Total execution time: 1.6356
INFO - 2022-05-08 14:15:47 --> Config Class Initialized
INFO - 2022-05-08 14:15:47 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:15:47 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:15:47 --> Utf8 Class Initialized
INFO - 2022-05-08 14:15:47 --> URI Class Initialized
INFO - 2022-05-08 14:15:47 --> Router Class Initialized
INFO - 2022-05-08 14:15:47 --> Output Class Initialized
INFO - 2022-05-08 14:15:47 --> Security Class Initialized
DEBUG - 2022-05-08 14:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:15:47 --> Input Class Initialized
INFO - 2022-05-08 14:15:47 --> Language Class Initialized
INFO - 2022-05-08 14:15:47 --> Language Class Initialized
INFO - 2022-05-08 14:15:47 --> Config Class Initialized
INFO - 2022-05-08 14:15:47 --> Loader Class Initialized
INFO - 2022-05-08 14:15:47 --> Helper loaded: url_helper
INFO - 2022-05-08 14:15:47 --> Database Driver Class Initialized
INFO - 2022-05-08 14:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:15:47 --> Controller Class Initialized
DEBUG - 2022-05-08 14:15:47 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:15:47 --> Model Class Initialized
DEBUG - 2022-05-08 14:15:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:15:47 --> Model Class Initialized
DEBUG - 2022-05-08 14:15:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:15:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:15:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:15:47 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:15:47 --> Final output sent to browser
DEBUG - 2022-05-08 14:15:47 --> Total execution time: 0.1430
INFO - 2022-05-08 14:16:13 --> Config Class Initialized
INFO - 2022-05-08 14:16:13 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:13 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:13 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:13 --> URI Class Initialized
INFO - 2022-05-08 14:16:13 --> Router Class Initialized
INFO - 2022-05-08 14:16:13 --> Output Class Initialized
INFO - 2022-05-08 14:16:13 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:13 --> Input Class Initialized
INFO - 2022-05-08 14:16:13 --> Language Class Initialized
INFO - 2022-05-08 14:16:13 --> Language Class Initialized
INFO - 2022-05-08 14:16:13 --> Config Class Initialized
INFO - 2022-05-08 14:16:13 --> Loader Class Initialized
INFO - 2022-05-08 14:16:13 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:13 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:13 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:13 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:13 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:13 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:16:13 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:13 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:13 --> Total execution time: 0.0370
INFO - 2022-05-08 14:16:33 --> Config Class Initialized
INFO - 2022-05-08 14:16:33 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:33 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:33 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:33 --> URI Class Initialized
INFO - 2022-05-08 14:16:33 --> Router Class Initialized
INFO - 2022-05-08 14:16:33 --> Output Class Initialized
INFO - 2022-05-08 14:16:33 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:33 --> Input Class Initialized
INFO - 2022-05-08 14:16:33 --> Language Class Initialized
INFO - 2022-05-08 14:16:33 --> Language Class Initialized
INFO - 2022-05-08 14:16:33 --> Config Class Initialized
INFO - 2022-05-08 14:16:33 --> Loader Class Initialized
INFO - 2022-05-08 14:16:33 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:33 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:33 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:33 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:33 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:33 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:16:33 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:33 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:33 --> Total execution time: 0.0386
INFO - 2022-05-08 14:16:37 --> Config Class Initialized
INFO - 2022-05-08 14:16:37 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:37 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:37 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:37 --> URI Class Initialized
INFO - 2022-05-08 14:16:37 --> Router Class Initialized
INFO - 2022-05-08 14:16:37 --> Output Class Initialized
INFO - 2022-05-08 14:16:37 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:37 --> Input Class Initialized
INFO - 2022-05-08 14:16:37 --> Language Class Initialized
INFO - 2022-05-08 14:16:37 --> Language Class Initialized
INFO - 2022-05-08 14:16:37 --> Config Class Initialized
INFO - 2022-05-08 14:16:37 --> Loader Class Initialized
INFO - 2022-05-08 14:16:37 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:37 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:37 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:37 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:37 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:37 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:16:37 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:37 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:37 --> Total execution time: 0.0386
INFO - 2022-05-08 14:16:42 --> Config Class Initialized
INFO - 2022-05-08 14:16:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:42 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:42 --> URI Class Initialized
INFO - 2022-05-08 14:16:42 --> Router Class Initialized
INFO - 2022-05-08 14:16:42 --> Output Class Initialized
INFO - 2022-05-08 14:16:42 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:42 --> Input Class Initialized
INFO - 2022-05-08 14:16:42 --> Language Class Initialized
INFO - 2022-05-08 14:16:42 --> Language Class Initialized
INFO - 2022-05-08 14:16:42 --> Config Class Initialized
INFO - 2022-05-08 14:16:42 --> Loader Class Initialized
INFO - 2022-05-08 14:16:42 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:42 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:42 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:42 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:42 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 14:16:43 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:43 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:43 --> Total execution time: 1.3653
INFO - 2022-05-08 14:16:48 --> Config Class Initialized
INFO - 2022-05-08 14:16:48 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:48 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:48 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:48 --> URI Class Initialized
INFO - 2022-05-08 14:16:48 --> Router Class Initialized
INFO - 2022-05-08 14:16:48 --> Output Class Initialized
INFO - 2022-05-08 14:16:48 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:48 --> Input Class Initialized
INFO - 2022-05-08 14:16:48 --> Language Class Initialized
INFO - 2022-05-08 14:16:48 --> Language Class Initialized
INFO - 2022-05-08 14:16:48 --> Config Class Initialized
INFO - 2022-05-08 14:16:48 --> Loader Class Initialized
INFO - 2022-05-08 14:16:48 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:48 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:48 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:48 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:48 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:48 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:48 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 14:16:49 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:49 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:49 --> Total execution time: 1.3630
INFO - 2022-05-08 14:16:53 --> Config Class Initialized
INFO - 2022-05-08 14:16:53 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:53 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:53 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:53 --> URI Class Initialized
INFO - 2022-05-08 14:16:53 --> Router Class Initialized
INFO - 2022-05-08 14:16:53 --> Output Class Initialized
INFO - 2022-05-08 14:16:53 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:53 --> Input Class Initialized
INFO - 2022-05-08 14:16:53 --> Language Class Initialized
INFO - 2022-05-08 14:16:53 --> Language Class Initialized
INFO - 2022-05-08 14:16:53 --> Config Class Initialized
INFO - 2022-05-08 14:16:53 --> Loader Class Initialized
INFO - 2022-05-08 14:16:53 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:53 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:53 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:53 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:53 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:53 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 14:16:53 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:53 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:53 --> Total execution time: 0.0936
INFO - 2022-05-08 14:16:56 --> Config Class Initialized
INFO - 2022-05-08 14:16:56 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:56 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:56 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:56 --> URI Class Initialized
INFO - 2022-05-08 14:16:56 --> Router Class Initialized
INFO - 2022-05-08 14:16:56 --> Output Class Initialized
INFO - 2022-05-08 14:16:56 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:56 --> Input Class Initialized
INFO - 2022-05-08 14:16:56 --> Language Class Initialized
INFO - 2022-05-08 14:16:56 --> Language Class Initialized
INFO - 2022-05-08 14:16:56 --> Config Class Initialized
INFO - 2022-05-08 14:16:56 --> Loader Class Initialized
INFO - 2022-05-08 14:16:56 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:56 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:56 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:56 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:56 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:56 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 14:16:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:56 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:56 --> Total execution time: 0.1330
INFO - 2022-05-08 14:16:57 --> Config Class Initialized
INFO - 2022-05-08 14:16:57 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:16:57 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:16:57 --> Utf8 Class Initialized
INFO - 2022-05-08 14:16:57 --> URI Class Initialized
INFO - 2022-05-08 14:16:57 --> Router Class Initialized
INFO - 2022-05-08 14:16:57 --> Output Class Initialized
INFO - 2022-05-08 14:16:57 --> Security Class Initialized
DEBUG - 2022-05-08 14:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:16:57 --> Input Class Initialized
INFO - 2022-05-08 14:16:57 --> Language Class Initialized
INFO - 2022-05-08 14:16:57 --> Language Class Initialized
INFO - 2022-05-08 14:16:57 --> Config Class Initialized
INFO - 2022-05-08 14:16:57 --> Loader Class Initialized
INFO - 2022-05-08 14:16:57 --> Helper loaded: url_helper
INFO - 2022-05-08 14:16:57 --> Database Driver Class Initialized
INFO - 2022-05-08 14:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:16:57 --> Controller Class Initialized
DEBUG - 2022-05-08 14:16:57 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:16:57 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:16:57 --> Model Class Initialized
DEBUG - 2022-05-08 14:16:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:16:57 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:16:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-08 14:16:58 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:16:58 --> Final output sent to browser
DEBUG - 2022-05-08 14:16:58 --> Total execution time: 0.3719
INFO - 2022-05-08 14:17:00 --> Config Class Initialized
INFO - 2022-05-08 14:17:00 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:17:00 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:17:00 --> Utf8 Class Initialized
INFO - 2022-05-08 14:17:00 --> URI Class Initialized
INFO - 2022-05-08 14:17:00 --> Router Class Initialized
INFO - 2022-05-08 14:17:00 --> Output Class Initialized
INFO - 2022-05-08 14:17:00 --> Security Class Initialized
DEBUG - 2022-05-08 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:17:00 --> Input Class Initialized
INFO - 2022-05-08 14:17:00 --> Language Class Initialized
INFO - 2022-05-08 14:17:00 --> Language Class Initialized
INFO - 2022-05-08 14:17:00 --> Config Class Initialized
INFO - 2022-05-08 14:17:00 --> Loader Class Initialized
INFO - 2022-05-08 14:17:00 --> Helper loaded: url_helper
INFO - 2022-05-08 14:17:00 --> Database Driver Class Initialized
INFO - 2022-05-08 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:17:00 --> Controller Class Initialized
DEBUG - 2022-05-08 14:17:00 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:17:00 --> Model Class Initialized
DEBUG - 2022-05-08 14:17:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:17:00 --> Model Class Initialized
DEBUG - 2022-05-08 14:17:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:17:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:17:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:17:00 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:17:00 --> Final output sent to browser
DEBUG - 2022-05-08 14:17:00 --> Total execution time: 0.0298
INFO - 2022-05-08 14:17:05 --> Config Class Initialized
INFO - 2022-05-08 14:17:05 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:17:05 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:17:05 --> Utf8 Class Initialized
INFO - 2022-05-08 14:17:05 --> URI Class Initialized
INFO - 2022-05-08 14:17:05 --> Router Class Initialized
INFO - 2022-05-08 14:17:05 --> Output Class Initialized
INFO - 2022-05-08 14:17:05 --> Security Class Initialized
DEBUG - 2022-05-08 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:17:05 --> Input Class Initialized
INFO - 2022-05-08 14:17:05 --> Language Class Initialized
INFO - 2022-05-08 14:17:05 --> Language Class Initialized
INFO - 2022-05-08 14:17:05 --> Config Class Initialized
INFO - 2022-05-08 14:17:05 --> Loader Class Initialized
INFO - 2022-05-08 14:17:05 --> Helper loaded: url_helper
INFO - 2022-05-08 14:17:05 --> Database Driver Class Initialized
INFO - 2022-05-08 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:17:05 --> Controller Class Initialized
DEBUG - 2022-05-08 14:17:05 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:17:05 --> Model Class Initialized
DEBUG - 2022-05-08 14:17:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:17:05 --> Model Class Initialized
DEBUG - 2022-05-08 14:17:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:17:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:17:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 14:17:05 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:17:05 --> Final output sent to browser
DEBUG - 2022-05-08 14:17:05 --> Total execution time: 0.0388
INFO - 2022-05-08 14:17:55 --> Config Class Initialized
INFO - 2022-05-08 14:17:55 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:17:55 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:17:55 --> Utf8 Class Initialized
INFO - 2022-05-08 14:17:55 --> URI Class Initialized
INFO - 2022-05-08 14:17:55 --> Router Class Initialized
INFO - 2022-05-08 14:17:55 --> Output Class Initialized
INFO - 2022-05-08 14:17:55 --> Security Class Initialized
DEBUG - 2022-05-08 14:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:17:55 --> Input Class Initialized
INFO - 2022-05-08 14:17:55 --> Language Class Initialized
INFO - 2022-05-08 14:17:55 --> Language Class Initialized
INFO - 2022-05-08 14:17:55 --> Config Class Initialized
INFO - 2022-05-08 14:17:55 --> Loader Class Initialized
INFO - 2022-05-08 14:17:55 --> Helper loaded: url_helper
INFO - 2022-05-08 14:17:55 --> Database Driver Class Initialized
INFO - 2022-05-08 14:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:17:55 --> Controller Class Initialized
DEBUG - 2022-05-08 14:17:55 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:17:55 --> Model Class Initialized
DEBUG - 2022-05-08 14:17:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:17:55 --> Model Class Initialized
DEBUG - 2022-05-08 14:17:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:17:55 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:17:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 14:17:56 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:17:56 --> Final output sent to browser
DEBUG - 2022-05-08 14:17:56 --> Total execution time: 1.7611
INFO - 2022-05-08 14:18:07 --> Config Class Initialized
INFO - 2022-05-08 14:18:07 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:07 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:07 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:07 --> URI Class Initialized
INFO - 2022-05-08 14:18:07 --> Router Class Initialized
INFO - 2022-05-08 14:18:07 --> Output Class Initialized
INFO - 2022-05-08 14:18:07 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:07 --> Input Class Initialized
INFO - 2022-05-08 14:18:07 --> Language Class Initialized
INFO - 2022-05-08 14:18:07 --> Language Class Initialized
INFO - 2022-05-08 14:18:07 --> Config Class Initialized
INFO - 2022-05-08 14:18:07 --> Loader Class Initialized
INFO - 2022-05-08 14:18:07 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:07 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:07 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:07 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:07 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:07 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:18:07 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:07 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:07 --> Total execution time: 0.0548
INFO - 2022-05-08 14:18:14 --> Config Class Initialized
INFO - 2022-05-08 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:14 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:14 --> URI Class Initialized
INFO - 2022-05-08 14:18:14 --> Router Class Initialized
INFO - 2022-05-08 14:18:14 --> Output Class Initialized
INFO - 2022-05-08 14:18:14 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:14 --> Input Class Initialized
INFO - 2022-05-08 14:18:14 --> Language Class Initialized
INFO - 2022-05-08 14:18:14 --> Language Class Initialized
INFO - 2022-05-08 14:18:14 --> Config Class Initialized
INFO - 2022-05-08 14:18:14 --> Loader Class Initialized
INFO - 2022-05-08 14:18:14 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:14 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:14 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:14 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:14 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:14 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:18:14 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:14 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:14 --> Total execution time: 0.0422
INFO - 2022-05-08 14:18:30 --> Config Class Initialized
INFO - 2022-05-08 14:18:30 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:30 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:30 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:30 --> URI Class Initialized
INFO - 2022-05-08 14:18:30 --> Router Class Initialized
INFO - 2022-05-08 14:18:30 --> Output Class Initialized
INFO - 2022-05-08 14:18:30 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:30 --> Input Class Initialized
INFO - 2022-05-08 14:18:30 --> Language Class Initialized
INFO - 2022-05-08 14:18:30 --> Language Class Initialized
INFO - 2022-05-08 14:18:30 --> Config Class Initialized
INFO - 2022-05-08 14:18:30 --> Loader Class Initialized
INFO - 2022-05-08 14:18:30 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:30 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:30 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:30 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:30 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:30 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/dashboard.php
DEBUG - 2022-05-08 14:18:30 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:30 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:30 --> Total execution time: 0.0367
INFO - 2022-05-08 14:18:38 --> Config Class Initialized
INFO - 2022-05-08 14:18:38 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:38 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:38 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:38 --> URI Class Initialized
INFO - 2022-05-08 14:18:38 --> Router Class Initialized
INFO - 2022-05-08 14:18:38 --> Output Class Initialized
INFO - 2022-05-08 14:18:38 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:38 --> Input Class Initialized
INFO - 2022-05-08 14:18:38 --> Language Class Initialized
INFO - 2022-05-08 14:18:38 --> Language Class Initialized
INFO - 2022-05-08 14:18:38 --> Config Class Initialized
INFO - 2022-05-08 14:18:38 --> Loader Class Initialized
INFO - 2022-05-08 14:18:38 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:38 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:38 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:38 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:38 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:38 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 14:18:38 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:38 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:38 --> Total execution time: 0.0353
INFO - 2022-05-08 14:18:41 --> Config Class Initialized
INFO - 2022-05-08 14:18:41 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:41 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:41 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:41 --> URI Class Initialized
INFO - 2022-05-08 14:18:41 --> Router Class Initialized
INFO - 2022-05-08 14:18:41 --> Output Class Initialized
INFO - 2022-05-08 14:18:41 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:41 --> Input Class Initialized
INFO - 2022-05-08 14:18:41 --> Language Class Initialized
INFO - 2022-05-08 14:18:41 --> Language Class Initialized
INFO - 2022-05-08 14:18:41 --> Config Class Initialized
INFO - 2022-05-08 14:18:41 --> Loader Class Initialized
INFO - 2022-05-08 14:18:41 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:41 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:41 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:41 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:41 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:41 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_bodytype.php
DEBUG - 2022-05-08 14:18:41 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:41 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:41 --> Total execution time: 0.0352
INFO - 2022-05-08 14:18:42 --> Config Class Initialized
INFO - 2022-05-08 14:18:42 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:42 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:42 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:42 --> URI Class Initialized
INFO - 2022-05-08 14:18:42 --> Router Class Initialized
INFO - 2022-05-08 14:18:42 --> Output Class Initialized
INFO - 2022-05-08 14:18:42 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:42 --> Input Class Initialized
INFO - 2022-05-08 14:18:42 --> Language Class Initialized
INFO - 2022-05-08 14:18:42 --> Language Class Initialized
INFO - 2022-05-08 14:18:42 --> Config Class Initialized
INFO - 2022-05-08 14:18:42 --> Loader Class Initialized
INFO - 2022-05-08 14:18:42 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:42 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:42 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:42 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:42 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:42 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_vehiclecolor.php
DEBUG - 2022-05-08 14:18:42 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:42 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:42 --> Total execution time: 0.0348
INFO - 2022-05-08 14:18:44 --> Config Class Initialized
INFO - 2022-05-08 14:18:44 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:44 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:44 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:44 --> URI Class Initialized
INFO - 2022-05-08 14:18:44 --> Router Class Initialized
INFO - 2022-05-08 14:18:44 --> Output Class Initialized
INFO - 2022-05-08 14:18:44 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:44 --> Input Class Initialized
INFO - 2022-05-08 14:18:44 --> Language Class Initialized
INFO - 2022-05-08 14:18:44 --> Language Class Initialized
INFO - 2022-05-08 14:18:44 --> Config Class Initialized
INFO - 2022-05-08 14:18:44 --> Loader Class Initialized
INFO - 2022-05-08 14:18:44 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:44 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:44 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:44 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:44 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:44 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_model.php
DEBUG - 2022-05-08 14:18:44 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:44 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:44 --> Total execution time: 0.0278
INFO - 2022-05-08 14:18:45 --> Config Class Initialized
INFO - 2022-05-08 14:18:45 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:45 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:45 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:45 --> URI Class Initialized
INFO - 2022-05-08 14:18:45 --> Router Class Initialized
INFO - 2022-05-08 14:18:45 --> Output Class Initialized
INFO - 2022-05-08 14:18:45 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:45 --> Input Class Initialized
INFO - 2022-05-08 14:18:45 --> Language Class Initialized
INFO - 2022-05-08 14:18:45 --> Language Class Initialized
INFO - 2022-05-08 14:18:45 --> Config Class Initialized
INFO - 2022-05-08 14:18:45 --> Loader Class Initialized
INFO - 2022-05-08 14:18:45 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:45 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:45 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:45 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:45 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:45 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_brand.php
DEBUG - 2022-05-08 14:18:45 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:45 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:45 --> Total execution time: 0.0355
INFO - 2022-05-08 14:18:46 --> Config Class Initialized
INFO - 2022-05-08 14:18:46 --> Hooks Class Initialized
DEBUG - 2022-05-08 14:18:46 --> UTF-8 Support Enabled
INFO - 2022-05-08 14:18:46 --> Utf8 Class Initialized
INFO - 2022-05-08 14:18:46 --> URI Class Initialized
INFO - 2022-05-08 14:18:46 --> Router Class Initialized
INFO - 2022-05-08 14:18:46 --> Output Class Initialized
INFO - 2022-05-08 14:18:46 --> Security Class Initialized
DEBUG - 2022-05-08 14:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-08 14:18:46 --> Input Class Initialized
INFO - 2022-05-08 14:18:46 --> Language Class Initialized
INFO - 2022-05-08 14:18:46 --> Language Class Initialized
INFO - 2022-05-08 14:18:46 --> Config Class Initialized
INFO - 2022-05-08 14:18:46 --> Loader Class Initialized
INFO - 2022-05-08 14:18:46 --> Helper loaded: url_helper
INFO - 2022-05-08 14:18:46 --> Database Driver Class Initialized
INFO - 2022-05-08 14:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-08 14:18:46 --> Controller Class Initialized
DEBUG - 2022-05-08 14:18:46 --> Admin MX_Controller Initialized
INFO - 2022-05-08 14:18:46 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/models/Admin_model.php
INFO - 2022-05-08 14:18:46 --> Model Class Initialized
DEBUG - 2022-05-08 14:18:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/head.php
DEBUG - 2022-05-08 14:18:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/header.php
DEBUG - 2022-05-08 14:18:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin/views/add_category.php
DEBUG - 2022-05-08 14:18:46 --> File loaded: N:\Xampp\htdocs\motodeal\application\modules/admin_common/views/footer.php
INFO - 2022-05-08 14:18:46 --> Final output sent to browser
DEBUG - 2022-05-08 14:18:46 --> Total execution time: 0.0374
